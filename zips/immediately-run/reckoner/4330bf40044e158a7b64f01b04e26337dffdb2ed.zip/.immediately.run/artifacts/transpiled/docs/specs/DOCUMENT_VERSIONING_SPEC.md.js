var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-reckoner-document-versioning-the-formatstdlibcatalog-compatibility-envelope",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-reckoner-document-versioning-the-formatstdlibcatalog-compatibility-envelope"
      }), "immediately.run Reckoner Document Versioning — the format/stdlib/catalog compatibility envelope"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spine 3"
      }), " of the up-front-design triage\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ARCHITECTURE_PLAN.md"
      }), " §0.1). Scope is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "envelope + compatibility policy\nonly"
      }), ", to be folded into the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "M1 format freeze"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " migration machinery. Design only,\nnothing built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/DOCUMENT_VERSIONING_STATUS.md"
          })]
        }), " (to be created at build) — where they disagree,\nthe status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ARCHITECTURE_PLAN.md"
        }), " §3 (document model — the formats this\nversions), §3.2 (additive-only stdlib), §3.3 (the component catalog), §5.4 (freeze/frames),\n§12 (the parked \"catalog/stdlib versioning\" + \"reproducibility\" questions this closes);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENGINE_INFORMATION_FLOW_SPEC.md"
        }), " §4 C5 (frozen frames carry a capture epoch — the\nreproducibility hook). Companion practice: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "new-project-template"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"immediately.run\": { \"requireLatest\" }"
        }), " (the platform's existing freshness enum — a\nprecedent for a document-level compatibility field)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-why-this-is-up-front-not-implementation-time-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Why this is up-front, not implementation-time  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A Reckoner document is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "long-lived and shared"
      }), ": it is opened by viewers, forked, and\nre-run months after it was authored, against whatever app version is current then. Four\nthings underneath it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "evolve independently of the document"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "document format"
        }), " (the worksheet/template/fixture/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reckoner.json"
        }), " schema, §3);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "stdlib"
        }), " (formula callables, §3.2 — additive-only, but additions still change what a\ndocument may reference);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "component catalog"
        }), " (template components, §3.3 — additive; includes the responsive\nconditional components ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ShowAbove"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ShowBelow"
        }), " with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "width"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "height"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dpr"
        }), " literal\nthresholds, which are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "template syntax"
        }), " and are therefore frozen with the v1 catalog at\nM1 — a document using them declares the catalog version that introduced them,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §3.3.1/§13"
        }), ");"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tier-tag encoding"
        }), " and other host-interpreted metadata (§5.4)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["If the format carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no version envelope from v1"
      }), ", the first change to any of these either\nbreaks every shared/forked document or renders it silently wrong — and retrofitting an envelope\nis a migration of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "every document in existence"
      }), ". The envelope is cheap now (a few fields + a\nresolution rule) and a rewrite later. That asymmetry is why it is booked for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "M1 freeze"
      }), ",\nbefore any document is shared."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This spec deliberately specifies ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only the envelope and the resolution policy"
      }), " — enough that\nlater evolution is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "possible"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "legible"
      }), ". The actual per-version migrations, codemods, and\ncatalog shims are implementation-time work that the envelope makes tractable."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-envelope-what-a-document-declares-proposal-owned-by-the-m1-freeze",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. The envelope — what a document declares  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — owned by the M1 freeze)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "reckoner.json"
      }), " carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "compat"
      }), " block. Every field is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "range the document was authored\nagainst and needs"
      }), ", not a pin:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "// reckoner.json\n{\n  \"format\": 1,                       // integer; the document-schema major (breaking → bump)\n  \"compat\": {\n    \"stdlib\":  \">=1.4 <2\",           // the formula stdlib the worksheets rely on\n    \"catalog\": \">=1.2 <2\",           // the template component catalog the templates rely on\n    \"tierTag\": 1                     // the tier-tag encoding version (host-interpreted)\n  },\n  \"authoredWith\": {                  // provenance, not a constraint (reproducibility, §4)\n    \"app\": \"reckoner@1.4.2\",\n    \"stdlib\": \"1.4.0\",\n    \"catalog\": \"1.2.1\"\n  }\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "format"
          })
        }), " is an integer major. A breaking schema change bumps it; the app supports a set of\nformat majors and refuses (legibly, §3) a format it does not know."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "compat.*"
          })
        }), " are semver ranges. A document declares the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "minimum"
        }), " it needs and the major\nit was built for. Because stdlib and catalog are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "additive-only"
        }), " (§3.2/§3.3), the common\ncase is \"needs ≥ the version that introduced the newest callable/component I use, same major\"\n— a lower bound, open upper bound within the major."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "authoredWith"
          })
        }), " is exact-version ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "provenance"
        }), ", never used for resolution — it exists so a\nre-run can be reproduced (§4)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The author does not hand-maintain ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "compat"
      }), ": the host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "derives"
      }), " the lower bounds by static\nanalysis (which stdlib callables the worksheets import, which components the templates use →\nthe versions that introduced them) at save time, the same way it derives the dependency graph\n(§3.1). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "authoredWith"
      }), " is stamped by the running app."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-resolution-rule-how-the-current-app-opens-an-old-document-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The resolution rule — how the current app opens an old document  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["On open, the app compares its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{format, stdlib, catalog, tierTag}"
      }), " versions to the\ndocument's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "compat"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Case"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Result"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["App satisfies every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "compat"
            }), " range and knows the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "format"
            }), " major"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Runs normally."
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["App's stdlib/catalog is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "newer, same major"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Runs"
            }), " (additive-only guarantees the document's callables/components still exist)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Document needs a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "newer"
            }), " stdlib/catalog than the app has (e.g. an old app opening a new document)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Legible degradation"
            }), " (§3): the specific unknown callable/component renders as a marked placeholder naming what it needs; the rest runs. Never a silent wrong render."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["App does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not"
            }), " know the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "format"
            }), " major (a breaking schema change it predates)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Refuse with a legible message"
            }), " (\"this report needs a newer Reckoner\"), never a partial parse."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "additive-only contract does the heavy lifting"
      }), " (§3.2 decision): within a major, forward\ncompatibility is free because nothing is ever removed or changed — only added. The envelope's\njob is to make the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "cross-major"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "old-app-new-document"
      }), " cases ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "legible"
      }), ", not to prevent\nthem. A major bump is the escape hatch for the one thing additive-only cannot absorb (a genuine\nbreaking change); it is expected to be rare and to ship with a codemod (implementation-time)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-legible-degradation-not-silent-wrong-data-normative-reuses-33",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Legible degradation, not silent wrong data  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — reuses §3.3)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The degradation surface is the one the catalog already defines (§3.3): an unknown component\nrenders as a safe placeholder naming what it needs, and this spec extends the same treatment to\nan unknown-stdlib formula (the cell renders as a marked \"needs stdlib ≥ x\" tile, not a broken\nvalue or a silent zero) and an unknown tier-tag encoding (the value is treated as its\nhost-authoritative mount tier — §5.4/L1 — and the unreadable in-file tag is ignored, never\ntrusted). The invariant: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a version mismatch degrades visibly and specifically; it never\nproduces a plausible-but-wrong number."
      }), " This composes with the testing story's standing rule\n(a green suite over a mismatched runtime is not a correctness claim)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-reproducibility-falls-out-of-the-envelope-normative-intent-closes-a-12-parked-question",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. Reproducibility falls out of the envelope  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent — closes a §12 parked question)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["\"Which numbers did we report last quarter?\" is answerable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "iff"
      }), " the document records the\nversions that produced them. The envelope provides two of the three needed pieces, and Spine 1\nprovides the third:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "authoredWith"
          })
        }), " (§1) records the exact app/stdlib/catalog versions — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "code"
        }), " that\ncomputed the numbers."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "frozen frame / snapshot"
        }), " (§5.4, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENGINE_INFORMATION_FLOW §4"
        }), " C5) records the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "data"
        }), " and\nits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "capture epoch"
        }), " — the inputs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Re-running (1) over (2) reproduces the numbers, because formulas are pure (§3.1)."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["So \"report reproducibility\" is not a separate feature: it is ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authoredWith"
        }), " + a freeze at\nreport time"]
      }), ". The spec's only ask of the M1 freeze is that both are recorded; the actual\n\"open last quarter's version\" UX is implementation-time. Honesty note: reproducibility holds\nonly for a document that was ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "frozen"
      }), " at report time — a live report re-run today shows\ntoday's data by design, which is correct, not a bug."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-concurrency-constraint-decide-now-design-later-normative-a-constraint-not-a-v1-design",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. The concurrency constraint — decide now, design later  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — a constraint, not a v1 design)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Concurrent multi-author editing is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " a v1 feature. But the format must not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "preclude"
      }), "\nit, because retrofitting concurrency into a positional/whole-file format is a rewrite. The\nconstraint the M1 freeze must honor:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cells are independent, named units"
        }), " (§3.1 — names not coordinates), and a worksheet is a\nset of named exports, not an ordered grid. So an edit is scoped to a named cell, and a future\nmerge is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "per-cell"
        }), " (two authors editing different cells never conflict; two editing the\nsame cell is an ordinary text/CRDT merge on that cell's source). The named-cell model — chosen\nfor review and agent-ergonomics — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "already"
        }), " satisfies this; the constraint is simply ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "don't\nregress it"
        }), " (no positional cell identity, no whole-file-as-the-unit format)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "That one sentence is the entire up-front concurrency cost. The CRDT/merge design itself is\ndeferred."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-load-bearing-assumptions-code-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Load-bearing assumptions & code anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-2026-07-09",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-2026-07-09"
      }), "Depends-on-today (verified 2026-07-09)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption (existing behavior the design rests on)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.tbody, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The platform already has an app-level ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "package.json"
            }), " freshness-enum precedent (a document-compat analogue)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "new-project-template/README.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "requireLatest"
            })
          })]
        })
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Every document carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "format"
            }), " major + derived ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "compat"
            }), " ranges + stamped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authoredWith"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["envelope test: a saved document has a valid ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "compat"
            }), " block the host derived from its imports/uses"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "An old app opening a newer-stdlib document degrades legibly per cell, never silently"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "forward-compat gate: a document using a callable the app lacks renders a \"needs stdlib ≥ x\" tile, not a wrong value"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["An unknown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "format"
            }), " major is refused, not partially parsed"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["format-refusal gate: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "format"
            }), " the app predates yields a legible refusal"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A frozen report + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authoredWith"
            }), " reproduces its numbers on re-run"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "reproducibility gate: re-running the recorded versions over the frozen frame reproduces the reported values"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Cell identity is name-based, not positional (concurrency not precluded)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "format-constraint check: no positional cell identity anywhere in the schema"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A version ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "envelope"
          }), " (ranges + provenance) in v1; migrations deferred."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\nshipping the format with no version field (retrofitting is a per-document migration); building\nthe full migration/codemod machinery up-front (implementation-time; the envelope makes it\ntractable without pre-building it)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Host-derived ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "compat"
          }), " lower bounds, not author-maintained."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " asking authors to\nhand-maintain version ranges (rots; the host already does the static analysis for the\ndependency graph)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Additive-only stdlib/catalog does forward-compat; the envelope only makes cross-major and\nold-app cases legible."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " per-version compatibility shims as the primary mechanism\n(additive-only makes them unnecessary within a major)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Reproducibility = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "authoredWith"
          }), " + freeze, not a separate feature."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " a bespoke\nversion-history/time-travel store (over-built for v1; the freeze + provenance already suffice\nfor \"what did we report\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Constrain the format to name-based cell identity so concurrency is not precluded; defer the\nmerge design."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " designing multi-author merge in v1 (not needed); a\npositional/whole-file format (would preclude a per-cell merge — a rewrite to add later)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-1 (catalog forks)."
        }), " A fork ships new components (§3.3). A document authored against a\nfork's catalog opened in stock Reckoner hits the unknown-component path (fine) — but should\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "compat.catalog"
        }), " be able to name a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "fork identity"
        }), ", or is \"unknown component → placeholder\"\nsufficient? Likely sufficient; confirm against the fork story."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-2 (tier-tag encoding evolution)."
        }), " §3 treats an unknown tier-tag as \"fall back to\nhost mount tier.\" Confirm that a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "newer"
        }), " tier encoding (finer granularity, per-column tiers if\nE-2 forces them) degrades safely to the coarser host tier and never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "up"
        }), "-labels."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-3 (stdlib deprecation within additive-only)."
        }), " Additive-only forbids removal — but a\ncallable can be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "discouraged"
        }), ". Does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "compat"
        }), " need a \"soft-deprecated since x\" signal for the\nreview surface, or is that out of scope for the envelope? Probably out of scope; note it."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/DOCUMENT_VERSIONING_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRPQ1VNRU5UX1ZFUlNJT05JTkdfU1BFQy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiaW1tZWRpYXRlbHlydW4tcmVja29uZXItZG9jdW1lbnQtdmVyc2lvbmluZy10aGUtZm9ybWF0c3RkbGliY2F0YWxvZy1jb21wYXRpYmlsaXR5LWVudmVsb3BlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJpbW1lZGlhdGVseXJ1bi1yZWNrb25lci1kb2N1bWVudC12ZXJzaW9uaW5nLXRoZS1mb3JtYXRzdGRsaWJjYXRhbG9nLWNvbXBhdGliaWxpdHktZW52ZWxvcGVcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBSZWNrb25lciBEb2N1bWVudCBWZXJzaW9uaW5nIOKAlCB0aGUgZm9ybWF0L3N0ZGxpYi9jYXRhbG9nIGNvbXBhdGliaWxpdHkgZW52ZWxvcGVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwcm9wb3NhbCAvIGRyYWZ0IOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwaW5lIDNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2YgdGhlIHVwLWZyb250LWRlc2lnbiB0cmlhZ2VcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi4vQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMC4xKS4gU2NvcGUgaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW52ZWxvcGUgKyBjb21wYXRpYmlsaXR5IHBvbGljeVxcbm9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHRvIGJlIGZvbGRlZCBpbnRvIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk0xIGZvcm1hdCBmcmVlemVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiBtaWdyYXRpb24gbWFjaGluZXJ5LiBEZXNpZ24gb25seSxcXG5ub3RoaW5nIGJ1aWx0LiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDctMDlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yIHRoaXMgc3BlYyBpc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3RhdHVzL0RPQ1VNRU5UX1ZFUlNJT05JTkdfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodG8gYmUgY3JlYXRlZCBhdCBidWlsZCkg4oCUIHdoZXJlIHRoZXkgZGlzYWdyZWUsXFxudGhlIHN0YXR1cyBkb2MgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3Q6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL0FSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMgKGRvY3VtZW50IG1vZGVsIOKAlCB0aGUgZm9ybWF0cyB0aGlzXFxudmVyc2lvbnMpLCDCpzMuMiAoYWRkaXRpdmUtb25seSBzdGRsaWIpLCDCpzMuMyAodGhlIGNvbXBvbmVudCBjYXRhbG9nKSwgwqc1LjQgKGZyZWV6ZS9mcmFtZXMpLFxcbsKnMTIgKHRoZSBwYXJrZWQgXFxcImNhdGFsb2cvc3RkbGliIHZlcnNpb25pbmdcXFwiICsgXFxcInJlcHJvZHVjaWJpbGl0eVxcXCIgcXVlc3Rpb25zIHRoaXMgY2xvc2VzKTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJFTkdJTkVfSU5GT1JNQVRJT05fRkxPV19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzQgQzUgKGZyb3plbiBmcmFtZXMgY2FycnkgYSBjYXB0dXJlIGVwb2NoIOKAlCB0aGVcXG5yZXByb2R1Y2liaWxpdHkgaG9vaykuIENvbXBhbmlvbiBwcmFjdGljZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV3LXByb2plY3QtdGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW1tZWRpYXRlbHkucnVuXFxcIjogeyBcXFwicmVxdWlyZUxhdGVzdFxcXCIgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBwbGF0Zm9ybSdzIGV4aXN0aW5nIGZyZXNobmVzcyBlbnVtIOKAlCBhXFxucHJlY2VkZW50IGZvciBhIGRvY3VtZW50LWxldmVsIGNvbXBhdGliaWxpdHkgZmllbGQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTBcIiBkYXRhLXNsdWc9XCIwLXdoeS10aGlzLWlzLXVwLWZyb250LW5vdC1pbXBsZW1lbnRhdGlvbi10aW1lLW5vcm1hdGl2ZS1pbnRlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0wXCIgLz57XCIwLiBXaHkgdGhpcyBpcyB1cC1mcm9udCwgbm90IGltcGxlbWVudGF0aW9uLXRpbWUgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIGludGVudClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBSZWNrb25lciBkb2N1bWVudCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxvbmctbGl2ZWQgYW5kIHNoYXJlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogaXQgaXMgb3BlbmVkIGJ5IHZpZXdlcnMsIGZvcmtlZCwgYW5kXFxucmUtcnVuIG1vbnRocyBhZnRlciBpdCB3YXMgYXV0aG9yZWQsIGFnYWluc3Qgd2hhdGV2ZXIgYXBwIHZlcnNpb24gaXMgY3VycmVudCB0aGVuLiBGb3VyXFxudGhpbmdzIHVuZGVybmVhdGggaXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJldm9sdmUgaW5kZXBlbmRlbnRseSBvZiB0aGUgZG9jdW1lbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1widGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9jdW1lbnQgZm9ybWF0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgd29ya3NoZWV0L3RlbXBsYXRlL2ZpeHR1cmUvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVja29uZXIuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2NoZW1hLCDCpzMpO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInN0ZGxpYlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZm9ybXVsYSBjYWxsYWJsZXMsIMKnMy4yIOKAlCBhZGRpdGl2ZS1vbmx5LCBidXQgYWRkaXRpb25zIHN0aWxsIGNoYW5nZSB3aGF0IGFcXG5kb2N1bWVudCBtYXkgcmVmZXJlbmNlKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb21wb25lbnQgY2F0YWxvZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGVtcGxhdGUgY29tcG9uZW50cywgwqczLjMg4oCUIGFkZGl0aXZlOyBpbmNsdWRlcyB0aGUgcmVzcG9uc2l2ZVxcbmNvbmRpdGlvbmFsIGNvbXBvbmVudHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvd0Fib3ZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJTaG93QmVsb3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2lkdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImhlaWdodFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZHByXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsaXRlcmFsXFxudGhyZXNob2xkcywgd2hpY2ggYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGVtcGxhdGUgc3ludGF4XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBhcmUgdGhlcmVmb3JlIGZyb3plbiB3aXRoIHRoZSB2MSBjYXRhbG9nIGF0XFxuTTEg4oCUIGEgZG9jdW1lbnQgdXNpbmcgdGhlbSBkZWNsYXJlcyB0aGUgY2F0YWxvZyB2ZXJzaW9uIHRoYXQgaW50cm9kdWNlZCB0aGVtLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnMy4zLjEvwqcxM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRpZXItdGFnIGVuY29kaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBvdGhlciBob3N0LWludGVycHJldGVkIG1ldGFkYXRhICjCpzUuNCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIklmIHRoZSBmb3JtYXQgY2FycmllcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHZlcnNpb24gZW52ZWxvcGUgZnJvbSB2MVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdGhlIGZpcnN0IGNoYW5nZSB0byBhbnkgb2YgdGhlc2UgZWl0aGVyXFxuYnJlYWtzIGV2ZXJ5IHNoYXJlZC9mb3JrZWQgZG9jdW1lbnQgb3IgcmVuZGVycyBpdCBzaWxlbnRseSB3cm9uZyDigJQgYW5kIHJldHJvZml0dGluZyBhbiBlbnZlbG9wZVxcbmlzIGEgbWlncmF0aW9uIG9mIFwifTxfY29tcG9uZW50cy5lbT57XCJldmVyeSBkb2N1bWVudCBpbiBleGlzdGVuY2VcIn08L19jb21wb25lbnRzLmVtPntcIi4gVGhlIGVudmVsb3BlIGlzIGNoZWFwIG5vdyAoYSBmZXcgZmllbGRzICsgYVxcbnJlc29sdXRpb24gcnVsZSkgYW5kIGEgcmV3cml0ZSBsYXRlci4gVGhhdCBhc3ltbWV0cnkgaXMgd2h5IGl0IGlzIGJvb2tlZCBmb3IgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTTEgZnJlZXplXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLFxcbmJlZm9yZSBhbnkgZG9jdW1lbnQgaXMgc2hhcmVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIHNwZWMgZGVsaWJlcmF0ZWx5IHNwZWNpZmllcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHkgdGhlIGVudmVsb3BlIGFuZCB0aGUgcmVzb2x1dGlvbiBwb2xpY3lcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGVub3VnaCB0aGF0XFxubGF0ZXIgZXZvbHV0aW9uIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJwb3NzaWJsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuZW0+e1wibGVnaWJsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBUaGUgYWN0dWFsIHBlci12ZXJzaW9uIG1pZ3JhdGlvbnMsIGNvZGVtb2RzLCBhbmRcXG5jYXRhbG9nIHNoaW1zIGFyZSBpbXBsZW1lbnRhdGlvbi10aW1lIHdvcmsgdGhhdCB0aGUgZW52ZWxvcGUgbWFrZXMgdHJhY3RhYmxlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMVwiIGRhdGEtc2x1Zz1cIjEtdGhlLWVudmVsb3BlLXdoYXQtYS1kb2N1bWVudC1kZWNsYXJlcy1wcm9wb3NhbC1vd25lZC1ieS10aGUtbTEtZnJlZXplXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMS4gVGhlIGVudmVsb3BlIOKAlCB3aGF0IGEgZG9jdW1lbnQgZGVjbGFyZXMgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwg4oCUIG93bmVkIGJ5IHRoZSBNMSBmcmVlemUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInJlY2tvbmVyLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJsb2NrLiBFdmVyeSBmaWVsZCBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmFuZ2UgdGhlIGRvY3VtZW50IHdhcyBhdXRob3JlZFxcbmFnYWluc3QgYW5kIG5lZWRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYSBwaW46XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtanNvbmNcIj57XCIvLyByZWNrb25lci5qc29uXFxue1xcbiAgXFxcImZvcm1hdFxcXCI6IDEsICAgICAgICAgICAgICAgICAgICAgICAvLyBpbnRlZ2VyOyB0aGUgZG9jdW1lbnQtc2NoZW1hIG1ham9yIChicmVha2luZyDihpIgYnVtcClcXG4gIFxcXCJjb21wYXRcXFwiOiB7XFxuICAgIFxcXCJzdGRsaWJcXFwiOiAgXFxcIj49MS40IDwyXFxcIiwgICAgICAgICAgIC8vIHRoZSBmb3JtdWxhIHN0ZGxpYiB0aGUgd29ya3NoZWV0cyByZWx5IG9uXFxuICAgIFxcXCJjYXRhbG9nXFxcIjogXFxcIj49MS4yIDwyXFxcIiwgICAgICAgICAgIC8vIHRoZSB0ZW1wbGF0ZSBjb21wb25lbnQgY2F0YWxvZyB0aGUgdGVtcGxhdGVzIHJlbHkgb25cXG4gICAgXFxcInRpZXJUYWdcXFwiOiAxICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIHRpZXItdGFnIGVuY29kaW5nIHZlcnNpb24gKGhvc3QtaW50ZXJwcmV0ZWQpXFxuICB9LFxcbiAgXFxcImF1dGhvcmVkV2l0aFxcXCI6IHsgICAgICAgICAgICAgICAgICAvLyBwcm92ZW5hbmNlLCBub3QgYSBjb25zdHJhaW50IChyZXByb2R1Y2liaWxpdHksIMKnNClcXG4gICAgXFxcImFwcFxcXCI6IFxcXCJyZWNrb25lckAxLjQuMlxcXCIsXFxuICAgIFxcXCJzdGRsaWJcXFwiOiBcXFwiMS40LjBcXFwiLFxcbiAgICBcXFwiY2F0YWxvZ1xcXCI6IFxcXCIxLjIuMVxcXCJcXG4gIH1cXG59XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJmb3JtYXRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIGFuIGludGVnZXIgbWFqb3IuIEEgYnJlYWtpbmcgc2NoZW1hIGNoYW5nZSBidW1wcyBpdDsgdGhlIGFwcCBzdXBwb3J0cyBhIHNldCBvZlxcbmZvcm1hdCBtYWpvcnMgYW5kIHJlZnVzZXMgKGxlZ2libHksIMKnMykgYSBmb3JtYXQgaXQgZG9lcyBub3Qga25vdy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImNvbXBhdC4qXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhcmUgc2VtdmVyIHJhbmdlcy4gQSBkb2N1bWVudCBkZWNsYXJlcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtaW5pbXVtXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGl0IG5lZWRzIGFuZCB0aGUgbWFqb3JcXG5pdCB3YXMgYnVpbHQgZm9yLiBCZWNhdXNlIHN0ZGxpYiBhbmQgY2F0YWxvZyBhcmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhZGRpdGl2ZS1vbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzMuMi/CpzMuMyksIHRoZSBjb21tb25cXG5jYXNlIGlzIFxcXCJuZWVkcyDiiaUgdGhlIHZlcnNpb24gdGhhdCBpbnRyb2R1Y2VkIHRoZSBuZXdlc3QgY2FsbGFibGUvY29tcG9uZW50IEkgdXNlLCBzYW1lIG1ham9yXFxcIlxcbuKAlCBhIGxvd2VyIGJvdW5kLCBvcGVuIHVwcGVyIGJvdW5kIHdpdGhpbiB0aGUgbWFqb3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JlZFdpdGhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIGV4YWN0LXZlcnNpb24gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcm92ZW5hbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuZXZlciB1c2VkIGZvciByZXNvbHV0aW9uIOKAlCBpdCBleGlzdHMgc28gYVxcbnJlLXJ1biBjYW4gYmUgcmVwcm9kdWNlZCAowqc0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGF1dGhvciBkb2VzIG5vdCBoYW5kLW1haW50YWluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IHRoZSBob3N0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVyaXZlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgbG93ZXIgYm91bmRzIGJ5IHN0YXRpY1xcbmFuYWx5c2lzICh3aGljaCBzdGRsaWIgY2FsbGFibGVzIHRoZSB3b3Jrc2hlZXRzIGltcG9ydCwgd2hpY2ggY29tcG9uZW50cyB0aGUgdGVtcGxhdGVzIHVzZSDihpJcXG50aGUgdmVyc2lvbnMgdGhhdCBpbnRyb2R1Y2VkIHRoZW0pIGF0IHNhdmUgdGltZSwgdGhlIHNhbWUgd2F5IGl0IGRlcml2ZXMgdGhlIGRlcGVuZGVuY3kgZ3JhcGhcXG4owqczLjEpLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JlZFdpdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHN0YW1wZWQgYnkgdGhlIHJ1bm5pbmcgYXBwLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItdGhlLXJlc29sdXRpb24tcnVsZS1ob3ctdGhlLWN1cnJlbnQtYXBwLW9wZW5zLWFuLW9sZC1kb2N1bWVudC1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBUaGUgcmVzb2x1dGlvbiBydWxlIOKAlCBob3cgdGhlIGN1cnJlbnQgYXBwIG9wZW5zIGFuIG9sZCBkb2N1bWVudCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk9uIG9wZW4sIHRoZSBhcHAgY29tcGFyZXMgaXRzIG93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7Zm9ybWF0LCBzdGRsaWIsIGNhdGFsb2csIHRpZXJUYWd9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2ZXJzaW9ucyB0byB0aGVcXG5kb2N1bWVudCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJDYXNlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiUmVzdWx0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQXBwIHNhdGlzZmllcyBldmVyeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJhbmdlIGFuZCBrbm93cyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybWF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYWpvclwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUnVucyBub3JtYWxseS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBcHAncyBzdGRsaWIvY2F0YWxvZyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5ld2VyLCBzYW1lIG1ham9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSdW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhZGRpdGl2ZS1vbmx5IGd1YXJhbnRlZXMgdGhlIGRvY3VtZW50J3MgY2FsbGFibGVzL2NvbXBvbmVudHMgc3RpbGwgZXhpc3QpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRvY3VtZW50IG5lZWRzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXdlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzdGRsaWIvY2F0YWxvZyB0aGFuIHRoZSBhcHAgaGFzIChlLmcuIGFuIG9sZCBhcHAgb3BlbmluZyBhIG5ldyBkb2N1bWVudClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxlZ2libGUgZGVncmFkYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMyk6IHRoZSBzcGVjaWZpYyB1bmtub3duIGNhbGxhYmxlL2NvbXBvbmVudCByZW5kZXJzIGFzIGEgbWFya2VkIHBsYWNlaG9sZGVyIG5hbWluZyB3aGF0IGl0IG5lZWRzOyB0aGUgcmVzdCBydW5zLiBOZXZlciBhIHNpbGVudCB3cm9uZyByZW5kZXIuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQXBwIGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIga25vdyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybWF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYWpvciAoYSBicmVha2luZyBzY2hlbWEgY2hhbmdlIGl0IHByZWRhdGVzKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVmdXNlIHdpdGggYSBsZWdpYmxlIG1lc3NhZ2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFxcXCJ0aGlzIHJlcG9ydCBuZWVkcyBhIG5ld2VyIFJlY2tvbmVyXFxcIiksIG5ldmVyIGEgcGFydGlhbCBwYXJzZS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFkZGl0aXZlLW9ubHkgY29udHJhY3QgZG9lcyB0aGUgaGVhdnkgbGlmdGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqczLjIgZGVjaXNpb24pOiB3aXRoaW4gYSBtYWpvciwgZm9yd2FyZFxcbmNvbXBhdGliaWxpdHkgaXMgZnJlZSBiZWNhdXNlIG5vdGhpbmcgaXMgZXZlciByZW1vdmVkIG9yIGNoYW5nZWQg4oCUIG9ubHkgYWRkZWQuIFRoZSBlbnZlbG9wZSdzXFxuam9iIGlzIHRvIG1ha2UgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJjcm9zcy1tYWpvclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuZW0+e1wib2xkLWFwcC1uZXctZG9jdW1lbnRcIn08L19jb21wb25lbnRzLmVtPntcIiBjYXNlcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxlZ2libGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCB0byBwcmV2ZW50XFxudGhlbS4gQSBtYWpvciBidW1wIGlzIHRoZSBlc2NhcGUgaGF0Y2ggZm9yIHRoZSBvbmUgdGhpbmcgYWRkaXRpdmUtb25seSBjYW5ub3QgYWJzb3JiIChhIGdlbnVpbmVcXG5icmVha2luZyBjaGFuZ2UpOyBpdCBpcyBleHBlY3RlZCB0byBiZSByYXJlIGFuZCB0byBzaGlwIHdpdGggYSBjb2RlbW9kIChpbXBsZW1lbnRhdGlvbi10aW1lKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTNcIiBkYXRhLXNsdWc9XCIzLWxlZ2libGUtZGVncmFkYXRpb24tbm90LXNpbGVudC13cm9uZy1kYXRhLW5vcm1hdGl2ZS1yZXVzZXMtMzNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBMZWdpYmxlIGRlZ3JhZGF0aW9uLCBub3Qgc2lsZW50IHdyb25nIGRhdGEgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCByZXVzZXMgwqczLjMpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBkZWdyYWRhdGlvbiBzdXJmYWNlIGlzIHRoZSBvbmUgdGhlIGNhdGFsb2cgYWxyZWFkeSBkZWZpbmVzICjCpzMuMyk6IGFuIHVua25vd24gY29tcG9uZW50XFxucmVuZGVycyBhcyBhIHNhZmUgcGxhY2Vob2xkZXIgbmFtaW5nIHdoYXQgaXQgbmVlZHMsIGFuZCB0aGlzIHNwZWMgZXh0ZW5kcyB0aGUgc2FtZSB0cmVhdG1lbnQgdG9cXG5hbiB1bmtub3duLXN0ZGxpYiBmb3JtdWxhICh0aGUgY2VsbCByZW5kZXJzIGFzIGEgbWFya2VkIFxcXCJuZWVkcyBzdGRsaWIg4omlIHhcXFwiIHRpbGUsIG5vdCBhIGJyb2tlblxcbnZhbHVlIG9yIGEgc2lsZW50IHplcm8pIGFuZCBhbiB1bmtub3duIHRpZXItdGFnIGVuY29kaW5nICh0aGUgdmFsdWUgaXMgdHJlYXRlZCBhcyBpdHNcXG5ob3N0LWF1dGhvcml0YXRpdmUgbW91bnQgdGllciDigJQgwqc1LjQvTDEg4oCUIGFuZCB0aGUgdW5yZWFkYWJsZSBpbi1maWxlIHRhZyBpcyBpZ25vcmVkLCBuZXZlclxcbnRydXN0ZWQpLiBUaGUgaW52YXJpYW50OiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImEgdmVyc2lvbiBtaXNtYXRjaCBkZWdyYWRlcyB2aXNpYmx5IGFuZCBzcGVjaWZpY2FsbHk7IGl0IG5ldmVyXFxucHJvZHVjZXMgYSBwbGF1c2libGUtYnV0LXdyb25nIG51bWJlci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhpcyBjb21wb3NlcyB3aXRoIHRoZSB0ZXN0aW5nIHN0b3J5J3Mgc3RhbmRpbmcgcnVsZVxcbihhIGdyZWVuIHN1aXRlIG92ZXIgYSBtaXNtYXRjaGVkIHJ1bnRpbWUgaXMgbm90IGEgY29ycmVjdG5lc3MgY2xhaW0pLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNFwiIGRhdGEtc2x1Zz1cIjQtcmVwcm9kdWNpYmlsaXR5LWZhbGxzLW91dC1vZi10aGUtZW52ZWxvcGUtbm9ybWF0aXZlLWludGVudC1jbG9zZXMtYS0xMi1wYXJrZWQtcXVlc3Rpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0LiBSZXByb2R1Y2liaWxpdHkgZmFsbHMgb3V0IG9mIHRoZSBlbnZlbG9wZSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUgaW50ZW50IOKAlCBjbG9zZXMgYSDCpzEyIHBhcmtlZCBxdWVzdGlvbilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiXFxcIldoaWNoIG51bWJlcnMgZGlkIHdlIHJlcG9ydCBsYXN0IHF1YXJ0ZXI/XFxcIiBpcyBhbnN3ZXJhYmxlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaWZmXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBkb2N1bWVudCByZWNvcmRzIHRoZVxcbnZlcnNpb25zIHRoYXQgcHJvZHVjZWQgdGhlbS4gVGhlIGVudmVsb3BlIHByb3ZpZGVzIHR3byBvZiB0aGUgdGhyZWUgbmVlZGVkIHBpZWNlcywgYW5kIFNwaW5lIDFcXG5wcm92aWRlcyB0aGUgdGhpcmQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JlZFdpdGhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzEpIHJlY29yZHMgdGhlIGV4YWN0IGFwcC9zdGRsaWIvY2F0YWxvZyB2ZXJzaW9ucyDigJQgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJjb2RlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhhdFxcbmNvbXB1dGVkIHRoZSBudW1iZXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmcm96ZW4gZnJhbWUgLyBzbmFwc2hvdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1LjQsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVOR0lORV9JTkZPUk1BVElPTl9GTE9XIMKnNFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgQzUpIHJlY29yZHMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJkYXRhXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW5kXFxuaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2FwdHVyZSBlcG9jaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGlucHV0cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJSZS1ydW5uaW5nICgxKSBvdmVyICgyKSByZXByb2R1Y2VzIHRoZSBudW1iZXJzLCBiZWNhdXNlIGZvcm11bGFzIGFyZSBwdXJlICjCpzMuMSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNvIFxcXCJyZXBvcnQgcmVwcm9kdWNpYmlsaXR5XFxcIiBpcyBub3QgYSBzZXBhcmF0ZSBmZWF0dXJlOiBpdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcmVkV2l0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBhIGZyZWV6ZSBhdFxcbnJlcG9ydCB0aW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGUgc3BlYydzIG9ubHkgYXNrIG9mIHRoZSBNMSBmcmVlemUgaXMgdGhhdCBib3RoIGFyZSByZWNvcmRlZDsgdGhlIGFjdHVhbFxcblxcXCJvcGVuIGxhc3QgcXVhcnRlcidzIHZlcnNpb25cXFwiIFVYIGlzIGltcGxlbWVudGF0aW9uLXRpbWUuIEhvbmVzdHkgbm90ZTogcmVwcm9kdWNpYmlsaXR5IGhvbGRzXFxub25seSBmb3IgYSBkb2N1bWVudCB0aGF0IHdhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZyb3plblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdCByZXBvcnQgdGltZSDigJQgYSBsaXZlIHJlcG9ydCByZS1ydW4gdG9kYXkgc2hvd3NcXG50b2RheSdzIGRhdGEgYnkgZGVzaWduLCB3aGljaCBpcyBjb3JyZWN0LCBub3QgYSBidWcuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy01XCIgZGF0YS1zbHVnPVwiNS10aGUtY29uY3VycmVuY3ktY29uc3RyYWludC1kZWNpZGUtbm93LWRlc2lnbi1sYXRlci1ub3JtYXRpdmUtYS1jb25zdHJhaW50LW5vdC1hLXYxLWRlc2lnblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTVcIiAvPntcIjUuIFRoZSBjb25jdXJyZW5jeSBjb25zdHJhaW50IOKAlCBkZWNpZGUgbm93LCBkZXNpZ24gbGF0ZXIgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBhIGNvbnN0cmFpbnQsIG5vdCBhIHYxIGRlc2lnbilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQ29uY3VycmVudCBtdWx0aS1hdXRob3IgZWRpdGluZyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhIHYxIGZlYXR1cmUuIEJ1dCB0aGUgZm9ybWF0IG11c3Qgbm90IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHJlY2x1ZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5pdCwgYmVjYXVzZSByZXRyb2ZpdHRpbmcgY29uY3VycmVuY3kgaW50byBhIHBvc2l0aW9uYWwvd2hvbGUtZmlsZSBmb3JtYXQgaXMgYSByZXdyaXRlLiBUaGVcXG5jb25zdHJhaW50IHRoZSBNMSBmcmVlemUgbXVzdCBob25vcjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNlbGxzIGFyZSBpbmRlcGVuZGVudCwgbmFtZWQgdW5pdHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy4xIOKAlCBuYW1lcyBub3QgY29vcmRpbmF0ZXMpLCBhbmQgYSB3b3Jrc2hlZXQgaXMgYVxcbnNldCBvZiBuYW1lZCBleHBvcnRzLCBub3QgYW4gb3JkZXJlZCBncmlkLiBTbyBhbiBlZGl0IGlzIHNjb3BlZCB0byBhIG5hbWVkIGNlbGwsIGFuZCBhIGZ1dHVyZVxcbm1lcmdlIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGVyLWNlbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHR3byBhdXRob3JzIGVkaXRpbmcgZGlmZmVyZW50IGNlbGxzIG5ldmVyIGNvbmZsaWN0OyB0d28gZWRpdGluZyB0aGVcXG5zYW1lIGNlbGwgaXMgYW4gb3JkaW5hcnkgdGV4dC9DUkRUIG1lcmdlIG9uIHRoYXQgY2VsbCdzIHNvdXJjZSkuIFRoZSBuYW1lZC1jZWxsIG1vZGVsIOKAlCBjaG9zZW5cXG5mb3IgcmV2aWV3IGFuZCBhZ2VudC1lcmdvbm9taWNzIOKAlCBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWxyZWFkeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHNhdGlzZmllcyB0aGlzOyB0aGUgY29uc3RyYWludCBpcyBzaW1wbHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkb24ndFxcbnJlZ3Jlc3MgaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vIHBvc2l0aW9uYWwgY2VsbCBpZGVudGl0eSwgbm8gd2hvbGUtZmlsZS1hcy10aGUtdW5pdCBmb3JtYXQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGF0IG9uZSBzZW50ZW5jZSBpcyB0aGUgZW50aXJlIHVwLWZyb250IGNvbmN1cnJlbmN5IGNvc3QuIFRoZSBDUkRUL21lcmdlIGRlc2lnbiBpdHNlbGYgaXNcXG5kZWZlcnJlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LWxvYWQtYmVhcmluZy1hc3N1bXB0aW9ucy1jb2RlLWFuY2hvcnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2LiBMb2FkLWJlYXJpbmcgYXNzdW1wdGlvbnMgJiBjb2RlIGFuY2hvcnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRlcGVuZHMtb24tdG9kYXktdmVyaWZpZWQtMjAyNi0wNy0wOVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC0yMDI2LTA3LTA5XCIgLz57XCJEZXBlbmRzLW9uLXRvZGF5ICh2ZXJpZmllZCAyMDI2LTA3LTA5KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb24gKGV4aXN0aW5nIGJlaGF2aW9yIHRoZSBkZXNpZ24gcmVzdHMgb24pXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQW5jaG9yIChyZXBvLXJlbGF0aXZlIGZpbGUpXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVG9rZW4gKGdyZXAtc3RhYmxlKVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBwbGF0Zm9ybSBhbHJlYWR5IGhhcyBhbiBhcHAtbGV2ZWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmcmVzaG5lc3MtZW51bSBwcmVjZWRlbnQgKGEgZG9jdW1lbnQtY29tcGF0IGFuYWxvZ3VlKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIm5ldy1wcm9qZWN0LXRlbXBsYXRlL1JFQURNRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJyZXF1aXJlTGF0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1jcmVhdGVzXCIgLz57XCJNdXN0LWVzdGFibGlzaCAobmV3IGludmFyaWFudHMgdGhlIGltcGxlbWVudGF0aW9uIGNyZWF0ZXMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiTmV3IGludmFyaWFudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlByb3ZlbiBieSAoZ2F0ZSB0ZXN0KVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkV2ZXJ5IGRvY3VtZW50IGNhcnJpZXMgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JtYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1ham9yICsgZGVyaXZlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJhbmdlcyArIHN0YW1wZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yZWRXaXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImVudmVsb3BlIHRlc3Q6IGEgc2F2ZWQgZG9jdW1lbnQgaGFzIGEgdmFsaWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBibG9jayB0aGUgaG9zdCBkZXJpdmVkIGZyb20gaXRzIGltcG9ydHMvdXNlc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkFuIG9sZCBhcHAgb3BlbmluZyBhIG5ld2VyLXN0ZGxpYiBkb2N1bWVudCBkZWdyYWRlcyBsZWdpYmx5IHBlciBjZWxsLCBuZXZlciBzaWxlbnRseVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImZvcndhcmQtY29tcGF0IGdhdGU6IGEgZG9jdW1lbnQgdXNpbmcgYSBjYWxsYWJsZSB0aGUgYXBwIGxhY2tzIHJlbmRlcnMgYSBcXFwibmVlZHMgc3RkbGliIOKJpSB4XFxcIiB0aWxlLCBub3QgYSB3cm9uZyB2YWx1ZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkFuIHVua25vd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybWF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYWpvciBpcyByZWZ1c2VkLCBub3QgcGFydGlhbGx5IHBhcnNlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImZvcm1hdC1yZWZ1c2FsIGdhdGU6IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybWF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGUgYXBwIHByZWRhdGVzIHlpZWxkcyBhIGxlZ2libGUgcmVmdXNhbFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgZnJvemVuIHJlcG9ydCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcmVkV2l0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwcm9kdWNlcyBpdHMgbnVtYmVycyBvbiByZS1ydW5cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJyZXByb2R1Y2liaWxpdHkgZ2F0ZTogcmUtcnVubmluZyB0aGUgcmVjb3JkZWQgdmVyc2lvbnMgb3ZlciB0aGUgZnJvemVuIGZyYW1lIHJlcHJvZHVjZXMgdGhlIHJlcG9ydGVkIHZhbHVlc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkNlbGwgaWRlbnRpdHkgaXMgbmFtZS1iYXNlZCwgbm90IHBvc2l0aW9uYWwgKGNvbmN1cnJlbmN5IG5vdCBwcmVjbHVkZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZm9ybWF0LWNvbnN0cmFpbnQgY2hlY2s6IG5vIHBvc2l0aW9uYWwgY2VsbCBpZGVudGl0eSBhbnl3aGVyZSBpbiB0aGUgc2NoZW1hXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtN1wiIGRhdGEtc2x1Zz1cIjctZGVjaXNpb25zLXJlamVjdGVkLWFsdGVybmF0aXZlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTdcIiAvPntcIjcuIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgdmVyc2lvbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiZW52ZWxvcGVcIn08L19jb21wb25lbnRzLmVtPntcIiAocmFuZ2VzICsgcHJvdmVuYW5jZSkgaW4gdjE7IG1pZ3JhdGlvbnMgZGVmZXJyZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIlxcbnNoaXBwaW5nIHRoZSBmb3JtYXQgd2l0aCBubyB2ZXJzaW9uIGZpZWxkIChyZXRyb2ZpdHRpbmcgaXMgYSBwZXItZG9jdW1lbnQgbWlncmF0aW9uKTsgYnVpbGRpbmdcXG50aGUgZnVsbCBtaWdyYXRpb24vY29kZW1vZCBtYWNoaW5lcnkgdXAtZnJvbnQgKGltcGxlbWVudGF0aW9uLXRpbWU7IHRoZSBlbnZlbG9wZSBtYWtlcyBpdFxcbnRyYWN0YWJsZSB3aXRob3V0IHByZS1idWlsZGluZyBpdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIb3N0LWRlcml2ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsb3dlciBib3VuZHMsIG5vdCBhdXRob3ItbWFpbnRhaW5lZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFza2luZyBhdXRob3JzIHRvXFxuaGFuZC1tYWludGFpbiB2ZXJzaW9uIHJhbmdlcyAocm90czsgdGhlIGhvc3QgYWxyZWFkeSBkb2VzIHRoZSBzdGF0aWMgYW5hbHlzaXMgZm9yIHRoZVxcbmRlcGVuZGVuY3kgZ3JhcGgpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWRkaXRpdmUtb25seSBzdGRsaWIvY2F0YWxvZyBkb2VzIGZvcndhcmQtY29tcGF0OyB0aGUgZW52ZWxvcGUgb25seSBtYWtlcyBjcm9zcy1tYWpvciBhbmRcXG5vbGQtYXBwIGNhc2VzIGxlZ2libGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBwZXItdmVyc2lvbiBjb21wYXRpYmlsaXR5IHNoaW1zIGFzIHRoZSBwcmltYXJ5IG1lY2hhbmlzbVxcbihhZGRpdGl2ZS1vbmx5IG1ha2VzIHRoZW0gdW5uZWNlc3Nhcnkgd2l0aGluIGEgbWFqb3IpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVwcm9kdWNpYmlsaXR5ID0gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yZWRXaXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIGZyZWV6ZSwgbm90IGEgc2VwYXJhdGUgZmVhdHVyZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgYmVzcG9rZVxcbnZlcnNpb24taGlzdG9yeS90aW1lLXRyYXZlbCBzdG9yZSAob3Zlci1idWlsdCBmb3IgdjE7IHRoZSBmcmVlemUgKyBwcm92ZW5hbmNlIGFscmVhZHkgc3VmZmljZVxcbmZvciBcXFwid2hhdCBkaWQgd2UgcmVwb3J0XFxcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb25zdHJhaW4gdGhlIGZvcm1hdCB0byBuYW1lLWJhc2VkIGNlbGwgaWRlbnRpdHkgc28gY29uY3VycmVuY3kgaXMgbm90IHByZWNsdWRlZDsgZGVmZXIgdGhlXFxubWVyZ2UgZGVzaWduLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVzaWduaW5nIG11bHRpLWF1dGhvciBtZXJnZSBpbiB2MSAobm90IG5lZWRlZCk7IGFcXG5wb3NpdGlvbmFsL3dob2xlLWZpbGUgZm9ybWF0ICh3b3VsZCBwcmVjbHVkZSBhIHBlci1jZWxsIG1lcmdlIOKAlCBhIHJld3JpdGUgdG8gYWRkIGxhdGVyKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLThcIiBkYXRhLXNsdWc9XCI4LW9wZW4tcXVlc3Rpb25zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOFwiIC8+e1wiOC4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0xIChjYXRhbG9nIGZvcmtzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQSBmb3JrIHNoaXBzIG5ldyBjb21wb25lbnRzICjCpzMuMykuIEEgZG9jdW1lbnQgYXV0aG9yZWQgYWdhaW5zdCBhXFxuZm9yaydzIGNhdGFsb2cgb3BlbmVkIGluIHN0b2NrIFJlY2tvbmVyIGhpdHMgdGhlIHVua25vd24tY29tcG9uZW50IHBhdGggKGZpbmUpIOKAlCBidXQgc2hvdWxkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0LmNhdGFsb2dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJlIGFibGUgdG8gbmFtZSBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9yayBpZGVudGl0eVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgb3IgaXMgXFxcInVua25vd24gY29tcG9uZW50IOKGkiBwbGFjZWhvbGRlclxcXCJcXG5zdWZmaWNpZW50PyBMaWtlbHkgc3VmZmljaWVudDsgY29uZmlybSBhZ2FpbnN0IHRoZSBmb3JrIHN0b3J5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMiAodGllci10YWcgZW5jb2RpbmcgZXZvbHV0aW9uKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgwqczIHRyZWF0cyBhbiB1bmtub3duIHRpZXItdGFnIGFzIFxcXCJmYWxsIGJhY2sgdG9cXG5ob3N0IG1vdW50IHRpZXIuXFxcIiBDb25maXJtIHRoYXQgYSBcIn08X2NvbXBvbmVudHMuZW0+e1wibmV3ZXJcIn08L19jb21wb25lbnRzLmVtPntcIiB0aWVyIGVuY29kaW5nIChmaW5lciBncmFudWxhcml0eSwgcGVyLWNvbHVtbiB0aWVycyBpZlxcbkUtMiBmb3JjZXMgdGhlbSkgZGVncmFkZXMgc2FmZWx5IHRvIHRoZSBjb2Fyc2VyIGhvc3QgdGllciBhbmQgbmV2ZXIgXCJ9PF9jb21wb25lbnRzLmVtPntcInVwXCJ9PC9fY29tcG9uZW50cy5lbT57XCItbGFiZWxzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMyAoc3RkbGliIGRlcHJlY2F0aW9uIHdpdGhpbiBhZGRpdGl2ZS1vbmx5KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQWRkaXRpdmUtb25seSBmb3JiaWRzIHJlbW92YWwg4oCUIGJ1dCBhXFxuY2FsbGFibGUgY2FuIGJlIFwifTxfY29tcG9uZW50cy5lbT57XCJkaXNjb3VyYWdlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBEb2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbmVlZCBhIFxcXCJzb2Z0LWRlcHJlY2F0ZWQgc2luY2UgeFxcXCIgc2lnbmFsIGZvciB0aGVcXG5yZXZpZXcgc3VyZmFjZSwgb3IgaXMgdGhhdCBvdXQgb2Ygc2NvcGUgZm9yIHRoZSBlbnZlbG9wZT8gUHJvYmFibHkgb3V0IG9mIHNjb3BlOyBub3RlIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9zcGVjcy9ET0NVTUVOVF9WRVJTSU9OSU5HX1NQRUMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3JCLEtBQUssQ0FBQ3NCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHdEIsV0FBVztFQUNoQyxJQUFJLENBQUNzQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQTFCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQTNCLFdBQUEsQ0FBQTRCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO01BQUN1QixFQUFFLEVBQUMsNEZBQTRGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEYsQ0FBRSxDQUFDLEVBQUMsaUdBQWlHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBMkMsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQywyRUFBMkU7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLG9PQUFvTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBNEMsQ0FBbUIsQ0FBQyxFQUFDLG9HQUFvRztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxpRUFBaUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLHdKQUF3SixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNDLENBQXFCLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxlQUFlO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLHdHQUF3RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLG1JQUFtSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUE4QixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsOENBQThDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QixDQUFxQixDQUFDLEVBQUMsZ0tBQWdLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQTZCLENBQWlCLENBQUMsRUFBQyxrSUFBa0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxtQ0FBbUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxtQ0FBbUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QyxDQUFxQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMsbUlBQW1JO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUVBQXlFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBcUMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvRCxDQUFxQixDQUFDLEVBQUMsY0FBYztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1csR0FBRztNQUFBZSxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDMkIsU0FBUyxFQUFDLGdCQUFnQjtRQUFBSCxRQUFBLEVBQUU7TUFBbW1CLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVEsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsd0pBQXdKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFVLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLDRFQUE0RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLGdMQUFnTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBYyxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyw4RUFBOEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsb09BQW9PLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDJFQUEyRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFvQyxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQW1CLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQixDQUFDLEVBQUMsOEVBQThFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsMkVBQTJFO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXFCLENBQXFCLENBQUMsRUFBQyxrSkFBa0o7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSyxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQywrQ0FBK0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBK0IsQ0FBcUIsQ0FBQyxFQUFDLG1FQUFtRTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUErQyxDQUFxQixDQUFDLEVBQUMsK0pBQStKLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBc0IsQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxrTkFBa047SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxpRUFBaUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUEyQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsNmVBQTZlLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0csQ0FBcUIsQ0FBQyxFQUFDLDhIQUE4SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDBGQUEwRjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQW1ELENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSw4REFBOEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxnSkFBZ0o7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNTLEVBQUU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBYyxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxFQUFFO01BQW1GLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsaUVBQWlFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7TUFBQSxDQUFxQixDQUFDLEVBQUMsNk1BQTZNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsMEdBQTBHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNkZBQTZGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBNkMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHFDQUFxQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLG9JQUFvSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9DLENBQXFCLENBQUMsRUFBQyxpS0FBaUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQywyTUFBMk0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLG1FQUFtRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBdUcsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0Q0FBNEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxzQ0FBc0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQyxDQUFFLENBQUMsRUFBQyx3Q0FBd0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBb0QsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHdDQUF3QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyx3REFBd0Q7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZSxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQywwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwRCxDQUFFLENBQUMsRUFBQyw0REFBNEQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBdUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsMkJBQTJCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNGLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXVILENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyxtQ0FBbUM7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLEVBQUMsb0RBQW9EO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsa09BQWtPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsdUNBQXVDO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsK0hBQStIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1ILENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1IQUFtSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsb0NBQW9DO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMseUlBQXlJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRHLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLCtJQUErSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0JBQWtCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsbUtBQW1LLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyw2R0FBNkc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyw4SEFBOEgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBSSxDQUFpQixDQUFDLEVBQUMsVUFBVTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsK0lBQStJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ244c0I7QUFDZSxTQUFTSSxVQUFVQSxDQUFDL0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2dDLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdyQixLQUFLLENBQUNzQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFuQyxXQUFBLENBQUErQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLakMsS0FBSztJQUFBMkIsUUFBQSxlQUFFLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM5QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDa0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxvREFBb0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM5UTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}