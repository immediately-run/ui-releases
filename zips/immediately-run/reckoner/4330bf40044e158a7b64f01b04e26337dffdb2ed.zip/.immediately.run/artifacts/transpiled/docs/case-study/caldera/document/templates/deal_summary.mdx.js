var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      h1: "h1",
      h2: "h2",
      p: "p",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      Chart,
      HeadingAnchor,
      Kpi,
      Params,
      Range,
      Row,
      Table,
      Value
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "37:1-42:11");
  if (!Chart) _missingMdxReference("Chart", true, "25:1-25:71");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  if (!Kpi) _missingMdxReference("Kpi", true, "18:3-18:54");
  if (!Params) _missingMdxReference("Params", true, "10:1-15:10");
  if (!Range) _missingMdxReference("Range", true, "11:3-11:74");
  if (!Row) _missingMdxReference("Row", true, "17:1-21:7");
  if (!Table) _missingMdxReference("Table", true, "28:1-28:416");
  if (!Value) _missingMdxReference("Value", true, "4:1-4:41");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "caldera-components-lbo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "caldera-components-lbo"
      }), "Caldera Components — LBO."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The Harrow Capital take-private of Caldera Components (fictional): entry at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Value, {
        source: "params.entry_multiple"
      }), "x LTM EBITDA, exit at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Value, {
        source: "params.exit_multiple"
      }), "x, funded with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Value, {
        source: "params.tlb_turns"
      }), "x Term Loan B plus a 1.0x mezzanine tranche.\nDebt schedule charges interest on beginning balances; the converged\naverage-balance variant lives in the workbook cells."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(Params, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Range, {
        name: "entry_multiple",
        min: 6,
        max: 10,
        step: 0.5,
        default: 8
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Range, {
        name: "exit_multiple",
        min: 6,
        max: 10,
        step: 0.5,
        default: 8
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Range, {
        name: "tlb_turns",
        min: 3.5,
        max: 6.5,
        step: 0.5,
        default: 5
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Range, {
        name: "tax_rate",
        min: 0.15,
        max: 0.35,
        step: 0.01,
        default: 0.25
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(Row, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Kpi, {
        source: "model.sponsor_irr",
        format: "percent"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Kpi, {
        source: "model.moic",
        format: "multiple"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Kpi, {
        source: "model.sponsor_equity",
        format: "currency",
        unit: "m"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-deleveraging-story",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-deleveraging-story"
      }), "The deleveraging story."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Chart, {
      source: "model.debt_schedule",
      kind: "bar",
      x: "year",
      y: "tlb_end"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Chart, {
      source: "model.operating",
      kind: "line",
      x: "year",
      y: "ebitda"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Table, {
      source: "model.debt_schedule",
      columns: ["year", "ebitda", "interest", "cfadr", "mand", "sweep", {
        field: "tlb_end",
        format: "currency",
        unit: "m"
      }, {
        field: "mezz_end",
        format: "currency",
        unit: "m"
      }, {
        field: "cash_end",
        format: "currency",
        unit: "m"
      }, {
        field: "net_debt",
        format: "currency",
        unit: "m"
      }, {
        field: "leverage",
        format: "multiple"
      }, {
        field: "coverage",
        format: "multiple"
      }],
      sortable: true
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sensitivity-sponsor-irr-by-exit-multiple-and-leverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sensitivity-sponsor-irr-by-exit-multiple-and-leverage"
      }), "Sensitivity — sponsor IRR by exit multiple and leverage."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Twenty-five full model re-runs over the base fixtures; the live deal knobs above\ndo not bend this grid (it sweeps the model as a function, not the params)."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Table, {
      source: "model.sensitivity",
      columns: ["exit_multiple", "tlb_turns", {
        field: "sponsor_equity",
        format: "currency",
        unit: "m"
      }, {
        field: "exit_equity",
        format: "currency",
        unit: "m"
      }, {
        field: "moic",
        format: "multiple"
      }, {
        field: "irr",
        format: "percent"
      }],
      sortable: true
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Callout, {
      tone: "info",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Breakeven exit multiple for the 20 percent hurdle:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Value, {
          source: "model.breakeven_exit_multiple"
        }), "x — a goal seek recomputed\nby the model, not a pasted number. The converged average-balance interest\nvariant lives in the model.debt_schedule_avg and model.returns_avg cells."]
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/case-study/caldera/document/templates/deal_summary.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJoMSIsImgyIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJDYWxsb3V0IiwiQ2hhcnQiLCJIZWFkaW5nQW5jaG9yIiwiS3BpIiwiUGFyYW1zIiwiUmFuZ2UiLCJSb3ciLCJUYWJsZSIsIlZhbHVlIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4Iiwic291cmNlIiwibmFtZSIsIm1pbiIsIm1heCIsInN0ZXAiLCJkZWZhdWx0IiwiZm9ybWF0IiwidW5pdCIsImtpbmQiLCJ4IiwieSIsImNvbHVtbnMiLCJmaWVsZCIsInNvcnRhYmxlIiwidG9uZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGVhbF9zdW1tYXJ5Lm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgcDogXCJwXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7Q2FsbG91dCwgQ2hhcnQsIEhlYWRpbmdBbmNob3IsIEtwaSwgUGFyYW1zLCBSYW5nZSwgUm93LCBUYWJsZSwgVmFsdWV9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghQ2FsbG91dCkgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJDYWxsb3V0XCIsIHRydWUsIFwiMzc6MS00MjoxMVwiKTtcbiAgaWYgKCFDaGFydCkgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJDaGFydFwiLCB0cnVlLCBcIjI1OjEtMjU6NzFcIik7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICBpZiAoIUtwaSkgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJLcGlcIiwgdHJ1ZSwgXCIxODozLTE4OjU0XCIpO1xuICBpZiAoIVBhcmFtcykgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJQYXJhbXNcIiwgdHJ1ZSwgXCIxMDoxLTE1OjEwXCIpO1xuICBpZiAoIVJhbmdlKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIlJhbmdlXCIsIHRydWUsIFwiMTE6My0xMTo3NFwiKTtcbiAgaWYgKCFSb3cpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiUm93XCIsIHRydWUsIFwiMTc6MS0yMTo3XCIpO1xuICBpZiAoIVRhYmxlKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIlRhYmxlXCIsIHRydWUsIFwiMjg6MS0yODo0MTZcIik7XG4gIGlmICghVmFsdWUpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiVmFsdWVcIiwgdHJ1ZSwgXCI0OjEtNDo0MVwiKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiY2FsZGVyYS1jb21wb25lbnRzLWxib1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2FsZGVyYS1jb21wb25lbnRzLWxib1wiIC8+e1wiQ2FsZGVyYSBDb21wb25lbnRzIOKAlCBMQk8uXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgSGFycm93IENhcGl0YWwgdGFrZS1wcml2YXRlIG9mIENhbGRlcmEgQ29tcG9uZW50cyAoZmljdGlvbmFsKTogZW50cnkgYXRcXG5cIn08VmFsdWUgc291cmNlPVwicGFyYW1zLmVudHJ5X211bHRpcGxlXCIgLz57XCJ4IExUTSBFQklUREEsIGV4aXQgYXRcXG5cIn08VmFsdWUgc291cmNlPVwicGFyYW1zLmV4aXRfbXVsdGlwbGVcIiAvPntcIngsIGZ1bmRlZCB3aXRoXFxuXCJ9PFZhbHVlIHNvdXJjZT1cInBhcmFtcy50bGJfdHVybnNcIiAvPntcInggVGVybSBMb2FuIEIgcGx1cyBhIDEuMHggbWV6emFuaW5lIHRyYW5jaGUuXFxuRGVidCBzY2hlZHVsZSBjaGFyZ2VzIGludGVyZXN0IG9uIGJlZ2lubmluZyBiYWxhbmNlczsgdGhlIGNvbnZlcmdlZFxcbmF2ZXJhZ2UtYmFsYW5jZSB2YXJpYW50IGxpdmVzIGluIHRoZSB3b3JrYm9vayBjZWxscy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PFBhcmFtcz48UmFuZ2UgbmFtZT1cImVudHJ5X211bHRpcGxlXCIgbWluPXs2fSBtYXg9ezEwfSBzdGVwPXswLjV9IGRlZmF1bHQ9ezh9IC8+PFJhbmdlIG5hbWU9XCJleGl0X211bHRpcGxlXCIgbWluPXs2fSBtYXg9ezEwfSBzdGVwPXswLjV9IGRlZmF1bHQ9ezh9IC8+PFJhbmdlIG5hbWU9XCJ0bGJfdHVybnNcIiBtaW49ezMuNX0gbWF4PXs2LjV9IHN0ZXA9ezAuNX0gZGVmYXVsdD17NX0gLz48UmFuZ2UgbmFtZT1cInRheF9yYXRlXCIgbWluPXswLjE1fSBtYXg9ezAuMzV9IHN0ZXA9ezAuMDF9IGRlZmF1bHQ9ezAuMjV9IC8+PC9QYXJhbXM+e1wiXFxuXCJ9PFJvdz48S3BpIHNvdXJjZT1cIm1vZGVsLnNwb25zb3JfaXJyXCIgZm9ybWF0PVwicGVyY2VudFwiIC8+PEtwaSBzb3VyY2U9XCJtb2RlbC5tb2ljXCIgZm9ybWF0PVwibXVsdGlwbGVcIiAvPjxLcGkgc291cmNlPVwibW9kZWwuc3BvbnNvcl9lcXVpdHlcIiBmb3JtYXQ9XCJjdXJyZW5jeVwiIHVuaXQ9XCJtXCIgLz48L1Jvdz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtZGVsZXZlcmFnaW5nLXN0b3J5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtZGVsZXZlcmFnaW5nLXN0b3J5XCIgLz57XCJUaGUgZGVsZXZlcmFnaW5nIHN0b3J5LlwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PENoYXJ0IHNvdXJjZT1cIm1vZGVsLmRlYnRfc2NoZWR1bGVcIiBraW5kPVwiYmFyXCIgeD1cInllYXJcIiB5PVwidGxiX2VuZFwiIC8+e1wiXFxuXCJ9PENoYXJ0IHNvdXJjZT1cIm1vZGVsLm9wZXJhdGluZ1wiIGtpbmQ9XCJsaW5lXCIgeD1cInllYXJcIiB5PVwiZWJpdGRhXCIgLz57XCJcXG5cIn08VGFibGUgc291cmNlPVwibW9kZWwuZGVidF9zY2hlZHVsZVwiIGNvbHVtbnM9e1tcInllYXJcIiwgXCJlYml0ZGFcIiwgXCJpbnRlcmVzdFwiLCBcImNmYWRyXCIsIFwibWFuZFwiLCBcInN3ZWVwXCIsIHtcbiAgICBmaWVsZDogXCJ0bGJfZW5kXCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcIm1lenpfZW5kXCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcImNhc2hfZW5kXCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcIm5ldF9kZWJ0XCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcImxldmVyYWdlXCIsXG4gICAgZm9ybWF0OiBcIm11bHRpcGxlXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcImNvdmVyYWdlXCIsXG4gICAgZm9ybWF0OiBcIm11bHRpcGxlXCJcbiAgfV19IHNvcnRhYmxlIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2Vuc2l0aXZpdHktc3BvbnNvci1pcnItYnktZXhpdC1tdWx0aXBsZS1hbmQtbGV2ZXJhZ2VcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlbnNpdGl2aXR5LXNwb25zb3ItaXJyLWJ5LWV4aXQtbXVsdGlwbGUtYW5kLWxldmVyYWdlXCIgLz57XCJTZW5zaXRpdml0eSDigJQgc3BvbnNvciBJUlIgYnkgZXhpdCBtdWx0aXBsZSBhbmQgbGV2ZXJhZ2UuXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUd2VudHktZml2ZSBmdWxsIG1vZGVsIHJlLXJ1bnMgb3ZlciB0aGUgYmFzZSBmaXh0dXJlczsgdGhlIGxpdmUgZGVhbCBrbm9icyBhYm92ZVxcbmRvIG5vdCBiZW5kIHRoaXMgZ3JpZCAoaXQgc3dlZXBzIHRoZSBtb2RlbCBhcyBhIGZ1bmN0aW9uLCBub3QgdGhlIHBhcmFtcykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxUYWJsZSBzb3VyY2U9XCJtb2RlbC5zZW5zaXRpdml0eVwiIGNvbHVtbnM9e1tcImV4aXRfbXVsdGlwbGVcIiwgXCJ0bGJfdHVybnNcIiwge1xuICAgIGZpZWxkOiBcInNwb25zb3JfZXF1aXR5XCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcImV4aXRfZXF1aXR5XCIsXG4gICAgZm9ybWF0OiBcImN1cnJlbmN5XCIsXG4gICAgdW5pdDogXCJtXCJcbiAgfSwge1xuICAgIGZpZWxkOiBcIm1vaWNcIixcbiAgICBmb3JtYXQ6IFwibXVsdGlwbGVcIlxuICB9LCB7XG4gICAgZmllbGQ6IFwiaXJyXCIsXG4gICAgZm9ybWF0OiBcInBlcmNlbnRcIlxuICB9XX0gc29ydGFibGUgLz57XCJcXG5cIn08Q2FsbG91dCB0b25lPVwiaW5mb1wiPjxfY29tcG9uZW50cy5wPntcIkJyZWFrZXZlbiBleGl0IG11bHRpcGxlIGZvciB0aGUgMjAgcGVyY2VudCBodXJkbGU6XFxuXCJ9PFZhbHVlIHNvdXJjZT1cIm1vZGVsLmJyZWFrZXZlbl9leGl0X211bHRpcGxlXCIgLz57XCJ4IOKAlCBhIGdvYWwgc2VlayByZWNvbXB1dGVkXFxuYnkgdGhlIG1vZGVsLCBub3QgYSBwYXN0ZWQgbnVtYmVyLiBUaGUgY29udmVyZ2VkIGF2ZXJhZ2UtYmFsYW5jZSBpbnRlcmVzdFxcbnZhcmlhbnQgbGl2ZXMgaW4gdGhlIG1vZGVsLmRlYnRfc2NoZWR1bGVfYXZnIGFuZCBtb2RlbC5yZXR1cm5zX2F2ZyBjZWxscy5cIn08L19jb21wb25lbnRzLnA+PC9DYWxsb3V0PjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Nhc2Utc3R1ZHkvY2FsZGVyYS9kb2N1bWVudC90ZW1wbGF0ZXMvZGVhbF9zdW1tYXJ5Lm1keGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR0wsS0FBSyxDQUFDTTtJQUNYLENBQUM7SUFBRTtNQUFDQyxPQUFPO01BQUVDLEtBQUs7TUFBRUMsYUFBYTtNQUFFQyxHQUFHO01BQUVDLE1BQU07TUFBRUMsS0FBSztNQUFFQyxHQUFHO01BQUVDLEtBQUs7TUFBRUM7SUFBSyxDQUFDLEdBQUdkLFdBQVc7RUFDdkYsSUFBSSxDQUFDTSxPQUFPLEVBQUVTLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQ2pFLElBQUksQ0FBQ1IsS0FBSyxFQUFFUSxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUM3RCxJQUFJLENBQUNQLGFBQWEsRUFBRU8sb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxJQUFJLENBQUNOLEdBQUcsRUFBRU0sb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxZQUFZLENBQUM7RUFDekQsSUFBSSxDQUFDTCxNQUFNLEVBQUVLLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQy9ELElBQUksQ0FBQ0osS0FBSyxFQUFFSSxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUM3RCxJQUFJLENBQUNILEdBQUcsRUFBRUcsb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxXQUFXLENBQUM7RUFDeEQsSUFBSSxDQUFDRixLQUFLLEVBQUVFLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBQzlELElBQUksQ0FBQ0QsS0FBSyxFQUFFQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQztFQUMzRCxvQkFBTyxJQUFBbEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFBbkIsV0FBQSxDQUFBb0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNDLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyx3QkFBd0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDWixhQUFhO1FBQUNXLEVBQUUsRUFBQztNQUF3QixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNHLENBQUM7TUFBQWUsUUFBQSxHQUFFLCtFQUErRSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLEtBQUs7UUFBQ08sTUFBTSxFQUFDO01BQXVCLENBQUUsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF4QixXQUFBLENBQUF1QixHQUFBLEVBQUNOLEtBQUs7UUFBQ08sTUFBTSxFQUFDO01BQXNCLENBQUUsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF4QixXQUFBLENBQUF1QixHQUFBLEVBQUNOLEtBQUs7UUFBQ08sTUFBTSxFQUFDO01BQWtCLENBQUUsQ0FBQyxFQUFDLHlLQUF5SztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ04sTUFBTTtNQUFBUSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNULEtBQUs7UUFBQ1csSUFBSSxFQUFDLGdCQUFnQjtRQUFDQyxHQUFHLEVBQUUsQ0FBRTtRQUFDQyxHQUFHLEVBQUUsRUFBRztRQUFDQyxJQUFJLEVBQUUsR0FBSTtRQUFDQyxPQUFPLEVBQUU7TUFBRSxDQUFFLENBQUMsbUJBQUE3QixXQUFBLENBQUF1QixHQUFBLEVBQUNULEtBQUs7UUFBQ1csSUFBSSxFQUFDLGVBQWU7UUFBQ0MsR0FBRyxFQUFFLENBQUU7UUFBQ0MsR0FBRyxFQUFFLEVBQUc7UUFBQ0MsSUFBSSxFQUFFLEdBQUk7UUFBQ0MsT0FBTyxFQUFFO01BQUUsQ0FBRSxDQUFDLG1CQUFBN0IsV0FBQSxDQUFBdUIsR0FBQSxFQUFDVCxLQUFLO1FBQUNXLElBQUksRUFBQyxXQUFXO1FBQUNDLEdBQUcsRUFBRSxHQUFJO1FBQUNDLEdBQUcsRUFBRSxHQUFJO1FBQUNDLElBQUksRUFBRSxHQUFJO1FBQUNDLE9BQU8sRUFBRTtNQUFFLENBQUUsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ1QsS0FBSztRQUFDVyxJQUFJLEVBQUMsVUFBVTtRQUFDQyxHQUFHLEVBQUUsSUFBSztRQUFDQyxHQUFHLEVBQUUsSUFBSztRQUFDQyxJQUFJLEVBQUUsSUFBSztRQUFDQyxPQUFPLEVBQUU7TUFBSyxDQUFFLENBQUM7SUFBQSxDQUFRLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ0osR0FBRztNQUFBTSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNYLEdBQUc7UUFBQ1ksTUFBTSxFQUFDLG1CQUFtQjtRQUFDTSxNQUFNLEVBQUM7TUFBUyxDQUFFLENBQUMsbUJBQUE5QixXQUFBLENBQUF1QixHQUFBLEVBQUNYLEdBQUc7UUFBQ1ksTUFBTSxFQUFDLFlBQVk7UUFBQ00sTUFBTSxFQUFDO01BQVUsQ0FBRSxDQUFDLG1CQUFBOUIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDWCxHQUFHO1FBQUNZLE1BQU0sRUFBQyxzQkFBc0I7UUFBQ00sTUFBTSxFQUFDLFVBQVU7UUFBQ0MsSUFBSSxFQUFDO01BQUcsQ0FBRSxDQUFDO0lBQUEsQ0FBSyxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEvQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNFLEVBQUU7TUFBQ2lCLEVBQUUsRUFBQyx3QkFBd0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDWixhQUFhO1FBQUNXLEVBQUUsRUFBQztNQUF3QixDQUFFLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNiLEtBQUs7TUFBQ2MsTUFBTSxFQUFDLHFCQUFxQjtNQUFDUSxJQUFJLEVBQUMsS0FBSztNQUFDQyxDQUFDLEVBQUMsTUFBTTtNQUFDQyxDQUFDLEVBQUM7SUFBUyxDQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxDLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ2IsS0FBSztNQUFDYyxNQUFNLEVBQUMsaUJBQWlCO01BQUNRLElBQUksRUFBQyxNQUFNO01BQUNDLENBQUMsRUFBQyxNQUFNO01BQUNDLENBQUMsRUFBQztJQUFRLENBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEMsV0FBQSxDQUFBdUIsR0FBQSxFQUFDUCxLQUFLO01BQUNRLE1BQU0sRUFBQyxxQkFBcUI7TUFBQ1csT0FBTyxFQUFFLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUU7UUFDLzdDQyxLQUFLLEVBQUUsU0FBUztRQUNoQk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsVUFBVTtRQUNqQk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsVUFBVTtRQUNqQk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsVUFBVTtRQUNqQk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsVUFBVTtRQUNqQk4sTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUFFO1FBQ0RNLEtBQUssRUFBRSxVQUFVO1FBQ2pCTixNQUFNLEVBQUU7TUFDVixDQUFDLENBQUU7TUFBQ08sUUFBUTtJQUFBLENBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckMsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDRSxFQUFFO01BQUNpQixFQUFFLEVBQUMsdURBQXVEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ1osYUFBYTtRQUFDVyxFQUFFLEVBQUM7TUFBdUQsQ0FBRSxDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxDQUFDO01BQUFlLFFBQUEsRUFBRTtJQUE4SixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNQLEtBQUs7TUFBQ1EsTUFBTSxFQUFDLG1CQUFtQjtNQUFDVyxPQUFPLEVBQUUsQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUFFO1FBQzVnQkMsS0FBSyxFQUFFLGdCQUFnQjtRQUN2Qk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsYUFBYTtRQUNwQk4sTUFBTSxFQUFFLFVBQVU7UUFDbEJDLElBQUksRUFBRTtNQUNSLENBQUMsRUFBRTtRQUNESyxLQUFLLEVBQUUsTUFBTTtRQUNiTixNQUFNLEVBQUU7TUFDVixDQUFDLEVBQUU7UUFDRE0sS0FBSyxFQUFFLEtBQUs7UUFDWk4sTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUFFO01BQUNPLFFBQVE7SUFBQSxDQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJDLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ2QsT0FBTztNQUFDNkIsSUFBSSxFQUFDLE1BQU07TUFBQWpCLFFBQUEsZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDRyxDQUFDO1FBQUFlLFFBQUEsR0FBRSxzREFBc0QsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixLQUFLO1VBQUNPLE1BQU0sRUFBQztRQUErQixDQUFFLENBQUMsRUFBQyxrTEFBa0w7TUFBQSxDQUFnQjtJQUFDLENBQVMsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwWDtBQUNlLFNBQVNlLFVBQVVBLENBQUNyQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDc0MsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFsQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdMLEtBQUssQ0FBQ007RUFDWCxDQUFDO0VBQ0QsT0FBT2lDLFNBQVMsZ0JBQUcsSUFBQXpDLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ2tCLFNBQVM7SUFBQSxHQUFLdkMsS0FBSztJQUFBbUIsUUFBQSxlQUFFLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUN0QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDd0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTckIsb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVxQixTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHckIsRUFBRSxHQUFHLG9FQUFvRSxJQUFJc0IsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcseUVBQXlFLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDblM7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}