var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "status-holdout-redacted-mount-view-d9",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "status-holdout-redacted-mount-view-d9"
      }), "Status — Holdout redacted-mount view (D9)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Overall: BUILT at the platform layer — the deny-by-default fs primitive, the realm\nrule-sets, the host-brokered injection port, the credit classifier and the verdict rule\nall hold and are gated. What remains is the Reckoner-side topology that uses them."
      }), "\n· ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Created:"
      }), " 2026-08-27 (roadmap R3-228)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["This document is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "single implementation-status source"
        }), " for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../specs/HOLDOUT_REDACTED_MOUNT_SPEC.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "specs/HOLDOUT_REDACTED_MOUNT_SPEC.md"
          })
        }), ".\nWhere the spec and this file disagree, this file governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "read-this-before-reading-anything-else-here",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "read-this-before-reading-anything-else-here"
      }), "Read this before reading anything else here"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["D9 closes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "trivial"
      }), " leaks: the direct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readFile"
      }), " (H3) and the metadata probe. It\ndoes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " close the test-oracle channel (§5.1) and it adds little for the low-parameter\nformulas Reckoner actually targets (§5.2). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Holdout is a tripwire, never a\ncertification"
      }), ", and the review surface must never promote a holdout-only cell to\n\"validated\" — which is now a test (G-HRM-8), not a convention."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-gate-ladder",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-gate-ladder"
      }), "The gate ladder"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it establishes"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "State"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Where"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The authoring realm's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " is the enumerated subtrees, never bare root"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "site-main/src/filesystem/holdoutScope.ts"
            }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mintRealmRules"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "throws"
            }), " rather than returning an exposing set"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A held-out fixture is unreadable and un-probeable (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readFile"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "exists"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "stat"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "streamRead"
            }), ", incl. traversal)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["primitive shipped in site-main#364; re-asserted against the minted rule-set in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "holdoutScope.adversarial.test.ts"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Existence and name do not leak via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readdir"
            }), " or metadata, at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " reachable level"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same suite — checked through the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "synthesizedChildren"
            }), ", at every ancestor the rule-set makes reachable"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The engine resolves holdout without an assistant-visible path"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "filesystem/holdoutInjection.ts"
            }), " — a NAME, never a path; path-shaped names are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invalid-params"
            }), " before the table is consulted"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-5"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Credit only for a host-fetched, never-agent-seen split"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "filesystem/holdoutEligibility.ts"
            }), " — capture-then-infer, static sources and indeterminacy all classify ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "no-enforceable-holdout"
            }), " at weight 0"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-6"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The blind second agent's scope is intent-only"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "holdoutScope.ts"
            }), " — granting it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "worksheets/"
            }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixtures/"
            }), " is refused at the mint"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-7"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The fs filter is deny-by-default; an empty rule-set denies all"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["shipped in site-main#364; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "extended"
            }), " here to the routing half (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "applyScope"
            }), " mis-routed a thunk ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "RuleScope"
            }), " to the whole-mount chroot)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-HRM-8"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Holdout does not promote a cell to \"validated\""
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "reckoner/src/engine/testrunner.test.ts"
            }), " — the rule predates D9; the gate pins it so it cannot be quietly re-promoted"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-is-not-built",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-is-not-built"
      }), "What is NOT built"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".holdout/"
          }), " topology itself in a Reckoner document"]
        }), " — the host-performed\npre-agent split, writing the withheld slice, and emitting the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "specification"
        }), " cells that\nreference it. The platform now has every primitive that work needs; none of it exists in\nthe Reckoner engine yet."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Wiring the minted rule-sets into the live realm mounts."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mintRealmRules"
        }), " is the\nsanctioned way to build a realm's rule-set and is fully gated, but the assistant realm\ndoes not yet exist as a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " to mint one for — that is D7/AA-01."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tracking the agent's read path per feed."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "classifyHoldoutSplit"
        }), " consumes an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "agentReadFeeds"
        }), " set; nothing populates it yet. Until something does, every classification\nis ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "unknown-feed"
        }), " ⇒ zero credit, which is the correct fail-closed default and also means\nno holdout currently earns credit."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "residuals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "residuals"
      }), "Residuals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The test-oracle channel (§5.1) is open, by design."
        }), " The agent authors the test cell\nthat runs over the holdout and reads its result; trace-replay hands it the declared\ninputs, and a failure message leaks the exact aggregate. Suppressing results would taint\nthe assistant every authoring iteration and break the loop. The correctness weight\ntherefore lives in the oracle-free legs (metamorphic/property/mutation), which need no\nhidden data."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reconstruction (§5.2) is central, not a corner."
        }), " For affine/aggregate/lookup formulas\nthe training split ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "determines"
        }), " the holdout by ordinary fitting."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Blind second-agent authoring is a weak signal (§7 / D9-3)"
        }), " — agent-1 authors the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "doc"
        }), "\nagent-2 reads, so a complete intent over-determines the implementation."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/HOLDOUT_REDACTED_MOUNT_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TVEFUVVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwic3RhdHVzLWhvbGRvdXQtcmVkYWN0ZWQtbW91bnQtdmlldy1kOVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RhdHVzLWhvbGRvdXQtcmVkYWN0ZWQtbW91bnQtdmlldy1kOVwiIC8+e1wiU3RhdHVzIOKAlCBIb2xkb3V0IHJlZGFjdGVkLW1vdW50IHZpZXcgKEQ5KVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPdmVyYWxsOiBCVUlMVCBhdCB0aGUgcGxhdGZvcm0gbGF5ZXIg4oCUIHRoZSBkZW55LWJ5LWRlZmF1bHQgZnMgcHJpbWl0aXZlLCB0aGUgcmVhbG1cXG5ydWxlLXNldHMsIHRoZSBob3N0LWJyb2tlcmVkIGluamVjdGlvbiBwb3J0LCB0aGUgY3JlZGl0IGNsYXNzaWZpZXIgYW5kIHRoZSB2ZXJkaWN0IHJ1bGVcXG5hbGwgaG9sZCBhbmQgYXJlIGdhdGVkLiBXaGF0IHJlbWFpbnMgaXMgdGhlIFJlY2tvbmVyLXNpZGUgdG9wb2xvZ3kgdGhhdCB1c2VzIHRoZW0uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDcmVhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA4LTI3IChyb2FkbWFwIFIzLTIyOClcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBkb2N1bWVudCBpcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3JcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vc3BlY3MvSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TUEVDLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY3MvSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIuXFxuV2hlcmUgdGhlIHNwZWMgYW5kIHRoaXMgZmlsZSBkaXNhZ3JlZSwgdGhpcyBmaWxlIGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWFkLXRoaXMtYmVmb3JlLXJlYWRpbmctYW55dGhpbmctZWxzZS1oZXJlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWFkLXRoaXMtYmVmb3JlLXJlYWRpbmctYW55dGhpbmctZWxzZS1oZXJlXCIgLz57XCJSZWFkIHRoaXMgYmVmb3JlIHJlYWRpbmcgYW55dGhpbmcgZWxzZSBoZXJlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEOSBjbG9zZXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widHJpdmlhbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBsZWFrczogdGhlIGRpcmVjdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKEgzKSBhbmQgdGhlIG1ldGFkYXRhIHByb2JlLiBJdFxcbmRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2xvc2UgdGhlIHRlc3Qtb3JhY2xlIGNoYW5uZWwgKMKnNS4xKSBhbmQgaXQgYWRkcyBsaXR0bGUgZm9yIHRoZSBsb3ctcGFyYW1ldGVyXFxuZm9ybXVsYXMgUmVja29uZXIgYWN0dWFsbHkgdGFyZ2V0cyAowqc1LjIpLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvbGRvdXQgaXMgYSB0cmlwd2lyZSwgbmV2ZXIgYVxcbmNlcnRpZmljYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCB0aGUgcmV2aWV3IHN1cmZhY2UgbXVzdCBuZXZlciBwcm9tb3RlIGEgaG9sZG91dC1vbmx5IGNlbGwgdG9cXG5cXFwidmFsaWRhdGVkXFxcIiDigJQgd2hpY2ggaXMgbm93IGEgdGVzdCAoRy1IUk0tOCksIG5vdCBhIGNvbnZlbnRpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1nYXRlLWxhZGRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWdhdGUtbGFkZGVyXCIgLz57XCJUaGUgZ2F0ZSBsYWRkZXJcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJHYXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiV2hhdCBpdCBlc3RhYmxpc2hlc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlN0YXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiV2hlcmVcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctSFJNLTFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgYXV0aG9yaW5nIHJlYWxtJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIGVudW1lcmF0ZWQgc3VidHJlZXMsIG5ldmVyIGJhcmUgcm9vdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNpdGUtbWFpbi9zcmMvZmlsZXN5c3RlbS9ob2xkb3V0U2NvcGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW50UmVhbG1SdWxlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aHJvd3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmF0aGVyIHRoYW4gcmV0dXJuaW5nIGFuIGV4cG9zaW5nIHNldFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1IUk0tMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgaGVsZC1vdXQgZml4dHVyZSBpcyB1bnJlYWRhYmxlIGFuZCB1bi1wcm9iZWFibGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJleGlzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInN0YXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInN0cmVhbVJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBpbmNsLiB0cmF2ZXJzYWwpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wicHJpbWl0aXZlIHNoaXBwZWQgaW4gc2l0ZS1tYWluIzM2NDsgcmUtYXNzZXJ0ZWQgYWdhaW5zdCB0aGUgbWludGVkIHJ1bGUtc2V0IGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImhvbGRvdXRTY29wZS5hZHZlcnNhcmlhbC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1IUk0tM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkV4aXN0ZW5jZSBhbmQgbmFtZSBkbyBub3QgbGVhayB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZGRpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgbWV0YWRhdGEsIGF0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXZlcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVhY2hhYmxlIGxldmVsXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2FtZSBzdWl0ZSDigJQgY2hlY2tlZCB0aHJvdWdoIHRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN5bnRoZXNpemVkQ2hpbGRyZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhdCBldmVyeSBhbmNlc3RvciB0aGUgcnVsZS1zZXQgbWFrZXMgcmVhY2hhYmxlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUhSTS00XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGVuZ2luZSByZXNvbHZlcyBob2xkb3V0IHdpdGhvdXQgYW4gYXNzaXN0YW50LXZpc2libGUgcGF0aFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImZpbGVzeXN0ZW0vaG9sZG91dEluamVjdGlvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgTkFNRSwgbmV2ZXIgYSBwYXRoOyBwYXRoLXNoYXBlZCBuYW1lcyBhcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52YWxpZC1wYXJhbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJlZm9yZSB0aGUgdGFibGUgaXMgY29uc3VsdGVkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUhSTS01XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ3JlZGl0IG9ubHkgZm9yIGEgaG9zdC1mZXRjaGVkLCBuZXZlci1hZ2VudC1zZWVuIHNwbGl0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZmlsZXN5c3RlbS9ob2xkb3V0RWxpZ2liaWxpdHkudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBjYXB0dXJlLXRoZW4taW5mZXIsIHN0YXRpYyBzb3VyY2VzIGFuZCBpbmRldGVybWluYWN5IGFsbCBjbGFzc2lmeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuby1lbmZvcmNlYWJsZS1ob2xkb3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCB3ZWlnaHQgMFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1IUk0tNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBibGluZCBzZWNvbmQgYWdlbnQncyBzY29wZSBpcyBpbnRlbnQtb25seVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImhvbGRvdXRTY29wZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGdyYW50aW5nIGl0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIndvcmtzaGVldHMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHJlZnVzZWQgYXQgdGhlIG1pbnRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctSFJNLTdcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgZnMgZmlsdGVyIGlzIGRlbnktYnktZGVmYXVsdDsgYW4gZW1wdHkgcnVsZS1zZXQgZGVuaWVzIGFsbFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNoaXBwZWQgaW4gc2l0ZS1tYWluIzM2NDsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleHRlbmRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBoZXJlIHRvIHRoZSByb3V0aW5nIGhhbGYgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcGx5U2NvcGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1pcy1yb3V0ZWQgYSB0aHVuayBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSdWxlU2NvcGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvIHRoZSB3aG9sZS1tb3VudCBjaHJvb3QpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUhSTS04XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiSG9sZG91dCBkb2VzIG5vdCBwcm9tb3RlIGEgY2VsbCB0byBcXFwidmFsaWRhdGVkXFxcIlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInJlY2tvbmVyL3NyYy9lbmdpbmUvdGVzdHJ1bm5lci50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHJ1bGUgcHJlZGF0ZXMgRDk7IHRoZSBnYXRlIHBpbnMgaXQgc28gaXQgY2Fubm90IGJlIHF1aWV0bHkgcmUtcHJvbW90ZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoYXQtaXMtbm90LWJ1aWx0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ3aGF0LWlzLW5vdC1idWlsdFwiIC8+e1wiV2hhdCBpcyBOT1QgYnVpbHRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0b3BvbG9neSBpdHNlbGYgaW4gYSBSZWNrb25lciBkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGhvc3QtcGVyZm9ybWVkXFxucHJlLWFnZW50IHNwbGl0LCB3cml0aW5nIHRoZSB3aXRoaGVsZCBzbGljZSwgYW5kIGVtaXR0aW5nIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjaWZpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjZWxscyB0aGF0XFxucmVmZXJlbmNlIGl0LiBUaGUgcGxhdGZvcm0gbm93IGhhcyBldmVyeSBwcmltaXRpdmUgdGhhdCB3b3JrIG5lZWRzOyBub25lIG9mIGl0IGV4aXN0cyBpblxcbnRoZSBSZWNrb25lciBlbmdpbmUgeWV0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2lyaW5nIHRoZSBtaW50ZWQgcnVsZS1zZXRzIGludG8gdGhlIGxpdmUgcmVhbG0gbW91bnRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW50UmVhbG1SdWxlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlXFxuc2FuY3Rpb25lZCB3YXkgdG8gYnVpbGQgYSByZWFsbSdzIHJ1bGUtc2V0IGFuZCBpcyBmdWxseSBnYXRlZCwgYnV0IHRoZSBhc3Npc3RhbnQgcmVhbG1cXG5kb2VzIG5vdCB5ZXQgZXhpc3QgYXMgYSBkaXN0aW5jdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvIG1pbnQgb25lIGZvciDigJQgdGhhdCBpcyBENy9BQS0wMS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRyYWNraW5nIHRoZSBhZ2VudCdzIHJlYWQgcGF0aCBwZXIgZmVlZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2xhc3NpZnlIb2xkb3V0U3BsaXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnN1bWVzIGFuXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWdlbnRSZWFkRmVlZHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNldDsgbm90aGluZyBwb3B1bGF0ZXMgaXQgeWV0LiBVbnRpbCBzb21ldGhpbmcgZG9lcywgZXZlcnkgY2xhc3NpZmljYXRpb25cXG5pcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1bmtub3duLWZlZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKHkiB6ZXJvIGNyZWRpdCwgd2hpY2ggaXMgdGhlIGNvcnJlY3QgZmFpbC1jbG9zZWQgZGVmYXVsdCBhbmQgYWxzbyBtZWFuc1xcbm5vIGhvbGRvdXQgY3VycmVudGx5IGVhcm5zIGNyZWRpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicmVzaWR1YWxzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZXNpZHVhbHNcIiAvPntcIlJlc2lkdWFsc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSB0ZXN0LW9yYWNsZSBjaGFubmVsICjCpzUuMSkgaXMgb3BlbiwgYnkgZGVzaWduLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYWdlbnQgYXV0aG9ycyB0aGUgdGVzdCBjZWxsXFxudGhhdCBydW5zIG92ZXIgdGhlIGhvbGRvdXQgYW5kIHJlYWRzIGl0cyByZXN1bHQ7IHRyYWNlLXJlcGxheSBoYW5kcyBpdCB0aGUgZGVjbGFyZWRcXG5pbnB1dHMsIGFuZCBhIGZhaWx1cmUgbWVzc2FnZSBsZWFrcyB0aGUgZXhhY3QgYWdncmVnYXRlLiBTdXBwcmVzc2luZyByZXN1bHRzIHdvdWxkIHRhaW50XFxudGhlIGFzc2lzdGFudCBldmVyeSBhdXRob3JpbmcgaXRlcmF0aW9uIGFuZCBicmVhayB0aGUgbG9vcC4gVGhlIGNvcnJlY3RuZXNzIHdlaWdodFxcbnRoZXJlZm9yZSBsaXZlcyBpbiB0aGUgb3JhY2xlLWZyZWUgbGVncyAobWV0YW1vcnBoaWMvcHJvcGVydHkvbXV0YXRpb24pLCB3aGljaCBuZWVkIG5vXFxuaGlkZGVuIGRhdGEuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvbnN0cnVjdGlvbiAowqc1LjIpIGlzIGNlbnRyYWwsIG5vdCBhIGNvcm5lci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRm9yIGFmZmluZS9hZ2dyZWdhdGUvbG9va3VwIGZvcm11bGFzXFxudGhlIHRyYWluaW5nIHNwbGl0IFwifTxfY29tcG9uZW50cy5lbT57XCJkZXRlcm1pbmVzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGhvbGRvdXQgYnkgb3JkaW5hcnkgZml0dGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJsaW5kIHNlY29uZC1hZ2VudCBhdXRob3JpbmcgaXMgYSB3ZWFrIHNpZ25hbCAowqc3IC8gRDktMylcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFnZW50LTEgYXV0aG9ycyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmFnZW50LTIgcmVhZHMsIHNvIGEgY29tcGxldGUgaW50ZW50IG92ZXItZGV0ZXJtaW5lcyB0aGUgaW1wbGVtZW50YXRpb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3N0YXR1cy9IT0xET1VUX1JFREFDVEVEX01PVU5UX1NUQVRVUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHbEIsS0FBSyxDQUFDbUI7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUduQixXQUFXO0VBQ2hDLElBQUksQ0FBQ21CLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBdkIsV0FBQSxDQUFBd0IsSUFBQSxFQUFBeEIsV0FBQSxDQUFBeUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1QyxDQUFFLENBQUMsRUFBQywyQ0FBMkM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpUSxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBcUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO1FBQUFlLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNDLENBQUM7VUFBQ3lCLElBQUksRUFBQyx5Q0FBeUM7VUFBQUgsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7WUFBQW9CLFFBQUEsRUFBRTtVQUFzQyxDQUFtQjtRQUFDLENBQWUsQ0FBQyxFQUFDLDhEQUE4RDtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO01BQUNrQixFQUFFLEVBQUMsNkNBQTZDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkMsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsNkhBQTZILGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLHNJQUFzSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDa0IsRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNjLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXFCLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsOENBQThDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQTBDLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQixDQUFDLEVBQUMsd0NBQXdDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUscURBQXFELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQjtVQUFBLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsaUZBQWlGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWtDLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxxQ0FBcUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsa0JBQWtCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQStELENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFnQyxDQUFtQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0M7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3RCxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLHVFQUF1RSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsY0FBYztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQStDLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMseUJBQXlCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0UsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw0QkFBNEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtELENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUF3QyxDQUFtQixDQUFDLEVBQUMsK0VBQStFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO01BQUNrQixFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7WUFBQW9CLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7UUFBQSxDQUFxQixDQUFDLEVBQUMsdUZBQXVGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLGlJQUFpSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsb0lBQW9JLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxpRkFBaUYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsNkdBQTZHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyxXQUFXO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBVyxDQUFFLENBQUMsRUFBQyxXQUFXO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0QsQ0FBcUIsQ0FBQyxFQUFDLDJZQUEyWTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBbUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLG1DQUFtQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyRCxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLDJFQUEyRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNoc1M7QUFDZSxTQUFTSSxVQUFVQSxDQUFDNUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzZCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdsQixLQUFLLENBQUNtQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFoQyxXQUFBLENBQUE0QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLOUIsS0FBSztJQUFBd0IsUUFBQSxlQUFFLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUMzQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDK0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRywwREFBMEQsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNwUjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}