var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ChartFigure;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.reduce.js");
var _chartMath = require("../chartMath.ts");
var _shape = require("../shape.ts");
var _palette = require("../palette.ts");
var _format = require("../format.ts");
var _useContainerWidth = require("../useContainerWidth.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s2 = $RefreshSig$(); // The presentational SVG chart (§3.3.1 "SVG-first charts"): resolution-independent, accessible
// (DOM + ARIA), tokens-styled, and driven purely by rows + an encoding — no binding, no engine.
// `Chart` (bound) and `Facets` (row subsets) both draw through this. Every kind in the catalog
// is here: bar (grouped/stacked/normalized), line, area, scatter, histogram, pie (≤5 slices).
//
// Responsive by container: the SVG has a fixed viewBox and scales to 100% width; the density
// ladder (wide → medium → narrow) trims the legend/labels via ResizeObserver. Resize is a pure
// view op (resize ≠ recompute).
const W = 720;
const H = 340;
const M = {
  top: 16,
  right: 20,
  bottom: 44,
  left: 60
};
const PW = W - M.left - M.right;
const PH = H - M.top - M.bottom;
function tickLabel(n) {
  const a = Math.abs(n);
  if (a >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (a >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return (0, _format.formatNumber)(n);
}

// Cartesian frame: y gridlines + labels, and a baseline. Returns the y-scale for callers.
function YAxis({
  domain
}) {
  const y = (0, _chartMath.linearScale)(domain, [M.top + PH, M.top]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("g", {
    className: "rk-chart-axis",
    "aria-hidden": "true",
    children: (0, _chartMath.ticks)(domain, 4).map((t, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("g", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("line", {
        x1: M.left,
        x2: M.left + PW,
        y1: y(t),
        y2: y(t),
        className: "rk-chart-grid"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("text", {
        x: M.left - 8,
        y: y(t),
        dy: "0.32em",
        textAnchor: "end",
        className: "rk-chart-tick",
        children: tickLabel(t)
      })]
    }, i))
  });
}
_c = YAxis;
function XCategoryLabels({
  cats,
  band,
  density
}) {
  const stride = density === 'narrow' ? Math.ceil(cats.length / 4) : density === 'medium' ? Math.ceil(cats.length / 8) : 1;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("g", {
    className: "rk-chart-axis",
    "aria-hidden": "true",
    children: cats.map((c, i) => i % stride === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsx)("text", {
      x: band(i),
      y: M.top + PH + 18,
      textAnchor: "middle",
      className: "rk-chart-tick",
      children: c.length > 10 ? `${c.slice(0, 9)}…` : c
    }, i) : null)
  });
}
_c2 = XCategoryLabels;
function Legend({
  names,
  density
}) {
  if (density === 'narrow' || names.length <= 1 || names.every(n => n === '')) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("g", {
    className: "rk-chart-legend",
    children: names.map((n, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("g", {
      transform: `translate(${M.left + i * 130}, ${H - 6})`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("rect", {
        width: 11,
        height: 11,
        y: -10,
        rx: 2,
        fill: (0, _palette.seriesColor)(i)
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("text", {
        x: 16,
        className: "rk-chart-tick",
        children: n.length > 12 ? `${n.slice(0, 11)}…` : n
      })]
    }, i))
  });
}
_c3 = Legend;
function BarChart({
  rows,
  enc,
  density
}) {
  const xf = enc.x ?? 'x';
  const yf = enc.y ?? 'y';
  const cats = (0, _chartMath.categories)(rows, xf);
  const series = (0, _chartMath.seriesByColor)(rows, enc.color);
  const bandW = PW / Math.max(1, cats.length);
  const bandX = i => M.left + bandW * i + bandW / 2;

  // Index rows by (category, series) for stacking / grouping.
  const at = (si, ci) => {
    const cat = cats[ci];
    const r = series[si].rows.find(row => (0, _shape.labelField)(row, xf) === cat);
    return r ? (0, _shape.numericField)(r, yf) ?? 0 : 0;
  };
  if (enc.stack === 'none') {
    const inner = bandW * 0.7;
    const gw = inner / series.length;
    const domain = (0, _chartMath.niceDomain)(rows.map(r => (0, _shape.numericField)(r, yf)));
    const y = (0, _chartMath.linearScale)(domain, [M.top + PH, M.top]);
    const y0 = y(Math.max(domain[0], 0));
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(YAxis, {
        domain: domain
      }), series.map((_s, si) => cats.map((_, ci) => {
        const v = at(si, ci);
        const yv = y(v);
        const x = M.left + bandW * ci + (bandW - inner) / 2 + gw * si;
        return /*#__PURE__*/(0, _jsxRuntime.jsx)("rect", {
          x: x,
          y: Math.min(yv, y0),
          width: Math.max(0, gw - 1),
          height: Math.abs(yv - y0),
          fill: (0, _palette.seriesColor)(si)
        }, `${si}-${ci}`);
      })), /*#__PURE__*/(0, _jsxRuntime.jsx)(XCategoryLabels, {
        cats: cats,
        band: bandX,
        density: density
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Legend, {
        names: series.map(s => s.name),
        density: density
      })]
    });
  }

  // stacked / normalized
  const totals = cats.map((_, ci) => series.reduce((acc, _s, si) => acc + Math.max(0, at(si, ci)), 0));
  const domain = enc.stack === 'normalized' ? [0, 1] : [0, Math.max(1, ...totals)];
  const y = (0, _chartMath.linearScale)(domain, [M.top + PH, M.top]);
  const barW = bandW * 0.7;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(YAxis, {
      domain: domain
    }), cats.map((_, ci) => {
      let acc = 0;
      const total = enc.stack === 'normalized' ? totals[ci] || 1 : 1;
      return series.map((_s, si) => {
        const raw = Math.max(0, at(si, ci));
        const v = enc.stack === 'normalized' ? raw / total : raw;
        const yTop = y(acc + v);
        const yBot = y(acc);
        acc += v;
        const x = M.left + bandW * ci + (bandW - barW) / 2;
        return /*#__PURE__*/(0, _jsxRuntime.jsx)("rect", {
          x: x,
          y: yTop,
          width: barW,
          height: Math.max(0, yBot - yTop),
          fill: (0, _palette.seriesColor)(si)
        }, `${si}-${ci}`);
      });
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(XCategoryLabels, {
      cats: cats,
      band: bandX,
      density: density
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Legend, {
      names: series.map(s => s.name),
      density: density
    })]
  });
}
_c4 = BarChart;
function LineArea({
  rows,
  enc,
  density
}) {
  const xf = enc.x ?? 'x';
  const yf = enc.y ?? 'y';
  const cats = (0, _chartMath.categories)(rows, xf);
  const series = (0, _chartMath.seriesByColor)(rows, enc.color);
  const bandW = PW / Math.max(1, cats.length - 1 || 1);
  const px = cat => M.left + bandW * Math.max(0, cats.indexOf(cat));
  const domain = (0, _chartMath.niceDomain)(rows.map(r => (0, _shape.numericField)(r, yf)));
  const y = (0, _chartMath.linearScale)(domain, [M.top + PH, M.top]);
  const y0 = y(Math.max(domain[0], 0));
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(YAxis, {
      domain: domain
    }), series.map((s, si) => {
      const pts = s.rows.map(r => ({
        x: px((0, _shape.labelField)(r, xf)),
        y: (0, _shape.numericField)(r, yf)
      })).filter(p => p.y !== null).map(p => ({
        x: p.x,
        y: y(p.y)
      }));
      if (pts.length === 0) return null;
      const line = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
      const color = (0, _palette.seriesColor)(si);
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("g", {
        children: [enc.kind === 'area' && /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
          d: `${line} L ${pts[pts.length - 1].x.toFixed(1)} ${y0.toFixed(1)} L ${pts[0].x.toFixed(1)} ${y0.toFixed(1)} Z`,
          fill: color,
          fillOpacity: 0.18
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
          d: line,
          fill: "none",
          stroke: color,
          strokeWidth: 2,
          strokeLinejoin: "round",
          strokeLinecap: "round"
        })]
      }, si);
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(XCategoryLabels, {
      cats: cats,
      band: i => M.left + bandW * i,
      density: density
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Legend, {
      names: series.map(s => s.name),
      density: density
    })]
  });
}
_c5 = LineArea;
function Scatter({
  rows,
  enc,
  density
}) {
  const xf = enc.x ?? 'x';
  const yf = enc.y ?? 'y';
  const series = (0, _chartMath.seriesByColor)(rows, enc.color);
  const xd = (0, _chartMath.niceDomain)(rows.map(r => (0, _shape.numericField)(r, xf)));
  const yd = (0, _chartMath.niceDomain)(rows.map(r => (0, _shape.numericField)(r, yf)));
  const x = (0, _chartMath.linearScale)(xd, [M.left, M.left + PW]);
  const y = (0, _chartMath.linearScale)(yd, [M.top + PH, M.top]);
  const sizes = enc.size ? rows.map(r => (0, _shape.numericField)(r, enc.size) ?? 0) : [];
  const sMax = sizes.length ? Math.max(1, ...sizes) : 1;
  const radius = r => enc.size ? 3 + 9 * Math.sqrt(Math.max(0, ((0, _shape.numericField)(r, enc.size) ?? 0) / sMax)) : 4;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(YAxis, {
      domain: yd
    }), series.map((s, si) => s.rows.map((r, ri) => {
      const xv = (0, _shape.numericField)(r, xf);
      const yv = (0, _shape.numericField)(r, yf);
      if (xv === null || yv === null) return null;
      return /*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
        cx: x(xv),
        cy: y(yv),
        r: radius(r),
        fill: (0, _palette.seriesColor)(si),
        fillOpacity: 0.7
      }, `${si}-${ri}`);
    })), /*#__PURE__*/(0, _jsxRuntime.jsx)("g", {
      className: "rk-chart-axis",
      "aria-hidden": "true",
      children: (0, _chartMath.ticks)(xd, density === 'narrow' ? 2 : 4).map((t, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("text", {
        x: x(t),
        y: M.top + PH + 18,
        textAnchor: "middle",
        className: "rk-chart-tick",
        children: tickLabel(t)
      }, i))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Legend, {
      names: series.map(s => s.name),
      density: density
    })]
  });
}
_c6 = Scatter;
function HistogramChart({
  rows,
  enc
}) {
  const vf = enc.value ?? 'value';
  const bins = (0, _chartMath.histogram)(rows, vf, enc.bins);
  const domain = (0, _chartMath.niceDomain)(bins.map(b => b.count));
  const y = (0, _chartMath.linearScale)(domain, [M.top + PH, M.top]);
  const y0 = y(0);
  const bw = PW / Math.max(1, bins.length);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(YAxis, {
      domain: domain
    }), bins.map((b, i) => {
      const yv = y(b.count);
      return /*#__PURE__*/(0, _jsxRuntime.jsx)("rect", {
        x: M.left + bw * i + 1,
        y: yv,
        width: Math.max(0, bw - 2),
        height: Math.max(0, y0 - yv),
        fill: (0, _palette.seriesColor)(0)
      }, i);
    })]
  });
}

// Precompute wedge paths without mutating render-scope state (react-hooks/immutability). Each
// entry is a full-circle flag (a lone slice ≈ the whole pie — a single `A` arc from start to
// the identical end point is degenerate and draws nothing) or a wedge path string.
_c7 = HistogramChart;
function pieArcs(slices, cx, cy, r) {
  const total = slices.reduce((acc, s) => acc + s.value, 0) || 1;
  const out = [];
  let a0 = -Math.PI / 2;
  for (const s of slices) {
    const frac = s.value / total;
    if (frac >= 0.9999) {
      out.push({
        full: true
      });
      continue;
    }
    const a1 = a0 + frac * Math.PI * 2;
    const large = a1 - a0 > Math.PI ? 1 : 0;
    const p0 = [cx + r * Math.cos(a0), cy + r * Math.sin(a0)];
    const p1 = [cx + r * Math.cos(a1), cy + r * Math.sin(a1)];
    out.push({
      full: false,
      d: `M ${cx} ${cy} L ${p0[0].toFixed(1)} ${p0[1].toFixed(1)} A ${r} ${r} 0 ${large} 1 ${p1[0].toFixed(1)} ${p1[1].toFixed(1)} Z`
    });
    a0 = a1;
  }
  return out;
}
function PieChart({
  rows,
  enc,
  density
}) {
  const vf = enc.value ?? 'value';
  const lf = enc.label ?? 'label';
  const slices = (0, _chartMath.pieSlices)(rows, vf, lf);
  const cx = M.left + PW / 2;
  const cy = M.top + PH / 2;
  const r = Math.min(PW, PH) / 2 - 6;
  const wedges = pieArcs(slices, cx, cy, r);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("g", {
      children: wedges.map((w, i) => w.full ? /*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
        cx: cx,
        cy: cy,
        r: r,
        fill: (0, _palette.seriesColor)(i),
        stroke: "var(--panel, #13141d)",
        strokeWidth: 1.5
      }, i) : /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
        d: w.d,
        fill: (0, _palette.seriesColor)(i),
        stroke: "var(--panel, #13141d)",
        strokeWidth: 1.5
      }, i))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Legend, {
      names: slices.map(s => s.label),
      density: density
    })]
  });
}
_c8 = PieChart;
function ChartFigure({
  rows,
  enc,
  ariaLabel
}) {
  _s2();
  const {
    ref,
    width
  } = (0, _useContainerWidth.useContainerWidth)(W);
  const density = (0, _useContainerWidth.densityFor)(width);
  const label = ariaLabel ?? `${enc.kind} chart`;
  if (rows.length === 0) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-chart rk-chart-empty",
      ref: ref,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-broken-reason",
        children: "no data"
      })
    });
  }
  let body;
  switch (enc.kind) {
    case 'bar':
      body = /*#__PURE__*/(0, _jsxRuntime.jsx)(BarChart, {
        rows: rows,
        enc: enc,
        density: density
      });
      break;
    case 'line':
    case 'area':
      body = /*#__PURE__*/(0, _jsxRuntime.jsx)(LineArea, {
        rows: rows,
        enc: enc,
        density: density
      });
      break;
    case 'scatter':
      body = /*#__PURE__*/(0, _jsxRuntime.jsx)(Scatter, {
        rows: rows,
        enc: enc,
        density: density
      });
      break;
    case 'histogram':
      body = /*#__PURE__*/(0, _jsxRuntime.jsx)(HistogramChart, {
        rows: rows,
        enc: enc
      });
      break;
    case 'pie':
      body = /*#__PURE__*/(0, _jsxRuntime.jsx)(PieChart, {
        rows: rows,
        enc: enc,
        density: density
      });
      break;
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-chart",
    ref: ref,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("svg", {
      viewBox: `0 0 ${W} ${H}`,
      preserveAspectRatio: "xMidYMid meet",
      className: "rk-chart-svg",
      role: "img",
      "aria-label": label,
      children: body
    })
  });
}
_s2(ChartFigure, "2nz6BVdmTV2W57iBxNej7wKjZ8s=", false, function () {
  return [_useContainerWidth.useContainerWidth];
});
_c9 = ChartFigure;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "YAxis");
$RefreshReg$(_c2, "XCategoryLabels");
$RefreshReg$(_c3, "Legend");
$RefreshReg$(_c4, "BarChart");
$RefreshReg$(_c5, "LineArea");
$RefreshReg$(_c6, "Scatter");
$RefreshReg$(_c7, "HistogramChart");
$RefreshReg$(_c8, "PieChart");
$RefreshReg$(_c9, "ChartFigure");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY2hhcnRNYXRoIiwicmVxdWlyZSIsIl9zaGFwZSIsIl9wYWxldHRlIiwiX2Zvcm1hdCIsIl91c2VDb250YWluZXJXaWR0aCIsIl9qc3hSdW50aW1lIiwiX3MyIiwiJFJlZnJlc2hTaWckIiwiVyIsIkgiLCJNIiwidG9wIiwicmlnaHQiLCJib3R0b20iLCJsZWZ0IiwiUFciLCJQSCIsInRpY2tMYWJlbCIsIm4iLCJhIiwiTWF0aCIsImFicyIsInRvRml4ZWQiLCJmb3JtYXROdW1iZXIiLCJZQXhpcyIsImRvbWFpbiIsInkiLCJsaW5lYXJTY2FsZSIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwidGlja3MiLCJtYXAiLCJ0IiwiaSIsImpzeHMiLCJ4MSIsIngyIiwieTEiLCJ5MiIsIngiLCJkeSIsInRleHRBbmNob3IiLCJfYyIsIlhDYXRlZ29yeUxhYmVscyIsImNhdHMiLCJiYW5kIiwiZGVuc2l0eSIsInN0cmlkZSIsImNlaWwiLCJsZW5ndGgiLCJjIiwic2xpY2UiLCJfYzIiLCJMZWdlbmQiLCJuYW1lcyIsImV2ZXJ5IiwidHJhbnNmb3JtIiwid2lkdGgiLCJoZWlnaHQiLCJyeCIsImZpbGwiLCJzZXJpZXNDb2xvciIsIl9jMyIsIkJhckNoYXJ0Iiwicm93cyIsImVuYyIsInhmIiwieWYiLCJjYXRlZ29yaWVzIiwic2VyaWVzIiwic2VyaWVzQnlDb2xvciIsImNvbG9yIiwiYmFuZFciLCJtYXgiLCJiYW5kWCIsImF0Iiwic2kiLCJjaSIsImNhdCIsInIiLCJmaW5kIiwicm93IiwibGFiZWxGaWVsZCIsIm51bWVyaWNGaWVsZCIsInN0YWNrIiwiaW5uZXIiLCJndyIsIm5pY2VEb21haW4iLCJ5MCIsIkZyYWdtZW50IiwiX3MiLCJfIiwidiIsInl2IiwibWluIiwicyIsIm5hbWUiLCJ0b3RhbHMiLCJyZWR1Y2UiLCJhY2MiLCJiYXJXIiwidG90YWwiLCJyYXciLCJ5VG9wIiwieUJvdCIsIl9jNCIsIkxpbmVBcmVhIiwicHgiLCJpbmRleE9mIiwicHRzIiwiZmlsdGVyIiwicCIsImxpbmUiLCJqb2luIiwia2luZCIsImQiLCJmaWxsT3BhY2l0eSIsInN0cm9rZSIsInN0cm9rZVdpZHRoIiwic3Ryb2tlTGluZWpvaW4iLCJzdHJva2VMaW5lY2FwIiwiX2M1IiwiU2NhdHRlciIsInhkIiwieWQiLCJzaXplcyIsInNpemUiLCJzTWF4IiwicmFkaXVzIiwic3FydCIsInJpIiwieHYiLCJjeCIsImN5IiwiX2M2IiwiSGlzdG9ncmFtQ2hhcnQiLCJ2ZiIsInZhbHVlIiwiYmlucyIsImhpc3RvZ3JhbSIsImIiLCJjb3VudCIsImJ3IiwiX2M3IiwicGllQXJjcyIsInNsaWNlcyIsIm91dCIsImEwIiwiUEkiLCJmcmFjIiwicHVzaCIsImZ1bGwiLCJhMSIsImxhcmdlIiwicDAiLCJjb3MiLCJzaW4iLCJwMSIsIlBpZUNoYXJ0IiwibGYiLCJsYWJlbCIsInBpZVNsaWNlcyIsIndlZGdlcyIsInciLCJfYzgiLCJDaGFydEZpZ3VyZSIsImFyaWFMYWJlbCIsInJlZiIsInVzZUNvbnRhaW5lcldpZHRoIiwiZGVuc2l0eUZvciIsImJvZHkiLCJ2aWV3Qm94IiwicHJlc2VydmVBc3BlY3RSYXRpbyIsInJvbGUiLCJfYzkiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDaGFydEZpZ3VyZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHByZXNlbnRhdGlvbmFsIFNWRyBjaGFydCAowqczLjMuMSBcIlNWRy1maXJzdCBjaGFydHNcIik6IHJlc29sdXRpb24taW5kZXBlbmRlbnQsIGFjY2Vzc2libGVcbi8vIChET00gKyBBUklBKSwgdG9rZW5zLXN0eWxlZCwgYW5kIGRyaXZlbiBwdXJlbHkgYnkgcm93cyArIGFuIGVuY29kaW5nIOKAlCBubyBiaW5kaW5nLCBubyBlbmdpbmUuXG4vLyBgQ2hhcnRgIChib3VuZCkgYW5kIGBGYWNldHNgIChyb3cgc3Vic2V0cykgYm90aCBkcmF3IHRocm91Z2ggdGhpcy4gRXZlcnkga2luZCBpbiB0aGUgY2F0YWxvZ1xuLy8gaXMgaGVyZTogYmFyIChncm91cGVkL3N0YWNrZWQvbm9ybWFsaXplZCksIGxpbmUsIGFyZWEsIHNjYXR0ZXIsIGhpc3RvZ3JhbSwgcGllICjiiaQ1IHNsaWNlcykuXG4vL1xuLy8gUmVzcG9uc2l2ZSBieSBjb250YWluZXI6IHRoZSBTVkcgaGFzIGEgZml4ZWQgdmlld0JveCBhbmQgc2NhbGVzIHRvIDEwMCUgd2lkdGg7IHRoZSBkZW5zaXR5XG4vLyBsYWRkZXIgKHdpZGUg4oaSIG1lZGl1bSDihpIgbmFycm93KSB0cmltcyB0aGUgbGVnZW5kL2xhYmVscyB2aWEgUmVzaXplT2JzZXJ2ZXIuIFJlc2l6ZSBpcyBhIHB1cmVcbi8vIHZpZXcgb3AgKHJlc2l6ZSDiiaAgcmVjb21wdXRlKS5cbmltcG9ydCB0eXBlIHsgUm93IH0gZnJvbSAnLi4vLi4vLi4vc3RkbGliL3R5cGVzLnRzJztcbmltcG9ydCB0eXBlIHsgQ2hhcnRFbmNvZGluZyB9IGZyb20gJy4uL2NoYXJ0RW5jb2RpbmcudHMnO1xuaW1wb3J0IHsgbGluZWFyU2NhbGUsIG5pY2VEb21haW4sIHRpY2tzLCBjYXRlZ29yaWVzLCBzZXJpZXNCeUNvbG9yLCBoaXN0b2dyYW0sIHBpZVNsaWNlcyB9IGZyb20gJy4uL2NoYXJ0TWF0aC50cyc7XG5pbXBvcnQgeyBudW1lcmljRmllbGQsIGxhYmVsRmllbGQgfSBmcm9tICcuLi9zaGFwZS50cyc7XG5pbXBvcnQgeyBzZXJpZXNDb2xvciB9IGZyb20gJy4uL3BhbGV0dGUudHMnO1xuaW1wb3J0IHsgZm9ybWF0TnVtYmVyIH0gZnJvbSAnLi4vZm9ybWF0LnRzJztcbmltcG9ydCB7IHVzZUNvbnRhaW5lcldpZHRoLCBkZW5zaXR5Rm9yIH0gZnJvbSAnLi4vdXNlQ29udGFpbmVyV2lkdGgudHMnO1xuXG5jb25zdCBXID0gNzIwO1xuY29uc3QgSCA9IDM0MDtcbmNvbnN0IE0gPSB7IHRvcDogMTYsIHJpZ2h0OiAyMCwgYm90dG9tOiA0NCwgbGVmdDogNjAgfTtcbmNvbnN0IFBXID0gVyAtIE0ubGVmdCAtIE0ucmlnaHQ7XG5jb25zdCBQSCA9IEggLSBNLnRvcCAtIE0uYm90dG9tO1xuXG50eXBlIERlbnNpdHkgPSAnd2lkZScgfCAnbWVkaXVtJyB8ICduYXJyb3cnO1xuXG5mdW5jdGlvbiB0aWNrTGFiZWwobjogbnVtYmVyKTogc3RyaW5nIHtcbiAgY29uc3QgYSA9IE1hdGguYWJzKG4pO1xuICBpZiAoYSA+PSAxXzAwMF8wMDApIHJldHVybiBgJHsobiAvIDFfMDAwXzAwMCkudG9GaXhlZCgxKX1NYDtcbiAgaWYgKGEgPj0gMV8wMDApIHJldHVybiBgJHsobiAvIDFfMDAwKS50b0ZpeGVkKDEpfWtgO1xuICByZXR1cm4gZm9ybWF0TnVtYmVyKG4pO1xufVxuXG4vLyBDYXJ0ZXNpYW4gZnJhbWU6IHkgZ3JpZGxpbmVzICsgbGFiZWxzLCBhbmQgYSBiYXNlbGluZS4gUmV0dXJucyB0aGUgeS1zY2FsZSBmb3IgY2FsbGVycy5cbmZ1bmN0aW9uIFlBeGlzKHsgZG9tYWluIH06IHsgZG9tYWluOiBbbnVtYmVyLCBudW1iZXJdIH0pIHtcbiAgY29uc3QgeSA9IGxpbmVhclNjYWxlKGRvbWFpbiwgW00udG9wICsgUEgsIE0udG9wXSk7XG4gIHJldHVybiAoXG4gICAgPGcgY2xhc3NOYW1lPVwicmstY2hhcnQtYXhpc1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAge3RpY2tzKGRvbWFpbiwgNCkubWFwKCh0LCBpKSA9PiAoXG4gICAgICAgIDxnIGtleT17aX0+XG4gICAgICAgICAgPGxpbmUgeDE9e00ubGVmdH0geDI9e00ubGVmdCArIFBXfSB5MT17eSh0KX0geTI9e3kodCl9IGNsYXNzTmFtZT1cInJrLWNoYXJ0LWdyaWRcIiAvPlxuICAgICAgICAgIDx0ZXh0IHg9e00ubGVmdCAtIDh9IHk9e3kodCl9IGR5PVwiMC4zMmVtXCIgdGV4dEFuY2hvcj1cImVuZFwiIGNsYXNzTmFtZT1cInJrLWNoYXJ0LXRpY2tcIj5cbiAgICAgICAgICAgIHt0aWNrTGFiZWwodCl9XG4gICAgICAgICAgPC90ZXh0PlxuICAgICAgICA8L2c+XG4gICAgICApKX1cbiAgICA8L2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFhDYXRlZ29yeUxhYmVscyh7IGNhdHMsIGJhbmQsIGRlbnNpdHkgfTogeyBjYXRzOiBzdHJpbmdbXTsgYmFuZDogKGk6IG51bWJlcikgPT4gbnVtYmVyOyBkZW5zaXR5OiBEZW5zaXR5IH0pIHtcbiAgY29uc3Qgc3RyaWRlID0gZGVuc2l0eSA9PT0gJ25hcnJvdycgPyBNYXRoLmNlaWwoY2F0cy5sZW5ndGggLyA0KSA6IGRlbnNpdHkgPT09ICdtZWRpdW0nID8gTWF0aC5jZWlsKGNhdHMubGVuZ3RoIC8gOCkgOiAxO1xuICByZXR1cm4gKFxuICAgIDxnIGNsYXNzTmFtZT1cInJrLWNoYXJ0LWF4aXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIHtjYXRzLm1hcCgoYywgaSkgPT5cbiAgICAgICAgaSAlIHN0cmlkZSA9PT0gMCA/IChcbiAgICAgICAgICA8dGV4dCBrZXk9e2l9IHg9e2JhbmQoaSl9IHk9e00udG9wICsgUEggKyAxOH0gdGV4dEFuY2hvcj1cIm1pZGRsZVwiIGNsYXNzTmFtZT1cInJrLWNoYXJ0LXRpY2tcIj5cbiAgICAgICAgICAgIHtjLmxlbmd0aCA+IDEwID8gYCR7Yy5zbGljZSgwLCA5KX3igKZgIDogY31cbiAgICAgICAgICA8L3RleHQ+XG4gICAgICAgICkgOiBudWxsLFxuICAgICAgKX1cbiAgICA8L2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIExlZ2VuZCh7IG5hbWVzLCBkZW5zaXR5IH06IHsgbmFtZXM6IHN0cmluZ1tdOyBkZW5zaXR5OiBEZW5zaXR5IH0pIHtcbiAgaWYgKGRlbnNpdHkgPT09ICduYXJyb3cnIHx8IG5hbWVzLmxlbmd0aCA8PSAxIHx8IG5hbWVzLmV2ZXJ5KChuKSA9PiBuID09PSAnJykpIHJldHVybiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxnIGNsYXNzTmFtZT1cInJrLWNoYXJ0LWxlZ2VuZFwiPlxuICAgICAge25hbWVzLm1hcCgobiwgaSkgPT4gKFxuICAgICAgICA8ZyBrZXk9e2l9IHRyYW5zZm9ybT17YHRyYW5zbGF0ZSgke00ubGVmdCArIGkgKiAxMzB9LCAke0ggLSA2fSlgfT5cbiAgICAgICAgICA8cmVjdCB3aWR0aD17MTF9IGhlaWdodD17MTF9IHk9ey0xMH0gcng9ezJ9IGZpbGw9e3Nlcmllc0NvbG9yKGkpfSAvPlxuICAgICAgICAgIDx0ZXh0IHg9ezE2fSBjbGFzc05hbWU9XCJyay1jaGFydC10aWNrXCI+XG4gICAgICAgICAgICB7bi5sZW5ndGggPiAxMiA/IGAke24uc2xpY2UoMCwgMTEpfeKApmAgOiBufVxuICAgICAgICAgIDwvdGV4dD5cbiAgICAgICAgPC9nPlxuICAgICAgKSl9XG4gICAgPC9nPlxuICApO1xufVxuXG5mdW5jdGlvbiBCYXJDaGFydCh7IHJvd3MsIGVuYywgZGVuc2l0eSB9OiB7IHJvd3M6IFJvd1tdOyBlbmM6IENoYXJ0RW5jb2Rpbmc7IGRlbnNpdHk6IERlbnNpdHkgfSkge1xuICBjb25zdCB4ZiA9IGVuYy54ID8/ICd4JztcbiAgY29uc3QgeWYgPSBlbmMueSA/PyAneSc7XG4gIGNvbnN0IGNhdHMgPSBjYXRlZ29yaWVzKHJvd3MsIHhmKTtcbiAgY29uc3Qgc2VyaWVzID0gc2VyaWVzQnlDb2xvcihyb3dzLCBlbmMuY29sb3IpO1xuICBjb25zdCBiYW5kVyA9IFBXIC8gTWF0aC5tYXgoMSwgY2F0cy5sZW5ndGgpO1xuICBjb25zdCBiYW5kWCA9IChpOiBudW1iZXIpOiBudW1iZXIgPT4gTS5sZWZ0ICsgYmFuZFcgKiBpICsgYmFuZFcgLyAyO1xuXG4gIC8vIEluZGV4IHJvd3MgYnkgKGNhdGVnb3J5LCBzZXJpZXMpIGZvciBzdGFja2luZyAvIGdyb3VwaW5nLlxuICBjb25zdCBhdCA9IChzaTogbnVtYmVyLCBjaTogbnVtYmVyKTogbnVtYmVyID0+IHtcbiAgICBjb25zdCBjYXQgPSBjYXRzW2NpXTtcbiAgICBjb25zdCByID0gc2VyaWVzW3NpXS5yb3dzLmZpbmQoKHJvdykgPT4gbGFiZWxGaWVsZChyb3csIHhmKSA9PT0gY2F0KTtcbiAgICByZXR1cm4gciA/IG51bWVyaWNGaWVsZChyLCB5ZikgPz8gMCA6IDA7XG4gIH07XG5cbiAgaWYgKGVuYy5zdGFjayA9PT0gJ25vbmUnKSB7XG4gICAgY29uc3QgaW5uZXIgPSBiYW5kVyAqIDAuNztcbiAgICBjb25zdCBndyA9IGlubmVyIC8gc2VyaWVzLmxlbmd0aDtcbiAgICBjb25zdCBkb21haW4gPSBuaWNlRG9tYWluKHJvd3MubWFwKChyKSA9PiBudW1lcmljRmllbGQociwgeWYpKSk7XG4gICAgY29uc3QgeSA9IGxpbmVhclNjYWxlKGRvbWFpbiwgW00udG9wICsgUEgsIE0udG9wXSk7XG4gICAgY29uc3QgeTAgPSB5KE1hdGgubWF4KGRvbWFpblswXSwgMCkpO1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8WUF4aXMgZG9tYWluPXtkb21haW59IC8+XG4gICAgICAgIHtzZXJpZXMubWFwKChfcywgc2kpID0+XG4gICAgICAgICAgY2F0cy5tYXAoKF8sIGNpKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB2ID0gYXQoc2ksIGNpKTtcbiAgICAgICAgICAgIGNvbnN0IHl2ID0geSh2KTtcbiAgICAgICAgICAgIGNvbnN0IHggPSBNLmxlZnQgKyBiYW5kVyAqIGNpICsgKGJhbmRXIC0gaW5uZXIpIC8gMiArIGd3ICogc2k7XG4gICAgICAgICAgICByZXR1cm4gPHJlY3Qga2V5PXtgJHtzaX0tJHtjaX1gfSB4PXt4fSB5PXtNYXRoLm1pbih5diwgeTApfSB3aWR0aD17TWF0aC5tYXgoMCwgZ3cgLSAxKX0gaGVpZ2h0PXtNYXRoLmFicyh5diAtIHkwKX0gZmlsbD17c2VyaWVzQ29sb3Ioc2kpfSAvPjtcbiAgICAgICAgICB9KSxcbiAgICAgICAgKX1cbiAgICAgICAgPFhDYXRlZ29yeUxhYmVscyBjYXRzPXtjYXRzfSBiYW5kPXtiYW5kWH0gZGVuc2l0eT17ZGVuc2l0eX0gLz5cbiAgICAgICAgPExlZ2VuZCBuYW1lcz17c2VyaWVzLm1hcCgocykgPT4gcy5uYW1lKX0gZGVuc2l0eT17ZGVuc2l0eX0gLz5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICAvLyBzdGFja2VkIC8gbm9ybWFsaXplZFxuICBjb25zdCB0b3RhbHMgPSBjYXRzLm1hcCgoXywgY2kpID0+IHNlcmllcy5yZWR1Y2UoKGFjYywgX3MsIHNpKSA9PiBhY2MgKyBNYXRoLm1heCgwLCBhdChzaSwgY2kpKSwgMCkpO1xuICBjb25zdCBkb21haW46IFtudW1iZXIsIG51bWJlcl0gPSBlbmMuc3RhY2sgPT09ICdub3JtYWxpemVkJyA/IFswLCAxXSA6IFswLCBNYXRoLm1heCgxLCAuLi50b3RhbHMpXTtcbiAgY29uc3QgeSA9IGxpbmVhclNjYWxlKGRvbWFpbiwgW00udG9wICsgUEgsIE0udG9wXSk7XG4gIGNvbnN0IGJhclcgPSBiYW5kVyAqIDAuNztcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFlBeGlzIGRvbWFpbj17ZG9tYWlufSAvPlxuICAgICAge2NhdHMubWFwKChfLCBjaSkgPT4ge1xuICAgICAgICBsZXQgYWNjID0gMDtcbiAgICAgICAgY29uc3QgdG90YWwgPSBlbmMuc3RhY2sgPT09ICdub3JtYWxpemVkJyA/IHRvdGFsc1tjaV0gfHwgMSA6IDE7XG4gICAgICAgIHJldHVybiBzZXJpZXMubWFwKChfcywgc2kpID0+IHtcbiAgICAgICAgICBjb25zdCByYXcgPSBNYXRoLm1heCgwLCBhdChzaSwgY2kpKTtcbiAgICAgICAgICBjb25zdCB2ID0gZW5jLnN0YWNrID09PSAnbm9ybWFsaXplZCcgPyByYXcgLyB0b3RhbCA6IHJhdztcbiAgICAgICAgICBjb25zdCB5VG9wID0geShhY2MgKyB2KTtcbiAgICAgICAgICBjb25zdCB5Qm90ID0geShhY2MpO1xuICAgICAgICAgIGFjYyArPSB2O1xuICAgICAgICAgIGNvbnN0IHggPSBNLmxlZnQgKyBiYW5kVyAqIGNpICsgKGJhbmRXIC0gYmFyVykgLyAyO1xuICAgICAgICAgIHJldHVybiA8cmVjdCBrZXk9e2Ake3NpfS0ke2NpfWB9IHg9e3h9IHk9e3lUb3B9IHdpZHRoPXtiYXJXfSBoZWlnaHQ9e01hdGgubWF4KDAsIHlCb3QgLSB5VG9wKX0gZmlsbD17c2VyaWVzQ29sb3Ioc2kpfSAvPjtcbiAgICAgICAgfSk7XG4gICAgICB9KX1cbiAgICAgIDxYQ2F0ZWdvcnlMYWJlbHMgY2F0cz17Y2F0c30gYmFuZD17YmFuZFh9IGRlbnNpdHk9e2RlbnNpdHl9IC8+XG4gICAgICA8TGVnZW5kIG5hbWVzPXtzZXJpZXMubWFwKChzKSA9PiBzLm5hbWUpfSBkZW5zaXR5PXtkZW5zaXR5fSAvPlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBMaW5lQXJlYSh7IHJvd3MsIGVuYywgZGVuc2l0eSB9OiB7IHJvd3M6IFJvd1tdOyBlbmM6IENoYXJ0RW5jb2Rpbmc7IGRlbnNpdHk6IERlbnNpdHkgfSkge1xuICBjb25zdCB4ZiA9IGVuYy54ID8/ICd4JztcbiAgY29uc3QgeWYgPSBlbmMueSA/PyAneSc7XG4gIGNvbnN0IGNhdHMgPSBjYXRlZ29yaWVzKHJvd3MsIHhmKTtcbiAgY29uc3Qgc2VyaWVzID0gc2VyaWVzQnlDb2xvcihyb3dzLCBlbmMuY29sb3IpO1xuICBjb25zdCBiYW5kVyA9IFBXIC8gTWF0aC5tYXgoMSwgY2F0cy5sZW5ndGggLSAxIHx8IDEpO1xuICBjb25zdCBweCA9IChjYXQ6IHN0cmluZyk6IG51bWJlciA9PiBNLmxlZnQgKyBiYW5kVyAqIE1hdGgubWF4KDAsIGNhdHMuaW5kZXhPZihjYXQpKTtcbiAgY29uc3QgZG9tYWluID0gbmljZURvbWFpbihyb3dzLm1hcCgocikgPT4gbnVtZXJpY0ZpZWxkKHIsIHlmKSkpO1xuICBjb25zdCB5ID0gbGluZWFyU2NhbGUoZG9tYWluLCBbTS50b3AgKyBQSCwgTS50b3BdKTtcbiAgY29uc3QgeTAgPSB5KE1hdGgubWF4KGRvbWFpblswXSwgMCkpO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxZQXhpcyBkb21haW49e2RvbWFpbn0gLz5cbiAgICAgIHtzZXJpZXMubWFwKChzLCBzaSkgPT4ge1xuICAgICAgICBjb25zdCBwdHMgPSBzLnJvd3NcbiAgICAgICAgICAubWFwKChyKSA9PiAoeyB4OiBweChsYWJlbEZpZWxkKHIsIHhmKSksIHk6IG51bWVyaWNGaWVsZChyLCB5ZikgfSkpXG4gICAgICAgICAgLmZpbHRlcigocCk6IHAgaXMgeyB4OiBudW1iZXI7IHk6IG51bWJlciB9ID0+IHAueSAhPT0gbnVsbClcbiAgICAgICAgICAubWFwKChwKSA9PiAoeyB4OiBwLngsIHk6IHkocC55KSB9KSk7XG4gICAgICAgIGlmIChwdHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgbGluZSA9IHB0cy5tYXAoKHAsIGkpID0+IGAke2kgPT09IDAgPyAnTScgOiAnTCd9ICR7cC54LnRvRml4ZWQoMSl9ICR7cC55LnRvRml4ZWQoMSl9YCkuam9pbignICcpO1xuICAgICAgICBjb25zdCBjb2xvciA9IHNlcmllc0NvbG9yKHNpKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZyBrZXk9e3NpfT5cbiAgICAgICAgICAgIHtlbmMua2luZCA9PT0gJ2FyZWEnICYmIChcbiAgICAgICAgICAgICAgPHBhdGggZD17YCR7bGluZX0gTCAke3B0c1twdHMubGVuZ3RoIC0gMV0ueC50b0ZpeGVkKDEpfSAke3kwLnRvRml4ZWQoMSl9IEwgJHtwdHNbMF0ueC50b0ZpeGVkKDEpfSAke3kwLnRvRml4ZWQoMSl9IFpgfSBmaWxsPXtjb2xvcn0gZmlsbE9wYWNpdHk9ezAuMTh9IC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPHBhdGggZD17bGluZX0gZmlsbD1cIm5vbmVcIiBzdHJva2U9e2NvbG9yfSBzdHJva2VXaWR0aD17Mn0gc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICAgICAgPC9nPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgICA8WENhdGVnb3J5TGFiZWxzIGNhdHM9e2NhdHN9IGJhbmQ9eyhpKSA9PiBNLmxlZnQgKyBiYW5kVyAqIGl9IGRlbnNpdHk9e2RlbnNpdHl9IC8+XG4gICAgICA8TGVnZW5kIG5hbWVzPXtzZXJpZXMubWFwKChzKSA9PiBzLm5hbWUpfSBkZW5zaXR5PXtkZW5zaXR5fSAvPlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBTY2F0dGVyKHsgcm93cywgZW5jLCBkZW5zaXR5IH06IHsgcm93czogUm93W107IGVuYzogQ2hhcnRFbmNvZGluZzsgZGVuc2l0eTogRGVuc2l0eSB9KSB7XG4gIGNvbnN0IHhmID0gZW5jLnggPz8gJ3gnO1xuICBjb25zdCB5ZiA9IGVuYy55ID8/ICd5JztcbiAgY29uc3Qgc2VyaWVzID0gc2VyaWVzQnlDb2xvcihyb3dzLCBlbmMuY29sb3IpO1xuICBjb25zdCB4ZCA9IG5pY2VEb21haW4ocm93cy5tYXAoKHIpID0+IG51bWVyaWNGaWVsZChyLCB4ZikpKTtcbiAgY29uc3QgeWQgPSBuaWNlRG9tYWluKHJvd3MubWFwKChyKSA9PiBudW1lcmljRmllbGQociwgeWYpKSk7XG4gIGNvbnN0IHggPSBsaW5lYXJTY2FsZSh4ZCwgW00ubGVmdCwgTS5sZWZ0ICsgUFddKTtcbiAgY29uc3QgeSA9IGxpbmVhclNjYWxlKHlkLCBbTS50b3AgKyBQSCwgTS50b3BdKTtcbiAgY29uc3Qgc2l6ZXMgPSBlbmMuc2l6ZSA/IHJvd3MubWFwKChyKSA9PiBudW1lcmljRmllbGQociwgZW5jLnNpemUhKSA/PyAwKSA6IFtdO1xuICBjb25zdCBzTWF4ID0gc2l6ZXMubGVuZ3RoID8gTWF0aC5tYXgoMSwgLi4uc2l6ZXMpIDogMTtcbiAgY29uc3QgcmFkaXVzID0gKHI6IFJvdyk6IG51bWJlciA9PiAoZW5jLnNpemUgPyAzICsgOSAqIE1hdGguc3FydChNYXRoLm1heCgwLCAobnVtZXJpY0ZpZWxkKHIsIGVuYy5zaXplKSA/PyAwKSAvIHNNYXgpKSA6IDQpO1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8WUF4aXMgZG9tYWluPXt5ZH0gLz5cbiAgICAgIHtzZXJpZXMubWFwKChzLCBzaSkgPT5cbiAgICAgICAgcy5yb3dzLm1hcCgociwgcmkpID0+IHtcbiAgICAgICAgICBjb25zdCB4diA9IG51bWVyaWNGaWVsZChyLCB4Zik7XG4gICAgICAgICAgY29uc3QgeXYgPSBudW1lcmljRmllbGQociwgeWYpO1xuICAgICAgICAgIGlmICh4diA9PT0gbnVsbCB8fCB5diA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gICAgICAgICAgcmV0dXJuIDxjaXJjbGUga2V5PXtgJHtzaX0tJHtyaX1gfSBjeD17eCh4dil9IGN5PXt5KHl2KX0gcj17cmFkaXVzKHIpfSBmaWxsPXtzZXJpZXNDb2xvcihzaSl9IGZpbGxPcGFjaXR5PXswLjd9IC8+O1xuICAgICAgICB9KSxcbiAgICAgICl9XG4gICAgICA8ZyBjbGFzc05hbWU9XCJyay1jaGFydC1heGlzXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgIHt0aWNrcyh4ZCwgZGVuc2l0eSA9PT0gJ25hcnJvdycgPyAyIDogNCkubWFwKCh0LCBpKSA9PiAoXG4gICAgICAgICAgPHRleHQga2V5PXtpfSB4PXt4KHQpfSB5PXtNLnRvcCArIFBIICsgMTh9IHRleHRBbmNob3I9XCJtaWRkbGVcIiBjbGFzc05hbWU9XCJyay1jaGFydC10aWNrXCI+XG4gICAgICAgICAgICB7dGlja0xhYmVsKHQpfVxuICAgICAgICAgIDwvdGV4dD5cbiAgICAgICAgKSl9XG4gICAgICA8L2c+XG4gICAgICA8TGVnZW5kIG5hbWVzPXtzZXJpZXMubWFwKChzKSA9PiBzLm5hbWUpfSBkZW5zaXR5PXtkZW5zaXR5fSAvPlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBIaXN0b2dyYW1DaGFydCh7IHJvd3MsIGVuYyB9OiB7IHJvd3M6IFJvd1tdOyBlbmM6IENoYXJ0RW5jb2RpbmcgfSkge1xuICBjb25zdCB2ZiA9IGVuYy52YWx1ZSA/PyAndmFsdWUnO1xuICBjb25zdCBiaW5zID0gaGlzdG9ncmFtKHJvd3MsIHZmLCBlbmMuYmlucyk7XG4gIGNvbnN0IGRvbWFpbiA9IG5pY2VEb21haW4oYmlucy5tYXAoKGIpID0+IGIuY291bnQpKTtcbiAgY29uc3QgeSA9IGxpbmVhclNjYWxlKGRvbWFpbiwgW00udG9wICsgUEgsIE0udG9wXSk7XG4gIGNvbnN0IHkwID0geSgwKTtcbiAgY29uc3QgYncgPSBQVyAvIE1hdGgubWF4KDEsIGJpbnMubGVuZ3RoKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFlBeGlzIGRvbWFpbj17ZG9tYWlufSAvPlxuICAgICAge2JpbnMubWFwKChiLCBpKSA9PiB7XG4gICAgICAgIGNvbnN0IHl2ID0geShiLmNvdW50KTtcbiAgICAgICAgcmV0dXJuIDxyZWN0IGtleT17aX0geD17TS5sZWZ0ICsgYncgKiBpICsgMX0geT17eXZ9IHdpZHRoPXtNYXRoLm1heCgwLCBidyAtIDIpfSBoZWlnaHQ9e01hdGgubWF4KDAsIHkwIC0geXYpfSBmaWxsPXtzZXJpZXNDb2xvcigwKX0gLz47XG4gICAgICB9KX1cbiAgICA8Lz5cbiAgKTtcbn1cblxuLy8gUHJlY29tcHV0ZSB3ZWRnZSBwYXRocyB3aXRob3V0IG11dGF0aW5nIHJlbmRlci1zY29wZSBzdGF0ZSAocmVhY3QtaG9va3MvaW1tdXRhYmlsaXR5KS4gRWFjaFxuLy8gZW50cnkgaXMgYSBmdWxsLWNpcmNsZSBmbGFnIChhIGxvbmUgc2xpY2Ug4omIIHRoZSB3aG9sZSBwaWUg4oCUIGEgc2luZ2xlIGBBYCBhcmMgZnJvbSBzdGFydCB0b1xuLy8gdGhlIGlkZW50aWNhbCBlbmQgcG9pbnQgaXMgZGVnZW5lcmF0ZSBhbmQgZHJhd3Mgbm90aGluZykgb3IgYSB3ZWRnZSBwYXRoIHN0cmluZy5cbnR5cGUgV2VkZ2UgPSB7IGZ1bGw6IHRydWUgfSB8IHsgZnVsbDogZmFsc2U7IGQ6IHN0cmluZyB9O1xuZnVuY3Rpb24gcGllQXJjcyhzbGljZXM6IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IG51bWJlciB9W10sIGN4OiBudW1iZXIsIGN5OiBudW1iZXIsIHI6IG51bWJlcik6IFdlZGdlW10ge1xuICBjb25zdCB0b3RhbCA9IHNsaWNlcy5yZWR1Y2UoKGFjYywgcykgPT4gYWNjICsgcy52YWx1ZSwgMCkgfHwgMTtcbiAgY29uc3Qgb3V0OiBXZWRnZVtdID0gW107XG4gIGxldCBhMCA9IC1NYXRoLlBJIC8gMjtcbiAgZm9yIChjb25zdCBzIG9mIHNsaWNlcykge1xuICAgIGNvbnN0IGZyYWMgPSBzLnZhbHVlIC8gdG90YWw7XG4gICAgaWYgKGZyYWMgPj0gMC45OTk5KSB7XG4gICAgICBvdXQucHVzaCh7IGZ1bGw6IHRydWUgfSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgYTEgPSBhMCArIGZyYWMgKiBNYXRoLlBJICogMjtcbiAgICBjb25zdCBsYXJnZSA9IGExIC0gYTAgPiBNYXRoLlBJID8gMSA6IDA7XG4gICAgY29uc3QgcDAgPSBbY3ggKyByICogTWF0aC5jb3MoYTApLCBjeSArIHIgKiBNYXRoLnNpbihhMCldO1xuICAgIGNvbnN0IHAxID0gW2N4ICsgciAqIE1hdGguY29zKGExKSwgY3kgKyByICogTWF0aC5zaW4oYTEpXTtcbiAgICBvdXQucHVzaCh7IGZ1bGw6IGZhbHNlLCBkOiBgTSAke2N4fSAke2N5fSBMICR7cDBbMF0udG9GaXhlZCgxKX0gJHtwMFsxXS50b0ZpeGVkKDEpfSBBICR7cn0gJHtyfSAwICR7bGFyZ2V9IDEgJHtwMVswXS50b0ZpeGVkKDEpfSAke3AxWzFdLnRvRml4ZWQoMSl9IFpgIH0pO1xuICAgIGEwID0gYTE7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gUGllQ2hhcnQoeyByb3dzLCBlbmMsIGRlbnNpdHkgfTogeyByb3dzOiBSb3dbXTsgZW5jOiBDaGFydEVuY29kaW5nOyBkZW5zaXR5OiBEZW5zaXR5IH0pIHtcbiAgY29uc3QgdmYgPSBlbmMudmFsdWUgPz8gJ3ZhbHVlJztcbiAgY29uc3QgbGYgPSBlbmMubGFiZWwgPz8gJ2xhYmVsJztcbiAgY29uc3Qgc2xpY2VzID0gcGllU2xpY2VzKHJvd3MsIHZmLCBsZik7XG4gIGNvbnN0IGN4ID0gTS5sZWZ0ICsgUFcgLyAyO1xuICBjb25zdCBjeSA9IE0udG9wICsgUEggLyAyO1xuICBjb25zdCByID0gTWF0aC5taW4oUFcsIFBIKSAvIDIgLSA2O1xuICBjb25zdCB3ZWRnZXMgPSBwaWVBcmNzKHNsaWNlcywgY3gsIGN5LCByKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGc+XG4gICAgICAgIHt3ZWRnZXMubWFwKCh3LCBpKSA9PlxuICAgICAgICAgIHcuZnVsbCA/IChcbiAgICAgICAgICAgIDxjaXJjbGUga2V5PXtpfSBjeD17Y3h9IGN5PXtjeX0gcj17cn0gZmlsbD17c2VyaWVzQ29sb3IoaSl9IHN0cm9rZT1cInZhcigtLXBhbmVsLCAjMTMxNDFkKVwiIHN0cm9rZVdpZHRoPXsxLjV9IC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwYXRoIGtleT17aX0gZD17dy5kfSBmaWxsPXtzZXJpZXNDb2xvcihpKX0gc3Ryb2tlPVwidmFyKC0tcGFuZWwsICMxMzE0MWQpXCIgc3Ryb2tlV2lkdGg9ezEuNX0gLz5cbiAgICAgICAgICApLFxuICAgICAgICApfVxuICAgICAgPC9nPlxuICAgICAgPExlZ2VuZCBuYW1lcz17c2xpY2VzLm1hcCgocykgPT4gcy5sYWJlbCl9IGRlbnNpdHk9e2RlbnNpdHl9IC8+XG4gICAgPC8+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENoYXJ0RmlndXJlKHsgcm93cywgZW5jLCBhcmlhTGFiZWwgfTogeyByb3dzOiBSb3dbXTsgZW5jOiBDaGFydEVuY29kaW5nOyBhcmlhTGFiZWw/OiBzdHJpbmcgfSkge1xuICBjb25zdCB7IHJlZiwgd2lkdGggfSA9IHVzZUNvbnRhaW5lcldpZHRoKFcpO1xuICBjb25zdCBkZW5zaXR5ID0gZGVuc2l0eUZvcih3aWR0aCk7XG4gIGNvbnN0IGxhYmVsID0gYXJpYUxhYmVsID8/IGAke2VuYy5raW5kfSBjaGFydGA7XG5cbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstY2hhcnQgcmstY2hhcnQtZW1wdHlcIiByZWY9e3JlZn0+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWJyb2tlbi1yZWFzb25cIj5ubyBkYXRhPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGxldCBib2R5OiBSZWFjdC5SZWFjdE5vZGU7XG4gIHN3aXRjaCAoZW5jLmtpbmQpIHtcbiAgICBjYXNlICdiYXInOlxuICAgICAgYm9keSA9IDxCYXJDaGFydCByb3dzPXtyb3dzfSBlbmM9e2VuY30gZGVuc2l0eT17ZGVuc2l0eX0gLz47XG4gICAgICBicmVhaztcbiAgICBjYXNlICdsaW5lJzpcbiAgICBjYXNlICdhcmVhJzpcbiAgICAgIGJvZHkgPSA8TGluZUFyZWEgcm93cz17cm93c30gZW5jPXtlbmN9IGRlbnNpdHk9e2RlbnNpdHl9IC8+O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnc2NhdHRlcic6XG4gICAgICBib2R5ID0gPFNjYXR0ZXIgcm93cz17cm93c30gZW5jPXtlbmN9IGRlbnNpdHk9e2RlbnNpdHl9IC8+O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnaGlzdG9ncmFtJzpcbiAgICAgIGJvZHkgPSA8SGlzdG9ncmFtQ2hhcnQgcm93cz17cm93c30gZW5jPXtlbmN9IC8+O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncGllJzpcbiAgICAgIGJvZHkgPSA8UGllQ2hhcnQgcm93cz17cm93c30gZW5jPXtlbmN9IGRlbnNpdHk9e2RlbnNpdHl9IC8+O1xuICAgICAgYnJlYWs7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmstY2hhcnRcIiByZWY9e3JlZn0+XG4gICAgICA8c3ZnIHZpZXdCb3g9e2AwIDAgJHtXfSAke0h9YH0gcHJlc2VydmVBc3BlY3RSYXRpbz1cInhNaWRZTWlkIG1lZXRcIiBjbGFzc05hbWU9XCJyay1jaGFydC1zdmdcIiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17bGFiZWx9PlxuICAgICAgICB7Ym9keX1cbiAgICAgIDwvc3ZnPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFVQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxrQkFBQSxHQUFBSixPQUFBO0FBQXdFLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLElBQUFNLEdBQUEsR0FBQUMsWUFBQSxJQWR4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBU0EsTUFBTUMsQ0FBQyxHQUFHLEdBQUc7QUFDYixNQUFNQyxDQUFDLEdBQUcsR0FBRztBQUNiLE1BQU1DLENBQUMsR0FBRztFQUFFQyxHQUFHLEVBQUUsRUFBRTtFQUFFQyxLQUFLLEVBQUUsRUFBRTtFQUFFQyxNQUFNLEVBQUUsRUFBRTtFQUFFQyxJQUFJLEVBQUU7QUFBRyxDQUFDO0FBQ3RELE1BQU1DLEVBQUUsR0FBR1AsQ0FBQyxHQUFHRSxDQUFDLENBQUNJLElBQUksR0FBR0osQ0FBQyxDQUFDRSxLQUFLO0FBQy9CLE1BQU1JLEVBQUUsR0FBR1AsQ0FBQyxHQUFHQyxDQUFDLENBQUNDLEdBQUcsR0FBR0QsQ0FBQyxDQUFDRyxNQUFNO0FBSS9CLFNBQVNJLFNBQVNBLENBQUNDLENBQVMsRUFBVTtFQUNwQyxNQUFNQyxDQUFDLEdBQUdDLElBQUksQ0FBQ0MsR0FBRyxDQUFDSCxDQUFDLENBQUM7RUFDckIsSUFBSUMsQ0FBQyxJQUFJLFNBQVMsRUFBRSxPQUFPLEdBQUcsQ0FBQ0QsQ0FBQyxHQUFHLFNBQVMsRUFBRUksT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHO0VBQzNELElBQUlILENBQUMsSUFBSSxLQUFLLEVBQUUsT0FBTyxHQUFHLENBQUNELENBQUMsR0FBRyxLQUFLLEVBQUVJLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRztFQUNuRCxPQUFPLElBQUFDLG9CQUFZLEVBQUNMLENBQUMsQ0FBQztBQUN4Qjs7QUFFQTtBQUNBLFNBQVNNLEtBQUtBLENBQUM7RUFBRUM7QUFBcUMsQ0FBQyxFQUFFO0VBQ3ZELE1BQU1DLENBQUMsR0FBRyxJQUFBQyxzQkFBVyxFQUFDRixNQUFNLEVBQUUsQ0FBQ2YsQ0FBQyxDQUFDQyxHQUFHLEdBQUdLLEVBQUUsRUFBRU4sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQztFQUNsRCxvQkFDRSxJQUFBTixXQUFBLENBQUF1QixHQUFBO0lBQUdDLFNBQVMsRUFBQyxlQUFlO0lBQUMsZUFBWSxNQUFNO0lBQUFDLFFBQUEsRUFDNUMsSUFBQUMsZ0JBQUssRUFBQ04sTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDTyxHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLGtCQUN6QixJQUFBN0IsV0FBQSxDQUFBOEIsSUFBQTtNQUFBTCxRQUFBLGdCQUNFLElBQUF6QixXQUFBLENBQUF1QixHQUFBO1FBQU1RLEVBQUUsRUFBRTFCLENBQUMsQ0FBQ0ksSUFBSztRQUFDdUIsRUFBRSxFQUFFM0IsQ0FBQyxDQUFDSSxJQUFJLEdBQUdDLEVBQUc7UUFBQ3VCLEVBQUUsRUFBRVosQ0FBQyxDQUFDTyxDQUFDLENBQUU7UUFBQ00sRUFBRSxFQUFFYixDQUFDLENBQUNPLENBQUMsQ0FBRTtRQUFDSixTQUFTLEVBQUM7TUFBZSxDQUFFLENBQUMsZUFDbkYsSUFBQXhCLFdBQUEsQ0FBQXVCLEdBQUE7UUFBTVksQ0FBQyxFQUFFOUIsQ0FBQyxDQUFDSSxJQUFJLEdBQUcsQ0FBRTtRQUFDWSxDQUFDLEVBQUVBLENBQUMsQ0FBQ08sQ0FBQyxDQUFFO1FBQUNRLEVBQUUsRUFBQyxRQUFRO1FBQUNDLFVBQVUsRUFBQyxLQUFLO1FBQUNiLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsRUFDakZiLFNBQVMsQ0FBQ2dCLENBQUM7TUFBQyxDQUNULENBQUM7SUFBQSxHQUpEQyxDQUtMLENBQ0o7RUFBQyxDQUNELENBQUM7QUFFUjtBQUFDUyxFQUFBLEdBZFFuQixLQUFLO0FBZ0JkLFNBQVNvQixlQUFlQSxDQUFDO0VBQUVDLElBQUk7RUFBRUMsSUFBSTtFQUFFQztBQUEyRSxDQUFDLEVBQUU7RUFDbkgsTUFBTUMsTUFBTSxHQUFHRCxPQUFPLEtBQUssUUFBUSxHQUFHM0IsSUFBSSxDQUFDNkIsSUFBSSxDQUFDSixJQUFJLENBQUNLLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBR0gsT0FBTyxLQUFLLFFBQVEsR0FBRzNCLElBQUksQ0FBQzZCLElBQUksQ0FBQ0osSUFBSSxDQUFDSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztFQUN4SCxvQkFDRSxJQUFBN0MsV0FBQSxDQUFBdUIsR0FBQTtJQUFHQyxTQUFTLEVBQUMsZUFBZTtJQUFDLGVBQVksTUFBTTtJQUFBQyxRQUFBLEVBQzVDZSxJQUFJLENBQUNiLEdBQUcsQ0FBQyxDQUFDbUIsQ0FBQyxFQUFFakIsQ0FBQyxLQUNiQSxDQUFDLEdBQUdjLE1BQU0sS0FBSyxDQUFDLGdCQUNkLElBQUEzQyxXQUFBLENBQUF1QixHQUFBO01BQWNZLENBQUMsRUFBRU0sSUFBSSxDQUFDWixDQUFDLENBQUU7TUFBQ1IsQ0FBQyxFQUFFaEIsQ0FBQyxDQUFDQyxHQUFHLEdBQUdLLEVBQUUsR0FBRyxFQUFHO01BQUMwQixVQUFVLEVBQUMsUUFBUTtNQUFDYixTQUFTLEVBQUMsZUFBZTtNQUFBQyxRQUFBLEVBQ3hGcUIsQ0FBQyxDQUFDRCxNQUFNLEdBQUcsRUFBRSxHQUFHLEdBQUdDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHRDtJQUFDLEdBRC9CakIsQ0FFTCxDQUFDLEdBQ0wsSUFDTjtFQUFDLENBQ0EsQ0FBQztBQUVSO0FBQUNtQixHQUFBLEdBYlFULGVBQWU7QUFleEIsU0FBU1UsTUFBTUEsQ0FBQztFQUFFQyxLQUFLO0VBQUVSO0FBQStDLENBQUMsRUFBRTtFQUN6RSxJQUFJQSxPQUFPLEtBQUssUUFBUSxJQUFJUSxLQUFLLENBQUNMLE1BQU0sSUFBSSxDQUFDLElBQUlLLEtBQUssQ0FBQ0MsS0FBSyxDQUFFdEMsQ0FBQyxJQUFLQSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQzFGLG9CQUNFLElBQUFiLFdBQUEsQ0FBQXVCLEdBQUE7SUFBR0MsU0FBUyxFQUFDLGlCQUFpQjtJQUFBQyxRQUFBLEVBQzNCeUIsS0FBSyxDQUFDdkIsR0FBRyxDQUFDLENBQUNkLENBQUMsRUFBRWdCLENBQUMsa0JBQ2QsSUFBQTdCLFdBQUEsQ0FBQThCLElBQUE7TUFBV3NCLFNBQVMsRUFBRSxhQUFhL0MsQ0FBQyxDQUFDSSxJQUFJLEdBQUdvQixDQUFDLEdBQUcsR0FBRyxLQUFLekIsQ0FBQyxHQUFHLENBQUMsR0FBSTtNQUFBcUIsUUFBQSxnQkFDL0QsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUE7UUFBTThCLEtBQUssRUFBRSxFQUFHO1FBQUNDLE1BQU0sRUFBRSxFQUFHO1FBQUNqQyxDQUFDLEVBQUUsQ0FBQyxFQUFHO1FBQUNrQyxFQUFFLEVBQUUsQ0FBRTtRQUFDQyxJQUFJLEVBQUUsSUFBQUMsb0JBQVcsRUFBQzVCLENBQUM7TUFBRSxDQUFFLENBQUMsZUFDcEUsSUFBQTdCLFdBQUEsQ0FBQXVCLEdBQUE7UUFBTVksQ0FBQyxFQUFFLEVBQUc7UUFBQ1gsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxFQUNuQ1osQ0FBQyxDQUFDZ0MsTUFBTSxHQUFHLEVBQUUsR0FBRyxHQUFHaEMsQ0FBQyxDQUFDa0MsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHbEM7TUFBQyxDQUNyQyxDQUFDO0lBQUEsR0FKRGdCLENBS0wsQ0FDSjtFQUFDLENBQ0QsQ0FBQztBQUVSO0FBQUM2QixHQUFBLEdBZFFULE1BQU07QUFnQmYsU0FBU1UsUUFBUUEsQ0FBQztFQUFFQyxJQUFJO0VBQUVDLEdBQUc7RUFBRW5CO0FBQStELENBQUMsRUFBRTtFQUMvRixNQUFNb0IsRUFBRSxHQUFHRCxHQUFHLENBQUMxQixDQUFDLElBQUksR0FBRztFQUN2QixNQUFNNEIsRUFBRSxHQUFHRixHQUFHLENBQUN4QyxDQUFDLElBQUksR0FBRztFQUN2QixNQUFNbUIsSUFBSSxHQUFHLElBQUF3QixxQkFBVSxFQUFDSixJQUFJLEVBQUVFLEVBQUUsQ0FBQztFQUNqQyxNQUFNRyxNQUFNLEdBQUcsSUFBQUMsd0JBQWEsRUFBQ04sSUFBSSxFQUFFQyxHQUFHLENBQUNNLEtBQUssQ0FBQztFQUM3QyxNQUFNQyxLQUFLLEdBQUcxRCxFQUFFLEdBQUdLLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEVBQUU3QixJQUFJLENBQUNLLE1BQU0sQ0FBQztFQUMzQyxNQUFNeUIsS0FBSyxHQUFJekMsQ0FBUyxJQUFheEIsQ0FBQyxDQUFDSSxJQUFJLEdBQUcyRCxLQUFLLEdBQUd2QyxDQUFDLEdBQUd1QyxLQUFLLEdBQUcsQ0FBQzs7RUFFbkU7RUFDQSxNQUFNRyxFQUFFLEdBQUdBLENBQUNDLEVBQVUsRUFBRUMsRUFBVSxLQUFhO0lBQzdDLE1BQU1DLEdBQUcsR0FBR2xDLElBQUksQ0FBQ2lDLEVBQUUsQ0FBQztJQUNwQixNQUFNRSxDQUFDLEdBQUdWLE1BQU0sQ0FBQ08sRUFBRSxDQUFDLENBQUNaLElBQUksQ0FBQ2dCLElBQUksQ0FBRUMsR0FBRyxJQUFLLElBQUFDLGlCQUFVLEVBQUNELEdBQUcsRUFBRWYsRUFBRSxDQUFDLEtBQUtZLEdBQUcsQ0FBQztJQUNwRSxPQUFPQyxDQUFDLEdBQUcsSUFBQUksbUJBQVksRUFBQ0osQ0FBQyxFQUFFWixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUN6QyxDQUFDO0VBRUQsSUFBSUYsR0FBRyxDQUFDbUIsS0FBSyxLQUFLLE1BQU0sRUFBRTtJQUN4QixNQUFNQyxLQUFLLEdBQUdiLEtBQUssR0FBRyxHQUFHO0lBQ3pCLE1BQU1jLEVBQUUsR0FBR0QsS0FBSyxHQUFHaEIsTUFBTSxDQUFDcEIsTUFBTTtJQUNoQyxNQUFNekIsTUFBTSxHQUFHLElBQUErRCxxQkFBVSxFQUFDdkIsSUFBSSxDQUFDakMsR0FBRyxDQUFFZ0QsQ0FBQyxJQUFLLElBQUFJLG1CQUFZLEVBQUNKLENBQUMsRUFBRVosRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMvRCxNQUFNMUMsQ0FBQyxHQUFHLElBQUFDLHNCQUFXLEVBQUNGLE1BQU0sRUFBRSxDQUFDZixDQUFDLENBQUNDLEdBQUcsR0FBR0ssRUFBRSxFQUFFTixDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xELE1BQU04RSxFQUFFLEdBQUcvRCxDQUFDLENBQUNOLElBQUksQ0FBQ3NELEdBQUcsQ0FBQ2pELE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNwQyxvQkFDRSxJQUFBcEIsV0FBQSxDQUFBOEIsSUFBQSxFQUFBOUIsV0FBQSxDQUFBcUYsUUFBQTtNQUFBNUQsUUFBQSxnQkFDRSxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDSixLQUFLO1FBQUNDLE1BQU0sRUFBRUE7TUFBTyxDQUFFLENBQUMsRUFDeEI2QyxNQUFNLENBQUN0QyxHQUFHLENBQUMsQ0FBQzJELEVBQUUsRUFBRWQsRUFBRSxLQUNqQmhDLElBQUksQ0FBQ2IsR0FBRyxDQUFDLENBQUM0RCxDQUFDLEVBQUVkLEVBQUUsS0FBSztRQUNsQixNQUFNZSxDQUFDLEdBQUdqQixFQUFFLENBQUNDLEVBQUUsRUFBRUMsRUFBRSxDQUFDO1FBQ3BCLE1BQU1nQixFQUFFLEdBQUdwRSxDQUFDLENBQUNtRSxDQUFDLENBQUM7UUFDZixNQUFNckQsQ0FBQyxHQUFHOUIsQ0FBQyxDQUFDSSxJQUFJLEdBQUcyRCxLQUFLLEdBQUdLLEVBQUUsR0FBRyxDQUFDTCxLQUFLLEdBQUdhLEtBQUssSUFBSSxDQUFDLEdBQUdDLEVBQUUsR0FBR1YsRUFBRTtRQUM3RCxvQkFBTyxJQUFBeEUsV0FBQSxDQUFBdUIsR0FBQTtVQUEwQlksQ0FBQyxFQUFFQSxDQUFFO1VBQUNkLENBQUMsRUFBRU4sSUFBSSxDQUFDMkUsR0FBRyxDQUFDRCxFQUFFLEVBQUVMLEVBQUUsQ0FBRTtVQUFDL0IsS0FBSyxFQUFFdEMsSUFBSSxDQUFDc0QsR0FBRyxDQUFDLENBQUMsRUFBRWEsRUFBRSxHQUFHLENBQUMsQ0FBRTtVQUFDNUIsTUFBTSxFQUFFdkMsSUFBSSxDQUFDQyxHQUFHLENBQUN5RSxFQUFFLEdBQUdMLEVBQUUsQ0FBRTtVQUFDNUIsSUFBSSxFQUFFLElBQUFDLG9CQUFXLEVBQUNlLEVBQUU7UUFBRSxHQUF2SCxHQUFHQSxFQUFFLElBQUlDLEVBQUUsRUFBOEcsQ0FBQztNQUM5SSxDQUFDLENBQ0gsQ0FBQyxlQUNELElBQUF6RSxXQUFBLENBQUF1QixHQUFBLEVBQUNnQixlQUFlO1FBQUNDLElBQUksRUFBRUEsSUFBSztRQUFDQyxJQUFJLEVBQUU2QixLQUFNO1FBQUM1QixPQUFPLEVBQUVBO01BQVEsQ0FBRSxDQUFDLGVBQzlELElBQUExQyxXQUFBLENBQUF1QixHQUFBLEVBQUMwQixNQUFNO1FBQUNDLEtBQUssRUFBRWUsTUFBTSxDQUFDdEMsR0FBRyxDQUFFZ0UsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBRTtRQUFDbEQsT0FBTyxFQUFFQTtNQUFRLENBQUUsQ0FBQztJQUFBLENBQzlELENBQUM7RUFFUDs7RUFFQTtFQUNBLE1BQU1tRCxNQUFNLEdBQUdyRCxJQUFJLENBQUNiLEdBQUcsQ0FBQyxDQUFDNEQsQ0FBQyxFQUFFZCxFQUFFLEtBQUtSLE1BQU0sQ0FBQzZCLE1BQU0sQ0FBQyxDQUFDQyxHQUFHLEVBQUVULEVBQUUsRUFBRWQsRUFBRSxLQUFLdUIsR0FBRyxHQUFHaEYsSUFBSSxDQUFDc0QsR0FBRyxDQUFDLENBQUMsRUFBRUUsRUFBRSxDQUFDQyxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDcEcsTUFBTXJELE1BQXdCLEdBQUd5QyxHQUFHLENBQUNtQixLQUFLLEtBQUssWUFBWSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFakUsSUFBSSxDQUFDc0QsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHd0IsTUFBTSxDQUFDLENBQUM7RUFDbEcsTUFBTXhFLENBQUMsR0FBRyxJQUFBQyxzQkFBVyxFQUFDRixNQUFNLEVBQUUsQ0FBQ2YsQ0FBQyxDQUFDQyxHQUFHLEdBQUdLLEVBQUUsRUFBRU4sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQztFQUNsRCxNQUFNMEYsSUFBSSxHQUFHNUIsS0FBSyxHQUFHLEdBQUc7RUFDeEIsb0JBQ0UsSUFBQXBFLFdBQUEsQ0FBQThCLElBQUEsRUFBQTlCLFdBQUEsQ0FBQXFGLFFBQUE7SUFBQTVELFFBQUEsZ0JBQ0UsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ0osS0FBSztNQUFDQyxNQUFNLEVBQUVBO0lBQU8sQ0FBRSxDQUFDLEVBQ3hCb0IsSUFBSSxDQUFDYixHQUFHLENBQUMsQ0FBQzRELENBQUMsRUFBRWQsRUFBRSxLQUFLO01BQ25CLElBQUlzQixHQUFHLEdBQUcsQ0FBQztNQUNYLE1BQU1FLEtBQUssR0FBR3BDLEdBQUcsQ0FBQ21CLEtBQUssS0FBSyxZQUFZLEdBQUdhLE1BQU0sQ0FBQ3BCLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO01BQzlELE9BQU9SLE1BQU0sQ0FBQ3RDLEdBQUcsQ0FBQyxDQUFDMkQsRUFBRSxFQUFFZCxFQUFFLEtBQUs7UUFDNUIsTUFBTTBCLEdBQUcsR0FBR25GLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEVBQUVFLEVBQUUsQ0FBQ0MsRUFBRSxFQUFFQyxFQUFFLENBQUMsQ0FBQztRQUNuQyxNQUFNZSxDQUFDLEdBQUczQixHQUFHLENBQUNtQixLQUFLLEtBQUssWUFBWSxHQUFHa0IsR0FBRyxHQUFHRCxLQUFLLEdBQUdDLEdBQUc7UUFDeEQsTUFBTUMsSUFBSSxHQUFHOUUsQ0FBQyxDQUFDMEUsR0FBRyxHQUFHUCxDQUFDLENBQUM7UUFDdkIsTUFBTVksSUFBSSxHQUFHL0UsQ0FBQyxDQUFDMEUsR0FBRyxDQUFDO1FBQ25CQSxHQUFHLElBQUlQLENBQUM7UUFDUixNQUFNckQsQ0FBQyxHQUFHOUIsQ0FBQyxDQUFDSSxJQUFJLEdBQUcyRCxLQUFLLEdBQUdLLEVBQUUsR0FBRyxDQUFDTCxLQUFLLEdBQUc0QixJQUFJLElBQUksQ0FBQztRQUNsRCxvQkFBTyxJQUFBaEcsV0FBQSxDQUFBdUIsR0FBQTtVQUEwQlksQ0FBQyxFQUFFQSxDQUFFO1VBQUNkLENBQUMsRUFBRThFLElBQUs7VUFBQzlDLEtBQUssRUFBRTJDLElBQUs7VUFBQzFDLE1BQU0sRUFBRXZDLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEVBQUUrQixJQUFJLEdBQUdELElBQUksQ0FBRTtVQUFDM0MsSUFBSSxFQUFFLElBQUFDLG9CQUFXLEVBQUNlLEVBQUU7UUFBRSxHQUFuRyxHQUFHQSxFQUFFLElBQUlDLEVBQUUsRUFBMEYsQ0FBQztNQUMxSCxDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsZUFDRixJQUFBekUsV0FBQSxDQUFBdUIsR0FBQSxFQUFDZ0IsZUFBZTtNQUFDQyxJQUFJLEVBQUVBLElBQUs7TUFBQ0MsSUFBSSxFQUFFNkIsS0FBTTtNQUFDNUIsT0FBTyxFQUFFQTtJQUFRLENBQUUsQ0FBQyxlQUM5RCxJQUFBMUMsV0FBQSxDQUFBdUIsR0FBQSxFQUFDMEIsTUFBTTtNQUFDQyxLQUFLLEVBQUVlLE1BQU0sQ0FBQ3RDLEdBQUcsQ0FBRWdFLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLENBQUU7TUFBQ2xELE9BQU8sRUFBRUE7SUFBUSxDQUFFLENBQUM7RUFBQSxDQUM5RCxDQUFDO0FBRVA7QUFBQzJELEdBQUEsR0EvRFExQyxRQUFRO0FBaUVqQixTQUFTMkMsUUFBUUEsQ0FBQztFQUFFMUMsSUFBSTtFQUFFQyxHQUFHO0VBQUVuQjtBQUErRCxDQUFDLEVBQUU7RUFDL0YsTUFBTW9CLEVBQUUsR0FBR0QsR0FBRyxDQUFDMUIsQ0FBQyxJQUFJLEdBQUc7RUFDdkIsTUFBTTRCLEVBQUUsR0FBR0YsR0FBRyxDQUFDeEMsQ0FBQyxJQUFJLEdBQUc7RUFDdkIsTUFBTW1CLElBQUksR0FBRyxJQUFBd0IscUJBQVUsRUFBQ0osSUFBSSxFQUFFRSxFQUFFLENBQUM7RUFDakMsTUFBTUcsTUFBTSxHQUFHLElBQUFDLHdCQUFhLEVBQUNOLElBQUksRUFBRUMsR0FBRyxDQUFDTSxLQUFLLENBQUM7RUFDN0MsTUFBTUMsS0FBSyxHQUFHMUQsRUFBRSxHQUFHSyxJQUFJLENBQUNzRCxHQUFHLENBQUMsQ0FBQyxFQUFFN0IsSUFBSSxDQUFDSyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNwRCxNQUFNMEQsRUFBRSxHQUFJN0IsR0FBVyxJQUFhckUsQ0FBQyxDQUFDSSxJQUFJLEdBQUcyRCxLQUFLLEdBQUdyRCxJQUFJLENBQUNzRCxHQUFHLENBQUMsQ0FBQyxFQUFFN0IsSUFBSSxDQUFDZ0UsT0FBTyxDQUFDOUIsR0FBRyxDQUFDLENBQUM7RUFDbkYsTUFBTXRELE1BQU0sR0FBRyxJQUFBK0QscUJBQVUsRUFBQ3ZCLElBQUksQ0FBQ2pDLEdBQUcsQ0FBRWdELENBQUMsSUFBSyxJQUFBSSxtQkFBWSxFQUFDSixDQUFDLEVBQUVaLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDL0QsTUFBTTFDLENBQUMsR0FBRyxJQUFBQyxzQkFBVyxFQUFDRixNQUFNLEVBQUUsQ0FBQ2YsQ0FBQyxDQUFDQyxHQUFHLEdBQUdLLEVBQUUsRUFBRU4sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQztFQUNsRCxNQUFNOEUsRUFBRSxHQUFHL0QsQ0FBQyxDQUFDTixJQUFJLENBQUNzRCxHQUFHLENBQUNqRCxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFFcEMsb0JBQ0UsSUFBQXBCLFdBQUEsQ0FBQThCLElBQUEsRUFBQTlCLFdBQUEsQ0FBQXFGLFFBQUE7SUFBQTVELFFBQUEsZ0JBQ0UsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ0osS0FBSztNQUFDQyxNQUFNLEVBQUVBO0lBQU8sQ0FBRSxDQUFDLEVBQ3hCNkMsTUFBTSxDQUFDdEMsR0FBRyxDQUFDLENBQUNnRSxDQUFDLEVBQUVuQixFQUFFLEtBQUs7TUFDckIsTUFBTWlDLEdBQUcsR0FBR2QsQ0FBQyxDQUFDL0IsSUFBSSxDQUNmakMsR0FBRyxDQUFFZ0QsQ0FBQyxLQUFNO1FBQUV4QyxDQUFDLEVBQUVvRSxFQUFFLENBQUMsSUFBQXpCLGlCQUFVLEVBQUNILENBQUMsRUFBRWIsRUFBRSxDQUFDLENBQUM7UUFBRXpDLENBQUMsRUFBRSxJQUFBMEQsbUJBQVksRUFBQ0osQ0FBQyxFQUFFWixFQUFFO01BQUUsQ0FBQyxDQUFDLENBQUMsQ0FDbEUyQyxNQUFNLENBQUVDLENBQUMsSUFBb0NBLENBQUMsQ0FBQ3RGLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FDMURNLEdBQUcsQ0FBRWdGLENBQUMsS0FBTTtRQUFFeEUsQ0FBQyxFQUFFd0UsQ0FBQyxDQUFDeEUsQ0FBQztRQUFFZCxDQUFDLEVBQUVBLENBQUMsQ0FBQ3NGLENBQUMsQ0FBQ3RGLENBQUM7TUFBRSxDQUFDLENBQUMsQ0FBQztNQUN0QyxJQUFJb0YsR0FBRyxDQUFDNUQsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLElBQUk7TUFDakMsTUFBTStELElBQUksR0FBR0gsR0FBRyxDQUFDOUUsR0FBRyxDQUFDLENBQUNnRixDQUFDLEVBQUU5RSxDQUFDLEtBQUssR0FBR0EsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJOEUsQ0FBQyxDQUFDeEUsQ0FBQyxDQUFDbEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJMEYsQ0FBQyxDQUFDdEYsQ0FBQyxDQUFDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDNEYsSUFBSSxDQUFDLEdBQUcsQ0FBQztNQUN0RyxNQUFNMUMsS0FBSyxHQUFHLElBQUFWLG9CQUFXLEVBQUNlLEVBQUUsQ0FBQztNQUM3QixvQkFDRSxJQUFBeEUsV0FBQSxDQUFBOEIsSUFBQTtRQUFBTCxRQUFBLEdBQ0dvQyxHQUFHLENBQUNpRCxJQUFJLEtBQUssTUFBTSxpQkFDbEIsSUFBQTlHLFdBQUEsQ0FBQXVCLEdBQUE7VUFBTXdGLENBQUMsRUFBRSxHQUFHSCxJQUFJLE1BQU1ILEdBQUcsQ0FBQ0EsR0FBRyxDQUFDNUQsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDVixDQUFDLENBQUNsQixPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUltRSxFQUFFLENBQUNuRSxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU13RixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUN0RSxDQUFDLENBQUNsQixPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUltRSxFQUFFLENBQUNuRSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUs7VUFBQ3VDLElBQUksRUFBRVcsS0FBTTtVQUFDNkMsV0FBVyxFQUFFO1FBQUssQ0FBRSxDQUN6SixlQUNELElBQUFoSCxXQUFBLENBQUF1QixHQUFBO1VBQU13RixDQUFDLEVBQUVILElBQUs7VUFBQ3BELElBQUksRUFBQyxNQUFNO1VBQUN5RCxNQUFNLEVBQUU5QyxLQUFNO1VBQUMrQyxXQUFXLEVBQUUsQ0FBRTtVQUFDQyxjQUFjLEVBQUMsT0FBTztVQUFDQyxhQUFhLEVBQUM7UUFBTyxDQUFFLENBQUM7TUFBQSxHQUpuRzVDLEVBS0wsQ0FBQztJQUVSLENBQUMsQ0FBQyxlQUNGLElBQUF4RSxXQUFBLENBQUF1QixHQUFBLEVBQUNnQixlQUFlO01BQUNDLElBQUksRUFBRUEsSUFBSztNQUFDQyxJQUFJLEVBQUdaLENBQUMsSUFBS3hCLENBQUMsQ0FBQ0ksSUFBSSxHQUFHMkQsS0FBSyxHQUFHdkMsQ0FBRTtNQUFDYSxPQUFPLEVBQUVBO0lBQVEsQ0FBRSxDQUFDLGVBQ2xGLElBQUExQyxXQUFBLENBQUF1QixHQUFBLEVBQUMwQixNQUFNO01BQUNDLEtBQUssRUFBRWUsTUFBTSxDQUFDdEMsR0FBRyxDQUFFZ0UsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBRTtNQUFDbEQsT0FBTyxFQUFFQTtJQUFRLENBQUUsQ0FBQztFQUFBLENBQzlELENBQUM7QUFFUDtBQUFDMkUsR0FBQSxHQW5DUWYsUUFBUTtBQXFDakIsU0FBU2dCLE9BQU9BLENBQUM7RUFBRTFELElBQUk7RUFBRUMsR0FBRztFQUFFbkI7QUFBK0QsQ0FBQyxFQUFFO0VBQzlGLE1BQU1vQixFQUFFLEdBQUdELEdBQUcsQ0FBQzFCLENBQUMsSUFBSSxHQUFHO0VBQ3ZCLE1BQU00QixFQUFFLEdBQUdGLEdBQUcsQ0FBQ3hDLENBQUMsSUFBSSxHQUFHO0VBQ3ZCLE1BQU00QyxNQUFNLEdBQUcsSUFBQUMsd0JBQWEsRUFBQ04sSUFBSSxFQUFFQyxHQUFHLENBQUNNLEtBQUssQ0FBQztFQUM3QyxNQUFNb0QsRUFBRSxHQUFHLElBQUFwQyxxQkFBVSxFQUFDdkIsSUFBSSxDQUFDakMsR0FBRyxDQUFFZ0QsQ0FBQyxJQUFLLElBQUFJLG1CQUFZLEVBQUNKLENBQUMsRUFBRWIsRUFBRSxDQUFDLENBQUMsQ0FBQztFQUMzRCxNQUFNMEQsRUFBRSxHQUFHLElBQUFyQyxxQkFBVSxFQUFDdkIsSUFBSSxDQUFDakMsR0FBRyxDQUFFZ0QsQ0FBQyxJQUFLLElBQUFJLG1CQUFZLEVBQUNKLENBQUMsRUFBRVosRUFBRSxDQUFDLENBQUMsQ0FBQztFQUMzRCxNQUFNNUIsQ0FBQyxHQUFHLElBQUFiLHNCQUFXLEVBQUNpRyxFQUFFLEVBQUUsQ0FBQ2xILENBQUMsQ0FBQ0ksSUFBSSxFQUFFSixDQUFDLENBQUNJLElBQUksR0FBR0MsRUFBRSxDQUFDLENBQUM7RUFDaEQsTUFBTVcsQ0FBQyxHQUFHLElBQUFDLHNCQUFXLEVBQUNrRyxFQUFFLEVBQUUsQ0FBQ25ILENBQUMsQ0FBQ0MsR0FBRyxHQUFHSyxFQUFFLEVBQUVOLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLENBQUM7RUFDOUMsTUFBTW1ILEtBQUssR0FBRzVELEdBQUcsQ0FBQzZELElBQUksR0FBRzlELElBQUksQ0FBQ2pDLEdBQUcsQ0FBRWdELENBQUMsSUFBSyxJQUFBSSxtQkFBWSxFQUFDSixDQUFDLEVBQUVkLEdBQUcsQ0FBQzZELElBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7RUFDOUUsTUFBTUMsSUFBSSxHQUFHRixLQUFLLENBQUM1RSxNQUFNLEdBQUc5QixJQUFJLENBQUNzRCxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUdvRCxLQUFLLENBQUMsR0FBRyxDQUFDO0VBQ3JELE1BQU1HLE1BQU0sR0FBSWpELENBQU0sSUFBY2QsR0FBRyxDQUFDNkQsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUczRyxJQUFJLENBQUM4RyxJQUFJLENBQUM5RyxJQUFJLENBQUNzRCxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBQVUsbUJBQVksRUFBQ0osQ0FBQyxFQUFFZCxHQUFHLENBQUM2RCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUlDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBRTtFQUMzSCxvQkFDRSxJQUFBM0gsV0FBQSxDQUFBOEIsSUFBQSxFQUFBOUIsV0FBQSxDQUFBcUYsUUFBQTtJQUFBNUQsUUFBQSxnQkFDRSxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDSixLQUFLO01BQUNDLE1BQU0sRUFBRW9HO0lBQUcsQ0FBRSxDQUFDLEVBQ3BCdkQsTUFBTSxDQUFDdEMsR0FBRyxDQUFDLENBQUNnRSxDQUFDLEVBQUVuQixFQUFFLEtBQ2hCbUIsQ0FBQyxDQUFDL0IsSUFBSSxDQUFDakMsR0FBRyxDQUFDLENBQUNnRCxDQUFDLEVBQUVtRCxFQUFFLEtBQUs7TUFDcEIsTUFBTUMsRUFBRSxHQUFHLElBQUFoRCxtQkFBWSxFQUFDSixDQUFDLEVBQUViLEVBQUUsQ0FBQztNQUM5QixNQUFNMkIsRUFBRSxHQUFHLElBQUFWLG1CQUFZLEVBQUNKLENBQUMsRUFBRVosRUFBRSxDQUFDO01BQzlCLElBQUlnRSxFQUFFLEtBQUssSUFBSSxJQUFJdEMsRUFBRSxLQUFLLElBQUksRUFBRSxPQUFPLElBQUk7TUFDM0Msb0JBQU8sSUFBQXpGLFdBQUEsQ0FBQXVCLEdBQUE7UUFBNEJ5RyxFQUFFLEVBQUU3RixDQUFDLENBQUM0RixFQUFFLENBQUU7UUFBQ0UsRUFBRSxFQUFFNUcsQ0FBQyxDQUFDb0UsRUFBRSxDQUFFO1FBQUNkLENBQUMsRUFBRWlELE1BQU0sQ0FBQ2pELENBQUMsQ0FBRTtRQUFDbkIsSUFBSSxFQUFFLElBQUFDLG9CQUFXLEVBQUNlLEVBQUUsQ0FBRTtRQUFDd0MsV0FBVyxFQUFFO01BQUksR0FBM0YsR0FBR3hDLEVBQUUsSUFBSXNELEVBQUUsRUFBa0YsQ0FBQztJQUNwSCxDQUFDLENBQ0gsQ0FBQyxlQUNELElBQUE5SCxXQUFBLENBQUF1QixHQUFBO01BQUdDLFNBQVMsRUFBQyxlQUFlO01BQUMsZUFBWSxNQUFNO01BQUFDLFFBQUEsRUFDNUMsSUFBQUMsZ0JBQUssRUFBQzZGLEVBQUUsRUFBRTdFLE9BQU8sS0FBSyxRQUFRLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDZixHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLGtCQUNoRCxJQUFBN0IsV0FBQSxDQUFBdUIsR0FBQTtRQUFjWSxDQUFDLEVBQUVBLENBQUMsQ0FBQ1AsQ0FBQyxDQUFFO1FBQUNQLENBQUMsRUFBRWhCLENBQUMsQ0FBQ0MsR0FBRyxHQUFHSyxFQUFFLEdBQUcsRUFBRztRQUFDMEIsVUFBVSxFQUFDLFFBQVE7UUFBQ2IsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxFQUNyRmIsU0FBUyxDQUFDZ0IsQ0FBQztNQUFDLEdBREpDLENBRUwsQ0FDUDtJQUFDLENBQ0QsQ0FBQyxlQUNKLElBQUE3QixXQUFBLENBQUF1QixHQUFBLEVBQUMwQixNQUFNO01BQUNDLEtBQUssRUFBRWUsTUFBTSxDQUFDdEMsR0FBRyxDQUFFZ0UsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBRTtNQUFDbEQsT0FBTyxFQUFFQTtJQUFRLENBQUUsQ0FBQztFQUFBLENBQzlELENBQUM7QUFFUDtBQUFDd0YsR0FBQSxHQWhDUVosT0FBTztBQWtDaEIsU0FBU2EsY0FBY0EsQ0FBQztFQUFFdkUsSUFBSTtFQUFFQztBQUF5QyxDQUFDLEVBQUU7RUFDMUUsTUFBTXVFLEVBQUUsR0FBR3ZFLEdBQUcsQ0FBQ3dFLEtBQUssSUFBSSxPQUFPO0VBQy9CLE1BQU1DLElBQUksR0FBRyxJQUFBQyxvQkFBUyxFQUFDM0UsSUFBSSxFQUFFd0UsRUFBRSxFQUFFdkUsR0FBRyxDQUFDeUUsSUFBSSxDQUFDO0VBQzFDLE1BQU1sSCxNQUFNLEdBQUcsSUFBQStELHFCQUFVLEVBQUNtRCxJQUFJLENBQUMzRyxHQUFHLENBQUU2RyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDbkQsTUFBTXBILENBQUMsR0FBRyxJQUFBQyxzQkFBVyxFQUFDRixNQUFNLEVBQUUsQ0FBQ2YsQ0FBQyxDQUFDQyxHQUFHLEdBQUdLLEVBQUUsRUFBRU4sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQztFQUNsRCxNQUFNOEUsRUFBRSxHQUFHL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNmLE1BQU1xSCxFQUFFLEdBQUdoSSxFQUFFLEdBQUdLLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEVBQUVpRSxJQUFJLENBQUN6RixNQUFNLENBQUM7RUFDeEMsb0JBQ0UsSUFBQTdDLFdBQUEsQ0FBQThCLElBQUEsRUFBQTlCLFdBQUEsQ0FBQXFGLFFBQUE7SUFBQTVELFFBQUEsZ0JBQ0UsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ0osS0FBSztNQUFDQyxNQUFNLEVBQUVBO0lBQU8sQ0FBRSxDQUFDLEVBQ3hCa0gsSUFBSSxDQUFDM0csR0FBRyxDQUFDLENBQUM2RyxDQUFDLEVBQUUzRyxDQUFDLEtBQUs7TUFDbEIsTUFBTTRELEVBQUUsR0FBR3BFLENBQUMsQ0FBQ21ILENBQUMsQ0FBQ0MsS0FBSyxDQUFDO01BQ3JCLG9CQUFPLElBQUF6SSxXQUFBLENBQUF1QixHQUFBO1FBQWNZLENBQUMsRUFBRTlCLENBQUMsQ0FBQ0ksSUFBSSxHQUFHaUksRUFBRSxHQUFHN0csQ0FBQyxHQUFHLENBQUU7UUFBQ1IsQ0FBQyxFQUFFb0UsRUFBRztRQUFDcEMsS0FBSyxFQUFFdEMsSUFBSSxDQUFDc0QsR0FBRyxDQUFDLENBQUMsRUFBRXFFLEVBQUUsR0FBRyxDQUFDLENBQUU7UUFBQ3BGLE1BQU0sRUFBRXZDLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEVBQUVlLEVBQUUsR0FBR0ssRUFBRSxDQUFFO1FBQUNqQyxJQUFJLEVBQUUsSUFBQUMsb0JBQVcsRUFBQyxDQUFDO01BQUUsR0FBakg1QixDQUFtSCxDQUFDO0lBQ3hJLENBQUMsQ0FBQztFQUFBLENBQ0YsQ0FBQztBQUVQOztBQUVBO0FBQ0E7QUFDQTtBQUFBOEcsR0FBQSxHQXBCU1IsY0FBYztBQXNCdkIsU0FBU1MsT0FBT0EsQ0FBQ0MsTUFBMEMsRUFBRWIsRUFBVSxFQUFFQyxFQUFVLEVBQUV0RCxDQUFTLEVBQVc7RUFDdkcsTUFBTXNCLEtBQUssR0FBRzRDLE1BQU0sQ0FBQy9DLE1BQU0sQ0FBQyxDQUFDQyxHQUFHLEVBQUVKLENBQUMsS0FBS0ksR0FBRyxHQUFHSixDQUFDLENBQUMwQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztFQUM5RCxNQUFNUyxHQUFZLEdBQUcsRUFBRTtFQUN2QixJQUFJQyxFQUFFLEdBQUcsQ0FBQ2hJLElBQUksQ0FBQ2lJLEVBQUUsR0FBRyxDQUFDO0VBQ3JCLEtBQUssTUFBTXJELENBQUMsSUFBSWtELE1BQU0sRUFBRTtJQUN0QixNQUFNSSxJQUFJLEdBQUd0RCxDQUFDLENBQUMwQyxLQUFLLEdBQUdwQyxLQUFLO0lBQzVCLElBQUlnRCxJQUFJLElBQUksTUFBTSxFQUFFO01BQ2xCSCxHQUFHLENBQUNJLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUU7TUFBSyxDQUFDLENBQUM7TUFDeEI7SUFDRjtJQUNBLE1BQU1DLEVBQUUsR0FBR0wsRUFBRSxHQUFHRSxJQUFJLEdBQUdsSSxJQUFJLENBQUNpSSxFQUFFLEdBQUcsQ0FBQztJQUNsQyxNQUFNSyxLQUFLLEdBQUdELEVBQUUsR0FBR0wsRUFBRSxHQUFHaEksSUFBSSxDQUFDaUksRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3ZDLE1BQU1NLEVBQUUsR0FBRyxDQUFDdEIsRUFBRSxHQUFHckQsQ0FBQyxHQUFHNUQsSUFBSSxDQUFDd0ksR0FBRyxDQUFDUixFQUFFLENBQUMsRUFBRWQsRUFBRSxHQUFHdEQsQ0FBQyxHQUFHNUQsSUFBSSxDQUFDeUksR0FBRyxDQUFDVCxFQUFFLENBQUMsQ0FBQztJQUN6RCxNQUFNVSxFQUFFLEdBQUcsQ0FBQ3pCLEVBQUUsR0FBR3JELENBQUMsR0FBRzVELElBQUksQ0FBQ3dJLEdBQUcsQ0FBQ0gsRUFBRSxDQUFDLEVBQUVuQixFQUFFLEdBQUd0RCxDQUFDLEdBQUc1RCxJQUFJLENBQUN5SSxHQUFHLENBQUNKLEVBQUUsQ0FBQyxDQUFDO0lBQ3pETixHQUFHLENBQUNJLElBQUksQ0FBQztNQUFFQyxJQUFJLEVBQUUsS0FBSztNQUFFcEMsQ0FBQyxFQUFFLEtBQUtpQixFQUFFLElBQUlDLEVBQUUsTUFBTXFCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JJLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSXFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JJLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTTBELENBQUMsSUFBSUEsQ0FBQyxNQUFNMEUsS0FBSyxNQUFNSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUN4SSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUl3SSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUN4SSxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQUssQ0FBQyxDQUFDO0lBQzFKOEgsRUFBRSxHQUFHSyxFQUFFO0VBQ1Q7RUFDQSxPQUFPTixHQUFHO0FBQ1o7QUFFQSxTQUFTWSxRQUFRQSxDQUFDO0VBQUU5RixJQUFJO0VBQUVDLEdBQUc7RUFBRW5CO0FBQStELENBQUMsRUFBRTtFQUMvRixNQUFNMEYsRUFBRSxHQUFHdkUsR0FBRyxDQUFDd0UsS0FBSyxJQUFJLE9BQU87RUFDL0IsTUFBTXNCLEVBQUUsR0FBRzlGLEdBQUcsQ0FBQytGLEtBQUssSUFBSSxPQUFPO0VBQy9CLE1BQU1mLE1BQU0sR0FBRyxJQUFBZ0Isb0JBQVMsRUFBQ2pHLElBQUksRUFBRXdFLEVBQUUsRUFBRXVCLEVBQUUsQ0FBQztFQUN0QyxNQUFNM0IsRUFBRSxHQUFHM0gsQ0FBQyxDQUFDSSxJQUFJLEdBQUdDLEVBQUUsR0FBRyxDQUFDO0VBQzFCLE1BQU11SCxFQUFFLEdBQUc1SCxDQUFDLENBQUNDLEdBQUcsR0FBR0ssRUFBRSxHQUFHLENBQUM7RUFDekIsTUFBTWdFLENBQUMsR0FBRzVELElBQUksQ0FBQzJFLEdBQUcsQ0FBQ2hGLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDbEMsTUFBTW1KLE1BQU0sR0FBR2xCLE9BQU8sQ0FBQ0MsTUFBTSxFQUFFYixFQUFFLEVBQUVDLEVBQUUsRUFBRXRELENBQUMsQ0FBQztFQUN6QyxvQkFDRSxJQUFBM0UsV0FBQSxDQUFBOEIsSUFBQSxFQUFBOUIsV0FBQSxDQUFBcUYsUUFBQTtJQUFBNUQsUUFBQSxnQkFDRSxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQTtNQUFBRSxRQUFBLEVBQ0dxSSxNQUFNLENBQUNuSSxHQUFHLENBQUMsQ0FBQ29JLENBQUMsRUFBRWxJLENBQUMsS0FDZmtJLENBQUMsQ0FBQ1osSUFBSSxnQkFDSixJQUFBbkosV0FBQSxDQUFBdUIsR0FBQTtRQUFnQnlHLEVBQUUsRUFBRUEsRUFBRztRQUFDQyxFQUFFLEVBQUVBLEVBQUc7UUFBQ3RELENBQUMsRUFBRUEsQ0FBRTtRQUFDbkIsSUFBSSxFQUFFLElBQUFDLG9CQUFXLEVBQUM1QixDQUFDLENBQUU7UUFBQ29GLE1BQU0sRUFBQyx1QkFBdUI7UUFBQ0MsV0FBVyxFQUFFO01BQUksR0FBL0ZyRixDQUFpRyxDQUFDLGdCQUUvRyxJQUFBN0IsV0FBQSxDQUFBdUIsR0FBQTtRQUFjd0YsQ0FBQyxFQUFFZ0QsQ0FBQyxDQUFDaEQsQ0FBRTtRQUFDdkQsSUFBSSxFQUFFLElBQUFDLG9CQUFXLEVBQUM1QixDQUFDLENBQUU7UUFBQ29GLE1BQU0sRUFBQyx1QkFBdUI7UUFBQ0MsV0FBVyxFQUFFO01BQUksR0FBakZyRixDQUFtRixDQUVsRztJQUFDLENBQ0EsQ0FBQyxlQUNKLElBQUE3QixXQUFBLENBQUF1QixHQUFBLEVBQUMwQixNQUFNO01BQUNDLEtBQUssRUFBRTJGLE1BQU0sQ0FBQ2xILEdBQUcsQ0FBRWdFLENBQUMsSUFBS0EsQ0FBQyxDQUFDaUUsS0FBSyxDQUFFO01BQUNsSCxPQUFPLEVBQUVBO0lBQVEsQ0FBRSxDQUFDO0VBQUEsQ0FDL0QsQ0FBQztBQUVQO0FBQUNzSCxHQUFBLEdBdEJRTixRQUFRO0FBd0JGLFNBQVNPLFdBQVdBLENBQUM7RUFBRXJHLElBQUk7RUFBRUMsR0FBRztFQUFFcUc7QUFBbUUsQ0FBQyxFQUFFO0VBQUFqSyxHQUFBO0VBQ3JILE1BQU07SUFBRWtLLEdBQUc7SUFBRTlHO0VBQU0sQ0FBQyxHQUFHLElBQUErRyxvQ0FBaUIsRUFBQ2pLLENBQUMsQ0FBQztFQUMzQyxNQUFNdUMsT0FBTyxHQUFHLElBQUEySCw2QkFBVSxFQUFDaEgsS0FBSyxDQUFDO0VBQ2pDLE1BQU11RyxLQUFLLEdBQUdNLFNBQVMsSUFBSSxHQUFHckcsR0FBRyxDQUFDaUQsSUFBSSxRQUFRO0VBRTlDLElBQUlsRCxJQUFJLENBQUNmLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDckIsb0JBQ0UsSUFBQTdDLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS0MsU0FBUyxFQUFDLHlCQUF5QjtNQUFDMkksR0FBRyxFQUFFQSxHQUFJO01BQUExSSxRQUFBLGVBQ2hELElBQUF6QixXQUFBLENBQUF1QixHQUFBO1FBQU1DLFNBQVMsRUFBQyxrQkFBa0I7UUFBQUMsUUFBQSxFQUFDO01BQU8sQ0FBTTtJQUFDLENBQzlDLENBQUM7RUFFVjtFQUVBLElBQUk2SSxJQUFxQjtFQUN6QixRQUFRekcsR0FBRyxDQUFDaUQsSUFBSTtJQUNkLEtBQUssS0FBSztNQUNSd0QsSUFBSSxnQkFBRyxJQUFBdEssV0FBQSxDQUFBdUIsR0FBQSxFQUFDb0MsUUFBUTtRQUFDQyxJQUFJLEVBQUVBLElBQUs7UUFBQ0MsR0FBRyxFQUFFQSxHQUFJO1FBQUNuQixPQUFPLEVBQUVBO01BQVEsQ0FBRSxDQUFDO01BQzNEO0lBQ0YsS0FBSyxNQUFNO0lBQ1gsS0FBSyxNQUFNO01BQ1Q0SCxJQUFJLGdCQUFHLElBQUF0SyxXQUFBLENBQUF1QixHQUFBLEVBQUMrRSxRQUFRO1FBQUMxQyxJQUFJLEVBQUVBLElBQUs7UUFBQ0MsR0FBRyxFQUFFQSxHQUFJO1FBQUNuQixPQUFPLEVBQUVBO01BQVEsQ0FBRSxDQUFDO01BQzNEO0lBQ0YsS0FBSyxTQUFTO01BQ1o0SCxJQUFJLGdCQUFHLElBQUF0SyxXQUFBLENBQUF1QixHQUFBLEVBQUMrRixPQUFPO1FBQUMxRCxJQUFJLEVBQUVBLElBQUs7UUFBQ0MsR0FBRyxFQUFFQSxHQUFJO1FBQUNuQixPQUFPLEVBQUVBO01BQVEsQ0FBRSxDQUFDO01BQzFEO0lBQ0YsS0FBSyxXQUFXO01BQ2Q0SCxJQUFJLGdCQUFHLElBQUF0SyxXQUFBLENBQUF1QixHQUFBLEVBQUM0RyxjQUFjO1FBQUN2RSxJQUFJLEVBQUVBLElBQUs7UUFBQ0MsR0FBRyxFQUFFQTtNQUFJLENBQUUsQ0FBQztNQUMvQztJQUNGLEtBQUssS0FBSztNQUNSeUcsSUFBSSxnQkFBRyxJQUFBdEssV0FBQSxDQUFBdUIsR0FBQSxFQUFDbUksUUFBUTtRQUFDOUYsSUFBSSxFQUFFQSxJQUFLO1FBQUNDLEdBQUcsRUFBRUEsR0FBSTtRQUFDbkIsT0FBTyxFQUFFQTtNQUFRLENBQUUsQ0FBQztNQUMzRDtFQUNKO0VBRUEsb0JBQ0UsSUFBQTFDLFdBQUEsQ0FBQXVCLEdBQUE7SUFBS0MsU0FBUyxFQUFDLFVBQVU7SUFBQzJJLEdBQUcsRUFBRUEsR0FBSTtJQUFBMUksUUFBQSxlQUNqQyxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQTtNQUFLZ0osT0FBTyxFQUFFLE9BQU9wSyxDQUFDLElBQUlDLENBQUMsRUFBRztNQUFDb0ssbUJBQW1CLEVBQUMsZUFBZTtNQUFDaEosU0FBUyxFQUFDLGNBQWM7TUFBQ2lKLElBQUksRUFBQyxLQUFLO01BQUMsY0FBWWIsS0FBTTtNQUFBbkksUUFBQSxFQUN0SDZJO0lBQUksQ0FDRjtFQUFDLENBQ0gsQ0FBQztBQUVWO0FBQUNySyxHQUFBLENBeEN1QmdLLFdBQVc7RUFBQSxRQUNWRyxvQ0FBaUI7QUFBQTtBQUFBTSxHQUFBLEdBRGxCVCxXQUFXO0FBQUEsSUFBQTNILEVBQUEsRUFBQVUsR0FBQSxFQUFBVSxHQUFBLEVBQUEyQyxHQUFBLEVBQUFnQixHQUFBLEVBQUFhLEdBQUEsRUFBQVMsR0FBQSxFQUFBcUIsR0FBQSxFQUFBVSxHQUFBO0FBQUFDLFlBQUEsQ0FBQXJJLEVBQUE7QUFBQXFJLFlBQUEsQ0FBQTNILEdBQUE7QUFBQTJILFlBQUEsQ0FBQWpILEdBQUE7QUFBQWlILFlBQUEsQ0FBQXRFLEdBQUE7QUFBQXNFLFlBQUEsQ0FBQXRELEdBQUE7QUFBQXNELFlBQUEsQ0FBQXpDLEdBQUE7QUFBQXlDLFlBQUEsQ0FBQWhDLEdBQUE7QUFBQWdDLFlBQUEsQ0FBQVgsR0FBQTtBQUFBVyxZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}