"use strict";

require("ses");
var _engineWorker = require("../engine/worker/engineWorker.ts");
// The real Web Worker entry (ARCHITECTURE_PLAN §4): `lockdown()` the worker realm, then serve
// `build`/`eval` over `postMessage` with the framework-free worker body. This is the one piece
// that can only run inside a real dedicated worker; all of its logic lives in the tested
// `createEngineWorker`. The host spawns it with
//   new Worker(new URL('./entry/engine.ts', import.meta.url), { type: 'module' })
// (a standard ESM worker — not a bundler macro), wrapped by `workerTransport`.

const scope = globalThis;

// Freeze intrinsics so formulas run in a starved realm. Confinement holds with or without
// lockdown (a fresh Compartment holds only its endowments), but production locks down; the
// availability-critical half is the host's watchdog, which terminates a wedged worker.
scope.lockdown?.({
  errorTaming: 'unsafe'
});
const worker = (0, _engineWorker.createEngineWorker)();
scope.onmessage = e => {
  const msg = e.data;
  if (msg.type === 'build') {
    try {
      scope.postMessage({
        type: 'built',
        descriptor: worker.build(msg.sources)
      });
    } catch (err) {
      scope.postMessage({
        type: 'build-error',
        message: err.message
      });
    }
    return;
  }
  if (msg.type === 'run-tests') {
    try {
      scope.postMessage({
        type: 'test-results',
        token: msg.token,
        suites: worker.runSuites(msg.suites)
      });
    } catch (err) {
      scope.postMessage({
        type: 'eval-error',
        token: msg.token,
        id: '(run-tests)',
        message: err.message
      });
    }
    return;
  }
  // A formula may be async (§4.1) — await it before posting the result.
  Promise.resolve().then(() => worker.eval(msg.id, msg.inputs)).then(value => scope.postMessage({
    type: 'result',
    token: msg.token,
    id: msg.id,
    value
  })).catch(err => scope.postMessage({
    type: 'eval-error',
    token: msg.token,
    id: msg.id,
    message: err.message
  }));
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2VuZ2luZVdvcmtlciIsInNjb3BlIiwiZ2xvYmFsVGhpcyIsImxvY2tkb3duIiwiZXJyb3JUYW1pbmciLCJ3b3JrZXIiLCJjcmVhdGVFbmdpbmVXb3JrZXIiLCJvbm1lc3NhZ2UiLCJlIiwibXNnIiwiZGF0YSIsInR5cGUiLCJwb3N0TWVzc2FnZSIsImRlc2NyaXB0b3IiLCJidWlsZCIsInNvdXJjZXMiLCJlcnIiLCJtZXNzYWdlIiwidG9rZW4iLCJzdWl0ZXMiLCJydW5TdWl0ZXMiLCJpZCIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsImV2YWwiLCJpbnB1dHMiLCJ2YWx1ZSIsImNhdGNoIl0sInNvdXJjZXMiOlsiZW5naW5lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSByZWFsIFdlYiBXb3JrZXIgZW50cnkgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnNCk6IGBsb2NrZG93bigpYCB0aGUgd29ya2VyIHJlYWxtLCB0aGVuIHNlcnZlXG4vLyBgYnVpbGRgL2BldmFsYCBvdmVyIGBwb3N0TWVzc2FnZWAgd2l0aCB0aGUgZnJhbWV3b3JrLWZyZWUgd29ya2VyIGJvZHkuIFRoaXMgaXMgdGhlIG9uZSBwaWVjZVxuLy8gdGhhdCBjYW4gb25seSBydW4gaW5zaWRlIGEgcmVhbCBkZWRpY2F0ZWQgd29ya2VyOyBhbGwgb2YgaXRzIGxvZ2ljIGxpdmVzIGluIHRoZSB0ZXN0ZWRcbi8vIGBjcmVhdGVFbmdpbmVXb3JrZXJgLiBUaGUgaG9zdCBzcGF3bnMgaXQgd2l0aFxuLy8gICBuZXcgV29ya2VyKG5ldyBVUkwoJy4vZW50cnkvZW5naW5lLnRzJywgaW1wb3J0Lm1ldGEudXJsKSwgeyB0eXBlOiAnbW9kdWxlJyB9KVxuLy8gKGEgc3RhbmRhcmQgRVNNIHdvcmtlciDigJQgbm90IGEgYnVuZGxlciBtYWNybyksIHdyYXBwZWQgYnkgYHdvcmtlclRyYW5zcG9ydGAuXG5cbmltcG9ydCAnc2VzJztcbmltcG9ydCB7IGNyZWF0ZUVuZ2luZVdvcmtlciB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXIvZW5naW5lV29ya2VyLnRzJztcbmltcG9ydCB0eXBlIHsgV29ya2VyUmVxdWVzdCwgV29ya2VyUmVzcG9uc2UgfSBmcm9tICcuLi9lbmdpbmUvd29ya2VyL3Byb3RvY29sLnRzJztcblxuaW50ZXJmYWNlIFdvcmtlclNjb3BlIHtcbiAgb25tZXNzYWdlOiAoKGU6IHsgZGF0YTogV29ya2VyUmVxdWVzdCB9KSA9PiB2b2lkKSB8IG51bGw7XG4gIHBvc3RNZXNzYWdlKG1zZzogV29ya2VyUmVzcG9uc2UpOiB2b2lkO1xuICBsb2NrZG93bj86IChvcHRzPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pID0+IHZvaWQ7XG59XG5jb25zdCBzY29wZSA9IGdsb2JhbFRoaXMgYXMgdW5rbm93biBhcyBXb3JrZXJTY29wZTtcblxuLy8gRnJlZXplIGludHJpbnNpY3Mgc28gZm9ybXVsYXMgcnVuIGluIGEgc3RhcnZlZCByZWFsbS4gQ29uZmluZW1lbnQgaG9sZHMgd2l0aCBvciB3aXRob3V0XG4vLyBsb2NrZG93biAoYSBmcmVzaCBDb21wYXJ0bWVudCBob2xkcyBvbmx5IGl0cyBlbmRvd21lbnRzKSwgYnV0IHByb2R1Y3Rpb24gbG9ja3MgZG93bjsgdGhlXG4vLyBhdmFpbGFiaWxpdHktY3JpdGljYWwgaGFsZiBpcyB0aGUgaG9zdCdzIHdhdGNoZG9nLCB3aGljaCB0ZXJtaW5hdGVzIGEgd2VkZ2VkIHdvcmtlci5cbnNjb3BlLmxvY2tkb3duPy4oeyBlcnJvclRhbWluZzogJ3Vuc2FmZScgfSk7XG5cbmNvbnN0IHdvcmtlciA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuXG5zY29wZS5vbm1lc3NhZ2UgPSAoZSkgPT4ge1xuICBjb25zdCBtc2cgPSBlLmRhdGE7XG4gIGlmIChtc2cudHlwZSA9PT0gJ2J1aWxkJykge1xuICAgIHRyeSB7XG4gICAgICBzY29wZS5wb3N0TWVzc2FnZSh7IHR5cGU6ICdidWlsdCcsIGRlc2NyaXB0b3I6IHdvcmtlci5idWlsZChtc2cuc291cmNlcykgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzY29wZS5wb3N0TWVzc2FnZSh7IHR5cGU6ICdidWlsZC1lcnJvcicsIG1lc3NhZ2U6IChlcnIgYXMgRXJyb3IpLm1lc3NhZ2UgfSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuICBpZiAobXNnLnR5cGUgPT09ICdydW4tdGVzdHMnKSB7XG4gICAgdHJ5IHtcbiAgICAgIHNjb3BlLnBvc3RNZXNzYWdlKHsgdHlwZTogJ3Rlc3QtcmVzdWx0cycsIHRva2VuOiBtc2cudG9rZW4sIHN1aXRlczogd29ya2VyLnJ1blN1aXRlcyhtc2cuc3VpdGVzKSB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNjb3BlLnBvc3RNZXNzYWdlKHsgdHlwZTogJ2V2YWwtZXJyb3InLCB0b2tlbjogbXNnLnRva2VuLCBpZDogJyhydW4tdGVzdHMpJywgbWVzc2FnZTogKGVyciBhcyBFcnJvcikubWVzc2FnZSB9KTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIEEgZm9ybXVsYSBtYXkgYmUgYXN5bmMgKMKnNC4xKSDigJQgYXdhaXQgaXQgYmVmb3JlIHBvc3RpbmcgdGhlIHJlc3VsdC5cbiAgUHJvbWlzZS5yZXNvbHZlKClcbiAgICAudGhlbigoKSA9PiB3b3JrZXIuZXZhbChtc2cuaWQsIG1zZy5pbnB1dHMpKVxuICAgIC50aGVuKCh2YWx1ZSkgPT4gc2NvcGUucG9zdE1lc3NhZ2UoeyB0eXBlOiAncmVzdWx0JywgdG9rZW46IG1zZy50b2tlbiwgaWQ6IG1zZy5pZCwgdmFsdWUgfSkpXG4gICAgLmNhdGNoKChlcnIpID0+IHNjb3BlLnBvc3RNZXNzYWdlKHsgdHlwZTogJ2V2YWwtZXJyb3InLCB0b2tlbjogbXNnLnRva2VuLCBpZDogbXNnLmlkLCBtZXNzYWdlOiAoZXJyIGFzIEVycm9yKS5tZXNzYWdlIH0pKTtcbn07XG4iXSwibWFwcGluZ3MiOiI7O0FBT0FBLE9BQUE7QUFDQSxJQUFBQyxhQUFBLEdBQUFELE9BQUE7QUFSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBV0EsTUFBTUUsS0FBSyxHQUFHQyxVQUFvQzs7QUFFbEQ7QUFDQTtBQUNBO0FBQ0FELEtBQUssQ0FBQ0UsUUFBUSxHQUFHO0VBQUVDLFdBQVcsRUFBRTtBQUFTLENBQUMsQ0FBQztBQUUzQyxNQUFNQyxNQUFNLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztBQUVuQ0wsS0FBSyxDQUFDTSxTQUFTLEdBQUlDLENBQUMsSUFBSztFQUN2QixNQUFNQyxHQUFHLEdBQUdELENBQUMsQ0FBQ0UsSUFBSTtFQUNsQixJQUFJRCxHQUFHLENBQUNFLElBQUksS0FBSyxPQUFPLEVBQUU7SUFDeEIsSUFBSTtNQUNGVixLQUFLLENBQUNXLFdBQVcsQ0FBQztRQUFFRCxJQUFJLEVBQUUsT0FBTztRQUFFRSxVQUFVLEVBQUVSLE1BQU0sQ0FBQ1MsS0FBSyxDQUFDTCxHQUFHLENBQUNNLE9BQU87TUFBRSxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDLE9BQU9DLEdBQUcsRUFBRTtNQUNaZixLQUFLLENBQUNXLFdBQVcsQ0FBQztRQUFFRCxJQUFJLEVBQUUsYUFBYTtRQUFFTSxPQUFPLEVBQUdELEdBQUcsQ0FBV0M7TUFBUSxDQUFDLENBQUM7SUFDN0U7SUFDQTtFQUNGO0VBQ0EsSUFBSVIsR0FBRyxDQUFDRSxJQUFJLEtBQUssV0FBVyxFQUFFO0lBQzVCLElBQUk7TUFDRlYsS0FBSyxDQUFDVyxXQUFXLENBQUM7UUFBRUQsSUFBSSxFQUFFLGNBQWM7UUFBRU8sS0FBSyxFQUFFVCxHQUFHLENBQUNTLEtBQUs7UUFBRUMsTUFBTSxFQUFFZCxNQUFNLENBQUNlLFNBQVMsQ0FBQ1gsR0FBRyxDQUFDVSxNQUFNO01BQUUsQ0FBQyxDQUFDO0lBQ3JHLENBQUMsQ0FBQyxPQUFPSCxHQUFHLEVBQUU7TUFDWmYsS0FBSyxDQUFDVyxXQUFXLENBQUM7UUFBRUQsSUFBSSxFQUFFLFlBQVk7UUFBRU8sS0FBSyxFQUFFVCxHQUFHLENBQUNTLEtBQUs7UUFBRUcsRUFBRSxFQUFFLGFBQWE7UUFBRUosT0FBTyxFQUFHRCxHQUFHLENBQVdDO01BQVEsQ0FBQyxDQUFDO0lBQ2pIO0lBQ0E7RUFDRjtFQUNBO0VBQ0FLLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FDZEMsSUFBSSxDQUFDLE1BQU1uQixNQUFNLENBQUNvQixJQUFJLENBQUNoQixHQUFHLENBQUNZLEVBQUUsRUFBRVosR0FBRyxDQUFDaUIsTUFBTSxDQUFDLENBQUMsQ0FDM0NGLElBQUksQ0FBRUcsS0FBSyxJQUFLMUIsS0FBSyxDQUFDVyxXQUFXLENBQUM7SUFBRUQsSUFBSSxFQUFFLFFBQVE7SUFBRU8sS0FBSyxFQUFFVCxHQUFHLENBQUNTLEtBQUs7SUFBRUcsRUFBRSxFQUFFWixHQUFHLENBQUNZLEVBQUU7SUFBRU07RUFBTSxDQUFDLENBQUMsQ0FBQyxDQUMzRkMsS0FBSyxDQUFFWixHQUFHLElBQUtmLEtBQUssQ0FBQ1csV0FBVyxDQUFDO0lBQUVELElBQUksRUFBRSxZQUFZO0lBQUVPLEtBQUssRUFBRVQsR0FBRyxDQUFDUyxLQUFLO0lBQUVHLEVBQUUsRUFBRVosR0FBRyxDQUFDWSxFQUFFO0lBQUVKLE9BQU8sRUFBR0QsR0FBRyxDQUFXQztFQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzdILENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=