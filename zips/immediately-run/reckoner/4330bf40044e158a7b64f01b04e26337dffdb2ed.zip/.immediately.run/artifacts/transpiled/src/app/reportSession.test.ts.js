"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _vitest = require("vitest");
var _reportSession = require("./reportSession.ts");
var _workerTransport = require("../engine/workerTransport.ts");
var _react = require("react");
var _server = require("react-dom/server");
var _Renderer = _interopRequireDefault(require("../report/render/Renderer.tsx"));
var _data = require("../seed/data.ts");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// End-to-end integration of shell B over the real pipeline: the bundled document loads, the
// SES-confined engine runs the worksheet, and the Bindings adapter resolves cells + params and
// recomputes on a param write. Runs in Node with the real `ses` package (same as the engine
// unit tests).
(0, _vitest.describe)('buildReportSession + sessionBindings', () => {
  (0, _vitest.it)('loads the demo document, runs the engine, and parses the template', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    (0, _vitest.expect)(session.title).toBe('Meridian — monthly review');
    (0, _vitest.expect)(session.nodes.length).toBeGreaterThan(0);
    (0, _vitest.expect)(session.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
  });
  (0, _vitest.it)('resolves a cell binding to the engine value + tier', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    const bindings = (0, _reportSession.sessionBindings)(session, () => {});
    const total = bindings.resolve('review.total');
    (0, _vitest.expect)(total.status).toBe('ok');
    (0, _vitest.expect)(total.tier).toBe('static');
    (0, _vitest.expect)(total.value).toBe(_data.execSummary[_data.execSummary.length - 1].mrr);

    // A percent KPI is a ratio (nrrPct / 100).
    const nrr = bindings.resolve('review.nrr');
    (0, _vitest.expect)(nrr.status).toBe('ok');
    (0, _vitest.expect)(nrr.value).toBeCloseTo(_data.execSummary[_data.execSummary.length - 1].nrrPct / 100, 6);
  });
  (0, _vitest.it)('resolves a param binding and an unknown binding', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    const bindings = (0, _reportSession.sessionBindings)(session, () => {});
    (0, _vitest.expect)(bindings.resolve('params.span')).toMatchObject({
      status: 'ok',
      value: '12m'
    });
    (0, _vitest.expect)(bindings.resolve('review.nope').status).toBe('missing');
  });
  (0, _vitest.it)('shapes the growth stack into long rows for the stacked bar', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    const bindings = (0, _reportSession.sessionBindings)(session, () => {});
    const stack = bindings.resolve('review.growth_stack');
    (0, _vitest.expect)(stack.status).toBe('ok');
    (0, _vitest.expect)(Array.isArray(stack.value)).toBe(true);
    (0, _vitest.expect)(stack.value.length).toBe(_data.mrrMovements.length * 3); // 3 drivers per month
  });
  (0, _vitest.it)('writing a param recomputes dependent cells (the interaction loop)', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    let changes = 0;
    // The worker engine recomputes asynchronously — resolve `onChange` when the pass settles.
    let settled = () => {};
    const bindings = (0, _reportSession.sessionBindings)(session, () => {
      changes++;
      settled();
    });
    const full = bindings.resolve('review.by_month').value;
    (0, _vitest.expect)(full.length).toBe(_data.execSummary.length); // span=12m → all months

    const recomputed = new Promise(r => settled = r);
    bindings.setParam('span', '6m');
    await recomputed;
    (0, _vitest.expect)(changes).toBe(1);
    (0, _vitest.expect)(bindings.resolve('params.span').value).toBe('6m');
    const windowed = bindings.resolve('review.by_month').value;
    (0, _vitest.expect)(windowed.length).toBe(6); // span=6m → last 6 months
  });
});
(0, _vitest.describe)('the demo document under the review surface', () => {
  (0, _vitest.it)('cells() carries docs; tests() carries the demo test cards; runTests() yields honest verdicts', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    (0, _vitest.expect)(session.engine.cells().find(c => c.id === 'review.total')?.doc).toContain('Latest monthly');
    (0, _vitest.expect)(session.engine.tests().map(t => [t.name, t.kind])).toEqual([['total_check', 'specification'], ['nrr_sane', 'property']]);
    const verdicts = await session.engine.runTests();
    (0, _vitest.expect)(verdicts.get('review.total')?.verdict).toBe('pinned'); // example-based only
    (0, _vitest.expect)(verdicts.get('review.nrr')?.verdict).toBe('validated'); // a property leg
    (0, _vitest.expect)(verdicts.has('review.by_month')).toBe(false); // honestly untested
  });
});
(0, _vitest.describe)('cross-reference validation (worksheet externals vs. what can be supplied)', () => {
  (0, _vitest.it)('the demo document is clean — no error diagnostics, only the frozen-provenance warnings', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    (0, _vitest.expect)(session.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
    // The demo fixtures cite the "meridian" feed the frozen document doesn't declare —
    // historical provenance, warning-class by design.
    (0, _vitest.expect)(session.diagnostics.some(d => d.severity === 'warning' && /sourceFeed/.test(d.message))).toBe(true);
  });
  (0, _vitest.it)('a dangling worksheet reference is an error anchored at the declaring worksheet', () => {
    const loaded = {
      root: 'doc',
      manifest: {
        params: {
          region: 'all'
        }
      },
      worksheets: [{
        name: 'revenue',
        path: 'worksheets/revenue.sheet.js',
        source: ''
      }],
      templates: [],
      feeds: [{
        name: 'orders',
        path: 'feeds/orders.feed.json',
        config: {}
      }],
      fixtures: [],
      diagnostics: []
    };
    const nodes = [{
      type: 'component',
      name: 'Select',
      attrs: {
        name: {
          kind: 'literal',
          value: 'span'
        }
      },
      children: []
    }];
    const diags = (0, _reportSession.xrefDiagnostics)(loaded, [{
      key: 'feeds.orders',
      site: 'revenue.by_month'
    },
    // declared → silent
    {
      key: 'feeds.ghost',
      site: 'revenue.by_month'
    },
    // dangling → error
    {
      key: 'params.span',
      site: 'revenue.total'
    },
    // widget param → silent
    {
      key: 'params.typo',
      site: 'revenue.total'
    } // no default, no widget → warning
    ], nodes);
    (0, _vitest.expect)(diags).toHaveLength(2);
    const error = diags.find(d => d.severity === 'error');
    (0, _vitest.expect)(error.message).toContain('feeds.ghost');
    (0, _vitest.expect)(error.file).toBe('worksheets/revenue.sheet.js'); // anchored at the declaring file
    (0, _vitest.expect)(diags.find(d => d.severity === 'warning')?.message).toContain('typo');
  });
});
(0, _vitest.describe)('the demo document under the value inspector', () => {
  (0, _vitest.it)('cells carry their formula source for read-only display', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)());
    const total = session.engine.cells().find(c => c.id === 'review.total');
    (0, _vitest.expect)(total.formulaSource).toContain('rows[rows.length - 1].mrr');
  });
});
(0, _vitest.describe)('makeTransport — module-semantics degradation (the import.meta platform trap)', () => {
  (0, _vitest.it)('falls back to the in-process transport when the worker URL module cannot load', async () => {
    // The platform shape: immediately.run transpiles ESM→CJS and evaluates as a classic
    // script, so any module containing import.meta throws at load — the dynamic import
    // rejects HERE (catchable) instead of killing the app at parse time.
    const t = await (0, _reportSession.makeTransport)(() => Promise.reject(new SyntaxError("Cannot use 'import.meta' outside a module")));
    (0, _vitest.expect)(t).toBeInstanceOf(Object);
    (0, _vitest.expect)(typeof t.post).toBe('function');
    (0, _vitest.expect)(typeof t.restart).toBe('function');
  });
  (0, _vitest.it)('uses the worker transport when real module semantics resolve the URL', async () => {
    const t = await (0, _reportSession.makeTransport)(async () => ({
      ENGINE_WORKER_URL: new URL('https://example.com/engine.js')
    }));
    // A real worker transport satisfies the same port; asserting the distinction by
    // behavior would need a Worker — the port shape is the contract.
    (0, _vitest.expect)(typeof t.post).toBe('function');
  });
  (0, _vitest.it)('the worker URL module itself resolves under real ESM (vitest) to the engine entry', async () => {
    const {
      ENGINE_WORKER_URL
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('./workerUrl.ts')));
    (0, _vitest.expect)(ENGINE_WORKER_URL.href).toContain('entry/engine.ts');
  });
});
(0, _vitest.describe)('declared vs undeclared feeds (R3-768)', () => {
  const SHEET = `import { cell } from "@reckoner/stdlib";

export const from_declared = cell({
  doc: "reads a declared feed",
  inputs: { raw: "feeds.declared" },
  formula: ({ raw }) => raw,
});

export const from_ghost = cell({
  doc: "reads an undeclared feed",
  inputs: { raw: "feeds.ghost" },
  formula: ({ raw }) => raw,
});
`;
  const seed = {
    root: 'doc',
    files: {
      'doc/reckoner.json': JSON.stringify({
        format: 1,
        compat: {
          stdlib: '>=0.1.0',
          catalog: '>=0.1.0'
        },
        worksheets: ['feeds'],
        params: {},
        title: 'Feed-xref harness'
      }),
      'doc/worksheets/feeds.sheet.js': SHEET,
      'doc/feeds/declared.feed.json': JSON.stringify({
        source: 'https://example.com/declared',
        mode: 'poll'
      }),
      'doc/templates/weekly.mdx': '# Report.\n'
    }
  };
  (0, _vitest.it)('an input naming an undeclared feed still raises the "no feed named" diagnostic', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed);
    const errors = session.diagnostics.filter(d => d.severity === 'error');
    (0, _vitest.expect)(errors.some(d => d.message.includes('no feed named "ghost"'))).toBe(true);
    (0, _vitest.expect)(errors.some(d => d.message.includes('feeds.declared'))).toBe(false);
  });
  (0, _vitest.it)('an input naming a declared feed raises no diagnostic and its cell resolves null', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed);
    const errors = session.diagnostics.filter(d => d.severity === 'error');
    (0, _vitest.expect)(errors.some(d => d.message.includes('feeds.declared'))).toBe(false);
    const bindings = (0, _reportSession.sessionBindings)(session, () => {});
    (0, _vitest.expect)(bindings.resolve('feeds.from_declared').value).toBeNull();
  });
});
(0, _vitest.describe)('the Caldera seed (the live LBO demo branch)', () => {
  (0, _vitest.it)('builds the session over the generated seed: clean diagnostics, parsed template, live cells', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), _reportSession.CALDERA_SEED);
    (0, _vitest.expect)(session.title).toBe('Caldera Components — LBO');
    (0, _vitest.expect)(session.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
    (0, _vitest.expect)(session.nodes.length).toBeGreaterThan(5); // Kpis, charts, tables, the params block

    const bindings = (0, _reportSession.sessionBindings)(session, () => {});
    const irr = bindings.resolve('model.sponsor_irr');
    (0, _vitest.expect)(irr.status).toBe('ok');
    (0, _vitest.expect)(irr.value).toBeCloseTo(0.22387462120837076, 10);
    const equity = bindings.resolve('model.sponsor_equity');
    (0, _vitest.expect)(equity.value).toBeCloseTo(114.8837, 4);
    (0, _vitest.expect)(bindings.resolve('params.tax_rate')).toMatchObject({
      status: 'ok',
      value: 0.25
    });
  });
  (0, _vitest.it)('a live deal-knob flip recomputes the returns (the interaction loop, finance edition)', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), _reportSession.CALDERA_SEED);
    let settled = () => {};
    const bindings = (0, _reportSession.sessionBindings)(session, () => settled());
    const before = bindings.resolve('model.sponsor_irr').value;
    const recomputed = new Promise(r => settled = r);
    bindings.setParam('exit_multiple', 9);
    await recomputed;
    (0, _vitest.expect)(bindings.resolve('model.sponsor_irr').value).toBeGreaterThan(before);
  });
});
(0, _vitest.describe)('Flow over the real producer (worksheet cells → two bound tables)', () => {
  const SHEET = `import { cell } from "@reckoner/stdlib";

export const n = cell({
  doc: "factory stations",
  formula: () => [
    { id: "draft", label: "Drafting", x: 0, y: 0, tone: "agent" },
    { id: "review", label: "Review gate", x: 240, y: 0, shape: "diamond", tone: "ci" },
    { id: "merge", label: "Merge", x: 480, y: 0, shape: "pill", tone: "owner" },
  ],
});

export const e = cell({
  doc: "buffers between stations",
  formula: () => [
    { from: "draft", to: "review", label: "awaiting review", value: 3, buffer: true, alert: true },
    { from: "review", to: "merge", label: "green", value: "1" },
  ],
});
`;
  const seed = {
    root: 'doc',
    files: {
      'doc/reckoner.json': JSON.stringify({
        format: 1,
        compat: {
          stdlib: '>=0.1.0',
          catalog: '>=0.1.0'
        },
        worksheets: ['w'],
        params: {},
        title: 'Flow harness'
      }),
      'doc/worksheets/w.sheet.js': SHEET,
      'doc/templates/weekly.mdx': '# Factory.\n\n<Flow nodes="w.n" edges="w.e" />\n'
    }
  };
  (0, _vitest.it)('validates clean and draws the stations and annotations', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed);
    (0, _vitest.expect)(session.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: session.nodes,
      bindings: (0, _reportSession.sessionBindings)(session, () => {})
    }));
    (0, _vitest.expect)(html).not.toContain('rk-broken');
    (0, _vitest.expect)(html).toContain('>Drafting<');
    (0, _vitest.expect)(html).toContain('>Review gate<');
    (0, _vitest.expect)(html).toContain('>Merge<');
    (0, _vitest.expect)(html).toContain('>awaiting review<');
    (0, _vitest.expect)(html).toContain('rk-flow-buffer');
    (0, _vitest.expect)(html).toContain('rk-flow-alert');
  });
});
(0, _vitest.describe)('ShowWhen over the real producer (engine booleans → conditional subtrees)', () => {
  const SHEET = `import { cell } from "@reckoner/stdlib";

export const flag = cell({
  doc: "on",
  formula: () => true,
});

export const off = cell({
  doc: "off",
  formula: () => false,
});
`;
  const seed = {
    root: 'doc',
    files: {
      'doc/reckoner.json': JSON.stringify({
        format: 1,
        compat: {
          stdlib: '>=0.1.0',
          catalog: '>=0.1.0'
        },
        worksheets: ['w'],
        params: {},
        title: 'ShowWhen harness'
      }),
      'doc/worksheets/w.sheet.js': SHEET,
      'doc/templates/weekly.mdx': '# Alarm.\n\n<ShowWhen source="w.flag"><Callout tone="danger">Over bound.</Callout></ShowWhen>\n\n<ShowWhen source="w.off"><Callout tone="danger">Never shown.</Callout></ShowWhen>\n'
    }
  };
  (0, _vitest.it)("renders only the true cell's subtree, with no error diagnostics — the engine, not a literal, produces the boolean", async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed);
    (0, _vitest.expect)(session.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: session.nodes,
      bindings: (0, _reportSession.sessionBindings)(session, () => {})
    }));
    (0, _vitest.expect)(html).toContain('Over bound.');
    (0, _vitest.expect)(html).not.toContain('Never shown.');
    (0, _vitest.expect)(html).not.toContain('rk-broken');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZXBvcnRTZXNzaW9uIiwiX3dvcmtlclRyYW5zcG9ydCIsIl9yZWFjdCIsIl9zZXJ2ZXIiLCJfUmVuZGVyZXIiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2RhdGEiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsImRlc2NyaWJlIiwiaXQiLCJzZXNzaW9uIiwiYnVpbGRSZXBvcnRTZXNzaW9uIiwiaW5NZW1vcnlUcmFuc3BvcnQiLCJleHBlY3QiLCJ0aXRsZSIsInRvQmUiLCJub2RlcyIsImxlbmd0aCIsInRvQmVHcmVhdGVyVGhhbiIsImRpYWdub3N0aWNzIiwiZmlsdGVyIiwiZCIsInNldmVyaXR5IiwidG9FcXVhbCIsImJpbmRpbmdzIiwic2Vzc2lvbkJpbmRpbmdzIiwidG90YWwiLCJyZXNvbHZlIiwic3RhdHVzIiwidGllciIsInZhbHVlIiwiZXhlY1N1bW1hcnkiLCJtcnIiLCJucnIiLCJ0b0JlQ2xvc2VUbyIsIm5yclBjdCIsInRvTWF0Y2hPYmplY3QiLCJzdGFjayIsIkFycmF5IiwiaXNBcnJheSIsIm1yck1vdmVtZW50cyIsImNoYW5nZXMiLCJzZXR0bGVkIiwiZnVsbCIsInJlY29tcHV0ZWQiLCJQcm9taXNlIiwic2V0UGFyYW0iLCJ3aW5kb3dlZCIsImVuZ2luZSIsImNlbGxzIiwiZmluZCIsImMiLCJpZCIsImRvYyIsInRvQ29udGFpbiIsInRlc3RzIiwibWFwIiwibmFtZSIsImtpbmQiLCJ2ZXJkaWN0cyIsInJ1blRlc3RzIiwidmVyZGljdCIsInNvbWUiLCJ0ZXN0IiwibWVzc2FnZSIsImxvYWRlZCIsInJvb3QiLCJtYW5pZmVzdCIsInBhcmFtcyIsInJlZ2lvbiIsIndvcmtzaGVldHMiLCJwYXRoIiwic291cmNlIiwidGVtcGxhdGVzIiwiZmVlZHMiLCJjb25maWciLCJmaXh0dXJlcyIsInR5cGUiLCJhdHRycyIsImNoaWxkcmVuIiwiZGlhZ3MiLCJ4cmVmRGlhZ25vc3RpY3MiLCJrZXkiLCJzaXRlIiwidG9IYXZlTGVuZ3RoIiwiZXJyb3IiLCJmaWxlIiwiZm9ybXVsYVNvdXJjZSIsIm1ha2VUcmFuc3BvcnQiLCJyZWplY3QiLCJTeW50YXhFcnJvciIsInRvQmVJbnN0YW5jZU9mIiwicG9zdCIsInJlc3RhcnQiLCJFTkdJTkVfV09SS0VSX1VSTCIsIlVSTCIsInRoZW4iLCJocmVmIiwiU0hFRVQiLCJzZWVkIiwiZmlsZXMiLCJKU09OIiwic3RyaW5naWZ5IiwiZm9ybWF0IiwiY29tcGF0Iiwic3RkbGliIiwiY2F0YWxvZyIsIm1vZGUiLCJlcnJvcnMiLCJpbmNsdWRlcyIsInRvQmVOdWxsIiwiQ0FMREVSQV9TRUVEIiwiaXJyIiwiZXF1aXR5IiwiYmVmb3JlIiwiaHRtbCIsInJlbmRlclRvU3RhdGljTWFya3VwIiwiY3JlYXRlRWxlbWVudCIsIlJlcG9ydFZpZXciLCJub3QiXSwic291cmNlcyI6WyJyZXBvcnRTZXNzaW9uLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVzY3JpYmUsIGV4cGVjdCwgaXQgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYnVpbGRSZXBvcnRTZXNzaW9uLCBtYWtlVHJhbnNwb3J0LCBzZXNzaW9uQmluZGluZ3MsIHhyZWZEaWFnbm9zdGljcyB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgeyBDQUxERVJBX1NFRUQgfSBmcm9tICcuL3JlcG9ydFNlc3Npb24udHMnO1xuaW1wb3J0IHR5cGUgeyBTZWVkRG9jdW1lbnQgfSBmcm9tICcuL3JlcG9ydFNlc3Npb24udHMnO1xuaW1wb3J0IHsgaW5NZW1vcnlUcmFuc3BvcnQgfSBmcm9tICcuLi9lbmdpbmUvd29ya2VyVHJhbnNwb3J0LnRzJztcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyByZW5kZXJUb1N0YXRpY01hcmt1cCB9IGZyb20gJ3JlYWN0LWRvbS9zZXJ2ZXInO1xuaW1wb3J0IFJlcG9ydFZpZXcgZnJvbSAnLi4vcmVwb3J0L3JlbmRlci9SZW5kZXJlci50c3gnO1xuaW1wb3J0IHsgZXhlY1N1bW1hcnksIG1yck1vdmVtZW50cyB9IGZyb20gJy4uL3NlZWQvZGF0YS50cyc7XG5cbi8vIEVuZC10by1lbmQgaW50ZWdyYXRpb24gb2Ygc2hlbGwgQiBvdmVyIHRoZSByZWFsIHBpcGVsaW5lOiB0aGUgYnVuZGxlZCBkb2N1bWVudCBsb2FkcywgdGhlXG4vLyBTRVMtY29uZmluZWQgZW5naW5lIHJ1bnMgdGhlIHdvcmtzaGVldCwgYW5kIHRoZSBCaW5kaW5ncyBhZGFwdGVyIHJlc29sdmVzIGNlbGxzICsgcGFyYW1zIGFuZFxuLy8gcmVjb21wdXRlcyBvbiBhIHBhcmFtIHdyaXRlLiBSdW5zIGluIE5vZGUgd2l0aCB0aGUgcmVhbCBgc2VzYCBwYWNrYWdlIChzYW1lIGFzIHRoZSBlbmdpbmVcbi8vIHVuaXQgdGVzdHMpLlxuZGVzY3JpYmUoJ2J1aWxkUmVwb3J0U2Vzc2lvbiArIHNlc3Npb25CaW5kaW5ncycsICgpID0+IHtcbiAgaXQoJ2xvYWRzIHRoZSBkZW1vIGRvY3VtZW50LCBydW5zIHRoZSBlbmdpbmUsIGFuZCBwYXJzZXMgdGhlIHRlbXBsYXRlJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSk7XG4gICAgZXhwZWN0KHNlc3Npb24udGl0bGUpLnRvQmUoJ01lcmlkaWFuIOKAlCBtb250aGx5IHJldmlldycpO1xuICAgIGV4cGVjdChzZXNzaW9uLm5vZGVzLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICAgIGV4cGVjdChzZXNzaW9uLmRpYWdub3N0aWNzLmZpbHRlcigoZCkgPT4gZC5zZXZlcml0eSA9PT0gJ2Vycm9yJykpLnRvRXF1YWwoW10pO1xuICB9KTtcblxuICBpdCgncmVzb2x2ZXMgYSBjZWxsIGJpbmRpbmcgdG8gdGhlIGVuZ2luZSB2YWx1ZSArIHRpZXInLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihpbk1lbW9yeVRyYW5zcG9ydCgpKTtcbiAgICBjb25zdCBiaW5kaW5ncyA9IHNlc3Npb25CaW5kaW5ncyhzZXNzaW9uLCAoKSA9PiB7fSk7XG4gICAgY29uc3QgdG90YWwgPSBiaW5kaW5ncy5yZXNvbHZlKCdyZXZpZXcudG90YWwnKTtcbiAgICBleHBlY3QodG90YWwuc3RhdHVzKS50b0JlKCdvaycpO1xuICAgIGV4cGVjdCh0b3RhbC50aWVyKS50b0JlKCdzdGF0aWMnKTtcbiAgICBleHBlY3QodG90YWwudmFsdWUpLnRvQmUoZXhlY1N1bW1hcnlbZXhlY1N1bW1hcnkubGVuZ3RoIC0gMV0ubXJyKTtcblxuICAgIC8vIEEgcGVyY2VudCBLUEkgaXMgYSByYXRpbyAobnJyUGN0IC8gMTAwKS5cbiAgICBjb25zdCBucnIgPSBiaW5kaW5ncy5yZXNvbHZlKCdyZXZpZXcubnJyJyk7XG4gICAgZXhwZWN0KG5yci5zdGF0dXMpLnRvQmUoJ29rJyk7XG4gICAgZXhwZWN0KG5yci52YWx1ZSkudG9CZUNsb3NlVG8oKGV4ZWNTdW1tYXJ5W2V4ZWNTdW1tYXJ5Lmxlbmd0aCAtIDFdLm5yclBjdCBhcyBudW1iZXIpIC8gMTAwLCA2KTtcbiAgfSk7XG5cbiAgaXQoJ3Jlc29sdmVzIGEgcGFyYW0gYmluZGluZyBhbmQgYW4gdW5rbm93biBiaW5kaW5nJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSk7XG4gICAgY29uc3QgYmluZGluZ3MgPSBzZXNzaW9uQmluZGluZ3Moc2Vzc2lvbiwgKCkgPT4ge30pO1xuICAgIGV4cGVjdChiaW5kaW5ncy5yZXNvbHZlKCdwYXJhbXMuc3BhbicpKS50b01hdGNoT2JqZWN0KHsgc3RhdHVzOiAnb2snLCB2YWx1ZTogJzEybScgfSk7XG4gICAgZXhwZWN0KGJpbmRpbmdzLnJlc29sdmUoJ3Jldmlldy5ub3BlJykuc3RhdHVzKS50b0JlKCdtaXNzaW5nJyk7XG4gIH0pO1xuXG4gIGl0KCdzaGFwZXMgdGhlIGdyb3d0aCBzdGFjayBpbnRvIGxvbmcgcm93cyBmb3IgdGhlIHN0YWNrZWQgYmFyJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSk7XG4gICAgY29uc3QgYmluZGluZ3MgPSBzZXNzaW9uQmluZGluZ3Moc2Vzc2lvbiwgKCkgPT4ge30pO1xuICAgIGNvbnN0IHN0YWNrID0gYmluZGluZ3MucmVzb2x2ZSgncmV2aWV3Lmdyb3d0aF9zdGFjaycpO1xuICAgIGV4cGVjdChzdGFjay5zdGF0dXMpLnRvQmUoJ29rJyk7XG4gICAgZXhwZWN0KEFycmF5LmlzQXJyYXkoc3RhY2sudmFsdWUpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdCgoc3RhY2sudmFsdWUgYXMgdW5rbm93bltdKS5sZW5ndGgpLnRvQmUobXJyTW92ZW1lbnRzLmxlbmd0aCAqIDMpOyAvLyAzIGRyaXZlcnMgcGVyIG1vbnRoXG4gIH0pO1xuXG4gIGl0KCd3cml0aW5nIGEgcGFyYW0gcmVjb21wdXRlcyBkZXBlbmRlbnQgY2VsbHMgKHRoZSBpbnRlcmFjdGlvbiBsb29wKScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYnVpbGRSZXBvcnRTZXNzaW9uKGluTWVtb3J5VHJhbnNwb3J0KCkpO1xuICAgIGxldCBjaGFuZ2VzID0gMDtcbiAgICAvLyBUaGUgd29ya2VyIGVuZ2luZSByZWNvbXB1dGVzIGFzeW5jaHJvbm91c2x5IOKAlCByZXNvbHZlIGBvbkNoYW5nZWAgd2hlbiB0aGUgcGFzcyBzZXR0bGVzLlxuICAgIGxldCBzZXR0bGVkOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG4gICAgY29uc3QgYmluZGluZ3MgPSBzZXNzaW9uQmluZGluZ3Moc2Vzc2lvbiwgKCkgPT4ge1xuICAgICAgY2hhbmdlcysrO1xuICAgICAgc2V0dGxlZCgpO1xuICAgIH0pO1xuXG4gICAgY29uc3QgZnVsbCA9IGJpbmRpbmdzLnJlc29sdmUoJ3Jldmlldy5ieV9tb250aCcpLnZhbHVlIGFzIHVua25vd25bXTtcbiAgICBleHBlY3QoZnVsbC5sZW5ndGgpLnRvQmUoZXhlY1N1bW1hcnkubGVuZ3RoKTsgLy8gc3Bhbj0xMm0g4oaSIGFsbCBtb250aHNcblxuICAgIGNvbnN0IHJlY29tcHV0ZWQgPSBuZXcgUHJvbWlzZTx2b2lkPigocikgPT4gKHNldHRsZWQgPSByKSk7XG4gICAgYmluZGluZ3Muc2V0UGFyYW0oJ3NwYW4nLCAnNm0nKTtcbiAgICBhd2FpdCByZWNvbXB1dGVkO1xuXG4gICAgZXhwZWN0KGNoYW5nZXMpLnRvQmUoMSk7XG4gICAgZXhwZWN0KGJpbmRpbmdzLnJlc29sdmUoJ3BhcmFtcy5zcGFuJykudmFsdWUpLnRvQmUoJzZtJyk7XG4gICAgY29uc3Qgd2luZG93ZWQgPSBiaW5kaW5ncy5yZXNvbHZlKCdyZXZpZXcuYnlfbW9udGgnKS52YWx1ZSBhcyB1bmtub3duW107XG4gICAgZXhwZWN0KHdpbmRvd2VkLmxlbmd0aCkudG9CZSg2KTsgLy8gc3Bhbj02bSDihpIgbGFzdCA2IG1vbnRoc1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgndGhlIGRlbW8gZG9jdW1lbnQgdW5kZXIgdGhlIHJldmlldyBzdXJmYWNlJywgKCkgPT4ge1xuICBpdCgnY2VsbHMoKSBjYXJyaWVzIGRvY3M7IHRlc3RzKCkgY2FycmllcyB0aGUgZGVtbyB0ZXN0IGNhcmRzOyBydW5UZXN0cygpIHlpZWxkcyBob25lc3QgdmVyZGljdHMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihpbk1lbW9yeVRyYW5zcG9ydCgpKTtcbiAgICBleHBlY3Qoc2Vzc2lvbi5lbmdpbmUuY2VsbHMoKS5maW5kKChjKSA9PiBjLmlkID09PSAncmV2aWV3LnRvdGFsJyk/LmRvYykudG9Db250YWluKCdMYXRlc3QgbW9udGhseScpO1xuICAgIGV4cGVjdChzZXNzaW9uLmVuZ2luZS50ZXN0cygpLm1hcCgodCkgPT4gW3QubmFtZSwgdC5raW5kXSkpLnRvRXF1YWwoW1xuICAgICAgWyd0b3RhbF9jaGVjaycsICdzcGVjaWZpY2F0aW9uJ10sXG4gICAgICBbJ25ycl9zYW5lJywgJ3Byb3BlcnR5J10sXG4gICAgXSk7XG5cbiAgICBjb25zdCB2ZXJkaWN0cyA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgZXhwZWN0KHZlcmRpY3RzLmdldCgncmV2aWV3LnRvdGFsJyk/LnZlcmRpY3QpLnRvQmUoJ3Bpbm5lZCcpOyAvLyBleGFtcGxlLWJhc2VkIG9ubHlcbiAgICBleHBlY3QodmVyZGljdHMuZ2V0KCdyZXZpZXcubnJyJyk/LnZlcmRpY3QpLnRvQmUoJ3ZhbGlkYXRlZCcpOyAvLyBhIHByb3BlcnR5IGxlZ1xuICAgIGV4cGVjdCh2ZXJkaWN0cy5oYXMoJ3Jldmlldy5ieV9tb250aCcpKS50b0JlKGZhbHNlKTsgLy8gaG9uZXN0bHkgdW50ZXN0ZWRcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ2Nyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uICh3b3Jrc2hlZXQgZXh0ZXJuYWxzIHZzLiB3aGF0IGNhbiBiZSBzdXBwbGllZCknLCAoKSA9PiB7XG4gIGl0KCd0aGUgZGVtbyBkb2N1bWVudCBpcyBjbGVhbiDigJQgbm8gZXJyb3IgZGlhZ25vc3RpY3MsIG9ubHkgdGhlIGZyb3plbi1wcm92ZW5hbmNlIHdhcm5pbmdzJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSk7XG4gICAgZXhwZWN0KHNlc3Npb24uZGlhZ25vc3RpY3MuZmlsdGVyKChkKSA9PiBkLnNldmVyaXR5ID09PSAnZXJyb3InKSkudG9FcXVhbChbXSk7XG4gICAgLy8gVGhlIGRlbW8gZml4dHVyZXMgY2l0ZSB0aGUgXCJtZXJpZGlhblwiIGZlZWQgdGhlIGZyb3plbiBkb2N1bWVudCBkb2Vzbid0IGRlY2xhcmUg4oCUXG4gICAgLy8gaGlzdG9yaWNhbCBwcm92ZW5hbmNlLCB3YXJuaW5nLWNsYXNzIGJ5IGRlc2lnbi5cbiAgICBleHBlY3Qoc2Vzc2lvbi5kaWFnbm9zdGljcy5zb21lKChkKSA9PiBkLnNldmVyaXR5ID09PSAnd2FybmluZycgJiYgL3NvdXJjZUZlZWQvLnRlc3QoZC5tZXNzYWdlKSkpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCdhIGRhbmdsaW5nIHdvcmtzaGVldCByZWZlcmVuY2UgaXMgYW4gZXJyb3IgYW5jaG9yZWQgYXQgdGhlIGRlY2xhcmluZyB3b3Jrc2hlZXQnLCAoKSA9PiB7XG4gICAgY29uc3QgbG9hZGVkID0ge1xuICAgICAgcm9vdDogJ2RvYycsXG4gICAgICBtYW5pZmVzdDogeyBwYXJhbXM6IHsgcmVnaW9uOiAnYWxsJyB9IH0sXG4gICAgICB3b3Jrc2hlZXRzOiBbeyBuYW1lOiAncmV2ZW51ZScsIHBhdGg6ICd3b3Jrc2hlZXRzL3JldmVudWUuc2hlZXQuanMnLCBzb3VyY2U6ICcnIH1dLFxuICAgICAgdGVtcGxhdGVzOiBbXSxcbiAgICAgIGZlZWRzOiBbeyBuYW1lOiAnb3JkZXJzJywgcGF0aDogJ2ZlZWRzL29yZGVycy5mZWVkLmpzb24nLCBjb25maWc6IHt9IH1dLFxuICAgICAgZml4dHVyZXM6IFtdLFxuICAgICAgZGlhZ25vc3RpY3M6IFtdLFxuICAgIH07XG4gICAgY29uc3Qgbm9kZXMgPSBbXG4gICAgICB7IHR5cGU6ICdjb21wb25lbnQnLCBuYW1lOiAnU2VsZWN0JywgYXR0cnM6IHsgbmFtZTogeyBraW5kOiAnbGl0ZXJhbCcsIHZhbHVlOiAnc3BhbicgfSB9LCBjaGlsZHJlbjogW10gfSxcbiAgICBdIGFzIG5ldmVyO1xuICAgIGNvbnN0IGRpYWdzID0geHJlZkRpYWdub3N0aWNzKFxuICAgICAgbG9hZGVkIGFzIG5ldmVyLFxuICAgICAgW1xuICAgICAgICB7IGtleTogJ2ZlZWRzLm9yZGVycycsIHNpdGU6ICdyZXZlbnVlLmJ5X21vbnRoJyB9LCAvLyBkZWNsYXJlZCDihpIgc2lsZW50XG4gICAgICAgIHsga2V5OiAnZmVlZHMuZ2hvc3QnLCBzaXRlOiAncmV2ZW51ZS5ieV9tb250aCcgfSwgLy8gZGFuZ2xpbmcg4oaSIGVycm9yXG4gICAgICAgIHsga2V5OiAncGFyYW1zLnNwYW4nLCBzaXRlOiAncmV2ZW51ZS50b3RhbCcgfSwgLy8gd2lkZ2V0IHBhcmFtIOKGkiBzaWxlbnRcbiAgICAgICAgeyBrZXk6ICdwYXJhbXMudHlwbycsIHNpdGU6ICdyZXZlbnVlLnRvdGFsJyB9LCAvLyBubyBkZWZhdWx0LCBubyB3aWRnZXQg4oaSIHdhcm5pbmdcbiAgICAgIF0sXG4gICAgICBub2RlcyxcbiAgICApO1xuICAgIGV4cGVjdChkaWFncykudG9IYXZlTGVuZ3RoKDIpO1xuICAgIGNvbnN0IGVycm9yID0gZGlhZ3MuZmluZCgoZCkgPT4gZC5zZXZlcml0eSA9PT0gJ2Vycm9yJykhO1xuICAgIGV4cGVjdChlcnJvci5tZXNzYWdlKS50b0NvbnRhaW4oJ2ZlZWRzLmdob3N0Jyk7XG4gICAgZXhwZWN0KGVycm9yLmZpbGUpLnRvQmUoJ3dvcmtzaGVldHMvcmV2ZW51ZS5zaGVldC5qcycpOyAvLyBhbmNob3JlZCBhdCB0aGUgZGVjbGFyaW5nIGZpbGVcbiAgICBleHBlY3QoZGlhZ3MuZmluZCgoZCkgPT4gZC5zZXZlcml0eSA9PT0gJ3dhcm5pbmcnKT8ubWVzc2FnZSkudG9Db250YWluKCd0eXBvJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd0aGUgZGVtbyBkb2N1bWVudCB1bmRlciB0aGUgdmFsdWUgaW5zcGVjdG9yJywgKCkgPT4ge1xuICBpdCgnY2VsbHMgY2FycnkgdGhlaXIgZm9ybXVsYSBzb3VyY2UgZm9yIHJlYWQtb25seSBkaXNwbGF5JywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSk7XG4gICAgY29uc3QgdG90YWwgPSBzZXNzaW9uLmVuZ2luZS5jZWxscygpLmZpbmQoKGMpID0+IGMuaWQgPT09ICdyZXZpZXcudG90YWwnKSE7XG4gICAgZXhwZWN0KHRvdGFsLmZvcm11bGFTb3VyY2UpLnRvQ29udGFpbigncm93c1tyb3dzLmxlbmd0aCAtIDFdLm1ycicpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnbWFrZVRyYW5zcG9ydCDigJQgbW9kdWxlLXNlbWFudGljcyBkZWdyYWRhdGlvbiAodGhlIGltcG9ydC5tZXRhIHBsYXRmb3JtIHRyYXApJywgKCkgPT4ge1xuICBpdCgnZmFsbHMgYmFjayB0byB0aGUgaW4tcHJvY2VzcyB0cmFuc3BvcnQgd2hlbiB0aGUgd29ya2VyIFVSTCBtb2R1bGUgY2Fubm90IGxvYWQnLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gVGhlIHBsYXRmb3JtIHNoYXBlOiBpbW1lZGlhdGVseS5ydW4gdHJhbnNwaWxlcyBFU03ihpJDSlMgYW5kIGV2YWx1YXRlcyBhcyBhIGNsYXNzaWNcbiAgICAvLyBzY3JpcHQsIHNvIGFueSBtb2R1bGUgY29udGFpbmluZyBpbXBvcnQubWV0YSB0aHJvd3MgYXQgbG9hZCDigJQgdGhlIGR5bmFtaWMgaW1wb3J0XG4gICAgLy8gcmVqZWN0cyBIRVJFIChjYXRjaGFibGUpIGluc3RlYWQgb2Yga2lsbGluZyB0aGUgYXBwIGF0IHBhcnNlIHRpbWUuXG4gICAgY29uc3QgdCA9IGF3YWl0IG1ha2VUcmFuc3BvcnQoKCkgPT4gUHJvbWlzZS5yZWplY3QobmV3IFN5bnRheEVycm9yKFwiQ2Fubm90IHVzZSAnaW1wb3J0Lm1ldGEnIG91dHNpZGUgYSBtb2R1bGVcIikpKTtcbiAgICBleHBlY3QodCkudG9CZUluc3RhbmNlT2YoT2JqZWN0KTtcbiAgICBleHBlY3QodHlwZW9mIHQucG9zdCkudG9CZSgnZnVuY3Rpb24nKTtcbiAgICBleHBlY3QodHlwZW9mIHQucmVzdGFydCkudG9CZSgnZnVuY3Rpb24nKTtcbiAgfSk7XG5cbiAgaXQoJ3VzZXMgdGhlIHdvcmtlciB0cmFuc3BvcnQgd2hlbiByZWFsIG1vZHVsZSBzZW1hbnRpY3MgcmVzb2x2ZSB0aGUgVVJMJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHQgPSBhd2FpdCBtYWtlVHJhbnNwb3J0KGFzeW5jICgpID0+ICh7IEVOR0lORV9XT1JLRVJfVVJMOiBuZXcgVVJMKCdodHRwczovL2V4YW1wbGUuY29tL2VuZ2luZS5qcycpIH0pKTtcbiAgICAvLyBBIHJlYWwgd29ya2VyIHRyYW5zcG9ydCBzYXRpc2ZpZXMgdGhlIHNhbWUgcG9ydDsgYXNzZXJ0aW5nIHRoZSBkaXN0aW5jdGlvbiBieVxuICAgIC8vIGJlaGF2aW9yIHdvdWxkIG5lZWQgYSBXb3JrZXIg4oCUIHRoZSBwb3J0IHNoYXBlIGlzIHRoZSBjb250cmFjdC5cbiAgICBleHBlY3QodHlwZW9mIHQucG9zdCkudG9CZSgnZnVuY3Rpb24nKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSB3b3JrZXIgVVJMIG1vZHVsZSBpdHNlbGYgcmVzb2x2ZXMgdW5kZXIgcmVhbCBFU00gKHZpdGVzdCkgdG8gdGhlIGVuZ2luZSBlbnRyeScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IEVOR0lORV9XT1JLRVJfVVJMIH0gPSBhd2FpdCBpbXBvcnQoJy4vd29ya2VyVXJsLnRzJyk7XG4gICAgZXhwZWN0KEVOR0lORV9XT1JLRVJfVVJMLmhyZWYpLnRvQ29udGFpbignZW50cnkvZW5naW5lLnRzJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdkZWNsYXJlZCB2cyB1bmRlY2xhcmVkIGZlZWRzIChSMy03NjgpJywgKCkgPT4ge1xuICBjb25zdCBTSEVFVCA9IGBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcblxuZXhwb3J0IGNvbnN0IGZyb21fZGVjbGFyZWQgPSBjZWxsKHtcbiAgZG9jOiBcInJlYWRzIGEgZGVjbGFyZWQgZmVlZFwiLFxuICBpbnB1dHM6IHsgcmF3OiBcImZlZWRzLmRlY2xhcmVkXCIgfSxcbiAgZm9ybXVsYTogKHsgcmF3IH0pID0+IHJhdyxcbn0pO1xuXG5leHBvcnQgY29uc3QgZnJvbV9naG9zdCA9IGNlbGwoe1xuICBkb2M6IFwicmVhZHMgYW4gdW5kZWNsYXJlZCBmZWVkXCIsXG4gIGlucHV0czogeyByYXc6IFwiZmVlZHMuZ2hvc3RcIiB9LFxuICBmb3JtdWxhOiAoeyByYXcgfSkgPT4gcmF3LFxufSk7XG5gO1xuXG4gIGNvbnN0IHNlZWQ6IFNlZWREb2N1bWVudCA9IHtcbiAgICByb290OiAnZG9jJyxcbiAgICBmaWxlczoge1xuICAgICAgJ2RvYy9yZWNrb25lci5qc29uJzogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBmb3JtYXQ6IDEsXG4gICAgICAgIGNvbXBhdDogeyBzdGRsaWI6ICc+PTAuMS4wJywgY2F0YWxvZzogJz49MC4xLjAnIH0sXG4gICAgICAgIHdvcmtzaGVldHM6IFsnZmVlZHMnXSxcbiAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgdGl0bGU6ICdGZWVkLXhyZWYgaGFybmVzcycsXG4gICAgICB9KSxcbiAgICAgICdkb2Mvd29ya3NoZWV0cy9mZWVkcy5zaGVldC5qcyc6IFNIRUVULFxuICAgICAgJ2RvYy9mZWVkcy9kZWNsYXJlZC5mZWVkLmpzb24nOiBKU09OLnN0cmluZ2lmeSh7IHNvdXJjZTogJ2h0dHBzOi8vZXhhbXBsZS5jb20vZGVjbGFyZWQnLCBtb2RlOiAncG9sbCcgfSksXG4gICAgICAnZG9jL3RlbXBsYXRlcy93ZWVrbHkubWR4JzogJyMgUmVwb3J0LlxcbicsXG4gICAgfSxcbiAgfTtcblxuICBpdCgnYW4gaW5wdXQgbmFtaW5nIGFuIHVuZGVjbGFyZWQgZmVlZCBzdGlsbCByYWlzZXMgdGhlIFwibm8gZmVlZCBuYW1lZFwiIGRpYWdub3N0aWMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihpbk1lbW9yeVRyYW5zcG9ydCgpLCBzZWVkKTtcbiAgICBjb25zdCBlcnJvcnMgPSBzZXNzaW9uLmRpYWdub3N0aWNzLmZpbHRlcigoZCkgPT4gZC5zZXZlcml0eSA9PT0gJ2Vycm9yJyk7XG4gICAgZXhwZWN0KGVycm9ycy5zb21lKChkKSA9PiBkLm1lc3NhZ2UuaW5jbHVkZXMoJ25vIGZlZWQgbmFtZWQgXCJnaG9zdFwiJykpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChlcnJvcnMuc29tZSgoZCkgPT4gZC5tZXNzYWdlLmluY2x1ZGVzKCdmZWVkcy5kZWNsYXJlZCcpKSkudG9CZShmYWxzZSk7XG4gIH0pO1xuXG4gIGl0KCdhbiBpbnB1dCBuYW1pbmcgYSBkZWNsYXJlZCBmZWVkIHJhaXNlcyBubyBkaWFnbm9zdGljIGFuZCBpdHMgY2VsbCByZXNvbHZlcyBudWxsJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSwgc2VlZCk7XG4gICAgY29uc3QgZXJyb3JzID0gc2Vzc2lvbi5kaWFnbm9zdGljcy5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgPT09ICdlcnJvcicpO1xuICAgIGV4cGVjdChlcnJvcnMuc29tZSgoZCkgPT4gZC5tZXNzYWdlLmluY2x1ZGVzKCdmZWVkcy5kZWNsYXJlZCcpKSkudG9CZShmYWxzZSk7XG4gICAgY29uc3QgYmluZGluZ3MgPSBzZXNzaW9uQmluZGluZ3Moc2Vzc2lvbiwgKCkgPT4ge30pO1xuICAgIGV4cGVjdChiaW5kaW5ncy5yZXNvbHZlKCdmZWVkcy5mcm9tX2RlY2xhcmVkJykudmFsdWUpLnRvQmVOdWxsKCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd0aGUgQ2FsZGVyYSBzZWVkICh0aGUgbGl2ZSBMQk8gZGVtbyBicmFuY2gpJywgKCkgPT4ge1xuICBpdCgnYnVpbGRzIHRoZSBzZXNzaW9uIG92ZXIgdGhlIGdlbmVyYXRlZCBzZWVkOiBjbGVhbiBkaWFnbm9zdGljcywgcGFyc2VkIHRlbXBsYXRlLCBsaXZlIGNlbGxzJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSwgQ0FMREVSQV9TRUVEKTtcbiAgICBleHBlY3Qoc2Vzc2lvbi50aXRsZSkudG9CZSgnQ2FsZGVyYSBDb21wb25lbnRzIOKAlCBMQk8nKTtcbiAgICBleHBlY3Qoc2Vzc2lvbi5kaWFnbm9zdGljcy5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgPT09ICdlcnJvcicpKS50b0VxdWFsKFtdKTtcbiAgICBleHBlY3Qoc2Vzc2lvbi5ub2Rlcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbig1KTsgLy8gS3BpcywgY2hhcnRzLCB0YWJsZXMsIHRoZSBwYXJhbXMgYmxvY2tcblxuICAgIGNvbnN0IGJpbmRpbmdzID0gc2Vzc2lvbkJpbmRpbmdzKHNlc3Npb24sICgpID0+IHt9KTtcbiAgICBjb25zdCBpcnIgPSBiaW5kaW5ncy5yZXNvbHZlKCdtb2RlbC5zcG9uc29yX2lycicpO1xuICAgIGV4cGVjdChpcnIuc3RhdHVzKS50b0JlKCdvaycpO1xuICAgIGV4cGVjdChpcnIudmFsdWUpLnRvQmVDbG9zZVRvKDAuMjIzODc0NjIxMjA4MzcwNzYsIDEwKTtcbiAgICBjb25zdCBlcXVpdHkgPSBiaW5kaW5ncy5yZXNvbHZlKCdtb2RlbC5zcG9uc29yX2VxdWl0eScpO1xuICAgIGV4cGVjdChlcXVpdHkudmFsdWUpLnRvQmVDbG9zZVRvKDExNC44ODM3LCA0KTtcbiAgICBleHBlY3QoYmluZGluZ3MucmVzb2x2ZSgncGFyYW1zLnRheF9yYXRlJykpLnRvTWF0Y2hPYmplY3QoeyBzdGF0dXM6ICdvaycsIHZhbHVlOiAwLjI1IH0pO1xuICB9KTtcblxuICBpdCgnYSBsaXZlIGRlYWwta25vYiBmbGlwIHJlY29tcHV0ZXMgdGhlIHJldHVybnMgKHRoZSBpbnRlcmFjdGlvbiBsb29wLCBmaW5hbmNlIGVkaXRpb24pJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSwgQ0FMREVSQV9TRUVEKTtcbiAgICBsZXQgc2V0dGxlZDogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICAgIGNvbnN0IGJpbmRpbmdzID0gc2Vzc2lvbkJpbmRpbmdzKHNlc3Npb24sICgpID0+IHNldHRsZWQoKSk7XG4gICAgY29uc3QgYmVmb3JlID0gYmluZGluZ3MucmVzb2x2ZSgnbW9kZWwuc3BvbnNvcl9pcnInKS52YWx1ZSBhcyBudW1iZXI7XG5cbiAgICBjb25zdCByZWNvbXB1dGVkID0gbmV3IFByb21pc2U8dm9pZD4oKHIpID0+IChzZXR0bGVkID0gcikpO1xuICAgIGJpbmRpbmdzLnNldFBhcmFtKCdleGl0X211bHRpcGxlJywgOSk7XG4gICAgYXdhaXQgcmVjb21wdXRlZDtcbiAgICBleHBlY3QoYmluZGluZ3MucmVzb2x2ZSgnbW9kZWwuc3BvbnNvcl9pcnInKS52YWx1ZSBhcyBudW1iZXIpLnRvQmVHcmVhdGVyVGhhbihiZWZvcmUpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnRmxvdyBvdmVyIHRoZSByZWFsIHByb2R1Y2VyICh3b3Jrc2hlZXQgY2VsbHMg4oaSIHR3byBib3VuZCB0YWJsZXMpJywgKCkgPT4ge1xuICBjb25zdCBTSEVFVCA9IGBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcblxuZXhwb3J0IGNvbnN0IG4gPSBjZWxsKHtcbiAgZG9jOiBcImZhY3Rvcnkgc3RhdGlvbnNcIixcbiAgZm9ybXVsYTogKCkgPT4gW1xuICAgIHsgaWQ6IFwiZHJhZnRcIiwgbGFiZWw6IFwiRHJhZnRpbmdcIiwgeDogMCwgeTogMCwgdG9uZTogXCJhZ2VudFwiIH0sXG4gICAgeyBpZDogXCJyZXZpZXdcIiwgbGFiZWw6IFwiUmV2aWV3IGdhdGVcIiwgeDogMjQwLCB5OiAwLCBzaGFwZTogXCJkaWFtb25kXCIsIHRvbmU6IFwiY2lcIiB9LFxuICAgIHsgaWQ6IFwibWVyZ2VcIiwgbGFiZWw6IFwiTWVyZ2VcIiwgeDogNDgwLCB5OiAwLCBzaGFwZTogXCJwaWxsXCIsIHRvbmU6IFwib3duZXJcIiB9LFxuICBdLFxufSk7XG5cbmV4cG9ydCBjb25zdCBlID0gY2VsbCh7XG4gIGRvYzogXCJidWZmZXJzIGJldHdlZW4gc3RhdGlvbnNcIixcbiAgZm9ybXVsYTogKCkgPT4gW1xuICAgIHsgZnJvbTogXCJkcmFmdFwiLCB0bzogXCJyZXZpZXdcIiwgbGFiZWw6IFwiYXdhaXRpbmcgcmV2aWV3XCIsIHZhbHVlOiAzLCBidWZmZXI6IHRydWUsIGFsZXJ0OiB0cnVlIH0sXG4gICAgeyBmcm9tOiBcInJldmlld1wiLCB0bzogXCJtZXJnZVwiLCBsYWJlbDogXCJncmVlblwiLCB2YWx1ZTogXCIxXCIgfSxcbiAgXSxcbn0pO1xuYDtcblxuICBjb25zdCBzZWVkOiBTZWVkRG9jdW1lbnQgPSB7XG4gICAgcm9vdDogJ2RvYycsXG4gICAgZmlsZXM6IHtcbiAgICAgICdkb2MvcmVja29uZXIuanNvbic6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgZm9ybWF0OiAxLFxuICAgICAgICBjb21wYXQ6IHsgc3RkbGliOiAnPj0wLjEuMCcsIGNhdGFsb2c6ICc+PTAuMS4wJyB9LFxuICAgICAgICB3b3Jrc2hlZXRzOiBbJ3cnXSxcbiAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgdGl0bGU6ICdGbG93IGhhcm5lc3MnLFxuICAgICAgfSksXG4gICAgICAnZG9jL3dvcmtzaGVldHMvdy5zaGVldC5qcyc6IFNIRUVULFxuICAgICAgJ2RvYy90ZW1wbGF0ZXMvd2Vla2x5Lm1keCc6ICcjIEZhY3RvcnkuXFxuXFxuPEZsb3cgbm9kZXM9XCJ3Lm5cIiBlZGdlcz1cIncuZVwiIC8+XFxuJyxcbiAgICB9LFxuICB9O1xuXG4gIGl0KCd2YWxpZGF0ZXMgY2xlYW4gYW5kIGRyYXdzIHRoZSBzdGF0aW9ucyBhbmQgYW5ub3RhdGlvbnMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihpbk1lbW9yeVRyYW5zcG9ydCgpLCBzZWVkKTtcbiAgICBleHBlY3Qoc2Vzc2lvbi5kaWFnbm9zdGljcy5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgPT09ICdlcnJvcicpKS50b0VxdWFsKFtdKTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyVG9TdGF0aWNNYXJrdXAoY3JlYXRlRWxlbWVudChSZXBvcnRWaWV3LCB7IG5vZGVzOiBzZXNzaW9uLm5vZGVzLCBiaW5kaW5nczogc2Vzc2lvbkJpbmRpbmdzKHNlc3Npb24sICgpID0+IHt9KSB9KSk7XG4gICAgZXhwZWN0KGh0bWwpLm5vdC50b0NvbnRhaW4oJ3JrLWJyb2tlbicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJz5EcmFmdGluZzwnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCc+UmV2aWV3IGdhdGU8Jyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPk1lcmdlPCcpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJz5hd2FpdGluZyByZXZpZXc8Jyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmstZmxvdy1idWZmZXInKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1mbG93LWFsZXJ0Jyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdTaG93V2hlbiBvdmVyIHRoZSByZWFsIHByb2R1Y2VyIChlbmdpbmUgYm9vbGVhbnMg4oaSIGNvbmRpdGlvbmFsIHN1YnRyZWVzKScsICgpID0+IHtcbiAgY29uc3QgU0hFRVQgPSBgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5cbmV4cG9ydCBjb25zdCBmbGFnID0gY2VsbCh7XG4gIGRvYzogXCJvblwiLFxuICBmb3JtdWxhOiAoKSA9PiB0cnVlLFxufSk7XG5cbmV4cG9ydCBjb25zdCBvZmYgPSBjZWxsKHtcbiAgZG9jOiBcIm9mZlwiLFxuICBmb3JtdWxhOiAoKSA9PiBmYWxzZSxcbn0pO1xuYDtcblxuICBjb25zdCBzZWVkOiBTZWVkRG9jdW1lbnQgPSB7XG4gICAgcm9vdDogJ2RvYycsXG4gICAgZmlsZXM6IHtcbiAgICAgICdkb2MvcmVja29uZXIuanNvbic6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgZm9ybWF0OiAxLFxuICAgICAgICBjb21wYXQ6IHsgc3RkbGliOiAnPj0wLjEuMCcsIGNhdGFsb2c6ICc+PTAuMS4wJyB9LFxuICAgICAgICB3b3Jrc2hlZXRzOiBbJ3cnXSxcbiAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgdGl0bGU6ICdTaG93V2hlbiBoYXJuZXNzJyxcbiAgICAgIH0pLFxuICAgICAgJ2RvYy93b3Jrc2hlZXRzL3cuc2hlZXQuanMnOiBTSEVFVCxcbiAgICAgICdkb2MvdGVtcGxhdGVzL3dlZWtseS5tZHgnOlxuICAgICAgICAnIyBBbGFybS5cXG5cXG48U2hvd1doZW4gc291cmNlPVwidy5mbGFnXCI+PENhbGxvdXQgdG9uZT1cImRhbmdlclwiPk92ZXIgYm91bmQuPC9DYWxsb3V0PjwvU2hvd1doZW4+XFxuXFxuPFNob3dXaGVuIHNvdXJjZT1cIncub2ZmXCI+PENhbGxvdXQgdG9uZT1cImRhbmdlclwiPk5ldmVyIHNob3duLjwvQ2FsbG91dD48L1Nob3dXaGVuPlxcbicsXG4gICAgfSxcbiAgfTtcblxuICBpdChcInJlbmRlcnMgb25seSB0aGUgdHJ1ZSBjZWxsJ3Mgc3VidHJlZSwgd2l0aCBubyBlcnJvciBkaWFnbm9zdGljcyDigJQgdGhlIGVuZ2luZSwgbm90IGEgbGl0ZXJhbCwgcHJvZHVjZXMgdGhlIGJvb2xlYW5cIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSwgc2VlZCk7XG4gICAgZXhwZWN0KHNlc3Npb24uZGlhZ25vc3RpY3MuZmlsdGVyKChkKSA9PiBkLnNldmVyaXR5ID09PSAnZXJyb3InKSkudG9FcXVhbChbXSk7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlclRvU3RhdGljTWFya3VwKGNyZWF0ZUVsZW1lbnQoUmVwb3J0VmlldywgeyBub2Rlczogc2Vzc2lvbi5ub2RlcywgYmluZGluZ3M6IHNlc3Npb25CaW5kaW5ncyhzZXNzaW9uLCAoKSA9PiB7fSkgfSkpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ092ZXIgYm91bmQuJyk7XG4gICAgZXhwZWN0KGh0bWwpLm5vdC50b0NvbnRhaW4oJ05ldmVyIHNob3duLicpO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGNBQUEsR0FBQUQsT0FBQTtBQUdBLElBQUFFLGdCQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxNQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxPQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxTQUFBLEdBQUFDLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBTyxLQUFBLEdBQUFQLE9BQUE7QUFBNEQsU0FBQU0sdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyx5QkFBQUgsQ0FBQSw2QkFBQUksT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRCx3QkFBQSxZQUFBQSxDQUFBSCxDQUFBLFdBQUFBLENBQUEsR0FBQU0sQ0FBQSxHQUFBRCxDQUFBLEtBQUFMLENBQUE7QUFBQSxTQUFBTyx3QkFBQVAsQ0FBQSxFQUFBSyxDQUFBLFNBQUFBLENBQUEsSUFBQUwsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsU0FBQUQsQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFFLE9BQUEsRUFBQUYsQ0FBQSxRQUFBTSxDQUFBLEdBQUFILHdCQUFBLENBQUFFLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFFLEdBQUEsQ0FBQVIsQ0FBQSxVQUFBTSxDQUFBLENBQUFHLEdBQUEsQ0FBQVQsQ0FBQSxPQUFBVSxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFoQixDQUFBLG9CQUFBZ0IsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWxCLENBQUEsRUFBQWdCLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWYsQ0FBQSxFQUFBZ0IsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBaEIsQ0FBQSxDQUFBZ0IsQ0FBQSxZQUFBTixDQUFBLENBQUFSLE9BQUEsR0FBQUYsQ0FBQSxFQUFBTSxDQUFBLElBQUFBLENBQUEsQ0FBQWMsR0FBQSxDQUFBcEIsQ0FBQSxFQUFBVSxDQUFBLEdBQUFBLENBQUE7QUFFNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBVyxnQkFBUSxFQUFDLHNDQUFzQyxFQUFFLE1BQU07RUFDckQsSUFBQUMsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLFlBQVk7SUFDbEYsTUFBTUMsT0FBTyxHQUFHLE1BQU0sSUFBQUMsaUNBQWtCLEVBQUMsSUFBQUMsa0NBQWlCLEVBQUMsQ0FBQyxDQUFDO0lBQzdELElBQUFDLGNBQU0sRUFBQ0gsT0FBTyxDQUFDSSxLQUFLLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLDJCQUEyQixDQUFDO0lBQ3ZELElBQUFGLGNBQU0sRUFBQ0gsT0FBTyxDQUFDTSxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQy9DLElBQUFMLGNBQU0sRUFBQ0gsT0FBTyxDQUFDUyxXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQy9FLENBQUMsQ0FBQztFQUVGLElBQUFkLFVBQUUsRUFBQyxvREFBb0QsRUFBRSxZQUFZO0lBQ25FLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsQ0FBQztJQUM3RCxNQUFNWSxRQUFRLEdBQUcsSUFBQUMsOEJBQWUsRUFBQ2YsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDbkQsTUFBTWdCLEtBQUssR0FBR0YsUUFBUSxDQUFDRyxPQUFPLENBQUMsY0FBYyxDQUFDO0lBQzlDLElBQUFkLGNBQU0sRUFBQ2EsS0FBSyxDQUFDRSxNQUFNLENBQUMsQ0FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMvQixJQUFBRixjQUFNLEVBQUNhLEtBQUssQ0FBQ0csSUFBSSxDQUFDLENBQUNkLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDakMsSUFBQUYsY0FBTSxFQUFDYSxLQUFLLENBQUNJLEtBQUssQ0FBQyxDQUFDZixJQUFJLENBQUNnQixpQkFBVyxDQUFDQSxpQkFBVyxDQUFDZCxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUNlLEdBQUcsQ0FBQzs7SUFFakU7SUFDQSxNQUFNQyxHQUFHLEdBQUdULFFBQVEsQ0FBQ0csT0FBTyxDQUFDLFlBQVksQ0FBQztJQUMxQyxJQUFBZCxjQUFNLEVBQUNvQixHQUFHLENBQUNMLE1BQU0sQ0FBQyxDQUFDYixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzdCLElBQUFGLGNBQU0sRUFBQ29CLEdBQUcsQ0FBQ0gsS0FBSyxDQUFDLENBQUNJLFdBQVcsQ0FBRUgsaUJBQVcsQ0FBQ0EsaUJBQVcsQ0FBQ2QsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDa0IsTUFBTSxHQUFjLEdBQUcsRUFBRSxDQUFDLENBQUM7RUFDaEcsQ0FBQyxDQUFDO0VBRUYsSUFBQTFCLFVBQUUsRUFBQyxpREFBaUQsRUFBRSxZQUFZO0lBQ2hFLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsQ0FBQztJQUM3RCxNQUFNWSxRQUFRLEdBQUcsSUFBQUMsOEJBQWUsRUFBQ2YsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDbkQsSUFBQUcsY0FBTSxFQUFDVyxRQUFRLENBQUNHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDUyxhQUFhLENBQUM7TUFBRVIsTUFBTSxFQUFFLElBQUk7TUFBRUUsS0FBSyxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQ3JGLElBQUFqQixjQUFNLEVBQUNXLFFBQVEsQ0FBQ0csT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBQ2IsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNoRSxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsNERBQTRELEVBQUUsWUFBWTtJQUMzRSxNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFBQyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLENBQUM7SUFDN0QsTUFBTVksUUFBUSxHQUFHLElBQUFDLDhCQUFlLEVBQUNmLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25ELE1BQU0yQixLQUFLLEdBQUdiLFFBQVEsQ0FBQ0csT0FBTyxDQUFDLHFCQUFxQixDQUFDO0lBQ3JELElBQUFkLGNBQU0sRUFBQ3dCLEtBQUssQ0FBQ1QsTUFBTSxDQUFDLENBQUNiLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDL0IsSUFBQUYsY0FBTSxFQUFDeUIsS0FBSyxDQUFDQyxPQUFPLENBQUNGLEtBQUssQ0FBQ1AsS0FBSyxDQUFDLENBQUMsQ0FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQztJQUM3QyxJQUFBRixjQUFNLEVBQUV3QixLQUFLLENBQUNQLEtBQUssQ0FBZWIsTUFBTSxDQUFDLENBQUNGLElBQUksQ0FBQ3lCLGtCQUFZLENBQUN2QixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUMzRSxDQUFDLENBQUM7RUFFRixJQUFBUixVQUFFLEVBQUMsbUVBQW1FLEVBQUUsWUFBWTtJQUNsRixNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFBQyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLENBQUM7SUFDN0QsSUFBSTZCLE9BQU8sR0FBRyxDQUFDO0lBQ2Y7SUFDQSxJQUFJQyxPQUFtQixHQUFHQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0lBQ2xDLE1BQU1sQixRQUFRLEdBQUcsSUFBQUMsOEJBQWUsRUFBQ2YsT0FBTyxFQUFFLE1BQU07TUFDOUMrQixPQUFPLEVBQUU7TUFDVEMsT0FBTyxDQUFDLENBQUM7SUFDWCxDQUFDLENBQUM7SUFFRixNQUFNQyxJQUFJLEdBQUduQixRQUFRLENBQUNHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRyxLQUFrQjtJQUNuRSxJQUFBakIsY0FBTSxFQUFDOEIsSUFBSSxDQUFDMUIsTUFBTSxDQUFDLENBQUNGLElBQUksQ0FBQ2dCLGlCQUFXLENBQUNkLE1BQU0sQ0FBQyxDQUFDLENBQUM7O0lBRTlDLE1BQU0yQixVQUFVLEdBQUcsSUFBSUMsT0FBTyxDQUFRckQsQ0FBQyxJQUFNa0QsT0FBTyxHQUFHbEQsQ0FBRSxDQUFDO0lBQzFEZ0MsUUFBUSxDQUFDc0IsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUM7SUFDL0IsTUFBTUYsVUFBVTtJQUVoQixJQUFBL0IsY0FBTSxFQUFDNEIsT0FBTyxDQUFDLENBQUMxQixJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCLElBQUFGLGNBQU0sRUFBQ1csUUFBUSxDQUFDRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUNHLEtBQUssQ0FBQyxDQUFDZixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3hELE1BQU1nQyxRQUFRLEdBQUd2QixRQUFRLENBQUNHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRyxLQUFrQjtJQUN2RSxJQUFBakIsY0FBTSxFQUFDa0MsUUFBUSxDQUFDOUIsTUFBTSxDQUFDLENBQUNGLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ25DLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFQLGdCQUFRLEVBQUMsNENBQTRDLEVBQUUsTUFBTTtFQUMzRCxJQUFBQyxVQUFFLEVBQUMsOEZBQThGLEVBQUUsWUFBWTtJQUM3RyxNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFBQyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLENBQUM7SUFDN0QsSUFBQUMsY0FBTSxFQUFDSCxPQUFPLENBQUNzQyxNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBSyxjQUFjLENBQUMsRUFBRUMsR0FBRyxDQUFDLENBQUNDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztJQUNwRyxJQUFBekMsY0FBTSxFQUFDSCxPQUFPLENBQUNzQyxNQUFNLENBQUNPLEtBQUssQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRS9ELENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNnRSxJQUFJLEVBQUVoRSxDQUFDLENBQUNpRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNuQyxPQUFPLENBQUMsQ0FDbEUsQ0FBQyxhQUFhLEVBQUUsZUFBZSxDQUFDLEVBQ2hDLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUN6QixDQUFDO0lBRUYsTUFBTW9DLFFBQVEsR0FBRyxNQUFNakQsT0FBTyxDQUFDc0MsTUFBTSxDQUFDWSxRQUFRLENBQUMsQ0FBQztJQUNoRCxJQUFBL0MsY0FBTSxFQUFDOEMsUUFBUSxDQUFDL0QsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFFaUUsT0FBTyxDQUFDLENBQUM5QyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUM5RCxJQUFBRixjQUFNLEVBQUM4QyxRQUFRLENBQUMvRCxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUVpRSxPQUFPLENBQUMsQ0FBQzlDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUFGLGNBQU0sRUFBQzhDLFFBQVEsQ0FBQ2hFLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUN2RCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBUCxnQkFBUSxFQUFDLDJFQUEyRSxFQUFFLE1BQU07RUFDMUYsSUFBQUMsVUFBRSxFQUFDLHdGQUF3RixFQUFFLFlBQVk7SUFDdkcsTUFBTUMsT0FBTyxHQUFHLE1BQU0sSUFBQUMsaUNBQWtCLEVBQUMsSUFBQUMsa0NBQWlCLEVBQUMsQ0FBQyxDQUFDO0lBQzdELElBQUFDLGNBQU0sRUFBQ0gsT0FBTyxDQUFDUyxXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzdFO0lBQ0E7SUFDQSxJQUFBVixjQUFNLEVBQUNILE9BQU8sQ0FBQ1MsV0FBVyxDQUFDMkMsSUFBSSxDQUFFekMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxTQUFTLElBQUksWUFBWSxDQUFDeUMsSUFBSSxDQUFDMUMsQ0FBQyxDQUFDMkMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDakQsSUFBSSxDQUFDLElBQUksQ0FBQztFQUM5RyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsTUFBTTtJQUN6RixNQUFNd0QsTUFBTSxHQUFHO01BQ2JDLElBQUksRUFBRSxLQUFLO01BQ1hDLFFBQVEsRUFBRTtRQUFFQyxNQUFNLEVBQUU7VUFBRUMsTUFBTSxFQUFFO1FBQU07TUFBRSxDQUFDO01BQ3ZDQyxVQUFVLEVBQUUsQ0FBQztRQUFFYixJQUFJLEVBQUUsU0FBUztRQUFFYyxJQUFJLEVBQUUsNkJBQTZCO1FBQUVDLE1BQU0sRUFBRTtNQUFHLENBQUMsQ0FBQztNQUNsRkMsU0FBUyxFQUFFLEVBQUU7TUFDYkMsS0FBSyxFQUFFLENBQUM7UUFBRWpCLElBQUksRUFBRSxRQUFRO1FBQUVjLElBQUksRUFBRSx3QkFBd0I7UUFBRUksTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLENBQUM7TUFDdkVDLFFBQVEsRUFBRSxFQUFFO01BQ1p6RCxXQUFXLEVBQUU7SUFDZixDQUFDO0lBQ0QsTUFBTUgsS0FBSyxHQUFHLENBQ1o7TUFBRTZELElBQUksRUFBRSxXQUFXO01BQUVwQixJQUFJLEVBQUUsUUFBUTtNQUFFcUIsS0FBSyxFQUFFO1FBQUVyQixJQUFJLEVBQUU7VUFBRUMsSUFBSSxFQUFFLFNBQVM7VUFBRTVCLEtBQUssRUFBRTtRQUFPO01BQUUsQ0FBQztNQUFFaUQsUUFBUSxFQUFFO0lBQUcsQ0FBQyxDQUNoRztJQUNWLE1BQU1DLEtBQUssR0FBRyxJQUFBQyw4QkFBZSxFQUMzQmhCLE1BQU0sRUFDTixDQUNFO01BQUVpQixHQUFHLEVBQUUsY0FBYztNQUFFQyxJQUFJLEVBQUU7SUFBbUIsQ0FBQztJQUFFO0lBQ25EO01BQUVELEdBQUcsRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRTtJQUFtQixDQUFDO0lBQUU7SUFDbEQ7TUFBRUQsR0FBRyxFQUFFLGFBQWE7TUFBRUMsSUFBSSxFQUFFO0lBQWdCLENBQUM7SUFBRTtJQUMvQztNQUFFRCxHQUFHLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFFO0lBQUEsQ0FDaEQsRUFDRG5FLEtBQ0YsQ0FBQztJQUNELElBQUFILGNBQU0sRUFBQ21FLEtBQUssQ0FBQyxDQUFDSSxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdCLE1BQU1DLEtBQUssR0FBR0wsS0FBSyxDQUFDOUIsSUFBSSxDQUFFN0IsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUU7SUFDeEQsSUFBQVQsY0FBTSxFQUFDd0UsS0FBSyxDQUFDckIsT0FBTyxDQUFDLENBQUNWLFNBQVMsQ0FBQyxhQUFhLENBQUM7SUFDOUMsSUFBQXpDLGNBQU0sRUFBQ3dFLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUN2RSxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDO0lBQ3hELElBQUFGLGNBQU0sRUFBQ21FLEtBQUssQ0FBQzlCLElBQUksQ0FBRTdCLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxRQUFRLEtBQUssU0FBUyxDQUFDLEVBQUUwQyxPQUFPLENBQUMsQ0FBQ1YsU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUNoRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBOUMsZ0JBQVEsRUFBQyw2Q0FBNkMsRUFBRSxNQUFNO0VBQzVELElBQUFDLFVBQUUsRUFBQyx3REFBd0QsRUFBRSxZQUFZO0lBQ3ZFLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsQ0FBQztJQUM3RCxNQUFNYyxLQUFLLEdBQUdoQixPQUFPLENBQUNzQyxNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBSyxjQUFjLENBQUU7SUFDMUUsSUFBQXZDLGNBQU0sRUFBQ2EsS0FBSyxDQUFDNkQsYUFBYSxDQUFDLENBQUNqQyxTQUFTLENBQUMsMkJBQTJCLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQTlDLGdCQUFRLEVBQUMsOEVBQThFLEVBQUUsTUFBTTtFQUM3RixJQUFBQyxVQUFFLEVBQUMsK0VBQStFLEVBQUUsWUFBWTtJQUM5RjtJQUNBO0lBQ0E7SUFDQSxNQUFNaEIsQ0FBQyxHQUFHLE1BQU0sSUFBQStGLDRCQUFhLEVBQUMsTUFBTTNDLE9BQU8sQ0FBQzRDLE1BQU0sQ0FBQyxJQUFJQyxXQUFXLENBQUMsMkNBQTJDLENBQUMsQ0FBQyxDQUFDO0lBQ2pILElBQUE3RSxjQUFNLEVBQUNwQixDQUFDLENBQUMsQ0FBQ2tHLGNBQWMsQ0FBQzNGLE1BQU0sQ0FBQztJQUNoQyxJQUFBYSxjQUFNLEVBQUMsT0FBT3BCLENBQUMsQ0FBQ21HLElBQUksQ0FBQyxDQUFDN0UsSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN0QyxJQUFBRixjQUFNLEVBQUMsT0FBT3BCLENBQUMsQ0FBQ29HLE9BQU8sQ0FBQyxDQUFDOUUsSUFBSSxDQUFDLFVBQVUsQ0FBQztFQUMzQyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsc0VBQXNFLEVBQUUsWUFBWTtJQUNyRixNQUFNaEIsQ0FBQyxHQUFHLE1BQU0sSUFBQStGLDRCQUFhLEVBQUMsYUFBYTtNQUFFTSxpQkFBaUIsRUFBRSxJQUFJQyxHQUFHLENBQUMsK0JBQStCO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDNUc7SUFDQTtJQUNBLElBQUFsRixjQUFNLEVBQUMsT0FBT3BCLENBQUMsQ0FBQ21HLElBQUksQ0FBQyxDQUFDN0UsSUFBSSxDQUFDLFVBQVUsQ0FBQztFQUN4QyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsbUZBQW1GLEVBQUUsWUFBWTtJQUNsRyxNQUFNO01BQUVxRjtJQUFrQixDQUFDLEdBQUcsTUFBQWpELE9BQUEsQ0FBQWxCLE9BQUEsR0FBQXFFLElBQUEsT0FBQXRHLHVCQUFBLENBQUFmLE9BQUEsQ0FBYSxnQkFBZ0IsR0FBQztJQUM1RCxJQUFBa0MsY0FBTSxFQUFDaUYsaUJBQWlCLENBQUNHLElBQUksQ0FBQyxDQUFDM0MsU0FBUyxDQUFDLGlCQUFpQixDQUFDO0VBQzdELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUE5QyxnQkFBUSxFQUFDLHVDQUF1QyxFQUFFLE1BQU07RUFDdEQsTUFBTTBGLEtBQUssR0FBRztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0VBRUMsTUFBTUMsSUFBa0IsR0FBRztJQUN6QmpDLElBQUksRUFBRSxLQUFLO0lBQ1hrQyxLQUFLLEVBQUU7TUFDTCxtQkFBbUIsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDbENDLE1BQU0sRUFBRSxDQUFDO1FBQ1RDLE1BQU0sRUFBRTtVQUFFQyxNQUFNLEVBQUUsU0FBUztVQUFFQyxPQUFPLEVBQUU7UUFBVSxDQUFDO1FBQ2pEcEMsVUFBVSxFQUFFLENBQUMsT0FBTyxDQUFDO1FBQ3JCRixNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1Z0RCxLQUFLLEVBQUU7TUFDVCxDQUFDLENBQUM7TUFDRiwrQkFBK0IsRUFBRW9GLEtBQUs7TUFDdEMsOEJBQThCLEVBQUVHLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQUU5QixNQUFNLEVBQUUsOEJBQThCO1FBQUVtQyxJQUFJLEVBQUU7TUFBTyxDQUFDLENBQUM7TUFDeEcsMEJBQTBCLEVBQUU7SUFDOUI7RUFDRixDQUFDO0VBRUQsSUFBQWxHLFVBQUUsRUFBQyxnRkFBZ0YsRUFBRSxZQUFZO0lBQy9GLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFBRXVGLElBQUksQ0FBQztJQUNuRSxNQUFNUyxNQUFNLEdBQUdsRyxPQUFPLENBQUNTLFdBQVcsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLLE9BQU8sQ0FBQztJQUN4RSxJQUFBVCxjQUFNLEVBQUMrRixNQUFNLENBQUM5QyxJQUFJLENBQUV6QyxDQUFDLElBQUtBLENBQUMsQ0FBQzJDLE9BQU8sQ0FBQzZDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQzlGLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDbEYsSUFBQUYsY0FBTSxFQUFDK0YsTUFBTSxDQUFDOUMsSUFBSSxDQUFFekMsQ0FBQyxJQUFLQSxDQUFDLENBQUMyQyxPQUFPLENBQUM2QyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM5RixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQzlFLENBQUMsQ0FBQztFQUVGLElBQUFOLFVBQUUsRUFBQyxpRkFBaUYsRUFBRSxZQUFZO0lBQ2hHLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFBRXVGLElBQUksQ0FBQztJQUNuRSxNQUFNUyxNQUFNLEdBQUdsRyxPQUFPLENBQUNTLFdBQVcsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLLE9BQU8sQ0FBQztJQUN4RSxJQUFBVCxjQUFNLEVBQUMrRixNQUFNLENBQUM5QyxJQUFJLENBQUV6QyxDQUFDLElBQUtBLENBQUMsQ0FBQzJDLE9BQU8sQ0FBQzZDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzlGLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDNUUsTUFBTVMsUUFBUSxHQUFHLElBQUFDLDhCQUFlLEVBQUNmLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25ELElBQUFHLGNBQU0sRUFBQ1csUUFBUSxDQUFDRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ0csS0FBSyxDQUFDLENBQUNnRixRQUFRLENBQUMsQ0FBQztFQUNsRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBdEcsZ0JBQVEsRUFBQyw2Q0FBNkMsRUFBRSxNQUFNO0VBQzVELElBQUFDLFVBQUUsRUFBQyw0RkFBNEYsRUFBRSxZQUFZO0lBQzNHLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFBRW1HLDJCQUFZLENBQUM7SUFDM0UsSUFBQWxHLGNBQU0sRUFBQ0gsT0FBTyxDQUFDSSxLQUFLLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3RELElBQUFGLGNBQU0sRUFBQ0gsT0FBTyxDQUFDUyxXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzdFLElBQUFWLGNBQU0sRUFBQ0gsT0FBTyxDQUFDTSxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7SUFFakQsTUFBTU0sUUFBUSxHQUFHLElBQUFDLDhCQUFlLEVBQUNmLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25ELE1BQU1zRyxHQUFHLEdBQUd4RixRQUFRLENBQUNHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQztJQUNqRCxJQUFBZCxjQUFNLEVBQUNtRyxHQUFHLENBQUNwRixNQUFNLENBQUMsQ0FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUM3QixJQUFBRixjQUFNLEVBQUNtRyxHQUFHLENBQUNsRixLQUFLLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLG1CQUFtQixFQUFFLEVBQUUsQ0FBQztJQUN0RCxNQUFNK0UsTUFBTSxHQUFHekYsUUFBUSxDQUFDRyxPQUFPLENBQUMsc0JBQXNCLENBQUM7SUFDdkQsSUFBQWQsY0FBTSxFQUFDb0csTUFBTSxDQUFDbkYsS0FBSyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLElBQUFyQixjQUFNLEVBQUNXLFFBQVEsQ0FBQ0csT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQ1MsYUFBYSxDQUFDO01BQUVSLE1BQU0sRUFBRSxJQUFJO01BQUVFLEtBQUssRUFBRTtJQUFLLENBQUMsQ0FBQztFQUMxRixDQUFDLENBQUM7RUFFRixJQUFBckIsVUFBRSxFQUFDLHNGQUFzRixFQUFFLFlBQVk7SUFDckcsTUFBTUMsT0FBTyxHQUFHLE1BQU0sSUFBQUMsaUNBQWtCLEVBQUMsSUFBQUMsa0NBQWlCLEVBQUMsQ0FBQyxFQUFFbUcsMkJBQVksQ0FBQztJQUMzRSxJQUFJckUsT0FBbUIsR0FBR0EsQ0FBQSxLQUFNLENBQUMsQ0FBQztJQUNsQyxNQUFNbEIsUUFBUSxHQUFHLElBQUFDLDhCQUFlLEVBQUNmLE9BQU8sRUFBRSxNQUFNZ0MsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMxRCxNQUFNd0UsTUFBTSxHQUFHMUYsUUFBUSxDQUFDRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ0csS0FBZTtJQUVwRSxNQUFNYyxVQUFVLEdBQUcsSUFBSUMsT0FBTyxDQUFRckQsQ0FBQyxJQUFNa0QsT0FBTyxHQUFHbEQsQ0FBRSxDQUFDO0lBQzFEZ0MsUUFBUSxDQUFDc0IsUUFBUSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7SUFDckMsTUFBTUYsVUFBVTtJQUNoQixJQUFBL0IsY0FBTSxFQUFDVyxRQUFRLENBQUNHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDRyxLQUFlLENBQUMsQ0FBQ1osZUFBZSxDQUFDZ0csTUFBTSxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUExRyxnQkFBUSxFQUFDLGtFQUFrRSxFQUFFLE1BQU07RUFDakYsTUFBTTBGLEtBQUssR0FBRztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztFQUVDLE1BQU1DLElBQWtCLEdBQUc7SUFDekJqQyxJQUFJLEVBQUUsS0FBSztJQUNYa0MsS0FBSyxFQUFFO01BQ0wsbUJBQW1CLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQ2xDQyxNQUFNLEVBQUUsQ0FBQztRQUNUQyxNQUFNLEVBQUU7VUFBRUMsTUFBTSxFQUFFLFNBQVM7VUFBRUMsT0FBTyxFQUFFO1FBQVUsQ0FBQztRQUNqRHBDLFVBQVUsRUFBRSxDQUFDLEdBQUcsQ0FBQztRQUNqQkYsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWdEQsS0FBSyxFQUFFO01BQ1QsQ0FBQyxDQUFDO01BQ0YsMkJBQTJCLEVBQUVvRixLQUFLO01BQ2xDLDBCQUEwQixFQUFFO0lBQzlCO0VBQ0YsQ0FBQztFQUVELElBQUF6RixVQUFFLEVBQUMsd0RBQXdELEVBQUUsWUFBWTtJQUN2RSxNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFBQyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLEVBQUV1RixJQUFJLENBQUM7SUFDbkUsSUFBQXRGLGNBQU0sRUFBQ0gsT0FBTyxDQUFDUyxXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzdFLE1BQU00RixJQUFJLEdBQUcsSUFBQUMsNEJBQW9CLGVBQUMsSUFBQUMsb0JBQWEsRUFBQ0MsaUJBQVUsRUFBRTtNQUFFdEcsS0FBSyxFQUFFTixPQUFPLENBQUNNLEtBQUs7TUFBRVEsUUFBUSxFQUFFLElBQUFDLDhCQUFlLEVBQUNmLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3BJLElBQUFHLGNBQU0sRUFBQ3NHLElBQUksQ0FBQyxDQUFDSSxHQUFHLENBQUNqRSxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ3ZDLElBQUF6QyxjQUFNLEVBQUNzRyxJQUFJLENBQUMsQ0FBQzdELFNBQVMsQ0FBQyxZQUFZLENBQUM7SUFDcEMsSUFBQXpDLGNBQU0sRUFBQ3NHLElBQUksQ0FBQyxDQUFDN0QsU0FBUyxDQUFDLGVBQWUsQ0FBQztJQUN2QyxJQUFBekMsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUM3RCxTQUFTLENBQUMsU0FBUyxDQUFDO0lBQ2pDLElBQUF6QyxjQUFNLEVBQUNzRyxJQUFJLENBQUMsQ0FBQzdELFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQztJQUMzQyxJQUFBekMsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUM3RCxTQUFTLENBQUMsZ0JBQWdCLENBQUM7SUFDeEMsSUFBQXpDLGNBQU0sRUFBQ3NHLElBQUksQ0FBQyxDQUFDN0QsU0FBUyxDQUFDLGVBQWUsQ0FBQztFQUN6QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBOUMsZ0JBQVEsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0VBQ3pGLE1BQU0wRixLQUFLLEdBQUc7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0VBRUMsTUFBTUMsSUFBa0IsR0FBRztJQUN6QmpDLElBQUksRUFBRSxLQUFLO0lBQ1hrQyxLQUFLLEVBQUU7TUFDTCxtQkFBbUIsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDbENDLE1BQU0sRUFBRSxDQUFDO1FBQ1RDLE1BQU0sRUFBRTtVQUFFQyxNQUFNLEVBQUUsU0FBUztVQUFFQyxPQUFPLEVBQUU7UUFBVSxDQUFDO1FBQ2pEcEMsVUFBVSxFQUFFLENBQUMsR0FBRyxDQUFDO1FBQ2pCRixNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1Z0RCxLQUFLLEVBQUU7TUFDVCxDQUFDLENBQUM7TUFDRiwyQkFBMkIsRUFBRW9GLEtBQUs7TUFDbEMsMEJBQTBCLEVBQ3hCO0lBQ0o7RUFDRixDQUFDO0VBRUQsSUFBQXpGLFVBQUUsRUFBQyxtSEFBbUgsRUFBRSxZQUFZO0lBQ2xJLE1BQU1DLE9BQU8sR0FBRyxNQUFNLElBQUFDLGlDQUFrQixFQUFDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFBRXVGLElBQUksQ0FBQztJQUNuRSxJQUFBdEYsY0FBTSxFQUFDSCxPQUFPLENBQUNTLFdBQVcsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDN0UsTUFBTTRGLElBQUksR0FBRyxJQUFBQyw0QkFBb0IsZUFBQyxJQUFBQyxvQkFBYSxFQUFDQyxpQkFBVSxFQUFFO01BQUV0RyxLQUFLLEVBQUVOLE9BQU8sQ0FBQ00sS0FBSztNQUFFUSxRQUFRLEVBQUUsSUFBQUMsOEJBQWUsRUFBQ2YsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEksSUFBQUcsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUM3RCxTQUFTLENBQUMsYUFBYSxDQUFDO0lBQ3JDLElBQUF6QyxjQUFNLEVBQUNzRyxJQUFJLENBQUMsQ0FBQ0ksR0FBRyxDQUFDakUsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUMxQyxJQUFBekMsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUNJLEdBQUcsQ0FBQ2pFLFNBQVMsQ0FBQyxXQUFXLENBQUM7RUFDekMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119