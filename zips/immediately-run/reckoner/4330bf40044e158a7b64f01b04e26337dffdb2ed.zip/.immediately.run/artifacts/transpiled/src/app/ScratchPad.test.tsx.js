var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _server = require("react-dom/server");
var _ScratchPad = _interopRequireDefault(require("./ScratchPad.tsx"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The scratch pad's static states (WHATIF_SHADOW_EVALUATION_SPEC §1.2): the G-WIF-8
// collision disable and the idle editor with its text-safety affordances. Static-rendered
// (SSR runs no effects, so the shadow runner stays inert); run/refusal behavior is covered
// by the whatif engine tests, and the readout by WhatIfResult.test.

// The pad touches only `session.sources` before a run — a stub session is enough for SSR.
function sessionWith(sources) {
  return {
    sources
  };
}
(0, _vitest.describe)('ScratchPad', () => {
  (0, _vitest.it)('disables itself with a visible message when the document declares a scratch worksheet (G-WIF-8)', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_ScratchPad.default, {
      session: sessionWith({
        scratch: '// taken',
        model: ''
      }),
      baseVerdicts: null,
      text: '',
      onTextChange: () => {}
    }));
    (0, _vitest.expect)(html).toContain('scratch pad is unavailable');
    (0, _vitest.expect)(html).not.toContain('textarea');
  });
  (0, _vitest.it)('renders the editor with Run, Copy, and Clear on a scratch-free document', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_ScratchPad.default, {
      session: sessionWith({
        model: ''
      }),
      baseVerdicts: null,
      text: 'export const probe = cell({ doc: "p", formula: () => 1 });',
      onTextChange: () => {}
    }));
    (0, _vitest.expect)(html).toContain('textarea');
    (0, _vitest.expect)(html).toContain('Run');
    (0, _vitest.expect)(html).toContain('Copy');
    (0, _vitest.expect)(html).toContain('Clear');
    (0, _vitest.expect)(html).toContain('unsaved');
    (0, _vitest.expect)(html).toContain('never saved to the document');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9zZXJ2ZXIiLCJfU2NyYXRjaFBhZCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJzZXNzaW9uV2l0aCIsInNvdXJjZXMiLCJkZXNjcmliZSIsIml0IiwiaHRtbCIsInJlbmRlclRvU3RhdGljTWFya3VwIiwiY3JlYXRlRWxlbWVudCIsIlNjcmF0Y2hQYWQiLCJzZXNzaW9uIiwic2NyYXRjaCIsIm1vZGVsIiwiYmFzZVZlcmRpY3RzIiwidGV4dCIsIm9uVGV4dENoYW5nZSIsImV4cGVjdCIsInRvQ29udGFpbiIsIm5vdCJdLCJzb3VyY2VzIjpbIlNjcmF0Y2hQYWQudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHNjcmF0Y2ggcGFkJ3Mgc3RhdGljIHN0YXRlcyAoV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMgwqcxLjIpOiB0aGUgRy1XSUYtOFxuLy8gY29sbGlzaW9uIGRpc2FibGUgYW5kIHRoZSBpZGxlIGVkaXRvciB3aXRoIGl0cyB0ZXh0LXNhZmV0eSBhZmZvcmRhbmNlcy4gU3RhdGljLXJlbmRlcmVkXG4vLyAoU1NSIHJ1bnMgbm8gZWZmZWN0cywgc28gdGhlIHNoYWRvdyBydW5uZXIgc3RheXMgaW5lcnQpOyBydW4vcmVmdXNhbCBiZWhhdmlvciBpcyBjb3ZlcmVkXG4vLyBieSB0aGUgd2hhdGlmIGVuZ2luZSB0ZXN0cywgYW5kIHRoZSByZWFkb3V0IGJ5IFdoYXRJZlJlc3VsdC50ZXN0LlxuaW1wb3J0IHsgZGVzY3JpYmUsIGV4cGVjdCwgaXQgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHJlbmRlclRvU3RhdGljTWFya3VwIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG5pbXBvcnQgU2NyYXRjaFBhZCBmcm9tICcuL1NjcmF0Y2hQYWQudHN4JztcbmltcG9ydCB0eXBlIHsgUmVwb3J0U2Vzc2lvbiB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5cbi8vIFRoZSBwYWQgdG91Y2hlcyBvbmx5IGBzZXNzaW9uLnNvdXJjZXNgIGJlZm9yZSBhIHJ1biDigJQgYSBzdHViIHNlc3Npb24gaXMgZW5vdWdoIGZvciBTU1IuXG5mdW5jdGlvbiBzZXNzaW9uV2l0aChzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogUmVwb3J0U2Vzc2lvbiB7XG4gIHJldHVybiB7IHNvdXJjZXMgfSBhcyB1bmtub3duIGFzIFJlcG9ydFNlc3Npb247XG59XG5cbmRlc2NyaWJlKCdTY3JhdGNoUGFkJywgKCkgPT4ge1xuICBpdCgnZGlzYWJsZXMgaXRzZWxmIHdpdGggYSB2aXNpYmxlIG1lc3NhZ2Ugd2hlbiB0aGUgZG9jdW1lbnQgZGVjbGFyZXMgYSBzY3JhdGNoIHdvcmtzaGVldCAoRy1XSUYtOCknLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlclRvU3RhdGljTWFya3VwKFxuICAgICAgY3JlYXRlRWxlbWVudChTY3JhdGNoUGFkLCB7XG4gICAgICAgIHNlc3Npb246IHNlc3Npb25XaXRoKHsgc2NyYXRjaDogJy8vIHRha2VuJywgbW9kZWw6ICcnIH0pLFxuICAgICAgICBiYXNlVmVyZGljdHM6IG51bGwsXG4gICAgICAgIHRleHQ6ICcnLFxuICAgICAgICBvblRleHRDaGFuZ2U6ICgpID0+IHt9LFxuICAgICAgfSksXG4gICAgKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdzY3JhdGNoIHBhZCBpcyB1bmF2YWlsYWJsZScpO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCd0ZXh0YXJlYScpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyB0aGUgZWRpdG9yIHdpdGggUnVuLCBDb3B5LCBhbmQgQ2xlYXIgb24gYSBzY3JhdGNoLWZyZWUgZG9jdW1lbnQnLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlclRvU3RhdGljTWFya3VwKFxuICAgICAgY3JlYXRlRWxlbWVudChTY3JhdGNoUGFkLCB7XG4gICAgICAgIHNlc3Npb246IHNlc3Npb25XaXRoKHsgbW9kZWw6ICcnIH0pLFxuICAgICAgICBiYXNlVmVyZGljdHM6IG51bGwsXG4gICAgICAgIHRleHQ6ICdleHBvcnQgY29uc3QgcHJvYmUgPSBjZWxsKHsgZG9jOiBcInBcIiwgZm9ybXVsYTogKCkgPT4gMSB9KTsnLFxuICAgICAgICBvblRleHRDaGFuZ2U6ICgpID0+IHt9LFxuICAgICAgfSksXG4gICAgKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCd0ZXh0YXJlYScpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ1J1bicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ0NvcHknKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdDbGVhcicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3Vuc2F2ZWQnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCduZXZlciBzYXZlZCB0byB0aGUgZG9jdW1lbnQnKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFJQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxXQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFBMEMsU0FBQUksdUJBQUFDLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFQMUM7QUFDQTtBQUNBO0FBQ0E7O0FBT0E7QUFDQSxTQUFTRyxXQUFXQSxDQUFDQyxPQUErQixFQUFpQjtFQUNuRSxPQUFPO0lBQUVBO0VBQVEsQ0FBQztBQUNwQjtBQUVBLElBQUFDLGdCQUFRLEVBQUMsWUFBWSxFQUFFLE1BQU07RUFDM0IsSUFBQUMsVUFBRSxFQUFDLGlHQUFpRyxFQUFFLE1BQU07SUFDMUcsTUFBTUMsSUFBSSxHQUFHLElBQUFDLDRCQUFvQixlQUMvQixJQUFBQyxvQkFBYSxFQUFDQyxtQkFBVSxFQUFFO01BQ3hCQyxPQUFPLEVBQUVSLFdBQVcsQ0FBQztRQUFFUyxPQUFPLEVBQUUsVUFBVTtRQUFFQyxLQUFLLEVBQUU7TUFBRyxDQUFDLENBQUM7TUFDeERDLFlBQVksRUFBRSxJQUFJO01BQ2xCQyxJQUFJLEVBQUUsRUFBRTtNQUNSQyxZQUFZLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQ3ZCLENBQUMsQ0FDSCxDQUFDO0lBQ0QsSUFBQUMsY0FBTSxFQUFDVixJQUFJLENBQUMsQ0FBQ1csU0FBUyxDQUFDLDRCQUE0QixDQUFDO0lBQ3BELElBQUFELGNBQU0sRUFBQ1YsSUFBSSxDQUFDLENBQUNZLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLFVBQVUsQ0FBQztFQUN4QyxDQUFDLENBQUM7RUFFRixJQUFBWixVQUFFLEVBQUMseUVBQXlFLEVBQUUsTUFBTTtJQUNsRixNQUFNQyxJQUFJLEdBQUcsSUFBQUMsNEJBQW9CLGVBQy9CLElBQUFDLG9CQUFhLEVBQUNDLG1CQUFVLEVBQUU7TUFDeEJDLE9BQU8sRUFBRVIsV0FBVyxDQUFDO1FBQUVVLEtBQUssRUFBRTtNQUFHLENBQUMsQ0FBQztNQUNuQ0MsWUFBWSxFQUFFLElBQUk7TUFDbEJDLElBQUksRUFBRSw0REFBNEQ7TUFDbEVDLFlBQVksRUFBRUEsQ0FBQSxLQUFNLENBQUM7SUFDdkIsQ0FBQyxDQUNILENBQUM7SUFDRCxJQUFBQyxjQUFNLEVBQUNWLElBQUksQ0FBQyxDQUFDVyxTQUFTLENBQUMsVUFBVSxDQUFDO0lBQ2xDLElBQUFELGNBQU0sRUFBQ1YsSUFBSSxDQUFDLENBQUNXLFNBQVMsQ0FBQyxLQUFLLENBQUM7SUFDN0IsSUFBQUQsY0FBTSxFQUFDVixJQUFJLENBQUMsQ0FBQ1csU0FBUyxDQUFDLE1BQU0sQ0FBQztJQUM5QixJQUFBRCxjQUFNLEVBQUNWLElBQUksQ0FBQyxDQUFDVyxTQUFTLENBQUMsT0FBTyxDQUFDO0lBQy9CLElBQUFELGNBQU0sRUFBQ1YsSUFBSSxDQUFDLENBQUNXLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDakMsSUFBQUQsY0FBTSxFQUFDVixJQUFJLENBQUMsQ0FBQ1csU0FBUyxDQUFDLDZCQUE2QixDQUFDO0VBQ3ZELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}