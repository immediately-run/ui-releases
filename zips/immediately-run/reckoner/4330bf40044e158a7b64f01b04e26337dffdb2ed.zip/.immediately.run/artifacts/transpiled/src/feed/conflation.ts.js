"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Conflator = void 0;
// Conflation — keep-latest coalescing (ARCHITECTURE_PLAN §5.3, RQ-C3 + review-1 F8). "Cadence =
// conflation": writes to a key (a feed's newest frame, or a dragged slider's `params.*` value at
// 60–120 Hz) are coalesced keep-latest, and the evaluator recomputes once per coalesced value —
// never once per write. Feeds and param drags share this **same** backpressure because they feed
// the same single-context evaluator (§5.3 F8); without it a fast drag floods the engine or, under
// naïve cancel-restart, livelocks (F2). This is NOT a debounce — the progress guarantee lives in
// the run-to-completion supersession rule (§4.1); this just collapses the input burst.
//
// Pure + clockless: writes accumulate keep-latest per key; the cadence driver (a timer / rAF, the
// injected effect) calls `flush()` each tick to drain the coalesced batch into `engine.update`.

class Conflator {
  #pending = new Map();
  #coalesced = 0;

  /** Record a write; a prior un-flushed write to the same key is superseded (kept-latest). */
  write(key, value) {
    if (this.#pending.has(key)) this.#coalesced++;
    this.#pending.set(key, value);
  }
  hasPending() {
    return this.#pending.size > 0;
  }

  /** Drain the coalesced batch (latest value per key) and clear. One recompute per flush. */
  flush() {
    const batch = new Map(this.#pending);
    this.#pending.clear();
    return batch;
  }

  /** How many writes were superseded before a flush — the backpressure savings (for E-4 metrics). */
  coalesced() {
    return this.#coalesced;
  }
}
exports.Conflator = Conflator;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJDb25mbGF0b3IiLCJwZW5kaW5nIiwiTWFwIiwiY29hbGVzY2VkIiwid3JpdGUiLCJrZXkiLCJ2YWx1ZSIsImhhcyIsInNldCIsImhhc1BlbmRpbmciLCJzaXplIiwiZmx1c2giLCJiYXRjaCIsImNsZWFyIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImNvbmZsYXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29uZmxhdGlvbiDigJQga2VlcC1sYXRlc3QgY29hbGVzY2luZyAoQVJDSElURUNUVVJFX1BMQU4gwqc1LjMsIFJRLUMzICsgcmV2aWV3LTEgRjgpLiBcIkNhZGVuY2UgPVxuLy8gY29uZmxhdGlvblwiOiB3cml0ZXMgdG8gYSBrZXkgKGEgZmVlZCdzIG5ld2VzdCBmcmFtZSwgb3IgYSBkcmFnZ2VkIHNsaWRlcidzIGBwYXJhbXMuKmAgdmFsdWUgYXRcbi8vIDYw4oCTMTIwIEh6KSBhcmUgY29hbGVzY2VkIGtlZXAtbGF0ZXN0LCBhbmQgdGhlIGV2YWx1YXRvciByZWNvbXB1dGVzIG9uY2UgcGVyIGNvYWxlc2NlZCB2YWx1ZSDigJRcbi8vIG5ldmVyIG9uY2UgcGVyIHdyaXRlLiBGZWVkcyBhbmQgcGFyYW0gZHJhZ3Mgc2hhcmUgdGhpcyAqKnNhbWUqKiBiYWNrcHJlc3N1cmUgYmVjYXVzZSB0aGV5IGZlZWRcbi8vIHRoZSBzYW1lIHNpbmdsZS1jb250ZXh0IGV2YWx1YXRvciAowqc1LjMgRjgpOyB3aXRob3V0IGl0IGEgZmFzdCBkcmFnIGZsb29kcyB0aGUgZW5naW5lIG9yLCB1bmRlclxuLy8gbmHDr3ZlIGNhbmNlbC1yZXN0YXJ0LCBsaXZlbG9ja3MgKEYyKS4gVGhpcyBpcyBOT1QgYSBkZWJvdW5jZSDigJQgdGhlIHByb2dyZXNzIGd1YXJhbnRlZSBsaXZlcyBpblxuLy8gdGhlIHJ1bi10by1jb21wbGV0aW9uIHN1cGVyc2Vzc2lvbiBydWxlICjCpzQuMSk7IHRoaXMganVzdCBjb2xsYXBzZXMgdGhlIGlucHV0IGJ1cnN0LlxuLy9cbi8vIFB1cmUgKyBjbG9ja2xlc3M6IHdyaXRlcyBhY2N1bXVsYXRlIGtlZXAtbGF0ZXN0IHBlciBrZXk7IHRoZSBjYWRlbmNlIGRyaXZlciAoYSB0aW1lciAvIHJBRiwgdGhlXG4vLyBpbmplY3RlZCBlZmZlY3QpIGNhbGxzIGBmbHVzaCgpYCBlYWNoIHRpY2sgdG8gZHJhaW4gdGhlIGNvYWxlc2NlZCBiYXRjaCBpbnRvIGBlbmdpbmUudXBkYXRlYC5cblxuZXhwb3J0IGNsYXNzIENvbmZsYXRvcjxWPiB7XG4gIHJlYWRvbmx5ICNwZW5kaW5nID0gbmV3IE1hcDxzdHJpbmcsIFY+KCk7XG4gICNjb2FsZXNjZWQgPSAwO1xuXG4gIC8qKiBSZWNvcmQgYSB3cml0ZTsgYSBwcmlvciB1bi1mbHVzaGVkIHdyaXRlIHRvIHRoZSBzYW1lIGtleSBpcyBzdXBlcnNlZGVkIChrZXB0LWxhdGVzdCkuICovXG4gIHdyaXRlKGtleTogc3RyaW5nLCB2YWx1ZTogVik6IHZvaWQge1xuICAgIGlmICh0aGlzLiNwZW5kaW5nLmhhcyhrZXkpKSB0aGlzLiNjb2FsZXNjZWQrKztcbiAgICB0aGlzLiNwZW5kaW5nLnNldChrZXksIHZhbHVlKTtcbiAgfVxuXG4gIGhhc1BlbmRpbmcoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI3BlbmRpbmcuc2l6ZSA+IDA7XG4gIH1cblxuICAvKiogRHJhaW4gdGhlIGNvYWxlc2NlZCBiYXRjaCAobGF0ZXN0IHZhbHVlIHBlciBrZXkpIGFuZCBjbGVhci4gT25lIHJlY29tcHV0ZSBwZXIgZmx1c2guICovXG4gIGZsdXNoKCk6IE1hcDxzdHJpbmcsIFY+IHtcbiAgICBjb25zdCBiYXRjaCA9IG5ldyBNYXAodGhpcy4jcGVuZGluZyk7XG4gICAgdGhpcy4jcGVuZGluZy5jbGVhcigpO1xuICAgIHJldHVybiBiYXRjaDtcbiAgfVxuXG4gIC8qKiBIb3cgbWFueSB3cml0ZXMgd2VyZSBzdXBlcnNlZGVkIGJlZm9yZSBhIGZsdXNoIOKAlCB0aGUgYmFja3ByZXNzdXJlIHNhdmluZ3MgKGZvciBFLTQgbWV0cmljcykuICovXG4gIGNvYWxlc2NlZCgpOiBudW1iZXIge1xuICAgIHJldHVybiB0aGlzLiNjb2FsZXNjZWQ7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU8sTUFBTUEsU0FBUyxDQUFJO0VBQ2YsQ0FBQ0MsT0FBTyxHQUFHLElBQUlDLEdBQUcsQ0FBWSxDQUFDO0VBQ3hDLENBQUNDLFNBQVMsR0FBRyxDQUFDOztFQUVkO0VBQ0FDLEtBQUtBLENBQUNDLEdBQVcsRUFBRUMsS0FBUSxFQUFRO0lBQ2pDLElBQUksSUFBSSxDQUFDLENBQUNMLE9BQU8sQ0FBQ00sR0FBRyxDQUFDRixHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQ0YsU0FBUyxFQUFFO0lBQzdDLElBQUksQ0FBQyxDQUFDRixPQUFPLENBQUNPLEdBQUcsQ0FBQ0gsR0FBRyxFQUFFQyxLQUFLLENBQUM7RUFDL0I7RUFFQUcsVUFBVUEsQ0FBQSxFQUFZO0lBQ3BCLE9BQU8sSUFBSSxDQUFDLENBQUNSLE9BQU8sQ0FBQ1MsSUFBSSxHQUFHLENBQUM7RUFDL0I7O0VBRUE7RUFDQUMsS0FBS0EsQ0FBQSxFQUFtQjtJQUN0QixNQUFNQyxLQUFLLEdBQUcsSUFBSVYsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDRCxPQUFPLENBQUM7SUFDcEMsSUFBSSxDQUFDLENBQUNBLE9BQU8sQ0FBQ1ksS0FBSyxDQUFDLENBQUM7SUFDckIsT0FBT0QsS0FBSztFQUNkOztFQUVBO0VBQ0FULFNBQVNBLENBQUEsRUFBVztJQUNsQixPQUFPLElBQUksQ0FBQyxDQUFDQSxTQUFTO0VBQ3hCO0FBQ0Y7QUFBQ1csT0FBQSxDQUFBZCxTQUFBLEdBQUFBLFNBQUEiLCJpZ25vcmVMaXN0IjpbXX0=