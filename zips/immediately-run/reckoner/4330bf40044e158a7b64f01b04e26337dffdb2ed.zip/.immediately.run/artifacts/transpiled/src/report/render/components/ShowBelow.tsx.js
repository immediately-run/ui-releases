var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ShowBelow;
var _attrs = require("../attrs.ts");
var _renderContext = require("../renderContext.ts");
var _useContainerWidth = require("../useContainerWidth.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // ShowBelow — the complement of ShowAbove (§3.3.1 point 4): render when the measured
// dimension is `<` the literal threshold. Same axis rule (one of width/height/dpr), same
// conditional-render (not display:none) semantics, same resize ≠ recompute guarantee.
function ShowBelow({
  node
}) {
  _s();
  const renderNodes = (0, _renderContext.useRenderNodes)();
  const {
    ref,
    width,
    height
  } = (0, _useContainerWidth.useContainerSize)();
  const dpr = (0, _useContainerWidth.useDpr)();
  const wT = (0, _attrs.attrNumber)(node, 'width');
  const hT = (0, _attrs.attrNumber)(node, 'height');
  const dT = (0, _attrs.attrNumber)(node, 'dpr');
  const measured = wT !== undefined ? width : hT !== undefined ? height : dpr;
  const threshold = wT ?? hT ?? dT ?? 0;
  const show = measured < threshold;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-responsive",
    ref: ref,
    "data-show": show || undefined,
    children: show ? renderNodes(node.children) : null
  });
}
_s(ShowBelow, "kiqUQUXWGmApBAzThmNmW8v4LJk=", false, function () {
  return [_renderContext.useRenderNodes, _useContainerWidth.useContainerSize, _useContainerWidth.useDpr];
});
_c = ShowBelow;
var _c;
$RefreshReg$(_c, "ShowBelow");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlbmRlckNvbnRleHQiLCJfdXNlQ29udGFpbmVyV2lkdGgiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiU2hvd0JlbG93Iiwibm9kZSIsInJlbmRlck5vZGVzIiwidXNlUmVuZGVyTm9kZXMiLCJyZWYiLCJ3aWR0aCIsImhlaWdodCIsInVzZUNvbnRhaW5lclNpemUiLCJkcHIiLCJ1c2VEcHIiLCJ3VCIsImF0dHJOdW1iZXIiLCJoVCIsImRUIiwibWVhc3VyZWQiLCJ1bmRlZmluZWQiLCJ0aHJlc2hvbGQiLCJzaG93IiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNob3dCZWxvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gU2hvd0JlbG93IOKAlCB0aGUgY29tcGxlbWVudCBvZiBTaG93QWJvdmUgKMKnMy4zLjEgcG9pbnQgNCk6IHJlbmRlciB3aGVuIHRoZSBtZWFzdXJlZFxuLy8gZGltZW5zaW9uIGlzIGA8YCB0aGUgbGl0ZXJhbCB0aHJlc2hvbGQuIFNhbWUgYXhpcyBydWxlIChvbmUgb2Ygd2lkdGgvaGVpZ2h0L2RwciksIHNhbWVcbi8vIGNvbmRpdGlvbmFsLXJlbmRlciAobm90IGRpc3BsYXk6bm9uZSkgc2VtYW50aWNzLCBzYW1lIHJlc2l6ZSDiiaAgcmVjb21wdXRlIGd1YXJhbnRlZS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJOdW1iZXIgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyB1c2VSZW5kZXJOb2RlcyB9IGZyb20gJy4uL3JlbmRlckNvbnRleHQudHMnO1xuaW1wb3J0IHsgdXNlQ29udGFpbmVyU2l6ZSwgdXNlRHByIH0gZnJvbSAnLi4vdXNlQ29udGFpbmVyV2lkdGgudHMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaG93QmVsb3coeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHJlbmRlck5vZGVzID0gdXNlUmVuZGVyTm9kZXMoKTtcbiAgY29uc3QgeyByZWYsIHdpZHRoLCBoZWlnaHQgfSA9IHVzZUNvbnRhaW5lclNpemUoKTtcbiAgY29uc3QgZHByID0gdXNlRHByKCk7XG5cbiAgY29uc3Qgd1QgPSBhdHRyTnVtYmVyKG5vZGUsICd3aWR0aCcpO1xuICBjb25zdCBoVCA9IGF0dHJOdW1iZXIobm9kZSwgJ2hlaWdodCcpO1xuICBjb25zdCBkVCA9IGF0dHJOdW1iZXIobm9kZSwgJ2RwcicpO1xuXG4gIGNvbnN0IG1lYXN1cmVkID0gd1QgIT09IHVuZGVmaW5lZCA/IHdpZHRoIDogaFQgIT09IHVuZGVmaW5lZCA/IGhlaWdodCA6IGRwcjtcbiAgY29uc3QgdGhyZXNob2xkID0gd1QgPz8gaFQgPz8gZFQgPz8gMDtcbiAgY29uc3Qgc2hvdyA9IG1lYXN1cmVkIDwgdGhyZXNob2xkO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZXNwb25zaXZlXCIgcmVmPXtyZWZ9IGRhdGEtc2hvdz17c2hvdyB8fCB1bmRlZmluZWR9PlxuICAgICAge3Nob3cgPyByZW5kZXJOb2Rlcyhub2RlLmNoaWxkcmVuKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUlBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGtCQUFBLEdBQUFGLE9BQUE7QUFBbUUsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBTm5FO0FBQ0E7QUFDQTtBQU1lLFNBQVNDLFNBQVNBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFILEVBQUE7RUFDbkUsTUFBTUksV0FBVyxHQUFHLElBQUFDLDZCQUFjLEVBQUMsQ0FBQztFQUNwQyxNQUFNO0lBQUVDLEdBQUc7SUFBRUMsS0FBSztJQUFFQztFQUFPLENBQUMsR0FBRyxJQUFBQyxtQ0FBZ0IsRUFBQyxDQUFDO0VBQ2pELE1BQU1DLEdBQUcsR0FBRyxJQUFBQyx5QkFBTSxFQUFDLENBQUM7RUFFcEIsTUFBTUMsRUFBRSxHQUFHLElBQUFDLGlCQUFVLEVBQUNWLElBQUksRUFBRSxPQUFPLENBQUM7RUFDcEMsTUFBTVcsRUFBRSxHQUFHLElBQUFELGlCQUFVLEVBQUNWLElBQUksRUFBRSxRQUFRLENBQUM7RUFDckMsTUFBTVksRUFBRSxHQUFHLElBQUFGLGlCQUFVLEVBQUNWLElBQUksRUFBRSxLQUFLLENBQUM7RUFFbEMsTUFBTWEsUUFBUSxHQUFHSixFQUFFLEtBQUtLLFNBQVMsR0FBR1YsS0FBSyxHQUFHTyxFQUFFLEtBQUtHLFNBQVMsR0FBR1QsTUFBTSxHQUFHRSxHQUFHO0VBQzNFLE1BQU1RLFNBQVMsR0FBR04sRUFBRSxJQUFJRSxFQUFFLElBQUlDLEVBQUUsSUFBSSxDQUFDO0VBQ3JDLE1BQU1JLElBQUksR0FBR0gsUUFBUSxHQUFHRSxTQUFTO0VBRWpDLG9CQUNFLElBQUFuQixXQUFBLENBQUFxQixHQUFBO0lBQUtDLFNBQVMsRUFBQyxlQUFlO0lBQUNmLEdBQUcsRUFBRUEsR0FBSTtJQUFDLGFBQVdhLElBQUksSUFBSUYsU0FBVTtJQUFBSyxRQUFBLEVBQ25FSCxJQUFJLEdBQUdmLFdBQVcsQ0FBQ0QsSUFBSSxDQUFDbUIsUUFBUSxDQUFDLEdBQUc7RUFBSSxDQUN0QyxDQUFDO0FBRVY7QUFBQ3RCLEVBQUEsQ0FsQnVCRSxTQUFTO0VBQUEsUUFDWEcsNkJBQWMsRUFDSEksbUNBQWdCLEVBQ25DRSx5QkFBTTtBQUFBO0FBQUFZLEVBQUEsR0FISXJCLFNBQVM7QUFBQSxJQUFBcUIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}