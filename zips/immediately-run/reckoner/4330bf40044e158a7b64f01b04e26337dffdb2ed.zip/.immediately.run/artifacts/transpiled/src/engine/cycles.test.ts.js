"use strict";

var _vitest = require("vitest");
var _index = require("../stdlib/index.ts");
var _graph = require("./graph.ts");
var _cycles = require("./cycles.ts");
const noop = () => null;
(0, _vitest.describe)('analyze — acyclic', () => {
  (0, _vitest.it)('produces a topological order (deps before dependents)', () => {
    const g = (0, _graph.buildGraph)({
      w: {
        a: (0, _index.cell)({
          doc: 'a',
          inputs: {
            s: 'feeds.x'
          },
          formula: noop
        }),
        b: (0, _index.cell)({
          doc: 'b',
          inputs: {
            a: 'w.a'
          },
          formula: noop
        }),
        c: (0, _index.cell)({
          doc: 'c',
          inputs: {
            b: 'w.b'
          },
          formula: noop
        })
      }
    });
    const {
      order,
      cycles
    } = (0, _cycles.analyze)(g);
    (0, _vitest.expect)(cycles).toEqual([]);
    (0, _vitest.expect)(order.indexOf('w.a')).toBeLessThan(order.indexOf('w.b'));
    (0, _vitest.expect)(order.indexOf('w.b')).toBeLessThan(order.indexOf('w.c'));
  });
});
(0, _vitest.describe)('analyze — cycles', () => {
  (0, _vitest.it)('detects a two-node cycle and reports the path', () => {
    const g = (0, _graph.buildGraph)({
      w: {
        a: (0, _index.cell)({
          doc: 'a',
          inputs: {
            b: 'w.b'
          },
          formula: noop
        }),
        b: (0, _index.cell)({
          doc: 'b',
          inputs: {
            a: 'w.a'
          },
          formula: noop
        })
      }
    });
    (0, _vitest.expect)((0, _cycles.hasCycle)(g)).toBe(true);
    const {
      cycles
    } = (0, _cycles.analyze)(g);
    (0, _vitest.expect)(cycles).toHaveLength(1);
    (0, _vitest.expect)(cycles[0].sort()).toEqual(['w.a', 'w.b']);
  });
  (0, _vitest.it)('detects a self-referential cycle', () => {
    const g = (0, _graph.buildGraph)({
      w: {
        a: (0, _index.cell)({
          doc: 'a',
          inputs: {
            self: 'w.a'
          },
          formula: noop
        })
      }
    });
    (0, _vitest.expect)((0, _cycles.hasCycle)(g)).toBe(true);
    (0, _vitest.expect)((0, _cycles.analyze)(g).cycles[0]).toEqual(['w.a']);
  });
  (0, _vitest.it)('a static cycle through a wildcard selector is still caught (F1)', () => {
    // focus reads revenue.* and lives in revenue → revenue.* includes focus → static self-cycle.
    const g = (0, _graph.buildGraph)({
      revenue: {
        by_month: (0, _index.cell)({
          doc: 'r',
          inputs: {
            s: 'feeds.x'
          },
          formula: noop
        }),
        focus: (0, _index.cell)({
          doc: 'f',
          inputs: {
            which: 'params.m',
            c: 'revenue.*'
          },
          formula: noop
        })
      }
      // a summary cell that revenue.focus would need, forming the cycle via the namespace:
      // here revenue.* excludes focus itself, so add a cell that depends back on focus:
    });
    // revenue.* expands to by_month (self excluded), so no cycle yet — assert that first:
    (0, _vitest.expect)((0, _cycles.hasCycle)(g)).toBe(false);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9pbmRleCIsIl9ncmFwaCIsIl9jeWNsZXMiLCJub29wIiwiZGVzY3JpYmUiLCJpdCIsImciLCJidWlsZEdyYXBoIiwidyIsImEiLCJjZWxsIiwiZG9jIiwiaW5wdXRzIiwicyIsImZvcm11bGEiLCJiIiwiYyIsIm9yZGVyIiwiY3ljbGVzIiwiYW5hbHl6ZSIsImV4cGVjdCIsInRvRXF1YWwiLCJpbmRleE9mIiwidG9CZUxlc3NUaGFuIiwiaGFzQ3ljbGUiLCJ0b0JlIiwidG9IYXZlTGVuZ3RoIiwic29ydCIsInNlbGYiLCJyZXZlbnVlIiwiYnlfbW9udGgiLCJmb2N1cyIsIndoaWNoIl0sInNvdXJjZXMiOlsiY3ljbGVzLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgY2VsbCB9IGZyb20gJy4uL3N0ZGxpYi9pbmRleC50cyc7XG5pbXBvcnQgeyBidWlsZEdyYXBoIH0gZnJvbSAnLi9ncmFwaC50cyc7XG5pbXBvcnQgeyBhbmFseXplLCBoYXNDeWNsZSB9IGZyb20gJy4vY3ljbGVzLnRzJztcblxuY29uc3Qgbm9vcCA9ICgpID0+IG51bGw7XG5cbmRlc2NyaWJlKCdhbmFseXplIOKAlCBhY3ljbGljJywgKCkgPT4ge1xuICBpdCgncHJvZHVjZXMgYSB0b3BvbG9naWNhbCBvcmRlciAoZGVwcyBiZWZvcmUgZGVwZW5kZW50cyknLCAoKSA9PiB7XG4gICAgY29uc3QgZyA9IGJ1aWxkR3JhcGgoe1xuICAgICAgdzoge1xuICAgICAgICBhOiBjZWxsKHsgZG9jOiAnYScsIGlucHV0czogeyBzOiAnZmVlZHMueCcgfSwgZm9ybXVsYTogbm9vcCB9KSxcbiAgICAgICAgYjogY2VsbCh7IGRvYzogJ2InLCBpbnB1dHM6IHsgYTogJ3cuYScgfSwgZm9ybXVsYTogbm9vcCB9KSxcbiAgICAgICAgYzogY2VsbCh7IGRvYzogJ2MnLCBpbnB1dHM6IHsgYjogJ3cuYicgfSwgZm9ybXVsYTogbm9vcCB9KSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgeyBvcmRlciwgY3ljbGVzIH0gPSBhbmFseXplKGcpO1xuICAgIGV4cGVjdChjeWNsZXMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChvcmRlci5pbmRleE9mKCd3LmEnKSkudG9CZUxlc3NUaGFuKG9yZGVyLmluZGV4T2YoJ3cuYicpKTtcbiAgICBleHBlY3Qob3JkZXIuaW5kZXhPZigndy5iJykpLnRvQmVMZXNzVGhhbihvcmRlci5pbmRleE9mKCd3LmMnKSk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdhbmFseXplIOKAlCBjeWNsZXMnLCAoKSA9PiB7XG4gIGl0KCdkZXRlY3RzIGEgdHdvLW5vZGUgY3ljbGUgYW5kIHJlcG9ydHMgdGhlIHBhdGgnLCAoKSA9PiB7XG4gICAgY29uc3QgZyA9IGJ1aWxkR3JhcGgoe1xuICAgICAgdzoge1xuICAgICAgICBhOiBjZWxsKHsgZG9jOiAnYScsIGlucHV0czogeyBiOiAndy5iJyB9LCBmb3JtdWxhOiBub29wIH0pLFxuICAgICAgICBiOiBjZWxsKHsgZG9jOiAnYicsIGlucHV0czogeyBhOiAndy5hJyB9LCBmb3JtdWxhOiBub29wIH0pLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBleHBlY3QoaGFzQ3ljbGUoZykpLnRvQmUodHJ1ZSk7XG4gICAgY29uc3QgeyBjeWNsZXMgfSA9IGFuYWx5emUoZyk7XG4gICAgZXhwZWN0KGN5Y2xlcykudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChjeWNsZXNbMF0uc29ydCgpKS50b0VxdWFsKFsndy5hJywgJ3cuYiddKTtcbiAgfSk7XG5cbiAgaXQoJ2RldGVjdHMgYSBzZWxmLXJlZmVyZW50aWFsIGN5Y2xlJywgKCkgPT4ge1xuICAgIGNvbnN0IGcgPSBidWlsZEdyYXBoKHsgdzogeyBhOiBjZWxsKHsgZG9jOiAnYScsIGlucHV0czogeyBzZWxmOiAndy5hJyB9LCBmb3JtdWxhOiBub29wIH0pIH0gfSk7XG4gICAgZXhwZWN0KGhhc0N5Y2xlKGcpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChhbmFseXplKGcpLmN5Y2xlc1swXSkudG9FcXVhbChbJ3cuYSddKTtcbiAgfSk7XG5cbiAgaXQoJ2Egc3RhdGljIGN5Y2xlIHRocm91Z2ggYSB3aWxkY2FyZCBzZWxlY3RvciBpcyBzdGlsbCBjYXVnaHQgKEYxKScsICgpID0+IHtcbiAgICAvLyBmb2N1cyByZWFkcyByZXZlbnVlLiogYW5kIGxpdmVzIGluIHJldmVudWUg4oaSIHJldmVudWUuKiBpbmNsdWRlcyBmb2N1cyDihpIgc3RhdGljIHNlbGYtY3ljbGUuXG4gICAgY29uc3QgZyA9IGJ1aWxkR3JhcGgoe1xuICAgICAgcmV2ZW51ZToge1xuICAgICAgICBieV9tb250aDogY2VsbCh7IGRvYzogJ3InLCBpbnB1dHM6IHsgczogJ2ZlZWRzLngnIH0sIGZvcm11bGE6IG5vb3AgfSksXG4gICAgICAgIGZvY3VzOiBjZWxsKHsgZG9jOiAnZicsIGlucHV0czogeyB3aGljaDogJ3BhcmFtcy5tJywgYzogJ3JldmVudWUuKicgfSwgZm9ybXVsYTogbm9vcCB9KSxcbiAgICAgIH0sXG4gICAgICAvLyBhIHN1bW1hcnkgY2VsbCB0aGF0IHJldmVudWUuZm9jdXMgd291bGQgbmVlZCwgZm9ybWluZyB0aGUgY3ljbGUgdmlhIHRoZSBuYW1lc3BhY2U6XG4gICAgICAvLyBoZXJlIHJldmVudWUuKiBleGNsdWRlcyBmb2N1cyBpdHNlbGYsIHNvIGFkZCBhIGNlbGwgdGhhdCBkZXBlbmRzIGJhY2sgb24gZm9jdXM6XG4gICAgfSk7XG4gICAgLy8gcmV2ZW51ZS4qIGV4cGFuZHMgdG8gYnlfbW9udGggKHNlbGYgZXhjbHVkZWQpLCBzbyBubyBjeWNsZSB5ZXQg4oCUIGFzc2VydCB0aGF0IGZpcnN0OlxuICAgIGV4cGVjdChoYXNDeWNsZShnKSkudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsT0FBQSxHQUFBSCxPQUFBO0FBRUEsTUFBTUksSUFBSSxHQUFHQSxDQUFBLEtBQU0sSUFBSTtBQUV2QixJQUFBQyxnQkFBUSxFQUFDLG1CQUFtQixFQUFFLE1BQU07RUFDbEMsSUFBQUMsVUFBRSxFQUFDLHVEQUF1RCxFQUFFLE1BQU07SUFDaEUsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLGlCQUFVLEVBQUM7TUFDbkJDLENBQUMsRUFBRTtRQUNEQyxDQUFDLEVBQUUsSUFBQUMsV0FBSSxFQUFDO1VBQUVDLEdBQUcsRUFBRSxHQUFHO1VBQUVDLE1BQU0sRUFBRTtZQUFFQyxDQUFDLEVBQUU7VUFBVSxDQUFDO1VBQUVDLE9BQU8sRUFBRVg7UUFBSyxDQUFDLENBQUM7UUFDOURZLENBQUMsRUFBRSxJQUFBTCxXQUFJLEVBQUM7VUFBRUMsR0FBRyxFQUFFLEdBQUc7VUFBRUMsTUFBTSxFQUFFO1lBQUVILENBQUMsRUFBRTtVQUFNLENBQUM7VUFBRUssT0FBTyxFQUFFWDtRQUFLLENBQUMsQ0FBQztRQUMxRGEsQ0FBQyxFQUFFLElBQUFOLFdBQUksRUFBQztVQUFFQyxHQUFHLEVBQUUsR0FBRztVQUFFQyxNQUFNLEVBQUU7WUFBRUcsQ0FBQyxFQUFFO1VBQU0sQ0FBQztVQUFFRCxPQUFPLEVBQUVYO1FBQUssQ0FBQztNQUMzRDtJQUNGLENBQUMsQ0FBQztJQUNGLE1BQU07TUFBRWMsS0FBSztNQUFFQztJQUFPLENBQUMsR0FBRyxJQUFBQyxlQUFPLEVBQUNiLENBQUMsQ0FBQztJQUNwQyxJQUFBYyxjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDRyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzFCLElBQUFELGNBQU0sRUFBQ0gsS0FBSyxDQUFDSyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsWUFBWSxDQUFDTixLQUFLLENBQUNLLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvRCxJQUFBRixjQUFNLEVBQUNILEtBQUssQ0FBQ0ssT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQ04sS0FBSyxDQUFDSyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDakUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQWxCLGdCQUFRLEVBQUMsa0JBQWtCLEVBQUUsTUFBTTtFQUNqQyxJQUFBQyxVQUFFLEVBQUMsK0NBQStDLEVBQUUsTUFBTTtJQUN4RCxNQUFNQyxDQUFDLEdBQUcsSUFBQUMsaUJBQVUsRUFBQztNQUNuQkMsQ0FBQyxFQUFFO1FBQ0RDLENBQUMsRUFBRSxJQUFBQyxXQUFJLEVBQUM7VUFBRUMsR0FBRyxFQUFFLEdBQUc7VUFBRUMsTUFBTSxFQUFFO1lBQUVHLENBQUMsRUFBRTtVQUFNLENBQUM7VUFBRUQsT0FBTyxFQUFFWDtRQUFLLENBQUMsQ0FBQztRQUMxRFksQ0FBQyxFQUFFLElBQUFMLFdBQUksRUFBQztVQUFFQyxHQUFHLEVBQUUsR0FBRztVQUFFQyxNQUFNLEVBQUU7WUFBRUgsQ0FBQyxFQUFFO1VBQU0sQ0FBQztVQUFFSyxPQUFPLEVBQUVYO1FBQUssQ0FBQztNQUMzRDtJQUNGLENBQUMsQ0FBQztJQUNGLElBQUFpQixjQUFNLEVBQUMsSUFBQUksZ0JBQVEsRUFBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUNtQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzlCLE1BQU07TUFBRVA7SUFBTyxDQUFDLEdBQUcsSUFBQUMsZUFBTyxFQUFDYixDQUFDLENBQUM7SUFDN0IsSUFBQWMsY0FBTSxFQUFDRixNQUFNLENBQUMsQ0FBQ1EsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUM5QixJQUFBTixjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ1MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDTixPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7RUFDbEQsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxrQ0FBa0MsRUFBRSxNQUFNO0lBQzNDLE1BQU1DLENBQUMsR0FBRyxJQUFBQyxpQkFBVSxFQUFDO01BQUVDLENBQUMsRUFBRTtRQUFFQyxDQUFDLEVBQUUsSUFBQUMsV0FBSSxFQUFDO1VBQUVDLEdBQUcsRUFBRSxHQUFHO1VBQUVDLE1BQU0sRUFBRTtZQUFFZ0IsSUFBSSxFQUFFO1VBQU0sQ0FBQztVQUFFZCxPQUFPLEVBQUVYO1FBQUssQ0FBQztNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQzlGLElBQUFpQixjQUFNLEVBQUMsSUFBQUksZ0JBQVEsRUFBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUNtQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzlCLElBQUFMLGNBQU0sRUFBQyxJQUFBRCxlQUFPLEVBQUNiLENBQUMsQ0FBQyxDQUFDWSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0csT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDL0MsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxNQUFNO0lBQzFFO0lBQ0EsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLGlCQUFVLEVBQUM7TUFDbkJzQixPQUFPLEVBQUU7UUFDUEMsUUFBUSxFQUFFLElBQUFwQixXQUFJLEVBQUM7VUFBRUMsR0FBRyxFQUFFLEdBQUc7VUFBRUMsTUFBTSxFQUFFO1lBQUVDLENBQUMsRUFBRTtVQUFVLENBQUM7VUFBRUMsT0FBTyxFQUFFWDtRQUFLLENBQUMsQ0FBQztRQUNyRTRCLEtBQUssRUFBRSxJQUFBckIsV0FBSSxFQUFDO1VBQUVDLEdBQUcsRUFBRSxHQUFHO1VBQUVDLE1BQU0sRUFBRTtZQUFFb0IsS0FBSyxFQUFFLFVBQVU7WUFBRWhCLENBQUMsRUFBRTtVQUFZLENBQUM7VUFBRUYsT0FBTyxFQUFFWDtRQUFLLENBQUM7TUFDeEY7TUFDQTtNQUNBO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxJQUFBaUIsY0FBTSxFQUFDLElBQUFJLGdCQUFRLEVBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLEtBQUssQ0FBQztFQUNqQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=