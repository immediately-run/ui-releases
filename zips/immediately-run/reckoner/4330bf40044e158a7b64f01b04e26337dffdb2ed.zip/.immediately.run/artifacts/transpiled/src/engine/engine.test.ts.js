"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
var _vitest = require("vitest");
var stdlib = _interopRequireWildcard(require("../stdlib/index.ts"));
var _engine = require("./engine.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// Two worksheets + a metamorphic test, all as transpiled worksheet source — the whole spine
// end to end: SES-confined evaluation → graph → scheduler → results → tests → verdict.
const SOURCES = {
  revenue: `
    import { cell, testCell, table, sum, permutationInvariance } from "@reckoner/stdlib";

    export const by_month = cell({
      doc: "revenue by month",
      inputs: { orders: "feeds.orders" },
      formula: ({ orders }) => table(orders).groupBy("month").rollup({ revenue: sum("eur") }).rows(),
    });

    export const total = cell({
      doc: "total revenue",
      inputs: { m: "revenue.by_month" },
      formula: ({ m }) => m.reduce((a, r) => a + r.revenue, 0),
    });

    export const by_month_order_free = testCell({
      kind: "metamorphic",
      subject: "revenue.by_month",
      inputs: { orders: "feeds.orders" },
      relation: permutationInvariance({ over: "orders" }),
    });
  `,
  summary: `
    import { cell } from "@reckoner/stdlib";
    export const months = cell({
      doc: "distinct months",
      inputs: { m: "revenue.by_month" },
      formula: ({ m }) => m.length,
    });
  `
};
const orders = [{
  month: '2026-01',
  eur: 100
}, {
  month: '2026-02',
  eur: 50
}, {
  month: '2026-01',
  eur: 40
}];
(0, _vitest.describe)('Engine — end to end over the whole spine', () => {
  (0, _vitest.it)('runs worksheets through SES → graph → scheduler and publishes cell values', () => {
    const engine = _engine.Engine.fromSources(SOURCES, stdlib);
    (0, _vitest.expect)(engine.graph.diagnostics).toEqual([]);
    (0, _vitest.expect)(engine.scheduler.cycles).toEqual([]);
    engine.run({
      'feeds.orders': {
        value: orders,
        tier: 'live'
      }
    });
    (0, _vitest.expect)(engine.value('revenue.by_month')).toEqual([{
      month: '2026-01',
      revenue: 140
    }, {
      month: '2026-02',
      revenue: 50
    }]);
    (0, _vitest.expect)(engine.value('revenue.total')).toBe(190);
    (0, _vitest.expect)(engine.value('summary.months')).toBe(2);
    // tier folds through: everything downstream of the live feed is live
    (0, _vitest.expect)(engine.scheduler.result('revenue.total').tier).toBe('live');
  });
  (0, _vitest.it)('incremental recompute rides cutoff', () => {
    const engine = _engine.Engine.fromSources(SOURCES, stdlib);
    engine.run({
      'feeds.orders': {
        value: orders,
        tier: 'live'
      }
    });
    const more = [...orders, {
      month: '2026-02',
      eur: 10
    }];
    const pass = engine.update({
      'feeds.orders': {
        value: more,
        tier: 'live'
      }
    });
    (0, _vitest.expect)(pass.changed).toEqual(_vitest.expect.arrayContaining(['revenue.by_month', 'revenue.total']));
    (0, _vitest.expect)(engine.value('revenue.total')).toBe(200);
    // summary.months is recomputed but its value (2 distinct months) is unchanged → not "changed"
    (0, _vitest.expect)(pass.changed).not.toContain('summary.months');
  });
  (0, _vitest.it)('runs tests-as-cells and produces the review verdict (metamorphic → validated)', () => {
    const engine = _engine.Engine.fromSources(SOURCES, stdlib);
    engine.run({
      'feeds.orders': {
        value: orders,
        tier: 'live'
      }
    });
    const verdicts = engine.runTests();
    const suite = verdicts.get('revenue.by_month');
    (0, _vitest.expect)(suite).toBeDefined();
    (0, _vitest.expect)(suite.outcomes.every(o => o.result.pass)).toBe(true);
    (0, _vitest.expect)(suite.verdict).toBe('validated');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsInN0ZGxpYiIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX2VuZ2luZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsIlNPVVJDRVMiLCJyZXZlbnVlIiwic3VtbWFyeSIsIm9yZGVycyIsIm1vbnRoIiwiZXVyIiwiZGVzY3JpYmUiLCJpdCIsImVuZ2luZSIsIkVuZ2luZSIsImZyb21Tb3VyY2VzIiwiZXhwZWN0IiwiZ3JhcGgiLCJkaWFnbm9zdGljcyIsInRvRXF1YWwiLCJzY2hlZHVsZXIiLCJjeWNsZXMiLCJydW4iLCJ2YWx1ZSIsInRpZXIiLCJ0b0JlIiwicmVzdWx0IiwibW9yZSIsInBhc3MiLCJ1cGRhdGUiLCJjaGFuZ2VkIiwiYXJyYXlDb250YWluaW5nIiwibm90IiwidG9Db250YWluIiwidmVyZGljdHMiLCJydW5UZXN0cyIsInN1aXRlIiwidG9CZURlZmluZWQiLCJvdXRjb21lcyIsImV2ZXJ5IiwibyIsInZlcmRpY3QiXSwic291cmNlcyI6WyJlbmdpbmUudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgKiBhcyBzdGRsaWIgZnJvbSAnLi4vc3RkbGliL2luZGV4LnRzJztcbmltcG9ydCB7IEVuZ2luZSB9IGZyb20gJy4vZW5naW5lLnRzJztcbmltcG9ydCB0eXBlIHsgUm93IH0gZnJvbSAnLi4vc3RkbGliL3R5cGVzLnRzJztcblxuLy8gVHdvIHdvcmtzaGVldHMgKyBhIG1ldGFtb3JwaGljIHRlc3QsIGFsbCBhcyB0cmFuc3BpbGVkIHdvcmtzaGVldCBzb3VyY2Ug4oCUIHRoZSB3aG9sZSBzcGluZVxuLy8gZW5kIHRvIGVuZDogU0VTLWNvbmZpbmVkIGV2YWx1YXRpb24g4oaSIGdyYXBoIOKGkiBzY2hlZHVsZXIg4oaSIHJlc3VsdHMg4oaSIHRlc3RzIOKGkiB2ZXJkaWN0LlxuY29uc3QgU09VUkNFUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgcmV2ZW51ZTogYFxuICAgIGltcG9ydCB7IGNlbGwsIHRlc3RDZWxsLCB0YWJsZSwgc3VtLCBwZXJtdXRhdGlvbkludmFyaWFuY2UgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG4gICAgZXhwb3J0IGNvbnN0IGJ5X21vbnRoID0gY2VsbCh7XG4gICAgICBkb2M6IFwicmV2ZW51ZSBieSBtb250aFwiLFxuICAgICAgaW5wdXRzOiB7IG9yZGVyczogXCJmZWVkcy5vcmRlcnNcIiB9LFxuICAgICAgZm9ybXVsYTogKHsgb3JkZXJzIH0pID0+IHRhYmxlKG9yZGVycykuZ3JvdXBCeShcIm1vbnRoXCIpLnJvbGx1cCh7IHJldmVudWU6IHN1bShcImV1clwiKSB9KS5yb3dzKCksXG4gICAgfSk7XG5cbiAgICBleHBvcnQgY29uc3QgdG90YWwgPSBjZWxsKHtcbiAgICAgIGRvYzogXCJ0b3RhbCByZXZlbnVlXCIsXG4gICAgICBpbnB1dHM6IHsgbTogXCJyZXZlbnVlLmJ5X21vbnRoXCIgfSxcbiAgICAgIGZvcm11bGE6ICh7IG0gfSkgPT4gbS5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLnJldmVudWUsIDApLFxuICAgIH0pO1xuXG4gICAgZXhwb3J0IGNvbnN0IGJ5X21vbnRoX29yZGVyX2ZyZWUgPSB0ZXN0Q2VsbCh7XG4gICAgICBraW5kOiBcIm1ldGFtb3JwaGljXCIsXG4gICAgICBzdWJqZWN0OiBcInJldmVudWUuYnlfbW9udGhcIixcbiAgICAgIGlucHV0czogeyBvcmRlcnM6IFwiZmVlZHMub3JkZXJzXCIgfSxcbiAgICAgIHJlbGF0aW9uOiBwZXJtdXRhdGlvbkludmFyaWFuY2UoeyBvdmVyOiBcIm9yZGVyc1wiIH0pLFxuICAgIH0pO1xuICBgLFxuICBzdW1tYXJ5OiBgXG4gICAgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG4gICAgZXhwb3J0IGNvbnN0IG1vbnRocyA9IGNlbGwoe1xuICAgICAgZG9jOiBcImRpc3RpbmN0IG1vbnRoc1wiLFxuICAgICAgaW5wdXRzOiB7IG06IFwicmV2ZW51ZS5ieV9tb250aFwiIH0sXG4gICAgICBmb3JtdWxhOiAoeyBtIH0pID0+IG0ubGVuZ3RoLFxuICAgIH0pO1xuICBgLFxufTtcblxuY29uc3Qgb3JkZXJzOiBSb3dbXSA9IFtcbiAgeyBtb250aDogJzIwMjYtMDEnLCBldXI6IDEwMCB9LFxuICB7IG1vbnRoOiAnMjAyNi0wMicsIGV1cjogNTAgfSxcbiAgeyBtb250aDogJzIwMjYtMDEnLCBldXI6IDQwIH0sXG5dO1xuXG5kZXNjcmliZSgnRW5naW5lIOKAlCBlbmQgdG8gZW5kIG92ZXIgdGhlIHdob2xlIHNwaW5lJywgKCkgPT4ge1xuICBpdCgncnVucyB3b3Jrc2hlZXRzIHRocm91Z2ggU0VTIOKGkiBncmFwaCDihpIgc2NoZWR1bGVyIGFuZCBwdWJsaXNoZXMgY2VsbCB2YWx1ZXMnLCAoKSA9PiB7XG4gICAgY29uc3QgZW5naW5lID0gRW5naW5lLmZyb21Tb3VyY2VzKFNPVVJDRVMsIHN0ZGxpYik7XG4gICAgZXhwZWN0KGVuZ2luZS5ncmFwaC5kaWFnbm9zdGljcykudG9FcXVhbChbXSk7XG4gICAgZXhwZWN0KGVuZ2luZS5zY2hlZHVsZXIuY3ljbGVzKS50b0VxdWFsKFtdKTtcblxuICAgIGVuZ2luZS5ydW4oeyAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogb3JkZXJzLCB0aWVyOiAnbGl2ZScgfSB9KTtcblxuICAgIGV4cGVjdChlbmdpbmUudmFsdWUoJ3JldmVudWUuYnlfbW9udGgnKSkudG9FcXVhbChbXG4gICAgICB7IG1vbnRoOiAnMjAyNi0wMScsIHJldmVudWU6IDE0MCB9LFxuICAgICAgeyBtb250aDogJzIwMjYtMDInLCByZXZlbnVlOiA1MCB9LFxuICAgIF0pO1xuICAgIGV4cGVjdChlbmdpbmUudmFsdWUoJ3JldmVudWUudG90YWwnKSkudG9CZSgxOTApO1xuICAgIGV4cGVjdChlbmdpbmUudmFsdWUoJ3N1bW1hcnkubW9udGhzJykpLnRvQmUoMik7XG4gICAgLy8gdGllciBmb2xkcyB0aHJvdWdoOiBldmVyeXRoaW5nIGRvd25zdHJlYW0gb2YgdGhlIGxpdmUgZmVlZCBpcyBsaXZlXG4gICAgZXhwZWN0KGVuZ2luZS5zY2hlZHVsZXIucmVzdWx0KCdyZXZlbnVlLnRvdGFsJykhLnRpZXIpLnRvQmUoJ2xpdmUnKTtcbiAgfSk7XG5cbiAgaXQoJ2luY3JlbWVudGFsIHJlY29tcHV0ZSByaWRlcyBjdXRvZmYnLCAoKSA9PiB7XG4gICAgY29uc3QgZW5naW5lID0gRW5naW5lLmZyb21Tb3VyY2VzKFNPVVJDRVMsIHN0ZGxpYik7XG4gICAgZW5naW5lLnJ1bih7ICdmZWVkcy5vcmRlcnMnOiB7IHZhbHVlOiBvcmRlcnMsIHRpZXI6ICdsaXZlJyB9IH0pO1xuICAgIGNvbnN0IG1vcmUgPSBbLi4ub3JkZXJzLCB7IG1vbnRoOiAnMjAyNi0wMicsIGV1cjogMTAgfV07XG4gICAgY29uc3QgcGFzcyA9IGVuZ2luZS51cGRhdGUoeyAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogbW9yZSwgdGllcjogJ2xpdmUnIH0gfSk7XG4gICAgZXhwZWN0KHBhc3MuY2hhbmdlZCkudG9FcXVhbChleHBlY3QuYXJyYXlDb250YWluaW5nKFsncmV2ZW51ZS5ieV9tb250aCcsICdyZXZlbnVlLnRvdGFsJ10pKTtcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdyZXZlbnVlLnRvdGFsJykpLnRvQmUoMjAwKTtcbiAgICAvLyBzdW1tYXJ5Lm1vbnRocyBpcyByZWNvbXB1dGVkIGJ1dCBpdHMgdmFsdWUgKDIgZGlzdGluY3QgbW9udGhzKSBpcyB1bmNoYW5nZWQg4oaSIG5vdCBcImNoYW5nZWRcIlxuICAgIGV4cGVjdChwYXNzLmNoYW5nZWQpLm5vdC50b0NvbnRhaW4oJ3N1bW1hcnkubW9udGhzJyk7XG4gIH0pO1xuXG4gIGl0KCdydW5zIHRlc3RzLWFzLWNlbGxzIGFuZCBwcm9kdWNlcyB0aGUgcmV2aWV3IHZlcmRpY3QgKG1ldGFtb3JwaGljIOKGkiB2YWxpZGF0ZWQpJywgKCkgPT4ge1xuICAgIGNvbnN0IGVuZ2luZSA9IEVuZ2luZS5mcm9tU291cmNlcyhTT1VSQ0VTLCBzdGRsaWIpO1xuICAgIGVuZ2luZS5ydW4oeyAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogb3JkZXJzLCB0aWVyOiAnbGl2ZScgfSB9KTtcblxuICAgIGNvbnN0IHZlcmRpY3RzID0gZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgY29uc3Qgc3VpdGUgPSB2ZXJkaWN0cy5nZXQoJ3JldmVudWUuYnlfbW9udGgnKTtcbiAgICBleHBlY3Qoc3VpdGUpLnRvQmVEZWZpbmVkKCk7XG4gICAgZXhwZWN0KHN1aXRlIS5vdXRjb21lcy5ldmVyeSgobykgPT4gby5yZXN1bHQucGFzcykpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHN1aXRlIS52ZXJkaWN0KS50b0JlKCd2YWxpZGF0ZWQnKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUMsdUJBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUgsT0FBQTtBQUFxQyxTQUFBSSx5QkFBQUMsQ0FBQSw2QkFBQUMsT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRix3QkFBQSxZQUFBQSxDQUFBQyxDQUFBLFdBQUFBLENBQUEsR0FBQUcsQ0FBQSxHQUFBRCxDQUFBLEtBQUFGLENBQUE7QUFBQSxTQUFBSCx3QkFBQUcsQ0FBQSxFQUFBRSxDQUFBLFNBQUFBLENBQUEsSUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUFJLFVBQUEsU0FBQUosQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFLLE9BQUEsRUFBQUwsQ0FBQSxRQUFBRyxDQUFBLEdBQUFKLHdCQUFBLENBQUFHLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFHLEdBQUEsQ0FBQU4sQ0FBQSxVQUFBRyxDQUFBLENBQUFJLEdBQUEsQ0FBQVAsQ0FBQSxPQUFBUSxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFkLENBQUEsb0JBQUFjLENBQUEsT0FBQUMsY0FBQSxDQUFBQyxJQUFBLENBQUFoQixDQUFBLEVBQUFjLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWIsQ0FBQSxFQUFBYyxDQUFBLFVBQUFHLENBQUEsS0FBQUEsQ0FBQSxDQUFBVixHQUFBLElBQUFVLENBQUEsQ0FBQUMsR0FBQSxJQUFBUCxNQUFBLENBQUFDLGNBQUEsQ0FBQUosQ0FBQSxFQUFBTSxDQUFBLEVBQUFHLENBQUEsSUFBQVQsQ0FBQSxDQUFBTSxDQUFBLElBQUFkLENBQUEsQ0FBQWMsQ0FBQSxZQUFBTixDQUFBLENBQUFILE9BQUEsR0FBQUwsQ0FBQSxFQUFBRyxDQUFBLElBQUFBLENBQUEsQ0FBQWUsR0FBQSxDQUFBbEIsQ0FBQSxFQUFBUSxDQUFBLEdBQUFBLENBQUE7QUFHckM7QUFDQTtBQUNBLE1BQU1XLE9BQStCLEdBQUc7RUFDdENDLE9BQU8sRUFBRTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0VBQ0RDLE9BQU8sRUFBRTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUVELE1BQU1DLE1BQWEsR0FBRyxDQUNwQjtFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFQyxHQUFHLEVBQUU7QUFBSSxDQUFDLEVBQzlCO0VBQUVELEtBQUssRUFBRSxTQUFTO0VBQUVDLEdBQUcsRUFBRTtBQUFHLENBQUMsRUFDN0I7RUFBRUQsS0FBSyxFQUFFLFNBQVM7RUFBRUMsR0FBRyxFQUFFO0FBQUcsQ0FBQyxDQUM5QjtBQUVELElBQUFDLGdCQUFRLEVBQUMsMENBQTBDLEVBQUUsTUFBTTtFQUN6RCxJQUFBQyxVQUFFLEVBQUMsMkVBQTJFLEVBQUUsTUFBTTtJQUNwRixNQUFNQyxNQUFNLEdBQUdDLGNBQU0sQ0FBQ0MsV0FBVyxDQUFDVixPQUFPLEVBQUV2QixNQUFNLENBQUM7SUFDbEQsSUFBQWtDLGNBQU0sRUFBQ0gsTUFBTSxDQUFDSSxLQUFLLENBQUNDLFdBQVcsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzVDLElBQUFILGNBQU0sRUFBQ0gsTUFBTSxDQUFDTyxTQUFTLENBQUNDLE1BQU0sQ0FBQyxDQUFDRixPQUFPLENBQUMsRUFBRSxDQUFDO0lBRTNDTixNQUFNLENBQUNTLEdBQUcsQ0FBQztNQUFFLGNBQWMsRUFBRTtRQUFFQyxLQUFLLEVBQUVmLE1BQU07UUFBRWdCLElBQUksRUFBRTtNQUFPO0lBQUUsQ0FBQyxDQUFDO0lBRS9ELElBQUFSLGNBQU0sRUFBQ0gsTUFBTSxDQUFDVSxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDSixPQUFPLENBQUMsQ0FDL0M7TUFBRVYsS0FBSyxFQUFFLFNBQVM7TUFBRUgsT0FBTyxFQUFFO0lBQUksQ0FBQyxFQUNsQztNQUFFRyxLQUFLLEVBQUUsU0FBUztNQUFFSCxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQ2xDLENBQUM7SUFDRixJQUFBVSxjQUFNLEVBQUNILE1BQU0sQ0FBQ1UsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDL0MsSUFBQVQsY0FBTSxFQUFDSCxNQUFNLENBQUNVLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUM7SUFDQSxJQUFBVCxjQUFNLEVBQUNILE1BQU0sQ0FBQ08sU0FBUyxDQUFDTSxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUVGLElBQUksQ0FBQyxDQUFDQyxJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3JFLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyxvQ0FBb0MsRUFBRSxNQUFNO0lBQzdDLE1BQU1DLE1BQU0sR0FBR0MsY0FBTSxDQUFDQyxXQUFXLENBQUNWLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQztJQUNsRCtCLE1BQU0sQ0FBQ1MsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUVDLEtBQUssRUFBRWYsTUFBTTtRQUFFZ0IsSUFBSSxFQUFFO01BQU87SUFBRSxDQUFDLENBQUM7SUFDL0QsTUFBTUcsSUFBSSxHQUFHLENBQUMsR0FBR25CLE1BQU0sRUFBRTtNQUFFQyxLQUFLLEVBQUUsU0FBUztNQUFFQyxHQUFHLEVBQUU7SUFBRyxDQUFDLENBQUM7SUFDdkQsTUFBTWtCLElBQUksR0FBR2YsTUFBTSxDQUFDZ0IsTUFBTSxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUVOLEtBQUssRUFBRUksSUFBSTtRQUFFSCxJQUFJLEVBQUU7TUFBTztJQUFFLENBQUMsQ0FBQztJQUM3RSxJQUFBUixjQUFNLEVBQUNZLElBQUksQ0FBQ0UsT0FBTyxDQUFDLENBQUNYLE9BQU8sQ0FBQ0gsY0FBTSxDQUFDZSxlQUFlLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQzNGLElBQUFmLGNBQU0sRUFBQ0gsTUFBTSxDQUFDVSxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUMvQztJQUNBLElBQUFULGNBQU0sRUFBQ1ksSUFBSSxDQUFDRSxPQUFPLENBQUMsQ0FBQ0UsR0FBRyxDQUFDQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7RUFDdEQsQ0FBQyxDQUFDO0VBRUYsSUFBQXJCLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxNQUFNO0lBQ3hGLE1BQU1DLE1BQU0sR0FBR0MsY0FBTSxDQUFDQyxXQUFXLENBQUNWLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQztJQUNsRCtCLE1BQU0sQ0FBQ1MsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUVDLEtBQUssRUFBRWYsTUFBTTtRQUFFZ0IsSUFBSSxFQUFFO01BQU87SUFBRSxDQUFDLENBQUM7SUFFL0QsTUFBTVUsUUFBUSxHQUFHckIsTUFBTSxDQUFDc0IsUUFBUSxDQUFDLENBQUM7SUFDbEMsTUFBTUMsS0FBSyxHQUFHRixRQUFRLENBQUN6QyxHQUFHLENBQUMsa0JBQWtCLENBQUM7SUFDOUMsSUFBQXVCLGNBQU0sRUFBQ29CLEtBQUssQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztJQUMzQixJQUFBckIsY0FBTSxFQUFDb0IsS0FBSyxDQUFFRSxRQUFRLENBQUNDLEtBQUssQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNkLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQztJQUM5RCxJQUFBVCxjQUFNLEVBQUNvQixLQUFLLENBQUVLLE9BQU8sQ0FBQyxDQUFDaEIsSUFBSSxDQUFDLFdBQVcsQ0FBQztFQUMxQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=