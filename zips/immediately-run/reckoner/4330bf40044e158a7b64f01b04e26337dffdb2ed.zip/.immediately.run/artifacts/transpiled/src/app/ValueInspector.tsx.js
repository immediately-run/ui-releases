var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _precedents = require("../engine/precedents.ts");
var _verdictChip = require("../report/render/verdictChip.ts");
var _PrecedentView = _interopRequireDefault(require("./PrecedentView.tsx"));
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The value inspector — review surface slice 2 (design brief surface 2, first cut). The
// provenance surface: what this number IS, where it comes from, and how well it is tested —
// binding name, `doc`, read-only formula source, declared-input chips (navigable hop-by-hop:
// the brief's V3 chain pixel → binding → formula → inputs → sources), current value + tier,
// and the coverage state.
//
// Deliberate v1 boundaries, recorded in the handoff: the **tier badge slot is reserved for
// the host** (review-1 H2 — the badge is host-drawn trust chrome; the tier appears here as
// plain data, never as a badge imitation), the **precedent-neighborhood view** (review-1
// UX-4) and the **on-pixel affordance** (V3's hover-reveal / long-press) are follow-ons —
// this slice opens from the workbook panel's cards. Edit / ask-assistant affordances wait
// for a writable mount (none in the standalone demo).

function preview(value) {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') return String(Math.round(value * 1000) / 1000);
  if (typeof value === 'string' || typeof value === 'boolean') return String(value);
  const json = JSON.stringify(value);
  return json === undefined ? '—' : json.length > 160 ? `${json.slice(0, 160)}…` : json;
}
/** The RCD §5.1 disclosure, at the button (Grove's dispatch wording): edits land in
 *  the mounted content, and proposing them back to the source repository is not
 *  wired. Rendered once when ANY row carries a door (the tooltip rides every button;
 *  this line makes the disclosure visible even in a row-set where only a test row
 *  is editable), directly after the formula row. */
const EDIT_DISCLOSURE = 'Edits save to the mounted content. Proposing a change back to its repository is not wired yet.';
function ValueInspector({
  cell,
  cells,
  tests,
  verdicts,
  result,
  onNavigate,
  onClose,
  onWhatIf,
  worksheetPaths,
  canEditPath,
  onEdit
}) {
  const fileLine = (worksheet, span) => {
    const path = worksheetPaths?.[worksheet];
    return path !== undefined && span !== undefined ? `${path}:${span.line}` : null;
  };
  const cellAt = fileLine(cell.worksheet, cell.span);
  const outcome = verdicts?.get(cell.id);
  const chip = (0, _verdictChip.verdictChip)(cell.id, verdicts);
  // The row door (§3): beside the `file:line` anchor, only where the row's own path
  // passes the gate. Absent — not disabled — everywhere else.
  const rowDoor = worksheet => {
    const path = worksheetPaths?.[worksheet];
    if (path === undefined) return null;
    return canEditPath !== undefined && onEdit !== undefined && canEditPath(path) ? path : null;
  };
  const cellDoor = rowDoor(cell.worksheet);
  // Any door in the row-set renders the disclosure line (see EDIT_DISCLOSURE above).
  const anyDoor = cellDoor !== null || tests.some(t => rowDoor(t.worksheet) !== null);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-ins",
    "aria-label": `Inspector for ${cell.id}`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "rk-ins-head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-ins-title",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-wb-name",
          children: cell.id
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: chip.className,
          children: chip.label
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-close",
        onClick: onClose,
        children: "Close"
      })]
    }), cell.doc !== '' && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "rk-ins-doc",
      children: cell.doc
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "value"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-value",
        children: preview(result?.value)
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "rk-ins-tier",
        children: ["tier ", result?.tier ?? '—']
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "inputs"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-ins-chips",
        children: [cell.resolvers.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-ins-none",
          children: "none declared"
        }), cell.resolvers.map(r => {
          if (r.kind === 'cell') {
            return /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
              type: "button",
              className: "rk-chip rk-chip--nav",
              onClick: () => onNavigate(r.nodeId),
              children: [r.name, " \u2190 ", r.nodeId]
            }, r.name);
          }
          if (r.kind === 'windowed-feed') {
            return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "rk-chip",
              children: [r.name, " \u2190 feed ", r.feed, " \xB7 ", r.window]
            }, r.name);
          }
          if (r.kind === 'wildcard') {
            return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "rk-chip",
              children: [r.name, " \u2190 ", r.worksheet, ".*"]
            }, r.name);
          }
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "rk-chip",
            children: [r.name, " \u2190 ", r.key]
          }, r.name);
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "rk-ins-label",
        children: ["formula", onWhatIf !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-chip rk-chip--nav rk-chip--whatif",
          onClick: onWhatIf,
          children: "what if \u2192"
        }), cellAt !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-ins-fileline",
          children: cellAt
        }), cellDoor !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-chip rk-chip--nav rk-chip--edit",
          title: EDIT_DISCLOSURE,
          onClick: () => onEdit?.(cellDoor),
          children: "edit"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
        className: "rk-ins-formula",
        children: cell.formulaSource
      })]
    }), anyDoor && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "rk-ins-edit-note",
      children: EDIT_DISCLOSURE
    }), cell.resolvers.some(r => r.kind === 'cell' || r.kind === 'wildcard') && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "precedents"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_PrecedentView.default, {
        tree: (0, _precedents.precedentTree)(cell.id, cells),
        onNavigate: onNavigate
      })]
    }), tests.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "tests"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-ins-tests",
        children: tests.map(t => {
          const o = outcome?.outcomes.find(x => x.id === t.id);
          const testAt = fileLine(t.worksheet, t.span);
          const testDoor = rowDoor(t.worksheet);
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: `rk-wb-test ${o?.pass === false ? 'rk-wb-test--fail' : 'rk-wb-test--pass'}`,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "rk-wb-kind",
              children: t.kind
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "rk-wb-test-name",
              children: t.name
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "rk-wb-outcome",
              children: o === undefined ? '' : o.pass ? 'pass' : 'fail'
            }), testAt !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "rk-ins-fileline",
              children: testAt
            }), testDoor !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
              type: "button",
              className: "rk-chip rk-chip--nav rk-chip--edit",
              title: EDIT_DISCLOSURE,
              onClick: () => onEdit?.(testDoor),
              children: "edit"
            }), o !== undefined && !o.pass && o.message !== '' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              className: "rk-wb-test-msg",
              children: o.message
            })]
          }, t.id);
        })
      })]
    })]
  });
}
_c = ValueInspector;
var _default = exports.default = ValueInspector;
var _c;
$RefreshReg$(_c, "ValueInspector");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcHJlY2VkZW50cyIsInJlcXVpcmUiLCJfdmVyZGljdENoaXAiLCJfUHJlY2VkZW50VmlldyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInByZXZpZXciLCJ2YWx1ZSIsInVuZGVmaW5lZCIsIlN0cmluZyIsIk1hdGgiLCJyb3VuZCIsImpzb24iLCJKU09OIiwic3RyaW5naWZ5IiwibGVuZ3RoIiwic2xpY2UiLCJFRElUX0RJU0NMT1NVUkUiLCJWYWx1ZUluc3BlY3RvciIsImNlbGwiLCJjZWxscyIsInRlc3RzIiwidmVyZGljdHMiLCJyZXN1bHQiLCJvbk5hdmlnYXRlIiwib25DbG9zZSIsIm9uV2hhdElmIiwid29ya3NoZWV0UGF0aHMiLCJjYW5FZGl0UGF0aCIsIm9uRWRpdCIsImZpbGVMaW5lIiwid29ya3NoZWV0Iiwic3BhbiIsInBhdGgiLCJsaW5lIiwiY2VsbEF0Iiwib3V0Y29tZSIsImdldCIsImlkIiwiY2hpcCIsInZlcmRpY3RDaGlwIiwicm93RG9vciIsImNlbGxEb29yIiwiYW55RG9vciIsInNvbWUiLCJ0IiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwibGFiZWwiLCJ0eXBlIiwib25DbGljayIsImRvYyIsInRpZXIiLCJyZXNvbHZlcnMiLCJtYXAiLCJyIiwia2luZCIsIm5vZGVJZCIsIm5hbWUiLCJmZWVkIiwid2luZG93Iiwia2V5IiwidGl0bGUiLCJmb3JtdWxhU291cmNlIiwidHJlZSIsInByZWNlZGVudFRyZWUiLCJvIiwib3V0Y29tZXMiLCJmaW5kIiwieCIsInRlc3RBdCIsInRlc3REb29yIiwicGFzcyIsIm1lc3NhZ2UiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlZhbHVlSW5zcGVjdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgdmFsdWUgaW5zcGVjdG9yIOKAlCByZXZpZXcgc3VyZmFjZSBzbGljZSAyIChkZXNpZ24gYnJpZWYgc3VyZmFjZSAyLCBmaXJzdCBjdXQpLiBUaGVcbi8vIHByb3ZlbmFuY2Ugc3VyZmFjZTogd2hhdCB0aGlzIG51bWJlciBJUywgd2hlcmUgaXQgY29tZXMgZnJvbSwgYW5kIGhvdyB3ZWxsIGl0IGlzIHRlc3RlZCDigJRcbi8vIGJpbmRpbmcgbmFtZSwgYGRvY2AsIHJlYWQtb25seSBmb3JtdWxhIHNvdXJjZSwgZGVjbGFyZWQtaW5wdXQgY2hpcHMgKG5hdmlnYWJsZSBob3AtYnktaG9wOlxuLy8gdGhlIGJyaWVmJ3MgVjMgY2hhaW4gcGl4ZWwg4oaSIGJpbmRpbmcg4oaSIGZvcm11bGEg4oaSIGlucHV0cyDihpIgc291cmNlcyksIGN1cnJlbnQgdmFsdWUgKyB0aWVyLFxuLy8gYW5kIHRoZSBjb3ZlcmFnZSBzdGF0ZS5cbi8vXG4vLyBEZWxpYmVyYXRlIHYxIGJvdW5kYXJpZXMsIHJlY29yZGVkIGluIHRoZSBoYW5kb2ZmOiB0aGUgKip0aWVyIGJhZGdlIHNsb3QgaXMgcmVzZXJ2ZWQgZm9yXG4vLyB0aGUgaG9zdCoqIChyZXZpZXctMSBIMiDigJQgdGhlIGJhZGdlIGlzIGhvc3QtZHJhd24gdHJ1c3QgY2hyb21lOyB0aGUgdGllciBhcHBlYXJzIGhlcmUgYXNcbi8vIHBsYWluIGRhdGEsIG5ldmVyIGFzIGEgYmFkZ2UgaW1pdGF0aW9uKSwgdGhlICoqcHJlY2VkZW50LW5laWdoYm9yaG9vZCB2aWV3KiogKHJldmlldy0xXG4vLyBVWC00KSBhbmQgdGhlICoqb24tcGl4ZWwgYWZmb3JkYW5jZSoqIChWMydzIGhvdmVyLXJldmVhbCAvIGxvbmctcHJlc3MpIGFyZSBmb2xsb3ctb25zIOKAlFxuLy8gdGhpcyBzbGljZSBvcGVucyBmcm9tIHRoZSB3b3JrYm9vayBwYW5lbCdzIGNhcmRzLiBFZGl0IC8gYXNrLWFzc2lzdGFudCBhZmZvcmRhbmNlcyB3YWl0XG4vLyBmb3IgYSB3cml0YWJsZSBtb3VudCAobm9uZSBpbiB0aGUgc3RhbmRhbG9uZSBkZW1vKS5cbmltcG9ydCB0eXBlIHsgQ2VsbERlc2NyaXB0b3IsIFN1YmplY3RSZXN1bHQsIFRlc3REZXNjcmlwdG9yIH0gZnJvbSAnLi4vZW5naW5lL3dvcmtlci9wcm90b2NvbC50cyc7XG5pbXBvcnQgdHlwZSB7IFB1Ymxpc2hlZFJlc3VsdCB9IGZyb20gJy4uL2VuZ2luZS90eXBlcy50cyc7XG5pbXBvcnQgeyBwcmVjZWRlbnRUcmVlIH0gZnJvbSAnLi4vZW5naW5lL3ByZWNlZGVudHMudHMnO1xuaW1wb3J0IHsgdmVyZGljdENoaXAgfSBmcm9tICcuLi9yZXBvcnQvcmVuZGVyL3ZlcmRpY3RDaGlwLnRzJztcbmltcG9ydCB0eXBlIHsgVmFsdWUgfSBmcm9tICcuLi9zdGRsaWIvdHlwZXMudHMnO1xuaW1wb3J0IFByZWNlZGVudFZpZXcgZnJvbSAnLi9QcmVjZWRlbnRWaWV3LnRzeCc7XG5pbXBvcnQgJy4vd29ya2Jvb2stcGFuZWwuY3NzJztcblxuZnVuY3Rpb24gcHJldmlldyh2YWx1ZTogVmFsdWUgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuICfigJQnO1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIFN0cmluZyhNYXRoLnJvdW5kKHZhbHVlICogMTAwMCkgLyAxMDAwKTtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICBjb25zdCBqc29uID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICByZXR1cm4ganNvbiA9PT0gdW5kZWZpbmVkID8gJ+KAlCcgOiBqc29uLmxlbmd0aCA+IDE2MCA/IGAke2pzb24uc2xpY2UoMCwgMTYwKX3igKZgIDoganNvbjtcbn1cblxuaW50ZXJmYWNlIFZhbHVlSW5zcGVjdG9yUHJvcHMge1xuICBjZWxsOiBDZWxsRGVzY3JpcHRvcjtcbiAgLyoqIEV2ZXJ5IGNlbGwgb2YgdGhlIHdvcmtib29rICh0aGUgcHJlY2VkZW50IG5laWdoYm9yaG9vZCdzIHN1YnN0cmF0ZSkuICovXG4gIGNlbGxzOiByZWFkb25seSBDZWxsRGVzY3JpcHRvcltdO1xuICAvKiogRXZlcnkgdGVzdCB0YXJnZXRpbmcgdGhpcyBjZWxsIChmaWx0ZXJlZCBieSBzdWJqZWN0IGJ5IHRoZSBjYWxsZXIpLiAqL1xuICB0ZXN0czogcmVhZG9ubHkgVGVzdERlc2NyaXB0b3JbXTtcbiAgLyoqIFRoZSBhcHAtbGV2ZWwgc3VpdGUgcmVzdWx0cyDigJQgYG51bGxgIHdoaWxlIHRoZSBzdWl0ZXMgYXJlIHN0aWxsIGNvbXB1dGluZywgd2hpY2hcbiAgICogIHJlbmRlcnMgdGhlIGRpc3RpbmN0IGBwZW5kaW5nYCBjaGlwIChuZXZlciBhIHByZW1hdHVyZSBgdW50ZXN0ZWRgKTsgYSBjZWxsIGFic2VudFxuICAgKiAgZnJvbSB0aGUgc2V0dGxlZCBtYXAgaXMgdGhlIGNvbXB1dGVkIGB1bnRlc3RlZGAuICovXG4gIHZlcmRpY3RzOiBSZWFkb25seU1hcDxzdHJpbmcsIFN1YmplY3RSZXN1bHQ+IHwgbnVsbDtcbiAgLyoqIFRoZSBwdWJsaXNoZWQgcmVzdWx0ICh2YWx1ZSArIHRpZXIpLiAqL1xuICByZXN1bHQ6IFB1Ymxpc2hlZFJlc3VsdCB8IHVuZGVmaW5lZDtcbiAgLyoqIE5hdmlnYXRlIHRvIGFub3RoZXIgY2VsbCAoYW4gaW5wdXQgY2hpcCkg4oCUIHRoZSBob3AtYnktaG9wIFYzIHdhbGsuICovXG4gIG9uTmF2aWdhdGU6IChjZWxsSWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgLyoqXG4gICAqIE9wZW4gdGhlIHdoYXQtaWYgZWRpdG9yIGZvciB0aGlzIGNlbGwgKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMS4xLCBhbWVuZGVkXG4gICAqIDIwMjYtMDgtMjgpOiB0aGUgY291bnRlcmZhY3R1YWwgc2VjdGlvbiBpcyBjb2xsYXBzZWQgYnkgZGVmYXVsdCwgYW5kIHRoaXMgYWZmb3JkYW5jZVxuICAgKiBvbiB0aGUgZm9ybXVsYSByb3cgaXMgaXRzIGRvb3Ig4oCUIGFic2VudCwgbm8gd2hhdC1pZiBjaHJvbWUgcmVuZGVycyBhdCBhbGwuXG4gICAqL1xuICBvbldoYXRJZj86ICgpID0+IHZvaWQ7XG4gIC8qKlxuICAgKiBXb3Jrc2hlZXQgbmFtZSDihpIgZG9jdW1lbnQtcmVsYXRpdmUgZmlsZSBwYXRoIChSMy00MjcpOiB3aXRoIHRoZSBkZXNjcmlwdG9yIHNwYW5zLFxuICAgKiB0aGUgZm9ybXVsYSByb3cgYW5kIGVhY2ggdGVzdCByb3cgbmFtZSB0aGVpciBleGFjdCBgZmlsZTpsaW5lYCwgc28gY29ycmVjdGluZyBhXG4gICAqIGZhdWx0eSBmb3JtdWxhIG9yIHRlc3QgYnkgaGFuZCBzdGFydHMgZnJvbSBhIGxvY2F0aW9uLCBub3QgYSBzZWFyY2guIFBsYWluIGRhdGEgZm9yXG4gICAqIG5vdzsgdGhlIGNsaWNrYWJsZSBvcGVuLWF0LWxpbmUgcmlkZSB0aGUgbmF2aWdhdG9yIHdvcmsgKyB0aGUgZWRpdG9yIGxpbmUtaGludC5cbiAgICovXG4gIHdvcmtzaGVldFBhdGhzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgLyoqXG4gICAqIFBhcnQgQidzIGVkaXQgZG9vciAoRE9DVU1FTlRfTkFWSUdBVE9SX1NQRUMgwqczL8KnNCwgUjMtNDQ3KTogdGhlIHBlci1yb3cgcGxhdGZvcm1cbiAgICogZWRpdG9yIGRlbGVnYXRpb24uIGBjYW5FZGl0UGF0aGAgZGVjaWRlcywgUEVSIFJPVywgd2hldGhlciB0aGUgZG9vciByZW5kZXJzIOKAlFxuICAgKiBhYnNlbnQgKG5ldmVyIGRpc2FibGVkKSB3aGVuIHRoZSBtb3VudCBpcyBub3QgYHJ3YCwgdGhlIGRvb3IgaXMgbGF0Y2hlZCBvZmYsIG9yXG4gICAqIHRoZSBwYXRoIGZhaWxzIHRoZSDCpzQuMyBnYXRlLiBgb25FZGl0YCBvcGVucyB0aGUgcGxhdGZvcm0gZWRpdG9yIG9uIHRoYXQgZmlsZS5cbiAgICogQm90aCBhcmUgdW5kZWZpbmVkL2Fic2VudCB0b2dldGhlciBpbiB0aGUgc2VlZCAobm9uLWRpc3BhdGNoZWQpIGZsb3cuXG4gICAqL1xuICBjYW5FZGl0UGF0aD86IChyZWxQYXRoOiBzdHJpbmcpID0+IGJvb2xlYW47XG4gIG9uRWRpdD86IChyZWxQYXRoOiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbi8qKiBUaGUgUkNEIMKnNS4xIGRpc2Nsb3N1cmUsIGF0IHRoZSBidXR0b24gKEdyb3ZlJ3MgZGlzcGF0Y2ggd29yZGluZyk6IGVkaXRzIGxhbmQgaW5cbiAqICB0aGUgbW91bnRlZCBjb250ZW50LCBhbmQgcHJvcG9zaW5nIHRoZW0gYmFjayB0byB0aGUgc291cmNlIHJlcG9zaXRvcnkgaXMgbm90XG4gKiAgd2lyZWQuIFJlbmRlcmVkIG9uY2Ugd2hlbiBBTlkgcm93IGNhcnJpZXMgYSBkb29yICh0aGUgdG9vbHRpcCByaWRlcyBldmVyeSBidXR0b247XG4gKiAgdGhpcyBsaW5lIG1ha2VzIHRoZSBkaXNjbG9zdXJlIHZpc2libGUgZXZlbiBpbiBhIHJvdy1zZXQgd2hlcmUgb25seSBhIHRlc3Qgcm93XG4gKiAgaXMgZWRpdGFibGUpLCBkaXJlY3RseSBhZnRlciB0aGUgZm9ybXVsYSByb3cuICovXG5jb25zdCBFRElUX0RJU0NMT1NVUkUgPSAnRWRpdHMgc2F2ZSB0byB0aGUgbW91bnRlZCBjb250ZW50LiBQcm9wb3NpbmcgYSBjaGFuZ2UgYmFjayB0byBpdHMgcmVwb3NpdG9yeSBpcyBub3Qgd2lyZWQgeWV0Lic7XG5mdW5jdGlvbiBWYWx1ZUluc3BlY3Rvcih7IGNlbGwsIGNlbGxzLCB0ZXN0cywgdmVyZGljdHMsIHJlc3VsdCwgb25OYXZpZ2F0ZSwgb25DbG9zZSwgb25XaGF0SWYsIHdvcmtzaGVldFBhdGhzLCBjYW5FZGl0UGF0aCwgb25FZGl0IH06IFZhbHVlSW5zcGVjdG9yUHJvcHMpIHtcbiAgY29uc3QgZmlsZUxpbmUgPSAod29ya3NoZWV0OiBzdHJpbmcsIHNwYW4/OiB7IGxpbmU6IG51bWJlciB9KTogc3RyaW5nIHwgbnVsbCA9PiB7XG4gICAgY29uc3QgcGF0aCA9IHdvcmtzaGVldFBhdGhzPy5bd29ya3NoZWV0XTtcbiAgICByZXR1cm4gcGF0aCAhPT0gdW5kZWZpbmVkICYmIHNwYW4gIT09IHVuZGVmaW5lZCA/IGAke3BhdGh9OiR7c3Bhbi5saW5lfWAgOiBudWxsO1xuICB9O1xuICBjb25zdCBjZWxsQXQgPSBmaWxlTGluZShjZWxsLndvcmtzaGVldCwgY2VsbC5zcGFuKTtcbiAgY29uc3Qgb3V0Y29tZSA9IHZlcmRpY3RzPy5nZXQoY2VsbC5pZCk7XG4gIGNvbnN0IGNoaXAgPSB2ZXJkaWN0Q2hpcChjZWxsLmlkLCB2ZXJkaWN0cyk7XG4gIC8vIFRoZSByb3cgZG9vciAowqczKTogYmVzaWRlIHRoZSBgZmlsZTpsaW5lYCBhbmNob3IsIG9ubHkgd2hlcmUgdGhlIHJvdydzIG93biBwYXRoXG4gIC8vIHBhc3NlcyB0aGUgZ2F0ZS4gQWJzZW50IOKAlCBub3QgZGlzYWJsZWQg4oCUIGV2ZXJ5d2hlcmUgZWxzZS5cbiAgY29uc3Qgcm93RG9vciA9ICh3b3Jrc2hlZXQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwgPT4ge1xuICAgIGNvbnN0IHBhdGggPSB3b3Jrc2hlZXRQYXRocz8uW3dvcmtzaGVldF07XG4gICAgaWYgKHBhdGggPT09IHVuZGVmaW5lZCkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIGNhbkVkaXRQYXRoICE9PSB1bmRlZmluZWQgJiYgb25FZGl0ICE9PSB1bmRlZmluZWQgJiYgY2FuRWRpdFBhdGgocGF0aCkgPyBwYXRoIDogbnVsbDtcbiAgfTtcbiAgY29uc3QgY2VsbERvb3IgPSByb3dEb29yKGNlbGwud29ya3NoZWV0KTtcbiAgLy8gQW55IGRvb3IgaW4gdGhlIHJvdy1zZXQgcmVuZGVycyB0aGUgZGlzY2xvc3VyZSBsaW5lIChzZWUgRURJVF9ESVNDTE9TVVJFIGFib3ZlKS5cbiAgY29uc3QgYW55RG9vciA9IGNlbGxEb29yICE9PSBudWxsIHx8IHRlc3RzLnNvbWUoKHQpID0+IHJvd0Rvb3IodC53b3Jrc2hlZXQpICE9PSBudWxsKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWluc1wiIGFyaWEtbGFiZWw9e2BJbnNwZWN0b3IgZm9yICR7Y2VsbC5pZH1gfT5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicmstaW5zLWhlYWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtdGl0bGVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay13Yi1uYW1lXCI+e2NlbGwuaWR9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y2hpcC5jbGFzc05hbWV9PntjaGlwLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgQ2xvc2VcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAge2NlbGwuZG9jICE9PSAnJyAmJiA8cCBjbGFzc05hbWU9XCJyay1pbnMtZG9jXCI+e2NlbGwuZG9jfTwvcD59XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstaW5zLXJvd1wiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtbGFiZWxcIj52YWx1ZTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstaW5zLXZhbHVlXCI+e3ByZXZpZXcocmVzdWx0Py52YWx1ZSl9PC9zcGFuPlxuICAgICAgICB7LyogUGxhaW4gdGV4dCwgbm90IGEgYmFkZ2U6IHRoZSB0aWVyIGJhZGdlIGlzIGhvc3QtZHJhd24gY2hyb21lIChyZXZpZXctMSBIMikg4oCUXG4gICAgICAgICAgICB0aGlzIGFwcCBzdXBwbGllcyB0aGUgdmFsdWUgYW5kIHJlc2VydmVzIHRoZSBzbG90LCBpdCBuZXZlciBkcmF3cyBvbmUuICovfVxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtdGllclwiPnRpZXIge3Jlc3VsdD8udGllciA/PyAn4oCUJ308L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtcm93XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWlucy1sYWJlbFwiPmlucHV0czwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtY2hpcHNcIj5cbiAgICAgICAgICB7Y2VsbC5yZXNvbHZlcnMubGVuZ3RoID09PSAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLWlucy1ub25lXCI+bm9uZSBkZWNsYXJlZDwvc3Bhbj59XG4gICAgICAgICAge2NlbGwucmVzb2x2ZXJzLm1hcCgocikgPT4ge1xuICAgICAgICAgICAgaWYgKHIua2luZCA9PT0gJ2NlbGwnKSB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3IubmFtZX0gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLWNoaXAgcmstY2hpcC0tbmF2XCIgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZShyLm5vZGVJZCl9PlxuICAgICAgICAgICAgICAgICAge3IubmFtZX0g4oaQIHtyLm5vZGVJZH1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyLmtpbmQgPT09ICd3aW5kb3dlZC1mZWVkJykge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxzcGFuIGtleT17ci5uYW1lfSBjbGFzc05hbWU9XCJyay1jaGlwXCI+XG4gICAgICAgICAgICAgICAgICB7ci5uYW1lfSDihpAgZmVlZCB7ci5mZWVkfSDCtyB7ci53aW5kb3d9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHIua2luZCA9PT0gJ3dpbGRjYXJkJykge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxzcGFuIGtleT17ci5uYW1lfSBjbGFzc05hbWU9XCJyay1jaGlwXCI+XG4gICAgICAgICAgICAgICAgICB7ci5uYW1lfSDihpAge3Iud29ya3NoZWV0fS4qXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXtyLm5hbWV9IGNsYXNzTmFtZT1cInJrLWNoaXBcIj5cbiAgICAgICAgICAgICAgICB7ci5uYW1lfSDihpAge3Iua2V5fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWlucy1yb3dcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstaW5zLWxhYmVsXCI+XG4gICAgICAgICAgZm9ybXVsYVxuICAgICAgICAgIHtvbldoYXRJZiAhPT0gdW5kZWZpbmVkICYmIChcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLWNoaXAgcmstY2hpcC0tbmF2IHJrLWNoaXAtLXdoYXRpZlwiIG9uQ2xpY2s9e29uV2hhdElmfT5cbiAgICAgICAgICAgICAgd2hhdCBpZiDihpJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgICAge2NlbGxBdCAhPT0gbnVsbCAmJiA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtZmlsZWxpbmVcIj57Y2VsbEF0fTwvc3Bhbj59XG4gICAgICAgICAge2NlbGxEb29yICE9PSBudWxsICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJrLWNoaXAgcmstY2hpcC0tbmF2IHJrLWNoaXAtLWVkaXRcIlxuICAgICAgICAgICAgICB0aXRsZT17RURJVF9ESVNDTE9TVVJFfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkVkaXQ/LihjZWxsRG9vcil9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIGVkaXRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPHByZSBjbGFzc05hbWU9XCJyay1pbnMtZm9ybXVsYVwiPntjZWxsLmZvcm11bGFTb3VyY2V9PC9wcmU+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2FueURvb3IgJiYgPHAgY2xhc3NOYW1lPVwicmstaW5zLWVkaXQtbm90ZVwiPntFRElUX0RJU0NMT1NVUkV9PC9wPn1cblxuICAgICAge2NlbGwucmVzb2x2ZXJzLnNvbWUoKHIpID0+IHIua2luZCA9PT0gJ2NlbGwnIHx8IHIua2luZCA9PT0gJ3dpbGRjYXJkJykgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWlucy1yb3dcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtbGFiZWxcIj5wcmVjZWRlbnRzPC9zcGFuPlxuICAgICAgICAgIDxQcmVjZWRlbnRWaWV3IHRyZWU9e3ByZWNlZGVudFRyZWUoY2VsbC5pZCwgY2VsbHMpfSBvbk5hdmlnYXRlPXtvbk5hdmlnYXRlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHt0ZXN0cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtcm93XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstaW5zLWxhYmVsXCI+dGVzdHM8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtdGVzdHNcIj5cbiAgICAgICAgICAgIHt0ZXN0cy5tYXAoKHQpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgbyA9IG91dGNvbWU/Lm91dGNvbWVzLmZpbmQoKHgpID0+IHguaWQgPT09IHQuaWQpO1xuICAgICAgICAgICAgICBjb25zdCB0ZXN0QXQgPSBmaWxlTGluZSh0LndvcmtzaGVldCwgdC5zcGFuKTtcbiAgICAgICAgICAgICAgY29uc3QgdGVzdERvb3IgPSByb3dEb29yKHQud29ya3NoZWV0KTtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17dC5pZH0gY2xhc3NOYW1lPXtgcmstd2ItdGVzdCAke28/LnBhc3MgPT09IGZhbHNlID8gJ3JrLXdiLXRlc3QtLWZhaWwnIDogJ3JrLXdiLXRlc3QtLXBhc3MnfWB9PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstd2Ita2luZFwiPnt0LmtpbmR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstd2ItdGVzdC1uYW1lXCI+e3QubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay13Yi1vdXRjb21lXCI+e28gPT09IHVuZGVmaW5lZCA/ICcnIDogby5wYXNzID8gJ3Bhc3MnIDogJ2ZhaWwnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHt0ZXN0QXQgIT09IG51bGwgJiYgPHNwYW4gY2xhc3NOYW1lPVwicmstaW5zLWZpbGVsaW5lXCI+e3Rlc3RBdH08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAge3Rlc3REb29yICE9PSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJrLWNoaXAgcmstY2hpcC0tbmF2IHJrLWNoaXAtLWVkaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtFRElUX0RJU0NMT1NVUkV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25FZGl0Py4odGVzdERvb3IpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgZWRpdFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7byAhPT0gdW5kZWZpbmVkICYmICFvLnBhc3MgJiYgby5tZXNzYWdlICE9PSAnJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInJrLXdiLXRlc3QtbXNnXCI+e28ubWVzc2FnZX08L2Rpdj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBWYWx1ZUluc3BlY3RvcjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQWNBLElBQUFBLFdBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUQsT0FBQTtBQUVBLElBQUFFLGNBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBQSxPQUFBO0FBQThCLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLFNBQUFHLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBbEI5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBU0EsU0FBU0csT0FBT0EsQ0FBQ0MsS0FBd0IsRUFBVTtFQUNqRCxJQUFJQSxLQUFLLEtBQUssSUFBSSxJQUFJQSxLQUFLLEtBQUtDLFNBQVMsRUFBRSxPQUFPLEdBQUc7RUFDckQsSUFBSSxPQUFPRCxLQUFLLEtBQUssUUFBUSxFQUFFLE9BQU9FLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUNKLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7RUFDN0UsSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJLE9BQU9BLEtBQUssS0FBSyxTQUFTLEVBQUUsT0FBT0UsTUFBTSxDQUFDRixLQUFLLENBQUM7RUFDakYsTUFBTUssSUFBSSxHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ1AsS0FBSyxDQUFDO0VBQ2xDLE9BQU9LLElBQUksS0FBS0osU0FBUyxHQUFHLEdBQUcsR0FBR0ksSUFBSSxDQUFDRyxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUdILElBQUksQ0FBQ0ksS0FBSyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHSixJQUFJO0FBQ3ZGO0FBeUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNSyxlQUFlLEdBQUcsZ0dBQWdHO0FBQ3hILFNBQVNDLGNBQWNBLENBQUM7RUFBRUMsSUFBSTtFQUFFQyxLQUFLO0VBQUVDLEtBQUs7RUFBRUMsUUFBUTtFQUFFQyxNQUFNO0VBQUVDLFVBQVU7RUFBRUMsT0FBTztFQUFFQyxRQUFRO0VBQUVDLGNBQWM7RUFBRUMsV0FBVztFQUFFQztBQUE0QixDQUFDLEVBQUU7RUFDekosTUFBTUMsUUFBUSxHQUFHQSxDQUFDQyxTQUFpQixFQUFFQyxJQUF1QixLQUFvQjtJQUM5RSxNQUFNQyxJQUFJLEdBQUdOLGNBQWMsR0FBR0ksU0FBUyxDQUFDO0lBQ3hDLE9BQU9FLElBQUksS0FBS3pCLFNBQVMsSUFBSXdCLElBQUksS0FBS3hCLFNBQVMsR0FBRyxHQUFHeUIsSUFBSSxJQUFJRCxJQUFJLENBQUNFLElBQUksRUFBRSxHQUFHLElBQUk7RUFDakYsQ0FBQztFQUNELE1BQU1DLE1BQU0sR0FBR0wsUUFBUSxDQUFDWCxJQUFJLENBQUNZLFNBQVMsRUFBRVosSUFBSSxDQUFDYSxJQUFJLENBQUM7RUFDbEQsTUFBTUksT0FBTyxHQUFHZCxRQUFRLEVBQUVlLEdBQUcsQ0FBQ2xCLElBQUksQ0FBQ21CLEVBQUUsQ0FBQztFQUN0QyxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsd0JBQVcsRUFBQ3JCLElBQUksQ0FBQ21CLEVBQUUsRUFBRWhCLFFBQVEsQ0FBQztFQUMzQztFQUNBO0VBQ0EsTUFBTW1CLE9BQU8sR0FBSVYsU0FBaUIsSUFBb0I7SUFDcEQsTUFBTUUsSUFBSSxHQUFHTixjQUFjLEdBQUdJLFNBQVMsQ0FBQztJQUN4QyxJQUFJRSxJQUFJLEtBQUt6QixTQUFTLEVBQUUsT0FBTyxJQUFJO0lBQ25DLE9BQU9vQixXQUFXLEtBQUtwQixTQUFTLElBQUlxQixNQUFNLEtBQUtyQixTQUFTLElBQUlvQixXQUFXLENBQUNLLElBQUksQ0FBQyxHQUFHQSxJQUFJLEdBQUcsSUFBSTtFQUM3RixDQUFDO0VBQ0QsTUFBTVMsUUFBUSxHQUFHRCxPQUFPLENBQUN0QixJQUFJLENBQUNZLFNBQVMsQ0FBQztFQUN4QztFQUNBLE1BQU1ZLE9BQU8sR0FBR0QsUUFBUSxLQUFLLElBQUksSUFBSXJCLEtBQUssQ0FBQ3VCLElBQUksQ0FBRUMsQ0FBQyxJQUFLSixPQUFPLENBQUNJLENBQUMsQ0FBQ2QsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDO0VBQ3JGLG9CQUNFLElBQUE3QixXQUFBLENBQUE0QyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxRQUFRO0lBQUMsY0FBWSxpQkFBaUI1QixJQUFJLENBQUNtQixFQUFFLEVBQUc7SUFBQVUsUUFBQSxnQkFDN0QsSUFBQTlDLFdBQUEsQ0FBQTRDLElBQUE7TUFBUUMsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxnQkFDN0IsSUFBQTlDLFdBQUEsQ0FBQTRDLElBQUE7UUFBS0MsU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxnQkFDM0IsSUFBQTlDLFdBQUEsQ0FBQStDLEdBQUE7VUFBTUYsU0FBUyxFQUFDLFlBQVk7VUFBQUMsUUFBQSxFQUFFN0IsSUFBSSxDQUFDbUI7UUFBRSxDQUFPLENBQUMsZUFDN0MsSUFBQXBDLFdBQUEsQ0FBQStDLEdBQUE7VUFBTUYsU0FBUyxFQUFFUixJQUFJLENBQUNRLFNBQVU7VUFBQUMsUUFBQSxFQUFFVCxJQUFJLENBQUNXO1FBQUssQ0FBTyxDQUFDO01BQUEsQ0FDakQsQ0FBQyxlQUNOLElBQUFoRCxXQUFBLENBQUErQyxHQUFBO1FBQVFFLElBQUksRUFBQyxRQUFRO1FBQUNKLFNBQVMsRUFBQyxhQUFhO1FBQUNLLE9BQU8sRUFBRTNCLE9BQVE7UUFBQXVCLFFBQUEsRUFBQztNQUVoRSxDQUFRLENBQUM7SUFBQSxDQUNILENBQUMsRUFFUjdCLElBQUksQ0FBQ2tDLEdBQUcsS0FBSyxFQUFFLGlCQUFJLElBQUFuRCxXQUFBLENBQUErQyxHQUFBO01BQUdGLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsRUFBRTdCLElBQUksQ0FBQ2tDO0lBQUcsQ0FBSSxDQUFDLGVBRTVELElBQUFuRCxXQUFBLENBQUE0QyxJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUE5QyxXQUFBLENBQUErQyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFBQztNQUFLLENBQU0sQ0FBQyxlQUMzQyxJQUFBOUMsV0FBQSxDQUFBK0MsR0FBQTtRQUFNRixTQUFTLEVBQUMsY0FBYztRQUFBQyxRQUFBLEVBQUUxQyxPQUFPLENBQUNpQixNQUFNLEVBQUVoQixLQUFLO01BQUMsQ0FBTyxDQUFDLGVBRzlELElBQUFMLFdBQUEsQ0FBQTRDLElBQUE7UUFBTUMsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxHQUFDLE9BQUssRUFBQ3pCLE1BQU0sRUFBRStCLElBQUksSUFBSSxHQUFHO01BQUEsQ0FBTyxDQUFDO0lBQUEsQ0FDNUQsQ0FBQyxlQUVOLElBQUFwRCxXQUFBLENBQUE0QyxJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUE5QyxXQUFBLENBQUErQyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFBQztNQUFNLENBQU0sQ0FBQyxlQUM1QyxJQUFBOUMsV0FBQSxDQUFBNEMsSUFBQTtRQUFLQyxTQUFTLEVBQUMsY0FBYztRQUFBQyxRQUFBLEdBQzFCN0IsSUFBSSxDQUFDb0MsU0FBUyxDQUFDeEMsTUFBTSxLQUFLLENBQUMsaUJBQUksSUFBQWIsV0FBQSxDQUFBK0MsR0FBQTtVQUFNRixTQUFTLEVBQUMsYUFBYTtVQUFBQyxRQUFBLEVBQUM7UUFBYSxDQUFNLENBQUMsRUFDakY3QixJQUFJLENBQUNvQyxTQUFTLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLO1VBQ3pCLElBQUlBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNyQixvQkFDRSxJQUFBeEQsV0FBQSxDQUFBNEMsSUFBQTtjQUFxQkssSUFBSSxFQUFDLFFBQVE7Y0FBQ0osU0FBUyxFQUFDLHNCQUFzQjtjQUFDSyxPQUFPLEVBQUVBLENBQUEsS0FBTTVCLFVBQVUsQ0FBQ2lDLENBQUMsQ0FBQ0UsTUFBTSxDQUFFO2NBQUFYLFFBQUEsR0FDckdTLENBQUMsQ0FBQ0csSUFBSSxFQUFDLFVBQUcsRUFBQ0gsQ0FBQyxDQUFDRSxNQUFNO1lBQUEsR0FEVEYsQ0FBQyxDQUFDRyxJQUVQLENBQUM7VUFFYjtVQUNBLElBQUlILENBQUMsQ0FBQ0MsSUFBSSxLQUFLLGVBQWUsRUFBRTtZQUM5QixvQkFDRSxJQUFBeEQsV0FBQSxDQUFBNEMsSUFBQTtjQUFtQkMsU0FBUyxFQUFDLFNBQVM7Y0FBQUMsUUFBQSxHQUNuQ1MsQ0FBQyxDQUFDRyxJQUFJLEVBQUMsZUFBUSxFQUFDSCxDQUFDLENBQUNJLElBQUksRUFBQyxRQUFHLEVBQUNKLENBQUMsQ0FBQ0ssTUFBTTtZQUFBLEdBRDNCTCxDQUFDLENBQUNHLElBRVAsQ0FBQztVQUVYO1VBQ0EsSUFBSUgsQ0FBQyxDQUFDQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQ3pCLG9CQUNFLElBQUF4RCxXQUFBLENBQUE0QyxJQUFBO2NBQW1CQyxTQUFTLEVBQUMsU0FBUztjQUFBQyxRQUFBLEdBQ25DUyxDQUFDLENBQUNHLElBQUksRUFBQyxVQUFHLEVBQUNILENBQUMsQ0FBQzFCLFNBQVMsRUFBQyxJQUMxQjtZQUFBLEdBRlcwQixDQUFDLENBQUNHLElBRVAsQ0FBQztVQUVYO1VBQ0Esb0JBQ0UsSUFBQTFELFdBQUEsQ0FBQTRDLElBQUE7WUFBbUJDLFNBQVMsRUFBQyxTQUFTO1lBQUFDLFFBQUEsR0FDbkNTLENBQUMsQ0FBQ0csSUFBSSxFQUFDLFVBQUcsRUFBQ0gsQ0FBQyxDQUFDTSxHQUFHO1VBQUEsR0FEUk4sQ0FBQyxDQUFDRyxJQUVQLENBQUM7UUFFWCxDQUFDLENBQUM7TUFBQSxDQUNDLENBQUM7SUFBQSxDQUNILENBQUMsZUFFTixJQUFBMUQsV0FBQSxDQUFBNEMsSUFBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLGdCQUN6QixJQUFBOUMsV0FBQSxDQUFBNEMsSUFBQTtRQUFNQyxTQUFTLEVBQUMsY0FBYztRQUFBQyxRQUFBLEdBQUMsU0FFN0IsRUFBQ3RCLFFBQVEsS0FBS2xCLFNBQVMsaUJBQ3JCLElBQUFOLFdBQUEsQ0FBQStDLEdBQUE7VUFBUUUsSUFBSSxFQUFDLFFBQVE7VUFBQ0osU0FBUyxFQUFDLHNDQUFzQztVQUFDSyxPQUFPLEVBQUUxQixRQUFTO1VBQUFzQixRQUFBLEVBQUM7UUFFMUYsQ0FBUSxDQUNULEVBQ0FiLE1BQU0sS0FBSyxJQUFJLGlCQUFJLElBQUFqQyxXQUFBLENBQUErQyxHQUFBO1VBQU1GLFNBQVMsRUFBQyxpQkFBaUI7VUFBQUMsUUFBQSxFQUFFYjtRQUFNLENBQU8sQ0FBQyxFQUNwRU8sUUFBUSxLQUFLLElBQUksaUJBQ2hCLElBQUF4QyxXQUFBLENBQUErQyxHQUFBO1VBQ0VFLElBQUksRUFBQyxRQUFRO1VBQ2JKLFNBQVMsRUFBQyxvQ0FBb0M7VUFDOUNpQixLQUFLLEVBQUUvQyxlQUFnQjtVQUN2Qm1DLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdkIsTUFBTSxHQUFHYSxRQUFRLENBQUU7VUFBQU0sUUFBQSxFQUNuQztRQUVELENBQVEsQ0FDVDtNQUFBLENBQ0csQ0FBQyxlQUNQLElBQUE5QyxXQUFBLENBQUErQyxHQUFBO1FBQUtGLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUMsUUFBQSxFQUFFN0IsSUFBSSxDQUFDOEM7TUFBYSxDQUFNLENBQUM7SUFBQSxDQUN2RCxDQUFDLEVBRUx0QixPQUFPLGlCQUFJLElBQUF6QyxXQUFBLENBQUErQyxHQUFBO01BQUdGLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxFQUFFL0I7SUFBZSxDQUFJLENBQUMsRUFFaEVFLElBQUksQ0FBQ29DLFNBQVMsQ0FBQ1gsSUFBSSxDQUFFYSxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLE1BQU0sSUFBSUQsQ0FBQyxDQUFDQyxJQUFJLEtBQUssVUFBVSxDQUFDLGlCQUNyRSxJQUFBeEQsV0FBQSxDQUFBNEMsSUFBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLGdCQUN6QixJQUFBOUMsV0FBQSxDQUFBK0MsR0FBQTtRQUFNRixTQUFTLEVBQUMsY0FBYztRQUFBQyxRQUFBLEVBQUM7TUFBVSxDQUFNLENBQUMsZUFDaEQsSUFBQTlDLFdBQUEsQ0FBQStDLEdBQUEsRUFBQ2pELGNBQUEsQ0FBQUssT0FBYTtRQUFDNkQsSUFBSSxFQUFFLElBQUFDLHlCQUFhLEVBQUNoRCxJQUFJLENBQUNtQixFQUFFLEVBQUVsQixLQUFLLENBQUU7UUFBQ0ksVUFBVSxFQUFFQTtNQUFXLENBQUUsQ0FBQztJQUFBLENBQzNFLENBQ04sRUFFQUgsS0FBSyxDQUFDTixNQUFNLEdBQUcsQ0FBQyxpQkFDZixJQUFBYixXQUFBLENBQUE0QyxJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUE5QyxXQUFBLENBQUErQyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFBQztNQUFLLENBQU0sQ0FBQyxlQUMzQyxJQUFBOUMsV0FBQSxDQUFBK0MsR0FBQTtRQUFLRixTQUFTLEVBQUMsY0FBYztRQUFBQyxRQUFBLEVBQzFCM0IsS0FBSyxDQUFDbUMsR0FBRyxDQUFFWCxDQUFDLElBQUs7VUFDaEIsTUFBTXVCLENBQUMsR0FBR2hDLE9BQU8sRUFBRWlDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ2pDLEVBQUUsS0FBS08sQ0FBQyxDQUFDUCxFQUFFLENBQUM7VUFDdEQsTUFBTWtDLE1BQU0sR0FBRzFDLFFBQVEsQ0FBQ2UsQ0FBQyxDQUFDZCxTQUFTLEVBQUVjLENBQUMsQ0FBQ2IsSUFBSSxDQUFDO1VBQzVDLE1BQU15QyxRQUFRLEdBQUdoQyxPQUFPLENBQUNJLENBQUMsQ0FBQ2QsU0FBUyxDQUFDO1VBQ3JDLG9CQUNFLElBQUE3QixXQUFBLENBQUE0QyxJQUFBO1lBQWdCQyxTQUFTLEVBQUUsY0FBY3FCLENBQUMsRUFBRU0sSUFBSSxLQUFLLEtBQUssR0FBRyxrQkFBa0IsR0FBRyxrQkFBa0IsRUFBRztZQUFBMUIsUUFBQSxnQkFDckcsSUFBQTlDLFdBQUEsQ0FBQStDLEdBQUE7Y0FBTUYsU0FBUyxFQUFDLFlBQVk7Y0FBQUMsUUFBQSxFQUFFSCxDQUFDLENBQUNhO1lBQUksQ0FBTyxDQUFDLGVBQzVDLElBQUF4RCxXQUFBLENBQUErQyxHQUFBO2NBQU1GLFNBQVMsRUFBQyxpQkFBaUI7Y0FBQUMsUUFBQSxFQUFFSCxDQUFDLENBQUNlO1lBQUksQ0FBTyxDQUFDLGVBQ2pELElBQUExRCxXQUFBLENBQUErQyxHQUFBO2NBQU1GLFNBQVMsRUFBQyxlQUFlO2NBQUFDLFFBQUEsRUFBRW9CLENBQUMsS0FBSzVELFNBQVMsR0FBRyxFQUFFLEdBQUc0RCxDQUFDLENBQUNNLElBQUksR0FBRyxNQUFNLEdBQUc7WUFBTSxDQUFPLENBQUMsRUFDdkZGLE1BQU0sS0FBSyxJQUFJLGlCQUFJLElBQUF0RSxXQUFBLENBQUErQyxHQUFBO2NBQU1GLFNBQVMsRUFBQyxpQkFBaUI7Y0FBQUMsUUFBQSxFQUFFd0I7WUFBTSxDQUFPLENBQUMsRUFDcEVDLFFBQVEsS0FBSyxJQUFJLGlCQUNoQixJQUFBdkUsV0FBQSxDQUFBK0MsR0FBQTtjQUNFRSxJQUFJLEVBQUMsUUFBUTtjQUNiSixTQUFTLEVBQUMsb0NBQW9DO2NBQzlDaUIsS0FBSyxFQUFFL0MsZUFBZ0I7Y0FDdkJtQyxPQUFPLEVBQUVBLENBQUEsS0FBTXZCLE1BQU0sR0FBRzRDLFFBQVEsQ0FBRTtjQUFBekIsUUFBQSxFQUNuQztZQUVELENBQVEsQ0FDVCxFQUNBb0IsQ0FBQyxLQUFLNUQsU0FBUyxJQUFJLENBQUM0RCxDQUFDLENBQUNNLElBQUksSUFBSU4sQ0FBQyxDQUFDTyxPQUFPLEtBQUssRUFBRSxpQkFBSSxJQUFBekUsV0FBQSxDQUFBK0MsR0FBQTtjQUFLRixTQUFTLEVBQUMsZ0JBQWdCO2NBQUFDLFFBQUEsRUFBRW9CLENBQUMsQ0FBQ087WUFBTyxDQUFNLENBQUM7VUFBQSxHQWY1RjlCLENBQUMsQ0FBQ1AsRUFnQlAsQ0FBQztRQUVWLENBQUM7TUFBQyxDQUNDLENBQUM7SUFBQSxDQUNILENBQ047RUFBQSxDQUNFLENBQUM7QUFFVjtBQUFDc0MsRUFBQSxHQTVJUTFELGNBQWM7QUFBQSxJQUFBMkQsUUFBQSxHQUFBQyxPQUFBLENBQUF6RSxPQUFBLEdBOElSYSxjQUFjO0FBQUEsSUFBQTBELEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}