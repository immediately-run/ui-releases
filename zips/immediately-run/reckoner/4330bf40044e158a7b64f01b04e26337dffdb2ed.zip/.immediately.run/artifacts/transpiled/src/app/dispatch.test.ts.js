"use strict";

var _vitest = require("vitest");
var _dispatch = require("./dispatch.ts");
// The open-workbook dispatched flow (R3-169 pattern, after Grove's open-wiki):
// resolution from the mount set, and the full session over a real mounted document
// (the DCF notebook's shape — the same `loadDocument` pipeline as the seed, but read
// from the filesystem port instead of embedded constants).

const mount = over => ({
  id: 'm',
  path: '/x',
  type: 'app',
  ...over
});
(0, _vitest.describe)('resolveWorkbookMount', () => {
  (0, _vitest.it)('the repo-load mark: the one mount typed "content" is the workbook root, and the ok variant carries the mount itself (Part B, R3-447)', () => {
    const wb = mount({
      id: 'content:o/r',
      path: '/task/7/dir',
      type: 'content',
      mode: 'ro'
    });
    const mounts = [mount({
      id: 'app',
      path: '/app',
      type: 'app'
    }), wb];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: true,
      root: '/task/7/dir',
      via: 'repo-load',
      mount: wb
    });
  });
  (0, _vitest.it)('the carried mount is what the edit door addresses: id and mode come from the live descriptor (G-DN-B1)', () => {
    const r = (0, _dispatch.resolveWorkbookMount)([mount({
      id: 'content:owner/repo',
      path: '/mnt/h',
      type: 'content',
      mode: 'rw'
    })]);
    if (!r.ok) throw new Error('expected ok');
    (0, _vitest.expect)(r.mount.id).toBe('content:owner/repo');
    (0, _vitest.expect)(r.mount.mode).toBe('rw');
  });
  (0, _vitest.it)('foreign mounts WITHOUT the mark are not guessed at (a space, a worktree)', () => {
    const mounts = [mount({
      id: 'app',
      path: '/app',
      type: 'app'
    }), mount({
      id: 'space',
      path: '/space/abc',
      type: 'space'
    }), mount({
      id: 'wt',
      path: '/wt/1',
      type: 'worktree'
    })];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('no mounts → the seed document flow', () => {
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([])).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('two marked mounts is a host bug we refuse, not paper over', () => {
    const mounts = [mount({
      id: 'a',
      path: '/a',
      type: 'content'
    }), mount({
      id: 'b',
      path: '/b',
      type: 'content'
    })];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: false,
      reason: 'ambiguous'
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9kaXNwYXRjaCIsIm1vdW50Iiwib3ZlciIsImlkIiwicGF0aCIsInR5cGUiLCJkZXNjcmliZSIsIml0Iiwid2IiLCJtb2RlIiwibW91bnRzIiwiZXhwZWN0IiwicmVzb2x2ZVdvcmtib29rTW91bnQiLCJ0b0VxdWFsIiwib2siLCJyb290IiwidmlhIiwiciIsIkVycm9yIiwidG9CZSIsInJlYXNvbiJdLCJzb3VyY2VzIjpbImRpc3BhdGNoLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIG9wZW4td29ya2Jvb2sgZGlzcGF0Y2hlZCBmbG93IChSMy0xNjkgcGF0dGVybiwgYWZ0ZXIgR3JvdmUncyBvcGVuLXdpa2kpOlxuLy8gcmVzb2x1dGlvbiBmcm9tIHRoZSBtb3VudCBzZXQsIGFuZCB0aGUgZnVsbCBzZXNzaW9uIG92ZXIgYSByZWFsIG1vdW50ZWQgZG9jdW1lbnRcbi8vICh0aGUgRENGIG5vdGVib29rJ3Mgc2hhcGUg4oCUIHRoZSBzYW1lIGBsb2FkRG9jdW1lbnRgIHBpcGVsaW5lIGFzIHRoZSBzZWVkLCBidXQgcmVhZFxuLy8gZnJvbSB0aGUgZmlsZXN5c3RlbSBwb3J0IGluc3RlYWQgb2YgZW1iZWRkZWQgY29uc3RhbnRzKS5cblxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgcmVzb2x2ZVdvcmtib29rTW91bnQgfSBmcm9tICcuL2Rpc3BhdGNoLnRzJztcbmltcG9ydCB0eXBlIHsgU2FuZGJveE1vdW50IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuXG5jb25zdCBtb3VudCA9IChvdmVyOiBQYXJ0aWFsPFNhbmRib3hNb3VudD4pOiBTYW5kYm94TW91bnQgPT5cbiAgKHsgaWQ6ICdtJywgcGF0aDogJy94JywgdHlwZTogJ2FwcCcsIC4uLm92ZXIgfSkgYXMgU2FuZGJveE1vdW50O1xuXG5kZXNjcmliZSgncmVzb2x2ZVdvcmtib29rTW91bnQnLCAoKSA9PiB7XG4gIGl0KCd0aGUgcmVwby1sb2FkIG1hcms6IHRoZSBvbmUgbW91bnQgdHlwZWQgXCJjb250ZW50XCIgaXMgdGhlIHdvcmtib29rIHJvb3QsIGFuZCB0aGUgb2sgdmFyaWFudCBjYXJyaWVzIHRoZSBtb3VudCBpdHNlbGYgKFBhcnQgQiwgUjMtNDQ3KScsICgpID0+IHtcbiAgICBjb25zdCB3YiA9IG1vdW50KHsgaWQ6ICdjb250ZW50Om8vcicsIHBhdGg6ICcvdGFzay83L2RpcicsIHR5cGU6ICdjb250ZW50JywgbW9kZTogJ3JvJyB9KTtcbiAgICBjb25zdCBtb3VudHMgPSBbbW91bnQoeyBpZDogJ2FwcCcsIHBhdGg6ICcvYXBwJywgdHlwZTogJ2FwcCcgfSksIHdiXTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQobW91bnRzKSkudG9FcXVhbCh7IG9rOiB0cnVlLCByb290OiAnL3Rhc2svNy9kaXInLCB2aWE6ICdyZXBvLWxvYWQnLCBtb3VudDogd2IgfSk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgY2FycmllZCBtb3VudCBpcyB3aGF0IHRoZSBlZGl0IGRvb3IgYWRkcmVzc2VzOiBpZCBhbmQgbW9kZSBjb21lIGZyb20gdGhlIGxpdmUgZGVzY3JpcHRvciAoRy1ETi1CMSknLCAoKSA9PiB7XG4gICAgY29uc3QgciA9IHJlc29sdmVXb3JrYm9va01vdW50KFtcbiAgICAgIG1vdW50KHsgaWQ6ICdjb250ZW50Om93bmVyL3JlcG8nLCBwYXRoOiAnL21udC9oJywgdHlwZTogJ2NvbnRlbnQnLCBtb2RlOiAncncnIH0pLFxuICAgIF0pO1xuICAgIGlmICghci5vaykgdGhyb3cgbmV3IEVycm9yKCdleHBlY3RlZCBvaycpO1xuICAgIGV4cGVjdChyLm1vdW50LmlkKS50b0JlKCdjb250ZW50Om93bmVyL3JlcG8nKTtcbiAgICBleHBlY3Qoci5tb3VudC5tb2RlKS50b0JlKCdydycpO1xuICB9KTtcblxuICBpdCgnZm9yZWlnbiBtb3VudHMgV0lUSE9VVCB0aGUgbWFyayBhcmUgbm90IGd1ZXNzZWQgYXQgKGEgc3BhY2UsIGEgd29ya3RyZWUpJywgKCkgPT4ge1xuICAgIGNvbnN0IG1vdW50cyA9IFtcbiAgICAgIG1vdW50KHsgaWQ6ICdhcHAnLCBwYXRoOiAnL2FwcCcsIHR5cGU6ICdhcHAnIH0pLFxuICAgICAgbW91bnQoeyBpZDogJ3NwYWNlJywgcGF0aDogJy9zcGFjZS9hYmMnLCB0eXBlOiAnc3BhY2UnIH0pLFxuICAgICAgbW91bnQoeyBpZDogJ3d0JywgcGF0aDogJy93dC8xJywgdHlwZTogJ3dvcmt0cmVlJyB9KSxcbiAgICBdO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMpKS50b0VxdWFsKHsgb2s6IGZhbHNlLCByZWFzb246ICdub3QtZGlzcGF0Y2hlZCcgfSk7XG4gIH0pO1xuXG4gIGl0KCdubyBtb3VudHMg4oaSIHRoZSBzZWVkIGRvY3VtZW50IGZsb3cnLCAoKSA9PiB7XG4gICAgZXhwZWN0KHJlc29sdmVXb3JrYm9va01vdW50KFtdKSkudG9FcXVhbCh7IG9rOiBmYWxzZSwgcmVhc29uOiAnbm90LWRpc3BhdGNoZWQnIH0pO1xuICB9KTtcblxuICBpdCgndHdvIG1hcmtlZCBtb3VudHMgaXMgYSBob3N0IGJ1ZyB3ZSByZWZ1c2UsIG5vdCBwYXBlciBvdmVyJywgKCkgPT4ge1xuICAgIGNvbnN0IG1vdW50cyA9IFtcbiAgICAgIG1vdW50KHsgaWQ6ICdhJywgcGF0aDogJy9hJywgdHlwZTogJ2NvbnRlbnQnIH0pLFxuICAgICAgbW91bnQoeyBpZDogJ2InLCBwYXRoOiAnL2InLCB0eXBlOiAnY29udGVudCcgfSksXG4gICAgXTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQobW91bnRzKSkudG9FcXVhbCh7IG9rOiBmYWxzZSwgcmVhc29uOiAnYW1iaWd1b3VzJyB9KTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFLQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFOQTtBQUNBO0FBQ0E7QUFDQTs7QUFNQSxNQUFNRSxLQUFLLEdBQUlDLElBQTJCLEtBQ3ZDO0VBQUVDLEVBQUUsRUFBRSxHQUFHO0VBQUVDLElBQUksRUFBRSxJQUFJO0VBQUVDLElBQUksRUFBRSxLQUFLO0VBQUUsR0FBR0g7QUFBSyxDQUFDLENBQWlCO0FBRWpFLElBQUFJLGdCQUFRLEVBQUMsc0JBQXNCLEVBQUUsTUFBTTtFQUNyQyxJQUFBQyxVQUFFLEVBQUMsc0lBQXNJLEVBQUUsTUFBTTtJQUMvSSxNQUFNQyxFQUFFLEdBQUdQLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDekYsTUFBTUMsTUFBTSxHQUFHLENBQUNULEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsS0FBSztNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsRUFBRUcsRUFBRSxDQUFDO0lBQ3BFLElBQUFHLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQ0YsTUFBTSxDQUFDLENBQUMsQ0FBQ0csT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRSxhQUFhO01BQUVDLEdBQUcsRUFBRSxXQUFXO01BQUVmLEtBQUssRUFBRU87SUFBRyxDQUFDLENBQUM7RUFDOUcsQ0FBQyxDQUFDO0VBRUYsSUFBQUQsVUFBRSxFQUFDLHdHQUF3RyxFQUFFLE1BQU07SUFDakgsTUFBTVUsQ0FBQyxHQUFHLElBQUFMLDhCQUFvQixFQUFDLENBQzdCWCxLQUFLLENBQUM7TUFBRUUsRUFBRSxFQUFFLG9CQUFvQjtNQUFFQyxJQUFJLEVBQUUsUUFBUTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FDakYsQ0FBQztJQUNGLElBQUksQ0FBQ1EsQ0FBQyxDQUFDSCxFQUFFLEVBQUUsTUFBTSxJQUFJSSxLQUFLLENBQUMsYUFBYSxDQUFDO0lBQ3pDLElBQUFQLGNBQU0sRUFBQ00sQ0FBQyxDQUFDaEIsS0FBSyxDQUFDRSxFQUFFLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUM3QyxJQUFBUixjQUFNLEVBQUNNLENBQUMsQ0FBQ2hCLEtBQUssQ0FBQ1EsSUFBSSxDQUFDLENBQUNVLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDakMsQ0FBQyxDQUFDO0VBRUYsSUFBQVosVUFBRSxFQUFDLDBFQUEwRSxFQUFFLE1BQU07SUFDbkYsTUFBTUcsTUFBTSxHQUFHLENBQ2JULEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsS0FBSztNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsRUFDL0NKLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUUsWUFBWTtNQUFFQyxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUMsRUFDekRKLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUMsQ0FDckQ7SUFDRCxJQUFBTSxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUNGLE1BQU0sQ0FBQyxDQUFDLENBQUNHLE9BQU8sQ0FBQztNQUFFQyxFQUFFLEVBQUUsS0FBSztNQUFFTSxNQUFNLEVBQUU7SUFBaUIsQ0FBQyxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyxvQ0FBb0MsRUFBRSxNQUFNO0lBQzdDLElBQUFJLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRU0sTUFBTSxFQUFFO0lBQWlCLENBQUMsQ0FBQztFQUNuRixDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxNQUFNRyxNQUFNLEdBQUcsQ0FDYlQsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxHQUFHO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxFQUMvQ0osS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxHQUFHO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxDQUNoRDtJQUNELElBQUFNLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQ0YsTUFBTSxDQUFDLENBQUMsQ0FBQ0csT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxLQUFLO01BQUVNLE1BQU0sRUFBRTtJQUFZLENBQUMsQ0FBQztFQUNsRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=