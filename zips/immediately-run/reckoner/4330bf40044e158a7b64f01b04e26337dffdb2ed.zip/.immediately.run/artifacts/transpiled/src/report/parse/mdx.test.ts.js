"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _mdx = require("./mdx.ts");
var _validate = require("../validate.ts");
(0, _vitest.describe)('parseTemplate', () => {
  (0, _vitest.it)('keeps markdown prose as opaque text', () => {
    const nodes = (0, _mdx.parseTemplate)('# Weekly revenue.\n\nSome prose here.');
    (0, _vitest.expect)(nodes).toHaveLength(1);
    (0, _vitest.expect)(nodes[0].type).toBe('markdown');
    (0, _vitest.expect)(nodes[0].text).toContain('# Weekly revenue.');
  });
  (0, _vitest.it)('parses a self-closing component with typed literal attributes', () => {
    const [node] = (0, _mdx.parseTemplate)('<Kpi source="revenue.total" spark format="currency" />');
    const c = node;
    (0, _vitest.expect)(c.type).toBe('component');
    (0, _vitest.expect)(c.name).toBe('Kpi');
    (0, _vitest.expect)(c.attrs.source).toEqual({
      kind: 'literal',
      value: 'revenue.total'
    });
    (0, _vitest.expect)(c.attrs.spark).toEqual({
      kind: 'literal',
      value: true
    }); // bare boolean
    (0, _vitest.expect)(c.attrs.format).toEqual({
      kind: 'literal',
      value: 'currency'
    });
  });
  (0, _vitest.it)('captures braced literals as literals and expressions as inert', () => {
    const [node] = (0, _mdx.parseTemplate)('<Select name="region" options={["all", "emea"]} evil={fetch("/x")} />');
    const c = node;
    (0, _vitest.expect)(c.attrs.options).toEqual({
      kind: 'literal',
      value: ['all', 'emea']
    });
    (0, _vitest.expect)(c.attrs.evil.kind).toBe('inert'); // never evaluated
    (0, _vitest.expect)(c.attrs.evil).toMatchObject({
      kind: 'inert',
      text: 'fetch("/x")'
    });
  });
  (0, _vitest.it)('parses nested children (Facets wraps a Chart)', () => {
    const src = '<Facets source="churn.by_cohort" by="cohort">\n  <Chart kind="bar" x="month" y="churned" />\n</Facets>';
    const [node] = (0, _mdx.parseTemplate)(src);
    const c = node;
    (0, _vitest.expect)(c.name).toBe('Facets');
    const child = c.children.find(n => n.type === 'component');
    (0, _vitest.expect)(child?.name).toBe('Chart');
    (0, _vitest.expect)(child?.attrs.kind).toEqual({
      kind: 'literal',
      value: 'bar'
    });
  });
  (0, _vitest.it)('interleaves prose and components at block level', () => {
    const src = '# Report.\n\n<Kpi source="revenue.total" />\n\nMore prose.';
    const nodes = (0, _mdx.parseTemplate)(src);
    const kinds = nodes.map(n => n.type === 'component' ? n.name : 'md');
    (0, _vitest.expect)(kinds).toEqual(['md', 'Kpi', 'md']);
  });
  (0, _vitest.it)('produces trees the existing validator accepts', () => {
    const src = '<Params>\n<Select name="region" options={["all","emea"]} default="all" />\n</Params>\n<Kpi source="revenue.total" format="currency" />';
    const nodes = (0, _mdx.parseTemplate)(src);
    const result = (0, _validate.validateTemplate)(nodes);
    (0, _vitest.expect)(result.diagnostics.filter(d => d.severity === 'error')).toHaveLength(0);
    (0, _vitest.expect)(result.bindings).toContain('revenue.total');
  });
  (0, _vitest.it)('an unknown component still parses to a node (renders as placeholder later)', () => {
    const [node] = (0, _mdx.parseTemplate)('<Timeline source="x.y" />');
    (0, _vitest.expect)(node.name).toBe('Timeline');
    (0, _vitest.expect)((0, _validate.validateTemplate)([node]).placeholders).toEqual(['Timeline']);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9tZHgiLCJfdmFsaWRhdGUiLCJkZXNjcmliZSIsIml0Iiwibm9kZXMiLCJwYXJzZVRlbXBsYXRlIiwiZXhwZWN0IiwidG9IYXZlTGVuZ3RoIiwidHlwZSIsInRvQmUiLCJ0ZXh0IiwidG9Db250YWluIiwibm9kZSIsImMiLCJuYW1lIiwiYXR0cnMiLCJzb3VyY2UiLCJ0b0VxdWFsIiwia2luZCIsInZhbHVlIiwic3BhcmsiLCJmb3JtYXQiLCJvcHRpb25zIiwiZXZpbCIsInRvTWF0Y2hPYmplY3QiLCJzcmMiLCJjaGlsZCIsImNoaWxkcmVuIiwiZmluZCIsIm4iLCJraW5kcyIsIm1hcCIsInJlc3VsdCIsInZhbGlkYXRlVGVtcGxhdGUiLCJkaWFnbm9zdGljcyIsImZpbHRlciIsImQiLCJzZXZlcml0eSIsImJpbmRpbmdzIiwicGxhY2Vob2xkZXJzIl0sInNvdXJjZXMiOlsibWR4LnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVzY3JpYmUsIGV4cGVjdCwgaXQgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgcGFyc2VUZW1wbGF0ZSB9IGZyb20gJy4vbWR4LnRzJztcbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSwgTWFya2Rvd25Ob2RlIH0gZnJvbSAnLi4vbm9kZXMudHMnO1xuaW1wb3J0IHsgdmFsaWRhdGVUZW1wbGF0ZSB9IGZyb20gJy4uL3ZhbGlkYXRlLnRzJztcblxuZGVzY3JpYmUoJ3BhcnNlVGVtcGxhdGUnLCAoKSA9PiB7XG4gIGl0KCdrZWVwcyBtYXJrZG93biBwcm9zZSBhcyBvcGFxdWUgdGV4dCcsICgpID0+IHtcbiAgICBjb25zdCBub2RlcyA9IHBhcnNlVGVtcGxhdGUoJyMgV2Vla2x5IHJldmVudWUuXFxuXFxuU29tZSBwcm9zZSBoZXJlLicpO1xuICAgIGV4cGVjdChub2RlcykudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChub2Rlc1swXS50eXBlKS50b0JlKCdtYXJrZG93bicpO1xuICAgIGV4cGVjdCgobm9kZXNbMF0gYXMgTWFya2Rvd25Ob2RlKS50ZXh0KS50b0NvbnRhaW4oJyMgV2Vla2x5IHJldmVudWUuJyk7XG4gIH0pO1xuXG4gIGl0KCdwYXJzZXMgYSBzZWxmLWNsb3NpbmcgY29tcG9uZW50IHdpdGggdHlwZWQgbGl0ZXJhbCBhdHRyaWJ1dGVzJywgKCkgPT4ge1xuICAgIGNvbnN0IFtub2RlXSA9IHBhcnNlVGVtcGxhdGUoJzxLcGkgc291cmNlPVwicmV2ZW51ZS50b3RhbFwiIHNwYXJrIGZvcm1hdD1cImN1cnJlbmN5XCIgLz4nKTtcbiAgICBjb25zdCBjID0gbm9kZSBhcyBDb21wb25lbnROb2RlO1xuICAgIGV4cGVjdChjLnR5cGUpLnRvQmUoJ2NvbXBvbmVudCcpO1xuICAgIGV4cGVjdChjLm5hbWUpLnRvQmUoJ0twaScpO1xuICAgIGV4cGVjdChjLmF0dHJzLnNvdXJjZSkudG9FcXVhbCh7IGtpbmQ6ICdsaXRlcmFsJywgdmFsdWU6ICdyZXZlbnVlLnRvdGFsJyB9KTtcbiAgICBleHBlY3QoYy5hdHRycy5zcGFyaykudG9FcXVhbCh7IGtpbmQ6ICdsaXRlcmFsJywgdmFsdWU6IHRydWUgfSk7IC8vIGJhcmUgYm9vbGVhblxuICAgIGV4cGVjdChjLmF0dHJzLmZvcm1hdCkudG9FcXVhbCh7IGtpbmQ6ICdsaXRlcmFsJywgdmFsdWU6ICdjdXJyZW5jeScgfSk7XG4gIH0pO1xuXG4gIGl0KCdjYXB0dXJlcyBicmFjZWQgbGl0ZXJhbHMgYXMgbGl0ZXJhbHMgYW5kIGV4cHJlc3Npb25zIGFzIGluZXJ0JywgKCkgPT4ge1xuICAgIGNvbnN0IFtub2RlXSA9IHBhcnNlVGVtcGxhdGUoJzxTZWxlY3QgbmFtZT1cInJlZ2lvblwiIG9wdGlvbnM9e1tcImFsbFwiLCBcImVtZWFcIl19IGV2aWw9e2ZldGNoKFwiL3hcIil9IC8+Jyk7XG4gICAgY29uc3QgYyA9IG5vZGUgYXMgQ29tcG9uZW50Tm9kZTtcbiAgICBleHBlY3QoYy5hdHRycy5vcHRpb25zKS50b0VxdWFsKHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZTogWydhbGwnLCAnZW1lYSddIH0pO1xuICAgIGV4cGVjdChjLmF0dHJzLmV2aWwua2luZCkudG9CZSgnaW5lcnQnKTsgLy8gbmV2ZXIgZXZhbHVhdGVkXG4gICAgZXhwZWN0KGMuYXR0cnMuZXZpbCkudG9NYXRjaE9iamVjdCh7IGtpbmQ6ICdpbmVydCcsIHRleHQ6ICdmZXRjaChcIi94XCIpJyB9KTtcbiAgfSk7XG5cbiAgaXQoJ3BhcnNlcyBuZXN0ZWQgY2hpbGRyZW4gKEZhY2V0cyB3cmFwcyBhIENoYXJ0KScsICgpID0+IHtcbiAgICBjb25zdCBzcmMgPSAnPEZhY2V0cyBzb3VyY2U9XCJjaHVybi5ieV9jb2hvcnRcIiBieT1cImNvaG9ydFwiPlxcbiAgPENoYXJ0IGtpbmQ9XCJiYXJcIiB4PVwibW9udGhcIiB5PVwiY2h1cm5lZFwiIC8+XFxuPC9GYWNldHM+JztcbiAgICBjb25zdCBbbm9kZV0gPSBwYXJzZVRlbXBsYXRlKHNyYyk7XG4gICAgY29uc3QgYyA9IG5vZGUgYXMgQ29tcG9uZW50Tm9kZTtcbiAgICBleHBlY3QoYy5uYW1lKS50b0JlKCdGYWNldHMnKTtcbiAgICBjb25zdCBjaGlsZCA9IGMuY2hpbGRyZW4uZmluZCgobik6IG4gaXMgQ29tcG9uZW50Tm9kZSA9PiBuLnR5cGUgPT09ICdjb21wb25lbnQnKTtcbiAgICBleHBlY3QoY2hpbGQ/Lm5hbWUpLnRvQmUoJ0NoYXJ0Jyk7XG4gICAgZXhwZWN0KGNoaWxkPy5hdHRycy5raW5kKS50b0VxdWFsKHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZTogJ2JhcicgfSk7XG4gIH0pO1xuXG4gIGl0KCdpbnRlcmxlYXZlcyBwcm9zZSBhbmQgY29tcG9uZW50cyBhdCBibG9jayBsZXZlbCcsICgpID0+IHtcbiAgICBjb25zdCBzcmMgPSAnIyBSZXBvcnQuXFxuXFxuPEtwaSBzb3VyY2U9XCJyZXZlbnVlLnRvdGFsXCIgLz5cXG5cXG5Nb3JlIHByb3NlLic7XG4gICAgY29uc3Qgbm9kZXMgPSBwYXJzZVRlbXBsYXRlKHNyYyk7XG4gICAgY29uc3Qga2luZHMgPSBub2Rlcy5tYXAoKG4pID0+IChuLnR5cGUgPT09ICdjb21wb25lbnQnID8gbi5uYW1lIDogJ21kJykpO1xuICAgIGV4cGVjdChraW5kcykudG9FcXVhbChbJ21kJywgJ0twaScsICdtZCddKTtcbiAgfSk7XG5cbiAgaXQoJ3Byb2R1Y2VzIHRyZWVzIHRoZSBleGlzdGluZyB2YWxpZGF0b3IgYWNjZXB0cycsICgpID0+IHtcbiAgICBjb25zdCBzcmMgPSAnPFBhcmFtcz5cXG48U2VsZWN0IG5hbWU9XCJyZWdpb25cIiBvcHRpb25zPXtbXCJhbGxcIixcImVtZWFcIl19IGRlZmF1bHQ9XCJhbGxcIiAvPlxcbjwvUGFyYW1zPlxcbjxLcGkgc291cmNlPVwicmV2ZW51ZS50b3RhbFwiIGZvcm1hdD1cImN1cnJlbmN5XCIgLz4nO1xuICAgIGNvbnN0IG5vZGVzID0gcGFyc2VUZW1wbGF0ZShzcmMpO1xuICAgIGNvbnN0IHJlc3VsdCA9IHZhbGlkYXRlVGVtcGxhdGUobm9kZXMpO1xuICAgIGV4cGVjdChyZXN1bHQuZGlhZ25vc3RpY3MuZmlsdGVyKChkKSA9PiBkLnNldmVyaXR5ID09PSAnZXJyb3InKSkudG9IYXZlTGVuZ3RoKDApO1xuICAgIGV4cGVjdChyZXN1bHQuYmluZGluZ3MpLnRvQ29udGFpbigncmV2ZW51ZS50b3RhbCcpO1xuICB9KTtcblxuICBpdCgnYW4gdW5rbm93biBjb21wb25lbnQgc3RpbGwgcGFyc2VzIHRvIGEgbm9kZSAocmVuZGVycyBhcyBwbGFjZWhvbGRlciBsYXRlciknLCAoKSA9PiB7XG4gICAgY29uc3QgW25vZGVdID0gcGFyc2VUZW1wbGF0ZSgnPFRpbWVsaW5lIHNvdXJjZT1cIngueVwiIC8+Jyk7XG4gICAgZXhwZWN0KChub2RlIGFzIENvbXBvbmVudE5vZGUpLm5hbWUpLnRvQmUoJ1RpbWVsaW5lJyk7XG4gICAgZXhwZWN0KHZhbGlkYXRlVGVtcGxhdGUoW25vZGVdKS5wbGFjZWhvbGRlcnMpLnRvRXF1YWwoWydUaW1lbGluZSddKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBRUEsSUFBQUcsZ0JBQVEsRUFBQyxlQUFlLEVBQUUsTUFBTTtFQUM5QixJQUFBQyxVQUFFLEVBQUMscUNBQXFDLEVBQUUsTUFBTTtJQUM5QyxNQUFNQyxLQUFLLEdBQUcsSUFBQUMsa0JBQWEsRUFBQyx1Q0FBdUMsQ0FBQztJQUNwRSxJQUFBQyxjQUFNLEVBQUNGLEtBQUssQ0FBQyxDQUFDRyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdCLElBQUFELGNBQU0sRUFBQ0YsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN0QyxJQUFBSCxjQUFNLEVBQUVGLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBa0JNLElBQUksQ0FBQyxDQUFDQyxTQUFTLENBQUMsbUJBQW1CLENBQUM7RUFDeEUsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLCtEQUErRCxFQUFFLE1BQU07SUFDeEUsTUFBTSxDQUFDUyxJQUFJLENBQUMsR0FBRyxJQUFBUCxrQkFBYSxFQUFDLHdEQUF3RCxDQUFDO0lBQ3RGLE1BQU1RLENBQUMsR0FBR0QsSUFBcUI7SUFDL0IsSUFBQU4sY0FBTSxFQUFDTyxDQUFDLENBQUNMLElBQUksQ0FBQyxDQUFDQyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ2hDLElBQUFILGNBQU0sRUFBQ08sQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQ0wsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUMxQixJQUFBSCxjQUFNLEVBQUNPLENBQUMsQ0FBQ0UsS0FBSyxDQUFDQyxNQUFNLENBQUMsQ0FBQ0MsT0FBTyxDQUFDO01BQUVDLElBQUksRUFBRSxTQUFTO01BQUVDLEtBQUssRUFBRTtJQUFnQixDQUFDLENBQUM7SUFDM0UsSUFBQWIsY0FBTSxFQUFDTyxDQUFDLENBQUNFLEtBQUssQ0FBQ0ssS0FBSyxDQUFDLENBQUNILE9BQU8sQ0FBQztNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFQyxLQUFLLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pFLElBQUFiLGNBQU0sRUFBQ08sQ0FBQyxDQUFDRSxLQUFLLENBQUNNLE1BQU0sQ0FBQyxDQUFDSixPQUFPLENBQUM7TUFBRUMsSUFBSSxFQUFFLFNBQVM7TUFBRUMsS0FBSyxFQUFFO0lBQVcsQ0FBQyxDQUFDO0VBQ3hFLENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsK0RBQStELEVBQUUsTUFBTTtJQUN4RSxNQUFNLENBQUNTLElBQUksQ0FBQyxHQUFHLElBQUFQLGtCQUFhLEVBQUMsdUVBQXVFLENBQUM7SUFDckcsTUFBTVEsQ0FBQyxHQUFHRCxJQUFxQjtJQUMvQixJQUFBTixjQUFNLEVBQUNPLENBQUMsQ0FBQ0UsS0FBSyxDQUFDTyxPQUFPLENBQUMsQ0FBQ0wsT0FBTyxDQUFDO01BQUVDLElBQUksRUFBRSxTQUFTO01BQUVDLEtBQUssRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNO0lBQUUsQ0FBQyxDQUFDO0lBQzVFLElBQUFiLGNBQU0sRUFBQ08sQ0FBQyxDQUFDRSxLQUFLLENBQUNRLElBQUksQ0FBQ0wsSUFBSSxDQUFDLENBQUNULElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3pDLElBQUFILGNBQU0sRUFBQ08sQ0FBQyxDQUFDRSxLQUFLLENBQUNRLElBQUksQ0FBQyxDQUFDQyxhQUFhLENBQUM7TUFBRU4sSUFBSSxFQUFFLE9BQU87TUFBRVIsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0VBQzVFLENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQywrQ0FBK0MsRUFBRSxNQUFNO0lBQ3hELE1BQU1zQixHQUFHLEdBQUcsd0dBQXdHO0lBQ3BILE1BQU0sQ0FBQ2IsSUFBSSxDQUFDLEdBQUcsSUFBQVAsa0JBQWEsRUFBQ29CLEdBQUcsQ0FBQztJQUNqQyxNQUFNWixDQUFDLEdBQUdELElBQXFCO0lBQy9CLElBQUFOLGNBQU0sRUFBQ08sQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUM3QixNQUFNaUIsS0FBSyxHQUFHYixDQUFDLENBQUNjLFFBQVEsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQXlCQSxDQUFDLENBQUNyQixJQUFJLEtBQUssV0FBVyxDQUFDO0lBQ2hGLElBQUFGLGNBQU0sRUFBQ29CLEtBQUssRUFBRVosSUFBSSxDQUFDLENBQUNMLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDakMsSUFBQUgsY0FBTSxFQUFDb0IsS0FBSyxFQUFFWCxLQUFLLENBQUNHLElBQUksQ0FBQyxDQUFDRCxPQUFPLENBQUM7TUFBRUMsSUFBSSxFQUFFLFNBQVM7TUFBRUMsS0FBSyxFQUFFO0lBQU0sQ0FBQyxDQUFDO0VBQ3RFLENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsaURBQWlELEVBQUUsTUFBTTtJQUMxRCxNQUFNc0IsR0FBRyxHQUFHLDREQUE0RDtJQUN4RSxNQUFNckIsS0FBSyxHQUFHLElBQUFDLGtCQUFhLEVBQUNvQixHQUFHLENBQUM7SUFDaEMsTUFBTUssS0FBSyxHQUFHMUIsS0FBSyxDQUFDMkIsR0FBRyxDQUFFRixDQUFDLElBQU1BLENBQUMsQ0FBQ3JCLElBQUksS0FBSyxXQUFXLEdBQUdxQixDQUFDLENBQUNmLElBQUksR0FBRyxJQUFLLENBQUM7SUFDeEUsSUFBQVIsY0FBTSxFQUFDd0IsS0FBSyxDQUFDLENBQUNiLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFDNUMsQ0FBQyxDQUFDO0VBRUYsSUFBQWQsVUFBRSxFQUFDLCtDQUErQyxFQUFFLE1BQU07SUFDeEQsTUFBTXNCLEdBQUcsR0FBRyx3SUFBd0k7SUFDcEosTUFBTXJCLEtBQUssR0FBRyxJQUFBQyxrQkFBYSxFQUFDb0IsR0FBRyxDQUFDO0lBQ2hDLE1BQU1PLE1BQU0sR0FBRyxJQUFBQywwQkFBZ0IsRUFBQzdCLEtBQUssQ0FBQztJQUN0QyxJQUFBRSxjQUFNLEVBQUMwQixNQUFNLENBQUNFLFdBQVcsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUM5QixZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ2hGLElBQUFELGNBQU0sRUFBQzBCLE1BQU0sQ0FBQ00sUUFBUSxDQUFDLENBQUMzQixTQUFTLENBQUMsZUFBZSxDQUFDO0VBQ3BELENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQyw0RUFBNEUsRUFBRSxNQUFNO0lBQ3JGLE1BQU0sQ0FBQ1MsSUFBSSxDQUFDLEdBQUcsSUFBQVAsa0JBQWEsRUFBQywyQkFBMkIsQ0FBQztJQUN6RCxJQUFBQyxjQUFNLEVBQUVNLElBQUksQ0FBbUJFLElBQUksQ0FBQyxDQUFDTCxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3JELElBQUFILGNBQU0sRUFBQyxJQUFBMkIsMEJBQWdCLEVBQUMsQ0FBQ3JCLElBQUksQ0FBQyxDQUFDLENBQUMyQixZQUFZLENBQUMsQ0FBQ3RCLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQ3JFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==