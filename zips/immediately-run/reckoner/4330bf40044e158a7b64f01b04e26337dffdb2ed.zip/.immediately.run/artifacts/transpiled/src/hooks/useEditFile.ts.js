"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEditFile = useEditFile;
var _react = require("react");
var _documentPaths = require("../app/documentPaths.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // Part B's edit door (DOCUMENT_NAVIGATOR_SPEC §4) — the stateful half of the
// delegation. The pure halves live beside it: `app/documentPaths.ts` gates the path
// before `capFile` ever sees it (§4.3/DN-R7), and `app/dispatch.ts` resolves the mount
// the door addresses. This hook owns:
//
//   • WRITABILITY (§4, after R3-447's host spike): derived from the live mount's
//     `mode` by the POSITIVE `rw` check R-EFE-1 prescribes — never "absent ⇒
//     writable" (DN-R2). Anything else — `ro`, or no dispatched mount at all —
//     means the affordance is ABSENT (editor-first §7 rule 3: absent, never
//     disabled; a greyed control still claims the action exists here).
//   • THE CALL (§4.1/DN-R5): `@immediately-run/sdk/tasks` registers a host listener
//     at module load, so it is imported dynamically INSIDE the handler; a
//     host-less environment (plain `vite dev`) is a silent no-op, the same shape
//     `reportSession.ts` uses for the worker URL. The platform guard
//     (`platformGuards.test.ts`) keeps the import lazy forever.
//   • BOTH REFUSAL CHANNELS (§4.2/DN-R1): `invokeTask` throws with a machine
//     `.code` AND returns the contract result unexamined — the edit-file contract
//     answers `{ saved: boolean }`, and `saved: false` is the result-carried
//     refusal. `cancelled` is silent; `forbidden` and the result-carried refusal
//     draw one plain message and LATCH the door off for that mount state, so a
//     stale grant cannot produce repeated dead clicks; anything else names its code.
//   • THE STALENESS SIGNAL (§4.4/DN-R11): a successful edit flips `edited`, which
//     App answers with the document-changed notice — the session reads the
//     document once, so the rendered report is stale the moment a save lands.
/** The plain refusal copy — one line, no code, no `EROFS` prose, no stack (§4.2). */
const REFUSED_MESSAGE = 'This document can’t be edited here.';

/** A transient, human-readable outcome line; `null` = nothing to say (silent). */

function useEditFile(mount) {
  // The latch: the mount-state identity that last drew `forbidden`/a result-carried
  // refusal. It is active ONLY while that identity IS the current mount state — a
  // re-grant, a role change or a re-dispatch re-arms the door BY DERIVATION (the
  // stored string no longer matches), which is exactly "stop offering for that
  // mount state" without an effect resetting anything.
  const [latchedFor, setLatchedFor] = (0, _react.useState)(null);
  const [notice, setNotice] = (0, _react.useState)(null);
  const [edited, setEdited] = (0, _react.useState)(false);
  const busy = (0, _react.useRef)(false);
  const mountState = mount !== null ? `${mount.id ?? mount.path}|${mount.mode ?? ''}` : null;
  const latchActive = latchedFor !== null && latchedFor === mountState;
  // The door needs BOTH the positive `rw` check AND an addressable mount: the
  // descriptor's `id` is the universal `scheme:locator` form (established live,
  // R3-447), and the host's grant lookup is an EXACT match on it — there is no
  // documented fallback, so a mount without an id is not a door rather than a
  // doomed call (fail-closed, belt and braces against a shape the live contract
  // has not produced).
  const writable = mount !== null && mount.id !== undefined && mount.mode === 'rw' && !latchActive;
  const canEditPath = (0, _react.useCallback)(relPath => writable && (0, _documentPaths.validDocumentRelPath)(relPath), [writable]);
  const onEdit = (0, _react.useCallback)(relPath => {
    if (mount === null || !writable || busy.current) return;
    if (!(0, _documentPaths.validDocumentRelPath)(relPath)) return; // §4.3 — never construct the delegation
    busy.current = true;
    setNotice(null);
    void (async () => {
      try {
        // §4.1/DN-R5 — the lazy import, inside the handler, never at module load.
        const {
          invokeTask,
          capFile
        } = await Promise.resolve().then(() => _interopRequireWildcard(require('@immediately-run/sdk/tasks')));
        // The host contract (R3-447, established live): the mount's `id` IS the
        // universal `scheme:locator` form, and the host's grant lookup matches it
        // exactly — the descriptor's id, verbatim.
        const result = await invokeTask('edit-file', {
          file: capFile({
            mountId: mount.id,
            relPath
          }, {
            mode: 'rw'
          })
        });
        if (result?.saved === true) {
          setEdited(true); // §4.4 — the rendered report is now stale
          setNotice(null);
        } else {
          // The result-carried refusal (§4.2/DN-R1): a call that ignored the
          // return value would have handled nothing.
          setNotice(REFUSED_MESSAGE);
          setLatchedFor(`${mount.id ?? mount.path}|${mount.mode ?? ''}`);
        }
      } catch (e) {
        const err = e;
        if (err?.code === 'cancelled') {
          setNotice(null); // the user dismissed the editor; not an error
        } else if (err?.code === 'forbidden') {
          setNotice(REFUSED_MESSAGE);
          setLatchedFor(`${mount.id ?? mount.path}|${mount.mode ?? ''}`);
        } else if (typeof err?.message === 'string' && /no host transport/i.test(err.message)) {
          setNotice(null); // host-less (plain vite dev) — a no-op (§4.1)
        } else {
          setNotice(`Couldn’t open the editor${err?.code !== undefined ? ` (${err.code})` : ''}.`);
        }
      } finally {
        busy.current = false;
      }
    })();
  }, [mount, writable]);
  const clearStale = (0, _react.useCallback)(() => setEdited(false), []);
  return (0, _react.useMemo)(() => ({
    canEditPath,
    onEdit,
    notice,
    edited,
    clearStale
  }), [canEditPath, onEdit, notice, edited, clearStale]);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2RvY3VtZW50UGF0aHMiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsIlJFRlVTRURfTUVTU0FHRSIsInVzZUVkaXRGaWxlIiwibW91bnQiLCJsYXRjaGVkRm9yIiwic2V0TGF0Y2hlZEZvciIsInVzZVN0YXRlIiwibm90aWNlIiwic2V0Tm90aWNlIiwiZWRpdGVkIiwic2V0RWRpdGVkIiwiYnVzeSIsInVzZVJlZiIsIm1vdW50U3RhdGUiLCJpZCIsInBhdGgiLCJtb2RlIiwibGF0Y2hBY3RpdmUiLCJ3cml0YWJsZSIsInVuZGVmaW5lZCIsImNhbkVkaXRQYXRoIiwidXNlQ2FsbGJhY2siLCJyZWxQYXRoIiwidmFsaWREb2N1bWVudFJlbFBhdGgiLCJvbkVkaXQiLCJjdXJyZW50IiwiaW52b2tlVGFzayIsImNhcEZpbGUiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJyZXN1bHQiLCJmaWxlIiwibW91bnRJZCIsInNhdmVkIiwiZXJyIiwiY29kZSIsIm1lc3NhZ2UiLCJ0ZXN0IiwiY2xlYXJTdGFsZSIsInVzZU1lbW8iXSwic291cmNlcyI6WyJ1c2VFZGl0RmlsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQYXJ0IEIncyBlZGl0IGRvb3IgKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIMKnNCkg4oCUIHRoZSBzdGF0ZWZ1bCBoYWxmIG9mIHRoZVxuLy8gZGVsZWdhdGlvbi4gVGhlIHB1cmUgaGFsdmVzIGxpdmUgYmVzaWRlIGl0OiBgYXBwL2RvY3VtZW50UGF0aHMudHNgIGdhdGVzIHRoZSBwYXRoXG4vLyBiZWZvcmUgYGNhcEZpbGVgIGV2ZXIgc2VlcyBpdCAowqc0LjMvRE4tUjcpLCBhbmQgYGFwcC9kaXNwYXRjaC50c2AgcmVzb2x2ZXMgdGhlIG1vdW50XG4vLyB0aGUgZG9vciBhZGRyZXNzZXMuIFRoaXMgaG9vayBvd25zOlxuLy9cbi8vICAg4oCiIFdSSVRBQklMSVRZICjCpzQsIGFmdGVyIFIzLTQ0NydzIGhvc3Qgc3Bpa2UpOiBkZXJpdmVkIGZyb20gdGhlIGxpdmUgbW91bnQnc1xuLy8gICAgIGBtb2RlYCBieSB0aGUgUE9TSVRJVkUgYHJ3YCBjaGVjayBSLUVGRS0xIHByZXNjcmliZXMg4oCUIG5ldmVyIFwiYWJzZW50IOKHklxuLy8gICAgIHdyaXRhYmxlXCIgKEROLVIyKS4gQW55dGhpbmcgZWxzZSDigJQgYHJvYCwgb3Igbm8gZGlzcGF0Y2hlZCBtb3VudCBhdCBhbGwg4oCUXG4vLyAgICAgbWVhbnMgdGhlIGFmZm9yZGFuY2UgaXMgQUJTRU5UIChlZGl0b3ItZmlyc3Qgwqc3IHJ1bGUgMzogYWJzZW50LCBuZXZlclxuLy8gICAgIGRpc2FibGVkOyBhIGdyZXllZCBjb250cm9sIHN0aWxsIGNsYWltcyB0aGUgYWN0aW9uIGV4aXN0cyBoZXJlKS5cbi8vICAg4oCiIFRIRSBDQUxMICjCpzQuMS9ETi1SNSk6IGBAaW1tZWRpYXRlbHktcnVuL3Nkay90YXNrc2AgcmVnaXN0ZXJzIGEgaG9zdCBsaXN0ZW5lclxuLy8gICAgIGF0IG1vZHVsZSBsb2FkLCBzbyBpdCBpcyBpbXBvcnRlZCBkeW5hbWljYWxseSBJTlNJREUgdGhlIGhhbmRsZXI7IGFcbi8vICAgICBob3N0LWxlc3MgZW52aXJvbm1lbnQgKHBsYWluIGB2aXRlIGRldmApIGlzIGEgc2lsZW50IG5vLW9wLCB0aGUgc2FtZSBzaGFwZVxuLy8gICAgIGByZXBvcnRTZXNzaW9uLnRzYCB1c2VzIGZvciB0aGUgd29ya2VyIFVSTC4gVGhlIHBsYXRmb3JtIGd1YXJkXG4vLyAgICAgKGBwbGF0Zm9ybUd1YXJkcy50ZXN0LnRzYCkga2VlcHMgdGhlIGltcG9ydCBsYXp5IGZvcmV2ZXIuXG4vLyAgIOKAoiBCT1RIIFJFRlVTQUwgQ0hBTk5FTFMgKMKnNC4yL0ROLVIxKTogYGludm9rZVRhc2tgIHRocm93cyB3aXRoIGEgbWFjaGluZVxuLy8gICAgIGAuY29kZWAgQU5EIHJldHVybnMgdGhlIGNvbnRyYWN0IHJlc3VsdCB1bmV4YW1pbmVkIOKAlCB0aGUgZWRpdC1maWxlIGNvbnRyYWN0XG4vLyAgICAgYW5zd2VycyBgeyBzYXZlZDogYm9vbGVhbiB9YCwgYW5kIGBzYXZlZDogZmFsc2VgIGlzIHRoZSByZXN1bHQtY2FycmllZFxuLy8gICAgIHJlZnVzYWwuIGBjYW5jZWxsZWRgIGlzIHNpbGVudDsgYGZvcmJpZGRlbmAgYW5kIHRoZSByZXN1bHQtY2FycmllZCByZWZ1c2FsXG4vLyAgICAgZHJhdyBvbmUgcGxhaW4gbWVzc2FnZSBhbmQgTEFUQ0ggdGhlIGRvb3Igb2ZmIGZvciB0aGF0IG1vdW50IHN0YXRlLCBzbyBhXG4vLyAgICAgc3RhbGUgZ3JhbnQgY2Fubm90IHByb2R1Y2UgcmVwZWF0ZWQgZGVhZCBjbGlja3M7IGFueXRoaW5nIGVsc2UgbmFtZXMgaXRzIGNvZGUuXG4vLyAgIOKAoiBUSEUgU1RBTEVORVNTIFNJR05BTCAowqc0LjQvRE4tUjExKTogYSBzdWNjZXNzZnVsIGVkaXQgZmxpcHMgYGVkaXRlZGAsIHdoaWNoXG4vLyAgICAgQXBwIGFuc3dlcnMgd2l0aCB0aGUgZG9jdW1lbnQtY2hhbmdlZCBub3RpY2Ug4oCUIHRoZSBzZXNzaW9uIHJlYWRzIHRoZVxuLy8gICAgIGRvY3VtZW50IG9uY2UsIHNvIHRoZSByZW5kZXJlZCByZXBvcnQgaXMgc3RhbGUgdGhlIG1vbWVudCBhIHNhdmUgbGFuZHMuXG5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBTYW5kYm94TW91bnQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyB2YWxpZERvY3VtZW50UmVsUGF0aCB9IGZyb20gJy4uL2FwcC9kb2N1bWVudFBhdGhzLnRzJztcblxuLyoqIFRoZSBwbGFpbiByZWZ1c2FsIGNvcHkg4oCUIG9uZSBsaW5lLCBubyBjb2RlLCBubyBgRVJPRlNgIHByb3NlLCBubyBzdGFjayAowqc0LjIpLiAqL1xuY29uc3QgUkVGVVNFRF9NRVNTQUdFID0gJ1RoaXMgZG9jdW1lbnQgY2Fu4oCZdCBiZSBlZGl0ZWQgaGVyZS4nO1xuXG4vKiogQSB0cmFuc2llbnQsIGh1bWFuLXJlYWRhYmxlIG91dGNvbWUgbGluZTsgYG51bGxgID0gbm90aGluZyB0byBzYXkgKHNpbGVudCkuICovXG5leHBvcnQgdHlwZSBFZGl0RmlsZU5vdGljZSA9IHN0cmluZyB8IG51bGw7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRWRpdEZpbGVQb3J0IHtcbiAgLyoqIFRoZSBwZXItcm93IGRvb3IgdGVzdDogdGhlIG1vdW50IGlzIGRpc3BhdGNoZWQgYW5kIGByd2AsIHRoZSBkb29yIGlzIG5vdFxuICAgKiAgbGF0Y2hlZCBvZmYsIGFuZCBUSElTIHBhdGggcGFzc2VzIHRoZSDCpzQuMyBnYXRlLiBUaGUgYWZmb3JkYW5jZSByZW5kZXJzXG4gICAqICBvbmx5IHdoZXJlIHRoaXMgaXMgdHJ1ZSDigJQgYWJzZW50IG90aGVyd2lzZSwgbmV2ZXIgZGlzYWJsZWQuICovXG4gIGNhbkVkaXRQYXRoOiAocmVsUGF0aDogc3RyaW5nKSA9PiBib29sZWFuO1xuICAvKiogT3BlbiB0aGUgcGxhdGZvcm0gZWRpdG9yIG9uIG9uZSBkb2N1bWVudCBmaWxlICjCpzQncyBkZWxlZ2F0aW9uKS4gKi9cbiAgb25FZGl0OiAocmVsUGF0aDogc3RyaW5nKSA9PiB2b2lkO1xuICAvKiogVGhlIGxhc3Qgb3V0Y29tZSdzIG9uZS1saW5lIG5vdGljZSAoYG51bGxgID0gc2lsZW50IOKAlCDCpzQuMidzIGNhbmNlbGxlZC9uby1vcCkuICovXG4gIG5vdGljZTogRWRpdEZpbGVOb3RpY2U7XG4gIC8qKiBUcnVlIG9uY2UgYSBzYXZlIGhhcyBsYW5kZWQgYW5kIHRoZSByZW5kZXJlZCByZXBvcnQgaXMgc3RhbGUgKMKnNC40KS4gKi9cbiAgZWRpdGVkOiBib29sZWFuO1xuICAvKiogQ2xlYXIgdGhlIHN0YWxlbmVzcyBzaWduYWwgKHRoZSBjYWxsZXIgZG9lcyB0aGlzIHdoZW4gaXQgcmVsb2FkcykuICovXG4gIGNsZWFyU3RhbGU6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VFZGl0RmlsZShtb3VudDogU2FuZGJveE1vdW50IHwgbnVsbCk6IEVkaXRGaWxlUG9ydCB7XG4gIC8vIFRoZSBsYXRjaDogdGhlIG1vdW50LXN0YXRlIGlkZW50aXR5IHRoYXQgbGFzdCBkcmV3IGBmb3JiaWRkZW5gL2EgcmVzdWx0LWNhcnJpZWRcbiAgLy8gcmVmdXNhbC4gSXQgaXMgYWN0aXZlIE9OTFkgd2hpbGUgdGhhdCBpZGVudGl0eSBJUyB0aGUgY3VycmVudCBtb3VudCBzdGF0ZSDigJQgYVxuICAvLyByZS1ncmFudCwgYSByb2xlIGNoYW5nZSBvciBhIHJlLWRpc3BhdGNoIHJlLWFybXMgdGhlIGRvb3IgQlkgREVSSVZBVElPTiAodGhlXG4gIC8vIHN0b3JlZCBzdHJpbmcgbm8gbG9uZ2VyIG1hdGNoZXMpLCB3aGljaCBpcyBleGFjdGx5IFwic3RvcCBvZmZlcmluZyBmb3IgdGhhdFxuICAvLyBtb3VudCBzdGF0ZVwiIHdpdGhvdXQgYW4gZWZmZWN0IHJlc2V0dGluZyBhbnl0aGluZy5cbiAgY29uc3QgW2xhdGNoZWRGb3IsIHNldExhdGNoZWRGb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZTxFZGl0RmlsZU5vdGljZT4obnVsbCk7XG4gIGNvbnN0IFtlZGl0ZWQsIHNldEVkaXRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGJ1c3kgPSB1c2VSZWYoZmFsc2UpO1xuXG4gIGNvbnN0IG1vdW50U3RhdGUgPSBtb3VudCAhPT0gbnVsbCA/IGAke21vdW50LmlkID8/IG1vdW50LnBhdGh9fCR7bW91bnQubW9kZSA/PyAnJ31gIDogbnVsbDtcbiAgY29uc3QgbGF0Y2hBY3RpdmUgPSBsYXRjaGVkRm9yICE9PSBudWxsICYmIGxhdGNoZWRGb3IgPT09IG1vdW50U3RhdGU7XG4gIC8vIFRoZSBkb29yIG5lZWRzIEJPVEggdGhlIHBvc2l0aXZlIGByd2AgY2hlY2sgQU5EIGFuIGFkZHJlc3NhYmxlIG1vdW50OiB0aGVcbiAgLy8gZGVzY3JpcHRvcidzIGBpZGAgaXMgdGhlIHVuaXZlcnNhbCBgc2NoZW1lOmxvY2F0b3JgIGZvcm0gKGVzdGFibGlzaGVkIGxpdmUsXG4gIC8vIFIzLTQ0NyksIGFuZCB0aGUgaG9zdCdzIGdyYW50IGxvb2t1cCBpcyBhbiBFWEFDVCBtYXRjaCBvbiBpdCDigJQgdGhlcmUgaXMgbm9cbiAgLy8gZG9jdW1lbnRlZCBmYWxsYmFjaywgc28gYSBtb3VudCB3aXRob3V0IGFuIGlkIGlzIG5vdCBhIGRvb3IgcmF0aGVyIHRoYW4gYVxuICAvLyBkb29tZWQgY2FsbCAoZmFpbC1jbG9zZWQsIGJlbHQgYW5kIGJyYWNlcyBhZ2FpbnN0IGEgc2hhcGUgdGhlIGxpdmUgY29udHJhY3RcbiAgLy8gaGFzIG5vdCBwcm9kdWNlZCkuXG4gIGNvbnN0IHdyaXRhYmxlID0gbW91bnQgIT09IG51bGwgJiYgbW91bnQuaWQgIT09IHVuZGVmaW5lZCAmJiBtb3VudC5tb2RlID09PSAncncnICYmICFsYXRjaEFjdGl2ZTtcblxuICBjb25zdCBjYW5FZGl0UGF0aCA9IHVzZUNhbGxiYWNrKFxuICAgIChyZWxQYXRoOiBzdHJpbmcpID0+IHdyaXRhYmxlICYmIHZhbGlkRG9jdW1lbnRSZWxQYXRoKHJlbFBhdGgpLFxuICAgIFt3cml0YWJsZV0sXG4gICk7XG5cbiAgY29uc3Qgb25FZGl0ID0gdXNlQ2FsbGJhY2soXG4gICAgKHJlbFBhdGg6IHN0cmluZykgPT4ge1xuICAgICAgaWYgKG1vdW50ID09PSBudWxsIHx8ICF3cml0YWJsZSB8fCBidXN5LmN1cnJlbnQpIHJldHVybjtcbiAgICAgIGlmICghdmFsaWREb2N1bWVudFJlbFBhdGgocmVsUGF0aCkpIHJldHVybjsgLy8gwqc0LjMg4oCUIG5ldmVyIGNvbnN0cnVjdCB0aGUgZGVsZWdhdGlvblxuICAgICAgYnVzeS5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHNldE5vdGljZShudWxsKTtcbiAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyDCpzQuMS9ETi1SNSDigJQgdGhlIGxhenkgaW1wb3J0LCBpbnNpZGUgdGhlIGhhbmRsZXIsIG5ldmVyIGF0IG1vZHVsZSBsb2FkLlxuICAgICAgICAgIGNvbnN0IHsgaW52b2tlVGFzaywgY2FwRmlsZSB9ID0gYXdhaXQgaW1wb3J0KCdAaW1tZWRpYXRlbHktcnVuL3Nkay90YXNrcycpO1xuICAgICAgICAgIC8vIFRoZSBob3N0IGNvbnRyYWN0IChSMy00NDcsIGVzdGFibGlzaGVkIGxpdmUpOiB0aGUgbW91bnQncyBgaWRgIElTIHRoZVxuICAgICAgICAgIC8vIHVuaXZlcnNhbCBgc2NoZW1lOmxvY2F0b3JgIGZvcm0sIGFuZCB0aGUgaG9zdCdzIGdyYW50IGxvb2t1cCBtYXRjaGVzIGl0XG4gICAgICAgICAgLy8gZXhhY3RseSDigJQgdGhlIGRlc2NyaXB0b3IncyBpZCwgdmVyYmF0aW0uXG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgaW52b2tlVGFzazx7IHNhdmVkPzogYm9vbGVhbiB9PignZWRpdC1maWxlJywge1xuICAgICAgICAgICAgZmlsZTogY2FwRmlsZSh7IG1vdW50SWQ6IG1vdW50LmlkISwgcmVsUGF0aCB9LCB7IG1vZGU6ICdydycgfSksXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKHJlc3VsdD8uc2F2ZWQgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHNldEVkaXRlZCh0cnVlKTsgLy8gwqc0LjQg4oCUIHRoZSByZW5kZXJlZCByZXBvcnQgaXMgbm93IHN0YWxlXG4gICAgICAgICAgICBzZXROb3RpY2UobnVsbCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFRoZSByZXN1bHQtY2FycmllZCByZWZ1c2FsICjCpzQuMi9ETi1SMSk6IGEgY2FsbCB0aGF0IGlnbm9yZWQgdGhlXG4gICAgICAgICAgICAvLyByZXR1cm4gdmFsdWUgd291bGQgaGF2ZSBoYW5kbGVkIG5vdGhpbmcuXG4gICAgICAgICAgICBzZXROb3RpY2UoUkVGVVNFRF9NRVNTQUdFKTtcbiAgICAgICAgICAgIHNldExhdGNoZWRGb3IoYCR7bW91bnQuaWQgPz8gbW91bnQucGF0aH18JHttb3VudC5tb2RlID8/ICcnfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGNvbnN0IGVyciA9IGUgYXMgeyBjb2RlPzogc3RyaW5nOyBtZXNzYWdlPzogc3RyaW5nIH07XG4gICAgICAgICAgaWYgKGVycj8uY29kZSA9PT0gJ2NhbmNlbGxlZCcpIHtcbiAgICAgICAgICAgIHNldE5vdGljZShudWxsKTsgLy8gdGhlIHVzZXIgZGlzbWlzc2VkIHRoZSBlZGl0b3I7IG5vdCBhbiBlcnJvclxuICAgICAgICAgIH0gZWxzZSBpZiAoZXJyPy5jb2RlID09PSAnZm9yYmlkZGVuJykge1xuICAgICAgICAgICAgc2V0Tm90aWNlKFJFRlVTRURfTUVTU0FHRSk7XG4gICAgICAgICAgICBzZXRMYXRjaGVkRm9yKGAke21vdW50LmlkID8/IG1vdW50LnBhdGh9fCR7bW91bnQubW9kZSA/PyAnJ31gKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBlcnI/Lm1lc3NhZ2UgPT09ICdzdHJpbmcnICYmIC9ubyBob3N0IHRyYW5zcG9ydC9pLnRlc3QoZXJyLm1lc3NhZ2UpKSB7XG4gICAgICAgICAgICBzZXROb3RpY2UobnVsbCk7IC8vIGhvc3QtbGVzcyAocGxhaW4gdml0ZSBkZXYpIOKAlCBhIG5vLW9wICjCpzQuMSlcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0Tm90aWNlKGBDb3VsZG7igJl0IG9wZW4gdGhlIGVkaXRvciR7ZXJyPy5jb2RlICE9PSB1bmRlZmluZWQgPyBgICgke2Vyci5jb2RlfSlgIDogJyd9LmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBidXN5LmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfSkoKTtcbiAgICB9LFxuICAgIFttb3VudCwgd3JpdGFibGVdLFxuICApO1xuXG4gIGNvbnN0IGNsZWFyU3RhbGUgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRFZGl0ZWQoZmFsc2UpLCBbXSk7XG5cbiAgcmV0dXJuIHVzZU1lbW8oXG4gICAgKCkgPT4gKHsgY2FuRWRpdFBhdGgsIG9uRWRpdCwgbm90aWNlLCBlZGl0ZWQsIGNsZWFyU3RhbGUgfSksXG4gICAgW2NhbkVkaXRQYXRoLCBvbkVkaXQsIG5vdGljZSwgZWRpdGVkLCBjbGVhclN0YWxlXSxcbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBeUJBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLGNBQUEsR0FBQUQsT0FBQTtBQUErRCxTQUFBRSx5QkFBQUMsQ0FBQSw2QkFBQUMsT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRix3QkFBQSxZQUFBQSxDQUFBQyxDQUFBLFdBQUFBLENBQUEsR0FBQUcsQ0FBQSxHQUFBRCxDQUFBLEtBQUFGLENBQUE7QUFBQSxTQUFBSSx3QkFBQUosQ0FBQSxFQUFBRSxDQUFBLFNBQUFBLENBQUEsSUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUFLLFVBQUEsU0FBQUwsQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFNLE9BQUEsRUFBQU4sQ0FBQSxRQUFBRyxDQUFBLEdBQUFKLHdCQUFBLENBQUFHLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFJLEdBQUEsQ0FBQVAsQ0FBQSxVQUFBRyxDQUFBLENBQUFLLEdBQUEsQ0FBQVIsQ0FBQSxPQUFBUyxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFmLENBQUEsb0JBQUFlLENBQUEsT0FBQUMsY0FBQSxDQUFBQyxJQUFBLENBQUFqQixDQUFBLEVBQUFlLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWQsQ0FBQSxFQUFBZSxDQUFBLFVBQUFHLENBQUEsS0FBQUEsQ0FBQSxDQUFBVixHQUFBLElBQUFVLENBQUEsQ0FBQUMsR0FBQSxJQUFBUCxNQUFBLENBQUFDLGNBQUEsQ0FBQUosQ0FBQSxFQUFBTSxDQUFBLEVBQUFHLENBQUEsSUFBQVQsQ0FBQSxDQUFBTSxDQUFBLElBQUFmLENBQUEsQ0FBQWUsQ0FBQSxZQUFBTixDQUFBLENBQUFILE9BQUEsR0FBQU4sQ0FBQSxFQUFBRyxDQUFBLElBQUFBLENBQUEsQ0FBQWdCLEdBQUEsQ0FBQW5CLENBQUEsRUFBQVMsQ0FBQSxHQUFBQSxDQUFBLElBM0IvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQTtBQUNBLE1BQU1XLGVBQWUsR0FBRyxxQ0FBcUM7O0FBRTdEOztBQWtCTyxTQUFTQyxXQUFXQSxDQUFDQyxLQUEwQixFQUFnQjtFQUNwRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDQyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ2pFLE1BQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQWlCLElBQUksQ0FBQztFQUMxRCxNQUFNLENBQUNHLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUosZUFBUSxFQUFDLEtBQUssQ0FBQztFQUMzQyxNQUFNSyxJQUFJLEdBQUcsSUFBQUMsYUFBTSxFQUFDLEtBQUssQ0FBQztFQUUxQixNQUFNQyxVQUFVLEdBQUdWLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FBR0EsS0FBSyxDQUFDVyxFQUFFLElBQUlYLEtBQUssQ0FBQ1ksSUFBSSxJQUFJWixLQUFLLENBQUNhLElBQUksSUFBSSxFQUFFLEVBQUUsR0FBRyxJQUFJO0VBQzFGLE1BQU1DLFdBQVcsR0FBR2IsVUFBVSxLQUFLLElBQUksSUFBSUEsVUFBVSxLQUFLUyxVQUFVO0VBQ3BFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1LLFFBQVEsR0FBR2YsS0FBSyxLQUFLLElBQUksSUFBSUEsS0FBSyxDQUFDVyxFQUFFLEtBQUtLLFNBQVMsSUFBSWhCLEtBQUssQ0FBQ2EsSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDQyxXQUFXO0VBRWhHLE1BQU1HLFdBQVcsR0FBRyxJQUFBQyxrQkFBVyxFQUM1QkMsT0FBZSxJQUFLSixRQUFRLElBQUksSUFBQUssbUNBQW9CLEVBQUNELE9BQU8sQ0FBQyxFQUM5RCxDQUFDSixRQUFRLENBQ1gsQ0FBQztFQUVELE1BQU1NLE1BQU0sR0FBRyxJQUFBSCxrQkFBVyxFQUN2QkMsT0FBZSxJQUFLO0lBQ25CLElBQUluQixLQUFLLEtBQUssSUFBSSxJQUFJLENBQUNlLFFBQVEsSUFBSVAsSUFBSSxDQUFDYyxPQUFPLEVBQUU7SUFDakQsSUFBSSxDQUFDLElBQUFGLG1DQUFvQixFQUFDRCxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUM7SUFDNUNYLElBQUksQ0FBQ2MsT0FBTyxHQUFHLElBQUk7SUFDbkJqQixTQUFTLENBQUMsSUFBSSxDQUFDO0lBQ2YsS0FBSyxDQUFDLFlBQVk7TUFDaEIsSUFBSTtRQUNGO1FBQ0EsTUFBTTtVQUFFa0IsVUFBVTtVQUFFQztRQUFRLENBQUMsR0FBRyxNQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBN0MsdUJBQUEsQ0FBQVAsT0FBQSxDQUFhLDRCQUE0QixHQUFDO1FBQzFFO1FBQ0E7UUFDQTtRQUNBLE1BQU1xRCxNQUFNLEdBQUcsTUFBTUwsVUFBVSxDQUFzQixXQUFXLEVBQUU7VUFDaEVNLElBQUksRUFBRUwsT0FBTyxDQUFDO1lBQUVNLE9BQU8sRUFBRTlCLEtBQUssQ0FBQ1csRUFBRztZQUFFUTtVQUFRLENBQUMsRUFBRTtZQUFFTixJQUFJLEVBQUU7VUFBSyxDQUFDO1FBQy9ELENBQUMsQ0FBQztRQUNGLElBQUllLE1BQU0sRUFBRUcsS0FBSyxLQUFLLElBQUksRUFBRTtVQUMxQnhCLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1VBQ2pCRixTQUFTLENBQUMsSUFBSSxDQUFDO1FBQ2pCLENBQUMsTUFBTTtVQUNMO1VBQ0E7VUFDQUEsU0FBUyxDQUFDUCxlQUFlLENBQUM7VUFDMUJJLGFBQWEsQ0FBQyxHQUFHRixLQUFLLENBQUNXLEVBQUUsSUFBSVgsS0FBSyxDQUFDWSxJQUFJLElBQUlaLEtBQUssQ0FBQ2EsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDO1FBQ2hFO01BQ0YsQ0FBQyxDQUFDLE9BQU9uQyxDQUFDLEVBQUU7UUFDVixNQUFNc0QsR0FBRyxHQUFHdEQsQ0FBd0M7UUFDcEQsSUFBSXNELEdBQUcsRUFBRUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtVQUM3QjVCLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ25CLENBQUMsTUFBTSxJQUFJMkIsR0FBRyxFQUFFQyxJQUFJLEtBQUssV0FBVyxFQUFFO1VBQ3BDNUIsU0FBUyxDQUFDUCxlQUFlLENBQUM7VUFDMUJJLGFBQWEsQ0FBQyxHQUFHRixLQUFLLENBQUNXLEVBQUUsSUFBSVgsS0FBSyxDQUFDWSxJQUFJLElBQUlaLEtBQUssQ0FBQ2EsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDO1FBQ2hFLENBQUMsTUFBTSxJQUFJLE9BQU9tQixHQUFHLEVBQUVFLE9BQU8sS0FBSyxRQUFRLElBQUksb0JBQW9CLENBQUNDLElBQUksQ0FBQ0gsR0FBRyxDQUFDRSxPQUFPLENBQUMsRUFBRTtVQUNyRjdCLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ25CLENBQUMsTUFBTTtVQUNMQSxTQUFTLENBQUMsMkJBQTJCMkIsR0FBRyxFQUFFQyxJQUFJLEtBQUtqQixTQUFTLEdBQUcsS0FBS2dCLEdBQUcsQ0FBQ0MsSUFBSSxHQUFHLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDMUY7TUFDRixDQUFDLFNBQVM7UUFDUnpCLElBQUksQ0FBQ2MsT0FBTyxHQUFHLEtBQUs7TUFDdEI7SUFDRixDQUFDLEVBQUUsQ0FBQztFQUNOLENBQUMsRUFDRCxDQUFDdEIsS0FBSyxFQUFFZSxRQUFRLENBQ2xCLENBQUM7RUFFRCxNQUFNcUIsVUFBVSxHQUFHLElBQUFsQixrQkFBVyxFQUFDLE1BQU1YLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFMUQsT0FBTyxJQUFBOEIsY0FBTyxFQUNaLE9BQU87SUFBRXBCLFdBQVc7SUFBRUksTUFBTTtJQUFFakIsTUFBTTtJQUFFRSxNQUFNO0lBQUU4QjtFQUFXLENBQUMsQ0FBQyxFQUMzRCxDQUFDbkIsV0FBVyxFQUFFSSxNQUFNLEVBQUVqQixNQUFNLEVBQUVFLE1BQU0sRUFBRThCLFVBQVUsQ0FDbEQsQ0FBQztBQUNIIiwiaWdub3JlTGlzdCI6W119