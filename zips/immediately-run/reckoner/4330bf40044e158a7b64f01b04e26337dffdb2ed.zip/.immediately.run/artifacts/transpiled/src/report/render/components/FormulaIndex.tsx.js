var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = FormulaIndex;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _attrs = require("../attrs.ts");
var _reflectionContext = require("../reflectionContext.ts");
var _verdictChip = require("../verdictChip.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // FormulaIndex — the reflection component listing the workbook's cells (AUTHORS_VIEW_SPEC
// §2): per worksheet, a native collapsible section (navigable on a phone even for a large
// workbook, §1.3) of cards — name, doc, read-only formula source in its own overflow
// container, and the computed verdict chip (pending is its own state, never a verdict).
// No reflection port → the author's-view-only broken tile (spec §6 makes the restriction
// structural); an unknown worksheet filter → broken tile with the reason (§2.2).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function FormulaIndex({
  node
}) {
  _s();
  const reflection = (0, _reflectionContext.useReflection)();
  const worksheet = (0, _attrs.attrString)(node, 'worksheet');
  if (reflection === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "FormulaIndex",
      reason: "available only in the author's view"
    });
  }
  const cells = reflection.cells();
  const worksheets = [...new Set(cells.map(c => c.worksheet))];
  const shown = worksheet === undefined ? worksheets : worksheets.filter(w => w === worksheet);
  if (worksheet !== undefined && shown.length === 0) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "FormulaIndex",
      reason: `unknown worksheet "${worksheet}"`
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-refl-index",
    children: shown.map(ws => /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
      className: "rk-refl-sheet",
      open: true,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
        className: "rk-refl-sheet-name",
        children: ws
      }), cells.filter(c => c.worksheet === ws).map(cell => {
        const chip = (0, _verdictChip.verdictChip)(cell.id, reflection.verdicts);
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "rk-refl-cell",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "rk-refl-cell-head",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "rk-refl-name",
              children: cell.cell
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: chip.className,
              children: chip.label
            })]
          }), cell.doc !== '' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "rk-refl-doc",
            children: cell.doc
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
            className: "rk-refl-formula",
            children: cell.formulaSource
          })]
        }, cell.id);
      })]
    }, ws))
  });
}
_s(FormulaIndex, "EcuPFGw29ARuTs47OEyfycl8jbM=", false, function () {
  return [_reflectionContext.useReflection];
});
_c = FormulaIndex;
var _c;
$RefreshReg$(_c, "FormulaIndex");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlZmxlY3Rpb25Db250ZXh0IiwiX3ZlcmRpY3RDaGlwIiwiX0Jyb2tlblRpbGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkZvcm11bGFJbmRleCIsIm5vZGUiLCJyZWZsZWN0aW9uIiwidXNlUmVmbGVjdGlvbiIsIndvcmtzaGVldCIsImF0dHJTdHJpbmciLCJqc3giLCJjb21wb25lbnQiLCJyZWFzb24iLCJjZWxscyIsIndvcmtzaGVldHMiLCJTZXQiLCJtYXAiLCJjIiwic2hvd24iLCJ1bmRlZmluZWQiLCJmaWx0ZXIiLCJ3IiwibGVuZ3RoIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJ3cyIsImpzeHMiLCJvcGVuIiwiY2VsbCIsImNoaXAiLCJ2ZXJkaWN0Q2hpcCIsImlkIiwidmVyZGljdHMiLCJsYWJlbCIsImRvYyIsImZvcm11bGFTb3VyY2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZvcm11bGFJbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRm9ybXVsYUluZGV4IOKAlCB0aGUgcmVmbGVjdGlvbiBjb21wb25lbnQgbGlzdGluZyB0aGUgd29ya2Jvb2sncyBjZWxscyAoQVVUSE9SU19WSUVXX1NQRUNcbi8vIMKnMik6IHBlciB3b3Jrc2hlZXQsIGEgbmF0aXZlIGNvbGxhcHNpYmxlIHNlY3Rpb24gKG5hdmlnYWJsZSBvbiBhIHBob25lIGV2ZW4gZm9yIGEgbGFyZ2Vcbi8vIHdvcmtib29rLCDCpzEuMykgb2YgY2FyZHMg4oCUIG5hbWUsIGRvYywgcmVhZC1vbmx5IGZvcm11bGEgc291cmNlIGluIGl0cyBvd24gb3ZlcmZsb3dcbi8vIGNvbnRhaW5lciwgYW5kIHRoZSBjb21wdXRlZCB2ZXJkaWN0IGNoaXAgKHBlbmRpbmcgaXMgaXRzIG93biBzdGF0ZSwgbmV2ZXIgYSB2ZXJkaWN0KS5cbi8vIE5vIHJlZmxlY3Rpb24gcG9ydCDihpIgdGhlIGF1dGhvcidzLXZpZXctb25seSBicm9rZW4gdGlsZSAoc3BlYyDCpzYgbWFrZXMgdGhlIHJlc3RyaWN0aW9uXG4vLyBzdHJ1Y3R1cmFsKTsgYW4gdW5rbm93biB3b3Jrc2hlZXQgZmlsdGVyIOKGkiBicm9rZW4gdGlsZSB3aXRoIHRoZSByZWFzb24gKMKnMi4yKS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyB1c2VSZWZsZWN0aW9uIH0gZnJvbSAnLi4vcmVmbGVjdGlvbkNvbnRleHQudHMnO1xuaW1wb3J0IHsgdmVyZGljdENoaXAgfSBmcm9tICcuLi92ZXJkaWN0Q2hpcC50cyc7XG5pbXBvcnQgQnJva2VuVGlsZSBmcm9tICcuL0Jyb2tlblRpbGUudHN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9ybXVsYUluZGV4KHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCByZWZsZWN0aW9uID0gdXNlUmVmbGVjdGlvbigpO1xuICBjb25zdCB3b3Jrc2hlZXQgPSBhdHRyU3RyaW5nKG5vZGUsICd3b3Jrc2hlZXQnKTtcblxuICBpZiAocmVmbGVjdGlvbiA9PT0gbnVsbCkge1xuICAgIHJldHVybiA8QnJva2VuVGlsZSBjb21wb25lbnQ9XCJGb3JtdWxhSW5kZXhcIiByZWFzb249XCJhdmFpbGFibGUgb25seSBpbiB0aGUgYXV0aG9yJ3Mgdmlld1wiIC8+O1xuICB9XG5cbiAgY29uc3QgY2VsbHMgPSByZWZsZWN0aW9uLmNlbGxzKCk7XG4gIGNvbnN0IHdvcmtzaGVldHMgPSBbLi4ubmV3IFNldChjZWxscy5tYXAoKGMpID0+IGMud29ya3NoZWV0KSldO1xuICBjb25zdCBzaG93biA9IHdvcmtzaGVldCA9PT0gdW5kZWZpbmVkID8gd29ya3NoZWV0cyA6IHdvcmtzaGVldHMuZmlsdGVyKCh3KSA9PiB3ID09PSB3b3Jrc2hlZXQpO1xuICBpZiAod29ya3NoZWV0ICE9PSB1bmRlZmluZWQgJiYgc2hvd24ubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIkZvcm11bGFJbmRleFwiIHJlYXNvbj17YHVua25vd24gd29ya3NoZWV0IFwiJHt3b3Jrc2hlZXR9XCJgfSAvPjtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLWluZGV4XCI+XG4gICAgICB7c2hvd24ubWFwKCh3cykgPT4gKFxuICAgICAgICA8ZGV0YWlscyBrZXk9e3dzfSBjbGFzc05hbWU9XCJyay1yZWZsLXNoZWV0XCIgb3Blbj5cbiAgICAgICAgICA8c3VtbWFyeSBjbGFzc05hbWU9XCJyay1yZWZsLXNoZWV0LW5hbWVcIj57d3N9PC9zdW1tYXJ5PlxuICAgICAgICAgIHtjZWxsc1xuICAgICAgICAgICAgLmZpbHRlcigoYykgPT4gYy53b3Jrc2hlZXQgPT09IHdzKVxuICAgICAgICAgICAgLm1hcCgoY2VsbCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBjaGlwID0gdmVyZGljdENoaXAoY2VsbC5pZCwgcmVmbGVjdGlvbi52ZXJkaWN0cyk7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NlbGwuaWR9IGNsYXNzTmFtZT1cInJrLXJlZmwtY2VsbFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLWNlbGwtaGVhZFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1yZWZsLW5hbWVcIj57Y2VsbC5jZWxsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjaGlwLmNsYXNzTmFtZX0+e2NoaXAubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7Y2VsbC5kb2MgIT09ICcnICYmIDxkaXYgY2xhc3NOYW1lPVwicmstcmVmbC1kb2NcIj57Y2VsbC5kb2N9PC9kaXY+fVxuICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJyay1yZWZsLWZvcm11bGFcIj57Y2VsbC5mb3JtdWxhU291cmNlfTwvcHJlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgIDwvZGV0YWlscz5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFPQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxrQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsWUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsV0FBQSxHQUFBQyxzQkFBQSxDQUFBSixPQUFBO0FBQTBDLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLElBQUFNLEVBQUEsR0FBQUMsWUFBQSxJQVYxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQU9lLFNBQVNHLFlBQVlBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDdEUsTUFBTU8sVUFBVSxHQUFHLElBQUFDLGdDQUFhLEVBQUMsQ0FBQztFQUNsQyxNQUFNQyxTQUFTLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0osSUFBSSxFQUFFLFdBQVcsQ0FBQztFQUUvQyxJQUFJQyxVQUFVLEtBQUssSUFBSSxFQUFFO0lBQ3ZCLG9CQUFPLElBQUFSLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxXQUFBLENBQUFPLE9BQVU7TUFBQ1EsU0FBUyxFQUFDLGNBQWM7TUFBQ0MsTUFBTSxFQUFDO0lBQXFDLENBQUUsQ0FBQztFQUM3RjtFQUVBLE1BQU1DLEtBQUssR0FBR1AsVUFBVSxDQUFDTyxLQUFLLENBQUMsQ0FBQztFQUNoQyxNQUFNQyxVQUFVLEdBQUcsQ0FBQyxHQUFHLElBQUlDLEdBQUcsQ0FBQ0YsS0FBSyxDQUFDRyxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDVCxTQUFTLENBQUMsQ0FBQyxDQUFDO0VBQzlELE1BQU1VLEtBQUssR0FBR1YsU0FBUyxLQUFLVyxTQUFTLEdBQUdMLFVBQVUsR0FBR0EsVUFBVSxDQUFDTSxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxLQUFLYixTQUFTLENBQUM7RUFDOUYsSUFBSUEsU0FBUyxLQUFLVyxTQUFTLElBQUlELEtBQUssQ0FBQ0ksTUFBTSxLQUFLLENBQUMsRUFBRTtJQUNqRCxvQkFBTyxJQUFBeEIsV0FBQSxDQUFBWSxHQUFBLEVBQUNkLFdBQUEsQ0FBQU8sT0FBVTtNQUFDUSxTQUFTLEVBQUMsY0FBYztNQUFDQyxNQUFNLEVBQUUsc0JBQXNCSixTQUFTO0lBQUksQ0FBRSxDQUFDO0VBQzVGO0VBRUEsb0JBQ0UsSUFBQVYsV0FBQSxDQUFBWSxHQUFBO0lBQUthLFNBQVMsRUFBQyxlQUFlO0lBQUFDLFFBQUEsRUFDM0JOLEtBQUssQ0FBQ0YsR0FBRyxDQUFFUyxFQUFFLGlCQUNaLElBQUEzQixXQUFBLENBQUE0QixJQUFBO01BQWtCSCxTQUFTLEVBQUMsZUFBZTtNQUFDSSxJQUFJO01BQUFILFFBQUEsZ0JBQzlDLElBQUExQixXQUFBLENBQUFZLEdBQUE7UUFBU2EsU0FBUyxFQUFDLG9CQUFvQjtRQUFBQyxRQUFBLEVBQUVDO01BQUUsQ0FBVSxDQUFDLEVBQ3JEWixLQUFLLENBQ0hPLE1BQU0sQ0FBRUgsQ0FBQyxJQUFLQSxDQUFDLENBQUNULFNBQVMsS0FBS2lCLEVBQUUsQ0FBQyxDQUNqQ1QsR0FBRyxDQUFFWSxJQUFJLElBQUs7UUFDYixNQUFNQyxJQUFJLEdBQUcsSUFBQUMsd0JBQVcsRUFBQ0YsSUFBSSxDQUFDRyxFQUFFLEVBQUV6QixVQUFVLENBQUMwQixRQUFRLENBQUM7UUFDdEQsb0JBQ0UsSUFBQWxDLFdBQUEsQ0FBQTRCLElBQUE7VUFBbUJILFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsZ0JBQ3pDLElBQUExQixXQUFBLENBQUE0QixJQUFBO1lBQUtILFNBQVMsRUFBQyxtQkFBbUI7WUFBQUMsUUFBQSxnQkFDaEMsSUFBQTFCLFdBQUEsQ0FBQVksR0FBQTtjQUFNYSxTQUFTLEVBQUMsY0FBYztjQUFBQyxRQUFBLEVBQUVJLElBQUksQ0FBQ0E7WUFBSSxDQUFPLENBQUMsZUFDakQsSUFBQTlCLFdBQUEsQ0FBQVksR0FBQTtjQUFNYSxTQUFTLEVBQUVNLElBQUksQ0FBQ04sU0FBVTtjQUFBQyxRQUFBLEVBQUVLLElBQUksQ0FBQ0k7WUFBSyxDQUFPLENBQUM7VUFBQSxDQUNqRCxDQUFDLEVBQ0xMLElBQUksQ0FBQ00sR0FBRyxLQUFLLEVBQUUsaUJBQUksSUFBQXBDLFdBQUEsQ0FBQVksR0FBQTtZQUFLYSxTQUFTLEVBQUMsYUFBYTtZQUFBQyxRQUFBLEVBQUVJLElBQUksQ0FBQ007VUFBRyxDQUFNLENBQUMsZUFDakUsSUFBQXBDLFdBQUEsQ0FBQVksR0FBQTtZQUFLYSxTQUFTLEVBQUMsaUJBQWlCO1lBQUFDLFFBQUEsRUFBRUksSUFBSSxDQUFDTztVQUFhLENBQU0sQ0FBQztRQUFBLEdBTm5EUCxJQUFJLENBQUNHLEVBT1YsQ0FBQztNQUVWLENBQUMsQ0FBQztJQUFBLEdBaEJRTixFQWlCTCxDQUNWO0VBQUMsQ0FDQyxDQUFDO0FBRVY7QUFBQzFCLEVBQUEsQ0F2Q3VCSyxZQUFZO0VBQUEsUUFDZkcsZ0NBQWE7QUFBQTtBQUFBNkIsRUFBQSxHQURWaEMsWUFBWTtBQUFBLElBQUFnQyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}