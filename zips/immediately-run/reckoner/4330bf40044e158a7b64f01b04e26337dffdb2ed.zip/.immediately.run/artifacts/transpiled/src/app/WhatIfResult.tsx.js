var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
// The what-if readout — pure presentation of a ShadowOutcome for one inspected cell
// (WHATIF_SHADOW_EVALUATION_SPEC §1.1): refusals as typed messages, the baseline→shadow
// value line with the pinned-baseline provenance, the downstream delta list scoped by the
// dependents closure, flipped verdicts, and cross-reference diagnostics. Kept free of
// effects so it renders under `react-dom/server` in tests, like WorkbookPanelBody.

function preview(value) {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') return String(Math.round(value * 1000) / 1000);
  if (typeof value === 'string' || typeof value === 'boolean') return String(value);
  const json = JSON.stringify(value);
  return json === undefined ? '—' : json.length > 72 ? `${json.slice(0, 72)}…` : json;
}
function deltaLine(d) {
  if (d.kind === 'changed') return `${preview(d.before)} → ${preview(d.after)}`;
  if (d.kind === 'new-error') return `${preview(d.before)} → error: ${d.afterError ?? ''}`;
  if (d.kind === 'error-cleared') return `error cleared → ${preview(d.after)}`;
  return `error: ${d.beforeError ?? ''} → ${d.afterError ?? ''}`;
}
function WhatIfResult({
  outcome,
  cellId
}) {
  if (!outcome.ok) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-refusal",
      role: "status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-wb-kind",
        children: outcome.refusal.code
      }), " ", outcome.refusal.message]
    });
  }
  const own = outcome.deltas.find(d => d.id === cellId);
  const rest = outcome.deltas.filter(d => d.id !== cellId);
  const baseOwn = outcome.baseline.results.get(cellId)?.value;
  const shadowOwnError = outcome.errorOf(cellId);
  const errorDiags = outcome.diagnostics.filter(d => d.severity === 'error');
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-wi-result",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-line",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "this cell"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-wi-values",
        children: shadowOwnError !== undefined ? `${preview(baseOwn)} → error: ${shadowOwnError}` : own !== undefined ? deltaLine(own) : `${preview(baseOwn)} (unchanged)`
      })]
    }), rest.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-line",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "downstream"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-wi-deltas",
        children: rest.map(d => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "rk-wi-delta",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rk-wb-name",
            children: d.id
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rk-wi-values",
            children: deltaLine(d)
          })]
        }, d.id))
      })]
    }), rest.length === 0 && own !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wi-note",
      children: "no other cell changed."
    }), own === undefined && shadowOwnError === undefined && outcome.deltas.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wi-note",
      children: "no change against the baseline."
    }), outcome.verdictFlips.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-line",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "verdicts"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-wi-deltas",
        children: outcome.verdictFlips.map(f => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "rk-wi-delta",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rk-wb-name",
            children: f.subject
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "rk-wi-values",
            children: [f.before, " \u2192 ", f.after]
          })]
        }, f.subject))
      })]
    }), errorDiags.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-line",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "references"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-wi-deltas",
        children: errorDiags.map((d, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "rk-wb-error",
          children: d.message
        }, i))
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wi-note",
      children: "baseline pinned when this run started \u2014 the live report may have advanced since."
    })]
  });
}
_c = WhatIfResult;
var _default = exports.default = WhatIfResult;
var _c;
$RefreshReg$(_c, "WhatIfResult");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJwcmV2aWV3IiwidmFsdWUiLCJ1bmRlZmluZWQiLCJTdHJpbmciLCJNYXRoIiwicm91bmQiLCJqc29uIiwiSlNPTiIsInN0cmluZ2lmeSIsImxlbmd0aCIsInNsaWNlIiwiZGVsdGFMaW5lIiwiZCIsImtpbmQiLCJiZWZvcmUiLCJhZnRlciIsImFmdGVyRXJyb3IiLCJiZWZvcmVFcnJvciIsIldoYXRJZlJlc3VsdCIsIm91dGNvbWUiLCJjZWxsSWQiLCJvayIsImpzeHMiLCJjbGFzc05hbWUiLCJyb2xlIiwiY2hpbGRyZW4iLCJqc3giLCJyZWZ1c2FsIiwiY29kZSIsIm1lc3NhZ2UiLCJvd24iLCJkZWx0YXMiLCJmaW5kIiwiaWQiLCJyZXN0IiwiZmlsdGVyIiwiYmFzZU93biIsImJhc2VsaW5lIiwicmVzdWx0cyIsImdldCIsInNoYWRvd093bkVycm9yIiwiZXJyb3JPZiIsImVycm9yRGlhZ3MiLCJkaWFnbm9zdGljcyIsInNldmVyaXR5IiwibWFwIiwidmVyZGljdEZsaXBzIiwiZiIsInN1YmplY3QiLCJpIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV2hhdElmUmVzdWx0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgd2hhdC1pZiByZWFkb3V0IOKAlCBwdXJlIHByZXNlbnRhdGlvbiBvZiBhIFNoYWRvd091dGNvbWUgZm9yIG9uZSBpbnNwZWN0ZWQgY2VsbFxuLy8gKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMS4xKTogcmVmdXNhbHMgYXMgdHlwZWQgbWVzc2FnZXMsIHRoZSBiYXNlbGluZeKGknNoYWRvd1xuLy8gdmFsdWUgbGluZSB3aXRoIHRoZSBwaW5uZWQtYmFzZWxpbmUgcHJvdmVuYW5jZSwgdGhlIGRvd25zdHJlYW0gZGVsdGEgbGlzdCBzY29wZWQgYnkgdGhlXG4vLyBkZXBlbmRlbnRzIGNsb3N1cmUsIGZsaXBwZWQgdmVyZGljdHMsIGFuZCBjcm9zcy1yZWZlcmVuY2UgZGlhZ25vc3RpY3MuIEtlcHQgZnJlZSBvZlxuLy8gZWZmZWN0cyBzbyBpdCByZW5kZXJzIHVuZGVyIGByZWFjdC1kb20vc2VydmVyYCBpbiB0ZXN0cywgbGlrZSBXb3JrYm9va1BhbmVsQm9keS5cbmltcG9ydCB0eXBlIHsgVmFsdWUgfSBmcm9tICcuLi9zdGRsaWIvdHlwZXMudHMnO1xuaW1wb3J0IHR5cGUgeyBTaGFkb3dPdXRjb21lIH0gZnJvbSAnLi93aGF0aWYudHMnO1xuaW1wb3J0IHR5cGUgeyBWYWx1ZURlbHRhIH0gZnJvbSAnLi4vZW5naW5lL3NoYWRvdy50cyc7XG5pbXBvcnQgJy4vd29ya2Jvb2stcGFuZWwuY3NzJztcblxuZnVuY3Rpb24gcHJldmlldyh2YWx1ZTogVmFsdWUgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuICfigJQnO1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIFN0cmluZyhNYXRoLnJvdW5kKHZhbHVlICogMTAwMCkgLyAxMDAwKTtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICBjb25zdCBqc29uID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICByZXR1cm4ganNvbiA9PT0gdW5kZWZpbmVkID8gJ+KAlCcgOiBqc29uLmxlbmd0aCA+IDcyID8gYCR7anNvbi5zbGljZSgwLCA3Mil94oCmYCA6IGpzb247XG59XG5cbmZ1bmN0aW9uIGRlbHRhTGluZShkOiBWYWx1ZURlbHRhKTogc3RyaW5nIHtcbiAgaWYgKGQua2luZCA9PT0gJ2NoYW5nZWQnKSByZXR1cm4gYCR7cHJldmlldyhkLmJlZm9yZSl9IOKGkiAke3ByZXZpZXcoZC5hZnRlcil9YDtcbiAgaWYgKGQua2luZCA9PT0gJ25ldy1lcnJvcicpIHJldHVybiBgJHtwcmV2aWV3KGQuYmVmb3JlKX0g4oaSIGVycm9yOiAke2QuYWZ0ZXJFcnJvciA/PyAnJ31gO1xuICBpZiAoZC5raW5kID09PSAnZXJyb3ItY2xlYXJlZCcpIHJldHVybiBgZXJyb3IgY2xlYXJlZCDihpIgJHtwcmV2aWV3KGQuYWZ0ZXIpfWA7XG4gIHJldHVybiBgZXJyb3I6ICR7ZC5iZWZvcmVFcnJvciA/PyAnJ30g4oaSICR7ZC5hZnRlckVycm9yID8/ICcnfWA7XG59XG5cbmludGVyZmFjZSBXaGF0SWZSZXN1bHRQcm9wcyB7XG4gIG91dGNvbWU6IFNoYWRvd091dGNvbWU7XG4gIC8qKiBUaGUgaW5zcGVjdGVkIGNlbGwg4oCUIGl0cyBvd24gbGluZSByZW5kZXJzIGZpcnN0LCB0aGUgcmVzdCBvZiB0aGUgY2xvc3VyZSBhZnRlci4gKi9cbiAgY2VsbElkOiBzdHJpbmc7XG59XG5cbmZ1bmN0aW9uIFdoYXRJZlJlc3VsdCh7IG91dGNvbWUsIGNlbGxJZCB9OiBXaGF0SWZSZXN1bHRQcm9wcykge1xuICBpZiAoIW91dGNvbWUub2spIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1yZWZ1c2FsXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay13Yi1raW5kXCI+e291dGNvbWUucmVmdXNhbC5jb2RlfTwvc3Bhbj4ge291dGNvbWUucmVmdXNhbC5tZXNzYWdlfVxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IG93biA9IG91dGNvbWUuZGVsdGFzLmZpbmQoKGQpID0+IGQuaWQgPT09IGNlbGxJZCk7XG4gIGNvbnN0IHJlc3QgPSBvdXRjb21lLmRlbHRhcy5maWx0ZXIoKGQpID0+IGQuaWQgIT09IGNlbGxJZCk7XG4gIGNvbnN0IGJhc2VPd24gPSBvdXRjb21lLmJhc2VsaW5lLnJlc3VsdHMuZ2V0KGNlbGxJZCk/LnZhbHVlO1xuICBjb25zdCBzaGFkb3dPd25FcnJvciA9IG91dGNvbWUuZXJyb3JPZihjZWxsSWQpO1xuICBjb25zdCBlcnJvckRpYWdzID0gb3V0Y29tZS5kaWFnbm9zdGljcy5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgPT09ICdlcnJvcicpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1yZXN1bHRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktbGluZVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtbGFiZWxcIj50aGlzIGNlbGw8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdpLXZhbHVlc1wiPlxuICAgICAgICAgIHtzaGFkb3dPd25FcnJvciAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICA/IGAke3ByZXZpZXcoYmFzZU93bil9IOKGkiBlcnJvcjogJHtzaGFkb3dPd25FcnJvcn1gXG4gICAgICAgICAgICA6IG93biAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgID8gZGVsdGFMaW5lKG93bilcbiAgICAgICAgICAgICAgOiBgJHtwcmV2aWV3KGJhc2VPd24pfSAodW5jaGFuZ2VkKWB9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7cmVzdC5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1saW5lXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstaW5zLWxhYmVsXCI+ZG93bnN0cmVhbTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdpLWRlbHRhc1wiPlxuICAgICAgICAgICAge3Jlc3QubWFwKChkKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtkLmlkfSBjbGFzc05hbWU9XCJyay13aS1kZWx0YVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdiLW5hbWVcIj57ZC5pZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstd2ktdmFsdWVzXCI+e2RlbHRhTGluZShkKX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHtyZXN0Lmxlbmd0aCA9PT0gMCAmJiBvd24gIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktbm90ZVwiPm5vIG90aGVyIGNlbGwgY2hhbmdlZC48L2Rpdj5cbiAgICAgICl9XG4gICAgICB7b3duID09PSB1bmRlZmluZWQgJiYgc2hhZG93T3duRXJyb3IgPT09IHVuZGVmaW5lZCAmJiBvdXRjb21lLmRlbHRhcy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdpLW5vdGVcIj5ubyBjaGFuZ2UgYWdhaW5zdCB0aGUgYmFzZWxpbmUuPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7b3V0Y29tZS52ZXJkaWN0RmxpcHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktbGluZVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWlucy1sYWJlbFwiPnZlcmRpY3RzPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktZGVsdGFzXCI+XG4gICAgICAgICAgICB7b3V0Y29tZS52ZXJkaWN0RmxpcHMubWFwKChmKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtmLnN1YmplY3R9IGNsYXNzTmFtZT1cInJrLXdpLWRlbHRhXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstd2ItbmFtZVwiPntmLnN1YmplY3R9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdpLXZhbHVlc1wiPlxuICAgICAgICAgICAgICAgICAge2YuYmVmb3JlfSDihpIge2YuYWZ0ZXJ9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtlcnJvckRpYWdzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdpLWxpbmVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1pbnMtbGFiZWxcIj5yZWZlcmVuY2VzPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktZGVsdGFzXCI+XG4gICAgICAgICAgICB7ZXJyb3JEaWFncy5tYXAoKGQsIGkpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInJrLXdiLWVycm9yXCI+XG4gICAgICAgICAgICAgICAge2QubWVzc2FnZX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdpLW5vdGVcIj5iYXNlbGluZSBwaW5uZWQgd2hlbiB0aGlzIHJ1biBzdGFydGVkIOKAlCB0aGUgbGl2ZSByZXBvcnQgbWF5IGhhdmUgYWR2YW5jZWQgc2luY2UuPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFdoYXRJZlJlc3VsdDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQVFBQSxPQUFBO0FBQThCLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQVI5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BLFNBQVNFLE9BQU9BLENBQUNDLEtBQXdCLEVBQVU7RUFDakQsSUFBSUEsS0FBSyxLQUFLLElBQUksSUFBSUEsS0FBSyxLQUFLQyxTQUFTLEVBQUUsT0FBTyxHQUFHO0VBQ3JELElBQUksT0FBT0QsS0FBSyxLQUFLLFFBQVEsRUFBRSxPQUFPRSxNQUFNLENBQUNDLElBQUksQ0FBQ0MsS0FBSyxDQUFDSixLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBQzdFLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPQSxLQUFLLEtBQUssU0FBUyxFQUFFLE9BQU9FLE1BQU0sQ0FBQ0YsS0FBSyxDQUFDO0VBQ2pGLE1BQU1LLElBQUksR0FBR0MsSUFBSSxDQUFDQyxTQUFTLENBQUNQLEtBQUssQ0FBQztFQUNsQyxPQUFPSyxJQUFJLEtBQUtKLFNBQVMsR0FBRyxHQUFHLEdBQUdJLElBQUksQ0FBQ0csTUFBTSxHQUFHLEVBQUUsR0FBRyxHQUFHSCxJQUFJLENBQUNJLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBR0osSUFBSTtBQUNyRjtBQUVBLFNBQVNLLFNBQVNBLENBQUNDLENBQWEsRUFBVTtFQUN4QyxJQUFJQSxDQUFDLENBQUNDLElBQUksS0FBSyxTQUFTLEVBQUUsT0FBTyxHQUFHYixPQUFPLENBQUNZLENBQUMsQ0FBQ0UsTUFBTSxDQUFDLE1BQU1kLE9BQU8sQ0FBQ1ksQ0FBQyxDQUFDRyxLQUFLLENBQUMsRUFBRTtFQUM3RSxJQUFJSCxDQUFDLENBQUNDLElBQUksS0FBSyxXQUFXLEVBQUUsT0FBTyxHQUFHYixPQUFPLENBQUNZLENBQUMsQ0FBQ0UsTUFBTSxDQUFDLGFBQWFGLENBQUMsQ0FBQ0ksVUFBVSxJQUFJLEVBQUUsRUFBRTtFQUN4RixJQUFJSixDQUFDLENBQUNDLElBQUksS0FBSyxlQUFlLEVBQUUsT0FBTyxtQkFBbUJiLE9BQU8sQ0FBQ1ksQ0FBQyxDQUFDRyxLQUFLLENBQUMsRUFBRTtFQUM1RSxPQUFPLFVBQVVILENBQUMsQ0FBQ0ssV0FBVyxJQUFJLEVBQUUsTUFBTUwsQ0FBQyxDQUFDSSxVQUFVLElBQUksRUFBRSxFQUFFO0FBQ2hFO0FBUUEsU0FBU0UsWUFBWUEsQ0FBQztFQUFFQyxPQUFPO0VBQUVDO0FBQTBCLENBQUMsRUFBRTtFQUM1RCxJQUFJLENBQUNELE9BQU8sQ0FBQ0UsRUFBRSxFQUFFO0lBQ2Ysb0JBQ0UsSUFBQXRCLFdBQUEsQ0FBQXVCLElBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQ0MsSUFBSSxFQUFDLFFBQVE7TUFBQUMsUUFBQSxnQkFDMUMsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUE7UUFBTUgsU0FBUyxFQUFDLFlBQVk7UUFBQUUsUUFBQSxFQUFFTixPQUFPLENBQUNRLE9BQU8sQ0FBQ0M7TUFBSSxDQUFPLENBQUMsS0FBQyxFQUFDVCxPQUFPLENBQUNRLE9BQU8sQ0FBQ0UsT0FBTztJQUFBLENBQ2hGLENBQUM7RUFFVjtFQUVBLE1BQU1DLEdBQUcsR0FBR1gsT0FBTyxDQUFDWSxNQUFNLENBQUNDLElBQUksQ0FBRXBCLENBQUMsSUFBS0EsQ0FBQyxDQUFDcUIsRUFBRSxLQUFLYixNQUFNLENBQUM7RUFDdkQsTUFBTWMsSUFBSSxHQUFHZixPQUFPLENBQUNZLE1BQU0sQ0FBQ0ksTUFBTSxDQUFFdkIsQ0FBQyxJQUFLQSxDQUFDLENBQUNxQixFQUFFLEtBQUtiLE1BQU0sQ0FBQztFQUMxRCxNQUFNZ0IsT0FBTyxHQUFHakIsT0FBTyxDQUFDa0IsUUFBUSxDQUFDQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ25CLE1BQU0sQ0FBQyxFQUFFbkIsS0FBSztFQUMzRCxNQUFNdUMsY0FBYyxHQUFHckIsT0FBTyxDQUFDc0IsT0FBTyxDQUFDckIsTUFBTSxDQUFDO0VBQzlDLE1BQU1zQixVQUFVLEdBQUd2QixPQUFPLENBQUN3QixXQUFXLENBQUNSLE1BQU0sQ0FBRXZCLENBQUMsSUFBS0EsQ0FBQyxDQUFDZ0MsUUFBUSxLQUFLLE9BQU8sQ0FBQztFQUU1RSxvQkFDRSxJQUFBN0MsV0FBQSxDQUFBdUIsSUFBQTtJQUFLQyxTQUFTLEVBQUMsY0FBYztJQUFBRSxRQUFBLGdCQUMzQixJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFBRSxRQUFBLGdCQUN6QixJQUFBMUIsV0FBQSxDQUFBMkIsR0FBQTtRQUFNSCxTQUFTLEVBQUMsY0FBYztRQUFBRSxRQUFBLEVBQUM7TUFBUyxDQUFNLENBQUMsZUFDL0MsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUE7UUFBTUgsU0FBUyxFQUFDLGNBQWM7UUFBQUUsUUFBQSxFQUMzQmUsY0FBYyxLQUFLdEMsU0FBUyxHQUN6QixHQUFHRixPQUFPLENBQUNvQyxPQUFPLENBQUMsYUFBYUksY0FBYyxFQUFFLEdBQ2hEVixHQUFHLEtBQUs1QixTQUFTLEdBQ2ZTLFNBQVMsQ0FBQ21CLEdBQUcsQ0FBQyxHQUNkLEdBQUc5QixPQUFPLENBQUNvQyxPQUFPLENBQUM7TUFBYyxDQUNuQyxDQUFDO0lBQUEsQ0FDSixDQUFDLEVBRUxGLElBQUksQ0FBQ3pCLE1BQU0sR0FBRyxDQUFDLGlCQUNkLElBQUFWLFdBQUEsQ0FBQXVCLElBQUE7TUFBS0MsU0FBUyxFQUFDLFlBQVk7TUFBQUUsUUFBQSxnQkFDekIsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUE7UUFBTUgsU0FBUyxFQUFDLGNBQWM7UUFBQUUsUUFBQSxFQUFDO01BQVUsQ0FBTSxDQUFDLGVBQ2hELElBQUExQixXQUFBLENBQUEyQixHQUFBO1FBQUtILFNBQVMsRUFBQyxjQUFjO1FBQUFFLFFBQUEsRUFDMUJTLElBQUksQ0FBQ1csR0FBRyxDQUFFakMsQ0FBQyxpQkFDVixJQUFBYixXQUFBLENBQUF1QixJQUFBO1VBQWdCQyxTQUFTLEVBQUMsYUFBYTtVQUFBRSxRQUFBLGdCQUNyQyxJQUFBMUIsV0FBQSxDQUFBMkIsR0FBQTtZQUFNSCxTQUFTLEVBQUMsWUFBWTtZQUFBRSxRQUFBLEVBQUViLENBQUMsQ0FBQ3FCO1VBQUUsQ0FBTyxDQUFDLGVBQzFDLElBQUFsQyxXQUFBLENBQUEyQixHQUFBO1lBQU1ILFNBQVMsRUFBQyxjQUFjO1lBQUFFLFFBQUEsRUFBRWQsU0FBUyxDQUFDQyxDQUFDO1VBQUMsQ0FBTyxDQUFDO1FBQUEsR0FGNUNBLENBQUMsQ0FBQ3FCLEVBR1AsQ0FDTjtNQUFDLENBQ0MsQ0FBQztJQUFBLENBQ0gsQ0FDTixFQUNBQyxJQUFJLENBQUN6QixNQUFNLEtBQUssQ0FBQyxJQUFJcUIsR0FBRyxLQUFLNUIsU0FBUyxpQkFDckMsSUFBQUgsV0FBQSxDQUFBMkIsR0FBQTtNQUFLSCxTQUFTLEVBQUMsWUFBWTtNQUFBRSxRQUFBLEVBQUM7SUFBc0IsQ0FBSyxDQUN4RCxFQUNBSyxHQUFHLEtBQUs1QixTQUFTLElBQUlzQyxjQUFjLEtBQUt0QyxTQUFTLElBQUlpQixPQUFPLENBQUNZLE1BQU0sQ0FBQ3RCLE1BQU0sS0FBSyxDQUFDLGlCQUMvRSxJQUFBVixXQUFBLENBQUEyQixHQUFBO01BQUtILFNBQVMsRUFBQyxZQUFZO01BQUFFLFFBQUEsRUFBQztJQUErQixDQUFLLENBQ2pFLEVBRUFOLE9BQU8sQ0FBQzJCLFlBQVksQ0FBQ3JDLE1BQU0sR0FBRyxDQUFDLGlCQUM5QixJQUFBVixXQUFBLENBQUF1QixJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFFLFFBQUEsZ0JBQ3pCLElBQUExQixXQUFBLENBQUEyQixHQUFBO1FBQU1ILFNBQVMsRUFBQyxjQUFjO1FBQUFFLFFBQUEsRUFBQztNQUFRLENBQU0sQ0FBQyxlQUM5QyxJQUFBMUIsV0FBQSxDQUFBMkIsR0FBQTtRQUFLSCxTQUFTLEVBQUMsY0FBYztRQUFBRSxRQUFBLEVBQzFCTixPQUFPLENBQUMyQixZQUFZLENBQUNELEdBQUcsQ0FBRUUsQ0FBQyxpQkFDMUIsSUFBQWhELFdBQUEsQ0FBQXVCLElBQUE7VUFBcUJDLFNBQVMsRUFBQyxhQUFhO1VBQUFFLFFBQUEsZ0JBQzFDLElBQUExQixXQUFBLENBQUEyQixHQUFBO1lBQU1ILFNBQVMsRUFBQyxZQUFZO1lBQUFFLFFBQUEsRUFBRXNCLENBQUMsQ0FBQ0M7VUFBTyxDQUFPLENBQUMsZUFDL0MsSUFBQWpELFdBQUEsQ0FBQXVCLElBQUE7WUFBTUMsU0FBUyxFQUFDLGNBQWM7WUFBQUUsUUFBQSxHQUMzQnNCLENBQUMsQ0FBQ2pDLE1BQU0sRUFBQyxVQUFHLEVBQUNpQyxDQUFDLENBQUNoQyxLQUFLO1VBQUEsQ0FDakIsQ0FBQztRQUFBLEdBSkNnQyxDQUFDLENBQUNDLE9BS1AsQ0FDTjtNQUFDLENBQ0MsQ0FBQztJQUFBLENBQ0gsQ0FDTixFQUVBTixVQUFVLENBQUNqQyxNQUFNLEdBQUcsQ0FBQyxpQkFDcEIsSUFBQVYsV0FBQSxDQUFBdUIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFBRSxRQUFBLGdCQUN6QixJQUFBMUIsV0FBQSxDQUFBMkIsR0FBQTtRQUFNSCxTQUFTLEVBQUMsY0FBYztRQUFBRSxRQUFBLEVBQUM7TUFBVSxDQUFNLENBQUMsZUFDaEQsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUE7UUFBS0gsU0FBUyxFQUFDLGNBQWM7UUFBQUUsUUFBQSxFQUMxQmlCLFVBQVUsQ0FBQ0csR0FBRyxDQUFDLENBQUNqQyxDQUFDLEVBQUVxQyxDQUFDLGtCQUNuQixJQUFBbEQsV0FBQSxDQUFBMkIsR0FBQTtVQUFhSCxTQUFTLEVBQUMsYUFBYTtVQUFBRSxRQUFBLEVBQ2pDYixDQUFDLENBQUNpQjtRQUFPLEdBREZvQixDQUVMLENBQ047TUFBQyxDQUNDLENBQUM7SUFBQSxDQUNILENBQ04sZUFFRCxJQUFBbEQsV0FBQSxDQUFBMkIsR0FBQTtNQUFLSCxTQUFTLEVBQUMsWUFBWTtNQUFBRSxRQUFBLEVBQUM7SUFBZ0YsQ0FBSyxDQUFDO0VBQUEsQ0FDL0csQ0FBQztBQUVWO0FBQUN5QixFQUFBLEdBaEZRaEMsWUFBWTtBQUFBLElBQUFpQyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQWtGTm5DLFlBQVk7QUFBQSxJQUFBZ0MsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}