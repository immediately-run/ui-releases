var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Range;
var _attrs = require("../attrs.ts");
var _useParam = require("./useParam.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Range widget — writes a numeric `params.<name>` bounded by literal min/max/step (§3.3). The
// declared bounds double as validation: the widget can only produce values in range.
function Range({
  node
}) {
  _s();
  const name = (0, _attrs.attrString)(node, 'name') ?? '';
  const min = (0, _attrs.attrNumber)(node, 'min') ?? 0;
  const max = (0, _attrs.attrNumber)(node, 'max') ?? 100;
  const step = (0, _attrs.attrNumber)(node, 'step') ?? 1;
  const def = (0, _attrs.attrNumber)(node, 'default') ?? min;
  const {
    value,
    set
  } = (0, _useParam.useParam)(name, def);
  const current = typeof value === 'number' ? value : def;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
    className: "rk-widget rk-widget-range",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "rk-widget-label",
      children: [name, " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-widget-num",
        children: current
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
      type: "range",
      min: min,
      max: max,
      step: step,
      value: current,
      onChange: e => set(Number(e.target.value))
    })]
  });
}
_s(Range, "P5g961Dx7UfkNf2t68spDCPaBwI=", false, function () {
  return [_useParam.useParam];
});
_c = Range;
var _c;
$RefreshReg$(_c, "Range");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3VzZVBhcmFtIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlJhbmdlIiwibm9kZSIsIm5hbWUiLCJhdHRyU3RyaW5nIiwibWluIiwiYXR0ck51bWJlciIsIm1heCIsInN0ZXAiLCJkZWYiLCJ2YWx1ZSIsInNldCIsInVzZVBhcmFtIiwiY3VycmVudCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInR5cGUiLCJvbkNoYW5nZSIsImUiLCJOdW1iZXIiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJhbmdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSYW5nZSB3aWRnZXQg4oCUIHdyaXRlcyBhIG51bWVyaWMgYHBhcmFtcy48bmFtZT5gIGJvdW5kZWQgYnkgbGl0ZXJhbCBtaW4vbWF4L3N0ZXAgKMKnMy4zKS4gVGhlXG4vLyBkZWNsYXJlZCBib3VuZHMgZG91YmxlIGFzIHZhbGlkYXRpb246IHRoZSB3aWRnZXQgY2FuIG9ubHkgcHJvZHVjZSB2YWx1ZXMgaW4gcmFuZ2UuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyBhdHRyU3RyaW5nLCBhdHRyTnVtYmVyIH0gZnJvbSAnLi4vYXR0cnMudHMnO1xuaW1wb3J0IHsgdXNlUGFyYW0gfSBmcm9tICcuL3VzZVBhcmFtLnRzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmFuZ2UoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IG5hbWUgPSBhdHRyU3RyaW5nKG5vZGUsICduYW1lJykgPz8gJyc7XG4gIGNvbnN0IG1pbiA9IGF0dHJOdW1iZXIobm9kZSwgJ21pbicpID8/IDA7XG4gIGNvbnN0IG1heCA9IGF0dHJOdW1iZXIobm9kZSwgJ21heCcpID8/IDEwMDtcbiAgY29uc3Qgc3RlcCA9IGF0dHJOdW1iZXIobm9kZSwgJ3N0ZXAnKSA/PyAxO1xuICBjb25zdCBkZWYgPSBhdHRyTnVtYmVyKG5vZGUsICdkZWZhdWx0JykgPz8gbWluO1xuICBjb25zdCB7IHZhbHVlLCBzZXQgfSA9IHVzZVBhcmFtKG5hbWUsIGRlZik7XG4gIGNvbnN0IGN1cnJlbnQgPSB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInID8gdmFsdWUgOiBkZWY7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIGNsYXNzTmFtZT1cInJrLXdpZGdldCByay13aWRnZXQtcmFuZ2VcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdpZGdldC1sYWJlbFwiPlxuICAgICAgICB7bmFtZX0gPHNwYW4gY2xhc3NOYW1lPVwicmstd2lkZ2V0LW51bVwiPntjdXJyZW50fTwvc3Bhbj5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxpbnB1dCB0eXBlPVwicmFuZ2VcIiBtaW49e21pbn0gbWF4PXttYXh9IHN0ZXA9e3N0ZXB9IHZhbHVlPXtjdXJyZW50fSBvbkNoYW5nZT17KGUpID0+IHNldChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0gLz5cbiAgICA8L2xhYmVsPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFBeUMsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBSnpDO0FBQ0E7QUFLZSxTQUFTQyxLQUFLQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBSCxFQUFBO0VBQy9ELE1BQU1JLElBQUksR0FBRyxJQUFBQyxpQkFBVSxFQUFDRixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRTtFQUMzQyxNQUFNRyxHQUFHLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0osSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUM7RUFDeEMsTUFBTUssR0FBRyxHQUFHLElBQUFELGlCQUFVLEVBQUNKLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxHQUFHO0VBQzFDLE1BQU1NLElBQUksR0FBRyxJQUFBRixpQkFBVSxFQUFDSixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQztFQUMxQyxNQUFNTyxHQUFHLEdBQUcsSUFBQUgsaUJBQVUsRUFBQ0osSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJRyxHQUFHO0VBQzlDLE1BQU07SUFBRUssS0FBSztJQUFFQztFQUFJLENBQUMsR0FBRyxJQUFBQyxrQkFBUSxFQUFDVCxJQUFJLEVBQUVNLEdBQUcsQ0FBQztFQUMxQyxNQUFNSSxPQUFPLEdBQUcsT0FBT0gsS0FBSyxLQUFLLFFBQVEsR0FBR0EsS0FBSyxHQUFHRCxHQUFHO0VBQ3ZELG9CQUNFLElBQUFYLFdBQUEsQ0FBQWdCLElBQUE7SUFBT0MsU0FBUyxFQUFDLDJCQUEyQjtJQUFBQyxRQUFBLGdCQUMxQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQTtNQUFNQyxTQUFTLEVBQUMsaUJBQWlCO01BQUFDLFFBQUEsR0FDOUJiLElBQUksRUFBQyxHQUFDLG1CQUFBTCxXQUFBLENBQUFtQixHQUFBO1FBQU1GLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsRUFBRUg7TUFBTyxDQUFPLENBQUM7SUFBQSxDQUNuRCxDQUFDLGVBQ1AsSUFBQWYsV0FBQSxDQUFBbUIsR0FBQTtNQUFPQyxJQUFJLEVBQUMsT0FBTztNQUFDYixHQUFHLEVBQUVBLEdBQUk7TUFBQ0UsR0FBRyxFQUFFQSxHQUFJO01BQUNDLElBQUksRUFBRUEsSUFBSztNQUFDRSxLQUFLLEVBQUVHLE9BQVE7TUFBQ00sUUFBUSxFQUFHQyxDQUFDLElBQUtULEdBQUcsQ0FBQ1UsTUFBTSxDQUFDRCxDQUFDLENBQUNFLE1BQU0sQ0FBQ1osS0FBSyxDQUFDO0lBQUUsQ0FBRSxDQUFDO0VBQUEsQ0FDL0csQ0FBQztBQUVaO0FBQUNYLEVBQUEsQ0FoQnVCRSxLQUFLO0VBQUEsUUFNSlcsa0JBQVE7QUFBQTtBQUFBVyxFQUFBLEdBTlR0QixLQUFLO0FBQUEsSUFBQXNCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}