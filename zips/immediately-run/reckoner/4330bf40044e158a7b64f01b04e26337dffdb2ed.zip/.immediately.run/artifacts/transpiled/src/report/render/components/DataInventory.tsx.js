var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DataInventory;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _attrs = require("../attrs.ts");
var _reflectionContext = require("../reflectionContext.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // DataInventory — the reflection component listing the document's data assets
// (AUTHORS_VIEW_SPEC §2, §3.1–§3.3). Fixtures: name, derived shape ("first-row columns"
// — an honest O(1) label, §3.1), the document-AUTHORED tier as plain labeled data (the
// review-1 H2 precedent — never chip chrome, §3.2), and provenance. Feeds: the
// allowlisted projection only (name, mode, scheme+host) — the port never carries raw
// config, so nothing here CAN render a query string or a secretRef (§3.3, G-AV-9).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function DataInventory({
  node
}) {
  _s();
  const reflection = (0, _reflectionContext.useReflection)();
  const kind = (0, _attrs.attrString)(node, 'kind');
  if (reflection === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "DataInventory",
      reason: "available only in the author's view"
    });
  }
  const showFixtures = kind === undefined || kind === 'fixtures';
  const showFeeds = kind === undefined || kind === 'feeds';
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-refl-index",
    children: [showFixtures && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-refl-datakind",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h4", {
        className: "rk-refl-datakind-name",
        children: "fixtures"
      }), reflection.fixtures.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-refl-none",
        children: "none in this document."
      }), reflection.fixtures.map(fx => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-refl-datum",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-name",
          children: fx.name
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-refl-shape",
          children: [fx.rowCount, " rows \xB7 first-row columns: ", fx.firstRowColumns.length === 0 ? '—' : fx.firstRowColumns.join(', ')]
        }), fx.declaredTier !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-refl-plain",
          children: ["declared tier: ", fx.declaredTier]
        }), fx.sourceFeed !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-refl-plain",
          children: ["captured from feed \u201C", fx.sourceFeed, "\u201D"]
        })]
      }, fx.name))]
    }), showFeeds && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-refl-datakind",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h4", {
        className: "rk-refl-datakind-name",
        children: "feeds"
      }), reflection.feeds.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-refl-none",
        children: "none in this document."
      }), reflection.feeds.map(feed => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-refl-datum",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-name",
          children: feed.name
        }), feed.mode !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-refl-plain",
          children: ["mode: ", feed.mode]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-plain",
          children: feed.hosts.join(' · ')
        })]
      }, feed.name))]
    })]
  });
}
_s(DataInventory, "EcuPFGw29ARuTs47OEyfycl8jbM=", false, function () {
  return [_reflectionContext.useReflection];
});
_c = DataInventory;
var _c;
$RefreshReg$(_c, "DataInventory");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlZmxlY3Rpb25Db250ZXh0IiwiX0Jyb2tlblRpbGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkRhdGFJbnZlbnRvcnkiLCJub2RlIiwicmVmbGVjdGlvbiIsInVzZVJlZmxlY3Rpb24iLCJraW5kIiwiYXR0clN0cmluZyIsImpzeCIsImNvbXBvbmVudCIsInJlYXNvbiIsInNob3dGaXh0dXJlcyIsInVuZGVmaW5lZCIsInNob3dGZWVkcyIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImZpeHR1cmVzIiwibGVuZ3RoIiwibWFwIiwiZngiLCJuYW1lIiwicm93Q291bnQiLCJmaXJzdFJvd0NvbHVtbnMiLCJqb2luIiwiZGVjbGFyZWRUaWVyIiwic291cmNlRmVlZCIsImZlZWRzIiwiZmVlZCIsIm1vZGUiLCJob3N0cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGF0YUludmVudG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRGF0YUludmVudG9yeSDigJQgdGhlIHJlZmxlY3Rpb24gY29tcG9uZW50IGxpc3RpbmcgdGhlIGRvY3VtZW50J3MgZGF0YSBhc3NldHNcbi8vIChBVVRIT1JTX1ZJRVdfU1BFQyDCpzIsIMKnMy4x4oCTwqczLjMpLiBGaXh0dXJlczogbmFtZSwgZGVyaXZlZCBzaGFwZSAoXCJmaXJzdC1yb3cgY29sdW1uc1wiXG4vLyDigJQgYW4gaG9uZXN0IE8oMSkgbGFiZWwsIMKnMy4xKSwgdGhlIGRvY3VtZW50LUFVVEhPUkVEIHRpZXIgYXMgcGxhaW4gbGFiZWxlZCBkYXRhICh0aGVcbi8vIHJldmlldy0xIEgyIHByZWNlZGVudCDigJQgbmV2ZXIgY2hpcCBjaHJvbWUsIMKnMy4yKSwgYW5kIHByb3ZlbmFuY2UuIEZlZWRzOiB0aGVcbi8vIGFsbG93bGlzdGVkIHByb2plY3Rpb24gb25seSAobmFtZSwgbW9kZSwgc2NoZW1lK2hvc3QpIOKAlCB0aGUgcG9ydCBuZXZlciBjYXJyaWVzIHJhd1xuLy8gY29uZmlnLCBzbyBub3RoaW5nIGhlcmUgQ0FOIHJlbmRlciBhIHF1ZXJ5IHN0cmluZyBvciBhIHNlY3JldFJlZiAowqczLjMsIEctQVYtOSkuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyBhdHRyU3RyaW5nIH0gZnJvbSAnLi4vYXR0cnMudHMnO1xuaW1wb3J0IHsgdXNlUmVmbGVjdGlvbiB9IGZyb20gJy4uL3JlZmxlY3Rpb25Db250ZXh0LnRzJztcbmltcG9ydCBCcm9rZW5UaWxlIGZyb20gJy4vQnJva2VuVGlsZS50c3gnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXRhSW52ZW50b3J5KHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCByZWZsZWN0aW9uID0gdXNlUmVmbGVjdGlvbigpO1xuICBjb25zdCBraW5kID0gYXR0clN0cmluZyhub2RlLCAna2luZCcpO1xuXG4gIGlmIChyZWZsZWN0aW9uID09PSBudWxsKSB7XG4gICAgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIkRhdGFJbnZlbnRvcnlcIiByZWFzb249XCJhdmFpbGFibGUgb25seSBpbiB0aGUgYXV0aG9yJ3Mgdmlld1wiIC8+O1xuICB9XG5cbiAgY29uc3Qgc2hvd0ZpeHR1cmVzID0ga2luZCA9PT0gdW5kZWZpbmVkIHx8IGtpbmQgPT09ICdmaXh0dXJlcyc7XG4gIGNvbnN0IHNob3dGZWVkcyA9IGtpbmQgPT09IHVuZGVmaW5lZCB8fCBraW5kID09PSAnZmVlZHMnO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLWluZGV4XCI+XG4gICAgICB7c2hvd0ZpeHR1cmVzICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLWRhdGFraW5kXCI+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInJrLXJlZmwtZGF0YWtpbmQtbmFtZVwiPmZpeHR1cmVzPC9oND5cbiAgICAgICAgICB7cmVmbGVjdGlvbi5maXh0dXJlcy5sZW5ndGggPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLW5vbmVcIj5ub25lIGluIHRoaXMgZG9jdW1lbnQuPC9kaXY+fVxuICAgICAgICAgIHtyZWZsZWN0aW9uLmZpeHR1cmVzLm1hcCgoZngpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtmeC5uYW1lfSBjbGFzc05hbWU9XCJyay1yZWZsLWRhdHVtXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwtbmFtZVwiPntmeC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstcmVmbC1zaGFwZVwiPlxuICAgICAgICAgICAgICAgIHtmeC5yb3dDb3VudH0gcm93cyDCtyBmaXJzdC1yb3cgY29sdW1uczoge2Z4LmZpcnN0Um93Q29sdW1ucy5sZW5ndGggPT09IDAgPyAn4oCUJyA6IGZ4LmZpcnN0Um93Q29sdW1ucy5qb2luKCcsICcpfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHtmeC5kZWNsYXJlZFRpZXIgIT09IHVuZGVmaW5lZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJyay1yZWZsLXBsYWluXCI+ZGVjbGFyZWQgdGllcjoge2Z4LmRlY2xhcmVkVGllcn08L3NwYW4+fVxuICAgICAgICAgICAgICB7Znguc291cmNlRmVlZCAhPT0gdW5kZWZpbmVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwtcGxhaW5cIj5jYXB0dXJlZCBmcm9tIGZlZWQg4oCce2Z4LnNvdXJjZUZlZWR94oCdPC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7c2hvd0ZlZWRzICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLWRhdGFraW5kXCI+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInJrLXJlZmwtZGF0YWtpbmQtbmFtZVwiPmZlZWRzPC9oND5cbiAgICAgICAgICB7cmVmbGVjdGlvbi5mZWVkcy5sZW5ndGggPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLW5vbmVcIj5ub25lIGluIHRoaXMgZG9jdW1lbnQuPC9kaXY+fVxuICAgICAgICAgIHtyZWZsZWN0aW9uLmZlZWRzLm1hcCgoZmVlZCkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2ZlZWQubmFtZX0gY2xhc3NOYW1lPVwicmstcmVmbC1kYXR1bVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1yZWZsLW5hbWVcIj57ZmVlZC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAge2ZlZWQubW9kZSAhPT0gdW5kZWZpbmVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwtcGxhaW5cIj5tb2RlOiB7ZmVlZC5tb2RlfTwvc3Bhbj59XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwtcGxhaW5cIj57ZmVlZC5ob3N0cy5qb2luKCcgwrcgJyl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFPQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxrQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQTBDLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVQxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQU1lLFNBQVNHLGFBQWFBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDdkUsTUFBTU8sVUFBVSxHQUFHLElBQUFDLGdDQUFhLEVBQUMsQ0FBQztFQUNsQyxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0osSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUVyQyxJQUFJQyxVQUFVLEtBQUssSUFBSSxFQUFFO0lBQ3ZCLG9CQUFPLElBQUFSLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxXQUFBLENBQUFPLE9BQVU7TUFBQ1EsU0FBUyxFQUFDLGVBQWU7TUFBQ0MsTUFBTSxFQUFDO0lBQXFDLENBQUUsQ0FBQztFQUM5RjtFQUVBLE1BQU1DLFlBQVksR0FBR0wsSUFBSSxLQUFLTSxTQUFTLElBQUlOLElBQUksS0FBSyxVQUFVO0VBQzlELE1BQU1PLFNBQVMsR0FBR1AsSUFBSSxLQUFLTSxTQUFTLElBQUlOLElBQUksS0FBSyxPQUFPO0VBRXhELG9CQUNFLElBQUFWLFdBQUEsQ0FBQWtCLElBQUE7SUFBS0MsU0FBUyxFQUFDLGVBQWU7SUFBQUMsUUFBQSxHQUMzQkwsWUFBWSxpQkFDWCxJQUFBZixXQUFBLENBQUFrQixJQUFBO01BQUtDLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxnQkFDL0IsSUFBQXBCLFdBQUEsQ0FBQVksR0FBQTtRQUFJTyxTQUFTLEVBQUMsdUJBQXVCO1FBQUFDLFFBQUEsRUFBQztNQUFRLENBQUksQ0FBQyxFQUNsRFosVUFBVSxDQUFDYSxRQUFRLENBQUNDLE1BQU0sS0FBSyxDQUFDLGlCQUFJLElBQUF0QixXQUFBLENBQUFZLEdBQUE7UUFBS08sU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxFQUFDO01BQXNCLENBQUssQ0FBQyxFQUM5RlosVUFBVSxDQUFDYSxRQUFRLENBQUNFLEdBQUcsQ0FBRUMsRUFBRSxpQkFDMUIsSUFBQXhCLFdBQUEsQ0FBQWtCLElBQUE7UUFBbUJDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsZ0JBQzFDLElBQUFwQixXQUFBLENBQUFZLEdBQUE7VUFBTU8sU0FBUyxFQUFDLGNBQWM7VUFBQUMsUUFBQSxFQUFFSSxFQUFFLENBQUNDO1FBQUksQ0FBTyxDQUFDLGVBQy9DLElBQUF6QixXQUFBLENBQUFrQixJQUFBO1VBQU1DLFNBQVMsRUFBQyxlQUFlO1VBQUFDLFFBQUEsR0FDNUJJLEVBQUUsQ0FBQ0UsUUFBUSxFQUFDLGdDQUEyQixFQUFDRixFQUFFLENBQUNHLGVBQWUsQ0FBQ0wsTUFBTSxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUdFLEVBQUUsQ0FBQ0csZUFBZSxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQUEsQ0FDMUcsQ0FBQyxFQUNOSixFQUFFLENBQUNLLFlBQVksS0FBS2IsU0FBUyxpQkFBSSxJQUFBaEIsV0FBQSxDQUFBa0IsSUFBQTtVQUFNQyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEdBQUMsaUJBQWUsRUFBQ0ksRUFBRSxDQUFDSyxZQUFZO1FBQUEsQ0FBTyxDQUFDLEVBQ3hHTCxFQUFFLENBQUNNLFVBQVUsS0FBS2QsU0FBUyxpQkFBSSxJQUFBaEIsV0FBQSxDQUFBa0IsSUFBQTtVQUFNQyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEdBQUMsMkJBQW9CLEVBQUNJLEVBQUUsQ0FBQ00sVUFBVSxFQUFDLFFBQUM7UUFBQSxDQUFNLENBQUM7TUFBQSxHQU5uR04sRUFBRSxDQUFDQyxJQU9SLENBQ04sQ0FBQztJQUFBLENBQ0MsQ0FDTixFQUNBUixTQUFTLGlCQUNSLElBQUFqQixXQUFBLENBQUFrQixJQUFBO01BQUtDLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxnQkFDL0IsSUFBQXBCLFdBQUEsQ0FBQVksR0FBQTtRQUFJTyxTQUFTLEVBQUMsdUJBQXVCO1FBQUFDLFFBQUEsRUFBQztNQUFLLENBQUksQ0FBQyxFQUMvQ1osVUFBVSxDQUFDdUIsS0FBSyxDQUFDVCxNQUFNLEtBQUssQ0FBQyxpQkFBSSxJQUFBdEIsV0FBQSxDQUFBWSxHQUFBO1FBQUtPLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFBQztNQUFzQixDQUFLLENBQUMsRUFDM0ZaLFVBQVUsQ0FBQ3VCLEtBQUssQ0FBQ1IsR0FBRyxDQUFFUyxJQUFJLGlCQUN6QixJQUFBaEMsV0FBQSxDQUFBa0IsSUFBQTtRQUFxQkMsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxnQkFDNUMsSUFBQXBCLFdBQUEsQ0FBQVksR0FBQTtVQUFNTyxTQUFTLEVBQUMsY0FBYztVQUFBQyxRQUFBLEVBQUVZLElBQUksQ0FBQ1A7UUFBSSxDQUFPLENBQUMsRUFDaERPLElBQUksQ0FBQ0MsSUFBSSxLQUFLakIsU0FBUyxpQkFBSSxJQUFBaEIsV0FBQSxDQUFBa0IsSUFBQTtVQUFNQyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEdBQUMsUUFBTSxFQUFDWSxJQUFJLENBQUNDLElBQUk7UUFBQSxDQUFPLENBQUMsZUFDcEYsSUFBQWpDLFdBQUEsQ0FBQVksR0FBQTtVQUFNTyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEVBQUVZLElBQUksQ0FBQ0UsS0FBSyxDQUFDTixJQUFJLENBQUMsS0FBSztRQUFDLENBQU8sQ0FBQztNQUFBLEdBSHZESSxJQUFJLENBQUNQLElBSVYsQ0FDTixDQUFDO0lBQUEsQ0FDQyxDQUNOO0VBQUEsQ0FDRSxDQUFDO0FBRVY7QUFBQ3hCLEVBQUEsQ0E1Q3VCSyxhQUFhO0VBQUEsUUFDaEJHLGdDQUFhO0FBQUE7QUFBQTBCLEVBQUEsR0FEVjdCLGFBQWE7QUFBQSxJQUFBNkIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}