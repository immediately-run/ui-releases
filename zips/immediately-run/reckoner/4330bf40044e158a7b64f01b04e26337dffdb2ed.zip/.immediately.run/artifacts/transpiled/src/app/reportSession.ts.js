"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "CALDERA_SEED", {
  enumerable: true,
  get: function () {
    return _seeds.CALDERA_SEED;
  }
});
Object.defineProperty(exports, "MERIDIAN_SEED", {
  enumerable: true,
  get: function () {
    return _seeds.MERIDIAN_SEED;
  }
});
exports.assembleExternals = assembleExternals;
exports.buildReportSession = buildReportSession;
exports.makeTransport = makeTransport;
exports.sessionBindings = sessionBindings;
exports.xrefDiagnostics = xrefDiagnostics;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _asyncEngine = require("../engine/asyncEngine.ts");
var _workerTransport = require("../engine/workerTransport.ts");
var _loader = require("../document/loader.ts");
var _xref = require("../document/xref.ts");
var _paramRefs = require("../document/paramRefs.ts");
var _catalog = require("../report/catalog.ts");
var _mdx = require("../report/parse/mdx.ts");
var _validate = require("../report/validate.ts");
var _authorsView = require("./authorsView.ts");
var _bindings = require("../report/render/bindings.ts");
var _memoryReader = require("./memoryReader.ts");
var _fsReader = require("../document/fsReader.ts");
var _dispatch = require("./dispatch.ts");
var _seeds = require("../seed/seeds.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // Shell B integration + shell C wiring (ARCHITECTURE_PLAN §2.1, §4, §7) — ties the pure spine
// to the render surface: load a document → run the **worker-backed** engine → parse the
// template → hand the renderer a `Bindings` adapter over the engine's results.
//
// The engine is now the `AsyncEngine`: formula execution happens in a terminable, `lockdown()`-ed
// SES Web Worker (`src/entry/engine.ts`), so a runaway formula is contained by the host watchdog
// rather than wedging the UI thread. Where a real `Worker` is unavailable (SSR/tests) it falls
// back to an in-process transport — same orchestration, main-thread execution.
//
// `sessionBindings` is the engine adapter the renderer resolves through (the render side is
// unit-tested against a hand-built port, so this stays a thin adapter). Params close the
// interaction loop: a widget write updates the external, calls the engine's async `update`, and
// re-renders when the pass settles.
// Re-exported for existing import sites (the seeds themselves live in src/seed/seeds.ts).
const EXTERNAL_NAMESPACES = ['feeds.', 'fixtures.', 'static.', 'params.'];
const TIERS = new Set(['static', 'pulled', 'live']);
function normTier(tag) {
  return tag !== undefined && TIERS.has(tag) ? tag : 'static';
}

/** Assemble the engine's externals from the document's fixtures + manifest param defaults + paramRefs knobs (R3-377). Exported for the case-study harness; the app wires it via {@link buildReportSession}. */
function assembleExternals(loaded) {
  const externals = {};
  for (const fx of loaded.fixtures) {
    externals[`fixtures.${fx.name}`] = {
      value: fx.frame.rows,
      tier: normTier(fx.frame.tier)
    };
  }
  for (const [name, value] of Object.entries(loaded.manifest.params)) {
    externals[`params.${name}`] = {
      value,
      tier: 'static'
    };
  }
  // Assumptions-as-params: each knob's default is read from its fixture leaf and also
  // published as `params.<name>` (for template binding + the params surface).
  const {
    defaults,
    refs,
    diagnostics
  } = (0, _paramRefs.resolveParamRefs)(loaded.manifest.paramRefs, loaded.fixtures);
  for (const [key, ext] of Object.entries(defaults)) {
    if (externals[key] === undefined) externals[key] = {
      value: ext.value,
      tier: ext.tier
    };
  }
  void diagnostics; // already surfaced by the loader's paramRefDiagnostics
  return {
    externals,
    paramRefs: refs
  };
}

/**
 * The engine's worker transport: a real module Web Worker (off-main-thread, `lockdown()`-ed)
 * under real module semantics (`vite` dev + build), else the in-process fallback.
 *
 * The worker's URL lives in `./workerUrl.ts` behind `import.meta.url` — a web standard, but
 * one immediately.run cannot yet evaluate: the platform transpiles app source ESM→CommonJS
 * and runs it as a classic script, where `import.meta` is a **parse-time** SyntaxError. That
 * module is therefore reached only via a dynamic `import()` inside this try/catch, so on the
 * platform the failure is *catchable* and the in-process transport takes over (same engine,
 * main-thread) instead of the whole app dying at module load. When the platform learns
 * `import.meta.url` (roadmap: the sandbox transpiler shim), nothing here needs to change.
 */
async function makeTransport(loadWorkerUrl = () => Promise.resolve().then(() => _interopRequireWildcard(require('./workerUrl.ts')))) {
  if (typeof Worker !== 'undefined') {
    try {
      const {
        ENGINE_WORKER_URL
      } = await loadWorkerUrl();
      return (0, _workerTransport.workerTransport)(() => new Worker(ENGINE_WORKER_URL, {
        type: 'module'
      }));
    } catch {
      /* classic-script semantics (immediately.run) — fall through to the in-process transport */
    }
  }
  return (0, _workerTransport.inMemoryTransport)();
}

/** The param names the template's input widgets can set (a `name`d widget declares one). */
function widgetParamNames(nodes) {
  const names = new Set();
  const walk = list => {
    for (const n of list) {
      if (n.type === 'component') {
        if (_catalog.WIDGETS.has(n.name) && n.attrs.name?.kind === 'literal' && typeof n.attrs.name.value === 'string') {
          names.add(n.attrs.name.value);
        }
        walk(n.children);
      }
    }
  };
  walk(nodes);
  return names;
}

/** Reflection component names used in a node tree (AUTHORS_VIEW_SPEC §6's consumer-template diagnostic). */
function reflectionComponentNames(nodes) {
  const found = new Set();
  const walk = list => {
    for (const n of list) {
      if (n.type === 'component') {
        if (_catalog.REFLECTION.has(n.name)) found.add(n.name);
        walk(n.children);
      }
    }
  };
  walk(nodes);
  return [...found];
}

/**
 * Cross-reference diagnostics for a loaded document + the workbook the engine built from
 * it: every worksheet external checked against what the document (and the running app)
 * can supply. Exported for unit tests; `buildReportSession` wires it.
 */
function xrefDiagnostics(loaded, references, nodes, runtimeFeeds = []) {
  return (0, _xref.validateExternalReferences)(references, {
    feeds: new Set([...loaded.feeds.map(f => f.name), ...runtimeFeeds]),
    fixtures: new Set(loaded.fixtures.map(f => f.name)),
    params: new Set([...Object.keys(loaded.manifest.params), ...Object.keys(loaded.manifest.paramRefs ?? {}), ...widgetParamNames(nodes)]),
    worksheetPaths: Object.fromEntries(loaded.worksheets.map(w => [w.name, w.path]))
  });
}

/** Load a bundled document and run the full cold pipeline through the worker engine. */
async function buildReportSession(transport, seed = _seeds.MERIDIAN_SEED, mounts = []) {
  const t = transport ?? (await makeTransport());

  // The dispatched flow first: a workbook repo that arrived as a content mount
  // (R3-172 repo-load dispatch) is read from the filesystem — plain files, the same
  // `loadDocument` pipeline as the seed, no copy embedded in this app. Absent a
  // dispatched mount, the bundled seed document (optionally `?doc=`-selected).
  const dispatch = (0, _dispatch.resolveWorkbookMount)(mounts);
  const loaded = dispatch.ok ? await (0, _loader.loadDocument)((0, _fsReader.fsReader)(), dispatch.root) : await (0, _loader.loadDocument)((0, _memoryReader.memoryReader)(seed.files), seed.root);
  const worksheetSources = {};
  for (const w of loaded.worksheets) worksheetSources[w.name] = w.source;
  const engine = await _asyncEngine.AsyncEngine.fromSources(worksheetSources, {
    transport: t
  });
  const {
    externals,
    paramRefs
  } = assembleExternals(loaded);
  await engine.run(externals);

  // Template roles (AUTHORS_VIEW_SPEC §4): the author's-view template — manifest-named
  // or the reserved `authors_view` — is excluded from consumer-report selection; the
  // consumer pick otherwise keeps the existing `weekly` guess. Absent an author's-view
  // file, the built-in scaffold is the default view (§1.1).
  const authorsName = (0, _authorsView.authorsViewName)(loaded);
  const template = (0, _authorsView.consumerTemplate)(loaded.templates, authorsName);
  const nodes = template === undefined ? [] : (0, _mdx.parseTemplate)(template.source);
  const authorsFile = loaded.templates.find(t => t.name === authorsName);
  const authorsNodes = (0, _mdx.parseTemplate)(authorsFile?.source ?? _authorsView.AUTHORS_VIEW_SCAFFOLD);

  // Both trees validate against the catalog, diagnostics attributed per file (§3.5) —
  // and a reflection component in a CONSUMER template is flagged (§6): the port is
  // withheld there, so it would render the author's-view-only tile.
  const templateDiagnostics = [];
  if (template !== undefined) {
    for (const d of (0, _validate.validateTemplate)(nodes).diagnostics) {
      templateDiagnostics.push({
        severity: d.severity,
        file: template.path,
        message: `${d.component}: ${d.message}`
      });
    }
    for (const name of reflectionComponentNames(nodes)) {
      templateDiagnostics.push({
        severity: 'warning',
        file: template.path,
        message: `<${name}> is an author's-view component; in the report it renders as unavailable.`
      });
    }
  }
  if (authorsFile !== undefined) {
    for (const d of (0, _validate.validateTemplate)(authorsNodes).diagnostics) {
      templateDiagnostics.push({
        severity: d.severity,
        file: authorsFile.path,
        message: `${d.component}: ${d.message}`
      });
    }
  }

  // Cross-reference validation: a bundled seed reads no app-supplied runtime feed
  // (R3-768), so the feed universe a mounted/dispatched workbook sees is its own —
  // the declared `feeds/*.feed.json` set — and a bundled seed's is empty.
  const runtimeFeeds = [];
  const diagnostics = [...loaded.diagnostics, ...templateDiagnostics,
  // The params universe spans BOTH trees (§3.5): a widget an author places in a
  // custom author's view resolves rather than false-flagging.
  ...xrefDiagnostics(loaded, engine.externalReferences(), [...nodes, ...authorsNodes], runtimeFeeds)];
  return {
    engine,
    externals,
    paramRefs,
    nodes,
    title: loaded.manifest.title ?? 'Reckoner report',
    diagnostics,
    sources: worksheetSources,
    loaded,
    runtimeFeeds,
    authorsNodes,
    authorsFromDocument: authorsFile !== undefined
  };
}

/** The engine adapter the renderer resolves `source` bindings through. */
function sessionBindings(session, onChange) {
  return {
    resolve(source) {
      if (EXTERNAL_NAMESPACES.some(ns => source.startsWith(ns))) {
        const ext = session.externals[source];
        return ext === undefined ? (0, _bindings.missing)(source) : {
          value: ext.value,
          tier: ext.tier,
          status: 'ok'
        };
      }
      const err = session.engine.error(source);
      if (err !== undefined) return {
        value: null,
        tier: 'live',
        status: 'error',
        message: err
      };
      const result = session.engine.result(source);
      return result === undefined ? (0, _bindings.missing)(source) : {
        value: result.value,
        tier: result.tier,
        status: 'ok'
      };
    },
    setParam(name, value) {
      // A paramRefs knob (R3-377) shadows its leaf INSIDE the fixture value — one
      // coherent frozen snapshot for the formulas, riding the existing externals path,
      // so exactly the cells that declared that fixture recompute.
      const ref = session.paramRefs[name];
      if (ref !== undefined) {
        const fixtureValue = session.externals[ref.from]?.value;
        if (fixtureValue !== undefined) {
          const patch = (0, _paramRefs.paramShadow)(name, value, ref, fixtureValue);
          for (const [key, {
            value: v
          }] of Object.entries(patch)) {
            session.externals[key] = {
              value: v,
              tier: 'static'
            };
          }
          void session.engine.update(patch).then(onChange);
          return;
        }
      }
      const key = `params.${name}`;
      const ext = {
        value,
        tier: 'static'
      };
      session.externals[key] = ext;
      // The engine recomputes off the main thread; re-render when the pass settles.
      void session.engine.update({
        [key]: ext
      }).then(onChange);
    }
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXN5bmNFbmdpbmUiLCJyZXF1aXJlIiwiX3dvcmtlclRyYW5zcG9ydCIsIl9sb2FkZXIiLCJfeHJlZiIsIl9wYXJhbVJlZnMiLCJfY2F0YWxvZyIsIl9tZHgiLCJfdmFsaWRhdGUiLCJfYXV0aG9yc1ZpZXciLCJfYmluZGluZ3MiLCJfbWVtb3J5UmVhZGVyIiwiX2ZzUmVhZGVyIiwiX2Rpc3BhdGNoIiwiX3NlZWRzIiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJFWFRFUk5BTF9OQU1FU1BBQ0VTIiwiVElFUlMiLCJTZXQiLCJub3JtVGllciIsInRhZyIsInVuZGVmaW5lZCIsImFzc2VtYmxlRXh0ZXJuYWxzIiwibG9hZGVkIiwiZXh0ZXJuYWxzIiwiZngiLCJmaXh0dXJlcyIsIm5hbWUiLCJ2YWx1ZSIsImZyYW1lIiwicm93cyIsInRpZXIiLCJlbnRyaWVzIiwibWFuaWZlc3QiLCJwYXJhbXMiLCJkZWZhdWx0cyIsInJlZnMiLCJkaWFnbm9zdGljcyIsInJlc29sdmVQYXJhbVJlZnMiLCJwYXJhbVJlZnMiLCJrZXkiLCJleHQiLCJtYWtlVHJhbnNwb3J0IiwibG9hZFdvcmtlclVybCIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsIldvcmtlciIsIkVOR0lORV9XT1JLRVJfVVJMIiwid29ya2VyVHJhbnNwb3J0IiwidHlwZSIsImluTWVtb3J5VHJhbnNwb3J0Iiwid2lkZ2V0UGFyYW1OYW1lcyIsIm5vZGVzIiwibmFtZXMiLCJ3YWxrIiwibGlzdCIsIldJREdFVFMiLCJhdHRycyIsImtpbmQiLCJhZGQiLCJjaGlsZHJlbiIsInJlZmxlY3Rpb25Db21wb25lbnROYW1lcyIsImZvdW5kIiwiUkVGTEVDVElPTiIsInhyZWZEaWFnbm9zdGljcyIsInJlZmVyZW5jZXMiLCJydW50aW1lRmVlZHMiLCJ2YWxpZGF0ZUV4dGVybmFsUmVmZXJlbmNlcyIsImZlZWRzIiwibWFwIiwiZiIsImtleXMiLCJ3b3Jrc2hlZXRQYXRocyIsImZyb21FbnRyaWVzIiwid29ya3NoZWV0cyIsInciLCJwYXRoIiwiYnVpbGRSZXBvcnRTZXNzaW9uIiwidHJhbnNwb3J0Iiwic2VlZCIsIk1FUklESUFOX1NFRUQiLCJtb3VudHMiLCJkaXNwYXRjaCIsInJlc29sdmVXb3JrYm9va01vdW50Iiwib2siLCJsb2FkRG9jdW1lbnQiLCJmc1JlYWRlciIsInJvb3QiLCJtZW1vcnlSZWFkZXIiLCJmaWxlcyIsIndvcmtzaGVldFNvdXJjZXMiLCJzb3VyY2UiLCJlbmdpbmUiLCJBc3luY0VuZ2luZSIsImZyb21Tb3VyY2VzIiwicnVuIiwiYXV0aG9yc05hbWUiLCJhdXRob3JzVmlld05hbWUiLCJ0ZW1wbGF0ZSIsImNvbnN1bWVyVGVtcGxhdGUiLCJ0ZW1wbGF0ZXMiLCJwYXJzZVRlbXBsYXRlIiwiYXV0aG9yc0ZpbGUiLCJmaW5kIiwiYXV0aG9yc05vZGVzIiwiQVVUSE9SU19WSUVXX1NDQUZGT0xEIiwidGVtcGxhdGVEaWFnbm9zdGljcyIsImQiLCJ2YWxpZGF0ZVRlbXBsYXRlIiwicHVzaCIsInNldmVyaXR5IiwiZmlsZSIsIm1lc3NhZ2UiLCJjb21wb25lbnQiLCJleHRlcm5hbFJlZmVyZW5jZXMiLCJ0aXRsZSIsInNvdXJjZXMiLCJhdXRob3JzRnJvbURvY3VtZW50Iiwic2Vzc2lvbkJpbmRpbmdzIiwic2Vzc2lvbiIsIm9uQ2hhbmdlIiwic29tZSIsIm5zIiwic3RhcnRzV2l0aCIsIm1pc3NpbmciLCJzdGF0dXMiLCJlcnIiLCJlcnJvciIsInJlc3VsdCIsInNldFBhcmFtIiwicmVmIiwiZml4dHVyZVZhbHVlIiwiZnJvbSIsInBhdGNoIiwicGFyYW1TaGFkb3ciLCJ2IiwidXBkYXRlIl0sInNvdXJjZXMiOlsicmVwb3J0U2Vzc2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBTaGVsbCBCIGludGVncmF0aW9uICsgc2hlbGwgQyB3aXJpbmcgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnMi4xLCDCpzQsIMKnNykg4oCUIHRpZXMgdGhlIHB1cmUgc3BpbmVcbi8vIHRvIHRoZSByZW5kZXIgc3VyZmFjZTogbG9hZCBhIGRvY3VtZW50IOKGkiBydW4gdGhlICoqd29ya2VyLWJhY2tlZCoqIGVuZ2luZSDihpIgcGFyc2UgdGhlXG4vLyB0ZW1wbGF0ZSDihpIgaGFuZCB0aGUgcmVuZGVyZXIgYSBgQmluZGluZ3NgIGFkYXB0ZXIgb3ZlciB0aGUgZW5naW5lJ3MgcmVzdWx0cy5cbi8vXG4vLyBUaGUgZW5naW5lIGlzIG5vdyB0aGUgYEFzeW5jRW5naW5lYDogZm9ybXVsYSBleGVjdXRpb24gaGFwcGVucyBpbiBhIHRlcm1pbmFibGUsIGBsb2NrZG93bigpYC1lZFxuLy8gU0VTIFdlYiBXb3JrZXIgKGBzcmMvZW50cnkvZW5naW5lLnRzYCksIHNvIGEgcnVuYXdheSBmb3JtdWxhIGlzIGNvbnRhaW5lZCBieSB0aGUgaG9zdCB3YXRjaGRvZ1xuLy8gcmF0aGVyIHRoYW4gd2VkZ2luZyB0aGUgVUkgdGhyZWFkLiBXaGVyZSBhIHJlYWwgYFdvcmtlcmAgaXMgdW5hdmFpbGFibGUgKFNTUi90ZXN0cykgaXQgZmFsbHNcbi8vIGJhY2sgdG8gYW4gaW4tcHJvY2VzcyB0cmFuc3BvcnQg4oCUIHNhbWUgb3JjaGVzdHJhdGlvbiwgbWFpbi10aHJlYWQgZXhlY3V0aW9uLlxuLy9cbi8vIGBzZXNzaW9uQmluZGluZ3NgIGlzIHRoZSBlbmdpbmUgYWRhcHRlciB0aGUgcmVuZGVyZXIgcmVzb2x2ZXMgdGhyb3VnaCAodGhlIHJlbmRlciBzaWRlIGlzXG4vLyB1bml0LXRlc3RlZCBhZ2FpbnN0IGEgaGFuZC1idWlsdCBwb3J0LCBzbyB0aGlzIHN0YXlzIGEgdGhpbiBhZGFwdGVyKS4gUGFyYW1zIGNsb3NlIHRoZVxuLy8gaW50ZXJhY3Rpb24gbG9vcDogYSB3aWRnZXQgd3JpdGUgdXBkYXRlcyB0aGUgZXh0ZXJuYWwsIGNhbGxzIHRoZSBlbmdpbmUncyBhc3luYyBgdXBkYXRlYCwgYW5kXG4vLyByZS1yZW5kZXJzIHdoZW4gdGhlIHBhc3Mgc2V0dGxlcy5cblxuaW1wb3J0IHsgQXN5bmNFbmdpbmUgfSBmcm9tICcuLi9lbmdpbmUvYXN5bmNFbmdpbmUudHMnO1xuaW1wb3J0IHsgd29ya2VyVHJhbnNwb3J0LCBpbk1lbW9yeVRyYW5zcG9ydCB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXJUcmFuc3BvcnQudHMnO1xuaW1wb3J0IHR5cGUgeyBXb3JrZXJUcmFuc3BvcnQgfSBmcm9tICcuLi9lbmdpbmUvd29ya2VyVHJhbnNwb3J0LnRzJztcbmltcG9ydCB0eXBlIHsgRXh0ZXJuYWxWYWx1ZSB9IGZyb20gJy4uL2VuZ2luZS90eXBlcy50cyc7XG5pbXBvcnQgdHlwZSB7IFRpZXIgfSBmcm9tICcuLi9lbmdpbmUvdGllci50cyc7XG5pbXBvcnQgeyBsb2FkRG9jdW1lbnQgfSBmcm9tICcuLi9kb2N1bWVudC9sb2FkZXIudHMnO1xuaW1wb3J0IHsgdmFsaWRhdGVFeHRlcm5hbFJlZmVyZW5jZXMgfSBmcm9tICcuLi9kb2N1bWVudC94cmVmLnRzJztcbmltcG9ydCB0eXBlIHsgRXh0ZXJuYWxSZWZlcmVuY2UgfSBmcm9tICcuLi9kb2N1bWVudC94cmVmLnRzJztcbmltcG9ydCB0eXBlIHsgRG9jdW1lbnREaWFnbm9zdGljLCBMb2FkZWREb2N1bWVudCwgUGFyYW1SZWYgfSBmcm9tICcuLi9kb2N1bWVudC90eXBlcy50cyc7XG5pbXBvcnQgeyByZXNvbHZlUGFyYW1SZWZzLCBwYXJhbVNoYWRvdyB9IGZyb20gJy4uL2RvY3VtZW50L3BhcmFtUmVmcy50cyc7XG5pbXBvcnQgeyBSRUZMRUNUSU9OLCBXSURHRVRTIH0gZnJvbSAnLi4vcmVwb3J0L2NhdGFsb2cudHMnO1xuaW1wb3J0IHsgcGFyc2VUZW1wbGF0ZSB9IGZyb20gJy4uL3JlcG9ydC9wYXJzZS9tZHgudHMnO1xuaW1wb3J0IHsgdmFsaWRhdGVUZW1wbGF0ZSB9IGZyb20gJy4uL3JlcG9ydC92YWxpZGF0ZS50cyc7XG5pbXBvcnQgdHlwZSB7IFRlbXBsYXRlTm9kZSB9IGZyb20gJy4uL3JlcG9ydC9ub2Rlcy50cyc7XG5pbXBvcnQgeyBBVVRIT1JTX1ZJRVdfU0NBRkZPTEQsIGF1dGhvcnNWaWV3TmFtZSwgY29uc3VtZXJUZW1wbGF0ZSB9IGZyb20gJy4vYXV0aG9yc1ZpZXcudHMnO1xuaW1wb3J0IHsgbWlzc2luZyB9IGZyb20gJy4uL3JlcG9ydC9yZW5kZXIvYmluZGluZ3MudHMnO1xuaW1wb3J0IHR5cGUgeyBCaW5kaW5ncywgQm91bmRWYWx1ZSB9IGZyb20gJy4uL3JlcG9ydC9yZW5kZXIvYmluZGluZ3MudHMnO1xuaW1wb3J0IHR5cGUgeyBWYWx1ZSB9IGZyb20gJy4uL3N0ZGxpYi90eXBlcy50cyc7XG5pbXBvcnQgeyBtZW1vcnlSZWFkZXIgfSBmcm9tICcuL21lbW9yeVJlYWRlci50cyc7XG5pbXBvcnQgeyBmc1JlYWRlciB9IGZyb20gJy4uL2RvY3VtZW50L2ZzUmVhZGVyLnRzJztcbmltcG9ydCB7IHJlc29sdmVXb3JrYm9va01vdW50IH0gZnJvbSAnLi9kaXNwYXRjaC50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IE1FUklESUFOX1NFRUQsIHR5cGUgU2VlZERvY3VtZW50IH0gZnJvbSAnLi4vc2VlZC9zZWVkcy50cyc7XG5cbi8vIFJlLWV4cG9ydGVkIGZvciBleGlzdGluZyBpbXBvcnQgc2l0ZXMgKHRoZSBzZWVkcyB0aGVtc2VsdmVzIGxpdmUgaW4gc3JjL3NlZWQvc2VlZHMudHMpLlxuZXhwb3J0IHsgQ0FMREVSQV9TRUVELCBNRVJJRElBTl9TRUVEIH0gZnJvbSAnLi4vc2VlZC9zZWVkcy50cyc7XG5leHBvcnQgdHlwZSB7IFNlZWREb2N1bWVudCB9IGZyb20gJy4uL3NlZWQvc2VlZHMudHMnO1xuXG5jb25zdCBFWFRFUk5BTF9OQU1FU1BBQ0VTID0gWydmZWVkcy4nLCAnZml4dHVyZXMuJywgJ3N0YXRpYy4nLCAncGFyYW1zLiddO1xuY29uc3QgVElFUlM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnc3RhdGljJywgJ3B1bGxlZCcsICdsaXZlJ10pO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlcG9ydFNlc3Npb24ge1xuICBlbmdpbmU6IEFzeW5jRW5naW5lO1xuICAvKiogTGl2ZSBleHRlcm5hbCBpbnB1dHMgKGZpeHR1cmVzICsgcGFyYW1zKSwga2V5ZWQgYnkgZG90dGVkIGJpbmRpbmcgbmFtZS4gKi9cbiAgZXh0ZXJuYWxzOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPjtcbiAgLyoqIHBhcmFtUmVmcyBrbm9icyAoUjMtMzc3KTogbmFtZSDihpIgdGhlIGZpeHR1cmUgbGVhZiBhIHJ1bnRpbWUgd3JpdGUgc2hhZG93cy4gKi9cbiAgcGFyYW1SZWZzOiBSZWNvcmQ8c3RyaW5nLCBQYXJhbVJlZj47XG4gIG5vZGVzOiBUZW1wbGF0ZU5vZGVbXTtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGlhZ25vc3RpY3M6IERvY3VtZW50RGlhZ25vc3RpY1tdO1xuICAvKipcbiAgICogUmV0YWluZWQgZm9yIHNoYWRvdyBldmFsdWF0aW9uIChXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQyDCpzIuMik6IHRoZSB3b3Jrc2hlZXRcbiAgICogc291cmNlcyB0aGUgZW5naW5lIHdhcyBidWlsdCBmcm9tICh0aGUgc3BsaWNlIHN1YnN0cmF0ZSksIHRoZSBsb2FkZWQgZG9jdW1lbnQgYW5kIHRoZVxuICAgKiBydW50aW1lLWZlZWQgbmFtZXMgKHRoZSBjcm9zcy1yZWZlcmVuY2UgdW5pdmVyc2UgdGhlIHNoYWRvdyBidWlsZCByZS12YWxpZGF0ZXNcbiAgICogYWdhaW5zdCwgRy1XSUYtMTApLlxuICAgKi9cbiAgc291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgbG9hZGVkOiBMb2FkZWREb2N1bWVudDtcbiAgcnVudGltZUZlZWRzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFRoZSBhdXRob3Incy12aWV3IG5vZGUgdHJlZSAoQVVUSE9SU19WSUVXX1NQRUMgwqczLjUpOiB0aGUgZG9jdW1lbnQncyBvd25cbiAgICogYXV0aG9yJ3MtdmlldyB0ZW1wbGF0ZSB3aGVuIGl0IGNhcnJpZXMgb25lLCBlbHNlIHRoZSBidWlsdC1pbiBzY2FmZm9sZCDigJQgbmV2ZXJcbiAgICogc2VydmVkIGFzIHRoZSBjb25zdW1lciByZXBvcnQgKMKnNCkuXG4gICAqL1xuICBhdXRob3JzTm9kZXM6IFRlbXBsYXRlTm9kZVtdO1xuICAvKiogVHJ1ZSB3aGVuIGBhdXRob3JzTm9kZXNgIGNhbWUgZnJvbSBhIGRvY3VtZW50IGZpbGUgKGFuIGF1dGhvciB0b29rIG93bmVyc2hpcCkuICovXG4gIGF1dGhvcnNGcm9tRG9jdW1lbnQ6IGJvb2xlYW47XG59XG5cbmZ1bmN0aW9uIG5vcm1UaWVyKHRhZzogc3RyaW5nIHwgdW5kZWZpbmVkKTogVGllciB7XG4gIHJldHVybiB0YWcgIT09IHVuZGVmaW5lZCAmJiBUSUVSUy5oYXModGFnKSA/ICh0YWcgYXMgVGllcikgOiAnc3RhdGljJztcbn1cblxuLyoqIEFzc2VtYmxlIHRoZSBlbmdpbmUncyBleHRlcm5hbHMgZnJvbSB0aGUgZG9jdW1lbnQncyBmaXh0dXJlcyArIG1hbmlmZXN0IHBhcmFtIGRlZmF1bHRzICsgcGFyYW1SZWZzIGtub2JzIChSMy0zNzcpLiBFeHBvcnRlZCBmb3IgdGhlIGNhc2Utc3R1ZHkgaGFybmVzczsgdGhlIGFwcCB3aXJlcyBpdCB2aWEge0BsaW5rIGJ1aWxkUmVwb3J0U2Vzc2lvbn0uICovXG5leHBvcnQgZnVuY3Rpb24gYXNzZW1ibGVFeHRlcm5hbHMobG9hZGVkOiBMb2FkZWREb2N1bWVudCk6IHtcbiAgZXh0ZXJuYWxzOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPjtcbiAgcGFyYW1SZWZzOiBSZWNvcmQ8c3RyaW5nLCBQYXJhbVJlZj47XG59IHtcbiAgY29uc3QgZXh0ZXJuYWxzOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPiA9IHt9O1xuICBmb3IgKGNvbnN0IGZ4IG9mIGxvYWRlZC5maXh0dXJlcykge1xuICAgIGV4dGVybmFsc1tgZml4dHVyZXMuJHtmeC5uYW1lfWBdID0geyB2YWx1ZTogZnguZnJhbWUucm93cyBhcyBWYWx1ZSwgdGllcjogbm9ybVRpZXIoZnguZnJhbWUudGllcikgfTtcbiAgfVxuICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMobG9hZGVkLm1hbmlmZXN0LnBhcmFtcykpIHtcbiAgICBleHRlcm5hbHNbYHBhcmFtcy4ke25hbWV9YF0gPSB7IHZhbHVlLCB0aWVyOiAnc3RhdGljJyB9O1xuICB9XG4gIC8vIEFzc3VtcHRpb25zLWFzLXBhcmFtczogZWFjaCBrbm9iJ3MgZGVmYXVsdCBpcyByZWFkIGZyb20gaXRzIGZpeHR1cmUgbGVhZiBhbmQgYWxzb1xuICAvLyBwdWJsaXNoZWQgYXMgYHBhcmFtcy48bmFtZT5gIChmb3IgdGVtcGxhdGUgYmluZGluZyArIHRoZSBwYXJhbXMgc3VyZmFjZSkuXG4gIGNvbnN0IHsgZGVmYXVsdHMsIHJlZnMsIGRpYWdub3N0aWNzIH0gPSByZXNvbHZlUGFyYW1SZWZzKGxvYWRlZC5tYW5pZmVzdC5wYXJhbVJlZnMsIGxvYWRlZC5maXh0dXJlcyk7XG4gIGZvciAoY29uc3QgW2tleSwgZXh0XSBvZiBPYmplY3QuZW50cmllcyhkZWZhdWx0cykpIHtcbiAgICBpZiAoZXh0ZXJuYWxzW2tleV0gPT09IHVuZGVmaW5lZCkgZXh0ZXJuYWxzW2tleV0gPSB7IHZhbHVlOiBleHQudmFsdWUsIHRpZXI6IGV4dC50aWVyIH07XG4gIH1cbiAgdm9pZCBkaWFnbm9zdGljczsgLy8gYWxyZWFkeSBzdXJmYWNlZCBieSB0aGUgbG9hZGVyJ3MgcGFyYW1SZWZEaWFnbm9zdGljc1xuICByZXR1cm4geyBleHRlcm5hbHMsIHBhcmFtUmVmczogcmVmcyB9O1xufVxuXG4vKipcbiAqIFRoZSBlbmdpbmUncyB3b3JrZXIgdHJhbnNwb3J0OiBhIHJlYWwgbW9kdWxlIFdlYiBXb3JrZXIgKG9mZi1tYWluLXRocmVhZCwgYGxvY2tkb3duKClgLWVkKVxuICogdW5kZXIgcmVhbCBtb2R1bGUgc2VtYW50aWNzIChgdml0ZWAgZGV2ICsgYnVpbGQpLCBlbHNlIHRoZSBpbi1wcm9jZXNzIGZhbGxiYWNrLlxuICpcbiAqIFRoZSB3b3JrZXIncyBVUkwgbGl2ZXMgaW4gYC4vd29ya2VyVXJsLnRzYCBiZWhpbmQgYGltcG9ydC5tZXRhLnVybGAg4oCUIGEgd2ViIHN0YW5kYXJkLCBidXRcbiAqIG9uZSBpbW1lZGlhdGVseS5ydW4gY2Fubm90IHlldCBldmFsdWF0ZTogdGhlIHBsYXRmb3JtIHRyYW5zcGlsZXMgYXBwIHNvdXJjZSBFU03ihpJDb21tb25KU1xuICogYW5kIHJ1bnMgaXQgYXMgYSBjbGFzc2ljIHNjcmlwdCwgd2hlcmUgYGltcG9ydC5tZXRhYCBpcyBhICoqcGFyc2UtdGltZSoqIFN5bnRheEVycm9yLiBUaGF0XG4gKiBtb2R1bGUgaXMgdGhlcmVmb3JlIHJlYWNoZWQgb25seSB2aWEgYSBkeW5hbWljIGBpbXBvcnQoKWAgaW5zaWRlIHRoaXMgdHJ5L2NhdGNoLCBzbyBvbiB0aGVcbiAqIHBsYXRmb3JtIHRoZSBmYWlsdXJlIGlzICpjYXRjaGFibGUqIGFuZCB0aGUgaW4tcHJvY2VzcyB0cmFuc3BvcnQgdGFrZXMgb3ZlciAoc2FtZSBlbmdpbmUsXG4gKiBtYWluLXRocmVhZCkgaW5zdGVhZCBvZiB0aGUgd2hvbGUgYXBwIGR5aW5nIGF0IG1vZHVsZSBsb2FkLiBXaGVuIHRoZSBwbGF0Zm9ybSBsZWFybnNcbiAqIGBpbXBvcnQubWV0YS51cmxgIChyb2FkbWFwOiB0aGUgc2FuZGJveCB0cmFuc3BpbGVyIHNoaW0pLCBub3RoaW5nIGhlcmUgbmVlZHMgdG8gY2hhbmdlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFrZVRyYW5zcG9ydChcbiAgbG9hZFdvcmtlclVybDogKCkgPT4gUHJvbWlzZTx7IEVOR0lORV9XT1JLRVJfVVJMOiBVUkwgfT4gPSAoKSA9PiBpbXBvcnQoJy4vd29ya2VyVXJsLnRzJyksXG4pOiBQcm9taXNlPFdvcmtlclRyYW5zcG9ydD4ge1xuICBpZiAodHlwZW9mIFdvcmtlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBFTkdJTkVfV09SS0VSX1VSTCB9ID0gYXdhaXQgbG9hZFdvcmtlclVybCgpO1xuICAgICAgcmV0dXJuIHdvcmtlclRyYW5zcG9ydCgoKSA9PiBuZXcgV29ya2VyKEVOR0lORV9XT1JLRVJfVVJMLCB7IHR5cGU6ICdtb2R1bGUnIH0pKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIGNsYXNzaWMtc2NyaXB0IHNlbWFudGljcyAoaW1tZWRpYXRlbHkucnVuKSDigJQgZmFsbCB0aHJvdWdoIHRvIHRoZSBpbi1wcm9jZXNzIHRyYW5zcG9ydCAqL1xuICAgIH1cbiAgfVxuICByZXR1cm4gaW5NZW1vcnlUcmFuc3BvcnQoKTtcbn1cblxuLyoqIFRoZSBwYXJhbSBuYW1lcyB0aGUgdGVtcGxhdGUncyBpbnB1dCB3aWRnZXRzIGNhbiBzZXQgKGEgYG5hbWVgZCB3aWRnZXQgZGVjbGFyZXMgb25lKS4gKi9cbmZ1bmN0aW9uIHdpZGdldFBhcmFtTmFtZXMobm9kZXM6IHJlYWRvbmx5IFRlbXBsYXRlTm9kZVtdKTogU2V0PHN0cmluZz4ge1xuICBjb25zdCBuYW1lcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCB3YWxrID0gKGxpc3Q6IHJlYWRvbmx5IFRlbXBsYXRlTm9kZVtdKTogdm9pZCA9PiB7XG4gICAgZm9yIChjb25zdCBuIG9mIGxpc3QpIHtcbiAgICAgIGlmIChuLnR5cGUgPT09ICdjb21wb25lbnQnKSB7XG4gICAgICAgIGlmIChXSURHRVRTLmhhcyhuLm5hbWUpICYmIG4uYXR0cnMubmFtZT8ua2luZCA9PT0gJ2xpdGVyYWwnICYmIHR5cGVvZiBuLmF0dHJzLm5hbWUudmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgbmFtZXMuYWRkKG4uYXR0cnMubmFtZS52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgd2FsayhuLmNoaWxkcmVuKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHdhbGsobm9kZXMpO1xuICByZXR1cm4gbmFtZXM7XG59XG5cbi8qKiBSZWZsZWN0aW9uIGNvbXBvbmVudCBuYW1lcyB1c2VkIGluIGEgbm9kZSB0cmVlIChBVVRIT1JTX1ZJRVdfU1BFQyDCpzYncyBjb25zdW1lci10ZW1wbGF0ZSBkaWFnbm9zdGljKS4gKi9cbmZ1bmN0aW9uIHJlZmxlY3Rpb25Db21wb25lbnROYW1lcyhub2RlczogcmVhZG9ubHkgVGVtcGxhdGVOb2RlW10pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGZvdW5kID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHdhbGsgPSAobGlzdDogcmVhZG9ubHkgVGVtcGxhdGVOb2RlW10pOiB2b2lkID0+IHtcbiAgICBmb3IgKGNvbnN0IG4gb2YgbGlzdCkge1xuICAgICAgaWYgKG4udHlwZSA9PT0gJ2NvbXBvbmVudCcpIHtcbiAgICAgICAgaWYgKFJFRkxFQ1RJT04uaGFzKG4ubmFtZSkpIGZvdW5kLmFkZChuLm5hbWUpO1xuICAgICAgICB3YWxrKG4uY2hpbGRyZW4pO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgd2Fsayhub2Rlcyk7XG4gIHJldHVybiBbLi4uZm91bmRdO1xufVxuXG4vKipcbiAqIENyb3NzLXJlZmVyZW5jZSBkaWFnbm9zdGljcyBmb3IgYSBsb2FkZWQgZG9jdW1lbnQgKyB0aGUgd29ya2Jvb2sgdGhlIGVuZ2luZSBidWlsdCBmcm9tXG4gKiBpdDogZXZlcnkgd29ya3NoZWV0IGV4dGVybmFsIGNoZWNrZWQgYWdhaW5zdCB3aGF0IHRoZSBkb2N1bWVudCAoYW5kIHRoZSBydW5uaW5nIGFwcClcbiAqIGNhbiBzdXBwbHkuIEV4cG9ydGVkIGZvciB1bml0IHRlc3RzOyBgYnVpbGRSZXBvcnRTZXNzaW9uYCB3aXJlcyBpdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHhyZWZEaWFnbm9zdGljcyhcbiAgbG9hZGVkOiBMb2FkZWREb2N1bWVudCxcbiAgcmVmZXJlbmNlczogcmVhZG9ubHkgRXh0ZXJuYWxSZWZlcmVuY2VbXSxcbiAgbm9kZXM6IHJlYWRvbmx5IFRlbXBsYXRlTm9kZVtdLFxuICBydW50aW1lRmVlZHM6IHJlYWRvbmx5IHN0cmluZ1tdID0gW10sXG4pOiBEb2N1bWVudERpYWdub3N0aWNbXSB7XG4gIHJldHVybiB2YWxpZGF0ZUV4dGVybmFsUmVmZXJlbmNlcyhyZWZlcmVuY2VzLCB7XG4gICAgZmVlZHM6IG5ldyBTZXQoWy4uLmxvYWRlZC5mZWVkcy5tYXAoKGYpID0+IGYubmFtZSksIC4uLnJ1bnRpbWVGZWVkc10pLFxuICAgIGZpeHR1cmVzOiBuZXcgU2V0KGxvYWRlZC5maXh0dXJlcy5tYXAoKGYpID0+IGYubmFtZSkpLFxuICAgIHBhcmFtczogbmV3IFNldChbXG4gICAgICAuLi5PYmplY3Qua2V5cyhsb2FkZWQubWFuaWZlc3QucGFyYW1zKSxcbiAgICAgIC4uLk9iamVjdC5rZXlzKGxvYWRlZC5tYW5pZmVzdC5wYXJhbVJlZnMgPz8ge30pLFxuICAgICAgLi4ud2lkZ2V0UGFyYW1OYW1lcyhub2RlcyksXG4gICAgXSksXG4gICAgd29ya3NoZWV0UGF0aHM6IE9iamVjdC5mcm9tRW50cmllcyhsb2FkZWQud29ya3NoZWV0cy5tYXAoKHcpID0+IFt3Lm5hbWUsIHcucGF0aF0pKSxcbiAgfSk7XG59XG5cbi8qKiBMb2FkIGEgYnVuZGxlZCBkb2N1bWVudCBhbmQgcnVuIHRoZSBmdWxsIGNvbGQgcGlwZWxpbmUgdGhyb3VnaCB0aGUgd29ya2VyIGVuZ2luZS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidWlsZFJlcG9ydFNlc3Npb24oXG4gIHRyYW5zcG9ydD86IFdvcmtlclRyYW5zcG9ydCxcbiAgc2VlZDogU2VlZERvY3VtZW50ID0gTUVSSURJQU5fU0VFRCxcbiAgbW91bnRzOiByZWFkb25seSBTYW5kYm94TW91bnRbXSA9IFtdLFxuKTogUHJvbWlzZTxSZXBvcnRTZXNzaW9uPiB7XG4gIGNvbnN0IHQgPSB0cmFuc3BvcnQgPz8gKGF3YWl0IG1ha2VUcmFuc3BvcnQoKSk7XG5cbiAgLy8gVGhlIGRpc3BhdGNoZWQgZmxvdyBmaXJzdDogYSB3b3JrYm9vayByZXBvIHRoYXQgYXJyaXZlZCBhcyBhIGNvbnRlbnQgbW91bnRcbiAgLy8gKFIzLTE3MiByZXBvLWxvYWQgZGlzcGF0Y2gpIGlzIHJlYWQgZnJvbSB0aGUgZmlsZXN5c3RlbSDigJQgcGxhaW4gZmlsZXMsIHRoZSBzYW1lXG4gIC8vIGBsb2FkRG9jdW1lbnRgIHBpcGVsaW5lIGFzIHRoZSBzZWVkLCBubyBjb3B5IGVtYmVkZGVkIGluIHRoaXMgYXBwLiBBYnNlbnQgYVxuICAvLyBkaXNwYXRjaGVkIG1vdW50LCB0aGUgYnVuZGxlZCBzZWVkIGRvY3VtZW50IChvcHRpb25hbGx5IGA/ZG9jPWAtc2VsZWN0ZWQpLlxuICBjb25zdCBkaXNwYXRjaCA9IHJlc29sdmVXb3JrYm9va01vdW50KG1vdW50cyk7XG4gIGNvbnN0IGxvYWRlZCA9XG4gICAgZGlzcGF0Y2gub2tcbiAgICAgID8gYXdhaXQgbG9hZERvY3VtZW50KGZzUmVhZGVyKCksIGRpc3BhdGNoLnJvb3QpXG4gICAgICA6IGF3YWl0IGxvYWREb2N1bWVudChtZW1vcnlSZWFkZXIoc2VlZC5maWxlcyksIHNlZWQucm9vdCk7XG5cbiAgY29uc3Qgd29ya3NoZWV0U291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICBmb3IgKGNvbnN0IHcgb2YgbG9hZGVkLndvcmtzaGVldHMpIHdvcmtzaGVldFNvdXJjZXNbdy5uYW1lXSA9IHcuc291cmNlO1xuXG4gIGNvbnN0IGVuZ2luZSA9IGF3YWl0IEFzeW5jRW5naW5lLmZyb21Tb3VyY2VzKHdvcmtzaGVldFNvdXJjZXMsIHsgdHJhbnNwb3J0OiB0IH0pO1xuICBjb25zdCB7IGV4dGVybmFscywgcGFyYW1SZWZzIH0gPSBhc3NlbWJsZUV4dGVybmFscyhsb2FkZWQpO1xuICBhd2FpdCBlbmdpbmUucnVuKGV4dGVybmFscyk7XG5cbiAgLy8gVGVtcGxhdGUgcm9sZXMgKEFVVEhPUlNfVklFV19TUEVDIMKnNCk6IHRoZSBhdXRob3Incy12aWV3IHRlbXBsYXRlIOKAlCBtYW5pZmVzdC1uYW1lZFxuICAvLyBvciB0aGUgcmVzZXJ2ZWQgYGF1dGhvcnNfdmlld2Ag4oCUIGlzIGV4Y2x1ZGVkIGZyb20gY29uc3VtZXItcmVwb3J0IHNlbGVjdGlvbjsgdGhlXG4gIC8vIGNvbnN1bWVyIHBpY2sgb3RoZXJ3aXNlIGtlZXBzIHRoZSBleGlzdGluZyBgd2Vla2x5YCBndWVzcy4gQWJzZW50IGFuIGF1dGhvcidzLXZpZXdcbiAgLy8gZmlsZSwgdGhlIGJ1aWx0LWluIHNjYWZmb2xkIGlzIHRoZSBkZWZhdWx0IHZpZXcgKMKnMS4xKS5cbiAgY29uc3QgYXV0aG9yc05hbWUgPSBhdXRob3JzVmlld05hbWUobG9hZGVkKTtcbiAgY29uc3QgdGVtcGxhdGUgPSBjb25zdW1lclRlbXBsYXRlKGxvYWRlZC50ZW1wbGF0ZXMsIGF1dGhvcnNOYW1lKTtcbiAgY29uc3Qgbm9kZXMgPSB0ZW1wbGF0ZSA9PT0gdW5kZWZpbmVkID8gW10gOiBwYXJzZVRlbXBsYXRlKHRlbXBsYXRlLnNvdXJjZSk7XG4gIGNvbnN0IGF1dGhvcnNGaWxlID0gbG9hZGVkLnRlbXBsYXRlcy5maW5kKCh0KSA9PiB0Lm5hbWUgPT09IGF1dGhvcnNOYW1lKTtcbiAgY29uc3QgYXV0aG9yc05vZGVzID0gcGFyc2VUZW1wbGF0ZShhdXRob3JzRmlsZT8uc291cmNlID8/IEFVVEhPUlNfVklFV19TQ0FGRk9MRCk7XG5cbiAgLy8gQm90aCB0cmVlcyB2YWxpZGF0ZSBhZ2FpbnN0IHRoZSBjYXRhbG9nLCBkaWFnbm9zdGljcyBhdHRyaWJ1dGVkIHBlciBmaWxlICjCpzMuNSkg4oCUXG4gIC8vIGFuZCBhIHJlZmxlY3Rpb24gY29tcG9uZW50IGluIGEgQ09OU1VNRVIgdGVtcGxhdGUgaXMgZmxhZ2dlZCAowqc2KTogdGhlIHBvcnQgaXNcbiAgLy8gd2l0aGhlbGQgdGhlcmUsIHNvIGl0IHdvdWxkIHJlbmRlciB0aGUgYXV0aG9yJ3Mtdmlldy1vbmx5IHRpbGUuXG4gIGNvbnN0IHRlbXBsYXRlRGlhZ25vc3RpY3M6IERvY3VtZW50RGlhZ25vc3RpY1tdID0gW107XG4gIGlmICh0ZW1wbGF0ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZm9yIChjb25zdCBkIG9mIHZhbGlkYXRlVGVtcGxhdGUobm9kZXMpLmRpYWdub3N0aWNzKSB7XG4gICAgICB0ZW1wbGF0ZURpYWdub3N0aWNzLnB1c2goeyBzZXZlcml0eTogZC5zZXZlcml0eSwgZmlsZTogdGVtcGxhdGUucGF0aCwgbWVzc2FnZTogYCR7ZC5jb21wb25lbnR9OiAke2QubWVzc2FnZX1gIH0pO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IG5hbWUgb2YgcmVmbGVjdGlvbkNvbXBvbmVudE5hbWVzKG5vZGVzKSkge1xuICAgICAgdGVtcGxhdGVEaWFnbm9zdGljcy5wdXNoKHtcbiAgICAgICAgc2V2ZXJpdHk6ICd3YXJuaW5nJyxcbiAgICAgICAgZmlsZTogdGVtcGxhdGUucGF0aCxcbiAgICAgICAgbWVzc2FnZTogYDwke25hbWV9PiBpcyBhbiBhdXRob3Incy12aWV3IGNvbXBvbmVudDsgaW4gdGhlIHJlcG9ydCBpdCByZW5kZXJzIGFzIHVuYXZhaWxhYmxlLmAsXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgaWYgKGF1dGhvcnNGaWxlICE9PSB1bmRlZmluZWQpIHtcbiAgICBmb3IgKGNvbnN0IGQgb2YgdmFsaWRhdGVUZW1wbGF0ZShhdXRob3JzTm9kZXMpLmRpYWdub3N0aWNzKSB7XG4gICAgICB0ZW1wbGF0ZURpYWdub3N0aWNzLnB1c2goeyBzZXZlcml0eTogZC5zZXZlcml0eSwgZmlsZTogYXV0aG9yc0ZpbGUucGF0aCwgbWVzc2FnZTogYCR7ZC5jb21wb25lbnR9OiAke2QubWVzc2FnZX1gIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8vIENyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uOiBhIGJ1bmRsZWQgc2VlZCByZWFkcyBubyBhcHAtc3VwcGxpZWQgcnVudGltZSBmZWVkXG4gIC8vIChSMy03NjgpLCBzbyB0aGUgZmVlZCB1bml2ZXJzZSBhIG1vdW50ZWQvZGlzcGF0Y2hlZCB3b3JrYm9vayBzZWVzIGlzIGl0cyBvd24g4oCUXG4gIC8vIHRoZSBkZWNsYXJlZCBgZmVlZHMvKi5mZWVkLmpzb25gIHNldCDigJQgYW5kIGEgYnVuZGxlZCBzZWVkJ3MgaXMgZW1wdHkuXG4gIGNvbnN0IHJ1bnRpbWVGZWVkczogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgZGlhZ25vc3RpY3MgPSBbXG4gICAgLi4ubG9hZGVkLmRpYWdub3N0aWNzLFxuICAgIC4uLnRlbXBsYXRlRGlhZ25vc3RpY3MsXG4gICAgLy8gVGhlIHBhcmFtcyB1bml2ZXJzZSBzcGFucyBCT1RIIHRyZWVzICjCpzMuNSk6IGEgd2lkZ2V0IGFuIGF1dGhvciBwbGFjZXMgaW4gYVxuICAgIC8vIGN1c3RvbSBhdXRob3IncyB2aWV3IHJlc29sdmVzIHJhdGhlciB0aGFuIGZhbHNlLWZsYWdnaW5nLlxuICAgIC4uLnhyZWZEaWFnbm9zdGljcyhsb2FkZWQsIGVuZ2luZS5leHRlcm5hbFJlZmVyZW5jZXMoKSwgWy4uLm5vZGVzLCAuLi5hdXRob3JzTm9kZXNdLCBydW50aW1lRmVlZHMpLFxuICBdO1xuXG4gIHJldHVybiB7XG4gICAgZW5naW5lLFxuICAgIGV4dGVybmFscyxcbiAgICBwYXJhbVJlZnMsXG4gICAgbm9kZXMsXG4gICAgdGl0bGU6IGxvYWRlZC5tYW5pZmVzdC50aXRsZSA/PyAnUmVja29uZXIgcmVwb3J0JyxcbiAgICBkaWFnbm9zdGljcyxcbiAgICBzb3VyY2VzOiB3b3Jrc2hlZXRTb3VyY2VzLFxuICAgIGxvYWRlZCxcbiAgICBydW50aW1lRmVlZHMsXG4gICAgYXV0aG9yc05vZGVzLFxuICAgIGF1dGhvcnNGcm9tRG9jdW1lbnQ6IGF1dGhvcnNGaWxlICE9PSB1bmRlZmluZWQsXG4gIH07XG59XG5cbi8qKiBUaGUgZW5naW5lIGFkYXB0ZXIgdGhlIHJlbmRlcmVyIHJlc29sdmVzIGBzb3VyY2VgIGJpbmRpbmdzIHRocm91Z2guICovXG5leHBvcnQgZnVuY3Rpb24gc2Vzc2lvbkJpbmRpbmdzKHNlc3Npb246IFJlcG9ydFNlc3Npb24sIG9uQ2hhbmdlOiAoKSA9PiB2b2lkKTogQmluZGluZ3Mge1xuICByZXR1cm4ge1xuICAgIHJlc29sdmUoc291cmNlKTogQm91bmRWYWx1ZSB7XG4gICAgICBpZiAoRVhURVJOQUxfTkFNRVNQQUNFUy5zb21lKChucykgPT4gc291cmNlLnN0YXJ0c1dpdGgobnMpKSkge1xuICAgICAgICBjb25zdCBleHQgPSBzZXNzaW9uLmV4dGVybmFsc1tzb3VyY2VdO1xuICAgICAgICByZXR1cm4gZXh0ID09PSB1bmRlZmluZWQgPyBtaXNzaW5nKHNvdXJjZSkgOiB7IHZhbHVlOiBleHQudmFsdWUsIHRpZXI6IGV4dC50aWVyLCBzdGF0dXM6ICdvaycgfTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGVyciA9IHNlc3Npb24uZW5naW5lLmVycm9yKHNvdXJjZSk7XG4gICAgICBpZiAoZXJyICE9PSB1bmRlZmluZWQpIHJldHVybiB7IHZhbHVlOiBudWxsLCB0aWVyOiAnbGl2ZScsIHN0YXR1czogJ2Vycm9yJywgbWVzc2FnZTogZXJyIH07XG4gICAgICBjb25zdCByZXN1bHQgPSBzZXNzaW9uLmVuZ2luZS5yZXN1bHQoc291cmNlKTtcbiAgICAgIHJldHVybiByZXN1bHQgPT09IHVuZGVmaW5lZCA/IG1pc3Npbmcoc291cmNlKSA6IHsgdmFsdWU6IHJlc3VsdC52YWx1ZSwgdGllcjogcmVzdWx0LnRpZXIsIHN0YXR1czogJ29rJyB9O1xuICAgIH0sXG4gICAgc2V0UGFyYW0obmFtZSwgdmFsdWUpIHtcbiAgICAgIC8vIEEgcGFyYW1SZWZzIGtub2IgKFIzLTM3Nykgc2hhZG93cyBpdHMgbGVhZiBJTlNJREUgdGhlIGZpeHR1cmUgdmFsdWUg4oCUIG9uZVxuICAgICAgLy8gY29oZXJlbnQgZnJvemVuIHNuYXBzaG90IGZvciB0aGUgZm9ybXVsYXMsIHJpZGluZyB0aGUgZXhpc3RpbmcgZXh0ZXJuYWxzIHBhdGgsXG4gICAgICAvLyBzbyBleGFjdGx5IHRoZSBjZWxscyB0aGF0IGRlY2xhcmVkIHRoYXQgZml4dHVyZSByZWNvbXB1dGUuXG4gICAgICBjb25zdCByZWYgPSBzZXNzaW9uLnBhcmFtUmVmc1tuYW1lXTtcbiAgICAgIGlmIChyZWYgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zdCBmaXh0dXJlVmFsdWUgPSBzZXNzaW9uLmV4dGVybmFsc1tyZWYuZnJvbV0/LnZhbHVlO1xuICAgICAgICBpZiAoZml4dHVyZVZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBjb25zdCBwYXRjaCA9IHBhcmFtU2hhZG93KG5hbWUsIHZhbHVlLCByZWYsIGZpeHR1cmVWYWx1ZSk7XG4gICAgICAgICAgZm9yIChjb25zdCBba2V5LCB7IHZhbHVlOiB2IH1dIG9mIE9iamVjdC5lbnRyaWVzKHBhdGNoKSkge1xuICAgICAgICAgICAgc2Vzc2lvbi5leHRlcm5hbHNba2V5XSA9IHsgdmFsdWU6IHYsIHRpZXI6ICdzdGF0aWMnIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHZvaWQgc2Vzc2lvbi5lbmdpbmUudXBkYXRlKHBhdGNoIGFzIFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+KS50aGVuKG9uQ2hhbmdlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IGtleSA9IGBwYXJhbXMuJHtuYW1lfWA7XG4gICAgICBjb25zdCBleHQ6IEV4dGVybmFsVmFsdWUgPSB7IHZhbHVlLCB0aWVyOiAnc3RhdGljJyB9O1xuICAgICAgc2Vzc2lvbi5leHRlcm5hbHNba2V5XSA9IGV4dDtcbiAgICAgIC8vIFRoZSBlbmdpbmUgcmVjb21wdXRlcyBvZmYgdGhlIG1haW4gdGhyZWFkOyByZS1yZW5kZXIgd2hlbiB0aGUgcGFzcyBzZXR0bGVzLlxuICAgICAgdm9pZCBzZXNzaW9uLmVuZ2luZS51cGRhdGUoeyBba2V5XTogZXh0IH0pLnRoZW4ob25DaGFuZ2UpO1xuICAgIH0sXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFjQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxnQkFBQSxHQUFBRCxPQUFBO0FBSUEsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsS0FBQSxHQUFBSCxPQUFBO0FBR0EsSUFBQUksVUFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssUUFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sSUFBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8sU0FBQSxHQUFBUCxPQUFBO0FBRUEsSUFBQVEsWUFBQSxHQUFBUixPQUFBO0FBQ0EsSUFBQVMsU0FBQSxHQUFBVCxPQUFBO0FBR0EsSUFBQVUsYUFBQSxHQUFBVixPQUFBO0FBQ0EsSUFBQVcsU0FBQSxHQUFBWCxPQUFBO0FBQ0EsSUFBQVksU0FBQSxHQUFBWixPQUFBO0FBRUEsSUFBQWEsTUFBQSxHQUFBYixPQUFBO0FBQW9FLFNBQUFjLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFJLHdCQUFBSixDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUssVUFBQSxTQUFBTCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQU0sT0FBQSxFQUFBTixDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLFVBQUFHLENBQUEsQ0FBQUssR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTixDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZ0IsR0FBQSxDQUFBbkIsQ0FBQSxFQUFBUyxDQUFBLEdBQUFBLENBQUEsSUFwQ3BFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBMEJBO0FBSUEsTUFBTVcsbUJBQW1CLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUM7QUFDekUsTUFBTUMsS0FBMEIsR0FBRyxJQUFJQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBOEJ4RSxTQUFTQyxRQUFRQSxDQUFDQyxHQUF1QixFQUFRO0VBQy9DLE9BQU9BLEdBQUcsS0FBS0MsU0FBUyxJQUFJSixLQUFLLENBQUNkLEdBQUcsQ0FBQ2lCLEdBQUcsQ0FBQyxHQUFJQSxHQUFHLEdBQVksUUFBUTtBQUN2RTs7QUFFQTtBQUNPLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsTUFBc0IsRUFHdEQ7RUFDQSxNQUFNQyxTQUF3QyxHQUFHLENBQUMsQ0FBQztFQUNuRCxLQUFLLE1BQU1DLEVBQUUsSUFBSUYsTUFBTSxDQUFDRyxRQUFRLEVBQUU7SUFDaENGLFNBQVMsQ0FBQyxZQUFZQyxFQUFFLENBQUNFLElBQUksRUFBRSxDQUFDLEdBQUc7TUFBRUMsS0FBSyxFQUFFSCxFQUFFLENBQUNJLEtBQUssQ0FBQ0MsSUFBYTtNQUFFQyxJQUFJLEVBQUVaLFFBQVEsQ0FBQ00sRUFBRSxDQUFDSSxLQUFLLENBQUNFLElBQUk7SUFBRSxDQUFDO0VBQ3JHO0VBQ0EsS0FBSyxNQUFNLENBQUNKLElBQUksRUFBRUMsS0FBSyxDQUFDLElBQUlwQixNQUFNLENBQUN3QixPQUFPLENBQUNULE1BQU0sQ0FBQ1UsUUFBUSxDQUFDQyxNQUFNLENBQUMsRUFBRTtJQUNsRVYsU0FBUyxDQUFDLFVBQVVHLElBQUksRUFBRSxDQUFDLEdBQUc7TUFBRUMsS0FBSztNQUFFRyxJQUFJLEVBQUU7SUFBUyxDQUFDO0VBQ3pEO0VBQ0E7RUFDQTtFQUNBLE1BQU07SUFBRUksUUFBUTtJQUFFQyxJQUFJO0lBQUVDO0VBQVksQ0FBQyxHQUFHLElBQUFDLDJCQUFnQixFQUFDZixNQUFNLENBQUNVLFFBQVEsQ0FBQ00sU0FBUyxFQUFFaEIsTUFBTSxDQUFDRyxRQUFRLENBQUM7RUFDcEcsS0FBSyxNQUFNLENBQUNjLEdBQUcsRUFBRUMsR0FBRyxDQUFDLElBQUlqQyxNQUFNLENBQUN3QixPQUFPLENBQUNHLFFBQVEsQ0FBQyxFQUFFO0lBQ2pELElBQUlYLFNBQVMsQ0FBQ2dCLEdBQUcsQ0FBQyxLQUFLbkIsU0FBUyxFQUFFRyxTQUFTLENBQUNnQixHQUFHLENBQUMsR0FBRztNQUFFWixLQUFLLEVBQUVhLEdBQUcsQ0FBQ2IsS0FBSztNQUFFRyxJQUFJLEVBQUVVLEdBQUcsQ0FBQ1Y7SUFBSyxDQUFDO0VBQ3pGO0VBQ0EsS0FBS00sV0FBVyxDQUFDLENBQUM7RUFDbEIsT0FBTztJQUFFYixTQUFTO0lBQUVlLFNBQVMsRUFBRUg7RUFBSyxDQUFDO0FBQ3ZDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVNLGFBQWFBLENBQ2pDQyxhQUF3RCxHQUFHQSxDQUFBLEtBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUE5Qyx1QkFBQSxDQUFBbkIsT0FBQSxDQUFhLGdCQUFnQixHQUFDLEVBQy9EO0VBQzFCLElBQUksT0FBT2tFLE1BQU0sS0FBSyxXQUFXLEVBQUU7SUFDakMsSUFBSTtNQUNGLE1BQU07UUFBRUM7TUFBa0IsQ0FBQyxHQUFHLE1BQU1MLGFBQWEsQ0FBQyxDQUFDO01BQ25ELE9BQU8sSUFBQU0sZ0NBQWUsRUFBQyxNQUFNLElBQUlGLE1BQU0sQ0FBQ0MsaUJBQWlCLEVBQUU7UUFBRUUsSUFBSSxFQUFFO01BQVMsQ0FBQyxDQUFDLENBQUM7SUFDakYsQ0FBQyxDQUFDLE1BQU07TUFDTjtJQUFBO0VBRUo7RUFDQSxPQUFPLElBQUFDLGtDQUFpQixFQUFDLENBQUM7QUFDNUI7O0FBRUE7QUFDQSxTQUFTQyxnQkFBZ0JBLENBQUNDLEtBQThCLEVBQWU7RUFDckUsTUFBTUMsS0FBSyxHQUFHLElBQUlwQyxHQUFHLENBQVMsQ0FBQztFQUMvQixNQUFNcUMsSUFBSSxHQUFJQyxJQUE2QixJQUFXO0lBQ3BELEtBQUssTUFBTW5ELENBQUMsSUFBSW1ELElBQUksRUFBRTtNQUNwQixJQUFJbkQsQ0FBQyxDQUFDNkMsSUFBSSxLQUFLLFdBQVcsRUFBRTtRQUMxQixJQUFJTyxnQkFBTyxDQUFDdEQsR0FBRyxDQUFDRSxDQUFDLENBQUNzQixJQUFJLENBQUMsSUFBSXRCLENBQUMsQ0FBQ3FELEtBQUssQ0FBQy9CLElBQUksRUFBRWdDLElBQUksS0FBSyxTQUFTLElBQUksT0FBT3RELENBQUMsQ0FBQ3FELEtBQUssQ0FBQy9CLElBQUksQ0FBQ0MsS0FBSyxLQUFLLFFBQVEsRUFBRTtVQUNyRzBCLEtBQUssQ0FBQ00sR0FBRyxDQUFDdkQsQ0FBQyxDQUFDcUQsS0FBSyxDQUFDL0IsSUFBSSxDQUFDQyxLQUFLLENBQUM7UUFDL0I7UUFDQTJCLElBQUksQ0FBQ2xELENBQUMsQ0FBQ3dELFFBQVEsQ0FBQztNQUNsQjtJQUNGO0VBQ0YsQ0FBQztFQUNETixJQUFJLENBQUNGLEtBQUssQ0FBQztFQUNYLE9BQU9DLEtBQUs7QUFDZDs7QUFFQTtBQUNBLFNBQVNRLHdCQUF3QkEsQ0FBQ1QsS0FBOEIsRUFBWTtFQUMxRSxNQUFNVSxLQUFLLEdBQUcsSUFBSTdDLEdBQUcsQ0FBUyxDQUFDO0VBQy9CLE1BQU1xQyxJQUFJLEdBQUlDLElBQTZCLElBQVc7SUFDcEQsS0FBSyxNQUFNbkQsQ0FBQyxJQUFJbUQsSUFBSSxFQUFFO01BQ3BCLElBQUluRCxDQUFDLENBQUM2QyxJQUFJLEtBQUssV0FBVyxFQUFFO1FBQzFCLElBQUljLG1CQUFVLENBQUM3RCxHQUFHLENBQUNFLENBQUMsQ0FBQ3NCLElBQUksQ0FBQyxFQUFFb0MsS0FBSyxDQUFDSCxHQUFHLENBQUN2RCxDQUFDLENBQUNzQixJQUFJLENBQUM7UUFDN0M0QixJQUFJLENBQUNsRCxDQUFDLENBQUN3RCxRQUFRLENBQUM7TUFDbEI7SUFDRjtFQUNGLENBQUM7RUFDRE4sSUFBSSxDQUFDRixLQUFLLENBQUM7RUFDWCxPQUFPLENBQUMsR0FBR1UsS0FBSyxDQUFDO0FBQ25COztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTRSxlQUFlQSxDQUM3QjFDLE1BQXNCLEVBQ3RCMkMsVUFBd0MsRUFDeENiLEtBQThCLEVBQzlCYyxZQUErQixHQUFHLEVBQUUsRUFDZDtFQUN0QixPQUFPLElBQUFDLGdDQUEwQixFQUFDRixVQUFVLEVBQUU7SUFDNUNHLEtBQUssRUFBRSxJQUFJbkQsR0FBRyxDQUFDLENBQUMsR0FBR0ssTUFBTSxDQUFDOEMsS0FBSyxDQUFDQyxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDNUMsSUFBSSxDQUFDLEVBQUUsR0FBR3dDLFlBQVksQ0FBQyxDQUFDO0lBQ3JFekMsUUFBUSxFQUFFLElBQUlSLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDRyxRQUFRLENBQUM0QyxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDNUMsSUFBSSxDQUFDLENBQUM7SUFDckRPLE1BQU0sRUFBRSxJQUFJaEIsR0FBRyxDQUFDLENBQ2QsR0FBR1YsTUFBTSxDQUFDZ0UsSUFBSSxDQUFDakQsTUFBTSxDQUFDVSxRQUFRLENBQUNDLE1BQU0sQ0FBQyxFQUN0QyxHQUFHMUIsTUFBTSxDQUFDZ0UsSUFBSSxDQUFDakQsTUFBTSxDQUFDVSxRQUFRLENBQUNNLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUMvQyxHQUFHYSxnQkFBZ0IsQ0FBQ0MsS0FBSyxDQUFDLENBQzNCLENBQUM7SUFDRm9CLGNBQWMsRUFBRWpFLE1BQU0sQ0FBQ2tFLFdBQVcsQ0FBQ25ELE1BQU0sQ0FBQ29ELFVBQVUsQ0FBQ0wsR0FBRyxDQUFFTSxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDakQsSUFBSSxFQUFFaUQsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQztFQUNuRixDQUFDLENBQUM7QUFDSjs7QUFFQTtBQUNPLGVBQWVDLGtCQUFrQkEsQ0FDdENDLFNBQTJCLEVBQzNCQyxJQUFrQixHQUFHQyxvQkFBYSxFQUNsQ0MsTUFBK0IsR0FBRyxFQUFFLEVBQ1o7RUFDeEIsTUFBTW5GLENBQUMsR0FBR2dGLFNBQVMsS0FBSyxNQUFNckMsYUFBYSxDQUFDLENBQUMsQ0FBQzs7RUFFOUM7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNeUMsUUFBUSxHQUFHLElBQUFDLDhCQUFvQixFQUFDRixNQUFNLENBQUM7RUFDN0MsTUFBTTNELE1BQU0sR0FDVjRELFFBQVEsQ0FBQ0UsRUFBRSxHQUNQLE1BQU0sSUFBQUMsb0JBQVksRUFBQyxJQUFBQyxrQkFBUSxFQUFDLENBQUMsRUFBRUosUUFBUSxDQUFDSyxJQUFJLENBQUMsR0FDN0MsTUFBTSxJQUFBRixvQkFBWSxFQUFDLElBQUFHLDBCQUFZLEVBQUNULElBQUksQ0FBQ1UsS0FBSyxDQUFDLEVBQUVWLElBQUksQ0FBQ1EsSUFBSSxDQUFDO0VBRTdELE1BQU1HLGdCQUF3QyxHQUFHLENBQUMsQ0FBQztFQUNuRCxLQUFLLE1BQU1mLENBQUMsSUFBSXJELE1BQU0sQ0FBQ29ELFVBQVUsRUFBRWdCLGdCQUFnQixDQUFDZixDQUFDLENBQUNqRCxJQUFJLENBQUMsR0FBR2lELENBQUMsQ0FBQ2dCLE1BQU07RUFFdEUsTUFBTUMsTUFBTSxHQUFHLE1BQU1DLHdCQUFXLENBQUNDLFdBQVcsQ0FBQ0osZ0JBQWdCLEVBQUU7SUFBRVosU0FBUyxFQUFFaEY7RUFBRSxDQUFDLENBQUM7RUFDaEYsTUFBTTtJQUFFeUIsU0FBUztJQUFFZTtFQUFVLENBQUMsR0FBR2pCLGlCQUFpQixDQUFDQyxNQUFNLENBQUM7RUFDMUQsTUFBTXNFLE1BQU0sQ0FBQ0csR0FBRyxDQUFDeEUsU0FBUyxDQUFDOztFQUUzQjtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU15RSxXQUFXLEdBQUcsSUFBQUMsNEJBQWUsRUFBQzNFLE1BQU0sQ0FBQztFQUMzQyxNQUFNNEUsUUFBUSxHQUFHLElBQUFDLDZCQUFnQixFQUFDN0UsTUFBTSxDQUFDOEUsU0FBUyxFQUFFSixXQUFXLENBQUM7RUFDaEUsTUFBTTVDLEtBQUssR0FBRzhDLFFBQVEsS0FBSzlFLFNBQVMsR0FBRyxFQUFFLEdBQUcsSUFBQWlGLGtCQUFhLEVBQUNILFFBQVEsQ0FBQ1AsTUFBTSxDQUFDO0VBQzFFLE1BQU1XLFdBQVcsR0FBR2hGLE1BQU0sQ0FBQzhFLFNBQVMsQ0FBQ0csSUFBSSxDQUFFekcsQ0FBQyxJQUFLQSxDQUFDLENBQUM0QixJQUFJLEtBQUtzRSxXQUFXLENBQUM7RUFDeEUsTUFBTVEsWUFBWSxHQUFHLElBQUFILGtCQUFhLEVBQUNDLFdBQVcsRUFBRVgsTUFBTSxJQUFJYyxrQ0FBcUIsQ0FBQzs7RUFFaEY7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsbUJBQXlDLEdBQUcsRUFBRTtFQUNwRCxJQUFJUixRQUFRLEtBQUs5RSxTQUFTLEVBQUU7SUFDMUIsS0FBSyxNQUFNdUYsQ0FBQyxJQUFJLElBQUFDLDBCQUFnQixFQUFDeEQsS0FBSyxDQUFDLENBQUNoQixXQUFXLEVBQUU7TUFDbkRzRSxtQkFBbUIsQ0FBQ0csSUFBSSxDQUFDO1FBQUVDLFFBQVEsRUFBRUgsQ0FBQyxDQUFDRyxRQUFRO1FBQUVDLElBQUksRUFBRWIsUUFBUSxDQUFDdEIsSUFBSTtRQUFFb0MsT0FBTyxFQUFFLEdBQUdMLENBQUMsQ0FBQ00sU0FBUyxLQUFLTixDQUFDLENBQUNLLE9BQU87TUFBRyxDQUFDLENBQUM7SUFDbEg7SUFDQSxLQUFLLE1BQU10RixJQUFJLElBQUltQyx3QkFBd0IsQ0FBQ1QsS0FBSyxDQUFDLEVBQUU7TUFDbERzRCxtQkFBbUIsQ0FBQ0csSUFBSSxDQUFDO1FBQ3ZCQyxRQUFRLEVBQUUsU0FBUztRQUNuQkMsSUFBSSxFQUFFYixRQUFRLENBQUN0QixJQUFJO1FBQ25Cb0MsT0FBTyxFQUFFLElBQUl0RixJQUFJO01BQ25CLENBQUMsQ0FBQztJQUNKO0VBQ0Y7RUFDQSxJQUFJNEUsV0FBVyxLQUFLbEYsU0FBUyxFQUFFO0lBQzdCLEtBQUssTUFBTXVGLENBQUMsSUFBSSxJQUFBQywwQkFBZ0IsRUFBQ0osWUFBWSxDQUFDLENBQUNwRSxXQUFXLEVBQUU7TUFDMURzRSxtQkFBbUIsQ0FBQ0csSUFBSSxDQUFDO1FBQUVDLFFBQVEsRUFBRUgsQ0FBQyxDQUFDRyxRQUFRO1FBQUVDLElBQUksRUFBRVQsV0FBVyxDQUFDMUIsSUFBSTtRQUFFb0MsT0FBTyxFQUFFLEdBQUdMLENBQUMsQ0FBQ00sU0FBUyxLQUFLTixDQUFDLENBQUNLLE9BQU87TUFBRyxDQUFDLENBQUM7SUFDckg7RUFDRjs7RUFFQTtFQUNBO0VBQ0E7RUFDQSxNQUFNOUMsWUFBc0IsR0FBRyxFQUFFO0VBQ2pDLE1BQU05QixXQUFXLEdBQUcsQ0FDbEIsR0FBR2QsTUFBTSxDQUFDYyxXQUFXLEVBQ3JCLEdBQUdzRSxtQkFBbUI7RUFDdEI7RUFDQTtFQUNBLEdBQUcxQyxlQUFlLENBQUMxQyxNQUFNLEVBQUVzRSxNQUFNLENBQUNzQixrQkFBa0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHOUQsS0FBSyxFQUFFLEdBQUdvRCxZQUFZLENBQUMsRUFBRXRDLFlBQVksQ0FBQyxDQUNuRztFQUVELE9BQU87SUFDTDBCLE1BQU07SUFDTnJFLFNBQVM7SUFDVGUsU0FBUztJQUNUYyxLQUFLO0lBQ0wrRCxLQUFLLEVBQUU3RixNQUFNLENBQUNVLFFBQVEsQ0FBQ21GLEtBQUssSUFBSSxpQkFBaUI7SUFDakQvRSxXQUFXO0lBQ1hnRixPQUFPLEVBQUUxQixnQkFBZ0I7SUFDekJwRSxNQUFNO0lBQ040QyxZQUFZO0lBQ1pzQyxZQUFZO0lBQ1phLG1CQUFtQixFQUFFZixXQUFXLEtBQUtsRjtFQUN2QyxDQUFDO0FBQ0g7O0FBRUE7QUFDTyxTQUFTa0csZUFBZUEsQ0FBQ0MsT0FBc0IsRUFBRUMsUUFBb0IsRUFBWTtFQUN0RixPQUFPO0lBQ0w1RSxPQUFPQSxDQUFDK0MsTUFBTSxFQUFjO01BQzFCLElBQUk1RSxtQkFBbUIsQ0FBQzBHLElBQUksQ0FBRUMsRUFBRSxJQUFLL0IsTUFBTSxDQUFDZ0MsVUFBVSxDQUFDRCxFQUFFLENBQUMsQ0FBQyxFQUFFO1FBQzNELE1BQU1sRixHQUFHLEdBQUcrRSxPQUFPLENBQUNoRyxTQUFTLENBQUNvRSxNQUFNLENBQUM7UUFDckMsT0FBT25ELEdBQUcsS0FBS3BCLFNBQVMsR0FBRyxJQUFBd0csaUJBQU8sRUFBQ2pDLE1BQU0sQ0FBQyxHQUFHO1VBQUVoRSxLQUFLLEVBQUVhLEdBQUcsQ0FBQ2IsS0FBSztVQUFFRyxJQUFJLEVBQUVVLEdBQUcsQ0FBQ1YsSUFBSTtVQUFFK0YsTUFBTSxFQUFFO1FBQUssQ0FBQztNQUNqRztNQUNBLE1BQU1DLEdBQUcsR0FBR1AsT0FBTyxDQUFDM0IsTUFBTSxDQUFDbUMsS0FBSyxDQUFDcEMsTUFBTSxDQUFDO01BQ3hDLElBQUltQyxHQUFHLEtBQUsxRyxTQUFTLEVBQUUsT0FBTztRQUFFTyxLQUFLLEVBQUUsSUFBSTtRQUFFRyxJQUFJLEVBQUUsTUFBTTtRQUFFK0YsTUFBTSxFQUFFLE9BQU87UUFBRWIsT0FBTyxFQUFFYztNQUFJLENBQUM7TUFDMUYsTUFBTUUsTUFBTSxHQUFHVCxPQUFPLENBQUMzQixNQUFNLENBQUNvQyxNQUFNLENBQUNyQyxNQUFNLENBQUM7TUFDNUMsT0FBT3FDLE1BQU0sS0FBSzVHLFNBQVMsR0FBRyxJQUFBd0csaUJBQU8sRUFBQ2pDLE1BQU0sQ0FBQyxHQUFHO1FBQUVoRSxLQUFLLEVBQUVxRyxNQUFNLENBQUNyRyxLQUFLO1FBQUVHLElBQUksRUFBRWtHLE1BQU0sQ0FBQ2xHLElBQUk7UUFBRStGLE1BQU0sRUFBRTtNQUFLLENBQUM7SUFDMUcsQ0FBQztJQUNESSxRQUFRQSxDQUFDdkcsSUFBSSxFQUFFQyxLQUFLLEVBQUU7TUFDcEI7TUFDQTtNQUNBO01BQ0EsTUFBTXVHLEdBQUcsR0FBR1gsT0FBTyxDQUFDakYsU0FBUyxDQUFDWixJQUFJLENBQUM7TUFDbkMsSUFBSXdHLEdBQUcsS0FBSzlHLFNBQVMsRUFBRTtRQUNyQixNQUFNK0csWUFBWSxHQUFHWixPQUFPLENBQUNoRyxTQUFTLENBQUMyRyxHQUFHLENBQUNFLElBQUksQ0FBQyxFQUFFekcsS0FBSztRQUN2RCxJQUFJd0csWUFBWSxLQUFLL0csU0FBUyxFQUFFO1VBQzlCLE1BQU1pSCxLQUFLLEdBQUcsSUFBQUMsc0JBQVcsRUFBQzVHLElBQUksRUFBRUMsS0FBSyxFQUFFdUcsR0FBRyxFQUFFQyxZQUFZLENBQUM7VUFDekQsS0FBSyxNQUFNLENBQUM1RixHQUFHLEVBQUU7WUFBRVosS0FBSyxFQUFFNEc7VUFBRSxDQUFDLENBQUMsSUFBSWhJLE1BQU0sQ0FBQ3dCLE9BQU8sQ0FBQ3NHLEtBQUssQ0FBQyxFQUFFO1lBQ3ZEZCxPQUFPLENBQUNoRyxTQUFTLENBQUNnQixHQUFHLENBQUMsR0FBRztjQUFFWixLQUFLLEVBQUU0RyxDQUFDO2NBQUV6RyxJQUFJLEVBQUU7WUFBUyxDQUFDO1VBQ3ZEO1VBQ0EsS0FBS3lGLE9BQU8sQ0FBQzNCLE1BQU0sQ0FBQzRDLE1BQU0sQ0FBQ0gsS0FBc0MsQ0FBQyxDQUFDeEYsSUFBSSxDQUFDMkUsUUFBUSxDQUFDO1VBQ2pGO1FBQ0Y7TUFDRjtNQUNBLE1BQU1qRixHQUFHLEdBQUcsVUFBVWIsSUFBSSxFQUFFO01BQzVCLE1BQU1jLEdBQWtCLEdBQUc7UUFBRWIsS0FBSztRQUFFRyxJQUFJLEVBQUU7TUFBUyxDQUFDO01BQ3BEeUYsT0FBTyxDQUFDaEcsU0FBUyxDQUFDZ0IsR0FBRyxDQUFDLEdBQUdDLEdBQUc7TUFDNUI7TUFDQSxLQUFLK0UsT0FBTyxDQUFDM0IsTUFBTSxDQUFDNEMsTUFBTSxDQUFDO1FBQUUsQ0FBQ2pHLEdBQUcsR0FBR0M7TUFBSSxDQUFDLENBQUMsQ0FBQ0ssSUFBSSxDQUFDMkUsUUFBUSxDQUFDO0lBQzNEO0VBQ0YsQ0FBQztBQUNIIiwiaWdub3JlTGlzdCI6W119