"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.densityFor = densityFor;
exports.useContainerSize = useContainerSize;
exports.useContainerWidth = useContainerWidth;
exports.useDpr = useDpr;
var _react = require("react");
// Measure a container's own width via `ResizeObserver` for component-level semantic reflow
// (§3.3.1 point 2/3 — a component adapts to *its allotted width*, not the viewport). Returns
// a ref to attach and the measured width; before first measure (and under SSR/static render
// where there is no `ResizeObserver`) it reports the `initial` width so the component renders
// its wide default. Resize is a pure view op — this never touches the engine (resize ≠
// recompute, §3.3.1).

function useContainerWidth(initial = 720) {
  const ref = (0, _react.useRef)(null);
  const [width, setWidth] = (0, _react.useState)(initial);
  (0, _react.useEffect)(() => {
    const el = ref.current;
    if (el === null || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(entries => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        if (w > 0) setWidth(w);
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return {
    ref,
    width
  };
}

/** Density level for a chart's adaptation ladder (§3.3.1 point 3): wide → medium → narrow. */
function densityFor(width) {
  if (width < 360) return 'narrow';
  if (width < 560) return 'medium';
  return 'wide';
}

/** Like {@link useContainerWidth} but tracks both dimensions (for ShowAbove/ShowBelow height). */
function useContainerSize(initial = {
  width: 720,
  height: 480
}) {
  const ref = (0, _react.useRef)(null);
  const [size, setSize] = (0, _react.useState)(initial);
  (0, _react.useEffect)(() => {
    const el = ref.current;
    if (el === null || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(entries => {
      for (const entry of entries) {
        const {
          width,
          height
        } = entry.contentRect;
        if (width > 0 || height > 0) setSize({
          width,
          height
        });
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return {
    ref,
    width: size.width,
    height: size.height
  };
}

/**
 * The device pixel ratio, updated as it changes (zoom, moving between displays), via a
 * `matchMedia` resolution query (§3.3.1 point 4). SSR/static render reports 1.
 */
function useDpr() {
  const [dpr, setDpr] = (0, _react.useState)(() => typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1);
  (0, _react.useEffect)(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return;
    let mql = null;
    const update = () => {
      const next = window.devicePixelRatio || 1;
      setDpr(next);
      // Re-arm at the new ratio so the next change fires (a matchMedia query is a point test).
      mql?.removeEventListener('change', update);
      mql = window.matchMedia(`(resolution: ${next}dppx)`);
      mql.addEventListener('change', update);
    };
    update();
    return () => mql?.removeEventListener('change', update);
  }, []);
  return dpr;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwidXNlQ29udGFpbmVyV2lkdGgiLCJpbml0aWFsIiwicmVmIiwidXNlUmVmIiwid2lkdGgiLCJzZXRXaWR0aCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiZWwiLCJjdXJyZW50IiwiUmVzaXplT2JzZXJ2ZXIiLCJybyIsImVudHJpZXMiLCJlbnRyeSIsInciLCJjb250ZW50UmVjdCIsIm9ic2VydmUiLCJkaXNjb25uZWN0IiwiZGVuc2l0eUZvciIsInVzZUNvbnRhaW5lclNpemUiLCJoZWlnaHQiLCJzaXplIiwic2V0U2l6ZSIsInVzZURwciIsImRwciIsInNldERwciIsIndpbmRvdyIsImRldmljZVBpeGVsUmF0aW8iLCJtYXRjaE1lZGlhIiwibXFsIiwidXBkYXRlIiwibmV4dCIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJhZGRFdmVudExpc3RlbmVyIl0sInNvdXJjZXMiOlsidXNlQ29udGFpbmVyV2lkdGgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTWVhc3VyZSBhIGNvbnRhaW5lcidzIG93biB3aWR0aCB2aWEgYFJlc2l6ZU9ic2VydmVyYCBmb3IgY29tcG9uZW50LWxldmVsIHNlbWFudGljIHJlZmxvd1xuLy8gKMKnMy4zLjEgcG9pbnQgMi8zIOKAlCBhIGNvbXBvbmVudCBhZGFwdHMgdG8gKml0cyBhbGxvdHRlZCB3aWR0aCosIG5vdCB0aGUgdmlld3BvcnQpLiBSZXR1cm5zXG4vLyBhIHJlZiB0byBhdHRhY2ggYW5kIHRoZSBtZWFzdXJlZCB3aWR0aDsgYmVmb3JlIGZpcnN0IG1lYXN1cmUgKGFuZCB1bmRlciBTU1Ivc3RhdGljIHJlbmRlclxuLy8gd2hlcmUgdGhlcmUgaXMgbm8gYFJlc2l6ZU9ic2VydmVyYCkgaXQgcmVwb3J0cyB0aGUgYGluaXRpYWxgIHdpZHRoIHNvIHRoZSBjb21wb25lbnQgcmVuZGVyc1xuLy8gaXRzIHdpZGUgZGVmYXVsdC4gUmVzaXplIGlzIGEgcHVyZSB2aWV3IG9wIOKAlCB0aGlzIG5ldmVyIHRvdWNoZXMgdGhlIGVuZ2luZSAocmVzaXplIOKJoFxuLy8gcmVjb21wdXRlLCDCpzMuMy4xKS5cblxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ29udGFpbmVyV2lkdGgoaW5pdGlhbCA9IDcyMCk6IHsgcmVmOiBSZWFjdC5SZWZPYmplY3Q8SFRNTERpdkVsZW1lbnQgfCBudWxsPjsgd2lkdGg6IG51bWJlciB9IHtcbiAgY29uc3QgcmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt3aWR0aCwgc2V0V2lkdGhdID0gdXNlU3RhdGUoaW5pdGlhbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBlbCA9IHJlZi5jdXJyZW50O1xuICAgIGlmIChlbCA9PT0gbnVsbCB8fCB0eXBlb2YgUmVzaXplT2JzZXJ2ZXIgPT09ICd1bmRlZmluZWQnKSByZXR1cm47XG4gICAgY29uc3Qgcm8gPSBuZXcgUmVzaXplT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICBjb25zdCB3ID0gZW50cnkuY29udGVudFJlY3Qud2lkdGg7XG4gICAgICAgIGlmICh3ID4gMCkgc2V0V2lkdGgodyk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcm8ub2JzZXJ2ZShlbCk7XG4gICAgcmV0dXJuICgpID0+IHJvLmRpc2Nvbm5lY3QoKTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiB7IHJlZiwgd2lkdGggfTtcbn1cblxuLyoqIERlbnNpdHkgbGV2ZWwgZm9yIGEgY2hhcnQncyBhZGFwdGF0aW9uIGxhZGRlciAowqczLjMuMSBwb2ludCAzKTogd2lkZSDihpIgbWVkaXVtIOKGkiBuYXJyb3cuICovXG5leHBvcnQgZnVuY3Rpb24gZGVuc2l0eUZvcih3aWR0aDogbnVtYmVyKTogJ3dpZGUnIHwgJ21lZGl1bScgfCAnbmFycm93JyB7XG4gIGlmICh3aWR0aCA8IDM2MCkgcmV0dXJuICduYXJyb3cnO1xuICBpZiAod2lkdGggPCA1NjApIHJldHVybiAnbWVkaXVtJztcbiAgcmV0dXJuICd3aWRlJztcbn1cblxuLyoqIExpa2Uge0BsaW5rIHVzZUNvbnRhaW5lcldpZHRofSBidXQgdHJhY2tzIGJvdGggZGltZW5zaW9ucyAoZm9yIFNob3dBYm92ZS9TaG93QmVsb3cgaGVpZ2h0KS4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VDb250YWluZXJTaXplKFxuICBpbml0aWFsOiB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0gPSB7IHdpZHRoOiA3MjAsIGhlaWdodDogNDgwIH0sXG4pOiB7IHJlZjogUmVhY3QuUmVmT2JqZWN0PEhUTUxEaXZFbGVtZW50IHwgbnVsbD47IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0ge1xuICBjb25zdCByZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NpemUsIHNldFNpemVdID0gdXNlU3RhdGUoaW5pdGlhbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBlbCA9IHJlZi5jdXJyZW50O1xuICAgIGlmIChlbCA9PT0gbnVsbCB8fCB0eXBlb2YgUmVzaXplT2JzZXJ2ZXIgPT09ICd1bmRlZmluZWQnKSByZXR1cm47XG4gICAgY29uc3Qgcm8gPSBuZXcgUmVzaXplT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQgfSA9IGVudHJ5LmNvbnRlbnRSZWN0O1xuICAgICAgICBpZiAod2lkdGggPiAwIHx8IGhlaWdodCA+IDApIHNldFNpemUoeyB3aWR0aCwgaGVpZ2h0IH0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJvLm9ic2VydmUoZWwpO1xuICAgIHJldHVybiAoKSA9PiByby5kaXNjb25uZWN0KCk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4geyByZWYsIHdpZHRoOiBzaXplLndpZHRoLCBoZWlnaHQ6IHNpemUuaGVpZ2h0IH07XG59XG5cbi8qKlxuICogVGhlIGRldmljZSBwaXhlbCByYXRpbywgdXBkYXRlZCBhcyBpdCBjaGFuZ2VzICh6b29tLCBtb3ZpbmcgYmV0d2VlbiBkaXNwbGF5cyksIHZpYSBhXG4gKiBgbWF0Y2hNZWRpYWAgcmVzb2x1dGlvbiBxdWVyeSAowqczLjMuMSBwb2ludCA0KS4gU1NSL3N0YXRpYyByZW5kZXIgcmVwb3J0cyAxLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRHByKCk6IG51bWJlciB7XG4gIGNvbnN0IFtkcHIsIHNldERwcl0gPSB1c2VTdGF0ZSgoKSA9PiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbyB8fCAxIDogMSkpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiB3aW5kb3cubWF0Y2hNZWRpYSAhPT0gJ2Z1bmN0aW9uJykgcmV0dXJuO1xuICAgIGxldCBtcWw6IE1lZGlhUXVlcnlMaXN0IHwgbnVsbCA9IG51bGw7XG4gICAgY29uc3QgdXBkYXRlID0gKCk6IHZvaWQgPT4ge1xuICAgICAgY29uc3QgbmV4dCA9IHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvIHx8IDE7XG4gICAgICBzZXREcHIobmV4dCk7XG4gICAgICAvLyBSZS1hcm0gYXQgdGhlIG5ldyByYXRpbyBzbyB0aGUgbmV4dCBjaGFuZ2UgZmlyZXMgKGEgbWF0Y2hNZWRpYSBxdWVyeSBpcyBhIHBvaW50IHRlc3QpLlxuICAgICAgbXFsPy5yZW1vdmVFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB1cGRhdGUpO1xuICAgICAgbXFsID0gd2luZG93Lm1hdGNoTWVkaWEoYChyZXNvbHV0aW9uOiAke25leHR9ZHBweClgKTtcbiAgICAgIG1xbC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB1cGRhdGUpO1xuICAgIH07XG4gICAgdXBkYXRlKCk7XG4gICAgcmV0dXJuICgpID0+IG1xbD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgdXBkYXRlKTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiBkcHI7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQU9BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQVBBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJTyxTQUFTQyxpQkFBaUJBLENBQUNDLE9BQU8sR0FBRyxHQUFHLEVBQWtFO0VBQy9HLE1BQU1DLEdBQUcsR0FBRyxJQUFBQyxhQUFNLEVBQXdCLElBQUksQ0FBQztFQUMvQyxNQUFNLENBQUNDLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDTCxPQUFPLENBQUM7RUFFM0MsSUFBQU0sZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTUMsRUFBRSxHQUFHTixHQUFHLENBQUNPLE9BQU87SUFDdEIsSUFBSUQsRUFBRSxLQUFLLElBQUksSUFBSSxPQUFPRSxjQUFjLEtBQUssV0FBVyxFQUFFO0lBQzFELE1BQU1DLEVBQUUsR0FBRyxJQUFJRCxjQUFjLENBQUVFLE9BQU8sSUFBSztNQUN6QyxLQUFLLE1BQU1DLEtBQUssSUFBSUQsT0FBTyxFQUFFO1FBQzNCLE1BQU1FLENBQUMsR0FBR0QsS0FBSyxDQUFDRSxXQUFXLENBQUNYLEtBQUs7UUFDakMsSUFBSVUsQ0FBQyxHQUFHLENBQUMsRUFBRVQsUUFBUSxDQUFDUyxDQUFDLENBQUM7TUFDeEI7SUFDRixDQUFDLENBQUM7SUFDRkgsRUFBRSxDQUFDSyxPQUFPLENBQUNSLEVBQUUsQ0FBQztJQUNkLE9BQU8sTUFBTUcsRUFBRSxDQUFDTSxVQUFVLENBQUMsQ0FBQztFQUM5QixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sT0FBTztJQUFFZixHQUFHO0lBQUVFO0VBQU0sQ0FBQztBQUN2Qjs7QUFFQTtBQUNPLFNBQVNjLFVBQVVBLENBQUNkLEtBQWEsRUFBZ0M7RUFDdEUsSUFBSUEsS0FBSyxHQUFHLEdBQUcsRUFBRSxPQUFPLFFBQVE7RUFDaEMsSUFBSUEsS0FBSyxHQUFHLEdBQUcsRUFBRSxPQUFPLFFBQVE7RUFDaEMsT0FBTyxNQUFNO0FBQ2Y7O0FBRUE7QUFDTyxTQUFTZSxnQkFBZ0JBLENBQzlCbEIsT0FBMEMsR0FBRztFQUFFRyxLQUFLLEVBQUUsR0FBRztFQUFFZ0IsTUFBTSxFQUFFO0FBQUksQ0FBQyxFQUNRO0VBQ2hGLE1BQU1sQixHQUFHLEdBQUcsSUFBQUMsYUFBTSxFQUF3QixJQUFJLENBQUM7RUFDL0MsTUFBTSxDQUFDa0IsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBaEIsZUFBUSxFQUFDTCxPQUFPLENBQUM7RUFFekMsSUFBQU0sZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTUMsRUFBRSxHQUFHTixHQUFHLENBQUNPLE9BQU87SUFDdEIsSUFBSUQsRUFBRSxLQUFLLElBQUksSUFBSSxPQUFPRSxjQUFjLEtBQUssV0FBVyxFQUFFO0lBQzFELE1BQU1DLEVBQUUsR0FBRyxJQUFJRCxjQUFjLENBQUVFLE9BQU8sSUFBSztNQUN6QyxLQUFLLE1BQU1DLEtBQUssSUFBSUQsT0FBTyxFQUFFO1FBQzNCLE1BQU07VUFBRVIsS0FBSztVQUFFZ0I7UUFBTyxDQUFDLEdBQUdQLEtBQUssQ0FBQ0UsV0FBVztRQUMzQyxJQUFJWCxLQUFLLEdBQUcsQ0FBQyxJQUFJZ0IsTUFBTSxHQUFHLENBQUMsRUFBRUUsT0FBTyxDQUFDO1VBQUVsQixLQUFLO1VBQUVnQjtRQUFPLENBQUMsQ0FBQztNQUN6RDtJQUNGLENBQUMsQ0FBQztJQUNGVCxFQUFFLENBQUNLLE9BQU8sQ0FBQ1IsRUFBRSxDQUFDO0lBQ2QsT0FBTyxNQUFNRyxFQUFFLENBQUNNLFVBQVUsQ0FBQyxDQUFDO0VBQzlCLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixPQUFPO0lBQUVmLEdBQUc7SUFBRUUsS0FBSyxFQUFFaUIsSUFBSSxDQUFDakIsS0FBSztJQUFFZ0IsTUFBTSxFQUFFQyxJQUFJLENBQUNEO0VBQU8sQ0FBQztBQUN4RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNHLE1BQU1BLENBQUEsRUFBVztFQUMvQixNQUFNLENBQUNDLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQW5CLGVBQVEsRUFBQyxNQUFPLE9BQU9vQixNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLENBQUNDLGdCQUFnQixJQUFJLENBQUMsR0FBRyxDQUFFLENBQUM7RUFFeEcsSUFBQXBCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksT0FBT21CLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBT0EsTUFBTSxDQUFDRSxVQUFVLEtBQUssVUFBVSxFQUFFO0lBQzlFLElBQUlDLEdBQTBCLEdBQUcsSUFBSTtJQUNyQyxNQUFNQyxNQUFNLEdBQUdBLENBQUEsS0FBWTtNQUN6QixNQUFNQyxJQUFJLEdBQUdMLE1BQU0sQ0FBQ0MsZ0JBQWdCLElBQUksQ0FBQztNQUN6Q0YsTUFBTSxDQUFDTSxJQUFJLENBQUM7TUFDWjtNQUNBRixHQUFHLEVBQUVHLG1CQUFtQixDQUFDLFFBQVEsRUFBRUYsTUFBTSxDQUFDO01BQzFDRCxHQUFHLEdBQUdILE1BQU0sQ0FBQ0UsVUFBVSxDQUFDLGdCQUFnQkcsSUFBSSxPQUFPLENBQUM7TUFDcERGLEdBQUcsQ0FBQ0ksZ0JBQWdCLENBQUMsUUFBUSxFQUFFSCxNQUFNLENBQUM7SUFDeEMsQ0FBQztJQUNEQSxNQUFNLENBQUMsQ0FBQztJQUNSLE9BQU8sTUFBTUQsR0FBRyxFQUFFRyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUVGLE1BQU0sQ0FBQztFQUN6RCxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sT0FBT04sR0FBRztBQUNaIiwiaWdub3JlTGlzdCI6W119