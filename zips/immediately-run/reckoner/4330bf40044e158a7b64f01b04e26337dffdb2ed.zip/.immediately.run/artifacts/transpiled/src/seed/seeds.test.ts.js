"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _seeds = require("./seeds.ts");
// The ?doc= seed picker: both boot shapes (platform `?href=<outer url>` vs vite dev's
// bare search), the default, and unparseable input failing closed to the default.

(0, _vitest.describe)('seedFromBootLocation', () => {
  (0, _vitest.it)('the platform shape: the doc param rides inside the encoded boot href', () => {
    const outer = 'https://immediately.run/present/github/immediately-run/reckoner/main/files/src/App.tsx?doc=caldera';
    const search = '?href=' + encodeURIComponent(outer);
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search
    })).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('the vite-dev shape: a bare ?doc= search', () => {
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?doc=caldera'
    })).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('no doc param → the default Meridian document', () => {
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: ''
    })).toBe(_seeds.MERIDIAN_SEED);
    const outer = 'https://immediately.run/present/github/immediately-run/reckoner/main/files/src/App.tsx';
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?href=' + encodeURIComponent(outer)
    })).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('an unknown doc value and garbage hrefs fail closed to the default', () => {
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?doc=ghost'
    })).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?href=' + encodeURIComponent('not a url::%zz')
    })).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?href=%zz'
    })).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('a retired doc slug (usage, R3-768) falls back to the default, not a broken document', () => {
    // The usage workbook moved out of the app into its own repo (R3-768); a legacy
    // `?doc=usage` link must open the default document in both boot shapes.
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?doc=usage'
    })).toBe(_seeds.MERIDIAN_SEED);
    const outer = 'https://immediately.run/present/github/immediately-run/reckoner/main/files/src/App.tsx?doc=usage';
    (0, _vitest.expect)((0, _seeds.seedFromBootLocation)({
      search: '?href=' + encodeURIComponent(outer)
    })).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('the seeds are distinct documents with the roots set correctly', () => {
    (0, _vitest.expect)(_seeds.CALDERA_SEED.root).toBe('caldera');
    (0, _vitest.expect)(Object.keys(_seeds.CALDERA_SEED.files).length).toBeGreaterThan(5);
    (0, _vitest.expect)(_seeds.MERIDIAN_SEED.root).toBe('meridian');
  });
  (0, _vitest.it)('the slugs are LITERAL, because they are the published URL contract (R3-553)', () => {
    // Since the root is also the URL segment, renaming one silently breaks every link anyone
    // has shared — `…/reckoner/main/meridian` and the README's. Pinning the strings here makes a
    // rename a deliberate act with a failing test in front of it. Nothing else can: every
    // other assertion in this file reads `seed.root`, so it is true whatever the root says.
    (0, _vitest.expect)(_seeds.MERIDIAN_SEED.root).toBe('meridian');
    (0, _vitest.expect)(_seeds.CALDERA_SEED.root).toBe('caldera');
  });
});

// R3-553 — the app owns a path space now, so the document comes from the PATH first.
(0, _vitest.describe)('seedFromAppPath', () => {
  // The expected roots are read from the SEEDS, never written as literals: the slug IS the
  // root, so a renamed root must fail this test rather than quietly diverge from the URL.
  (0, _vitest.it)('a slug matching a seed root opens that document', () => {
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)(`/${_seeds.MERIDIAN_SEED.root}`)).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)(`/${_seeds.CALDERA_SEED.root}`)).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('round-trips: every document is reachable at its own root, with and without a trailing slash', () => {
    // Driven from DOCUMENTS — the single list the app itself routes and renders from — so a
    // new document is covered the day it is added.
    //
    // What this does NOT prove is that a root was not RENAMED: every assertion here reads
    // `seed.root`, so it stays true whatever the root says. The first version claimed
    // otherwise in a comment, and renaming `SEED_ROOT` really did leave every test green.
    // A rename is caught by the literal slugs pinned in the first describe — the published
    // URL contract — and this case proves the other property: that each document is reachable
    // at whatever its root currently is. `documentAtPath` rather than `seedFromAppPath`
    // because the latter's unknown-slug fallback would make even that vacuous.
    (0, _vitest.expect)(_seeds.DOCUMENTS.length).toBeGreaterThan(1);
    for (const {
      seed
    } of _seeds.DOCUMENTS) {
      (0, _vitest.expect)((0, _seeds.documentAtPath)(`/${seed.root}`)).toBe(seed);
      (0, _vitest.expect)((0, _seeds.documentAtPath)(`/${seed.root}/`)).toBe(seed);
      (0, _vitest.expect)((0, _seeds.seedFromAppPath)(`/${seed.root}`)).toBe(seed);
    }
  });
  (0, _vitest.it)('the default document is selected EXPLICITLY at its own root, not through the fallback', () => {
    // The distinction the blocking bug turned on: `/meridian` names a document, `/` does not.
    (0, _vitest.expect)((0, _seeds.documentAtPath)(`/${_seeds.MERIDIAN_SEED.root}`)).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.documentAtPath)('/')).toBeNull();
    (0, _vitest.expect)((0, _seeds.documentAtPath)('/ghost')).toBeNull();
    (0, _vitest.expect)((0, _seeds.documentAtPath)('/files/src/App.tsx')).toBeNull();
  });
  (0, _vitest.it)('the root path is the default document', () => {
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)('/')).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)('')).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('an unknown slug opens the default rather than erroring — a stale link still shows something', () => {
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)('/ghost')).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('the legacy file-view path resolves, because `files/` is stripped and the rest is unknown', () => {
    // This is why every published `…/main/files/src/App.tsx` link keeps working: not a
    // special case, just normalisation followed by the unknown-slug default.
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)('/files/src/App.tsx')).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)('/corpus/x')).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('a `files/`-prefixed DOCUMENT link resolves to that document', () => {
    // The SDK's link builder prefixes `files/` unless a caller opts out, so this is the
    // shape an accidentally-default-built link arrives in.
    (0, _vitest.expect)((0, _seeds.seedFromAppPath)(`/files/${_seeds.CALDERA_SEED.root}`)).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('no slug may collide with a host-intercepted segment', () => {
    // `files`, `bundle` and `corpus` are taken by the host's own URL grammar; a document
    // named for one of them would be unreachable.
    for (const {
      seed
    } of _seeds.DOCUMENTS) {
      (0, _vitest.expect)(['files', 'bundle', 'corpus']).not.toContain(seed.root);
    }
  });
  (0, _vitest.it)('DOCUMENTS is the only enumeration — every seed the module exports appears in it', () => {
    // The nav renders DOCUMENTS and the router resolves through it, so a document added to the
    // module but not to the list would be routable-but-invisible, or the reverse.
    const listed = new Set(_seeds.DOCUMENTS.map(d => d.seed));
    for (const seed of [_seeds.MERIDIAN_SEED, _seeds.CALDERA_SEED]) (0, _vitest.expect)(listed.has(seed)).toBe(true);
    (0, _vitest.expect)(_seeds.DOCUMENTS.length).toBe(2);
  });
});
(0, _vitest.describe)('appPathFromSandboxPath', () => {
  (0, _vitest.it)('normalises absence, slashes and the two filesystem-space prefixes', () => {
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)(undefined)).toBe('/');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)(null)).toBe('/');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)('')).toBe('/');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)('/usage/')).toBe('/usage');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)('files/usage')).toBe('/usage');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)('/corpus/usage')).toBe('/usage');
    (0, _vitest.expect)((0, _seeds.appPathFromSandboxPath)('/files')).toBe('/');
  });
});
(0, _vitest.describe)('seedForBoot — precedence', () => {
  (0, _vitest.it)('the PATH wins over the query when a legacy link carries both', () => {
    // The case that only appears once the app emits paths: `/caldera` in the path and
    // `?doc=meridian` in the query. The path is the one the user can navigate to and Back
    // out of, so it decides.
    (0, _vitest.expect)((0, _seeds.seedForBoot)(`/${_seeds.CALDERA_SEED.root}`, {
      search: '?doc=meridian'
    })).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('the DEFAULT document wins over the query at its own root — the blocking regression', () => {
    // This returned CALDERA before the fix: `seedForBoot` read "resolved to the default" as
    // "named nothing" and handed the decision to the query. From any published link — all of
    // which carry `?doc=` — clicking Meridian in the nav moved the URL and left the other
    // document on screen.
    (0, _vitest.expect)((0, _seeds.seedForBoot)(`/${_seeds.MERIDIAN_SEED.root}`, {
      search: '?doc=caldera'
    })).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedForBoot)(`/${_seeds.MERIDIAN_SEED.root}`, {
      search: '?doc=usage'
    })).toBe(_seeds.MERIDIAN_SEED);
  });
  (0, _vitest.it)('the query still decides when the path names no document (every published link today)', () => {
    (0, _vitest.expect)((0, _seeds.seedForBoot)('/files/src/App.tsx', {
      search: '?doc=caldera'
    })).toBe(_seeds.CALDERA_SEED);
    (0, _vitest.expect)((0, _seeds.seedForBoot)('/', {
      search: '?doc=caldera'
    })).toBe(_seeds.CALDERA_SEED);
    (0, _vitest.expect)((0, _seeds.seedForBoot)(undefined, {
      search: '?doc=caldera'
    })).toBe(_seeds.CALDERA_SEED);
  });
  (0, _vitest.it)('neither → the default document', () => {
    (0, _vitest.expect)((0, _seeds.seedForBoot)('/', {
      search: ''
    })).toBe(_seeds.MERIDIAN_SEED);
    (0, _vitest.expect)((0, _seeds.seedForBoot)('/ghost', {
      search: '?doc=ghost'
    })).toBe(_seeds.MERIDIAN_SEED);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9zZWVkcyIsImRlc2NyaWJlIiwiaXQiLCJvdXRlciIsInNlYXJjaCIsImVuY29kZVVSSUNvbXBvbmVudCIsImV4cGVjdCIsInNlZWRGcm9tQm9vdExvY2F0aW9uIiwidG9CZSIsIkNBTERFUkFfU0VFRCIsIk1FUklESUFOX1NFRUQiLCJyb290IiwiT2JqZWN0Iiwia2V5cyIsImZpbGVzIiwibGVuZ3RoIiwidG9CZUdyZWF0ZXJUaGFuIiwic2VlZEZyb21BcHBQYXRoIiwiRE9DVU1FTlRTIiwic2VlZCIsImRvY3VtZW50QXRQYXRoIiwidG9CZU51bGwiLCJub3QiLCJ0b0NvbnRhaW4iLCJsaXN0ZWQiLCJTZXQiLCJtYXAiLCJkIiwiaGFzIiwiYXBwUGF0aEZyb21TYW5kYm94UGF0aCIsInVuZGVmaW5lZCIsInNlZWRGb3JCb290Il0sInNvdXJjZXMiOlsic2VlZHMudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgP2RvYz0gc2VlZCBwaWNrZXI6IGJvdGggYm9vdCBzaGFwZXMgKHBsYXRmb3JtIGA/aHJlZj08b3V0ZXIgdXJsPmAgdnMgdml0ZSBkZXYnc1xuLy8gYmFyZSBzZWFyY2gpLCB0aGUgZGVmYXVsdCwgYW5kIHVucGFyc2VhYmxlIGlucHV0IGZhaWxpbmcgY2xvc2VkIHRvIHRoZSBkZWZhdWx0LlxuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQge1xuICBzZWVkRnJvbUJvb3RMb2NhdGlvbixcbiAgc2VlZEZyb21BcHBQYXRoLFxuICBzZWVkRm9yQm9vdCxcbiAgZG9jdW1lbnRBdFBhdGgsXG4gIGFwcFBhdGhGcm9tU2FuZGJveFBhdGgsXG4gIERPQ1VNRU5UUyxcbiAgTUVSSURJQU5fU0VFRCxcbiAgQ0FMREVSQV9TRUVELFxufSBmcm9tICcuL3NlZWRzLnRzJztcblxuZGVzY3JpYmUoJ3NlZWRGcm9tQm9vdExvY2F0aW9uJywgKCkgPT4ge1xuICBpdCgndGhlIHBsYXRmb3JtIHNoYXBlOiB0aGUgZG9jIHBhcmFtIHJpZGVzIGluc2lkZSB0aGUgZW5jb2RlZCBib290IGhyZWYnLCAoKSA9PiB7XG4gICAgY29uc3Qgb3V0ZXIgPSAnaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvaW1tZWRpYXRlbHktcnVuL3JlY2tvbmVyL21haW4vZmlsZXMvc3JjL0FwcC50c3g/ZG9jPWNhbGRlcmEnO1xuICAgIGNvbnN0IHNlYXJjaCA9ICc/aHJlZj0nICsgZW5jb2RlVVJJQ29tcG9uZW50KG91dGVyKTtcbiAgICBleHBlY3Qoc2VlZEZyb21Cb290TG9jYXRpb24oeyBzZWFyY2ggfSkpLnRvQmUoQ0FMREVSQV9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSB2aXRlLWRldiBzaGFwZTogYSBiYXJlID9kb2M9IHNlYXJjaCcsICgpID0+IHtcbiAgICBleHBlY3Qoc2VlZEZyb21Cb290TG9jYXRpb24oeyBzZWFyY2g6ICc/ZG9jPWNhbGRlcmEnIH0pKS50b0JlKENBTERFUkFfU0VFRCk7XG4gIH0pO1xuXG4gIGl0KCdubyBkb2MgcGFyYW0g4oaSIHRoZSBkZWZhdWx0IE1lcmlkaWFuIGRvY3VtZW50JywgKCkgPT4ge1xuICAgIGV4cGVjdChzZWVkRnJvbUJvb3RMb2NhdGlvbih7IHNlYXJjaDogJycgfSkpLnRvQmUoTUVSSURJQU5fU0VFRCk7XG4gICAgY29uc3Qgb3V0ZXIgPSAnaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvaW1tZWRpYXRlbHktcnVuL3JlY2tvbmVyL21haW4vZmlsZXMvc3JjL0FwcC50c3gnO1xuICAgIGV4cGVjdChzZWVkRnJvbUJvb3RMb2NhdGlvbih7IHNlYXJjaDogJz9ocmVmPScgKyBlbmNvZGVVUklDb21wb25lbnQob3V0ZXIpIH0pKS50b0JlKE1FUklESUFOX1NFRUQpO1xuICB9KTtcblxuICBpdCgnYW4gdW5rbm93biBkb2MgdmFsdWUgYW5kIGdhcmJhZ2UgaHJlZnMgZmFpbCBjbG9zZWQgdG8gdGhlIGRlZmF1bHQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KHNlZWRGcm9tQm9vdExvY2F0aW9uKHsgc2VhcmNoOiAnP2RvYz1naG9zdCcgfSkpLnRvQmUoTUVSSURJQU5fU0VFRCk7XG4gICAgZXhwZWN0KHNlZWRGcm9tQm9vdExvY2F0aW9uKHsgc2VhcmNoOiAnP2hyZWY9JyArIGVuY29kZVVSSUNvbXBvbmVudCgnbm90IGEgdXJsOjolenonKSB9KSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgICBleHBlY3Qoc2VlZEZyb21Cb290TG9jYXRpb24oeyBzZWFyY2g6ICc/aHJlZj0lenonIH0pKS50b0JlKE1FUklESUFOX1NFRUQpO1xuICB9KTtcblxuICBpdCgnYSByZXRpcmVkIGRvYyBzbHVnICh1c2FnZSwgUjMtNzY4KSBmYWxscyBiYWNrIHRvIHRoZSBkZWZhdWx0LCBub3QgYSBicm9rZW4gZG9jdW1lbnQnLCAoKSA9PiB7XG4gICAgLy8gVGhlIHVzYWdlIHdvcmtib29rIG1vdmVkIG91dCBvZiB0aGUgYXBwIGludG8gaXRzIG93biByZXBvIChSMy03NjgpOyBhIGxlZ2FjeVxuICAgIC8vIGA/ZG9jPXVzYWdlYCBsaW5rIG11c3Qgb3BlbiB0aGUgZGVmYXVsdCBkb2N1bWVudCBpbiBib3RoIGJvb3Qgc2hhcGVzLlxuICAgIGV4cGVjdChzZWVkRnJvbUJvb3RMb2NhdGlvbih7IHNlYXJjaDogJz9kb2M9dXNhZ2UnIH0pKS50b0JlKE1FUklESUFOX1NFRUQpO1xuICAgIGNvbnN0IG91dGVyID0gJ2h0dHBzOi8vaW1tZWRpYXRlbHkucnVuL3ByZXNlbnQvZ2l0aHViL2ltbWVkaWF0ZWx5LXJ1bi9yZWNrb25lci9tYWluL2ZpbGVzL3NyYy9BcHAudHN4P2RvYz11c2FnZSc7XG4gICAgZXhwZWN0KHNlZWRGcm9tQm9vdExvY2F0aW9uKHsgc2VhcmNoOiAnP2hyZWY9JyArIGVuY29kZVVSSUNvbXBvbmVudChvdXRlcikgfSkpLnRvQmUoTUVSSURJQU5fU0VFRCk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgc2VlZHMgYXJlIGRpc3RpbmN0IGRvY3VtZW50cyB3aXRoIHRoZSByb290cyBzZXQgY29ycmVjdGx5JywgKCkgPT4ge1xuICAgIGV4cGVjdChDQUxERVJBX1NFRUQucm9vdCkudG9CZSgnY2FsZGVyYScpO1xuICAgIGV4cGVjdChPYmplY3Qua2V5cyhDQUxERVJBX1NFRUQuZmlsZXMpLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDUpO1xuICAgIGV4cGVjdChNRVJJRElBTl9TRUVELnJvb3QpLnRvQmUoJ21lcmlkaWFuJyk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgc2x1Z3MgYXJlIExJVEVSQUwsIGJlY2F1c2UgdGhleSBhcmUgdGhlIHB1Ymxpc2hlZCBVUkwgY29udHJhY3QgKFIzLTU1MyknLCAoKSA9PiB7XG4gICAgLy8gU2luY2UgdGhlIHJvb3QgaXMgYWxzbyB0aGUgVVJMIHNlZ21lbnQsIHJlbmFtaW5nIG9uZSBzaWxlbnRseSBicmVha3MgZXZlcnkgbGluayBhbnlvbmVcbiAgICAvLyBoYXMgc2hhcmVkIOKAlCBg4oCmL3JlY2tvbmVyL21haW4vbWVyaWRpYW5gIGFuZCB0aGUgUkVBRE1FJ3MuIFBpbm5pbmcgdGhlIHN0cmluZ3MgaGVyZSBtYWtlcyBhXG4gICAgLy8gcmVuYW1lIGEgZGVsaWJlcmF0ZSBhY3Qgd2l0aCBhIGZhaWxpbmcgdGVzdCBpbiBmcm9udCBvZiBpdC4gTm90aGluZyBlbHNlIGNhbjogZXZlcnlcbiAgICAvLyBvdGhlciBhc3NlcnRpb24gaW4gdGhpcyBmaWxlIHJlYWRzIGBzZWVkLnJvb3RgLCBzbyBpdCBpcyB0cnVlIHdoYXRldmVyIHRoZSByb290IHNheXMuXG4gICAgZXhwZWN0KE1FUklESUFOX1NFRUQucm9vdCkudG9CZSgnbWVyaWRpYW4nKTtcbiAgICBleHBlY3QoQ0FMREVSQV9TRUVELnJvb3QpLnRvQmUoJ2NhbGRlcmEnKTtcbiAgfSk7XG59KTtcblxuLy8gUjMtNTUzIOKAlCB0aGUgYXBwIG93bnMgYSBwYXRoIHNwYWNlIG5vdywgc28gdGhlIGRvY3VtZW50IGNvbWVzIGZyb20gdGhlIFBBVEggZmlyc3QuXG5kZXNjcmliZSgnc2VlZEZyb21BcHBQYXRoJywgKCkgPT4ge1xuICAvLyBUaGUgZXhwZWN0ZWQgcm9vdHMgYXJlIHJlYWQgZnJvbSB0aGUgU0VFRFMsIG5ldmVyIHdyaXR0ZW4gYXMgbGl0ZXJhbHM6IHRoZSBzbHVnIElTIHRoZVxuICAvLyByb290LCBzbyBhIHJlbmFtZWQgcm9vdCBtdXN0IGZhaWwgdGhpcyB0ZXN0IHJhdGhlciB0aGFuIHF1aWV0bHkgZGl2ZXJnZSBmcm9tIHRoZSBVUkwuXG4gIGl0KCdhIHNsdWcgbWF0Y2hpbmcgYSBzZWVkIHJvb3Qgb3BlbnMgdGhhdCBkb2N1bWVudCcsICgpID0+IHtcbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKGAvJHtNRVJJRElBTl9TRUVELnJvb3R9YCkpLnRvQmUoTUVSSURJQU5fU0VFRCk7XG4gICAgZXhwZWN0KHNlZWRGcm9tQXBwUGF0aChgLyR7Q0FMREVSQV9TRUVELnJvb3R9YCkpLnRvQmUoQ0FMREVSQV9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ3JvdW5kLXRyaXBzOiBldmVyeSBkb2N1bWVudCBpcyByZWFjaGFibGUgYXQgaXRzIG93biByb290LCB3aXRoIGFuZCB3aXRob3V0IGEgdHJhaWxpbmcgc2xhc2gnLCAoKSA9PiB7XG4gICAgLy8gRHJpdmVuIGZyb20gRE9DVU1FTlRTIOKAlCB0aGUgc2luZ2xlIGxpc3QgdGhlIGFwcCBpdHNlbGYgcm91dGVzIGFuZCByZW5kZXJzIGZyb20g4oCUIHNvIGFcbiAgICAvLyBuZXcgZG9jdW1lbnQgaXMgY292ZXJlZCB0aGUgZGF5IGl0IGlzIGFkZGVkLlxuICAgIC8vXG4gICAgLy8gV2hhdCB0aGlzIGRvZXMgTk9UIHByb3ZlIGlzIHRoYXQgYSByb290IHdhcyBub3QgUkVOQU1FRDogZXZlcnkgYXNzZXJ0aW9uIGhlcmUgcmVhZHNcbiAgICAvLyBgc2VlZC5yb290YCwgc28gaXQgc3RheXMgdHJ1ZSB3aGF0ZXZlciB0aGUgcm9vdCBzYXlzLiBUaGUgZmlyc3QgdmVyc2lvbiBjbGFpbWVkXG4gICAgLy8gb3RoZXJ3aXNlIGluIGEgY29tbWVudCwgYW5kIHJlbmFtaW5nIGBTRUVEX1JPT1RgIHJlYWxseSBkaWQgbGVhdmUgZXZlcnkgdGVzdCBncmVlbi5cbiAgICAvLyBBIHJlbmFtZSBpcyBjYXVnaHQgYnkgdGhlIGxpdGVyYWwgc2x1Z3MgcGlubmVkIGluIHRoZSBmaXJzdCBkZXNjcmliZSDigJQgdGhlIHB1Ymxpc2hlZFxuICAgIC8vIFVSTCBjb250cmFjdCDigJQgYW5kIHRoaXMgY2FzZSBwcm92ZXMgdGhlIG90aGVyIHByb3BlcnR5OiB0aGF0IGVhY2ggZG9jdW1lbnQgaXMgcmVhY2hhYmxlXG4gICAgLy8gYXQgd2hhdGV2ZXIgaXRzIHJvb3QgY3VycmVudGx5IGlzLiBgZG9jdW1lbnRBdFBhdGhgIHJhdGhlciB0aGFuIGBzZWVkRnJvbUFwcFBhdGhgXG4gICAgLy8gYmVjYXVzZSB0aGUgbGF0dGVyJ3MgdW5rbm93bi1zbHVnIGZhbGxiYWNrIHdvdWxkIG1ha2UgZXZlbiB0aGF0IHZhY3VvdXMuXG4gICAgZXhwZWN0KERPQ1VNRU5UUy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigxKTtcbiAgICBmb3IgKGNvbnN0IHsgc2VlZCB9IG9mIERPQ1VNRU5UUykge1xuICAgICAgZXhwZWN0KGRvY3VtZW50QXRQYXRoKGAvJHtzZWVkLnJvb3R9YCkpLnRvQmUoc2VlZCk7XG4gICAgICBleHBlY3QoZG9jdW1lbnRBdFBhdGgoYC8ke3NlZWQucm9vdH0vYCkpLnRvQmUoc2VlZCk7XG4gICAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKGAvJHtzZWVkLnJvb3R9YCkpLnRvQmUoc2VlZCk7XG4gICAgfVxuICB9KTtcblxuICBpdCgndGhlIGRlZmF1bHQgZG9jdW1lbnQgaXMgc2VsZWN0ZWQgRVhQTElDSVRMWSBhdCBpdHMgb3duIHJvb3QsIG5vdCB0aHJvdWdoIHRoZSBmYWxsYmFjaycsICgpID0+IHtcbiAgICAvLyBUaGUgZGlzdGluY3Rpb24gdGhlIGJsb2NraW5nIGJ1ZyB0dXJuZWQgb246IGAvbWVyaWRpYW5gIG5hbWVzIGEgZG9jdW1lbnQsIGAvYCBkb2VzIG5vdC5cbiAgICBleHBlY3QoZG9jdW1lbnRBdFBhdGgoYC8ke01FUklESUFOX1NFRUQucm9vdH1gKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgICBleHBlY3QoZG9jdW1lbnRBdFBhdGgoJy8nKSkudG9CZU51bGwoKTtcbiAgICBleHBlY3QoZG9jdW1lbnRBdFBhdGgoJy9naG9zdCcpKS50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChkb2N1bWVudEF0UGF0aCgnL2ZpbGVzL3NyYy9BcHAudHN4JykpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgcm9vdCBwYXRoIGlzIHRoZSBkZWZhdWx0IGRvY3VtZW50JywgKCkgPT4ge1xuICAgIGV4cGVjdChzZWVkRnJvbUFwcFBhdGgoJy8nKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKCcnKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ2FuIHVua25vd24gc2x1ZyBvcGVucyB0aGUgZGVmYXVsdCByYXRoZXIgdGhhbiBlcnJvcmluZyDigJQgYSBzdGFsZSBsaW5rIHN0aWxsIHNob3dzIHNvbWV0aGluZycsICgpID0+IHtcbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKCcvZ2hvc3QnKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBsZWdhY3kgZmlsZS12aWV3IHBhdGggcmVzb2x2ZXMsIGJlY2F1c2UgYGZpbGVzL2AgaXMgc3RyaXBwZWQgYW5kIHRoZSByZXN0IGlzIHVua25vd24nLCAoKSA9PiB7XG4gICAgLy8gVGhpcyBpcyB3aHkgZXZlcnkgcHVibGlzaGVkIGDigKYvbWFpbi9maWxlcy9zcmMvQXBwLnRzeGAgbGluayBrZWVwcyB3b3JraW5nOiBub3QgYVxuICAgIC8vIHNwZWNpYWwgY2FzZSwganVzdCBub3JtYWxpc2F0aW9uIGZvbGxvd2VkIGJ5IHRoZSB1bmtub3duLXNsdWcgZGVmYXVsdC5cbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKCcvZmlsZXMvc3JjL0FwcC50c3gnKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKCcvY29ycHVzL3gnKSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ2EgYGZpbGVzL2AtcHJlZml4ZWQgRE9DVU1FTlQgbGluayByZXNvbHZlcyB0byB0aGF0IGRvY3VtZW50JywgKCkgPT4ge1xuICAgIC8vIFRoZSBTREsncyBsaW5rIGJ1aWxkZXIgcHJlZml4ZXMgYGZpbGVzL2AgdW5sZXNzIGEgY2FsbGVyIG9wdHMgb3V0LCBzbyB0aGlzIGlzIHRoZVxuICAgIC8vIHNoYXBlIGFuIGFjY2lkZW50YWxseS1kZWZhdWx0LWJ1aWx0IGxpbmsgYXJyaXZlcyBpbi5cbiAgICBleHBlY3Qoc2VlZEZyb21BcHBQYXRoKGAvZmlsZXMvJHtDQUxERVJBX1NFRUQucm9vdH1gKSkudG9CZShDQUxERVJBX1NFRUQpO1xuICB9KTtcblxuICBpdCgnbm8gc2x1ZyBtYXkgY29sbGlkZSB3aXRoIGEgaG9zdC1pbnRlcmNlcHRlZCBzZWdtZW50JywgKCkgPT4ge1xuICAgIC8vIGBmaWxlc2AsIGBidW5kbGVgIGFuZCBgY29ycHVzYCBhcmUgdGFrZW4gYnkgdGhlIGhvc3QncyBvd24gVVJMIGdyYW1tYXI7IGEgZG9jdW1lbnRcbiAgICAvLyBuYW1lZCBmb3Igb25lIG9mIHRoZW0gd291bGQgYmUgdW5yZWFjaGFibGUuXG4gICAgZm9yIChjb25zdCB7IHNlZWQgfSBvZiBET0NVTUVOVFMpIHtcbiAgICAgIGV4cGVjdChbJ2ZpbGVzJywgJ2J1bmRsZScsICdjb3JwdXMnXSkubm90LnRvQ29udGFpbihzZWVkLnJvb3QpO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoJ0RPQ1VNRU5UUyBpcyB0aGUgb25seSBlbnVtZXJhdGlvbiDigJQgZXZlcnkgc2VlZCB0aGUgbW9kdWxlIGV4cG9ydHMgYXBwZWFycyBpbiBpdCcsICgpID0+IHtcbiAgICAvLyBUaGUgbmF2IHJlbmRlcnMgRE9DVU1FTlRTIGFuZCB0aGUgcm91dGVyIHJlc29sdmVzIHRocm91Z2ggaXQsIHNvIGEgZG9jdW1lbnQgYWRkZWQgdG8gdGhlXG4gICAgLy8gbW9kdWxlIGJ1dCBub3QgdG8gdGhlIGxpc3Qgd291bGQgYmUgcm91dGFibGUtYnV0LWludmlzaWJsZSwgb3IgdGhlIHJldmVyc2UuXG4gICAgY29uc3QgbGlzdGVkID0gbmV3IFNldChET0NVTUVOVFMubWFwKChkKSA9PiBkLnNlZWQpKTtcbiAgICBmb3IgKGNvbnN0IHNlZWQgb2YgW01FUklESUFOX1NFRUQsIENBTERFUkFfU0VFRF0pIGV4cGVjdChsaXN0ZWQuaGFzKHNlZWQpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChET0NVTUVOVFMubGVuZ3RoKS50b0JlKDIpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnYXBwUGF0aEZyb21TYW5kYm94UGF0aCcsICgpID0+IHtcbiAgaXQoJ25vcm1hbGlzZXMgYWJzZW5jZSwgc2xhc2hlcyBhbmQgdGhlIHR3byBmaWxlc3lzdGVtLXNwYWNlIHByZWZpeGVzJywgKCkgPT4ge1xuICAgIGV4cGVjdChhcHBQYXRoRnJvbVNhbmRib3hQYXRoKHVuZGVmaW5lZCkpLnRvQmUoJy8nKTtcbiAgICBleHBlY3QoYXBwUGF0aEZyb21TYW5kYm94UGF0aChudWxsKSkudG9CZSgnLycpO1xuICAgIGV4cGVjdChhcHBQYXRoRnJvbVNhbmRib3hQYXRoKCcnKSkudG9CZSgnLycpO1xuICAgIGV4cGVjdChhcHBQYXRoRnJvbVNhbmRib3hQYXRoKCcvdXNhZ2UvJykpLnRvQmUoJy91c2FnZScpO1xuICAgIGV4cGVjdChhcHBQYXRoRnJvbVNhbmRib3hQYXRoKCdmaWxlcy91c2FnZScpKS50b0JlKCcvdXNhZ2UnKTtcbiAgICBleHBlY3QoYXBwUGF0aEZyb21TYW5kYm94UGF0aCgnL2NvcnB1cy91c2FnZScpKS50b0JlKCcvdXNhZ2UnKTtcbiAgICBleHBlY3QoYXBwUGF0aEZyb21TYW5kYm94UGF0aCgnL2ZpbGVzJykpLnRvQmUoJy8nKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ3NlZWRGb3JCb290IOKAlCBwcmVjZWRlbmNlJywgKCkgPT4ge1xuICBpdCgndGhlIFBBVEggd2lucyBvdmVyIHRoZSBxdWVyeSB3aGVuIGEgbGVnYWN5IGxpbmsgY2FycmllcyBib3RoJywgKCkgPT4ge1xuICAgIC8vIFRoZSBjYXNlIHRoYXQgb25seSBhcHBlYXJzIG9uY2UgdGhlIGFwcCBlbWl0cyBwYXRoczogYC9jYWxkZXJhYCBpbiB0aGUgcGF0aCBhbmRcbiAgICAvLyBgP2RvYz1tZXJpZGlhbmAgaW4gdGhlIHF1ZXJ5LiBUaGUgcGF0aCBpcyB0aGUgb25lIHRoZSB1c2VyIGNhbiBuYXZpZ2F0ZSB0byBhbmQgQmFja1xuICAgIC8vIG91dCBvZiwgc28gaXQgZGVjaWRlcy5cbiAgICBleHBlY3Qoc2VlZEZvckJvb3QoYC8ke0NBTERFUkFfU0VFRC5yb290fWAsIHsgc2VhcmNoOiAnP2RvYz1tZXJpZGlhbicgfSkpLnRvQmUoQ0FMREVSQV9TRUVEKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBERUZBVUxUIGRvY3VtZW50IHdpbnMgb3ZlciB0aGUgcXVlcnkgYXQgaXRzIG93biByb290IOKAlCB0aGUgYmxvY2tpbmcgcmVncmVzc2lvbicsICgpID0+IHtcbiAgICAvLyBUaGlzIHJldHVybmVkIENBTERFUkEgYmVmb3JlIHRoZSBmaXg6IGBzZWVkRm9yQm9vdGAgcmVhZCBcInJlc29sdmVkIHRvIHRoZSBkZWZhdWx0XCIgYXNcbiAgICAvLyBcIm5hbWVkIG5vdGhpbmdcIiBhbmQgaGFuZGVkIHRoZSBkZWNpc2lvbiB0byB0aGUgcXVlcnkuIEZyb20gYW55IHB1Ymxpc2hlZCBsaW5rIOKAlCBhbGwgb2ZcbiAgICAvLyB3aGljaCBjYXJyeSBgP2RvYz1gIOKAlCBjbGlja2luZyBNZXJpZGlhbiBpbiB0aGUgbmF2IG1vdmVkIHRoZSBVUkwgYW5kIGxlZnQgdGhlIG90aGVyXG4gICAgLy8gZG9jdW1lbnQgb24gc2NyZWVuLlxuICAgIGV4cGVjdChzZWVkRm9yQm9vdChgLyR7TUVSSURJQU5fU0VFRC5yb290fWAsIHsgc2VhcmNoOiAnP2RvYz1jYWxkZXJhJyB9KSkudG9CZShNRVJJRElBTl9TRUVEKTtcbiAgICBleHBlY3Qoc2VlZEZvckJvb3QoYC8ke01FUklESUFOX1NFRUQucm9vdH1gLCB7IHNlYXJjaDogJz9kb2M9dXNhZ2UnIH0pKS50b0JlKE1FUklESUFOX1NFRUQpO1xuICB9KTtcblxuICBpdCgndGhlIHF1ZXJ5IHN0aWxsIGRlY2lkZXMgd2hlbiB0aGUgcGF0aCBuYW1lcyBubyBkb2N1bWVudCAoZXZlcnkgcHVibGlzaGVkIGxpbmsgdG9kYXkpJywgKCkgPT4ge1xuICAgIGV4cGVjdChzZWVkRm9yQm9vdCgnL2ZpbGVzL3NyYy9BcHAudHN4JywgeyBzZWFyY2g6ICc/ZG9jPWNhbGRlcmEnIH0pKS50b0JlKENBTERFUkFfU0VFRCk7XG4gICAgZXhwZWN0KHNlZWRGb3JCb290KCcvJywgeyBzZWFyY2g6ICc/ZG9jPWNhbGRlcmEnIH0pKS50b0JlKENBTERFUkFfU0VFRCk7XG4gICAgZXhwZWN0KHNlZWRGb3JCb290KHVuZGVmaW5lZCwgeyBzZWFyY2g6ICc/ZG9jPWNhbGRlcmEnIH0pKS50b0JlKENBTERFUkFfU0VFRCk7XG4gIH0pO1xuXG4gIGl0KCduZWl0aGVyIOKGkiB0aGUgZGVmYXVsdCBkb2N1bWVudCcsICgpID0+IHtcbiAgICBleHBlY3Qoc2VlZEZvckJvb3QoJy8nLCB7IHNlYXJjaDogJycgfSkpLnRvQmUoTUVSSURJQU5fU0VFRCk7XG4gICAgZXhwZWN0KHNlZWRGb3JCb290KCcvZ2hvc3QnLCB7IHNlYXJjaDogJz9kb2M9Z2hvc3QnIH0pKS50b0JlKE1FUklESUFOX1NFRUQpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7O0FBR0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBSkE7QUFDQTs7QUFjQSxJQUFBRSxnQkFBUSxFQUFDLHNCQUFzQixFQUFFLE1BQU07RUFDckMsSUFBQUMsVUFBRSxFQUFDLHNFQUFzRSxFQUFFLE1BQU07SUFDL0UsTUFBTUMsS0FBSyxHQUFHLG9HQUFvRztJQUNsSCxNQUFNQyxNQUFNLEdBQUcsUUFBUSxHQUFHQyxrQkFBa0IsQ0FBQ0YsS0FBSyxDQUFDO0lBQ25ELElBQUFHLGNBQU0sRUFBQyxJQUFBQywyQkFBb0IsRUFBQztNQUFFSDtJQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNJLElBQUksQ0FBQ0MsbUJBQVksQ0FBQztFQUM3RCxDQUFDLENBQUM7RUFFRixJQUFBUCxVQUFFLEVBQUMseUNBQXlDLEVBQUUsTUFBTTtJQUNsRCxJQUFBSSxjQUFNLEVBQUMsSUFBQUMsMkJBQW9CLEVBQUM7TUFBRUgsTUFBTSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksSUFBSSxDQUFDQyxtQkFBWSxDQUFDO0VBQzdFLENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQyw4Q0FBOEMsRUFBRSxNQUFNO0lBQ3ZELElBQUFJLGNBQU0sRUFBQyxJQUFBQywyQkFBb0IsRUFBQztNQUFFSCxNQUFNLEVBQUU7SUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNFLG9CQUFhLENBQUM7SUFDaEUsTUFBTVAsS0FBSyxHQUFHLHdGQUF3RjtJQUN0RyxJQUFBRyxjQUFNLEVBQUMsSUFBQUMsMkJBQW9CLEVBQUM7TUFBRUgsTUFBTSxFQUFFLFFBQVEsR0FBR0Msa0JBQWtCLENBQUNGLEtBQUs7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDSyxJQUFJLENBQUNFLG9CQUFhLENBQUM7RUFDcEcsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07SUFDNUUsSUFBQUksY0FBTSxFQUFDLElBQUFDLDJCQUFvQixFQUFDO01BQUVILE1BQU0sRUFBRTtJQUFhLENBQUMsQ0FBQyxDQUFDLENBQUNJLElBQUksQ0FBQ0Usb0JBQWEsQ0FBQztJQUMxRSxJQUFBSixjQUFNLEVBQUMsSUFBQUMsMkJBQW9CLEVBQUM7TUFBRUgsTUFBTSxFQUFFLFFBQVEsR0FBR0Msa0JBQWtCLENBQUMsZ0JBQWdCO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0csSUFBSSxDQUFDRSxvQkFBYSxDQUFDO0lBQzdHLElBQUFKLGNBQU0sRUFBQyxJQUFBQywyQkFBb0IsRUFBQztNQUFFSCxNQUFNLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNFLG9CQUFhLENBQUM7RUFDM0UsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLHFGQUFxRixFQUFFLE1BQU07SUFDOUY7SUFDQTtJQUNBLElBQUFJLGNBQU0sRUFBQyxJQUFBQywyQkFBb0IsRUFBQztNQUFFSCxNQUFNLEVBQUU7SUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNFLG9CQUFhLENBQUM7SUFDMUUsTUFBTVAsS0FBSyxHQUFHLGtHQUFrRztJQUNoSCxJQUFBRyxjQUFNLEVBQUMsSUFBQUMsMkJBQW9CLEVBQUM7TUFBRUgsTUFBTSxFQUFFLFFBQVEsR0FBR0Msa0JBQWtCLENBQUNGLEtBQUs7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDSyxJQUFJLENBQUNFLG9CQUFhLENBQUM7RUFDcEcsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLCtEQUErRCxFQUFFLE1BQU07SUFDeEUsSUFBQUksY0FBTSxFQUFDRyxtQkFBWSxDQUFDRSxJQUFJLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUN6QyxJQUFBRixjQUFNLEVBQUNNLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDSixtQkFBWSxDQUFDSyxLQUFLLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7SUFDakUsSUFBQVYsY0FBTSxFQUFDSSxvQkFBYSxDQUFDQyxJQUFJLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQztFQUM3QyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsNkVBQTZFLEVBQUUsTUFBTTtJQUN0RjtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUFJLGNBQU0sRUFBQ0ksb0JBQWEsQ0FBQ0MsSUFBSSxDQUFDLENBQUNILElBQUksQ0FBQyxVQUFVLENBQUM7SUFDM0MsSUFBQUYsY0FBTSxFQUFDRyxtQkFBWSxDQUFDRSxJQUFJLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUMzQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBUCxnQkFBUSxFQUFDLGlCQUFpQixFQUFFLE1BQU07RUFDaEM7RUFDQTtFQUNBLElBQUFDLFVBQUUsRUFBQyxpREFBaUQsRUFBRSxNQUFNO0lBQzFELElBQUFJLGNBQU0sRUFBQyxJQUFBVyxzQkFBZSxFQUFDLElBQUlQLG9CQUFhLENBQUNDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxDQUFDRSxvQkFBYSxDQUFDO0lBQ3JFLElBQUFKLGNBQU0sRUFBQyxJQUFBVyxzQkFBZSxFQUFDLElBQUlSLG1CQUFZLENBQUNFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxDQUFDQyxtQkFBWSxDQUFDO0VBQ3JFLENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQyw2RkFBNkYsRUFBRSxNQUFNO0lBQ3RHO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUksY0FBTSxFQUFDWSxnQkFBUyxDQUFDSCxNQUFNLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLENBQUMsQ0FBQztJQUMzQyxLQUFLLE1BQU07TUFBRUc7SUFBSyxDQUFDLElBQUlELGdCQUFTLEVBQUU7TUFDaEMsSUFBQVosY0FBTSxFQUFDLElBQUFjLHFCQUFjLEVBQUMsSUFBSUQsSUFBSSxDQUFDUixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUNILElBQUksQ0FBQ1csSUFBSSxDQUFDO01BQ2xELElBQUFiLGNBQU0sRUFBQyxJQUFBYyxxQkFBYyxFQUFDLElBQUlELElBQUksQ0FBQ1IsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDSCxJQUFJLENBQUNXLElBQUksQ0FBQztNQUNuRCxJQUFBYixjQUFNLEVBQUMsSUFBQVcsc0JBQWUsRUFBQyxJQUFJRSxJQUFJLENBQUNSLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxDQUFDVyxJQUFJLENBQUM7SUFDckQ7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBakIsVUFBRSxFQUFDLHVGQUF1RixFQUFFLE1BQU07SUFDaEc7SUFDQSxJQUFBSSxjQUFNLEVBQUMsSUFBQWMscUJBQWMsRUFBQyxJQUFJVixvQkFBYSxDQUFDQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUNILElBQUksQ0FBQ0Usb0JBQWEsQ0FBQztJQUNwRSxJQUFBSixjQUFNLEVBQUMsSUFBQWMscUJBQWMsRUFBQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztJQUN0QyxJQUFBZixjQUFNLEVBQUMsSUFBQWMscUJBQWMsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztJQUMzQyxJQUFBZixjQUFNLEVBQUMsSUFBQWMscUJBQWMsRUFBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0VBQ3pELENBQUMsQ0FBQztFQUVGLElBQUFuQixVQUFFLEVBQUMsdUNBQXVDLEVBQUUsTUFBTTtJQUNoRCxJQUFBSSxjQUFNLEVBQUMsSUFBQVcsc0JBQWUsRUFBQyxHQUFHLENBQUMsQ0FBQyxDQUFDVCxJQUFJLENBQUNFLG9CQUFhLENBQUM7SUFDaEQsSUFBQUosY0FBTSxFQUFDLElBQUFXLHNCQUFlLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ1QsSUFBSSxDQUFDRSxvQkFBYSxDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQyw2RkFBNkYsRUFBRSxNQUFNO0lBQ3RHLElBQUFJLGNBQU0sRUFBQyxJQUFBVyxzQkFBZSxFQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNULElBQUksQ0FBQ0Usb0JBQWEsQ0FBQztFQUN2RCxDQUFDLENBQUM7RUFFRixJQUFBUixVQUFFLEVBQUMsMEZBQTBGLEVBQUUsTUFBTTtJQUNuRztJQUNBO0lBQ0EsSUFBQUksY0FBTSxFQUFDLElBQUFXLHNCQUFlLEVBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDVCxJQUFJLENBQUNFLG9CQUFhLENBQUM7SUFDakUsSUFBQUosY0FBTSxFQUFDLElBQUFXLHNCQUFlLEVBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ1QsSUFBSSxDQUFDRSxvQkFBYSxDQUFDO0VBQzFELENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQyw2REFBNkQsRUFBRSxNQUFNO0lBQ3RFO0lBQ0E7SUFDQSxJQUFBSSxjQUFNLEVBQUMsSUFBQVcsc0JBQWUsRUFBQyxVQUFVUixtQkFBWSxDQUFDRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUNILElBQUksQ0FBQ0MsbUJBQVksQ0FBQztFQUMzRSxDQUFDLENBQUM7RUFFRixJQUFBUCxVQUFFLEVBQUMscURBQXFELEVBQUUsTUFBTTtJQUM5RDtJQUNBO0lBQ0EsS0FBSyxNQUFNO01BQUVpQjtJQUFLLENBQUMsSUFBSUQsZ0JBQVMsRUFBRTtNQUNoQyxJQUFBWixjQUFNLEVBQUMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUNnQixHQUFHLENBQUNDLFNBQVMsQ0FBQ0osSUFBSSxDQUFDUixJQUFJLENBQUM7SUFDaEU7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBVCxVQUFFLEVBQUMsaUZBQWlGLEVBQUUsTUFBTTtJQUMxRjtJQUNBO0lBQ0EsTUFBTXNCLE1BQU0sR0FBRyxJQUFJQyxHQUFHLENBQUNQLGdCQUFTLENBQUNRLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNSLElBQUksQ0FBQyxDQUFDO0lBQ3BELEtBQUssTUFBTUEsSUFBSSxJQUFJLENBQUNULG9CQUFhLEVBQUVELG1CQUFZLENBQUMsRUFBRSxJQUFBSCxjQUFNLEVBQUNrQixNQUFNLENBQUNJLEdBQUcsQ0FBQ1QsSUFBSSxDQUFDLENBQUMsQ0FBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNyRixJQUFBRixjQUFNLEVBQUNZLGdCQUFTLENBQUNILE1BQU0sQ0FBQyxDQUFDUCxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2xDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFQLGdCQUFRLEVBQUMsd0JBQXdCLEVBQUUsTUFBTTtFQUN2QyxJQUFBQyxVQUFFLEVBQUMsbUVBQW1FLEVBQUUsTUFBTTtJQUM1RSxJQUFBSSxjQUFNLEVBQUMsSUFBQXVCLDZCQUFzQixFQUFDQyxTQUFTLENBQUMsQ0FBQyxDQUFDdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNuRCxJQUFBRixjQUFNLEVBQUMsSUFBQXVCLDZCQUFzQixFQUFDLElBQUksQ0FBQyxDQUFDLENBQUNyQixJQUFJLENBQUMsR0FBRyxDQUFDO0lBQzlDLElBQUFGLGNBQU0sRUFBQyxJQUFBdUIsNkJBQXNCLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ3JCLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDNUMsSUFBQUYsY0FBTSxFQUFDLElBQUF1Qiw2QkFBc0IsRUFBQyxTQUFTLENBQUMsQ0FBQyxDQUFDckIsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN4RCxJQUFBRixjQUFNLEVBQUMsSUFBQXVCLDZCQUFzQixFQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNyQixJQUFJLENBQUMsUUFBUSxDQUFDO0lBQzVELElBQUFGLGNBQU0sRUFBQyxJQUFBdUIsNkJBQXNCLEVBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDOUQsSUFBQUYsY0FBTSxFQUFDLElBQUF1Qiw2QkFBc0IsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDckIsSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUNwRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBUCxnQkFBUSxFQUFDLDBCQUEwQixFQUFFLE1BQU07RUFDekMsSUFBQUMsVUFBRSxFQUFDLDhEQUE4RCxFQUFFLE1BQU07SUFDdkU7SUFDQTtJQUNBO0lBQ0EsSUFBQUksY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLElBQUl0QixtQkFBWSxDQUFDRSxJQUFJLEVBQUUsRUFBRTtNQUFFUCxNQUFNLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksSUFBSSxDQUFDQyxtQkFBWSxDQUFDO0VBQzlGLENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQyxvRkFBb0YsRUFBRSxNQUFNO0lBQzdGO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUksY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLElBQUlyQixvQkFBYSxDQUFDQyxJQUFJLEVBQUUsRUFBRTtNQUFFUCxNQUFNLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNFLG9CQUFhLENBQUM7SUFDN0YsSUFBQUosY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLElBQUlyQixvQkFBYSxDQUFDQyxJQUFJLEVBQUUsRUFBRTtNQUFFUCxNQUFNLEVBQUU7SUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNFLG9CQUFhLENBQUM7RUFDN0YsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLHNGQUFzRixFQUFFLE1BQU07SUFDL0YsSUFBQUksY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLG9CQUFvQixFQUFFO01BQUUzQixNQUFNLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNDLG1CQUFZLENBQUM7SUFDeEYsSUFBQUgsY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLEdBQUcsRUFBRTtNQUFFM0IsTUFBTSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksSUFBSSxDQUFDQyxtQkFBWSxDQUFDO0lBQ3ZFLElBQUFILGNBQU0sRUFBQyxJQUFBeUIsa0JBQVcsRUFBQ0QsU0FBUyxFQUFFO01BQUUxQixNQUFNLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUNDLG1CQUFZLENBQUM7RUFDL0UsQ0FBQyxDQUFDO0VBRUYsSUFBQVAsVUFBRSxFQUFDLGdDQUFnQyxFQUFFLE1BQU07SUFDekMsSUFBQUksY0FBTSxFQUFDLElBQUF5QixrQkFBVyxFQUFDLEdBQUcsRUFBRTtNQUFFM0IsTUFBTSxFQUFFO0lBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksSUFBSSxDQUFDRSxvQkFBYSxDQUFDO0lBQzVELElBQUFKLGNBQU0sRUFBQyxJQUFBeUIsa0JBQVcsRUFBQyxRQUFRLEVBQUU7TUFBRTNCLE1BQU0sRUFBRTtJQUFhLENBQUMsQ0FBQyxDQUFDLENBQUNJLElBQUksQ0FBQ0Usb0JBQWEsQ0FBQztFQUM3RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=