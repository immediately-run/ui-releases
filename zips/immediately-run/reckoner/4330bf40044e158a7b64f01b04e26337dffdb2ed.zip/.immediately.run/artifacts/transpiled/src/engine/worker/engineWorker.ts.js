"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createEngineWorker = createEngineWorker;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var stdlib = _interopRequireWildcard(require("../../stdlib/index.ts"));
var _compartment = require("../compartment.ts");
var _graph = require("../graph.ts");
var _cycles = require("../cycles.ts");
var _testrunner = require("../testrunner.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// The worker's formula executor (ARCHITECTURE_PLAN §4). Framework-free so it is driven by an
// in-memory transport in tests and by a real Web Worker in production (src/entry/engine.ts).
// It builds one SES Compartment per worksheet (via `evaluateWorksheet`), keeps the registered
// cell **formulas** here (they are closures — never serializable, never cross the boundary),
// and returns the host a serializable {@link WorkbookDescriptor} to schedule over. `eval` runs
// one cell's formula against host-resolved inputs. Purity makes re-evaluation sound.
//
// Only *cells* enter the value graph; test cells are kept here (their `expect`/`relation`
// closures live in this realm) and run via `runSuites` over host-computed contexts — the
// review surface's execution path (§6), never the report-render pipeline.

function createEngineWorker() {
  const formulas = new Map();
  // Subject → its tests, each with the export name (the def itself does not carry one back
  // out of the compartment registry).
  const testsBySubject = new Map();
  return {
    build(sources) {
      formulas.clear();
      testsBySubject.clear();
      const cellWorkbook = {};
      const tests = [];
      // Per-cell declaration spans, computed on the RAW source (R3-427): the what-if
      // splice patches within a cell's own block, and review surfaces show file:line.
      const spansById = new Map();
      for (const [worksheet, source] of Object.entries(sources)) {
        const defs = (0, _compartment.evaluateWorksheet)(source, {
          ...stdlib
        });
        const spans = (0, _compartment.exportSpans)(source);
        const sheet = {};
        for (const [name, def] of Object.entries(defs)) {
          if (spans[name] !== undefined) spansById.set(`${worksheet}.${name}`, spans[name]);
          if (def.kind === 'cell') {
            sheet[name] = def;
            formulas.set(`${worksheet}.${name}`, def.formula);
          } else {
            const id = `${worksheet}.${name}`;
            tests.push({
              id,
              worksheet,
              name,
              kind: def.testKind,
              subject: def.subject,
              span: spans[name],
              inputs: def.inputs
            });
            const list = testsBySubject.get(def.subject) ?? [];
            list.push({
              id,
              def
            });
            testsBySubject.set(def.subject, list);
          }
        }
        cellWorkbook[worksheet] = sheet;
      }
      const graph = (0, _graph.buildGraph)(cellWorkbook);
      const {
        order,
        cycles
      } = (0, _cycles.analyze)(graph);
      return {
        // The workbook passed to buildGraph holds only `cell` defs (tests were diverted
        // above), so every node's def is a CellDef carrying a `doc`.
        cells: [...graph.nodes.values()].map(n => ({
          id: n.id,
          worksheet: n.worksheet,
          cell: n.cell,
          doc: n.def.kind === 'cell' ? n.def.doc : '',
          // The formula itself stays in the worker; its source text crosses for the value
          // inspector's read-only display. SES preserves function sources across lockdown.
          formulaSource: n.def.kind === 'cell' ? n.def.formula.toString() : '',
          span: spansById.get(n.id),
          deps: n.deps,
          externals: n.externals,
          resolvers: n.resolvers
        })),
        tests,
        worksheets: [...graph.worksheets],
        externalInputs: [...graph.externalInputs],
        order,
        cycles,
        diagnostics: graph.diagnostics
      };
    },
    eval(id, inputs) {
      const formula = formulas.get(id);
      if (formula === undefined) throw new Error(`unknown cell "${id}"`);
      return formula(inputs);
    },
    runSuites(suites) {
      const out = [];
      for (const ctx of suites) {
        const tests = testsBySubject.get(ctx.subject) ?? [];
        let suite;
        try {
          suite = (0, _testrunner.runSuite)(tests.map(t => t.def), def => {
            const formula = formulas.get(ctx.subject);
            const reevaluate = formula === undefined ? undefined : inputs => formula(inputs);
            const id = tests.find(t => t.def === def)?.id;
            const entry = id === undefined ? undefined : ctx.tests?.find(t => t.id === id);
            if (entry !== undefined && entry.error !== undefined) {
              return {
                subject: ctx.subjectValue,
                inputs: ctx.inputs,
                error: entry.error
              };
            }
            if (entry === undefined || entry.inputs === undefined) {
              // No declared inputs resolved for this test — the live context, as before.
              return {
                subject: ctx.subjectValue,
                inputs: ctx.inputs,
                reevaluate
              };
            }

            // R3-373: name-matched entries SUBSTITUTe for the subject's live inputs (the
            // subject formula re-runs over the merged set — the holdout pattern);
            // name-unmatched entries are AUXILIARY context for expect/relation only
            // (an oracle fixture) and never feed the formula.
            const substituted = {};
            const auxiliary = {};
            for (const [name, value] of Object.entries(entry.inputs)) {
              if (name in ctx.inputs) substituted[name] = value;else auxiliary[name] = value;
            }
            if (Object.keys(substituted).length === 0) {
              return {
                subject: ctx.subjectValue,
                inputs: {
                  ...ctx.inputs,
                  ...auxiliary
                },
                reevaluate
              };
            }
            const merged = {
              ...ctx.inputs,
              ...substituted
            };
            try {
              const subject = formula(merged);
              return {
                subject,
                inputs: {
                  ...merged,
                  ...auxiliary
                },
                reevaluate
              };
            } catch (e) {
              // The subject errored over the substituted inputs — a data-shape mismatch
              // between the fixture and the formula, which is exactly what the test
              // should report.
              return {
                subject: null,
                inputs: {
                  ...merged,
                  ...auxiliary
                },
                error: `subject errored over substituted inputs: ${e.message}`
              };
            }
          });
        } catch (e) {
          // A test's own machinery threw (not a plain assertion failure) — every outcome
          // records the error; the suite still settles with a verdict.
          suite = {
            outcomes: tests.map(t => ({
              test: t.def,
              result: {
                pass: false,
                message: `suite crashed: ${e.message}`
              }
            })),
            verdict: 'failing'
          };
        }
        out.push({
          subject: ctx.subject,
          verdict: suite.verdict,
          outcomes: suite.outcomes.map(o => ({
            id: tests.find(t => t.def === o.test)?.id ?? o.test.subject,
            kind: o.test.testKind,
            pass: o.result.pass,
            message: o.result.message
          }))
        });
      }
      return out;
    }
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJzdGRsaWIiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsInJlcXVpcmUiLCJfY29tcGFydG1lbnQiLCJfZ3JhcGgiLCJfY3ljbGVzIiwiX3Rlc3RydW5uZXIiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJjcmVhdGVFbmdpbmVXb3JrZXIiLCJmb3JtdWxhcyIsIk1hcCIsInRlc3RzQnlTdWJqZWN0IiwiYnVpbGQiLCJzb3VyY2VzIiwiY2xlYXIiLCJjZWxsV29ya2Jvb2siLCJ0ZXN0cyIsInNwYW5zQnlJZCIsIndvcmtzaGVldCIsInNvdXJjZSIsImVudHJpZXMiLCJkZWZzIiwiZXZhbHVhdGVXb3Jrc2hlZXQiLCJzcGFucyIsImV4cG9ydFNwYW5zIiwic2hlZXQiLCJuYW1lIiwiZGVmIiwidW5kZWZpbmVkIiwia2luZCIsImZvcm11bGEiLCJpZCIsInB1c2giLCJ0ZXN0S2luZCIsInN1YmplY3QiLCJzcGFuIiwiaW5wdXRzIiwibGlzdCIsImdyYXBoIiwiYnVpbGRHcmFwaCIsIm9yZGVyIiwiY3ljbGVzIiwiYW5hbHl6ZSIsImNlbGxzIiwibm9kZXMiLCJ2YWx1ZXMiLCJtYXAiLCJjZWxsIiwiZG9jIiwiZm9ybXVsYVNvdXJjZSIsInRvU3RyaW5nIiwiZGVwcyIsImV4dGVybmFscyIsInJlc29sdmVycyIsIndvcmtzaGVldHMiLCJleHRlcm5hbElucHV0cyIsImRpYWdub3N0aWNzIiwiZXZhbCIsIkVycm9yIiwicnVuU3VpdGVzIiwic3VpdGVzIiwib3V0IiwiY3R4Iiwic3VpdGUiLCJydW5TdWl0ZSIsInJlZXZhbHVhdGUiLCJmaW5kIiwiZW50cnkiLCJlcnJvciIsInN1YmplY3RWYWx1ZSIsInN1YnN0aXR1dGVkIiwiYXV4aWxpYXJ5IiwidmFsdWUiLCJrZXlzIiwibGVuZ3RoIiwibWVyZ2VkIiwibWVzc2FnZSIsIm91dGNvbWVzIiwidGVzdCIsInJlc3VsdCIsInBhc3MiLCJ2ZXJkaWN0IiwibyJdLCJzb3VyY2VzIjpbImVuZ2luZVdvcmtlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgd29ya2VyJ3MgZm9ybXVsYSBleGVjdXRvciAoQVJDSElURUNUVVJFX1BMQU4gwqc0KS4gRnJhbWV3b3JrLWZyZWUgc28gaXQgaXMgZHJpdmVuIGJ5IGFuXG4vLyBpbi1tZW1vcnkgdHJhbnNwb3J0IGluIHRlc3RzIGFuZCBieSBhIHJlYWwgV2ViIFdvcmtlciBpbiBwcm9kdWN0aW9uIChzcmMvZW50cnkvZW5naW5lLnRzKS5cbi8vIEl0IGJ1aWxkcyBvbmUgU0VTIENvbXBhcnRtZW50IHBlciB3b3Jrc2hlZXQgKHZpYSBgZXZhbHVhdGVXb3Jrc2hlZXRgKSwga2VlcHMgdGhlIHJlZ2lzdGVyZWRcbi8vIGNlbGwgKipmb3JtdWxhcyoqIGhlcmUgKHRoZXkgYXJlIGNsb3N1cmVzIOKAlCBuZXZlciBzZXJpYWxpemFibGUsIG5ldmVyIGNyb3NzIHRoZSBib3VuZGFyeSksXG4vLyBhbmQgcmV0dXJucyB0aGUgaG9zdCBhIHNlcmlhbGl6YWJsZSB7QGxpbmsgV29ya2Jvb2tEZXNjcmlwdG9yfSB0byBzY2hlZHVsZSBvdmVyLiBgZXZhbGAgcnVuc1xuLy8gb25lIGNlbGwncyBmb3JtdWxhIGFnYWluc3QgaG9zdC1yZXNvbHZlZCBpbnB1dHMuIFB1cml0eSBtYWtlcyByZS1ldmFsdWF0aW9uIHNvdW5kLlxuLy9cbi8vIE9ubHkgKmNlbGxzKiBlbnRlciB0aGUgdmFsdWUgZ3JhcGg7IHRlc3QgY2VsbHMgYXJlIGtlcHQgaGVyZSAodGhlaXIgYGV4cGVjdGAvYHJlbGF0aW9uYFxuLy8gY2xvc3VyZXMgbGl2ZSBpbiB0aGlzIHJlYWxtKSBhbmQgcnVuIHZpYSBgcnVuU3VpdGVzYCBvdmVyIGhvc3QtY29tcHV0ZWQgY29udGV4dHMg4oCUIHRoZVxuLy8gcmV2aWV3IHN1cmZhY2UncyBleGVjdXRpb24gcGF0aCAowqc2KSwgbmV2ZXIgdGhlIHJlcG9ydC1yZW5kZXIgcGlwZWxpbmUuXG5cbmltcG9ydCAqIGFzIHN0ZGxpYiBmcm9tICcuLi8uLi9zdGRsaWIvaW5kZXgudHMnO1xuaW1wb3J0IHR5cGUgeyBWYWx1ZSB9IGZyb20gJy4uLy4uL3N0ZGxpYi90eXBlcy50cyc7XG5pbXBvcnQgdHlwZSB7IENlbGxEZWYsIEZvcm11bGEsIFRlc3RDZWxsRGVmIH0gZnJvbSAnLi4vLi4vc3RkbGliL2NlbGwudHMnO1xuaW1wb3J0IHR5cGUgeyBXb3JrYm9vayB9IGZyb20gJy4uL3R5cGVzLnRzJztcbmltcG9ydCB7IGV2YWx1YXRlV29ya3NoZWV0LCBleHBvcnRTcGFucyB9IGZyb20gJy4uL2NvbXBhcnRtZW50LnRzJztcbmltcG9ydCB0eXBlIHsgRXhwb3J0U3BhbiB9IGZyb20gJy4uL2NvbXBhcnRtZW50LnRzJztcbmltcG9ydCB7IGJ1aWxkR3JhcGggfSBmcm9tICcuLi9ncmFwaC50cyc7XG5pbXBvcnQgeyBhbmFseXplIH0gZnJvbSAnLi4vY3ljbGVzLnRzJztcbmltcG9ydCB7IHJ1blN1aXRlIH0gZnJvbSAnLi4vdGVzdHJ1bm5lci50cyc7XG5pbXBvcnQgdHlwZSB7IFN1aXRlUmVzdWx0IH0gZnJvbSAnLi4vdGVzdHJ1bm5lci50cyc7XG5pbXBvcnQgdHlwZSB7XG4gIFN1YmplY3RSZXN1bHQsXG4gIFN1aXRlQ29udGV4dCxcbiAgV29ya2Jvb2tEZXNjcmlwdG9yLFxufSBmcm9tICcuL3Byb3RvY29sLnRzJztcblxuZXhwb3J0IGludGVyZmFjZSBFbmdpbmVXb3JrZXIge1xuICBidWlsZChzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogV29ya2Jvb2tEZXNjcmlwdG9yO1xuICAvKiogUnVuIG9uZSBjZWxsJ3MgZm9ybXVsYS4gQSBmb3JtdWxhIG1heSBiZSBhc3luYyAowqc0LjEpIOKAlCB0aGUgY2FsbGVyIGF3YWl0cyB0aGUgcmVzdWx0LiAqL1xuICBldmFsKGlkOiBzdHJpbmcsIGlucHV0czogUmVjb3JkPHN0cmluZywgVmFsdWU+KTogVmFsdWUgfCBQcm9taXNlPFZhbHVlPjtcbiAgLyoqXG4gICAqIFJ1biBldmVyeSB0ZXN0IHN1aXRlIG92ZXIgaG9zdC1jb21wdXRlZCBjb250ZXh0cyAodGhlIHN1YmplY3QncyBzZXR0bGVkIHZhbHVlICsgcmVzb2x2ZWRcbiAgICogaW5wdXRzKSwgcmV0dXJuaW5nIHRoZSBzZXJpYWxpemFibGUgdmVyZGljdHMuIFRoZSBgcmVldmFsdWF0ZWAgcG9ydCBmb3IgbWV0YW1vcnBoaWNcbiAgICogaW52YXJpYW5jZSByZWxhdGlvbnMgcnVucyB0aGUgc3ViamVjdCBmb3JtdWxhIGhlcmUg4oCUIGl0IGlzIGEgY2xvc3VyZSB0aGF0IGNhbm5vdCBjcm9zcy5cbiAgICovXG4gIHJ1blN1aXRlcyhzdWl0ZXM6IHJlYWRvbmx5IFN1aXRlQ29udGV4dFtdKTogU3ViamVjdFJlc3VsdFtdO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRW5naW5lV29ya2VyKCk6IEVuZ2luZVdvcmtlciB7XG4gIGNvbnN0IGZvcm11bGFzID0gbmV3IE1hcDxzdHJpbmcsIEZvcm11bGE+KCk7XG4gIC8vIFN1YmplY3Qg4oaSIGl0cyB0ZXN0cywgZWFjaCB3aXRoIHRoZSBleHBvcnQgbmFtZSAodGhlIGRlZiBpdHNlbGYgZG9lcyBub3QgY2Fycnkgb25lIGJhY2tcbiAgLy8gb3V0IG9mIHRoZSBjb21wYXJ0bWVudCByZWdpc3RyeSkuXG4gIGNvbnN0IHRlc3RzQnlTdWJqZWN0ID0gbmV3IE1hcDxzdHJpbmcsIHsgaWQ6IHN0cmluZzsgZGVmOiBUZXN0Q2VsbERlZiB9W10+KCk7XG5cbiAgcmV0dXJuIHtcbiAgICBidWlsZChzb3VyY2VzKSB7XG4gICAgICBmb3JtdWxhcy5jbGVhcigpO1xuICAgICAgdGVzdHNCeVN1YmplY3QuY2xlYXIoKTtcbiAgICAgIGNvbnN0IGNlbGxXb3JrYm9vazogV29ya2Jvb2sgPSB7fTtcbiAgICAgIGNvbnN0IHRlc3RzOiBXb3JrYm9va0Rlc2NyaXB0b3JbJ3Rlc3RzJ10gPSBbXTtcbiAgICAgIC8vIFBlci1jZWxsIGRlY2xhcmF0aW9uIHNwYW5zLCBjb21wdXRlZCBvbiB0aGUgUkFXIHNvdXJjZSAoUjMtNDI3KTogdGhlIHdoYXQtaWZcbiAgICAgIC8vIHNwbGljZSBwYXRjaGVzIHdpdGhpbiBhIGNlbGwncyBvd24gYmxvY2ssIGFuZCByZXZpZXcgc3VyZmFjZXMgc2hvdyBmaWxlOmxpbmUuXG4gICAgICBjb25zdCBzcGFuc0J5SWQgPSBuZXcgTWFwPHN0cmluZywgRXhwb3J0U3Bhbj4oKTtcbiAgICAgIGZvciAoY29uc3QgW3dvcmtzaGVldCwgc291cmNlXSBvZiBPYmplY3QuZW50cmllcyhzb3VyY2VzKSkge1xuICAgICAgICBjb25zdCBkZWZzID0gZXZhbHVhdGVXb3Jrc2hlZXQoc291cmNlLCB7IC4uLnN0ZGxpYiB9KTtcbiAgICAgICAgY29uc3Qgc3BhbnMgPSBleHBvcnRTcGFucyhzb3VyY2UpO1xuICAgICAgICBjb25zdCBzaGVldDogUmVjb3JkPHN0cmluZywgQ2VsbERlZj4gPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBbbmFtZSwgZGVmXSBvZiBPYmplY3QuZW50cmllcyhkZWZzKSkge1xuICAgICAgICAgIGlmIChzcGFuc1tuYW1lXSAhPT0gdW5kZWZpbmVkKSBzcGFuc0J5SWQuc2V0KGAke3dvcmtzaGVldH0uJHtuYW1lfWAsIHNwYW5zW25hbWVdKTtcbiAgICAgICAgICBpZiAoZGVmLmtpbmQgPT09ICdjZWxsJykge1xuICAgICAgICAgICAgc2hlZXRbbmFtZV0gPSBkZWY7XG4gICAgICAgICAgICBmb3JtdWxhcy5zZXQoYCR7d29ya3NoZWV0fS4ke25hbWV9YCwgZGVmLmZvcm11bGEpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpZCA9IGAke3dvcmtzaGVldH0uJHtuYW1lfWA7XG4gICAgICAgICAgICB0ZXN0cy5wdXNoKHsgaWQsIHdvcmtzaGVldCwgbmFtZSwga2luZDogZGVmLnRlc3RLaW5kLCBzdWJqZWN0OiBkZWYuc3ViamVjdCwgc3Bhbjogc3BhbnNbbmFtZV0sIGlucHV0czogZGVmLmlucHV0cyB9KTtcbiAgICAgICAgICAgIGNvbnN0IGxpc3QgPSB0ZXN0c0J5U3ViamVjdC5nZXQoZGVmLnN1YmplY3QpID8/IFtdO1xuICAgICAgICAgICAgbGlzdC5wdXNoKHsgaWQsIGRlZiB9KTtcbiAgICAgICAgICAgIHRlc3RzQnlTdWJqZWN0LnNldChkZWYuc3ViamVjdCwgbGlzdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNlbGxXb3JrYm9va1t3b3Jrc2hlZXRdID0gc2hlZXQ7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGdyYXBoID0gYnVpbGRHcmFwaChjZWxsV29ya2Jvb2spO1xuICAgICAgY29uc3QgeyBvcmRlciwgY3ljbGVzIH0gPSBhbmFseXplKGdyYXBoKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC8vIFRoZSB3b3JrYm9vayBwYXNzZWQgdG8gYnVpbGRHcmFwaCBob2xkcyBvbmx5IGBjZWxsYCBkZWZzICh0ZXN0cyB3ZXJlIGRpdmVydGVkXG4gICAgICAgIC8vIGFib3ZlKSwgc28gZXZlcnkgbm9kZSdzIGRlZiBpcyBhIENlbGxEZWYgY2FycnlpbmcgYSBgZG9jYC5cbiAgICAgICAgY2VsbHM6IFsuLi5ncmFwaC5ub2Rlcy52YWx1ZXMoKV0ubWFwKChuKSA9PiAoe1xuICAgICAgICAgIGlkOiBuLmlkLFxuICAgICAgICAgIHdvcmtzaGVldDogbi53b3Jrc2hlZXQsXG4gICAgICAgICAgY2VsbDogbi5jZWxsLFxuICAgICAgICAgIGRvYzogbi5kZWYua2luZCA9PT0gJ2NlbGwnID8gbi5kZWYuZG9jIDogJycsXG4gICAgICAgICAgLy8gVGhlIGZvcm11bGEgaXRzZWxmIHN0YXlzIGluIHRoZSB3b3JrZXI7IGl0cyBzb3VyY2UgdGV4dCBjcm9zc2VzIGZvciB0aGUgdmFsdWVcbiAgICAgICAgICAvLyBpbnNwZWN0b3IncyByZWFkLW9ubHkgZGlzcGxheS4gU0VTIHByZXNlcnZlcyBmdW5jdGlvbiBzb3VyY2VzIGFjcm9zcyBsb2NrZG93bi5cbiAgICAgICAgICBmb3JtdWxhU291cmNlOiBuLmRlZi5raW5kID09PSAnY2VsbCcgPyBuLmRlZi5mb3JtdWxhLnRvU3RyaW5nKCkgOiAnJyxcbiAgICAgICAgICBzcGFuOiBzcGFuc0J5SWQuZ2V0KG4uaWQpLFxuICAgICAgICAgIGRlcHM6IG4uZGVwcyxcbiAgICAgICAgICBleHRlcm5hbHM6IG4uZXh0ZXJuYWxzLFxuICAgICAgICAgIHJlc29sdmVyczogbi5yZXNvbHZlcnMsXG4gICAgICAgIH0pKSxcbiAgICAgICAgdGVzdHMsXG4gICAgICAgIHdvcmtzaGVldHM6IFsuLi5ncmFwaC53b3Jrc2hlZXRzXSxcbiAgICAgICAgZXh0ZXJuYWxJbnB1dHM6IFsuLi5ncmFwaC5leHRlcm5hbElucHV0c10sXG4gICAgICAgIG9yZGVyLFxuICAgICAgICBjeWNsZXMsXG4gICAgICAgIGRpYWdub3N0aWNzOiBncmFwaC5kaWFnbm9zdGljcyxcbiAgICAgIH07XG4gICAgfSxcblxuICAgIGV2YWwoaWQsIGlucHV0cykge1xuICAgICAgY29uc3QgZm9ybXVsYSA9IGZvcm11bGFzLmdldChpZCk7XG4gICAgICBpZiAoZm9ybXVsYSA9PT0gdW5kZWZpbmVkKSB0aHJvdyBuZXcgRXJyb3IoYHVua25vd24gY2VsbCBcIiR7aWR9XCJgKTtcbiAgICAgIHJldHVybiBmb3JtdWxhKGlucHV0cyk7XG4gICAgfSxcblxuICAgIHJ1blN1aXRlcyhzdWl0ZXMpIHtcbiAgICAgIGNvbnN0IG91dDogU3ViamVjdFJlc3VsdFtdID0gW107XG4gICAgICBmb3IgKGNvbnN0IGN0eCBvZiBzdWl0ZXMpIHtcbiAgICAgICAgY29uc3QgdGVzdHMgPSB0ZXN0c0J5U3ViamVjdC5nZXQoY3R4LnN1YmplY3QpID8/IFtdO1xuICAgICAgICBsZXQgc3VpdGU6IFN1aXRlUmVzdWx0O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHN1aXRlID0gcnVuU3VpdGUodGVzdHMubWFwKCh0KSA9PiB0LmRlZiksIChkZWYpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm11bGEgPSBmb3JtdWxhcy5nZXQoY3R4LnN1YmplY3QpO1xuICAgICAgICAgICAgY29uc3QgcmVldmFsdWF0ZSA9XG4gICAgICAgICAgICAgIGZvcm11bGEgPT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgOiAoaW5wdXRzOiBSZWNvcmQ8c3RyaW5nLCBWYWx1ZT4pOiBWYWx1ZSA9PiBmb3JtdWxhKGlucHV0cyk7XG4gICAgICAgICAgICBjb25zdCBpZCA9IHRlc3RzLmZpbmQoKHQpID0+IHQuZGVmID09PSBkZWYpPy5pZDtcbiAgICAgICAgICAgIGNvbnN0IGVudHJ5ID0gaWQgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IGN0eC50ZXN0cz8uZmluZCgodCkgPT4gdC5pZCA9PT0gaWQpO1xuICAgICAgICAgICAgaWYgKGVudHJ5ICE9PSB1bmRlZmluZWQgJiYgZW50cnkuZXJyb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICByZXR1cm4geyBzdWJqZWN0OiBjdHguc3ViamVjdFZhbHVlLCBpbnB1dHM6IGN0eC5pbnB1dHMsIGVycm9yOiBlbnRyeS5lcnJvciB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGVudHJ5ID09PSB1bmRlZmluZWQgfHwgZW50cnkuaW5wdXRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgLy8gTm8gZGVjbGFyZWQgaW5wdXRzIHJlc29sdmVkIGZvciB0aGlzIHRlc3Qg4oCUIHRoZSBsaXZlIGNvbnRleHQsIGFzIGJlZm9yZS5cbiAgICAgICAgICAgICAgcmV0dXJuIHsgc3ViamVjdDogY3R4LnN1YmplY3RWYWx1ZSwgaW5wdXRzOiBjdHguaW5wdXRzLCByZWV2YWx1YXRlIH07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFIzLTM3MzogbmFtZS1tYXRjaGVkIGVudHJpZXMgU1VCU1RJVFVUZSBmb3IgdGhlIHN1YmplY3QncyBsaXZlIGlucHV0cyAodGhlXG4gICAgICAgICAgICAvLyBzdWJqZWN0IGZvcm11bGEgcmUtcnVucyBvdmVyIHRoZSBtZXJnZWQgc2V0IOKAlCB0aGUgaG9sZG91dCBwYXR0ZXJuKTtcbiAgICAgICAgICAgIC8vIG5hbWUtdW5tYXRjaGVkIGVudHJpZXMgYXJlIEFVWElMSUFSWSBjb250ZXh0IGZvciBleHBlY3QvcmVsYXRpb24gb25seVxuICAgICAgICAgICAgLy8gKGFuIG9yYWNsZSBmaXh0dXJlKSBhbmQgbmV2ZXIgZmVlZCB0aGUgZm9ybXVsYS5cbiAgICAgICAgICAgIGNvbnN0IHN1YnN0aXR1dGVkOiBSZWNvcmQ8c3RyaW5nLCBWYWx1ZT4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IGF1eGlsaWFyeTogUmVjb3JkPHN0cmluZywgVmFsdWU+ID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZW50cnkuaW5wdXRzKSkge1xuICAgICAgICAgICAgICBpZiAobmFtZSBpbiBjdHguaW5wdXRzKSBzdWJzdGl0dXRlZFtuYW1lXSA9IHZhbHVlO1xuICAgICAgICAgICAgICBlbHNlIGF1eGlsaWFyeVtuYW1lXSA9IHZhbHVlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoc3Vic3RpdHV0ZWQpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICByZXR1cm4geyBzdWJqZWN0OiBjdHguc3ViamVjdFZhbHVlLCBpbnB1dHM6IHsgLi4uY3R4LmlucHV0cywgLi4uYXV4aWxpYXJ5IH0sIHJlZXZhbHVhdGUgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IG1lcmdlZCA9IHsgLi4uY3R4LmlucHV0cywgLi4uc3Vic3RpdHV0ZWQgfTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGNvbnN0IHN1YmplY3QgPSBmb3JtdWxhIShtZXJnZWQpO1xuICAgICAgICAgICAgICByZXR1cm4geyBzdWJqZWN0LCBpbnB1dHM6IHsgLi4ubWVyZ2VkLCAuLi5hdXhpbGlhcnkgfSwgcmVldmFsdWF0ZSB9O1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAvLyBUaGUgc3ViamVjdCBlcnJvcmVkIG92ZXIgdGhlIHN1YnN0aXR1dGVkIGlucHV0cyDigJQgYSBkYXRhLXNoYXBlIG1pc21hdGNoXG4gICAgICAgICAgICAgIC8vIGJldHdlZW4gdGhlIGZpeHR1cmUgYW5kIHRoZSBmb3JtdWxhLCB3aGljaCBpcyBleGFjdGx5IHdoYXQgdGhlIHRlc3RcbiAgICAgICAgICAgICAgLy8gc2hvdWxkIHJlcG9ydC5cbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBzdWJqZWN0OiBudWxsLFxuICAgICAgICAgICAgICAgIGlucHV0czogeyAuLi5tZXJnZWQsIC4uLmF1eGlsaWFyeSB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiBgc3ViamVjdCBlcnJvcmVkIG92ZXIgc3Vic3RpdHV0ZWQgaW5wdXRzOiAkeyhlIGFzIEVycm9yKS5tZXNzYWdlfWAsXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBBIHRlc3QncyBvd24gbWFjaGluZXJ5IHRocmV3IChub3QgYSBwbGFpbiBhc3NlcnRpb24gZmFpbHVyZSkg4oCUIGV2ZXJ5IG91dGNvbWVcbiAgICAgICAgICAvLyByZWNvcmRzIHRoZSBlcnJvcjsgdGhlIHN1aXRlIHN0aWxsIHNldHRsZXMgd2l0aCBhIHZlcmRpY3QuXG4gICAgICAgICAgc3VpdGUgPSB7XG4gICAgICAgICAgICBvdXRjb21lczogdGVzdHMubWFwKCh0KSA9PiAoeyB0ZXN0OiB0LmRlZiwgcmVzdWx0OiB7IHBhc3M6IGZhbHNlLCBtZXNzYWdlOiBgc3VpdGUgY3Jhc2hlZDogJHsoZSBhcyBFcnJvcikubWVzc2FnZX1gIH0gfSkpLFxuICAgICAgICAgICAgdmVyZGljdDogJ2ZhaWxpbmcnLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgb3V0LnB1c2goe1xuICAgICAgICAgIHN1YmplY3Q6IGN0eC5zdWJqZWN0LFxuICAgICAgICAgIHZlcmRpY3Q6IHN1aXRlLnZlcmRpY3QsXG4gICAgICAgICAgb3V0Y29tZXM6IHN1aXRlLm91dGNvbWVzLm1hcCgobykgPT4gKHtcbiAgICAgICAgICAgIGlkOiB0ZXN0cy5maW5kKCh0KSA9PiB0LmRlZiA9PT0gby50ZXN0KT8uaWQgPz8gby50ZXN0LnN1YmplY3QsXG4gICAgICAgICAgICBraW5kOiBvLnRlc3QudGVzdEtpbmQsXG4gICAgICAgICAgICBwYXNzOiBvLnJlc3VsdC5wYXNzLFxuICAgICAgICAgICAgbWVzc2FnZTogby5yZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICB9KSksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG91dDtcbiAgICB9LFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFXQSxJQUFBQSxNQUFBLEdBQUFDLHVCQUFBLENBQUFDLE9BQUE7QUFJQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBNEMsU0FBQUsseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQVAsd0JBQUFPLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxVQUFBLFNBQUFKLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBSyxPQUFBLEVBQUFMLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBRyxHQUFBLENBQUFOLENBQUEsVUFBQUcsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsT0FBQVEsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZCxDQUFBLG9CQUFBYyxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBaEIsQ0FBQSxFQUFBYyxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFiLENBQUEsRUFBQWMsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZCxDQUFBLENBQUFjLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFMLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFlLEdBQUEsQ0FBQWxCLENBQUEsRUFBQVEsQ0FBQSxHQUFBQSxDQUFBO0FBbkI1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUE4Qk8sU0FBU1csa0JBQWtCQSxDQUFBLEVBQWlCO0VBQ2pELE1BQU1DLFFBQVEsR0FBRyxJQUFJQyxHQUFHLENBQWtCLENBQUM7RUFDM0M7RUFDQTtFQUNBLE1BQU1DLGNBQWMsR0FBRyxJQUFJRCxHQUFHLENBQTZDLENBQUM7RUFFNUUsT0FBTztJQUNMRSxLQUFLQSxDQUFDQyxPQUFPLEVBQUU7TUFDYkosUUFBUSxDQUFDSyxLQUFLLENBQUMsQ0FBQztNQUNoQkgsY0FBYyxDQUFDRyxLQUFLLENBQUMsQ0FBQztNQUN0QixNQUFNQyxZQUFzQixHQUFHLENBQUMsQ0FBQztNQUNqQyxNQUFNQyxLQUFrQyxHQUFHLEVBQUU7TUFDN0M7TUFDQTtNQUNBLE1BQU1DLFNBQVMsR0FBRyxJQUFJUCxHQUFHLENBQXFCLENBQUM7TUFDL0MsS0FBSyxNQUFNLENBQUNRLFNBQVMsRUFBRUMsTUFBTSxDQUFDLElBQUluQixNQUFNLENBQUNvQixPQUFPLENBQUNQLE9BQU8sQ0FBQyxFQUFFO1FBQ3pELE1BQU1RLElBQUksR0FBRyxJQUFBQyw4QkFBaUIsRUFBQ0gsTUFBTSxFQUFFO1VBQUUsR0FBR3RDO1FBQU8sQ0FBQyxDQUFDO1FBQ3JELE1BQU0wQyxLQUFLLEdBQUcsSUFBQUMsd0JBQVcsRUFBQ0wsTUFBTSxDQUFDO1FBQ2pDLE1BQU1NLEtBQThCLEdBQUcsQ0FBQyxDQUFDO1FBQ3pDLEtBQUssTUFBTSxDQUFDQyxJQUFJLEVBQUVDLEdBQUcsQ0FBQyxJQUFJM0IsTUFBTSxDQUFDb0IsT0FBTyxDQUFDQyxJQUFJLENBQUMsRUFBRTtVQUM5QyxJQUFJRSxLQUFLLENBQUNHLElBQUksQ0FBQyxLQUFLRSxTQUFTLEVBQUVYLFNBQVMsQ0FBQ1YsR0FBRyxDQUFDLEdBQUdXLFNBQVMsSUFBSVEsSUFBSSxFQUFFLEVBQUVILEtBQUssQ0FBQ0csSUFBSSxDQUFDLENBQUM7VUFDakYsSUFBSUMsR0FBRyxDQUFDRSxJQUFJLEtBQUssTUFBTSxFQUFFO1lBQ3ZCSixLQUFLLENBQUNDLElBQUksQ0FBQyxHQUFHQyxHQUFHO1lBQ2pCbEIsUUFBUSxDQUFDRixHQUFHLENBQUMsR0FBR1csU0FBUyxJQUFJUSxJQUFJLEVBQUUsRUFBRUMsR0FBRyxDQUFDRyxPQUFPLENBQUM7VUFDbkQsQ0FBQyxNQUFNO1lBQ0wsTUFBTUMsRUFBRSxHQUFHLEdBQUdiLFNBQVMsSUFBSVEsSUFBSSxFQUFFO1lBQ2pDVixLQUFLLENBQUNnQixJQUFJLENBQUM7Y0FBRUQsRUFBRTtjQUFFYixTQUFTO2NBQUVRLElBQUk7Y0FBRUcsSUFBSSxFQUFFRixHQUFHLENBQUNNLFFBQVE7Y0FBRUMsT0FBTyxFQUFFUCxHQUFHLENBQUNPLE9BQU87Y0FBRUMsSUFBSSxFQUFFWixLQUFLLENBQUNHLElBQUksQ0FBQztjQUFFVSxNQUFNLEVBQUVULEdBQUcsQ0FBQ1M7WUFBTyxDQUFDLENBQUM7WUFDcEgsTUFBTUMsSUFBSSxHQUFHMUIsY0FBYyxDQUFDZixHQUFHLENBQUMrQixHQUFHLENBQUNPLE9BQU8sQ0FBQyxJQUFJLEVBQUU7WUFDbERHLElBQUksQ0FBQ0wsSUFBSSxDQUFDO2NBQUVELEVBQUU7Y0FBRUo7WUFBSSxDQUFDLENBQUM7WUFDdEJoQixjQUFjLENBQUNKLEdBQUcsQ0FBQ29CLEdBQUcsQ0FBQ08sT0FBTyxFQUFFRyxJQUFJLENBQUM7VUFDdkM7UUFDRjtRQUNBdEIsWUFBWSxDQUFDRyxTQUFTLENBQUMsR0FBR08sS0FBSztNQUNqQztNQUVBLE1BQU1hLEtBQUssR0FBRyxJQUFBQyxpQkFBVSxFQUFDeEIsWUFBWSxDQUFDO01BQ3RDLE1BQU07UUFBRXlCLEtBQUs7UUFBRUM7TUFBTyxDQUFDLEdBQUcsSUFBQUMsZUFBTyxFQUFDSixLQUFLLENBQUM7TUFDeEMsT0FBTztRQUNMO1FBQ0E7UUFDQUssS0FBSyxFQUFFLENBQUMsR0FBR0wsS0FBSyxDQUFDTSxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFakQsQ0FBQyxLQUFNO1VBQzNDa0MsRUFBRSxFQUFFbEMsQ0FBQyxDQUFDa0MsRUFBRTtVQUNSYixTQUFTLEVBQUVyQixDQUFDLENBQUNxQixTQUFTO1VBQ3RCNkIsSUFBSSxFQUFFbEQsQ0FBQyxDQUFDa0QsSUFBSTtVQUNaQyxHQUFHLEVBQUVuRCxDQUFDLENBQUM4QixHQUFHLENBQUNFLElBQUksS0FBSyxNQUFNLEdBQUdoQyxDQUFDLENBQUM4QixHQUFHLENBQUNxQixHQUFHLEdBQUcsRUFBRTtVQUMzQztVQUNBO1VBQ0FDLGFBQWEsRUFBRXBELENBQUMsQ0FBQzhCLEdBQUcsQ0FBQ0UsSUFBSSxLQUFLLE1BQU0sR0FBR2hDLENBQUMsQ0FBQzhCLEdBQUcsQ0FBQ0csT0FBTyxDQUFDb0IsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFO1VBQ3BFZixJQUFJLEVBQUVsQixTQUFTLENBQUNyQixHQUFHLENBQUNDLENBQUMsQ0FBQ2tDLEVBQUUsQ0FBQztVQUN6Qm9CLElBQUksRUFBRXRELENBQUMsQ0FBQ3NELElBQUk7VUFDWkMsU0FBUyxFQUFFdkQsQ0FBQyxDQUFDdUQsU0FBUztVQUN0QkMsU0FBUyxFQUFFeEQsQ0FBQyxDQUFDd0Q7UUFDZixDQUFDLENBQUMsQ0FBQztRQUNIckMsS0FBSztRQUNMc0MsVUFBVSxFQUFFLENBQUMsR0FBR2hCLEtBQUssQ0FBQ2dCLFVBQVUsQ0FBQztRQUNqQ0MsY0FBYyxFQUFFLENBQUMsR0FBR2pCLEtBQUssQ0FBQ2lCLGNBQWMsQ0FBQztRQUN6Q2YsS0FBSztRQUNMQyxNQUFNO1FBQ05lLFdBQVcsRUFBRWxCLEtBQUssQ0FBQ2tCO01BQ3JCLENBQUM7SUFDSCxDQUFDO0lBRURDLElBQUlBLENBQUMxQixFQUFFLEVBQUVLLE1BQU0sRUFBRTtNQUNmLE1BQU1OLE9BQU8sR0FBR3JCLFFBQVEsQ0FBQ2IsR0FBRyxDQUFDbUMsRUFBRSxDQUFDO01BQ2hDLElBQUlELE9BQU8sS0FBS0YsU0FBUyxFQUFFLE1BQU0sSUFBSThCLEtBQUssQ0FBQyxpQkFBaUIzQixFQUFFLEdBQUcsQ0FBQztNQUNsRSxPQUFPRCxPQUFPLENBQUNNLE1BQU0sQ0FBQztJQUN4QixDQUFDO0lBRUR1QixTQUFTQSxDQUFDQyxNQUFNLEVBQUU7TUFDaEIsTUFBTUMsR0FBb0IsR0FBRyxFQUFFO01BQy9CLEtBQUssTUFBTUMsR0FBRyxJQUFJRixNQUFNLEVBQUU7UUFDeEIsTUFBTTVDLEtBQUssR0FBR0wsY0FBYyxDQUFDZixHQUFHLENBQUNrRSxHQUFHLENBQUM1QixPQUFPLENBQUMsSUFBSSxFQUFFO1FBQ25ELElBQUk2QixLQUFrQjtRQUN0QixJQUFJO1VBQ0ZBLEtBQUssR0FBRyxJQUFBQyxvQkFBUSxFQUFDaEQsS0FBSyxDQUFDOEIsR0FBRyxDQUFFdEQsQ0FBQyxJQUFLQSxDQUFDLENBQUNtQyxHQUFHLENBQUMsRUFBR0EsR0FBRyxJQUFLO1lBQ2pELE1BQU1HLE9BQU8sR0FBR3JCLFFBQVEsQ0FBQ2IsR0FBRyxDQUFDa0UsR0FBRyxDQUFDNUIsT0FBTyxDQUFDO1lBQ3pDLE1BQU0rQixVQUFVLEdBQ2RuQyxPQUFPLEtBQUtGLFNBQVMsR0FDakJBLFNBQVMsR0FDUlEsTUFBNkIsSUFBWU4sT0FBTyxDQUFDTSxNQUFNLENBQUM7WUFDL0QsTUFBTUwsRUFBRSxHQUFHZixLQUFLLENBQUNrRCxJQUFJLENBQUUxRSxDQUFDLElBQUtBLENBQUMsQ0FBQ21DLEdBQUcsS0FBS0EsR0FBRyxDQUFDLEVBQUVJLEVBQUU7WUFDL0MsTUFBTW9DLEtBQUssR0FBR3BDLEVBQUUsS0FBS0gsU0FBUyxHQUFHQSxTQUFTLEdBQUdrQyxHQUFHLENBQUM5QyxLQUFLLEVBQUVrRCxJQUFJLENBQUUxRSxDQUFDLElBQUtBLENBQUMsQ0FBQ3VDLEVBQUUsS0FBS0EsRUFBRSxDQUFDO1lBQ2hGLElBQUlvQyxLQUFLLEtBQUt2QyxTQUFTLElBQUl1QyxLQUFLLENBQUNDLEtBQUssS0FBS3hDLFNBQVMsRUFBRTtjQUNwRCxPQUFPO2dCQUFFTSxPQUFPLEVBQUU0QixHQUFHLENBQUNPLFlBQVk7Z0JBQUVqQyxNQUFNLEVBQUUwQixHQUFHLENBQUMxQixNQUFNO2dCQUFFZ0MsS0FBSyxFQUFFRCxLQUFLLENBQUNDO2NBQU0sQ0FBQztZQUM5RTtZQUNBLElBQUlELEtBQUssS0FBS3ZDLFNBQVMsSUFBSXVDLEtBQUssQ0FBQy9CLE1BQU0sS0FBS1IsU0FBUyxFQUFFO2NBQ3JEO2NBQ0EsT0FBTztnQkFBRU0sT0FBTyxFQUFFNEIsR0FBRyxDQUFDTyxZQUFZO2dCQUFFakMsTUFBTSxFQUFFMEIsR0FBRyxDQUFDMUIsTUFBTTtnQkFBRTZCO2NBQVcsQ0FBQztZQUN0RTs7WUFFQTtZQUNBO1lBQ0E7WUFDQTtZQUNBLE1BQU1LLFdBQWtDLEdBQUcsQ0FBQyxDQUFDO1lBQzdDLE1BQU1DLFNBQWdDLEdBQUcsQ0FBQyxDQUFDO1lBQzNDLEtBQUssTUFBTSxDQUFDN0MsSUFBSSxFQUFFOEMsS0FBSyxDQUFDLElBQUl4RSxNQUFNLENBQUNvQixPQUFPLENBQUMrQyxLQUFLLENBQUMvQixNQUFNLENBQUMsRUFBRTtjQUN4RCxJQUFJVixJQUFJLElBQUlvQyxHQUFHLENBQUMxQixNQUFNLEVBQUVrQyxXQUFXLENBQUM1QyxJQUFJLENBQUMsR0FBRzhDLEtBQUssQ0FBQyxLQUM3Q0QsU0FBUyxDQUFDN0MsSUFBSSxDQUFDLEdBQUc4QyxLQUFLO1lBQzlCO1lBRUEsSUFBSXhFLE1BQU0sQ0FBQ3lFLElBQUksQ0FBQ0gsV0FBVyxDQUFDLENBQUNJLE1BQU0sS0FBSyxDQUFDLEVBQUU7Y0FDekMsT0FBTztnQkFBRXhDLE9BQU8sRUFBRTRCLEdBQUcsQ0FBQ08sWUFBWTtnQkFBRWpDLE1BQU0sRUFBRTtrQkFBRSxHQUFHMEIsR0FBRyxDQUFDMUIsTUFBTTtrQkFBRSxHQUFHbUM7Z0JBQVUsQ0FBQztnQkFBRU47Y0FBVyxDQUFDO1lBQzNGO1lBQ0EsTUFBTVUsTUFBTSxHQUFHO2NBQUUsR0FBR2IsR0FBRyxDQUFDMUIsTUFBTTtjQUFFLEdBQUdrQztZQUFZLENBQUM7WUFDaEQsSUFBSTtjQUNGLE1BQU1wQyxPQUFPLEdBQUdKLE9BQU8sQ0FBRTZDLE1BQU0sQ0FBQztjQUNoQyxPQUFPO2dCQUFFekMsT0FBTztnQkFBRUUsTUFBTSxFQUFFO2tCQUFFLEdBQUd1QyxNQUFNO2tCQUFFLEdBQUdKO2dCQUFVLENBQUM7Z0JBQUVOO2NBQVcsQ0FBQztZQUNyRSxDQUFDLENBQUMsT0FBTzVFLENBQUMsRUFBRTtjQUNWO2NBQ0E7Y0FDQTtjQUNBLE9BQU87Z0JBQ0w2QyxPQUFPLEVBQUUsSUFBSTtnQkFDYkUsTUFBTSxFQUFFO2tCQUFFLEdBQUd1QyxNQUFNO2tCQUFFLEdBQUdKO2dCQUFVLENBQUM7Z0JBQ25DSCxLQUFLLEVBQUUsNENBQTZDL0UsQ0FBQyxDQUFXdUYsT0FBTztjQUN6RSxDQUFDO1lBQ0g7VUFDRixDQUFDLENBQUM7UUFDSixDQUFDLENBQUMsT0FBT3ZGLENBQUMsRUFBRTtVQUNWO1VBQ0E7VUFDQTBFLEtBQUssR0FBRztZQUNOYyxRQUFRLEVBQUU3RCxLQUFLLENBQUM4QixHQUFHLENBQUV0RCxDQUFDLEtBQU07Y0FBRXNGLElBQUksRUFBRXRGLENBQUMsQ0FBQ21DLEdBQUc7Y0FBRW9ELE1BQU0sRUFBRTtnQkFBRUMsSUFBSSxFQUFFLEtBQUs7Z0JBQUVKLE9BQU8sRUFBRSxrQkFBbUJ2RixDQUFDLENBQVd1RixPQUFPO2NBQUc7WUFBRSxDQUFDLENBQUMsQ0FBQztZQUN6SEssT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUNIO1FBQ0FwQixHQUFHLENBQUM3QixJQUFJLENBQUM7VUFDUEUsT0FBTyxFQUFFNEIsR0FBRyxDQUFDNUIsT0FBTztVQUNwQitDLE9BQU8sRUFBRWxCLEtBQUssQ0FBQ2tCLE9BQU87VUFDdEJKLFFBQVEsRUFBRWQsS0FBSyxDQUFDYyxRQUFRLENBQUMvQixHQUFHLENBQUVvQyxDQUFDLEtBQU07WUFDbkNuRCxFQUFFLEVBQUVmLEtBQUssQ0FBQ2tELElBQUksQ0FBRTFFLENBQUMsSUFBS0EsQ0FBQyxDQUFDbUMsR0FBRyxLQUFLdUQsQ0FBQyxDQUFDSixJQUFJLENBQUMsRUFBRS9DLEVBQUUsSUFBSW1ELENBQUMsQ0FBQ0osSUFBSSxDQUFDNUMsT0FBTztZQUM3REwsSUFBSSxFQUFFcUQsQ0FBQyxDQUFDSixJQUFJLENBQUM3QyxRQUFRO1lBQ3JCK0MsSUFBSSxFQUFFRSxDQUFDLENBQUNILE1BQU0sQ0FBQ0MsSUFBSTtZQUNuQkosT0FBTyxFQUFFTSxDQUFDLENBQUNILE1BQU0sQ0FBQ0g7VUFDcEIsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO01BQ0o7TUFDQSxPQUFPZixHQUFHO0lBQ1o7RUFDRixDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=