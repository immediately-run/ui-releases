var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _server = require("react-dom/server");
var _react = require("react");
var _Renderer = _interopRequireDefault(require("./Renderer.tsx"));
var _bindings = require("./bindings.ts");
var _mdx = require("../parse/mdx.ts");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// A hand-built data port standing in for the engine's tiered results (shell A's verification
// path: unit-render the components against mock Engine values). renderToStaticMarkup runs in
// Node with no DOM — effects (ResizeObserver/matchMedia) don't fire, so charts render their
// wide default. That is exactly the data path we want to assert here.
function ok(value, tier = 'static') {
  return {
    value,
    tier,
    status: 'ok'
  };
}
function bindings(map) {
  return {
    resolve: s => map[s] ?? (0, _bindings.missing)(s),
    setParam: () => {}
  };
}
function render(src, map) {
  return (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
    nodes: (0, _mdx.parseTemplate)(src),
    bindings: bindings(map)
  }));
}
(0, _vitest.describe)('ReportView', () => {
  (0, _vitest.it)('renders a Kpi value with its resolved binding', () => {
    const html = render('<Kpi source="revenue.total" format="currency" />', {
      'revenue.total': ok(1_234_000)
    });
    (0, _vitest.expect)(html).toContain('rk-kpi-value');
    (0, _vitest.expect)(html).toMatch(/1,234,000|1\.234\.000|1 234 000/);
    (0, _vitest.expect)(html).toContain('data-tier="static"'); // reserved host-badge slot carries the tier
  });
  (0, _vitest.it)('shows a KPI delta from a compare binding', () => {
    const html = render('<Kpi source="a" compare="b" />', {
      a: ok(110),
      b: ok(100)
    });
    (0, _vitest.expect)(html).toContain('rk-kpi-delta');
    (0, _vitest.expect)(html).toContain('data-direction="up"');
  });
  (0, _vitest.it)('degrades a missing binding to a needs-access tile (never a crash)', () => {
    const html = render('<Kpi source="revenue.total" />', {});
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toContain('Needs data access');
  });
  (0, _vitest.it)('degrades a wrong-shaped binding to a broken tile', () => {
    const html = render('<Kpi source="rows" />', {
      rows: ok([{
        a: 1
      }])
    });
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toMatch(/single value/);
  });
  (0, _vitest.it)('renders an unknown component as a placeholder, not an error', () => {
    const html = render('<Timeline source="x.y" />', {});
    (0, _vitest.expect)(html).toContain('rk-placeholder');
    (0, _vitest.expect)(html).toContain('Timeline');
  });
  (0, _vitest.it)('renders a Chart as accessible SVG from row data', () => {
    const rows = [{
      month: 'jan',
      revenue: 10
    }, {
      month: 'feb',
      revenue: 20
    }];
    const html = render('<Chart source="revenue.by_month" kind="line" x="month" y="revenue" />', {
      'revenue.by_month': ok(rows)
    });
    (0, _vitest.expect)(html).toContain('<svg');
    (0, _vitest.expect)(html).toContain('role="img"');
    (0, _vitest.expect)(html).toContain('<path'); // the line series
  });
  (0, _vitest.it)('renders a Table with the declared columns', () => {
    const rows = [{
      month: 'jan',
      revenue: 10
    }];
    const html = render('<Table source="t" columns={["month", "revenue"]} />', {
      t: ok(rows)
    });
    (0, _vitest.expect)(html).toContain('<table');
    (0, _vitest.expect)(html).toContain('>month<');
    (0, _vitest.expect)(html).toContain('>jan<');
  });
  (0, _vitest.it)('renders a sortable Table header as a real button inside the th (keyboard path, 2.1.1)', () => {
    const rows = [{
      month: 'jan',
      revenue: 10
    }];
    const html = render('<Table source="t" columns={["month", "revenue"]} sortable />', {
      t: ok(rows)
    });
    // the sort control is a <button type="button"> carrying the visible column label
    (0, _vitest.expect)(html).toMatch(/<th[^>]*><button type="button" class="rk-th-sort">month<\/button>/);
    // unsorted columns carry no aria-sort; it lands on the th (not the button) once sorted
    (0, _vitest.expect)(html).not.toContain('aria-sort');
    // non-sortable tables keep plain th text — no button, no hit-target chrome
    const plain = render('<Table source="t" columns={["month"]} />', {
      t: ok(rows)
    });
    (0, _vitest.expect)(plain).not.toContain('rk-th-sort');
  });
  (0, _vitest.it)('renders an inline Value from a params binding', () => {
    const html = render('Region <Value source="params.region" />', {
      'params.region': ok('emea')
    });
    (0, _vitest.expect)(html).toContain('rk-value');
    (0, _vitest.expect)(html).toContain('emea');
  });
  (0, _vitest.it)('faceting draws one small-multiple per partition', () => {
    const rows = [{
      cohort: 'a',
      month: 'jan',
      churned: 1
    }, {
      cohort: 'b',
      month: 'jan',
      churned: 2
    }];
    const html = render('<Facets source="churn" by="cohort"><Chart kind="bar" x="month" y="churned" /></Facets>', {
      churn: ok(rows)
    });
    const facets = html.match(/rk-facet-title/g) ?? [];
    (0, _vitest.expect)(facets).toHaveLength(2);
  });
  (0, _vitest.it)('renders a single-slice pie as a full circle (not a degenerate arc)', () => {
    const rows = [{
      seg: 'a',
      share: 100
    }];
    const html = render('<Chart source="mix" kind="pie" value="share" label="seg" />', {
      mix: ok(rows)
    });
    (0, _vitest.expect)(html).toContain('<circle'); // a lone 100% slice draws a circle, not an empty arc
  });
  (0, _vitest.it)('renders markdown prose as markup', () => {
    const html = render('# Weekly revenue.\n\nSome **bold** prose.', {});
    (0, _vitest.expect)(html).toContain('<h1>');
    (0, _vitest.expect)(html).toContain('<strong>bold</strong>');
  });
  (0, _vitest.it)('renders a Callout with its tone and prose children', () => {
    const html = render('<Callout tone="warning">Heads up.</Callout>', {});
    (0, _vitest.expect)(html).toContain('data-tone="warning"');
    (0, _vitest.expect)(html).toContain('Heads up.');
  });
});
(0, _vitest.describe)('the on-pixel inspection affordance (V3)', () => {
  const src = 'Recurring revenue.\n\n<Kpi source="rev.total" format="currency" />\n\n<Callout tone="info">Note.</Callout>';
  const map = {
    'rev.total': {
      value: 5,
      tier: 'static',
      status: 'ok'
    }
  };
  (0, _vitest.it)('with an inspection port, bound elements carry the affordance; unbound ones do not', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: (0, _mdx.parseTemplate)(src),
      bindings: bindings(map),
      inspection: {
        onInspect: () => {},
        canInspect: () => true
      }
    }));
    (0, _vitest.expect)(html).toContain('rk-inspectable');
    (0, _vitest.expect)(html).toContain('data-source="rev.total"');
    (0, _vitest.expect)(html).toContain('aria-label="Inspect rev.total"');
    // exactly one affordance — the Callout (no source) has none
    (0, _vitest.expect)(html.match(/rk-inspect-btn/g)).toHaveLength(1);
  });
  (0, _vitest.it)('the affordance hides for sources the port cannot inspect', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: (0, _mdx.parseTemplate)(src),
      bindings: bindings(map),
      inspection: {
        onInspect: () => {},
        canInspect: () => false
      }
    }));
    (0, _vitest.expect)(html).not.toContain('rk-inspectable');
  });
  (0, _vitest.it)('without a port (plain run mode) nothing renders — no tax on run mode', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: (0, _mdx.parseTemplate)(src),
      bindings: bindings(map)
    }));
    (0, _vitest.expect)(html).not.toContain('rk-inspectable');
    (0, _vitest.expect)(html).not.toContain('rk-inspect-btn');
  });
});
(0, _vitest.describe)('Flow', () => {
  const nodes = [{
    id: 'draft',
    label: 'Drafting',
    sub: 'agent',
    x: 0,
    y: 0,
    tone: 'agent'
  }, {
    id: 'review',
    label: 'Review gate',
    x: 260,
    y: 0,
    shape: 'diamond',
    tone: 'ci'
  }, {
    id: 'merge',
    label: 'Merge',
    x: 520,
    y: 0,
    shape: 'pill',
    tone: 'owner'
  }];
  const edges = [{
    from: 'draft',
    to: 'review',
    label: 'awaiting review',
    value: 4,
    buffer: true,
    alert: true,
    tone: 'ci'
  }, {
    from: 'review',
    to: 'merge',
    label: 'green',
    value: '2'
  }, {
    from: 'review',
    to: 'draft',
    dashed: true,
    via: '330,100 70,100'
  }];
  const tpl = '<Flow nodes="process.n" edges="process.e" title="The roadmap factory" />';
  (0, _vitest.it)('draws nodes, edges with arrowheads, annotations and the buffer triangle', () => {
    const html = render(tpl, {
      'process.n': ok(nodes),
      'process.e': ok(edges)
    });
    (0, _vitest.expect)(html).toContain('<svg');
    (0, _vitest.expect)(html).toContain('>Drafting<');
    (0, _vitest.expect)(html).toContain('>Review gate<');
    (0, _vitest.expect)(html).toContain('>agent<'); // sub line
    (0, _vitest.expect)(html).toMatch(/<path class="rk-flow-edge[^"]*"[^>]*marker-end="url\(#rk-flow-arrow-/);
    (0, _vitest.expect)(html).toContain('>awaiting review<');
    (0, _vitest.expect)(html).toContain('>4<');
    (0, _vitest.expect)(html).toContain('rk-flow-buffer');
    (0, _vitest.expect)(html).toContain('rk-flow-alert');
    (0, _vitest.expect)(html.match(/rk-flow-alert/g)).toHaveLength(1);
    (0, _vitest.expect)(html).toContain('rk-flow-dashed');
    (0, _vitest.expect)(html).toContain('aria-label="The roadmap factory: 3 nodes, 3 connections. Drafting → Review gate: awaiting review 4 (alert); Review gate → Merge: green 2."');
  });
  (0, _vitest.it)('a missing binding is a needs-access tile', () => {
    const html = render(tpl, {
      'process.n': ok(nodes)
    });
    (0, _vitest.expect)(html).toContain('Needs data access');
    (0, _vitest.expect)(html).not.toContain('<svg');
  });
  (0, _vitest.it)('an edge to an unknown node id is a broken tile naming the id', () => {
    const html = render(tpl, {
      'process.n': ok(nodes),
      'process.e': ok([{
        from: 'draft',
        to: 'publish'
      }])
    });
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toContain('unknown node id &quot;publish&quot;');
    (0, _vitest.expect)(html).not.toContain('<svg');
  });
  (0, _vitest.it)('more than 80 nodes is a broken tile', () => {
    const many = Array.from({
      length: 81
    }, (_, i) => ({
      id: `n${i}`,
      label: `N${i}`,
      x: i * 10,
      y: 0
    }));
    const html = render(tpl, {
      'process.n': ok(many),
      'process.e': ok([])
    });
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toMatch(/80-node cap/);
  });
  (0, _vitest.it)('a non-table binding is a broken tile', () => {
    const html = render(tpl, {
      'process.n': ok(3),
      'process.e': ok([])
    });
    (0, _vitest.expect)(html).toContain('nodes: expected a table of rows');
  });
  (0, _vitest.it)('carries one inspection affordance for the whole diagram (on its nodes binding)', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_Renderer.default, {
      nodes: (0, _mdx.parseTemplate)(tpl),
      bindings: bindings({
        'process.n': ok(nodes),
        'process.e': ok(edges)
      }),
      inspection: {
        onInspect: () => {},
        canInspect: () => true
      }
    }));
    (0, _vitest.expect)(html.match(/rk-inspect-btn/g)).toHaveLength(1);
    (0, _vitest.expect)(html).toContain('data-source="process.n"');
  });
});
(0, _vitest.describe)('ShowWhen', () => {
  const tpl = '<ShowWhen source="process.flag"><Callout tone="danger">Over bound.</Callout></ShowWhen>';
  (0, _vitest.it)('renders the children when the bound cell is exactly true', () => {
    const html = render(tpl, {
      'process.flag': ok(true)
    });
    (0, _vitest.expect)(html).toContain('data-tone="danger"');
    (0, _vitest.expect)(html).toContain('Over bound.');
    (0, _vitest.expect)(html).not.toContain('rk-broken');
  });
  (0, _vitest.it)('renders nothing when the cell is false — no prose, no broken tile', () => {
    const html = render(tpl, {
      'process.flag': ok(false)
    });
    (0, _vitest.expect)(html).not.toContain('Over bound.');
    (0, _vitest.expect)(html).not.toContain('rk-broken');
  });
  (0, _vitest.it)('a missing binding renders the needs-access tile', () => {
    const html = render(tpl, {});
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toContain('Needs data access');
    (0, _vitest.expect)(html).not.toContain('Over bound.');
  });
  (0, _vitest.it)('an errored binding renders the broken tile with its message', () => {
    const html = render(tpl, {
      'process.flag': {
        value: null,
        tier: 'static',
        status: 'error',
        message: 'flag threw in the engine'
      }
    });
    (0, _vitest.expect)(html).toContain('rk-broken');
    (0, _vitest.expect)(html).toContain('flag threw in the engine');
    (0, _vitest.expect)(html).not.toContain('Over bound.');
  });
  (0, _vitest.it)('refuses truthiness: 1, "true" and a row list each render a broken tile saying true or false', () => {
    for (const v of [1, 'true', [{
      a: 1
    }]]) {
      const html = render(tpl, {
        'process.flag': ok(v)
      });
      (0, _vitest.expect)(html).toContain('rk-broken');
      (0, _vitest.expect)(html).toContain('true or false');
      (0, _vitest.expect)(html).not.toContain('Over bound.');
    }
  });
  (0, _vitest.it)('adds no wrapper element inside a Row — the child is a direct child of the row container', () => {
    const html = render('<Row><ShowWhen source="process.flag"><Callout tone="danger">Over bound.</Callout></ShowWhen></Row>', {
      'process.flag': ok(true)
    });
    (0, _vitest.expect)(html).toMatch(/<div class="rk-row"><div class="rk-callout"/);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9zZXJ2ZXIiLCJfcmVhY3QiLCJfUmVuZGVyZXIiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2JpbmRpbmdzIiwiX21keCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIm9rIiwidmFsdWUiLCJ0aWVyIiwic3RhdHVzIiwiYmluZGluZ3MiLCJtYXAiLCJyZXNvbHZlIiwicyIsIm1pc3NpbmciLCJzZXRQYXJhbSIsInJlbmRlciIsInNyYyIsInJlbmRlclRvU3RhdGljTWFya3VwIiwiY3JlYXRlRWxlbWVudCIsIlJlcG9ydFZpZXciLCJub2RlcyIsInBhcnNlVGVtcGxhdGUiLCJkZXNjcmliZSIsIml0IiwiaHRtbCIsImV4cGVjdCIsInRvQ29udGFpbiIsInRvTWF0Y2giLCJhIiwiYiIsInJvd3MiLCJtb250aCIsInJldmVudWUiLCJ0Iiwibm90IiwicGxhaW4iLCJjb2hvcnQiLCJjaHVybmVkIiwiY2h1cm4iLCJmYWNldHMiLCJtYXRjaCIsInRvSGF2ZUxlbmd0aCIsInNlZyIsInNoYXJlIiwibWl4IiwiaW5zcGVjdGlvbiIsIm9uSW5zcGVjdCIsImNhbkluc3BlY3QiLCJpZCIsImxhYmVsIiwic3ViIiwieCIsInkiLCJ0b25lIiwic2hhcGUiLCJlZGdlcyIsImZyb20iLCJ0byIsImJ1ZmZlciIsImFsZXJ0IiwiZGFzaGVkIiwidmlhIiwidHBsIiwibWFueSIsIkFycmF5IiwibGVuZ3RoIiwiXyIsImkiLCJtZXNzYWdlIiwidiJdLCJzb3VyY2VzIjpbInJlbmRlci50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyByZW5kZXJUb1N0YXRpY01hcmt1cCB9IGZyb20gJ3JlYWN0LWRvbS9zZXJ2ZXInO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBSZXBvcnRWaWV3IGZyb20gJy4vUmVuZGVyZXIudHN4JztcbmltcG9ydCB7IG1pc3NpbmcgfSBmcm9tICcuL2JpbmRpbmdzLnRzJztcbmltcG9ydCB0eXBlIHsgQmluZGluZ3MsIEJvdW5kVmFsdWUgfSBmcm9tICcuL2JpbmRpbmdzLnRzJztcbmltcG9ydCB7IHBhcnNlVGVtcGxhdGUgfSBmcm9tICcuLi9wYXJzZS9tZHgudHMnO1xuaW1wb3J0IHR5cGUgeyBSb3csIFZhbHVlIH0gZnJvbSAnLi4vLi4vc3RkbGliL3R5cGVzLnRzJztcblxuLy8gQSBoYW5kLWJ1aWx0IGRhdGEgcG9ydCBzdGFuZGluZyBpbiBmb3IgdGhlIGVuZ2luZSdzIHRpZXJlZCByZXN1bHRzIChzaGVsbCBBJ3MgdmVyaWZpY2F0aW9uXG4vLyBwYXRoOiB1bml0LXJlbmRlciB0aGUgY29tcG9uZW50cyBhZ2FpbnN0IG1vY2sgRW5naW5lIHZhbHVlcykuIHJlbmRlclRvU3RhdGljTWFya3VwIHJ1bnMgaW5cbi8vIE5vZGUgd2l0aCBubyBET00g4oCUIGVmZmVjdHMgKFJlc2l6ZU9ic2VydmVyL21hdGNoTWVkaWEpIGRvbid0IGZpcmUsIHNvIGNoYXJ0cyByZW5kZXIgdGhlaXJcbi8vIHdpZGUgZGVmYXVsdC4gVGhhdCBpcyBleGFjdGx5IHRoZSBkYXRhIHBhdGggd2Ugd2FudCB0byBhc3NlcnQgaGVyZS5cbmZ1bmN0aW9uIG9rKHZhbHVlOiBWYWx1ZSwgdGllcjogQm91bmRWYWx1ZVsndGllciddID0gJ3N0YXRpYycpOiBCb3VuZFZhbHVlIHtcbiAgcmV0dXJuIHsgdmFsdWUsIHRpZXIsIHN0YXR1czogJ29rJyB9O1xufVxuZnVuY3Rpb24gYmluZGluZ3MobWFwOiBSZWNvcmQ8c3RyaW5nLCBCb3VuZFZhbHVlPik6IEJpbmRpbmdzIHtcbiAgcmV0dXJuIHsgcmVzb2x2ZTogKHMpID0+IG1hcFtzXSA/PyBtaXNzaW5nKHMpLCBzZXRQYXJhbTogKCkgPT4ge30gfTtcbn1cbmZ1bmN0aW9uIHJlbmRlcihzcmM6IHN0cmluZywgbWFwOiBSZWNvcmQ8c3RyaW5nLCBCb3VuZFZhbHVlPik6IHN0cmluZyB7XG4gIHJldHVybiByZW5kZXJUb1N0YXRpY01hcmt1cChjcmVhdGVFbGVtZW50KFJlcG9ydFZpZXcsIHsgbm9kZXM6IHBhcnNlVGVtcGxhdGUoc3JjKSwgYmluZGluZ3M6IGJpbmRpbmdzKG1hcCkgfSkpO1xufVxuXG5kZXNjcmliZSgnUmVwb3J0VmlldycsICgpID0+IHtcbiAgaXQoJ3JlbmRlcnMgYSBLcGkgdmFsdWUgd2l0aCBpdHMgcmVzb2x2ZWQgYmluZGluZycsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKCc8S3BpIHNvdXJjZT1cInJldmVudWUudG90YWxcIiBmb3JtYXQ9XCJjdXJyZW5jeVwiIC8+JywgeyAncmV2ZW51ZS50b3RhbCc6IG9rKDFfMjM0XzAwMCkgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmsta3BpLXZhbHVlJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvTWF0Y2goLzEsMjM0LDAwMHwxXFwuMjM0XFwuMDAwfDEgMjM0IDAwMC8pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2RhdGEtdGllcj1cInN0YXRpY1wiJyk7IC8vIHJlc2VydmVkIGhvc3QtYmFkZ2Ugc2xvdCBjYXJyaWVzIHRoZSB0aWVyXG4gIH0pO1xuXG4gIGl0KCdzaG93cyBhIEtQSSBkZWx0YSBmcm9tIGEgY29tcGFyZSBiaW5kaW5nJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxLcGkgc291cmNlPVwiYVwiIGNvbXBhcmU9XCJiXCIgLz4nLCB7IGE6IG9rKDExMCksIGI6IG9rKDEwMCkgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmsta3BpLWRlbHRhJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignZGF0YS1kaXJlY3Rpb249XCJ1cFwiJyk7XG4gIH0pO1xuXG4gIGl0KCdkZWdyYWRlcyBhIG1pc3NpbmcgYmluZGluZyB0byBhIG5lZWRzLWFjY2VzcyB0aWxlIChuZXZlciBhIGNyYXNoKScsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKCc8S3BpIHNvdXJjZT1cInJldmVudWUudG90YWxcIiAvPicsIHt9KTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdOZWVkcyBkYXRhIGFjY2VzcycpO1xuICB9KTtcblxuICBpdCgnZGVncmFkZXMgYSB3cm9uZy1zaGFwZWQgYmluZGluZyB0byBhIGJyb2tlbiB0aWxlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxLcGkgc291cmNlPVwicm93c1wiIC8+JywgeyByb3dzOiBvayhbeyBhOiAxIH1dKSB9KTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgICBleHBlY3QoaHRtbCkudG9NYXRjaCgvc2luZ2xlIHZhbHVlLyk7XG4gIH0pO1xuXG4gIGl0KCdyZW5kZXJzIGFuIHVua25vd24gY29tcG9uZW50IGFzIGEgcGxhY2Vob2xkZXIsIG5vdCBhbiBlcnJvcicsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKCc8VGltZWxpbmUgc291cmNlPVwieC55XCIgLz4nLCB7fSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmstcGxhY2Vob2xkZXInKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdUaW1lbGluZScpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBhIENoYXJ0IGFzIGFjY2Vzc2libGUgU1ZHIGZyb20gcm93IGRhdGEnLCAoKSA9PiB7XG4gICAgY29uc3Qgcm93cyA9IFt7IG1vbnRoOiAnamFuJywgcmV2ZW51ZTogMTAgfSwgeyBtb250aDogJ2ZlYicsIHJldmVudWU6IDIwIH1dO1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxDaGFydCBzb3VyY2U9XCJyZXZlbnVlLmJ5X21vbnRoXCIga2luZD1cImxpbmVcIiB4PVwibW9udGhcIiB5PVwicmV2ZW51ZVwiIC8+JywgeyAncmV2ZW51ZS5ieV9tb250aCc6IG9rKHJvd3MpIH0pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJzxzdmcnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyb2xlPVwiaW1nXCInKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCc8cGF0aCcpOyAvLyB0aGUgbGluZSBzZXJpZXNcbiAgfSk7XG5cbiAgaXQoJ3JlbmRlcnMgYSBUYWJsZSB3aXRoIHRoZSBkZWNsYXJlZCBjb2x1bW5zJywgKCkgPT4ge1xuICAgIGNvbnN0IHJvd3MgPSBbeyBtb250aDogJ2phbicsIHJldmVudWU6IDEwIH1dO1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxUYWJsZSBzb3VyY2U9XCJ0XCIgY29sdW1ucz17W1wibW9udGhcIiwgXCJyZXZlbnVlXCJdfSAvPicsIHsgdDogb2socm93cykgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPHRhYmxlJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPm1vbnRoPCcpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJz5qYW48Jyk7XG4gIH0pO1xuXG4gIGl0KCdyZW5kZXJzIGEgc29ydGFibGUgVGFibGUgaGVhZGVyIGFzIGEgcmVhbCBidXR0b24gaW5zaWRlIHRoZSB0aCAoa2V5Ym9hcmQgcGF0aCwgMi4xLjEpJywgKCkgPT4ge1xuICAgIGNvbnN0IHJvd3MgPSBbeyBtb250aDogJ2phbicsIHJldmVudWU6IDEwIH1dO1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxUYWJsZSBzb3VyY2U9XCJ0XCIgY29sdW1ucz17W1wibW9udGhcIiwgXCJyZXZlbnVlXCJdfSBzb3J0YWJsZSAvPicsIHsgdDogb2socm93cykgfSk7XG4gICAgLy8gdGhlIHNvcnQgY29udHJvbCBpcyBhIDxidXR0b24gdHlwZT1cImJ1dHRvblwiPiBjYXJyeWluZyB0aGUgdmlzaWJsZSBjb2x1bW4gbGFiZWxcbiAgICBleHBlY3QoaHRtbCkudG9NYXRjaCgvPHRoW14+XSo+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJyay10aC1zb3J0XCI+bW9udGg8XFwvYnV0dG9uPi8pO1xuICAgIC8vIHVuc29ydGVkIGNvbHVtbnMgY2Fycnkgbm8gYXJpYS1zb3J0OyBpdCBsYW5kcyBvbiB0aGUgdGggKG5vdCB0aGUgYnV0dG9uKSBvbmNlIHNvcnRlZFxuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdhcmlhLXNvcnQnKTtcbiAgICAvLyBub24tc29ydGFibGUgdGFibGVzIGtlZXAgcGxhaW4gdGggdGV4dCDigJQgbm8gYnV0dG9uLCBubyBoaXQtdGFyZ2V0IGNocm9tZVxuICAgIGNvbnN0IHBsYWluID0gcmVuZGVyKCc8VGFibGUgc291cmNlPVwidFwiIGNvbHVtbnM9e1tcIm1vbnRoXCJdfSAvPicsIHsgdDogb2socm93cykgfSk7XG4gICAgZXhwZWN0KHBsYWluKS5ub3QudG9Db250YWluKCdyay10aC1zb3J0Jyk7XG4gIH0pO1xuXG4gIGl0KCdyZW5kZXJzIGFuIGlubGluZSBWYWx1ZSBmcm9tIGEgcGFyYW1zIGJpbmRpbmcnLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlcignUmVnaW9uIDxWYWx1ZSBzb3VyY2U9XCJwYXJhbXMucmVnaW9uXCIgLz4nLCB7ICdwYXJhbXMucmVnaW9uJzogb2soJ2VtZWEnKSB9KTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay12YWx1ZScpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2VtZWEnKTtcbiAgfSk7XG5cbiAgaXQoJ2ZhY2V0aW5nIGRyYXdzIG9uZSBzbWFsbC1tdWx0aXBsZSBwZXIgcGFydGl0aW9uJywgKCkgPT4ge1xuICAgIGNvbnN0IHJvd3MgPSBbXG4gICAgICB7IGNvaG9ydDogJ2EnLCBtb250aDogJ2phbicsIGNodXJuZWQ6IDEgfSxcbiAgICAgIHsgY29ob3J0OiAnYicsIG1vbnRoOiAnamFuJywgY2h1cm5lZDogMiB9LFxuICAgIF07XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlcignPEZhY2V0cyBzb3VyY2U9XCJjaHVyblwiIGJ5PVwiY29ob3J0XCI+PENoYXJ0IGtpbmQ9XCJiYXJcIiB4PVwibW9udGhcIiB5PVwiY2h1cm5lZFwiIC8+PC9GYWNldHM+JywgeyBjaHVybjogb2socm93cykgfSk7XG4gICAgY29uc3QgZmFjZXRzID0gaHRtbC5tYXRjaCgvcmstZmFjZXQtdGl0bGUvZykgPz8gW107XG4gICAgZXhwZWN0KGZhY2V0cykudG9IYXZlTGVuZ3RoKDIpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBhIHNpbmdsZS1zbGljZSBwaWUgYXMgYSBmdWxsIGNpcmNsZSAobm90IGEgZGVnZW5lcmF0ZSBhcmMpJywgKCkgPT4ge1xuICAgIGNvbnN0IHJvd3MgPSBbeyBzZWc6ICdhJywgc2hhcmU6IDEwMCB9XTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKCc8Q2hhcnQgc291cmNlPVwibWl4XCIga2luZD1cInBpZVwiIHZhbHVlPVwic2hhcmVcIiBsYWJlbD1cInNlZ1wiIC8+JywgeyBtaXg6IG9rKHJvd3MpIH0pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJzxjaXJjbGUnKTsgLy8gYSBsb25lIDEwMCUgc2xpY2UgZHJhd3MgYSBjaXJjbGUsIG5vdCBhbiBlbXB0eSBhcmNcbiAgfSk7XG5cbiAgaXQoJ3JlbmRlcnMgbWFya2Rvd24gcHJvc2UgYXMgbWFya3VwJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJyMgV2Vla2x5IHJldmVudWUuXFxuXFxuU29tZSAqKmJvbGQqKiBwcm9zZS4nLCB7fSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPGgxPicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJzxzdHJvbmc+Ym9sZDwvc3Ryb25nPicpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBhIENhbGxvdXQgd2l0aCBpdHMgdG9uZSBhbmQgcHJvc2UgY2hpbGRyZW4nLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlcignPENhbGxvdXQgdG9uZT1cIndhcm5pbmdcIj5IZWFkcyB1cC48L0NhbGxvdXQ+Jywge30pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2RhdGEtdG9uZT1cIndhcm5pbmdcIicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ0hlYWRzIHVwLicpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgndGhlIG9uLXBpeGVsIGluc3BlY3Rpb24gYWZmb3JkYW5jZSAoVjMpJywgKCkgPT4ge1xuICBjb25zdCBzcmMgPSAnUmVjdXJyaW5nIHJldmVudWUuXFxuXFxuPEtwaSBzb3VyY2U9XCJyZXYudG90YWxcIiBmb3JtYXQ9XCJjdXJyZW5jeVwiIC8+XFxuXFxuPENhbGxvdXQgdG9uZT1cImluZm9cIj5Ob3RlLjwvQ2FsbG91dD4nO1xuICBjb25zdCBtYXAgPSB7ICdyZXYudG90YWwnOiB7IHZhbHVlOiA1LCB0aWVyOiAnc3RhdGljJyBhcyBjb25zdCwgc3RhdHVzOiAnb2snIGFzIGNvbnN0IH0gfTtcblxuICBpdCgnd2l0aCBhbiBpbnNwZWN0aW9uIHBvcnQsIGJvdW5kIGVsZW1lbnRzIGNhcnJ5IHRoZSBhZmZvcmRhbmNlOyB1bmJvdW5kIG9uZXMgZG8gbm90JywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0YXRpY01hcmt1cChcbiAgICAgIGNyZWF0ZUVsZW1lbnQoUmVwb3J0Vmlldywge1xuICAgICAgICBub2RlczogcGFyc2VUZW1wbGF0ZShzcmMpLFxuICAgICAgICBiaW5kaW5nczogYmluZGluZ3MobWFwKSxcbiAgICAgICAgaW5zcGVjdGlvbjogeyBvbkluc3BlY3Q6ICgpID0+IHt9LCBjYW5JbnNwZWN0OiAoKSA9PiB0cnVlIH0sXG4gICAgICB9KSxcbiAgICApO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JrLWluc3BlY3RhYmxlJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignZGF0YS1zb3VyY2U9XCJyZXYudG90YWxcIicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2FyaWEtbGFiZWw9XCJJbnNwZWN0IHJldi50b3RhbFwiJyk7XG4gICAgLy8gZXhhY3RseSBvbmUgYWZmb3JkYW5jZSDigJQgdGhlIENhbGxvdXQgKG5vIHNvdXJjZSkgaGFzIG5vbmVcbiAgICBleHBlY3QoaHRtbC5tYXRjaCgvcmstaW5zcGVjdC1idG4vZykpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBhZmZvcmRhbmNlIGhpZGVzIGZvciBzb3VyY2VzIHRoZSBwb3J0IGNhbm5vdCBpbnNwZWN0JywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0YXRpY01hcmt1cChcbiAgICAgIGNyZWF0ZUVsZW1lbnQoUmVwb3J0Vmlldywge1xuICAgICAgICBub2RlczogcGFyc2VUZW1wbGF0ZShzcmMpLFxuICAgICAgICBiaW5kaW5nczogYmluZGluZ3MobWFwKSxcbiAgICAgICAgaW5zcGVjdGlvbjogeyBvbkluc3BlY3Q6ICgpID0+IHt9LCBjYW5JbnNwZWN0OiAoKSA9PiBmYWxzZSB9LFxuICAgICAgfSksXG4gICAgKTtcbiAgICBleHBlY3QoaHRtbCkubm90LnRvQ29udGFpbigncmstaW5zcGVjdGFibGUnKTtcbiAgfSk7XG5cbiAgaXQoJ3dpdGhvdXQgYSBwb3J0IChwbGFpbiBydW4gbW9kZSkgbm90aGluZyByZW5kZXJzIOKAlCBubyB0YXggb24gcnVuIG1vZGUnLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlclRvU3RhdGljTWFya3VwKGNyZWF0ZUVsZW1lbnQoUmVwb3J0VmlldywgeyBub2RlczogcGFyc2VUZW1wbGF0ZShzcmMpLCBiaW5kaW5nczogYmluZGluZ3MobWFwKSB9KSk7XG4gICAgZXhwZWN0KGh0bWwpLm5vdC50b0NvbnRhaW4oJ3JrLWluc3BlY3RhYmxlJyk7XG4gICAgZXhwZWN0KGh0bWwpLm5vdC50b0NvbnRhaW4oJ3JrLWluc3BlY3QtYnRuJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdGbG93JywgKCkgPT4ge1xuICBjb25zdCBub2RlczogUm93W10gPSBbXG4gICAgeyBpZDogJ2RyYWZ0JywgbGFiZWw6ICdEcmFmdGluZycsIHN1YjogJ2FnZW50JywgeDogMCwgeTogMCwgdG9uZTogJ2FnZW50JyB9LFxuICAgIHsgaWQ6ICdyZXZpZXcnLCBsYWJlbDogJ1JldmlldyBnYXRlJywgeDogMjYwLCB5OiAwLCBzaGFwZTogJ2RpYW1vbmQnLCB0b25lOiAnY2knIH0sXG4gICAgeyBpZDogJ21lcmdlJywgbGFiZWw6ICdNZXJnZScsIHg6IDUyMCwgeTogMCwgc2hhcGU6ICdwaWxsJywgdG9uZTogJ293bmVyJyB9LFxuICBdO1xuICBjb25zdCBlZGdlczogUm93W10gPSBbXG4gICAgeyBmcm9tOiAnZHJhZnQnLCB0bzogJ3JldmlldycsIGxhYmVsOiAnYXdhaXRpbmcgcmV2aWV3JywgdmFsdWU6IDQsIGJ1ZmZlcjogdHJ1ZSwgYWxlcnQ6IHRydWUsIHRvbmU6ICdjaScgfSxcbiAgICB7IGZyb206ICdyZXZpZXcnLCB0bzogJ21lcmdlJywgbGFiZWw6ICdncmVlbicsIHZhbHVlOiAnMicgfSxcbiAgICB7IGZyb206ICdyZXZpZXcnLCB0bzogJ2RyYWZ0JywgZGFzaGVkOiB0cnVlLCB2aWE6ICczMzAsMTAwIDcwLDEwMCcgfSxcbiAgXTtcbiAgY29uc3QgdHBsID0gJzxGbG93IG5vZGVzPVwicHJvY2Vzcy5uXCIgZWRnZXM9XCJwcm9jZXNzLmVcIiB0aXRsZT1cIlRoZSByb2FkbWFwIGZhY3RvcnlcIiAvPic7XG5cbiAgaXQoJ2RyYXdzIG5vZGVzLCBlZGdlcyB3aXRoIGFycm93aGVhZHMsIGFubm90YXRpb25zIGFuZCB0aGUgYnVmZmVyIHRyaWFuZ2xlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7ICdwcm9jZXNzLm4nOiBvayhub2RlcyksICdwcm9jZXNzLmUnOiBvayhlZGdlcykgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPHN2ZycpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJz5EcmFmdGluZzwnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCc+UmV2aWV3IGdhdGU8Jyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPmFnZW50PCcpOyAvLyBzdWIgbGluZVxuICAgIGV4cGVjdChodG1sKS50b01hdGNoKC88cGF0aCBjbGFzcz1cInJrLWZsb3ctZWRnZVteXCJdKlwiW14+XSptYXJrZXItZW5kPVwidXJsXFwoI3JrLWZsb3ctYXJyb3ctLyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPmF3YWl0aW5nIHJldmlldzwnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCc+NDwnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1mbG93LWJ1ZmZlcicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JrLWZsb3ctYWxlcnQnKTtcbiAgICBleHBlY3QoaHRtbC5tYXRjaCgvcmstZmxvdy1hbGVydC9nKSkudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JrLWZsb3ctZGFzaGVkJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignYXJpYS1sYWJlbD1cIlRoZSByb2FkbWFwIGZhY3Rvcnk6IDMgbm9kZXMsIDMgY29ubmVjdGlvbnMuIERyYWZ0aW5nIOKGkiBSZXZpZXcgZ2F0ZTogYXdhaXRpbmcgcmV2aWV3IDQgKGFsZXJ0KTsgUmV2aWV3IGdhdGUg4oaSIE1lcmdlOiBncmVlbiAyLlwiJyk7XG4gIH0pO1xuXG4gIGl0KCdhIG1pc3NpbmcgYmluZGluZyBpcyBhIG5lZWRzLWFjY2VzcyB0aWxlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7ICdwcm9jZXNzLm4nOiBvayhub2RlcykgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignTmVlZHMgZGF0YSBhY2Nlc3MnKTtcbiAgICBleHBlY3QoaHRtbCkubm90LnRvQ29udGFpbignPHN2ZycpO1xuICB9KTtcblxuICBpdCgnYW4gZWRnZSB0byBhbiB1bmtub3duIG5vZGUgaWQgaXMgYSBicm9rZW4gdGlsZSBuYW1pbmcgdGhlIGlkJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7ICdwcm9jZXNzLm4nOiBvayhub2RlcyksICdwcm9jZXNzLmUnOiBvayhbeyBmcm9tOiAnZHJhZnQnLCB0bzogJ3B1Ymxpc2gnIH1dKSB9KTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCd1bmtub3duIG5vZGUgaWQgJnF1b3Q7cHVibGlzaCZxdW90OycpO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCc8c3ZnJyk7XG4gIH0pO1xuXG4gIGl0KCdtb3JlIHRoYW4gODAgbm9kZXMgaXMgYSBicm9rZW4gdGlsZScsICgpID0+IHtcbiAgICBjb25zdCBtYW55ID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogODEgfSwgKF8sIGkpID0+ICh7IGlkOiBgbiR7aX1gLCBsYWJlbDogYE4ke2l9YCwgeDogaSAqIDEwLCB5OiAwIH0pKTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKHRwbCwgeyAncHJvY2Vzcy5uJzogb2sobWFueSksICdwcm9jZXNzLmUnOiBvayhbXSkgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmstYnJva2VuJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvTWF0Y2goLzgwLW5vZGUgY2FwLyk7XG4gIH0pO1xuXG4gIGl0KCdhIG5vbi10YWJsZSBiaW5kaW5nIGlzIGEgYnJva2VuIHRpbGUnLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlcih0cGwsIHsgJ3Byb2Nlc3Mubic6IG9rKDMpLCAncHJvY2Vzcy5lJzogb2soW10pIH0pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ25vZGVzOiBleHBlY3RlZCBhIHRhYmxlIG9mIHJvd3MnKTtcbiAgfSk7XG5cbiAgaXQoJ2NhcnJpZXMgb25lIGluc3BlY3Rpb24gYWZmb3JkYW5jZSBmb3IgdGhlIHdob2xlIGRpYWdyYW0gKG9uIGl0cyBub2RlcyBiaW5kaW5nKScsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyVG9TdGF0aWNNYXJrdXAoXG4gICAgICBjcmVhdGVFbGVtZW50KFJlcG9ydFZpZXcsIHtcbiAgICAgICAgbm9kZXM6IHBhcnNlVGVtcGxhdGUodHBsKSxcbiAgICAgICAgYmluZGluZ3M6IGJpbmRpbmdzKHsgJ3Byb2Nlc3Mubic6IG9rKG5vZGVzKSwgJ3Byb2Nlc3MuZSc6IG9rKGVkZ2VzKSB9KSxcbiAgICAgICAgaW5zcGVjdGlvbjogeyBvbkluc3BlY3Q6ICgpID0+IHt9LCBjYW5JbnNwZWN0OiAoKSA9PiB0cnVlIH0sXG4gICAgICB9KSxcbiAgICApO1xuICAgIGV4cGVjdChodG1sLm1hdGNoKC9yay1pbnNwZWN0LWJ0bi9nKSkudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2RhdGEtc291cmNlPVwicHJvY2Vzcy5uXCInKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ1Nob3dXaGVuJywgKCkgPT4ge1xuICBjb25zdCB0cGwgPSAnPFNob3dXaGVuIHNvdXJjZT1cInByb2Nlc3MuZmxhZ1wiPjxDYWxsb3V0IHRvbmU9XCJkYW5nZXJcIj5PdmVyIGJvdW5kLjwvQ2FsbG91dD48L1Nob3dXaGVuPic7XG5cbiAgaXQoJ3JlbmRlcnMgdGhlIGNoaWxkcmVuIHdoZW4gdGhlIGJvdW5kIGNlbGwgaXMgZXhhY3RseSB0cnVlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7ICdwcm9jZXNzLmZsYWcnOiBvayh0cnVlKSB9KTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdkYXRhLXRvbmU9XCJkYW5nZXJcIicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ092ZXIgYm91bmQuJyk7XG4gICAgZXhwZWN0KGh0bWwpLm5vdC50b0NvbnRhaW4oJ3JrLWJyb2tlbicpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBub3RoaW5nIHdoZW4gdGhlIGNlbGwgaXMgZmFsc2Ug4oCUIG5vIHByb3NlLCBubyBicm9rZW4gdGlsZScsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKHRwbCwgeyAncHJvY2Vzcy5mbGFnJzogb2soZmFsc2UpIH0pO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdPdmVyIGJvdW5kLicpO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgfSk7XG5cbiAgaXQoJ2EgbWlzc2luZyBiaW5kaW5nIHJlbmRlcnMgdGhlIG5lZWRzLWFjY2VzcyB0aWxlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7fSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmstYnJva2VuJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignTmVlZHMgZGF0YSBhY2Nlc3MnKTtcbiAgICBleHBlY3QoaHRtbCkubm90LnRvQ29udGFpbignT3ZlciBib3VuZC4nKTtcbiAgfSk7XG5cbiAgaXQoJ2FuIGVycm9yZWQgYmluZGluZyByZW5kZXJzIHRoZSBicm9rZW4gdGlsZSB3aXRoIGl0cyBtZXNzYWdlJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIodHBsLCB7ICdwcm9jZXNzLmZsYWcnOiB7IHZhbHVlOiBudWxsLCB0aWVyOiAnc3RhdGljJywgc3RhdHVzOiAnZXJyb3InLCBtZXNzYWdlOiAnZmxhZyB0aHJldyBpbiB0aGUgZW5naW5lJyB9IH0pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JrLWJyb2tlbicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2ZsYWcgdGhyZXcgaW4gdGhlIGVuZ2luZScpO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdPdmVyIGJvdW5kLicpO1xuICB9KTtcblxuICBpdCgncmVmdXNlcyB0cnV0aGluZXNzOiAxLCBcInRydWVcIiBhbmQgYSByb3cgbGlzdCBlYWNoIHJlbmRlciBhIGJyb2tlbiB0aWxlIHNheWluZyB0cnVlIG9yIGZhbHNlJywgKCkgPT4ge1xuICAgIGZvciAoY29uc3QgdiBvZiBbMSwgJ3RydWUnLCBbeyBhOiAxIH1dXSBhcyBWYWx1ZVtdKSB7XG4gICAgICBjb25zdCBodG1sID0gcmVuZGVyKHRwbCwgeyAncHJvY2Vzcy5mbGFnJzogb2sodikgfSk7XG4gICAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1icm9rZW4nKTtcbiAgICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3RydWUgb3IgZmFsc2UnKTtcbiAgICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdPdmVyIGJvdW5kLicpO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoJ2FkZHMgbm8gd3JhcHBlciBlbGVtZW50IGluc2lkZSBhIFJvdyDigJQgdGhlIGNoaWxkIGlzIGEgZGlyZWN0IGNoaWxkIG9mIHRoZSByb3cgY29udGFpbmVyJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoJzxSb3c+PFNob3dXaGVuIHNvdXJjZT1cInByb2Nlc3MuZmxhZ1wiPjxDYWxsb3V0IHRvbmU9XCJkYW5nZXJcIj5PdmVyIGJvdW5kLjwvQ2FsbG91dD48L1Nob3dXaGVuPjwvUm93PicsIHtcbiAgICAgICdwcm9jZXNzLmZsYWcnOiBvayh0cnVlKSxcbiAgICB9KTtcbiAgICBleHBlY3QoaHRtbCkudG9NYXRjaCgvPGRpdiBjbGFzcz1cInJrLXJvd1wiPjxkaXYgY2xhc3M9XCJyay1jYWxsb3V0XCIvKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxTQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxTQUFBLEdBQUFMLE9BQUE7QUFFQSxJQUFBTSxJQUFBLEdBQUFOLE9BQUE7QUFBZ0QsU0FBQUksdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFHaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTRyxFQUFFQSxDQUFDQyxLQUFZLEVBQUVDLElBQXdCLEdBQUcsUUFBUSxFQUFjO0VBQ3pFLE9BQU87SUFBRUQsS0FBSztJQUFFQyxJQUFJO0lBQUVDLE1BQU0sRUFBRTtFQUFLLENBQUM7QUFDdEM7QUFDQSxTQUFTQyxRQUFRQSxDQUFDQyxHQUErQixFQUFZO0VBQzNELE9BQU87SUFBRUMsT0FBTyxFQUFHQyxDQUFDLElBQUtGLEdBQUcsQ0FBQ0UsQ0FBQyxDQUFDLElBQUksSUFBQUMsaUJBQU8sRUFBQ0QsQ0FBQyxDQUFDO0lBQUVFLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLENBQUM7RUFBRSxDQUFDO0FBQ3JFO0FBQ0EsU0FBU0MsTUFBTUEsQ0FBQ0MsR0FBVyxFQUFFTixHQUErQixFQUFVO0VBQ3BFLE9BQU8sSUFBQU8sNEJBQW9CLGVBQUMsSUFBQUMsb0JBQWEsRUFBQ0MsaUJBQVUsRUFBRTtJQUFFQyxLQUFLLEVBQUUsSUFBQUMsa0JBQWEsRUFBQ0wsR0FBRyxDQUFDO0lBQUVQLFFBQVEsRUFBRUEsUUFBUSxDQUFDQyxHQUFHO0VBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEg7QUFFQSxJQUFBWSxnQkFBUSxFQUFDLFlBQVksRUFBRSxNQUFNO0VBQzNCLElBQUFDLFVBQUUsRUFBQywrQ0FBK0MsRUFBRSxNQUFNO0lBQ3hELE1BQU1DLElBQUksR0FBR1QsTUFBTSxDQUFDLGtEQUFrRCxFQUFFO01BQUUsZUFBZSxFQUFFVixFQUFFLENBQUMsU0FBUztJQUFFLENBQUMsQ0FBQztJQUMzRyxJQUFBb0IsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUN0QyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRyxPQUFPLENBQUMsaUNBQWlDLENBQUM7SUFDdkQsSUFBQUYsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztFQUNoRCxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsMENBQTBDLEVBQUUsTUFBTTtJQUNuRCxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQyxnQ0FBZ0MsRUFBRTtNQUFFYSxDQUFDLEVBQUV2QixFQUFFLENBQUMsR0FBRyxDQUFDO01BQUV3QixDQUFDLEVBQUV4QixFQUFFLENBQUMsR0FBRztJQUFFLENBQUMsQ0FBQztJQUNqRixJQUFBb0IsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUN0QyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMscUJBQXFCLENBQUM7RUFDL0MsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07SUFDNUUsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDekQsSUFBQVUsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFdBQVcsQ0FBQztJQUNuQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsbUJBQW1CLENBQUM7RUFDN0MsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLGtEQUFrRCxFQUFFLE1BQU07SUFDM0QsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMsdUJBQXVCLEVBQUU7TUFBRWUsSUFBSSxFQUFFekIsRUFBRSxDQUFDLENBQUM7UUFBRXVCLENBQUMsRUFBRTtNQUFFLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN0RSxJQUFBSCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQyxjQUFjLENBQUM7RUFDdEMsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLDZEQUE2RCxFQUFFLE1BQU07SUFDdEUsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMsMkJBQTJCLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEQsSUFBQVUsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGdCQUFnQixDQUFDO0lBQ3hDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxVQUFVLENBQUM7RUFDcEMsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLGlEQUFpRCxFQUFFLE1BQU07SUFDMUQsTUFBTU8sSUFBSSxHQUFHLENBQUM7TUFBRUMsS0FBSyxFQUFFLEtBQUs7TUFBRUMsT0FBTyxFQUFFO0lBQUcsQ0FBQyxFQUFFO01BQUVELEtBQUssRUFBRSxLQUFLO01BQUVDLE9BQU8sRUFBRTtJQUFHLENBQUMsQ0FBQztJQUMzRSxNQUFNUixJQUFJLEdBQUdULE1BQU0sQ0FBQyx1RUFBdUUsRUFBRTtNQUFFLGtCQUFrQixFQUFFVixFQUFFLENBQUN5QixJQUFJO0lBQUUsQ0FBQyxDQUFDO0lBQzlILElBQUFMLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxNQUFNLENBQUM7SUFDOUIsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFlBQVksQ0FBQztJQUNwQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztFQUNuQyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsMkNBQTJDLEVBQUUsTUFBTTtJQUNwRCxNQUFNTyxJQUFJLEdBQUcsQ0FBQztNQUFFQyxLQUFLLEVBQUUsS0FBSztNQUFFQyxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQUM7SUFDNUMsTUFBTVIsSUFBSSxHQUFHVCxNQUFNLENBQUMscURBQXFELEVBQUU7TUFBRWtCLENBQUMsRUFBRTVCLEVBQUUsQ0FBQ3lCLElBQUk7SUFBRSxDQUFDLENBQUM7SUFDM0YsSUFBQUwsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUNoQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsU0FBUyxDQUFDO0lBQ2pDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxPQUFPLENBQUM7RUFDakMsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLHVGQUF1RixFQUFFLE1BQU07SUFDaEcsTUFBTU8sSUFBSSxHQUFHLENBQUM7TUFBRUMsS0FBSyxFQUFFLEtBQUs7TUFBRUMsT0FBTyxFQUFFO0lBQUcsQ0FBQyxDQUFDO0lBQzVDLE1BQU1SLElBQUksR0FBR1QsTUFBTSxDQUFDLDhEQUE4RCxFQUFFO01BQUVrQixDQUFDLEVBQUU1QixFQUFFLENBQUN5QixJQUFJO0lBQUUsQ0FBQyxDQUFDO0lBQ3BHO0lBQ0EsSUFBQUwsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0csT0FBTyxDQUFDLG1FQUFtRSxDQUFDO0lBQ3pGO0lBQ0EsSUFBQUYsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ1UsR0FBRyxDQUFDUixTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ3ZDO0lBQ0EsTUFBTVMsS0FBSyxHQUFHcEIsTUFBTSxDQUFDLDBDQUEwQyxFQUFFO01BQUVrQixDQUFDLEVBQUU1QixFQUFFLENBQUN5QixJQUFJO0lBQUUsQ0FBQyxDQUFDO0lBQ2pGLElBQUFMLGNBQU0sRUFBQ1UsS0FBSyxDQUFDLENBQUNELEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLFlBQVksQ0FBQztFQUMzQyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsK0NBQStDLEVBQUUsTUFBTTtJQUN4RCxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQyx5Q0FBeUMsRUFBRTtNQUFFLGVBQWUsRUFBRVYsRUFBRSxDQUFDLE1BQU07SUFBRSxDQUFDLENBQUM7SUFDL0YsSUFBQW9CLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxVQUFVLENBQUM7SUFDbEMsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUNoQyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsaURBQWlELEVBQUUsTUFBTTtJQUMxRCxNQUFNTyxJQUFJLEdBQUcsQ0FDWDtNQUFFTSxNQUFNLEVBQUUsR0FBRztNQUFFTCxLQUFLLEVBQUUsS0FBSztNQUFFTSxPQUFPLEVBQUU7SUFBRSxDQUFDLEVBQ3pDO01BQUVELE1BQU0sRUFBRSxHQUFHO01BQUVMLEtBQUssRUFBRSxLQUFLO01BQUVNLE9BQU8sRUFBRTtJQUFFLENBQUMsQ0FDMUM7SUFDRCxNQUFNYixJQUFJLEdBQUdULE1BQU0sQ0FBQyx3RkFBd0YsRUFBRTtNQUFFdUIsS0FBSyxFQUFFakMsRUFBRSxDQUFDeUIsSUFBSTtJQUFFLENBQUMsQ0FBQztJQUNsSSxNQUFNUyxNQUFNLEdBQUdmLElBQUksQ0FBQ2dCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUU7SUFDbEQsSUFBQWYsY0FBTSxFQUFDYyxNQUFNLENBQUMsQ0FBQ0UsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUNoQyxDQUFDLENBQUM7RUFFRixJQUFBbEIsVUFBRSxFQUFDLG9FQUFvRSxFQUFFLE1BQU07SUFDN0UsTUFBTU8sSUFBSSxHQUFHLENBQUM7TUFBRVksR0FBRyxFQUFFLEdBQUc7TUFBRUMsS0FBSyxFQUFFO0lBQUksQ0FBQyxDQUFDO0lBQ3ZDLE1BQU1uQixJQUFJLEdBQUdULE1BQU0sQ0FBQyw2REFBNkQsRUFBRTtNQUFFNkIsR0FBRyxFQUFFdkMsRUFBRSxDQUFDeUIsSUFBSTtJQUFFLENBQUMsQ0FBQztJQUNyRyxJQUFBTCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNyQyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsa0NBQWtDLEVBQUUsTUFBTTtJQUMzQyxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNwRSxJQUFBVSxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsTUFBTSxDQUFDO0lBQzlCLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQztFQUNqRCxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsb0RBQW9ELEVBQUUsTUFBTTtJQUM3RCxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQyw2Q0FBNkMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN0RSxJQUFBVSxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDN0MsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFdBQVcsQ0FBQztFQUNyQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLHlDQUF5QyxFQUFFLE1BQU07RUFDeEQsTUFBTU4sR0FBRyxHQUFHLDRHQUE0RztFQUN4SCxNQUFNTixHQUFHLEdBQUc7SUFBRSxXQUFXLEVBQUU7TUFBRUosS0FBSyxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFLFFBQWlCO01BQUVDLE1BQU0sRUFBRTtJQUFjO0VBQUUsQ0FBQztFQUV6RixJQUFBZSxVQUFFLEVBQUMsbUZBQW1GLEVBQUUsTUFBTTtJQUM1RixNQUFNQyxJQUFJLEdBQUcsSUFBQVAsNEJBQW9CLGVBQy9CLElBQUFDLG9CQUFhLEVBQUNDLGlCQUFVLEVBQUU7TUFDeEJDLEtBQUssRUFBRSxJQUFBQyxrQkFBYSxFQUFDTCxHQUFHLENBQUM7TUFDekJQLFFBQVEsRUFBRUEsUUFBUSxDQUFDQyxHQUFHLENBQUM7TUFDdkJtQyxVQUFVLEVBQUU7UUFBRUMsU0FBUyxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO1FBQUVDLFVBQVUsRUFBRUEsQ0FBQSxLQUFNO01BQUs7SUFDNUQsQ0FBQyxDQUNILENBQUM7SUFDRCxJQUFBdEIsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGdCQUFnQixDQUFDO0lBQ3hDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQztJQUNqRCxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsZ0NBQWdDLENBQUM7SUFDeEQ7SUFDQSxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQ2dCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDdkQsQ0FBQyxDQUFDO0VBRUYsSUFBQWxCLFVBQUUsRUFBQywwREFBMEQsRUFBRSxNQUFNO0lBQ25FLE1BQU1DLElBQUksR0FBRyxJQUFBUCw0QkFBb0IsZUFDL0IsSUFBQUMsb0JBQWEsRUFBQ0MsaUJBQVUsRUFBRTtNQUN4QkMsS0FBSyxFQUFFLElBQUFDLGtCQUFhLEVBQUNMLEdBQUcsQ0FBQztNQUN6QlAsUUFBUSxFQUFFQSxRQUFRLENBQUNDLEdBQUcsQ0FBQztNQUN2Qm1DLFVBQVUsRUFBRTtRQUFFQyxTQUFTLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7UUFBRUMsVUFBVSxFQUFFQSxDQUFBLEtBQU07TUFBTTtJQUM3RCxDQUFDLENBQ0gsQ0FBQztJQUNELElBQUF0QixjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDVSxHQUFHLENBQUNSLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztFQUM5QyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsc0VBQXNFLEVBQUUsTUFBTTtJQUMvRSxNQUFNQyxJQUFJLEdBQUcsSUFBQVAsNEJBQW9CLGVBQUMsSUFBQUMsb0JBQWEsRUFBQ0MsaUJBQVUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsSUFBQUMsa0JBQWEsRUFBQ0wsR0FBRyxDQUFDO01BQUVQLFFBQVEsRUFBRUEsUUFBUSxDQUFDQyxHQUFHO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEgsSUFBQWUsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ1UsR0FBRyxDQUFDUixTQUFTLENBQUMsZ0JBQWdCLENBQUM7SUFDNUMsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ1UsR0FBRyxDQUFDUixTQUFTLENBQUMsZ0JBQWdCLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQUosZ0JBQVEsRUFBQyxNQUFNLEVBQUUsTUFBTTtFQUNyQixNQUFNRixLQUFZLEdBQUcsQ0FDbkI7SUFBRTRCLEVBQUUsRUFBRSxPQUFPO0lBQUVDLEtBQUssRUFBRSxVQUFVO0lBQUVDLEdBQUcsRUFBRSxPQUFPO0lBQUVDLENBQUMsRUFBRSxDQUFDO0lBQUVDLENBQUMsRUFBRSxDQUFDO0lBQUVDLElBQUksRUFBRTtFQUFRLENBQUMsRUFDM0U7SUFBRUwsRUFBRSxFQUFFLFFBQVE7SUFBRUMsS0FBSyxFQUFFLGFBQWE7SUFBRUUsQ0FBQyxFQUFFLEdBQUc7SUFBRUMsQ0FBQyxFQUFFLENBQUM7SUFBRUUsS0FBSyxFQUFFLFNBQVM7SUFBRUQsSUFBSSxFQUFFO0VBQUssQ0FBQyxFQUNsRjtJQUFFTCxFQUFFLEVBQUUsT0FBTztJQUFFQyxLQUFLLEVBQUUsT0FBTztJQUFFRSxDQUFDLEVBQUUsR0FBRztJQUFFQyxDQUFDLEVBQUUsQ0FBQztJQUFFRSxLQUFLLEVBQUUsTUFBTTtJQUFFRCxJQUFJLEVBQUU7RUFBUSxDQUFDLENBQzVFO0VBQ0QsTUFBTUUsS0FBWSxHQUFHLENBQ25CO0lBQUVDLElBQUksRUFBRSxPQUFPO0lBQUVDLEVBQUUsRUFBRSxRQUFRO0lBQUVSLEtBQUssRUFBRSxpQkFBaUI7SUFBRTNDLEtBQUssRUFBRSxDQUFDO0lBQUVvRCxNQUFNLEVBQUUsSUFBSTtJQUFFQyxLQUFLLEVBQUUsSUFBSTtJQUFFTixJQUFJLEVBQUU7RUFBSyxDQUFDLEVBQzFHO0lBQUVHLElBQUksRUFBRSxRQUFRO0lBQUVDLEVBQUUsRUFBRSxPQUFPO0lBQUVSLEtBQUssRUFBRSxPQUFPO0lBQUUzQyxLQUFLLEVBQUU7RUFBSSxDQUFDLEVBQzNEO0lBQUVrRCxJQUFJLEVBQUUsUUFBUTtJQUFFQyxFQUFFLEVBQUUsT0FBTztJQUFFRyxNQUFNLEVBQUUsSUFBSTtJQUFFQyxHQUFHLEVBQUU7RUFBaUIsQ0FBQyxDQUNyRTtFQUNELE1BQU1DLEdBQUcsR0FBRywwRUFBMEU7RUFFdEYsSUFBQXZDLFVBQUUsRUFBQyx5RUFBeUUsRUFBRSxNQUFNO0lBQ2xGLE1BQU1DLElBQUksR0FBR1QsTUFBTSxDQUFDK0MsR0FBRyxFQUFFO01BQUUsV0FBVyxFQUFFekQsRUFBRSxDQUFDZSxLQUFLLENBQUM7TUFBRSxXQUFXLEVBQUVmLEVBQUUsQ0FBQ2tELEtBQUs7SUFBRSxDQUFDLENBQUM7SUFDNUUsSUFBQTlCLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxNQUFNLENBQUM7SUFDOUIsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFlBQVksQ0FBQztJQUNwQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsZUFBZSxDQUFDO0lBQ3ZDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQyxzRUFBc0UsQ0FBQztJQUM1RixJQUFBRixjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsbUJBQW1CLENBQUM7SUFDM0MsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLEtBQUssQ0FBQztJQUM3QixJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsZ0JBQWdCLENBQUM7SUFDeEMsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGVBQWUsQ0FBQztJQUN2QyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQ2dCLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDcEQsSUFBQWhCLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztJQUN4QyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsNElBQTRJLENBQUM7RUFDdEssQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLDBDQUEwQyxFQUFFLE1BQU07SUFDbkQsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMrQyxHQUFHLEVBQUU7TUFBRSxXQUFXLEVBQUV6RCxFQUFFLENBQUNlLEtBQUs7SUFBRSxDQUFDLENBQUM7SUFDcEQsSUFBQUssY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLG1CQUFtQixDQUFDO0lBQzNDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNVLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUNwQyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsOERBQThELEVBQUUsTUFBTTtJQUN2RSxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQytDLEdBQUcsRUFBRTtNQUFFLFdBQVcsRUFBRXpELEVBQUUsQ0FBQ2UsS0FBSyxDQUFDO01BQUUsV0FBVyxFQUFFZixFQUFFLENBQUMsQ0FBQztRQUFFbUQsSUFBSSxFQUFFLE9BQU87UUFBRUMsRUFBRSxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pHLElBQUFoQyxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyxxQ0FBcUMsQ0FBQztJQUM3RCxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDVSxHQUFHLENBQUNSLFNBQVMsQ0FBQyxNQUFNLENBQUM7RUFDcEMsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLHFDQUFxQyxFQUFFLE1BQU07SUFDOUMsTUFBTXdDLElBQUksR0FBR0MsS0FBSyxDQUFDUixJQUFJLENBQUM7TUFBRVMsTUFBTSxFQUFFO0lBQUcsQ0FBQyxFQUFFLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxNQUFNO01BQUVuQixFQUFFLEVBQUUsSUFBSW1CLENBQUMsRUFBRTtNQUFFbEIsS0FBSyxFQUFFLElBQUlrQixDQUFDLEVBQUU7TUFBRWhCLENBQUMsRUFBRWdCLENBQUMsR0FBRyxFQUFFO01BQUVmLENBQUMsRUFBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3JHLE1BQU01QixJQUFJLEdBQUdULE1BQU0sQ0FBQytDLEdBQUcsRUFBRTtNQUFFLFdBQVcsRUFBRXpELEVBQUUsQ0FBQzBELElBQUksQ0FBQztNQUFFLFdBQVcsRUFBRTFELEVBQUUsQ0FBQyxFQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLElBQUFvQixjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQyxhQUFhLENBQUM7RUFDckMsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLHNDQUFzQyxFQUFFLE1BQU07SUFDL0MsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMrQyxHQUFHLEVBQUU7TUFBRSxXQUFXLEVBQUV6RCxFQUFFLENBQUMsQ0FBQyxDQUFDO01BQUUsV0FBVyxFQUFFQSxFQUFFLENBQUMsRUFBRTtJQUFFLENBQUMsQ0FBQztJQUNyRSxJQUFBb0IsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGlDQUFpQyxDQUFDO0VBQzNELENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyxnRkFBZ0YsRUFBRSxNQUFNO0lBQ3pGLE1BQU1DLElBQUksR0FBRyxJQUFBUCw0QkFBb0IsZUFDL0IsSUFBQUMsb0JBQWEsRUFBQ0MsaUJBQVUsRUFBRTtNQUN4QkMsS0FBSyxFQUFFLElBQUFDLGtCQUFhLEVBQUN5QyxHQUFHLENBQUM7TUFDekJyRCxRQUFRLEVBQUVBLFFBQVEsQ0FBQztRQUFFLFdBQVcsRUFBRUosRUFBRSxDQUFDZSxLQUFLLENBQUM7UUFBRSxXQUFXLEVBQUVmLEVBQUUsQ0FBQ2tELEtBQUs7TUFBRSxDQUFDLENBQUM7TUFDdEVWLFVBQVUsRUFBRTtRQUFFQyxTQUFTLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7UUFBRUMsVUFBVSxFQUFFQSxDQUFBLEtBQU07TUFBSztJQUM1RCxDQUFDLENBQ0gsQ0FBQztJQUNELElBQUF0QixjQUFNLEVBQUNELElBQUksQ0FBQ2dCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDckQsSUFBQWhCLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQztFQUNuRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLFVBQVUsRUFBRSxNQUFNO0VBQ3pCLE1BQU13QyxHQUFHLEdBQUcseUZBQXlGO0VBRXJHLElBQUF2QyxVQUFFLEVBQUMsMERBQTBELEVBQUUsTUFBTTtJQUNuRSxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQytDLEdBQUcsRUFBRTtNQUFFLGNBQWMsRUFBRXpELEVBQUUsQ0FBQyxJQUFJO0lBQUUsQ0FBQyxDQUFDO0lBQ3RELElBQUFvQixjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsb0JBQW9CLENBQUM7SUFDNUMsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLGFBQWEsQ0FBQztJQUNyQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDVSxHQUFHLENBQUNSLFNBQVMsQ0FBQyxXQUFXLENBQUM7RUFDekMsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07SUFDNUUsTUFBTUMsSUFBSSxHQUFHVCxNQUFNLENBQUMrQyxHQUFHLEVBQUU7TUFBRSxjQUFjLEVBQUV6RCxFQUFFLENBQUMsS0FBSztJQUFFLENBQUMsQ0FBQztJQUN2RCxJQUFBb0IsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ1UsR0FBRyxDQUFDUixTQUFTLENBQUMsYUFBYSxDQUFDO0lBQ3pDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNVLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLFdBQVcsQ0FBQztFQUN6QyxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsaURBQWlELEVBQUUsTUFBTTtJQUMxRCxNQUFNQyxJQUFJLEdBQUdULE1BQU0sQ0FBQytDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM1QixJQUFBckMsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFdBQVcsQ0FBQztJQUNuQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsbUJBQW1CLENBQUM7SUFDM0MsSUFBQUQsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ1UsR0FBRyxDQUFDUixTQUFTLENBQUMsYUFBYSxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyw2REFBNkQsRUFBRSxNQUFNO0lBQ3RFLE1BQU1DLElBQUksR0FBR1QsTUFBTSxDQUFDK0MsR0FBRyxFQUFFO01BQUUsY0FBYyxFQUFFO1FBQUV4RCxLQUFLLEVBQUUsSUFBSTtRQUFFQyxJQUFJLEVBQUUsUUFBUTtRQUFFQyxNQUFNLEVBQUUsT0FBTztRQUFFNEQsT0FBTyxFQUFFO01BQTJCO0lBQUUsQ0FBQyxDQUFDO0lBQ25JLElBQUEzQyxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQztJQUNsRCxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDVSxHQUFHLENBQUNSLFNBQVMsQ0FBQyxhQUFhLENBQUM7RUFDM0MsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLDZGQUE2RixFQUFFLE1BQU07SUFDdEcsS0FBSyxNQUFNOEMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDO01BQUV6QyxDQUFDLEVBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFhO01BQ2xELE1BQU1KLElBQUksR0FBR1QsTUFBTSxDQUFDK0MsR0FBRyxFQUFFO1FBQUUsY0FBYyxFQUFFekQsRUFBRSxDQUFDZ0UsQ0FBQztNQUFFLENBQUMsQ0FBQztNQUNuRCxJQUFBNUMsY0FBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLFdBQVcsQ0FBQztNQUNuQyxJQUFBRCxjQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDRSxTQUFTLENBQUMsZUFBZSxDQUFDO01BQ3ZDLElBQUFELGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNVLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLGFBQWEsQ0FBQztJQUMzQztFQUNGLENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyx5RkFBeUYsRUFBRSxNQUFNO0lBQ2xHLE1BQU1DLElBQUksR0FBR1QsTUFBTSxDQUFDLG9HQUFvRyxFQUFFO01BQ3hILGNBQWMsRUFBRVYsRUFBRSxDQUFDLElBQUk7SUFDekIsQ0FBQyxDQUFDO0lBQ0YsSUFBQW9CLGNBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQyw2Q0FBNkMsQ0FBQztFQUNyRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}