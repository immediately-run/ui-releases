var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
require("./index.css");
require("./app/report-page.css");
var _react = require("react");
var _useReport = require("./hooks/useReport.ts");
var _seeds = require("./seed/seeds.ts");
var _useAppPath = require("./hooks/useAppPath.ts");
var _DocumentNav = _interopRequireDefault(require("./app/DocumentNav.tsx"));
var _DocumentChangedNotice = _interopRequireDefault(require("./app/DocumentChangedNotice.tsx"));
var _useMounts = require("./hooks/useMounts.ts");
var _dispatch = require("./app/dispatch.ts");
var _useEditFile = require("./hooks/useEditFile.ts");
var _index2 = require("./report/index.ts");
var _WorkbookPanel = _interopRequireDefault(require("./app/WorkbookPanel.tsx"));
var _ValueInspector = _interopRequireDefault(require("./app/ValueInspector.tsx"));
var _WhatIfPanel = _interopRequireDefault(require("./app/WhatIfPanel.tsx"));
var _AuthorsView = _interopRequireDefault(require("./app/AuthorsView.tsx"));
var _useOverlayDialog = require("./app/useOverlayDialog.ts");
var _useVerdicts = require("./hooks/useVerdicts.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — the default export of THIS file is what renders. immediately.run reaches it
// through `src/platform.tsx` (`package.json` → `main`), which exists only to call
// `boot({ children: <App /> })` so the app owns a path space (R3-553); `src/main.tsx` is the
// `vite dev` entry and is ignored at runtime (ARCHITECTURE_PLAN §2.1, §7). Reckoner opens a document and renders it as a static report with zero prompts:
// the hook loads the bundled demo document, runs the SES-confined engine, and hands the render
// surface a Bindings port over the results. Global CSS is imported here (not main.tsx), which
// immediately.run's runtime ignores.
//
// The inspected cell is app-level state shared by the two doors into the value inspector:
// the workbook panel's cards (author surface) and V3's on-pixel affordance on bound report
// elements (hover-reveal / long-press) — both open the same docked inspector.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  // The app-space PATH picks the bundled document (`/caldera`; `/` is the Meridian
  // monthly review), falling back to the legacy `?doc=` query — which the host forwards only
  // at boot, so it cannot survive navigation and is compatibility only (R3-553). The picked
  // seed is a module constant, so the reference is stable across renders.
  const appPath = (0, _useAppPath.useAppPath)();
  const hostLoc = (0, _useAppPath.useHostLocation)();
  const mounts = (0, _useMounts.useMounts)();
  const seed = (0, _seeds.seedForBoot)(appPath, window.location);
  const report = (0, _useReport.useReport)(seed, mounts);
  // Part B (R3-447): the dispatched workbook's edit door. The mount the resolution
  // carries is the whole contract — writability by the positive `rw` check, and the
  // `capFile` address from the descriptor's universal id. Absent (never disabled) in
  // the seed flow and on any non-`rw` mount.
  const dispatch = (0, _dispatch.resolveWorkbookMount)(mounts);
  const editFile = (0, _useEditFile.useEditFile)(dispatch.ok ? dispatch.mount : null);
  const [reviewOpen, setReviewOpen] = (0, _react.useState)(false);
  const [inspected, setInspected] = (0, _react.useState)(null);
  // What-if buffer text is SESSION-SCOPED app state (WHATIF_SHADOW_EVALUATION_SPEC §1.4):
  // closing a panel must never destroy typed source, so the per-cell variants and the
  // scratch pad's buffer live here, above the panels' mount/unmount lifecycle.
  const [variants, setVariants] = (0, _react.useState)({});
  const [scratchText, setScratchText] = (0, _react.useState)('');
  // The what-if section is collapsed by default (spec §1.1, amended 2026-08-28): the
  // formula row's "what if →" affordance opens it, and it stays open on its own whenever
  // the cell's variant text differs from the document formula — typed source never hides.
  // Keyed by cell id rather than reset in an effect: navigating to another cell makes
  // the door closed again by derivation (react-hooks/set-state-in-effect stays happy).
  const [whatIfOpenFor, setWhatIfOpenFor] = (0, _react.useState)(null);
  // The author's view (AUTHORS_VIEW_SPEC §1.2): opened from the workbook panel (its
  // door), rendered in place of the report with an explicit way back. Component state,
  // not a route.
  const [authorsOpen, setAuthorsOpen] = (0, _react.useState)(false);
  const title = report.status === 'ready' ? report.session.title : undefined;
  (0, _react.useEffect)(() => {
    if (title !== undefined) document.title = title;
  }, [title]);
  const inspectedCell = report.status === 'ready' && inspected !== null ? report.session.engine.cells().find(c => c.id === inspected) ?? null : null;

  // V3's inspection port: bound elements offer hover/long-press inspection of the CELL they
  // display (externals — params/fixtures — have no inspector card, so no affordance there).
  const inspection = (0, _react.useMemo)(() => report.status === 'ready' ? {
    onInspect: setInspected,
    canInspect: source => report.session.engine.cells().some(c => c.id === source)
  } : null, [report]);
  const verdicts = (0, _useVerdicts.useVerdicts)(report.status === 'ready' ? report.session.engine : null, report.status === 'ready' ? report.tick : 0);

  // The inspector dock's dialog contract (R3-610) — focus in on open, Tab wrap, keyed
  // close, focus back to the card or report affordance that opened it — lives in one
  // hook; `enabled` flips with the dock's own conditional mount, so the effect and the
  // element appear together.
  const inspectorRef = (0, _useOverlayDialog.useOverlayDialog)(() => setInspected(null), {
    enabled: inspectedCell !== null
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("main", {
    className: "rk-page",
    children: [report.status === 'loading' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-page-note",
      children: "Loading report\u2026"
    }), report.status === 'error' && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-page-note rk-page-error",
      children: ["Could not load the report: ", report.message]
    }), report.status === 'ready' && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
        className: "rk-page-head",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_DocumentNav.default, {
          loc: hostLoc,
          current: seed
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
          className: "grad-text",
          children: report.session.title
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-review-toggle",
          onClick: () => setReviewOpen(v => !v),
          children: reviewOpen ? 'Close workbook' : 'Workbook'
        })]
      }), editFile.edited && /*#__PURE__*/(0, _jsxRuntime.jsx)(_DocumentChangedNotice.default, {
        onReload: () => {
          report.reload();
          editFile.clearStale();
        }
      }), editFile.notice !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-stale rk-stale--note",
        role: "status",
        children: editFile.notice
      }), authorsOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_AuthorsView.default, {
        session: report.session,
        bindings: report.bindings,
        verdicts: verdicts.results,
        onClose: () => setAuthorsOpen(false)
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_index2.ReportView, {
        nodes: report.session.nodes,
        bindings: report.bindings,
        inspection: inspection ?? undefined
      }), reviewOpen && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WorkbookPanel.default, {
        session: report.session,
        verdicts: verdicts,
        onInspect: setInspected,
        onClose: () => setReviewOpen(false),
        onOpenAuthors: () => {
          setReviewOpen(false);
          setAuthorsOpen(true);
        },
        scratchText: scratchText,
        onScratchChange: setScratchText
      }), inspectedCell !== null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-inspector-dock",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Value inspector",
        ref: inspectorRef,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_ValueInspector.default, {
          cell: inspectedCell,
          cells: report.session.engine.cells(),
          tests: report.session.engine.tests().filter(t => t.subject === inspectedCell.id),
          verdicts: verdicts.results,
          result: report.session.engine.result(inspectedCell.id),
          onNavigate: setInspected,
          onClose: () => setInspected(null),
          onWhatIf: () => setWhatIfOpenFor(inspectedCell.id),
          worksheetPaths: Object.fromEntries(report.session.loaded.worksheets.map(w => [w.name, w.path])),
          canEditPath: editFile.canEditPath,
          onEdit: editFile.onEdit
        }), (whatIfOpenFor === inspectedCell.id || variants[inspectedCell.id] !== undefined && variants[inspectedCell.id] !== inspectedCell.formulaSource) && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WhatIfPanel.default, {
          session: report.session,
          cell: inspectedCell,
          baseVerdicts: verdicts.results,
          text: variants[inspectedCell.id] ?? inspectedCell.formulaSource,
          onTextChange: (cellId, text) => setVariants(v => ({
            ...v,
            [cellId]: text
          }))
        })]
      })]
    })]
  });
}
_s(App, "Z5F//nRXC8aNjxa0mkJ+O+SVRJ0=", false, function () {
  return [_useAppPath.useAppPath, _useAppPath.useHostLocation, _useMounts.useMounts, _useReport.useReport, _useEditFile.useEditFile, _useVerdicts.useVerdicts, _useOverlayDialog.useOverlayDialog];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3JlYWN0IiwiX3VzZVJlcG9ydCIsIl9zZWVkcyIsIl91c2VBcHBQYXRoIiwiX0RvY3VtZW50TmF2IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Eb2N1bWVudENoYW5nZWROb3RpY2UiLCJfdXNlTW91bnRzIiwiX2Rpc3BhdGNoIiwiX3VzZUVkaXRGaWxlIiwiX2luZGV4MiIsIl9Xb3JrYm9va1BhbmVsIiwiX1ZhbHVlSW5zcGVjdG9yIiwiX1doYXRJZlBhbmVsIiwiX0F1dGhvcnNWaWV3IiwiX3VzZU92ZXJsYXlEaWFsb2ciLCJfdXNlVmVyZGljdHMiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwiYXBwUGF0aCIsInVzZUFwcFBhdGgiLCJob3N0TG9jIiwidXNlSG9zdExvY2F0aW9uIiwibW91bnRzIiwidXNlTW91bnRzIiwic2VlZCIsInNlZWRGb3JCb290Iiwid2luZG93IiwibG9jYXRpb24iLCJyZXBvcnQiLCJ1c2VSZXBvcnQiLCJkaXNwYXRjaCIsInJlc29sdmVXb3JrYm9va01vdW50IiwiZWRpdEZpbGUiLCJ1c2VFZGl0RmlsZSIsIm9rIiwibW91bnQiLCJyZXZpZXdPcGVuIiwic2V0UmV2aWV3T3BlbiIsInVzZVN0YXRlIiwiaW5zcGVjdGVkIiwic2V0SW5zcGVjdGVkIiwidmFyaWFudHMiLCJzZXRWYXJpYW50cyIsInNjcmF0Y2hUZXh0Iiwic2V0U2NyYXRjaFRleHQiLCJ3aGF0SWZPcGVuRm9yIiwic2V0V2hhdElmT3BlbkZvciIsImF1dGhvcnNPcGVuIiwic2V0QXV0aG9yc09wZW4iLCJ0aXRsZSIsInN0YXR1cyIsInNlc3Npb24iLCJ1bmRlZmluZWQiLCJ1c2VFZmZlY3QiLCJkb2N1bWVudCIsImluc3BlY3RlZENlbGwiLCJlbmdpbmUiLCJjZWxscyIsImZpbmQiLCJjIiwiaWQiLCJpbnNwZWN0aW9uIiwidXNlTWVtbyIsIm9uSW5zcGVjdCIsImNhbkluc3BlY3QiLCJzb3VyY2UiLCJzb21lIiwidmVyZGljdHMiLCJ1c2VWZXJkaWN0cyIsInRpY2siLCJpbnNwZWN0b3JSZWYiLCJ1c2VPdmVybGF5RGlhbG9nIiwiZW5hYmxlZCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIm1lc3NhZ2UiLCJGcmFnbWVudCIsImxvYyIsImN1cnJlbnQiLCJ0eXBlIiwib25DbGljayIsInYiLCJlZGl0ZWQiLCJvblJlbG9hZCIsInJlbG9hZCIsImNsZWFyU3RhbGUiLCJub3RpY2UiLCJyb2xlIiwiYmluZGluZ3MiLCJyZXN1bHRzIiwib25DbG9zZSIsIlJlcG9ydFZpZXciLCJub2RlcyIsIm9uT3BlbkF1dGhvcnMiLCJvblNjcmF0Y2hDaGFuZ2UiLCJyZWYiLCJjZWxsIiwidGVzdHMiLCJmaWx0ZXIiLCJ0Iiwic3ViamVjdCIsInJlc3VsdCIsIm9uTmF2aWdhdGUiLCJvbldoYXRJZiIsIndvcmtzaGVldFBhdGhzIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJsb2FkZWQiLCJ3b3Jrc2hlZXRzIiwibWFwIiwidyIsIm5hbWUiLCJwYXRoIiwiY2FuRWRpdFBhdGgiLCJvbkVkaXQiLCJmb3JtdWxhU291cmNlIiwiYmFzZVZlcmRpY3RzIiwidGV4dCIsIm9uVGV4dENoYW5nZSIsImNlbGxJZCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZSBpcyB3aGF0IHJlbmRlcnMuIGltbWVkaWF0ZWx5LnJ1biByZWFjaGVzIGl0XG4vLyB0aHJvdWdoIGBzcmMvcGxhdGZvcm0udHN4YCAoYHBhY2thZ2UuanNvbmAg4oaSIGBtYWluYCksIHdoaWNoIGV4aXN0cyBvbmx5IHRvIGNhbGxcbi8vIGBib290KHsgY2hpbGRyZW46IDxBcHAgLz4gfSlgIHNvIHRoZSBhcHAgb3ducyBhIHBhdGggc3BhY2UgKFIzLTU1Myk7IGBzcmMvbWFpbi50c3hgIGlzIHRoZVxuLy8gYHZpdGUgZGV2YCBlbnRyeSBhbmQgaXMgaWdub3JlZCBhdCBydW50aW1lIChBUkNISVRFQ1RVUkVfUExBTiDCpzIuMSwgwqc3KS4gUmVja29uZXIgb3BlbnMgYSBkb2N1bWVudCBhbmQgcmVuZGVycyBpdCBhcyBhIHN0YXRpYyByZXBvcnQgd2l0aCB6ZXJvIHByb21wdHM6XG4vLyB0aGUgaG9vayBsb2FkcyB0aGUgYnVuZGxlZCBkZW1vIGRvY3VtZW50LCBydW5zIHRoZSBTRVMtY29uZmluZWQgZW5naW5lLCBhbmQgaGFuZHMgdGhlIHJlbmRlclxuLy8gc3VyZmFjZSBhIEJpbmRpbmdzIHBvcnQgb3ZlciB0aGUgcmVzdWx0cy4gR2xvYmFsIENTUyBpcyBpbXBvcnRlZCBoZXJlIChub3QgbWFpbi50c3gpLCB3aGljaFxuLy8gaW1tZWRpYXRlbHkucnVuJ3MgcnVudGltZSBpZ25vcmVzLlxuLy9cbi8vIFRoZSBpbnNwZWN0ZWQgY2VsbCBpcyBhcHAtbGV2ZWwgc3RhdGUgc2hhcmVkIGJ5IHRoZSB0d28gZG9vcnMgaW50byB0aGUgdmFsdWUgaW5zcGVjdG9yOlxuLy8gdGhlIHdvcmtib29rIHBhbmVsJ3MgY2FyZHMgKGF1dGhvciBzdXJmYWNlKSBhbmQgVjMncyBvbi1waXhlbCBhZmZvcmRhbmNlIG9uIGJvdW5kIHJlcG9ydFxuLy8gZWxlbWVudHMgKGhvdmVyLXJldmVhbCAvIGxvbmctcHJlc3MpIOKAlCBib3RoIG9wZW4gdGhlIHNhbWUgZG9ja2VkIGluc3BlY3Rvci5cbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0ICcuL2FwcC9yZXBvcnQtcGFnZS5jc3MnO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlcG9ydCB9IGZyb20gJy4vaG9va3MvdXNlUmVwb3J0LnRzJztcbmltcG9ydCB7IHNlZWRGb3JCb290IH0gZnJvbSAnLi9zZWVkL3NlZWRzLnRzJztcbmltcG9ydCB7IHVzZUFwcFBhdGgsIHVzZUhvc3RMb2NhdGlvbiB9IGZyb20gJy4vaG9va3MvdXNlQXBwUGF0aC50cyc7XG5pbXBvcnQgRG9jdW1lbnROYXYgZnJvbSAnLi9hcHAvRG9jdW1lbnROYXYudHN4JztcbmltcG9ydCBEb2N1bWVudENoYW5nZWROb3RpY2UgZnJvbSAnLi9hcHAvRG9jdW1lbnRDaGFuZ2VkTm90aWNlLnRzeCc7XG5pbXBvcnQgeyB1c2VNb3VudHMgfSBmcm9tICcuL2hvb2tzL3VzZU1vdW50cy50cyc7XG5pbXBvcnQgeyByZXNvbHZlV29ya2Jvb2tNb3VudCB9IGZyb20gJy4vYXBwL2Rpc3BhdGNoLnRzJztcbmltcG9ydCB7IHVzZUVkaXRGaWxlIH0gZnJvbSAnLi9ob29rcy91c2VFZGl0RmlsZS50cyc7XG5pbXBvcnQgeyBSZXBvcnRWaWV3IH0gZnJvbSAnLi9yZXBvcnQvaW5kZXgudHMnO1xuaW1wb3J0IFdvcmtib29rUGFuZWwgZnJvbSAnLi9hcHAvV29ya2Jvb2tQYW5lbC50c3gnO1xuaW1wb3J0IFZhbHVlSW5zcGVjdG9yIGZyb20gJy4vYXBwL1ZhbHVlSW5zcGVjdG9yLnRzeCc7XG5pbXBvcnQgV2hhdElmUGFuZWwgZnJvbSAnLi9hcHAvV2hhdElmUGFuZWwudHN4JztcbmltcG9ydCBBdXRob3JzVmlldyBmcm9tICcuL2FwcC9BdXRob3JzVmlldy50c3gnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheURpYWxvZyB9IGZyb20gJy4vYXBwL3VzZU92ZXJsYXlEaWFsb2cudHMnO1xuaW1wb3J0IHsgdXNlVmVyZGljdHMgfSBmcm9tICcuL2hvb2tzL3VzZVZlcmRpY3RzLnRzJztcblxuZnVuY3Rpb24gQXBwKCkge1xuICAvLyBUaGUgYXBwLXNwYWNlIFBBVEggcGlja3MgdGhlIGJ1bmRsZWQgZG9jdW1lbnQgKGAvY2FsZGVyYWA7IGAvYCBpcyB0aGUgTWVyaWRpYW5cbiAgLy8gbW9udGhseSByZXZpZXcpLCBmYWxsaW5nIGJhY2sgdG8gdGhlIGxlZ2FjeSBgP2RvYz1gIHF1ZXJ5IOKAlCB3aGljaCB0aGUgaG9zdCBmb3J3YXJkcyBvbmx5XG4gIC8vIGF0IGJvb3QsIHNvIGl0IGNhbm5vdCBzdXJ2aXZlIG5hdmlnYXRpb24gYW5kIGlzIGNvbXBhdGliaWxpdHkgb25seSAoUjMtNTUzKS4gVGhlIHBpY2tlZFxuICAvLyBzZWVkIGlzIGEgbW9kdWxlIGNvbnN0YW50LCBzbyB0aGUgcmVmZXJlbmNlIGlzIHN0YWJsZSBhY3Jvc3MgcmVuZGVycy5cbiAgY29uc3QgYXBwUGF0aCA9IHVzZUFwcFBhdGgoKTtcbiAgY29uc3QgaG9zdExvYyA9IHVzZUhvc3RMb2NhdGlvbigpO1xuICBjb25zdCBtb3VudHMgPSB1c2VNb3VudHMoKTtcbiAgY29uc3Qgc2VlZCA9IHNlZWRGb3JCb290KGFwcFBhdGgsIHdpbmRvdy5sb2NhdGlvbik7XG4gIGNvbnN0IHJlcG9ydCA9IHVzZVJlcG9ydChzZWVkLCBtb3VudHMpO1xuICAvLyBQYXJ0IEIgKFIzLTQ0Nyk6IHRoZSBkaXNwYXRjaGVkIHdvcmtib29rJ3MgZWRpdCBkb29yLiBUaGUgbW91bnQgdGhlIHJlc29sdXRpb25cbiAgLy8gY2FycmllcyBpcyB0aGUgd2hvbGUgY29udHJhY3Qg4oCUIHdyaXRhYmlsaXR5IGJ5IHRoZSBwb3NpdGl2ZSBgcndgIGNoZWNrLCBhbmQgdGhlXG4gIC8vIGBjYXBGaWxlYCBhZGRyZXNzIGZyb20gdGhlIGRlc2NyaXB0b3IncyB1bml2ZXJzYWwgaWQuIEFic2VudCAobmV2ZXIgZGlzYWJsZWQpIGluXG4gIC8vIHRoZSBzZWVkIGZsb3cgYW5kIG9uIGFueSBub24tYHJ3YCBtb3VudC5cbiAgY29uc3QgZGlzcGF0Y2ggPSByZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMpO1xuICBjb25zdCBlZGl0RmlsZSA9IHVzZUVkaXRGaWxlKGRpc3BhdGNoLm9rID8gZGlzcGF0Y2gubW91bnQgOiBudWxsKTtcbiAgY29uc3QgW3Jldmlld09wZW4sIHNldFJldmlld09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaW5zcGVjdGVkLCBzZXRJbnNwZWN0ZWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIC8vIFdoYXQtaWYgYnVmZmVyIHRleHQgaXMgU0VTU0lPTi1TQ09QRUQgYXBwIHN0YXRlIChXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQyDCpzEuNCk6XG4gIC8vIGNsb3NpbmcgYSBwYW5lbCBtdXN0IG5ldmVyIGRlc3Ryb3kgdHlwZWQgc291cmNlLCBzbyB0aGUgcGVyLWNlbGwgdmFyaWFudHMgYW5kIHRoZVxuICAvLyBzY3JhdGNoIHBhZCdzIGJ1ZmZlciBsaXZlIGhlcmUsIGFib3ZlIHRoZSBwYW5lbHMnIG1vdW50L3VubW91bnQgbGlmZWN5Y2xlLlxuICBjb25zdCBbdmFyaWFudHMsIHNldFZhcmlhbnRzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcbiAgY29uc3QgW3NjcmF0Y2hUZXh0LCBzZXRTY3JhdGNoVGV4dF0gPSB1c2VTdGF0ZSgnJyk7XG4gIC8vIFRoZSB3aGF0LWlmIHNlY3Rpb24gaXMgY29sbGFwc2VkIGJ5IGRlZmF1bHQgKHNwZWMgwqcxLjEsIGFtZW5kZWQgMjAyNi0wOC0yOCk6IHRoZVxuICAvLyBmb3JtdWxhIHJvdydzIFwid2hhdCBpZiDihpJcIiBhZmZvcmRhbmNlIG9wZW5zIGl0LCBhbmQgaXQgc3RheXMgb3BlbiBvbiBpdHMgb3duIHdoZW5ldmVyXG4gIC8vIHRoZSBjZWxsJ3MgdmFyaWFudCB0ZXh0IGRpZmZlcnMgZnJvbSB0aGUgZG9jdW1lbnQgZm9ybXVsYSDigJQgdHlwZWQgc291cmNlIG5ldmVyIGhpZGVzLlxuICAvLyBLZXllZCBieSBjZWxsIGlkIHJhdGhlciB0aGFuIHJlc2V0IGluIGFuIGVmZmVjdDogbmF2aWdhdGluZyB0byBhbm90aGVyIGNlbGwgbWFrZXNcbiAgLy8gdGhlIGRvb3IgY2xvc2VkIGFnYWluIGJ5IGRlcml2YXRpb24gKHJlYWN0LWhvb2tzL3NldC1zdGF0ZS1pbi1lZmZlY3Qgc3RheXMgaGFwcHkpLlxuICBjb25zdCBbd2hhdElmT3BlbkZvciwgc2V0V2hhdElmT3BlbkZvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgLy8gVGhlIGF1dGhvcidzIHZpZXcgKEFVVEhPUlNfVklFV19TUEVDIMKnMS4yKTogb3BlbmVkIGZyb20gdGhlIHdvcmtib29rIHBhbmVsIChpdHNcbiAgLy8gZG9vciksIHJlbmRlcmVkIGluIHBsYWNlIG9mIHRoZSByZXBvcnQgd2l0aCBhbiBleHBsaWNpdCB3YXkgYmFjay4gQ29tcG9uZW50IHN0YXRlLFxuICAvLyBub3QgYSByb3V0ZS5cbiAgY29uc3QgW2F1dGhvcnNPcGVuLCBzZXRBdXRob3JzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHRpdGxlID0gcmVwb3J0LnN0YXR1cyA9PT0gJ3JlYWR5JyA/IHJlcG9ydC5zZXNzaW9uLnRpdGxlIDogdW5kZWZpbmVkO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0aXRsZSAhPT0gdW5kZWZpbmVkKSBkb2N1bWVudC50aXRsZSA9IHRpdGxlO1xuICB9LCBbdGl0bGVdKTtcblxuICBjb25zdCBpbnNwZWN0ZWRDZWxsID1cbiAgICByZXBvcnQuc3RhdHVzID09PSAncmVhZHknICYmIGluc3BlY3RlZCAhPT0gbnVsbFxuICAgICAgPyByZXBvcnQuc2Vzc2lvbi5lbmdpbmUuY2VsbHMoKS5maW5kKChjKSA9PiBjLmlkID09PSBpbnNwZWN0ZWQpID8/IG51bGxcbiAgICAgIDogbnVsbDtcblxuICAvLyBWMydzIGluc3BlY3Rpb24gcG9ydDogYm91bmQgZWxlbWVudHMgb2ZmZXIgaG92ZXIvbG9uZy1wcmVzcyBpbnNwZWN0aW9uIG9mIHRoZSBDRUxMIHRoZXlcbiAgLy8gZGlzcGxheSAoZXh0ZXJuYWxzIOKAlCBwYXJhbXMvZml4dHVyZXMg4oCUIGhhdmUgbm8gaW5zcGVjdG9yIGNhcmQsIHNvIG5vIGFmZm9yZGFuY2UgdGhlcmUpLlxuICBjb25zdCBpbnNwZWN0aW9uID0gdXNlTWVtbyhcbiAgICAoKSA9PlxuICAgICAgcmVwb3J0LnN0YXR1cyA9PT0gJ3JlYWR5J1xuICAgICAgICA/IHtcbiAgICAgICAgICAgIG9uSW5zcGVjdDogc2V0SW5zcGVjdGVkLFxuICAgICAgICAgICAgY2FuSW5zcGVjdDogKHNvdXJjZTogc3RyaW5nKSA9PiByZXBvcnQuc2Vzc2lvbi5lbmdpbmUuY2VsbHMoKS5zb21lKChjKSA9PiBjLmlkID09PSBzb3VyY2UpLFxuICAgICAgICAgIH1cbiAgICAgICAgOiBudWxsLFxuICAgIFtyZXBvcnRdLFxuICApO1xuXG4gIGNvbnN0IHZlcmRpY3RzID0gdXNlVmVyZGljdHMoXG4gICAgcmVwb3J0LnN0YXR1cyA9PT0gJ3JlYWR5JyA/IHJlcG9ydC5zZXNzaW9uLmVuZ2luZSA6IG51bGwsXG4gICAgcmVwb3J0LnN0YXR1cyA9PT0gJ3JlYWR5JyA/IHJlcG9ydC50aWNrIDogMCxcbiAgKTtcblxuICAvLyBUaGUgaW5zcGVjdG9yIGRvY2sncyBkaWFsb2cgY29udHJhY3QgKFIzLTYxMCkg4oCUIGZvY3VzIGluIG9uIG9wZW4sIFRhYiB3cmFwLCBrZXllZFxuICAvLyBjbG9zZSwgZm9jdXMgYmFjayB0byB0aGUgY2FyZCBvciByZXBvcnQgYWZmb3JkYW5jZSB0aGF0IG9wZW5lZCBpdCDigJQgbGl2ZXMgaW4gb25lXG4gIC8vIGhvb2s7IGBlbmFibGVkYCBmbGlwcyB3aXRoIHRoZSBkb2NrJ3Mgb3duIGNvbmRpdGlvbmFsIG1vdW50LCBzbyB0aGUgZWZmZWN0IGFuZCB0aGVcbiAgLy8gZWxlbWVudCBhcHBlYXIgdG9nZXRoZXIuXG4gIGNvbnN0IGluc3BlY3RvclJlZiA9IHVzZU92ZXJsYXlEaWFsb2c8SFRNTERpdkVsZW1lbnQ+KCgpID0+IHNldEluc3BlY3RlZChudWxsKSwge1xuICAgIGVuYWJsZWQ6IGluc3BlY3RlZENlbGwgIT09IG51bGwsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwicmstcGFnZVwiPlxuICAgICAge3JlcG9ydC5zdGF0dXMgPT09ICdsb2FkaW5nJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInJrLXBhZ2Utbm90ZVwiPkxvYWRpbmcgcmVwb3J04oCmPC9kaXY+fVxuICAgICAge3JlcG9ydC5zdGF0dXMgPT09ICdlcnJvcicgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXBhZ2Utbm90ZSByay1wYWdlLWVycm9yXCI+Q291bGQgbm90IGxvYWQgdGhlIHJlcG9ydDoge3JlcG9ydC5tZXNzYWdlfTwvZGl2PlxuICAgICAgKX1cbiAgICAgIHtyZXBvcnQuc3RhdHVzID09PSAncmVhZHknICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInJrLXBhZ2UtaGVhZFwiPlxuICAgICAgICAgICAgPERvY3VtZW50TmF2IGxvYz17aG9zdExvY30gY3VycmVudD17c2VlZH0gLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJncmFkLXRleHRcIj57cmVwb3J0LnNlc3Npb24udGl0bGV9PC9oMT5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXJldmlldy10b2dnbGVcIiBvbkNsaWNrPXsoKSA9PiBzZXRSZXZpZXdPcGVuKCh2KSA9PiAhdil9PlxuICAgICAgICAgICAgICB7cmV2aWV3T3BlbiA/ICdDbG9zZSB3b3JrYm9vaycgOiAnV29ya2Jvb2snfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9oZWFkZXI+XG4gICAgICAgICAge2VkaXRGaWxlLmVkaXRlZCAmJiAoXG4gICAgICAgICAgICA8RG9jdW1lbnRDaGFuZ2VkTm90aWNlXG4gICAgICAgICAgICAgIG9uUmVsb2FkPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgcmVwb3J0LnJlbG9hZCgpO1xuICAgICAgICAgICAgICAgIGVkaXRGaWxlLmNsZWFyU3RhbGUoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7ZWRpdEZpbGUubm90aWNlICE9PSBudWxsICYmIDxkaXYgY2xhc3NOYW1lPVwicmstc3RhbGUgcmstc3RhbGUtLW5vdGVcIiByb2xlPVwic3RhdHVzXCI+e2VkaXRGaWxlLm5vdGljZX08L2Rpdj59XG4gICAgICAgICAge2F1dGhvcnNPcGVuID8gKFxuICAgICAgICAgICAgPEF1dGhvcnNWaWV3XG4gICAgICAgICAgICAgIHNlc3Npb249e3JlcG9ydC5zZXNzaW9ufVxuICAgICAgICAgICAgICBiaW5kaW5ncz17cmVwb3J0LmJpbmRpbmdzfVxuICAgICAgICAgICAgICB2ZXJkaWN0cz17dmVyZGljdHMucmVzdWx0c31cbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QXV0aG9yc09wZW4oZmFsc2UpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPFJlcG9ydFZpZXcgbm9kZXM9e3JlcG9ydC5zZXNzaW9uLm5vZGVzfSBiaW5kaW5ncz17cmVwb3J0LmJpbmRpbmdzfSBpbnNwZWN0aW9uPXtpbnNwZWN0aW9uID8/IHVuZGVmaW5lZH0gLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtyZXZpZXdPcGVuICYmIChcbiAgICAgICAgICAgIDxXb3JrYm9va1BhbmVsXG4gICAgICAgICAgICAgIHNlc3Npb249e3JlcG9ydC5zZXNzaW9ufVxuICAgICAgICAgICAgICB2ZXJkaWN0cz17dmVyZGljdHN9XG4gICAgICAgICAgICAgIG9uSW5zcGVjdD17c2V0SW5zcGVjdGVkfVxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRSZXZpZXdPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgb25PcGVuQXV0aG9ycz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFJldmlld09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgIHNldEF1dGhvcnNPcGVuKHRydWUpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBzY3JhdGNoVGV4dD17c2NyYXRjaFRleHR9XG4gICAgICAgICAgICAgIG9uU2NyYXRjaENoYW5nZT17c2V0U2NyYXRjaFRleHR9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAge2luc3BlY3RlZENlbGwgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnNwZWN0b3ItZG9ja1wiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJWYWx1ZSBpbnNwZWN0b3JcIiByZWY9e2luc3BlY3RvclJlZn0+XG4gICAgICAgICAgICAgIDxWYWx1ZUluc3BlY3RvclxuICAgICAgICAgICAgICAgIGNlbGw9e2luc3BlY3RlZENlbGx9XG4gICAgICAgICAgICAgICAgY2VsbHM9e3JlcG9ydC5zZXNzaW9uLmVuZ2luZS5jZWxscygpfVxuICAgICAgICAgICAgICAgIHRlc3RzPXtyZXBvcnQuc2Vzc2lvbi5lbmdpbmUudGVzdHMoKS5maWx0ZXIoKHQpID0+IHQuc3ViamVjdCA9PT0gaW5zcGVjdGVkQ2VsbC5pZCl9XG4gICAgICAgICAgICAgICAgdmVyZGljdHM9e3ZlcmRpY3RzLnJlc3VsdHN9XG4gICAgICAgICAgICAgICAgcmVzdWx0PXtyZXBvcnQuc2Vzc2lvbi5lbmdpbmUucmVzdWx0KGluc3BlY3RlZENlbGwuaWQpfVxuICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e3NldEluc3BlY3RlZH1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJbnNwZWN0ZWQobnVsbCl9XG4gICAgICAgICAgICAgICAgb25XaGF0SWY9eygpID0+IHNldFdoYXRJZk9wZW5Gb3IoaW5zcGVjdGVkQ2VsbC5pZCl9XG4gICAgICAgICAgICAgICAgd29ya3NoZWV0UGF0aHM9e09iamVjdC5mcm9tRW50cmllcyhyZXBvcnQuc2Vzc2lvbi5sb2FkZWQud29ya3NoZWV0cy5tYXAoKHcpID0+IFt3Lm5hbWUsIHcucGF0aF0pKX1cbiAgICAgICAgICAgICAgICBjYW5FZGl0UGF0aD17ZWRpdEZpbGUuY2FuRWRpdFBhdGh9XG4gICAgICAgICAgICAgICAgb25FZGl0PXtlZGl0RmlsZS5vbkVkaXR9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHsod2hhdElmT3BlbkZvciA9PT0gaW5zcGVjdGVkQ2VsbC5pZCB8fFxuICAgICAgICAgICAgICAgICh2YXJpYW50c1tpbnNwZWN0ZWRDZWxsLmlkXSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgICAgICB2YXJpYW50c1tpbnNwZWN0ZWRDZWxsLmlkXSAhPT0gaW5zcGVjdGVkQ2VsbC5mb3JtdWxhU291cmNlKSkgJiYgKFxuICAgICAgICAgICAgICAgIDxXaGF0SWZQYW5lbFxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbj17cmVwb3J0LnNlc3Npb259XG4gICAgICAgICAgICAgICAgICBjZWxsPXtpbnNwZWN0ZWRDZWxsfVxuICAgICAgICAgICAgICAgICAgYmFzZVZlcmRpY3RzPXt2ZXJkaWN0cy5yZXN1bHRzfVxuICAgICAgICAgICAgICAgICAgdGV4dD17dmFyaWFudHNbaW5zcGVjdGVkQ2VsbC5pZF0gPz8gaW5zcGVjdGVkQ2VsbC5mb3JtdWxhU291cmNlfVxuICAgICAgICAgICAgICAgICAgb25UZXh0Q2hhbmdlPXsoY2VsbElkLCB0ZXh0KSA9PiBzZXRWYXJpYW50cygodikgPT4gKHsgLi4udiwgW2NlbGxJZF06IHRleHQgfSkpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9tYWluPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBV0FBLE9BQUE7QUFDQUEsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE1BQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFPLHNCQUFBLEdBQUFELHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBUSxVQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxTQUFBLEdBQUFULE9BQUE7QUFDQSxJQUFBVSxZQUFBLEdBQUFWLE9BQUE7QUFDQSxJQUFBVyxPQUFBLEdBQUFYLE9BQUE7QUFDQSxJQUFBWSxjQUFBLEdBQUFOLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBYSxlQUFBLEdBQUFQLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBYyxZQUFBLEdBQUFSLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBZSxZQUFBLEdBQUFULHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBZ0IsaUJBQUEsR0FBQWhCLE9BQUE7QUFDQSxJQUFBaUIsWUFBQSxHQUFBakIsT0FBQTtBQUFxRCxJQUFBa0IsV0FBQSxHQUFBbEIsT0FBQTtBQUFBLElBQUFtQixFQUFBLEdBQUFDLFlBQUEsSUE1QnJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBZCx1QkFBQWUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQW9CQSxTQUFTRyxHQUFHQSxDQUFBLEVBQUc7RUFBQUwsRUFBQTtFQUNiO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTU0sT0FBTyxHQUFHLElBQUFDLHNCQUFVLEVBQUMsQ0FBQztFQUM1QixNQUFNQyxPQUFPLEdBQUcsSUFBQUMsMkJBQWUsRUFBQyxDQUFDO0VBQ2pDLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyxvQkFBUyxFQUFDLENBQUM7RUFDMUIsTUFBTUMsSUFBSSxHQUFHLElBQUFDLGtCQUFXLEVBQUNQLE9BQU8sRUFBRVEsTUFBTSxDQUFDQyxRQUFRLENBQUM7RUFDbEQsTUFBTUMsTUFBTSxHQUFHLElBQUFDLG9CQUFTLEVBQUNMLElBQUksRUFBRUYsTUFBTSxDQUFDO0VBQ3RDO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTVEsUUFBUSxHQUFHLElBQUFDLDhCQUFvQixFQUFDVCxNQUFNLENBQUM7RUFDN0MsTUFBTVUsUUFBUSxHQUFHLElBQUFDLHdCQUFXLEVBQUNILFFBQVEsQ0FBQ0ksRUFBRSxHQUFHSixRQUFRLENBQUNLLEtBQUssR0FBRyxJQUFJLENBQUM7RUFDakUsTUFBTSxDQUFDQyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDbkQsTUFBTSxDQUFDQyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQy9EO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0csUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQXlCLENBQUMsQ0FBQyxDQUFDO0VBQ3BFLE1BQU0sQ0FBQ0ssV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBRyxJQUFBTixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQ2xEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNPLGFBQWEsRUFBRUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFBUixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUN2RTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNTLFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQVYsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUNyRCxNQUFNVyxLQUFLLEdBQUdyQixNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxHQUFHdEIsTUFBTSxDQUFDdUIsT0FBTyxDQUFDRixLQUFLLEdBQUdHLFNBQVM7RUFDMUUsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUosS0FBSyxLQUFLRyxTQUFTLEVBQUVFLFFBQVEsQ0FBQ0wsS0FBSyxHQUFHQSxLQUFLO0VBQ2pELENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztFQUVYLE1BQU1NLGFBQWEsR0FDakIzQixNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxJQUFJWCxTQUFTLEtBQUssSUFBSSxHQUMzQ1gsTUFBTSxDQUFDdUIsT0FBTyxDQUFDSyxNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBS3JCLFNBQVMsQ0FBQyxJQUFJLElBQUksR0FDckUsSUFBSTs7RUFFVjtFQUNBO0VBQ0EsTUFBTXNCLFVBQVUsR0FBRyxJQUFBQyxjQUFPLEVBQ3hCLE1BQ0VsQyxNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxHQUNyQjtJQUNFYSxTQUFTLEVBQUV2QixZQUFZO0lBQ3ZCd0IsVUFBVSxFQUFHQyxNQUFjLElBQUtyQyxNQUFNLENBQUN1QixPQUFPLENBQUNLLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1MsSUFBSSxDQUFFUCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsRUFBRSxLQUFLSyxNQUFNO0VBQzNGLENBQUMsR0FDRCxJQUFJLEVBQ1YsQ0FBQ3JDLE1BQU0sQ0FDVCxDQUFDO0VBRUQsTUFBTXVDLFFBQVEsR0FBRyxJQUFBQyx3QkFBVyxFQUMxQnhDLE1BQU0sQ0FBQ3NCLE1BQU0sS0FBSyxPQUFPLEdBQUd0QixNQUFNLENBQUN1QixPQUFPLENBQUNLLE1BQU0sR0FBRyxJQUFJLEVBQ3hENUIsTUFBTSxDQUFDc0IsTUFBTSxLQUFLLE9BQU8sR0FBR3RCLE1BQU0sQ0FBQ3lDLElBQUksR0FBRyxDQUM1QyxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtDQUFnQixFQUFpQixNQUFNL0IsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQzlFZ0MsT0FBTyxFQUFFakIsYUFBYSxLQUFLO0VBQzdCLENBQUMsQ0FBQztFQUVGLG9CQUNFLElBQUE1QyxXQUFBLENBQUE4RCxJQUFBO0lBQU1DLFNBQVMsRUFBQyxTQUFTO0lBQUFDLFFBQUEsR0FDdEIvQyxNQUFNLENBQUNzQixNQUFNLEtBQUssU0FBUyxpQkFBSSxJQUFBdkMsV0FBQSxDQUFBaUUsR0FBQTtNQUFLRixTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLEVBQUM7SUFBZSxDQUFLLENBQUMsRUFDbEYvQyxNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxpQkFDeEIsSUFBQXZDLFdBQUEsQ0FBQThELElBQUE7TUFBS0MsU0FBUyxFQUFDLDRCQUE0QjtNQUFBQyxRQUFBLEdBQUMsNkJBQTJCLEVBQUMvQyxNQUFNLENBQUNpRCxPQUFPO0lBQUEsQ0FBTSxDQUM3RixFQUNBakQsTUFBTSxDQUFDc0IsTUFBTSxLQUFLLE9BQU8saUJBQ3hCLElBQUF2QyxXQUFBLENBQUE4RCxJQUFBLEVBQUE5RCxXQUFBLENBQUFtRSxRQUFBO01BQUFILFFBQUEsZ0JBQ0UsSUFBQWhFLFdBQUEsQ0FBQThELElBQUE7UUFBUUMsU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxnQkFDOUIsSUFBQWhFLFdBQUEsQ0FBQWlFLEdBQUEsRUFBQzlFLFlBQUEsQ0FBQWtCLE9BQVc7VUFBQytELEdBQUcsRUFBRTNELE9BQVE7VUFBQzRELE9BQU8sRUFBRXhEO1FBQUssQ0FBRSxDQUFDLGVBQzVDLElBQUFiLFdBQUEsQ0FBQWlFLEdBQUE7VUFBSUYsU0FBUyxFQUFDLFdBQVc7VUFBQUMsUUFBQSxFQUFFL0MsTUFBTSxDQUFDdUIsT0FBTyxDQUFDRjtRQUFLLENBQUssQ0FBQyxlQUNyRCxJQUFBdEMsV0FBQSxDQUFBaUUsR0FBQTtVQUFRSyxJQUFJLEVBQUMsUUFBUTtVQUFDUCxTQUFTLEVBQUMsa0JBQWtCO1VBQUNRLE9BQU8sRUFBRUEsQ0FBQSxLQUFNN0MsYUFBYSxDQUFFOEMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBRTtVQUFBUixRQUFBLEVBQ3hGdkMsVUFBVSxHQUFHLGdCQUFnQixHQUFHO1FBQVUsQ0FDckMsQ0FBQztNQUFBLENBQ0gsQ0FBQyxFQUNSSixRQUFRLENBQUNvRCxNQUFNLGlCQUNkLElBQUF6RSxXQUFBLENBQUFpRSxHQUFBLEVBQUM1RSxzQkFBQSxDQUFBZ0IsT0FBcUI7UUFDcEJxRSxRQUFRLEVBQUVBLENBQUEsS0FBTTtVQUNkekQsTUFBTSxDQUFDMEQsTUFBTSxDQUFDLENBQUM7VUFDZnRELFFBQVEsQ0FBQ3VELFVBQVUsQ0FBQyxDQUFDO1FBQ3ZCO01BQUUsQ0FDSCxDQUNGLEVBQ0F2RCxRQUFRLENBQUN3RCxNQUFNLEtBQUssSUFBSSxpQkFBSSxJQUFBN0UsV0FBQSxDQUFBaUUsR0FBQTtRQUFLRixTQUFTLEVBQUMseUJBQXlCO1FBQUNlLElBQUksRUFBQyxRQUFRO1FBQUFkLFFBQUEsRUFBRTNDLFFBQVEsQ0FBQ3dEO01BQU0sQ0FBTSxDQUFDLEVBQzFHekMsV0FBVyxnQkFDVixJQUFBcEMsV0FBQSxDQUFBaUUsR0FBQSxFQUFDcEUsWUFBQSxDQUFBUSxPQUFXO1FBQ1ZtQyxPQUFPLEVBQUV2QixNQUFNLENBQUN1QixPQUFRO1FBQ3hCdUMsUUFBUSxFQUFFOUQsTUFBTSxDQUFDOEQsUUFBUztRQUMxQnZCLFFBQVEsRUFBRUEsUUFBUSxDQUFDd0IsT0FBUTtRQUMzQkMsT0FBTyxFQUFFQSxDQUFBLEtBQU01QyxjQUFjLENBQUMsS0FBSztNQUFFLENBQ3RDLENBQUMsZ0JBRUYsSUFBQXJDLFdBQUEsQ0FBQWlFLEdBQUEsRUFBQ3hFLE9BQUEsQ0FBQXlGLFVBQVU7UUFBQ0MsS0FBSyxFQUFFbEUsTUFBTSxDQUFDdUIsT0FBTyxDQUFDMkMsS0FBTTtRQUFDSixRQUFRLEVBQUU5RCxNQUFNLENBQUM4RCxRQUFTO1FBQUM3QixVQUFVLEVBQUVBLFVBQVUsSUFBSVQ7TUFBVSxDQUFFLENBQzNHLEVBQ0FoQixVQUFVLGlCQUNULElBQUF6QixXQUFBLENBQUFpRSxHQUFBLEVBQUN2RSxjQUFBLENBQUFXLE9BQWE7UUFDWm1DLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQ3VCLE9BQVE7UUFDeEJnQixRQUFRLEVBQUVBLFFBQVM7UUFDbkJKLFNBQVMsRUFBRXZCLFlBQWE7UUFDeEJvRCxPQUFPLEVBQUVBLENBQUEsS0FBTXZELGFBQWEsQ0FBQyxLQUFLLENBQUU7UUFDcEMwRCxhQUFhLEVBQUVBLENBQUEsS0FBTTtVQUNuQjFELGFBQWEsQ0FBQyxLQUFLLENBQUM7VUFDcEJXLGNBQWMsQ0FBQyxJQUFJLENBQUM7UUFDdEIsQ0FBRTtRQUNGTCxXQUFXLEVBQUVBLFdBQVk7UUFDekJxRCxlQUFlLEVBQUVwRDtNQUFlLENBQ2pDLENBQ0YsRUFDQVcsYUFBYSxLQUFLLElBQUksaUJBQ3JCLElBQUE1QyxXQUFBLENBQUE4RCxJQUFBO1FBQUtDLFNBQVMsRUFBQyxtQkFBbUI7UUFBQ2UsSUFBSSxFQUFDLFFBQVE7UUFBQyxjQUFXLE1BQU07UUFBQyxjQUFXLGlCQUFpQjtRQUFDUSxHQUFHLEVBQUUzQixZQUFhO1FBQUFLLFFBQUEsZ0JBQ2hILElBQUFoRSxXQUFBLENBQUFpRSxHQUFBLEVBQUN0RSxlQUFBLENBQUFVLE9BQWM7VUFDYmtGLElBQUksRUFBRTNDLGFBQWM7VUFDcEJFLEtBQUssRUFBRTdCLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQ0ssTUFBTSxDQUFDQyxLQUFLLENBQUMsQ0FBRTtVQUNyQzBDLEtBQUssRUFBRXZFLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQ0ssTUFBTSxDQUFDMkMsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsT0FBTyxLQUFLL0MsYUFBYSxDQUFDSyxFQUFFLENBQUU7VUFDbkZPLFFBQVEsRUFBRUEsUUFBUSxDQUFDd0IsT0FBUTtVQUMzQlksTUFBTSxFQUFFM0UsTUFBTSxDQUFDdUIsT0FBTyxDQUFDSyxNQUFNLENBQUMrQyxNQUFNLENBQUNoRCxhQUFhLENBQUNLLEVBQUUsQ0FBRTtVQUN2RDRDLFVBQVUsRUFBRWhFLFlBQWE7VUFDekJvRCxPQUFPLEVBQUVBLENBQUEsS0FBTXBELFlBQVksQ0FBQyxJQUFJLENBQUU7VUFDbENpRSxRQUFRLEVBQUVBLENBQUEsS0FBTTNELGdCQUFnQixDQUFDUyxhQUFhLENBQUNLLEVBQUUsQ0FBRTtVQUNuRDhDLGNBQWMsRUFBRUMsTUFBTSxDQUFDQyxXQUFXLENBQUNoRixNQUFNLENBQUN1QixPQUFPLENBQUMwRCxNQUFNLENBQUNDLFVBQVUsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxJQUFJLEVBQUVELENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBRTtVQUNsR0MsV0FBVyxFQUFFbkYsUUFBUSxDQUFDbUYsV0FBWTtVQUNsQ0MsTUFBTSxFQUFFcEYsUUFBUSxDQUFDb0Y7UUFBTyxDQUN6QixDQUFDLEVBQ0QsQ0FBQ3ZFLGFBQWEsS0FBS1UsYUFBYSxDQUFDSyxFQUFFLElBQ2pDbkIsUUFBUSxDQUFDYyxhQUFhLENBQUNLLEVBQUUsQ0FBQyxLQUFLUixTQUFTLElBQ3ZDWCxRQUFRLENBQUNjLGFBQWEsQ0FBQ0ssRUFBRSxDQUFDLEtBQUtMLGFBQWEsQ0FBQzhELGFBQWMsa0JBQzdELElBQUExRyxXQUFBLENBQUFpRSxHQUFBLEVBQUNyRSxZQUFBLENBQUFTLE9BQVc7VUFDVm1DLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQ3VCLE9BQVE7VUFDeEIrQyxJQUFJLEVBQUUzQyxhQUFjO1VBQ3BCK0QsWUFBWSxFQUFFbkQsUUFBUSxDQUFDd0IsT0FBUTtVQUMvQjRCLElBQUksRUFBRTlFLFFBQVEsQ0FBQ2MsYUFBYSxDQUFDSyxFQUFFLENBQUMsSUFBSUwsYUFBYSxDQUFDOEQsYUFBYztVQUNoRUcsWUFBWSxFQUFFQSxDQUFDQyxNQUFNLEVBQUVGLElBQUksS0FBSzdFLFdBQVcsQ0FBRXlDLENBQUMsS0FBTTtZQUFFLEdBQUdBLENBQUM7WUFBRSxDQUFDc0MsTUFBTSxHQUFHRjtVQUFLLENBQUMsQ0FBQztRQUFFLENBQ2hGLENBQ0Y7TUFBQSxDQUNFLENBQ047SUFBQSxDQUNELENBQ0g7RUFBQSxDQUNHLENBQUM7QUFFWDtBQUFDM0csRUFBQSxDQXJKUUssR0FBRztFQUFBLFFBS01FLHNCQUFVLEVBQ1ZFLDJCQUFlLEVBQ2hCRSxvQkFBUyxFQUVUTSxvQkFBUyxFQU1QSSx3QkFBVyxFQXlDWG1DLHdCQUFXLEVBU1BHLGtDQUFnQjtBQUFBO0FBQUFtRCxFQUFBLEdBakU5QnpHLEdBQUc7QUFBQSxJQUFBMEcsUUFBQSxHQUFBQyxPQUFBLENBQUE1RyxPQUFBLEdBdUpHQyxHQUFHO0FBQUEsSUFBQXlHLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}