"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "REFLECTION", {
  enumerable: true,
  get: function () {
    return _catalog.REFLECTION;
  }
});
Object.defineProperty(exports, "ReportView", {
  enumerable: true,
  get: function () {
    return _index.ReportView;
  }
});
Object.defineProperty(exports, "WIDGETS", {
  enumerable: true,
  get: function () {
    return _catalog.WIDGETS;
  }
});
Object.defineProperty(exports, "catalog", {
  enumerable: true,
  get: function () {
    return _catalog.catalog;
  }
});
Object.defineProperty(exports, "component", {
  enumerable: true,
  get: function () {
    return _nodes.component;
  }
});
Object.defineProperty(exports, "componentNames", {
  enumerable: true,
  get: function () {
    return _catalog.componentNames;
  }
});
Object.defineProperty(exports, "inert", {
  enumerable: true,
  get: function () {
    return _nodes.inert;
  }
});
Object.defineProperty(exports, "lit", {
  enumerable: true,
  get: function () {
    return _nodes.lit;
  }
});
Object.defineProperty(exports, "markdown", {
  enumerable: true,
  get: function () {
    return _nodes.markdown;
  }
});
Object.defineProperty(exports, "missing", {
  enumerable: true,
  get: function () {
    return _index.missing;
  }
});
Object.defineProperty(exports, "parseTemplate", {
  enumerable: true,
  get: function () {
    return _mdx.parseTemplate;
  }
});
Object.defineProperty(exports, "validateTemplate", {
  enumerable: true,
  get: function () {
    return _validate.validateTemplate;
  }
});
var _nodes = require("./nodes.ts");
var _catalog = require("./catalog.ts");
var _validate = require("./validate.ts");
var _mdx = require("./parse/mdx.ts");
var _index = require("./render/index.ts");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZXMiLCJyZXF1aXJlIiwiX2NhdGFsb2ciLCJfdmFsaWRhdGUiLCJfbWR4IiwiX2luZGV4Il0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHJlcG9ydC12aWV3IHRlbXBsYXRlIGxheWVyIChBUkNISVRFQ1RVUkVfUExBTiDCpzMuMykg4oCUIHRoZSBjbG9zZWQgY29tcG9uZW50IGNhdGFsb2csXG4vLyB0aGUgcmVuZGVyLWFzLWRhdGEgbm9kZSBtb2RlbCwgYW5kIHRoZSB2YWxpZGF0b3IvYmluZGluZy1jb2xsZWN0b3IuIFRoaXMgaXMgdGhlIHB1cmUsXG4vLyBkYXRhLXNpZGUgY29udHJhY3QgdGhhdCBzaXRzIGFoZWFkIG9mIHRoZSBTREsgXCJyZW5kZXItYXMtZGF0YVwiIHNhZmUgcmVuZGVyZXIgKHBsYXRmb3JtXG4vLyBkZWx0YSBEMyk6IHRoZSByZW5kZXJlciBwYXJzZXMgTURYIGludG8gdGhlc2Ugbm9kZXMgYW5kIGRyYXdzIHRoZSBhdWRpdGVkIGNvbXBvbmVudHM7IHRoaXNcbi8vIHJlcG8gb3ducyB3aGljaCBjb21wb25lbnRzIGV4aXN0LCB3aGF0IGF0dHJpYnV0ZXMgdGhleSB0YWtlLCBhbmQgaG93IGEgdGVtcGxhdGUgaXMgY2hlY2tlZC5cbi8vXG4vLyBOb3QgaGVyZSAob3RoZXIgcmVhbG1zIC8gZGVmZXJyZWQpOiB0aGUgTURYIOKGkiBub2RlIHBhcnNlciAodGhlIFNESyBzYWZlIHJlbmRlcmVyLCBEMyksIHRoZVxuLy8gUmVhY3QgaW1wbGVtZW50YXRpb25zIG9mIHRoZSBjb21wb25lbnRzICh3aXRoIHRoZWlyIHJlc3BvbnNpdmUvdGhlbWVkL2FjY2Vzc2libGUgaW50ZXJuYWxzLFxuLy8gwqczLjMuMSksIGhvc3QtcmVuZGVyZWQgdGllciBiYWRnZXMgKMKnMy4zIHBvaW50IDMpLCBhbmQgZGF0YS1zaGFwZSBjb250cmFjdHMgdGhhdCBuZWVkIHRoZVxuLy8gcmVzb2x2ZWQgY2VsbCB2YWx1ZSBhdCByZW5kZXIgdGltZSAoYSBLcGkgd2FudHMgYSBzY2FsYXIsIGEgQ2hhcnQgd2FudHMgcm93cykuXG5cbmV4cG9ydCB0eXBlIHsgQXR0clZhbHVlLCBDb21wb25lbnROb2RlLCBNYXJrZG93bk5vZGUsIFRlbXBsYXRlTm9kZSB9IGZyb20gJy4vbm9kZXMudHMnO1xuZXhwb3J0IHsgY29tcG9uZW50LCBpbmVydCwgbGl0LCBtYXJrZG93biB9IGZyb20gJy4vbm9kZXMudHMnO1xuXG5leHBvcnQgeyBjYXRhbG9nLCBjb21wb25lbnROYW1lcywgV0lER0VUUywgUkVGTEVDVElPTiB9IGZyb20gJy4vY2F0YWxvZy50cyc7XG5leHBvcnQgdHlwZSB7IEF0dHJTY2hlbWEsIEF0dHJUeXBlLCBDb21wb25lbnRTY2hlbWEsIFZhcmlhbnRzIH0gZnJvbSAnLi9jYXRhbG9nLnRzJztcblxuZXhwb3J0IHsgdmFsaWRhdGVUZW1wbGF0ZSB9IGZyb20gJy4vdmFsaWRhdGUudHMnO1xuZXhwb3J0IHR5cGUgeyBUZW1wbGF0ZURpYWdub3N0aWMsIFRlbXBsYXRlVmFsaWRhdGlvbiB9IGZyb20gJy4vdmFsaWRhdGUudHMnO1xuXG4vLyBUaGUgTURYLXN1YnNldCBwYXJzZXIgKGRldiBzdGFuZC1pbiBmb3IgdGhlIHBsYXRmb3JtIEQzIHNhZmUgcmVuZGVyZXIpIHR1cm5zIGEgdGVtcGxhdGVcbi8vIGRvY3VtZW50IGludG8gdGhlIG5vZGUgbW9kZWwgYWJvdmUuXG5leHBvcnQgeyBwYXJzZVRlbXBsYXRlIH0gZnJvbSAnLi9wYXJzZS9tZHgudHMnO1xuXG4vLyBUaGUgUmVhY3QgcmVuZGVyIHN1cmZhY2UgKHNoZWxsIEEpOiBkcmF3cyBhIHBhcnNlZCB0ZW1wbGF0ZSBhZ2FpbnN0IGVuZ2luZSByZXN1bHRzIHZpYSB0aGVcbi8vIGluamVjdGVkIEJpbmRpbmdzIHBvcnQuIFNlZSAuL3JlbmRlci9pbmRleC50cyBmb3IgdGhlIGRlZmVycmVkLWVucmljaG1lbnQgbm90ZXMuXG5leHBvcnQgeyBSZXBvcnRWaWV3IH0gZnJvbSAnLi9yZW5kZXIvaW5kZXgudHMnO1xuZXhwb3J0IHR5cGUgeyBCaW5kaW5ncywgQm91bmRWYWx1ZSwgQmluZGluZ1N0YXR1cyB9IGZyb20gJy4vcmVuZGVyL2luZGV4LnRzJztcbmV4cG9ydCB0eXBlIHsgUmVmbGVjdGlvblBvcnQsIEZpeHR1cmVTdW1tYXJ5LCBGZWVkU3VtbWFyeSB9IGZyb20gJy4vcmVuZGVyL2luZGV4LnRzJztcbmV4cG9ydCB7IG1pc3NpbmcgfSBmcm9tICcuL3JlbmRlci9pbmRleC50cyc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsUUFBQSxHQUFBRCxPQUFBO0FBR0EsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBS0EsSUFBQUcsSUFBQSxHQUFBSCxPQUFBO0FBSUEsSUFBQUksTUFBQSxHQUFBSixPQUFBIiwiaWdub3JlTGlzdCI6W119