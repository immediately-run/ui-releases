var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
// The precedent-neighborhood view (review-1 UX-4) — the whole subgraph at once, spatially
// nested, alongside the inspector's hop-by-hop chips. Cell nodes navigate on click; externals
// are leaves. Truncation is stated, never silent (a capped unroll says so).

function nodeLabel(id) {
  return id.includes('.') ? id.slice(id.indexOf('.') + 1) : id;
}
function nodeNamespace(id) {
  return id.includes('.') ? id.slice(0, id.indexOf('.')) : '';
}
function Nodes({
  nodes,
  onNavigate
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
    className: "rk-prec-list",
    children: nodes.map(n => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
      className: `rk-prec-node rk-prec-node--${n.kind}`,
      children: [n.kind === 'cell' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "rk-prec-cell",
        onClick: () => onNavigate(n.id),
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-prec-via",
          children: [n.via, ":"]
        }), " ", nodeLabel(n.id), n.detail !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-prec-detail",
          children: [" (", n.detail, ")"]
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "rk-prec-leaf",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-prec-via",
          children: [n.via, ":"]
        }), " ", nodeNamespace(n.id), ".", nodeLabel(n.id), n.detail !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-prec-detail",
          children: [" \xB7 ", n.detail]
        })]
      }), n.children.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)(Nodes, {
        nodes: n.children,
        onNavigate: onNavigate
      })]
    }, `${n.via}:${n.id}`))
  });
}
_c = Nodes;
function PrecedentView({
  tree,
  onNavigate
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-prec",
    "aria-label": "Precedent neighborhood",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-prec-meta",
      children: [tree.nodeCount, " nodes \xB7 depth ", tree.depth, tree.truncated && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "rk-prec-truncated",
        children: [" \u2014 deep DAG truncated at ", tree.nodeCount, " nodes"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Nodes, {
      nodes: tree.root.children,
      onNavigate: onNavigate
    })]
  });
}
_c2 = PrecedentView;
var _default = exports.default = PrecedentView;
var _c, _c2;
$RefreshReg$(_c, "Nodes");
$RefreshReg$(_c2, "PrecedentView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJub2RlTGFiZWwiLCJpZCIsImluY2x1ZGVzIiwic2xpY2UiLCJpbmRleE9mIiwibm9kZU5hbWVzcGFjZSIsIk5vZGVzIiwibm9kZXMiLCJvbk5hdmlnYXRlIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJtYXAiLCJuIiwianN4cyIsImtpbmQiLCJ0eXBlIiwib25DbGljayIsInZpYSIsImRldGFpbCIsInVuZGVmaW5lZCIsImxlbmd0aCIsIl9jIiwiUHJlY2VkZW50VmlldyIsInRyZWUiLCJub2RlQ291bnQiLCJkZXB0aCIsInRydW5jYXRlZCIsInJvb3QiLCJfYzIiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJlY2VkZW50Vmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHByZWNlZGVudC1uZWlnaGJvcmhvb2QgdmlldyAocmV2aWV3LTEgVVgtNCkg4oCUIHRoZSB3aG9sZSBzdWJncmFwaCBhdCBvbmNlLCBzcGF0aWFsbHlcbi8vIG5lc3RlZCwgYWxvbmdzaWRlIHRoZSBpbnNwZWN0b3IncyBob3AtYnktaG9wIGNoaXBzLiBDZWxsIG5vZGVzIG5hdmlnYXRlIG9uIGNsaWNrOyBleHRlcm5hbHNcbi8vIGFyZSBsZWF2ZXMuIFRydW5jYXRpb24gaXMgc3RhdGVkLCBuZXZlciBzaWxlbnQgKGEgY2FwcGVkIHVucm9sbCBzYXlzIHNvKS5cbmltcG9ydCB0eXBlIHsgUHJlY2VkZW50Tm9kZSB9IGZyb20gJy4uL2VuZ2luZS9wcmVjZWRlbnRzLnRzJztcbmltcG9ydCB0eXBlIHsgUHJlY2VkZW50VHJlZSB9IGZyb20gJy4uL2VuZ2luZS9wcmVjZWRlbnRzLnRzJztcbmltcG9ydCAnLi93b3JrYm9vay1wYW5lbC5jc3MnO1xuXG5pbnRlcmZhY2UgUHJlY2VkZW50Vmlld1Byb3BzIHtcbiAgdHJlZTogUHJlY2VkZW50VHJlZTtcbiAgb25OYXZpZ2F0ZTogKGNlbGxJZDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBub2RlTGFiZWwoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5pbmNsdWRlcygnLicpID8gaWQuc2xpY2UoaWQuaW5kZXhPZignLicpICsgMSkgOiBpZDtcbn1cblxuZnVuY3Rpb24gbm9kZU5hbWVzcGFjZShpZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGlkLmluY2x1ZGVzKCcuJykgPyBpZC5zbGljZSgwLCBpZC5pbmRleE9mKCcuJykpIDogJyc7XG59XG5cbmZ1bmN0aW9uIE5vZGVzKHsgbm9kZXMsIG9uTmF2aWdhdGUgfTogeyBub2RlczogcmVhZG9ubHkgUHJlY2VkZW50Tm9kZVtdOyBvbk5hdmlnYXRlOiAoaWQ6IHN0cmluZykgPT4gdm9pZCB9KSB7XG4gIHJldHVybiAoXG4gICAgPHVsIGNsYXNzTmFtZT1cInJrLXByZWMtbGlzdFwiPlxuICAgICAge25vZGVzLm1hcCgobikgPT4gKFxuICAgICAgICA8bGkga2V5PXtgJHtuLnZpYX06JHtuLmlkfWB9IGNsYXNzTmFtZT17YHJrLXByZWMtbm9kZSByay1wcmVjLW5vZGUtLSR7bi5raW5kfWB9PlxuICAgICAgICAgIHtuLmtpbmQgPT09ICdjZWxsJyA/IChcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXByZWMtY2VsbFwiIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUobi5pZCl9PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1wcmVjLXZpYVwiPntuLnZpYX06PC9zcGFuPiB7bm9kZUxhYmVsKG4uaWQpfVxuICAgICAgICAgICAgICB7bi5kZXRhaWwgIT09IHVuZGVmaW5lZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJyay1wcmVjLWRldGFpbFwiPiAoe24uZGV0YWlsfSk8L3NwYW4+fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXByZWMtbGVhZlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1wcmVjLXZpYVwiPntuLnZpYX06PC9zcGFuPiB7bm9kZU5hbWVzcGFjZShuLmlkKX0ue25vZGVMYWJlbChuLmlkKX1cbiAgICAgICAgICAgICAge24uZGV0YWlsICE9PSB1bmRlZmluZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwicmstcHJlYy1kZXRhaWxcIj4gwrcge24uZGV0YWlsfTwvc3Bhbj59XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7bi5jaGlsZHJlbi5sZW5ndGggPiAwICYmIDxOb2RlcyBub2Rlcz17bi5jaGlsZHJlbn0gb25OYXZpZ2F0ZT17b25OYXZpZ2F0ZX0gLz59XG4gICAgICAgIDwvbGk+XG4gICAgICApKX1cbiAgICA8L3VsPlxuICApO1xufVxuXG5mdW5jdGlvbiBQcmVjZWRlbnRWaWV3KHsgdHJlZSwgb25OYXZpZ2F0ZSB9OiBQcmVjZWRlbnRWaWV3UHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXByZWNcIiBhcmlhLWxhYmVsPVwiUHJlY2VkZW50IG5laWdoYm9yaG9vZFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1wcmVjLW1ldGFcIj5cbiAgICAgICAge3RyZWUubm9kZUNvdW50fSBub2RlcyDCtyBkZXB0aCB7dHJlZS5kZXB0aH1cbiAgICAgICAge3RyZWUudHJ1bmNhdGVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLXByZWMtdHJ1bmNhdGVkXCI+IOKAlCBkZWVwIERBRyB0cnVuY2F0ZWQgYXQge3RyZWUubm9kZUNvdW50fSBub2Rlczwvc3Bhbj59XG4gICAgICA8L2Rpdj5cbiAgICAgIDxOb2RlcyBub2Rlcz17dHJlZS5yb290LmNoaWxkcmVufSBvbk5hdmlnYXRlPXtvbk5hdmlnYXRlfSAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBQcmVjZWRlbnRWaWV3O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUtBQSxPQUFBO0FBQThCLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUw5QjtBQUNBO0FBQ0E7O0FBVUEsU0FBU0UsU0FBU0EsQ0FBQ0MsRUFBVSxFQUFVO0VBQ3JDLE9BQU9BLEVBQUUsQ0FBQ0MsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHRCxFQUFFLENBQUNFLEtBQUssQ0FBQ0YsRUFBRSxDQUFDRyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUdILEVBQUU7QUFDOUQ7QUFFQSxTQUFTSSxhQUFhQSxDQUFDSixFQUFVLEVBQVU7RUFDekMsT0FBT0EsRUFBRSxDQUFDQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUdELEVBQUUsQ0FBQ0UsS0FBSyxDQUFDLENBQUMsRUFBRUYsRUFBRSxDQUFDRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFO0FBQzdEO0FBRUEsU0FBU0UsS0FBS0EsQ0FBQztFQUFFQyxLQUFLO0VBQUVDO0FBQWtGLENBQUMsRUFBRTtFQUMzRyxvQkFDRSxJQUFBVCxXQUFBLENBQUFVLEdBQUE7SUFBSUMsU0FBUyxFQUFDLGNBQWM7SUFBQUMsUUFBQSxFQUN6QkosS0FBSyxDQUFDSyxHQUFHLENBQUVDLENBQUMsaUJBQ1gsSUFBQWQsV0FBQSxDQUFBZSxJQUFBO01BQTZCSixTQUFTLEVBQUUsOEJBQThCRyxDQUFDLENBQUNFLElBQUksRUFBRztNQUFBSixRQUFBLEdBQzVFRSxDQUFDLENBQUNFLElBQUksS0FBSyxNQUFNLGdCQUNoQixJQUFBaEIsV0FBQSxDQUFBZSxJQUFBO1FBQVFFLElBQUksRUFBQyxRQUFRO1FBQUNOLFNBQVMsRUFBQyxjQUFjO1FBQUNPLE9BQU8sRUFBRUEsQ0FBQSxLQUFNVCxVQUFVLENBQUNLLENBQUMsQ0FBQ1osRUFBRSxDQUFFO1FBQUFVLFFBQUEsZ0JBQzdFLElBQUFaLFdBQUEsQ0FBQWUsSUFBQTtVQUFNSixTQUFTLEVBQUMsYUFBYTtVQUFBQyxRQUFBLEdBQUVFLENBQUMsQ0FBQ0ssR0FBRyxFQUFDLEdBQUM7UUFBQSxDQUFNLENBQUMsS0FBQyxFQUFDbEIsU0FBUyxDQUFDYSxDQUFDLENBQUNaLEVBQUUsQ0FBQyxFQUM3RFksQ0FBQyxDQUFDTSxNQUFNLEtBQUtDLFNBQVMsaUJBQUksSUFBQXJCLFdBQUEsQ0FBQWUsSUFBQTtVQUFNSixTQUFTLEVBQUMsZ0JBQWdCO1VBQUFDLFFBQUEsR0FBQyxJQUFFLEVBQUNFLENBQUMsQ0FBQ00sTUFBTSxFQUFDLEdBQUM7UUFBQSxDQUFNLENBQUM7TUFBQSxDQUMxRSxDQUFDLGdCQUVULElBQUFwQixXQUFBLENBQUFlLElBQUE7UUFBTUosU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxnQkFDNUIsSUFBQVosV0FBQSxDQUFBZSxJQUFBO1VBQU1KLFNBQVMsRUFBQyxhQUFhO1VBQUFDLFFBQUEsR0FBRUUsQ0FBQyxDQUFDSyxHQUFHLEVBQUMsR0FBQztRQUFBLENBQU0sQ0FBQyxLQUFDLEVBQUNiLGFBQWEsQ0FBQ1EsQ0FBQyxDQUFDWixFQUFFLENBQUMsRUFBQyxHQUFDLEVBQUNELFNBQVMsQ0FBQ2EsQ0FBQyxDQUFDWixFQUFFLENBQUMsRUFDbkZZLENBQUMsQ0FBQ00sTUFBTSxLQUFLQyxTQUFTLGlCQUFJLElBQUFyQixXQUFBLENBQUFlLElBQUE7VUFBTUosU0FBUyxFQUFDLGdCQUFnQjtVQUFBQyxRQUFBLEdBQUMsUUFBRyxFQUFDRSxDQUFDLENBQUNNLE1BQU07UUFBQSxDQUFPLENBQUM7TUFBQSxDQUM1RSxDQUNQLEVBQ0FOLENBQUMsQ0FBQ0YsUUFBUSxDQUFDVSxNQUFNLEdBQUcsQ0FBQyxpQkFBSSxJQUFBdEIsV0FBQSxDQUFBVSxHQUFBLEVBQUNILEtBQUs7UUFBQ0MsS0FBSyxFQUFFTSxDQUFDLENBQUNGLFFBQVM7UUFBQ0gsVUFBVSxFQUFFQTtNQUFXLENBQUUsQ0FBQztJQUFBLEdBWnZFLEdBQUdLLENBQUMsQ0FBQ0ssR0FBRyxJQUFJTCxDQUFDLENBQUNaLEVBQUUsRUFhckIsQ0FDTDtFQUFDLENBQ0EsQ0FBQztBQUVUO0FBQUNxQixFQUFBLEdBckJRaEIsS0FBSztBQXVCZCxTQUFTaUIsYUFBYUEsQ0FBQztFQUFFQyxJQUFJO0VBQUVoQjtBQUErQixDQUFDLEVBQUU7RUFDL0Qsb0JBQ0UsSUFBQVQsV0FBQSxDQUFBZSxJQUFBO0lBQUtKLFNBQVMsRUFBQyxTQUFTO0lBQUMsY0FBVyx3QkFBd0I7SUFBQUMsUUFBQSxnQkFDMUQsSUFBQVosV0FBQSxDQUFBZSxJQUFBO01BQUtKLFNBQVMsRUFBQyxjQUFjO01BQUFDLFFBQUEsR0FDMUJhLElBQUksQ0FBQ0MsU0FBUyxFQUFDLG9CQUFlLEVBQUNELElBQUksQ0FBQ0UsS0FBSyxFQUN6Q0YsSUFBSSxDQUFDRyxTQUFTLGlCQUFJLElBQUE1QixXQUFBLENBQUFlLElBQUE7UUFBTUosU0FBUyxFQUFDLG1CQUFtQjtRQUFBQyxRQUFBLEdBQUMsZ0NBQXlCLEVBQUNhLElBQUksQ0FBQ0MsU0FBUyxFQUFDLFFBQU07TUFBQSxDQUFNLENBQUM7SUFBQSxDQUMxRyxDQUFDLGVBQ04sSUFBQTFCLFdBQUEsQ0FBQVUsR0FBQSxFQUFDSCxLQUFLO01BQUNDLEtBQUssRUFBRWlCLElBQUksQ0FBQ0ksSUFBSSxDQUFDakIsUUFBUztNQUFDSCxVQUFVLEVBQUVBO0lBQVcsQ0FBRSxDQUFDO0VBQUEsQ0FDekQsQ0FBQztBQUVWO0FBQUNxQixHQUFBLEdBVlFOLGFBQWE7QUFBQSxJQUFBTyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQVlQVCxhQUFhO0FBQUEsSUFBQUQsRUFBQSxFQUFBTyxHQUFBO0FBQUFJLFlBQUEsQ0FBQVgsRUFBQTtBQUFBVyxZQUFBLENBQUFKLEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}