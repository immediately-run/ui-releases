"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _promises = require("node:fs/promises");
var _nodePath = require("node:path");
var _nodeUrl = require("node:url");
var _loader = require("./loader.ts");
var _memoryReader = require("../app/memoryReader.ts");
var _asyncEngine = require("../engine/asyncEngine.ts");
var _workerTransport = require("../engine/workerTransport.ts");
var _mdx = require("../report/parse/mdx.ts");
var _validate = require("../report/validate.ts");
var _reportSession = require("../app/reportSession.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // The Caldera LBO case study (docs/case-study/caldera) — the financial-domain
// sibling of the Meridian study. This harness is the *proof* half of the study:
// it loads the document from disk through the real `loadDocument` loader, runs
// it through the real SES-compartment engine (in-process transport, same worker
// body), asserts the port against the Python-generated truth (expected.json —
// an independent implementation of the model), and runs the workbook's own test
// cells through `runTests`, asserting verdicts.
const HERE = (0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url));
const CASE = (0, _nodePath.join)(HERE, '..', '..', 'docs', 'case-study', 'caldera');
async function caseReader(root) {
  const files = {};
  async function walk(dir, prefix = '') {
    const {
      readdir
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('node:fs/promises')));
    for (const entry of await readdir(dir, {
      withFileTypes: true
    })) {
      const rel = prefix === '' ? entry.name : `${prefix}/${entry.name}`;
      if (entry.isDirectory()) await walk((0, _nodePath.join)(dir, entry.name), rel);else files[(0, _nodePath.join)(root, rel)] = await (0, _promises.readFile)((0, _nodePath.join)(dir, entry.name), 'utf8');
    }
  }
  await walk((0, _nodePath.join)(CASE, 'document'));
  return (0, _memoryReader.memoryReader)(files);
}
async function loadCase() {
  const loaded = await (0, _loader.loadDocument)(await caseReader('caldera'), 'caldera');
  const expected = JSON.parse(await (0, _promises.readFile)((0, _nodePath.join)(CASE, 'expected.json'), 'utf8'));
  return {
    loaded,
    expected
  };
}
function externalsFor(loaded) {
  const externals = {};
  for (const fx of loaded.fixtures) {
    externals[`fixtures.${fx.name}`] = {
      value: fx.frame.rows,
      tier: 'static'
    };
  }
  for (const [name, value] of Object.entries(loaded.manifest.params)) {
    externals[`params.${name}`] = {
      value,
      tier: 'static'
    };
  }
  return externals;
}
(0, _vitest.describe)('Caldera LBO case study', () => {
  (0, _vitest.it)('loads the document with no error diagnostics', async () => {
    const {
      loaded
    } = await loadCase();
    (0, _vitest.expect)(loaded.worksheets.map(w => w.name)).toEqual(['model', 'checks']);
    (0, _vitest.expect)(loaded.fixtures.map(f => f.name).sort()).toEqual(['assumptions', 'expected_holdout', 'expected_values', 'historical_segments', 'ops_plan', 'ops_plan_holdout', 'year_plan']);
    (0, _vitest.expect)(loaded.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
  });
  (0, _vitest.it)('computes the model against the Python truth', async () => {
    const {
      loaded,
      expected
    } = await loadCase();
    const engine = await _asyncEngine.AsyncEngine.fromSources(Object.fromEntries(loaded.worksheets.map(w => [w.name, w.source])), {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    const pass = await engine.run(externalsFor(loaded));
    (0, _vitest.expect)([...pass.errors.entries()]).toEqual([]);
    const su = expected.sources_uses;
    const exit = expected.exit;
    const sched = expected.schedule;
    const ops = expected.operating;
    (0, _vitest.expect)(engine.value('model.ltm_ebitda')).toBeCloseTo(expected.ltm_ebitda, 8);
    const suv = engine.value('model.sources_uses');
    (0, _vitest.expect)(suv.entry_ev).toBeCloseTo(su.entry_ev, 6);
    (0, _vitest.expect)(suv.sponsor_equity).toBeCloseTo(su.sponsor_equity, 6);
    (0, _vitest.expect)(suv.uses).toBeCloseTo(su.uses, 6);
    (0, _vitest.expect)(suv.sources - suv.uses).toBeCloseTo(0, 9);
    const opv = engine.value('model.operating');
    (0, _vitest.expect)(opv.length).toBe(5);
    for (let i = 0; i < 5; i += 1) {
      (0, _vitest.expect)(opv[i].revenue).toBeCloseTo(ops[i].revenue, 6);
      (0, _vitest.expect)(opv[i].ebitda).toBeCloseTo(ops[i].ebitda, 6);
      (0, _vitest.expect)(opv[i].delta_nwc).toBeCloseTo(ops[i].delta_nwc, 6);
    }
    const schedv = engine.value('model.debt_schedule');
    for (let i = 0; i < 5; i += 1) {
      (0, _vitest.expect)(schedv[i].tlb_end).toBeCloseTo(sched[i].tlb_end, 6);
      (0, _vitest.expect)(schedv[i].mezz_end).toBeCloseTo(sched[i].mezz_end, 6);
      (0, _vitest.expect)(schedv[i].cash_end).toBeCloseTo(sched[i].cash_end, 6);
      (0, _vitest.expect)(schedv[i].leverage).toBeCloseTo(sched[i].leverage, 9);
      (0, _vitest.expect)(schedv[i].coverage).toBeCloseTo(sched[i].coverage, 9);
    }
    const retv = engine.value('model.returns');
    (0, _vitest.expect)(retv.exit_equity).toBeCloseTo(exit.exit_equity, 6);
    (0, _vitest.expect)(retv.irr).toBeCloseTo(exit.irr, 10);
    (0, _vitest.expect)(retv.moic).toBeCloseTo(exit.moic, 9);
    const avg = engine.value('model.returns_avg');
    (0, _vitest.expect)(avg.irr).toBeCloseTo(expected.exit_avg.irr, 10);
    (0, _vitest.expect)(engine.value('model.breakeven_exit_multiple')).toBeCloseTo(expected.breakeven_exit_multiple, 8);
    const grid = engine.value('model.sensitivity');
    const truth = expected.sensitivity_grid;
    (0, _vitest.expect)(grid.length).toBe(25);
    for (let i = 0; i < 25; i += 1) {
      (0, _vitest.expect)(grid[i].irr).toBeCloseTo(truth[i].irr, 10);
      (0, _vitest.expect)(grid[i].sponsor_equity).toBeCloseTo(truth[i].sponsor_equity, 6);
    }
    // the grid's center must reproduce the interactive base case exactly
    const center = grid.find(r => r.exit_multiple === 8.0 && r.tlb_turns === 5.0);
    (0, _vitest.expect)(center?.irr).toBe(retv.irr);

    // R3-376 parity: the stdlib irr matches the hand-rolled bisection it replaced,
    // over all 25 grid flows, to 1e-15 (the refactor-safety-net receipt).
    for (const g of truth) {
      const flows = [-g.sponsor_equity, 0, 0, 0, 0, g.exit_equity];
      const npvAt = r => flows.reduce((acc, cf, t) => acc + cf / (1 + r) ** t, 0);
      let lo = -0.99;
      let hi = 10;
      for (let i = 0; i < 200; i += 1) {
        const mid = (lo + hi) / 2;
        if (npvAt(mid) > 0) lo = mid;else hi = mid;
      }
      const {
        irr
      } = await Promise.resolve().then(() => _interopRequireWildcard(require('../stdlib/financial.ts')));
      (0, _vitest.expect)(Math.abs(irr(flows) - (lo + hi) / 2)).toBeLessThanOrEqual(1e-15);
    }
  });
  (0, _vitest.it)('every workbook test cell passes and the key cells are validated, not merely pinned', async () => {
    const {
      loaded
    } = await loadCase();
    const engine = await _asyncEngine.AsyncEngine.fromSources(Object.fromEntries(loaded.worksheets.map(w => [w.name, w.source])), {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run(externalsFor(loaded));
    const results = await engine.runTests();
    (0, _vitest.expect)(results.size).toBeGreaterThan(0);
    const failing = [];
    for (const [subject, r] of results) {
      for (const o of r.outcomes) {
        if (!o.pass) failing.push(`${subject} / ${o.id}: ${o.message}`);
      }
    }
    (0, _vitest.expect)(failing).toEqual([]);

    // R3-373's exit gates, exercised through the real engine: the holdout test
    // substitutes the downside plan fixture and passes against its own oracle…
    const holdout = results.get('model.operating')?.outcomes.find(o => o.id === 'checks.ops_holdout');
    (0, _vitest.expect)(holdout?.pass).toBe(true);
    // …and an oracle test that used to inline constants now reads its fixture.
    const suOracle = results.get('model.sources_uses')?.outcomes.find(o => o.id === 'checks.su_vs_oracle');
    (0, _vitest.expect)(suOracle?.pass).toBe(true);

    // the review-surface verdict taxonomy in action: the load-bearing cells
    // carry a metamorphic/property leg, so they read "validated"
    for (const subject of ['model.ltm_ebitda', 'model.sources_uses', 'model.sources_uses_row', 'model.operating', 'model.debt_schedule', 'model.debt_schedule_avg', 'model.returns', 'model.returns_avg', 'model.sensitivity', 'model.breakeven_exit_multiple']) {
      (0, _vitest.expect)(results.get(subject)?.verdict, `verdict for ${subject}`).toBe('validated');
    }
  });
  (0, _vitest.it)('the template parses and validates against the component catalog', async () => {
    const {
      loaded
    } = await loadCase();
    const template = loaded.templates.find(t => t.name === 'deal_summary');
    (0, _vitest.expect)(template).toBeDefined();
    const nodes = (0, _mdx.parseTemplate)(template.source);
    const validation = (0, _validate.validateTemplate)(nodes);
    (0, _vitest.expect)(validation.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
    (0, _vitest.expect)(validation.placeholders).toEqual([]);
  });

  // R3-377: assumptions-as-params. A paramRefs knob shadows its leaf inside the injected
  // fixture value — flipping params.tax_rate 0.25 → 0.30 must reproduce the Python truth
  // for the 30% variant exactly, leave every other fixture untouched, and keep the
  // cells that do not depend on the assumptions fixture at their published values.
  (0, _vitest.it)('a live tax-rate flip (paramRefs) reproduces the Python 30% variant', async () => {
    const {
      loaded,
      expected
    } = await loadCase();
    const engine = await _asyncEngine.AsyncEngine.fromSources(Object.fromEntries(loaded.worksheets.map(w => [w.name, w.source])), {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    const {
      externals,
      paramRefs
    } = (0, _reportSession.assembleExternals)(loaded);
    await engine.run(externals);
    (0, _vitest.expect)(paramRefs.tax_rate).toEqual({
      from: 'fixtures.assumptions',
      path: '0.tax_rate'
    });
    (0, _vitest.expect)(externals['params.tax_rate']?.value).toBe(0.25);
    const baseIrr = engine.value('model.returns').irr;
    const baseLtm = engine.value('model.ltm_ebitda');

    // the flip, through the same sessionBindings path the app's params surface uses
    let rerendered = false;
    const bindings = (0, _reportSession.sessionBindings)({
      engine,
      externals,
      paramRefs,
      nodes: [],
      title: 't',
      diagnostics: [],
      sources: {},
      loaded,
      runtimeFeeds: [],
      authorsNodes: [],
      authorsFromDocument: false
    }, () => {
      rerendered = true;
    });
    const originalAssumptions = externals['fixtures.assumptions'].value;
    bindings.setParam('tax_rate', 0.30);
    while (!rerendered) await new Promise(r => setTimeout(r, 0));
    const variant = expected.tax30_variant;
    const sched = engine.value('model.debt_schedule');
    (0, _vitest.expect)(sched.length).toBe(5);
    for (let i = 0; i < 5; i += 1) {
      (0, _vitest.expect)(sched[i].tlb_end).toBeCloseTo(variant.schedule[i].tlb_end, 6);
      (0, _vitest.expect)(sched[i].cash_end).toBeCloseTo(variant.schedule[i].cash_end, 6);
    }
    const flippedIrr = engine.value('model.returns').irr;
    (0, _vitest.expect)(flippedIrr).toBeCloseTo(variant.irr, 10);
    (0, _vitest.expect)(flippedIrr).toBeLessThan(baseIrr); // more tax, less sweep, worse returns

    // structural sharing: the fixture value the document shipped is untouched, and the
    // cells that never declared the assumptions fixture are unchanged
    (0, _vitest.expect)(originalAssumptions[0].tax_rate).toBe(0.25);
    (0, _vitest.expect)(externals['fixtures.assumptions'].value[0].tax_rate).toBe(0.30);
    (0, _vitest.expect)(engine.value('model.ltm_ebitda')).toBe(baseLtm);
    (0, _vitest.expect)(externals['params.tax_rate']?.value).toBe(0.30);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9wcm9taXNlcyIsIl9ub2RlUGF0aCIsIl9ub2RlVXJsIiwiX2xvYWRlciIsIl9tZW1vcnlSZWFkZXIiLCJfYXN5bmNFbmdpbmUiLCJfd29ya2VyVHJhbnNwb3J0IiwiX21keCIsIl92YWxpZGF0ZSIsIl9yZXBvcnRTZXNzaW9uIiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJIRVJFIiwiZGlybmFtZSIsImZpbGVVUkxUb1BhdGgiLCIkaXJfaW1wb3J0X21ldGEiLCJ1cmwiLCJDQVNFIiwiam9pbiIsImNhc2VSZWFkZXIiLCJyb290IiwiZmlsZXMiLCJ3YWxrIiwiZGlyIiwicHJlZml4IiwicmVhZGRpciIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsImVudHJ5Iiwid2l0aEZpbGVUeXBlcyIsInJlbCIsIm5hbWUiLCJpc0RpcmVjdG9yeSIsInJlYWRGaWxlIiwibWVtb3J5UmVhZGVyIiwibG9hZENhc2UiLCJsb2FkZWQiLCJsb2FkRG9jdW1lbnQiLCJleHBlY3RlZCIsIkpTT04iLCJwYXJzZSIsImV4dGVybmFsc0ZvciIsImV4dGVybmFscyIsImZ4IiwiZml4dHVyZXMiLCJ2YWx1ZSIsImZyYW1lIiwicm93cyIsInRpZXIiLCJlbnRyaWVzIiwibWFuaWZlc3QiLCJwYXJhbXMiLCJkZXNjcmliZSIsIml0IiwiZXhwZWN0Iiwid29ya3NoZWV0cyIsIm1hcCIsInciLCJ0b0VxdWFsIiwiZiIsInNvcnQiLCJkaWFnbm9zdGljcyIsImZpbHRlciIsImQiLCJzZXZlcml0eSIsImVuZ2luZSIsIkFzeW5jRW5naW5lIiwiZnJvbVNvdXJjZXMiLCJmcm9tRW50cmllcyIsInNvdXJjZSIsInRyYW5zcG9ydCIsImluTWVtb3J5VHJhbnNwb3J0IiwicGFzcyIsInJ1biIsImVycm9ycyIsInN1Iiwic291cmNlc191c2VzIiwiZXhpdCIsInNjaGVkIiwic2NoZWR1bGUiLCJvcHMiLCJvcGVyYXRpbmciLCJ0b0JlQ2xvc2VUbyIsImx0bV9lYml0ZGEiLCJzdXYiLCJlbnRyeV9ldiIsInNwb25zb3JfZXF1aXR5IiwidXNlcyIsInNvdXJjZXMiLCJvcHYiLCJsZW5ndGgiLCJ0b0JlIiwicmV2ZW51ZSIsImViaXRkYSIsImRlbHRhX253YyIsInNjaGVkdiIsInRsYl9lbmQiLCJtZXp6X2VuZCIsImNhc2hfZW5kIiwibGV2ZXJhZ2UiLCJjb3ZlcmFnZSIsInJldHYiLCJleGl0X2VxdWl0eSIsImlyciIsIm1vaWMiLCJhdmciLCJleGl0X2F2ZyIsImJyZWFrZXZlbl9leGl0X211bHRpcGxlIiwiZ3JpZCIsInRydXRoIiwic2Vuc2l0aXZpdHlfZ3JpZCIsImNlbnRlciIsImZpbmQiLCJleGl0X211bHRpcGxlIiwidGxiX3R1cm5zIiwiZyIsImZsb3dzIiwibnB2QXQiLCJyZWR1Y2UiLCJhY2MiLCJjZiIsImxvIiwiaGkiLCJtaWQiLCJNYXRoIiwiYWJzIiwidG9CZUxlc3NUaGFuT3JFcXVhbCIsInJlc3VsdHMiLCJydW5UZXN0cyIsInNpemUiLCJ0b0JlR3JlYXRlclRoYW4iLCJmYWlsaW5nIiwic3ViamVjdCIsIm8iLCJvdXRjb21lcyIsInB1c2giLCJpZCIsIm1lc3NhZ2UiLCJob2xkb3V0Iiwic3VPcmFjbGUiLCJ2ZXJkaWN0IiwidGVtcGxhdGUiLCJ0ZW1wbGF0ZXMiLCJ0b0JlRGVmaW5lZCIsIm5vZGVzIiwicGFyc2VUZW1wbGF0ZSIsInZhbGlkYXRpb24iLCJ2YWxpZGF0ZVRlbXBsYXRlIiwicGxhY2Vob2xkZXJzIiwicGFyYW1SZWZzIiwiYXNzZW1ibGVFeHRlcm5hbHMiLCJ0YXhfcmF0ZSIsImZyb20iLCJwYXRoIiwiYmFzZUlyciIsImJhc2VMdG0iLCJyZXJlbmRlcmVkIiwiYmluZGluZ3MiLCJzZXNzaW9uQmluZGluZ3MiLCJ0aXRsZSIsInJ1bnRpbWVGZWVkcyIsImF1dGhvcnNOb2RlcyIsImF1dGhvcnNGcm9tRG9jdW1lbnQiLCJvcmlnaW5hbEFzc3VtcHRpb25zIiwic2V0UGFyYW0iLCJzZXRUaW1lb3V0IiwidmFyaWFudCIsInRheDMwX3ZhcmlhbnQiLCJmbGlwcGVkSXJyIiwidG9CZUxlc3NUaGFuIl0sInNvdXJjZXMiOlsiY2FsZGVyYUNhc2VTdHVkeS50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBDYWxkZXJhIExCTyBjYXNlIHN0dWR5IChkb2NzL2Nhc2Utc3R1ZHkvY2FsZGVyYSkg4oCUIHRoZSBmaW5hbmNpYWwtZG9tYWluXG4vLyBzaWJsaW5nIG9mIHRoZSBNZXJpZGlhbiBzdHVkeS4gVGhpcyBoYXJuZXNzIGlzIHRoZSAqcHJvb2YqIGhhbGYgb2YgdGhlIHN0dWR5OlxuLy8gaXQgbG9hZHMgdGhlIGRvY3VtZW50IGZyb20gZGlzayB0aHJvdWdoIHRoZSByZWFsIGBsb2FkRG9jdW1lbnRgIGxvYWRlciwgcnVuc1xuLy8gaXQgdGhyb3VnaCB0aGUgcmVhbCBTRVMtY29tcGFydG1lbnQgZW5naW5lIChpbi1wcm9jZXNzIHRyYW5zcG9ydCwgc2FtZSB3b3JrZXJcbi8vIGJvZHkpLCBhc3NlcnRzIHRoZSBwb3J0IGFnYWluc3QgdGhlIFB5dGhvbi1nZW5lcmF0ZWQgdHJ1dGggKGV4cGVjdGVkLmpzb24g4oCUXG4vLyBhbiBpbmRlcGVuZGVudCBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgbW9kZWwpLCBhbmQgcnVucyB0aGUgd29ya2Jvb2sncyBvd24gdGVzdFxuLy8gY2VsbHMgdGhyb3VnaCBgcnVuVGVzdHNgLCBhc3NlcnRpbmcgdmVyZGljdHMuXG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyByZWFkRmlsZSB9IGZyb20gJ25vZGU6ZnMvcHJvbWlzZXMnO1xuaW1wb3J0IHsgam9pbiwgZGlybmFtZSB9IGZyb20gJ25vZGU6cGF0aCc7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSAnbm9kZTp1cmwnO1xuaW1wb3J0IHsgbG9hZERvY3VtZW50IH0gZnJvbSAnLi9sb2FkZXIudHMnO1xuaW1wb3J0IHsgbWVtb3J5UmVhZGVyIH0gZnJvbSAnLi4vYXBwL21lbW9yeVJlYWRlci50cyc7XG5pbXBvcnQgeyBBc3luY0VuZ2luZSB9IGZyb20gJy4uL2VuZ2luZS9hc3luY0VuZ2luZS50cyc7XG5pbXBvcnQgeyBpbk1lbW9yeVRyYW5zcG9ydCB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXJUcmFuc3BvcnQudHMnO1xuaW1wb3J0IHR5cGUgeyBFeHRlcm5hbFZhbHVlIH0gZnJvbSAnLi4vZW5naW5lL3R5cGVzLnRzJztcbmltcG9ydCB0eXBlIHsgTG9hZGVkRG9jdW1lbnQgfSBmcm9tICcuL3R5cGVzLnRzJztcbmltcG9ydCB7IHBhcnNlVGVtcGxhdGUgfSBmcm9tICcuLi9yZXBvcnQvcGFyc2UvbWR4LnRzJztcbmltcG9ydCB7IHZhbGlkYXRlVGVtcGxhdGUgfSBmcm9tICcuLi9yZXBvcnQvdmFsaWRhdGUudHMnO1xuaW1wb3J0IHsgYXNzZW1ibGVFeHRlcm5hbHMgfSBmcm9tICcuLi9hcHAvcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgeyBzZXNzaW9uQmluZGluZ3MgfSBmcm9tICcuLi9hcHAvcmVwb3J0U2Vzc2lvbi50cyc7XG5cbmNvbnN0IEhFUkUgPSBkaXJuYW1lKGZpbGVVUkxUb1BhdGgoaW1wb3J0Lm1ldGEudXJsKSk7XG5jb25zdCBDQVNFID0gam9pbihIRVJFLCAnLi4nLCAnLi4nLCAnZG9jcycsICdjYXNlLXN0dWR5JywgJ2NhbGRlcmEnKTtcblxuYXN5bmMgZnVuY3Rpb24gY2FzZVJlYWRlcihyb290OiBzdHJpbmcpIHtcbiAgY29uc3QgZmlsZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcbiAgYXN5bmMgZnVuY3Rpb24gd2FsayhkaXI6IHN0cmluZywgcHJlZml4ID0gJycpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB7IHJlYWRkaXIgfSA9IGF3YWl0IGltcG9ydCgnbm9kZTpmcy9wcm9taXNlcycpO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgYXdhaXQgcmVhZGRpcihkaXIsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KSkge1xuICAgICAgY29uc3QgcmVsID0gcHJlZml4ID09PSAnJyA/IGVudHJ5Lm5hbWUgOiBgJHtwcmVmaXh9LyR7ZW50cnkubmFtZX1gO1xuICAgICAgaWYgKGVudHJ5LmlzRGlyZWN0b3J5KCkpIGF3YWl0IHdhbGsoam9pbihkaXIsIGVudHJ5Lm5hbWUpLCByZWwpO1xuICAgICAgZWxzZSBmaWxlc1tqb2luKHJvb3QsIHJlbCldID0gYXdhaXQgcmVhZEZpbGUoam9pbihkaXIsIGVudHJ5Lm5hbWUpLCAndXRmOCcpO1xuICAgIH1cbiAgfVxuICBhd2FpdCB3YWxrKGpvaW4oQ0FTRSwgJ2RvY3VtZW50JykpO1xuICByZXR1cm4gbWVtb3J5UmVhZGVyKGZpbGVzKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZENhc2UoKTogUHJvbWlzZTx7IGxvYWRlZDogTG9hZGVkRG9jdW1lbnQ7IGV4cGVjdGVkOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB9PiB7XG4gIGNvbnN0IGxvYWRlZCA9IGF3YWl0IGxvYWREb2N1bWVudChhd2FpdCBjYXNlUmVhZGVyKCdjYWxkZXJhJyksICdjYWxkZXJhJyk7XG4gIGNvbnN0IGV4cGVjdGVkID0gSlNPTi5wYXJzZShhd2FpdCByZWFkRmlsZShqb2luKENBU0UsICdleHBlY3RlZC5qc29uJyksICd1dGY4JykpO1xuICByZXR1cm4geyBsb2FkZWQsIGV4cGVjdGVkIH07XG59XG5cbmZ1bmN0aW9uIGV4dGVybmFsc0Zvcihsb2FkZWQ6IExvYWRlZERvY3VtZW50KTogUmVjb3JkPHN0cmluZywgRXh0ZXJuYWxWYWx1ZT4ge1xuICBjb25zdCBleHRlcm5hbHM6IFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+ID0ge307XG4gIGZvciAoY29uc3QgZnggb2YgbG9hZGVkLmZpeHR1cmVzKSB7XG4gICAgZXh0ZXJuYWxzW2BmaXh0dXJlcy4ke2Z4Lm5hbWV9YF0gPSB7IHZhbHVlOiBmeC5mcmFtZS5yb3dzLCB0aWVyOiAnc3RhdGljJyB9O1xuICB9XG4gIGZvciAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhsb2FkZWQubWFuaWZlc3QucGFyYW1zKSkge1xuICAgIGV4dGVybmFsc1tgcGFyYW1zLiR7bmFtZX1gXSA9IHsgdmFsdWUsIHRpZXI6ICdzdGF0aWMnIH07XG4gIH1cbiAgcmV0dXJuIGV4dGVybmFscztcbn1cblxuZGVzY3JpYmUoJ0NhbGRlcmEgTEJPIGNhc2Ugc3R1ZHknLCAoKSA9PiB7XG4gIGl0KCdsb2FkcyB0aGUgZG9jdW1lbnQgd2l0aCBubyBlcnJvciBkaWFnbm9zdGljcycsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGxvYWRlZCB9ID0gYXdhaXQgbG9hZENhc2UoKTtcbiAgICBleHBlY3QobG9hZGVkLndvcmtzaGVldHMubWFwKCh3KSA9PiB3Lm5hbWUpKS50b0VxdWFsKFsnbW9kZWwnLCAnY2hlY2tzJ10pO1xuICAgIGV4cGVjdChsb2FkZWQuZml4dHVyZXMubWFwKChmKSA9PiBmLm5hbWUpLnNvcnQoKSkudG9FcXVhbChbXG4gICAgICAnYXNzdW1wdGlvbnMnLCAnZXhwZWN0ZWRfaG9sZG91dCcsICdleHBlY3RlZF92YWx1ZXMnLCAnaGlzdG9yaWNhbF9zZWdtZW50cycsXG4gICAgICAnb3BzX3BsYW4nLCAnb3BzX3BsYW5faG9sZG91dCcsICd5ZWFyX3BsYW4nLFxuICAgIF0pO1xuICAgIGV4cGVjdChsb2FkZWQuZGlhZ25vc3RpY3MuZmlsdGVyKChkKSA9PiBkLnNldmVyaXR5ID09PSAnZXJyb3InKSkudG9FcXVhbChbXSk7XG4gIH0pO1xuXG4gIGl0KCdjb21wdXRlcyB0aGUgbW9kZWwgYWdhaW5zdCB0aGUgUHl0aG9uIHRydXRoJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgbG9hZGVkLCBleHBlY3RlZCB9ID0gYXdhaXQgbG9hZENhc2UoKTtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhcbiAgICAgIE9iamVjdC5mcm9tRW50cmllcyhsb2FkZWQud29ya3NoZWV0cy5tYXAoKHcpID0+IFt3Lm5hbWUsIHcuc291cmNlXSkpLFxuICAgICAgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSxcbiAgICApO1xuICAgIGNvbnN0IHBhc3MgPSBhd2FpdCBlbmdpbmUucnVuKGV4dGVybmFsc0Zvcihsb2FkZWQpKTtcbiAgICBleHBlY3QoWy4uLnBhc3MuZXJyb3JzLmVudHJpZXMoKV0pLnRvRXF1YWwoW10pO1xuXG4gICAgY29uc3Qgc3UgPSBleHBlY3RlZC5zb3VyY2VzX3VzZXMgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgICBjb25zdCBleGl0ID0gZXhwZWN0ZWQuZXhpdCBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xuICAgIGNvbnN0IHNjaGVkID0gZXhwZWN0ZWQuc2NoZWR1bGUgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPltdO1xuICAgIGNvbnN0IG9wcyA9IGV4cGVjdGVkLm9wZXJhdGluZyBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+W107XG5cbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdtb2RlbC5sdG1fZWJpdGRhJykpLnRvQmVDbG9zZVRvKGV4cGVjdGVkLmx0bV9lYml0ZGEgYXMgbnVtYmVyLCA4KTtcblxuICAgIGNvbnN0IHN1diA9IGVuZ2luZS52YWx1ZSgnbW9kZWwuc291cmNlc191c2VzJykgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgICBleHBlY3Qoc3V2LmVudHJ5X2V2KS50b0JlQ2xvc2VUbyhzdS5lbnRyeV9ldiwgNik7XG4gICAgZXhwZWN0KHN1di5zcG9uc29yX2VxdWl0eSkudG9CZUNsb3NlVG8oc3Uuc3BvbnNvcl9lcXVpdHksIDYpO1xuICAgIGV4cGVjdChzdXYudXNlcykudG9CZUNsb3NlVG8oc3UudXNlcywgNik7XG4gICAgZXhwZWN0KHN1di5zb3VyY2VzIC0gc3V2LnVzZXMpLnRvQmVDbG9zZVRvKDAsIDkpO1xuXG4gICAgY29uc3Qgb3B2ID0gZW5naW5lLnZhbHVlKCdtb2RlbC5vcGVyYXRpbmcnKSBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+W107XG4gICAgZXhwZWN0KG9wdi5sZW5ndGgpLnRvQmUoNSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA1OyBpICs9IDEpIHtcbiAgICAgIGV4cGVjdChvcHZbaV0ucmV2ZW51ZSkudG9CZUNsb3NlVG8ob3BzW2ldLnJldmVudWUsIDYpO1xuICAgICAgZXhwZWN0KG9wdltpXS5lYml0ZGEpLnRvQmVDbG9zZVRvKG9wc1tpXS5lYml0ZGEsIDYpO1xuICAgICAgZXhwZWN0KG9wdltpXS5kZWx0YV9ud2MpLnRvQmVDbG9zZVRvKG9wc1tpXS5kZWx0YV9ud2MsIDYpO1xuICAgIH1cblxuICAgIGNvbnN0IHNjaGVkdiA9IGVuZ2luZS52YWx1ZSgnbW9kZWwuZGVidF9zY2hlZHVsZScpIGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj5bXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDU7IGkgKz0gMSkge1xuICAgICAgZXhwZWN0KHNjaGVkdltpXS50bGJfZW5kKS50b0JlQ2xvc2VUbyhzY2hlZFtpXS50bGJfZW5kLCA2KTtcbiAgICAgIGV4cGVjdChzY2hlZHZbaV0ubWV6el9lbmQpLnRvQmVDbG9zZVRvKHNjaGVkW2ldLm1lenpfZW5kLCA2KTtcbiAgICAgIGV4cGVjdChzY2hlZHZbaV0uY2FzaF9lbmQpLnRvQmVDbG9zZVRvKHNjaGVkW2ldLmNhc2hfZW5kLCA2KTtcbiAgICAgIGV4cGVjdChzY2hlZHZbaV0ubGV2ZXJhZ2UpLnRvQmVDbG9zZVRvKHNjaGVkW2ldLmxldmVyYWdlLCA5KTtcbiAgICAgIGV4cGVjdChzY2hlZHZbaV0uY292ZXJhZ2UpLnRvQmVDbG9zZVRvKHNjaGVkW2ldLmNvdmVyYWdlLCA5KTtcbiAgICB9XG5cbiAgICBjb25zdCByZXR2ID0gZW5naW5lLnZhbHVlKCdtb2RlbC5yZXR1cm5zJykgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgICBleHBlY3QocmV0di5leGl0X2VxdWl0eSkudG9CZUNsb3NlVG8oZXhpdC5leGl0X2VxdWl0eSwgNik7XG4gICAgZXhwZWN0KHJldHYuaXJyKS50b0JlQ2xvc2VUbyhleGl0LmlyciwgMTApO1xuICAgIGV4cGVjdChyZXR2Lm1vaWMpLnRvQmVDbG9zZVRvKGV4aXQubW9pYywgOSk7XG5cbiAgICBjb25zdCBhdmcgPSBlbmdpbmUudmFsdWUoJ21vZGVsLnJldHVybnNfYXZnJykgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgICBleHBlY3QoYXZnLmlycikudG9CZUNsb3NlVG8oKGV4cGVjdGVkLmV4aXRfYXZnIGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj4pLmlyciwgMTApO1xuXG4gICAgZXhwZWN0KGVuZ2luZS52YWx1ZSgnbW9kZWwuYnJlYWtldmVuX2V4aXRfbXVsdGlwbGUnKSkudG9CZUNsb3NlVG8oXG4gICAgICBleHBlY3RlZC5icmVha2V2ZW5fZXhpdF9tdWx0aXBsZSBhcyBudW1iZXIsIDgsXG4gICAgKTtcblxuICAgIGNvbnN0IGdyaWQgPSBlbmdpbmUudmFsdWUoJ21vZGVsLnNlbnNpdGl2aXR5JykgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPltdO1xuICAgIGNvbnN0IHRydXRoID0gZXhwZWN0ZWQuc2Vuc2l0aXZpdHlfZ3JpZCBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+W107XG4gICAgZXhwZWN0KGdyaWQubGVuZ3RoKS50b0JlKDI1KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDI1OyBpICs9IDEpIHtcbiAgICAgIGV4cGVjdChncmlkW2ldLmlycikudG9CZUNsb3NlVG8odHJ1dGhbaV0uaXJyLCAxMCk7XG4gICAgICBleHBlY3QoZ3JpZFtpXS5zcG9uc29yX2VxdWl0eSkudG9CZUNsb3NlVG8odHJ1dGhbaV0uc3BvbnNvcl9lcXVpdHksIDYpO1xuICAgIH1cbiAgICAvLyB0aGUgZ3JpZCdzIGNlbnRlciBtdXN0IHJlcHJvZHVjZSB0aGUgaW50ZXJhY3RpdmUgYmFzZSBjYXNlIGV4YWN0bHlcbiAgICBjb25zdCBjZW50ZXIgPSBncmlkLmZpbmQoKHIpID0+IHIuZXhpdF9tdWx0aXBsZSA9PT0gOC4wICYmIHIudGxiX3R1cm5zID09PSA1LjApO1xuICAgIGV4cGVjdChjZW50ZXI/LmlycikudG9CZShyZXR2Lmlycik7XG5cbiAgICAvLyBSMy0zNzYgcGFyaXR5OiB0aGUgc3RkbGliIGlyciBtYXRjaGVzIHRoZSBoYW5kLXJvbGxlZCBiaXNlY3Rpb24gaXQgcmVwbGFjZWQsXG4gICAgLy8gb3ZlciBhbGwgMjUgZ3JpZCBmbG93cywgdG8gMWUtMTUgKHRoZSByZWZhY3Rvci1zYWZldHktbmV0IHJlY2VpcHQpLlxuICAgIGZvciAoY29uc3QgZyBvZiB0cnV0aCkge1xuICAgICAgY29uc3QgZmxvd3MgPSBbLWcuc3BvbnNvcl9lcXVpdHksIDAsIDAsIDAsIDAsIGcuZXhpdF9lcXVpdHldO1xuICAgICAgY29uc3QgbnB2QXQgPSAocjogbnVtYmVyKTogbnVtYmVyID0+IGZsb3dzLnJlZHVjZSgoYWNjLCBjZiwgdCkgPT4gYWNjICsgY2YgLyAoMSArIHIpICoqIHQsIDApO1xuICAgICAgbGV0IGxvID0gLTAuOTk7XG4gICAgICBsZXQgaGkgPSAxMDtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMjAwOyBpICs9IDEpIHtcbiAgICAgICAgY29uc3QgbWlkID0gKGxvICsgaGkpIC8gMjtcbiAgICAgICAgaWYgKG5wdkF0KG1pZCkgPiAwKSBsbyA9IG1pZDtcbiAgICAgICAgZWxzZSBoaSA9IG1pZDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgaXJyIH0gPSBhd2FpdCBpbXBvcnQoJy4uL3N0ZGxpYi9maW5hbmNpYWwudHMnKTtcbiAgICAgIGV4cGVjdChNYXRoLmFicyhpcnIoZmxvd3MpIC0gKGxvICsgaGkpIC8gMikpLnRvQmVMZXNzVGhhbk9yRXF1YWwoMWUtMTUpO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoJ2V2ZXJ5IHdvcmtib29rIHRlc3QgY2VsbCBwYXNzZXMgYW5kIHRoZSBrZXkgY2VsbHMgYXJlIHZhbGlkYXRlZCwgbm90IG1lcmVseSBwaW5uZWQnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyBsb2FkZWQgfSA9IGF3YWl0IGxvYWRDYXNlKCk7XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoXG4gICAgICBPYmplY3QuZnJvbUVudHJpZXMobG9hZGVkLndvcmtzaGVldHMubWFwKCh3KSA9PiBbdy5uYW1lLCB3LnNvdXJjZV0pKSxcbiAgICAgIHsgdHJhbnNwb3J0OiBpbk1lbW9yeVRyYW5zcG9ydCgpIH0sXG4gICAgKTtcbiAgICBhd2FpdCBlbmdpbmUucnVuKGV4dGVybmFsc0Zvcihsb2FkZWQpKTtcbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgZW5naW5lLnJ1blRlc3RzKCk7XG5cbiAgICBleHBlY3QocmVzdWx0cy5zaXplKS50b0JlR3JlYXRlclRoYW4oMCk7XG4gICAgY29uc3QgZmFpbGluZzogc3RyaW5nW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IFtzdWJqZWN0LCByXSBvZiByZXN1bHRzKSB7XG4gICAgICBmb3IgKGNvbnN0IG8gb2Ygci5vdXRjb21lcykge1xuICAgICAgICBpZiAoIW8ucGFzcykgZmFpbGluZy5wdXNoKGAke3N1YmplY3R9IC8gJHtvLmlkfTogJHtvLm1lc3NhZ2V9YCk7XG4gICAgICB9XG4gICAgfVxuICAgIGV4cGVjdChmYWlsaW5nKS50b0VxdWFsKFtdKTtcblxuICAgIC8vIFIzLTM3MydzIGV4aXQgZ2F0ZXMsIGV4ZXJjaXNlZCB0aHJvdWdoIHRoZSByZWFsIGVuZ2luZTogdGhlIGhvbGRvdXQgdGVzdFxuICAgIC8vIHN1YnN0aXR1dGVzIHRoZSBkb3duc2lkZSBwbGFuIGZpeHR1cmUgYW5kIHBhc3NlcyBhZ2FpbnN0IGl0cyBvd24gb3JhY2xl4oCmXG4gICAgY29uc3QgaG9sZG91dCA9IHJlc3VsdHMuZ2V0KCdtb2RlbC5vcGVyYXRpbmcnKT8ub3V0Y29tZXMuZmluZCgobykgPT4gby5pZCA9PT0gJ2NoZWNrcy5vcHNfaG9sZG91dCcpO1xuICAgIGV4cGVjdChob2xkb3V0Py5wYXNzKS50b0JlKHRydWUpO1xuICAgIC8vIOKApmFuZCBhbiBvcmFjbGUgdGVzdCB0aGF0IHVzZWQgdG8gaW5saW5lIGNvbnN0YW50cyBub3cgcmVhZHMgaXRzIGZpeHR1cmUuXG4gICAgY29uc3Qgc3VPcmFjbGUgPSByZXN1bHRzLmdldCgnbW9kZWwuc291cmNlc191c2VzJyk/Lm91dGNvbWVzLmZpbmQoKG8pID0+IG8uaWQgPT09ICdjaGVja3Muc3VfdnNfb3JhY2xlJyk7XG4gICAgZXhwZWN0KHN1T3JhY2xlPy5wYXNzKS50b0JlKHRydWUpO1xuXG4gICAgLy8gdGhlIHJldmlldy1zdXJmYWNlIHZlcmRpY3QgdGF4b25vbXkgaW4gYWN0aW9uOiB0aGUgbG9hZC1iZWFyaW5nIGNlbGxzXG4gICAgLy8gY2FycnkgYSBtZXRhbW9ycGhpYy9wcm9wZXJ0eSBsZWcsIHNvIHRoZXkgcmVhZCBcInZhbGlkYXRlZFwiXG4gICAgZm9yIChjb25zdCBzdWJqZWN0IG9mIFtcbiAgICAgICdtb2RlbC5sdG1fZWJpdGRhJywgJ21vZGVsLnNvdXJjZXNfdXNlcycsICdtb2RlbC5zb3VyY2VzX3VzZXNfcm93JywgJ21vZGVsLm9wZXJhdGluZycsXG4gICAgICAnbW9kZWwuZGVidF9zY2hlZHVsZScsICdtb2RlbC5kZWJ0X3NjaGVkdWxlX2F2ZycsICdtb2RlbC5yZXR1cm5zJywgJ21vZGVsLnJldHVybnNfYXZnJyxcbiAgICAgICdtb2RlbC5zZW5zaXRpdml0eScsICdtb2RlbC5icmVha2V2ZW5fZXhpdF9tdWx0aXBsZScsXG4gICAgXSkge1xuICAgICAgZXhwZWN0KHJlc3VsdHMuZ2V0KHN1YmplY3QpPy52ZXJkaWN0LCBgdmVyZGljdCBmb3IgJHtzdWJqZWN0fWApLnRvQmUoJ3ZhbGlkYXRlZCcpO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoJ3RoZSB0ZW1wbGF0ZSBwYXJzZXMgYW5kIHZhbGlkYXRlcyBhZ2FpbnN0IHRoZSBjb21wb25lbnQgY2F0YWxvZycsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGxvYWRlZCB9ID0gYXdhaXQgbG9hZENhc2UoKTtcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGxvYWRlZC50ZW1wbGF0ZXMuZmluZCgodCkgPT4gdC5uYW1lID09PSAnZGVhbF9zdW1tYXJ5Jyk7XG4gICAgZXhwZWN0KHRlbXBsYXRlKS50b0JlRGVmaW5lZCgpO1xuICAgIGNvbnN0IG5vZGVzID0gcGFyc2VUZW1wbGF0ZSh0ZW1wbGF0ZSEuc291cmNlKTtcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gdmFsaWRhdGVUZW1wbGF0ZShub2Rlcyk7XG4gICAgZXhwZWN0KHZhbGlkYXRpb24uZGlhZ25vc3RpY3MuZmlsdGVyKChkKSA9PiBkLnNldmVyaXR5ID09PSAnZXJyb3InKSkudG9FcXVhbChbXSk7XG4gICAgZXhwZWN0KHZhbGlkYXRpb24ucGxhY2Vob2xkZXJzKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgLy8gUjMtMzc3OiBhc3N1bXB0aW9ucy1hcy1wYXJhbXMuIEEgcGFyYW1SZWZzIGtub2Igc2hhZG93cyBpdHMgbGVhZiBpbnNpZGUgdGhlIGluamVjdGVkXG4gIC8vIGZpeHR1cmUgdmFsdWUg4oCUIGZsaXBwaW5nIHBhcmFtcy50YXhfcmF0ZSAwLjI1IOKGkiAwLjMwIG11c3QgcmVwcm9kdWNlIHRoZSBQeXRob24gdHJ1dGhcbiAgLy8gZm9yIHRoZSAzMCUgdmFyaWFudCBleGFjdGx5LCBsZWF2ZSBldmVyeSBvdGhlciBmaXh0dXJlIHVudG91Y2hlZCwgYW5kIGtlZXAgdGhlXG4gIC8vIGNlbGxzIHRoYXQgZG8gbm90IGRlcGVuZCBvbiB0aGUgYXNzdW1wdGlvbnMgZml4dHVyZSBhdCB0aGVpciBwdWJsaXNoZWQgdmFsdWVzLlxuICBpdCgnYSBsaXZlIHRheC1yYXRlIGZsaXAgKHBhcmFtUmVmcykgcmVwcm9kdWNlcyB0aGUgUHl0aG9uIDMwJSB2YXJpYW50JywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgbG9hZGVkLCBleHBlY3RlZCB9ID0gYXdhaXQgbG9hZENhc2UoKTtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhcbiAgICAgIE9iamVjdC5mcm9tRW50cmllcyhsb2FkZWQud29ya3NoZWV0cy5tYXAoKHcpID0+IFt3Lm5hbWUsIHcuc291cmNlXSkpLFxuICAgICAgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSxcbiAgICApO1xuICAgIGNvbnN0IHsgZXh0ZXJuYWxzLCBwYXJhbVJlZnMgfSA9IGFzc2VtYmxlRXh0ZXJuYWxzKGxvYWRlZCk7XG4gICAgYXdhaXQgZW5naW5lLnJ1bihleHRlcm5hbHMpO1xuXG4gICAgZXhwZWN0KHBhcmFtUmVmcy50YXhfcmF0ZSkudG9FcXVhbCh7IGZyb206ICdmaXh0dXJlcy5hc3N1bXB0aW9ucycsIHBhdGg6ICcwLnRheF9yYXRlJyB9KTtcbiAgICBleHBlY3QoZXh0ZXJuYWxzWydwYXJhbXMudGF4X3JhdGUnXT8udmFsdWUpLnRvQmUoMC4yNSk7XG4gICAgY29uc3QgYmFzZUlyciA9IChlbmdpbmUudmFsdWUoJ21vZGVsLnJldHVybnMnKSBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+KS5pcnI7XG4gICAgY29uc3QgYmFzZUx0bSA9IGVuZ2luZS52YWx1ZSgnbW9kZWwubHRtX2ViaXRkYScpO1xuXG4gICAgLy8gdGhlIGZsaXAsIHRocm91Z2ggdGhlIHNhbWUgc2Vzc2lvbkJpbmRpbmdzIHBhdGggdGhlIGFwcCdzIHBhcmFtcyBzdXJmYWNlIHVzZXNcbiAgICBsZXQgcmVyZW5kZXJlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGJpbmRpbmdzID0gc2Vzc2lvbkJpbmRpbmdzKFxuICAgICAgeyBlbmdpbmUsIGV4dGVybmFscywgcGFyYW1SZWZzLCBub2RlczogW10sIHRpdGxlOiAndCcsIGRpYWdub3N0aWNzOiBbXSwgc291cmNlczoge30sIGxvYWRlZCwgcnVudGltZUZlZWRzOiBbXSwgYXV0aG9yc05vZGVzOiBbXSwgYXV0aG9yc0Zyb21Eb2N1bWVudDogZmFsc2UgfSxcbiAgICAgICgpID0+IHsgcmVyZW5kZXJlZCA9IHRydWU7IH0sXG4gICAgKTtcbiAgICBjb25zdCBvcmlnaW5hbEFzc3VtcHRpb25zID0gZXh0ZXJuYWxzWydmaXh0dXJlcy5hc3N1bXB0aW9ucyddIS52YWx1ZTtcbiAgICBiaW5kaW5ncy5zZXRQYXJhbSgndGF4X3JhdGUnLCAwLjMwKTtcbiAgICB3aGlsZSAoIXJlcmVuZGVyZWQpIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDApKTtcblxuICAgIGNvbnN0IHZhcmlhbnQgPSBleHBlY3RlZC50YXgzMF92YXJpYW50IGFzIHsgc2NoZWR1bGU6IFJlY29yZDxzdHJpbmcsIG51bWJlcj5bXTsgaXJyOiBudW1iZXIgfTtcbiAgICBjb25zdCBzY2hlZCA9IGVuZ2luZS52YWx1ZSgnbW9kZWwuZGVidF9zY2hlZHVsZScpIGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj5bXTtcbiAgICBleHBlY3Qoc2NoZWQubGVuZ3RoKS50b0JlKDUpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNTsgaSArPSAxKSB7XG4gICAgICBleHBlY3Qoc2NoZWRbaV0udGxiX2VuZCkudG9CZUNsb3NlVG8odmFyaWFudC5zY2hlZHVsZVtpXS50bGJfZW5kLCA2KTtcbiAgICAgIGV4cGVjdChzY2hlZFtpXS5jYXNoX2VuZCkudG9CZUNsb3NlVG8odmFyaWFudC5zY2hlZHVsZVtpXS5jYXNoX2VuZCwgNik7XG4gICAgfVxuICAgIGNvbnN0IGZsaXBwZWRJcnIgPSAoZW5naW5lLnZhbHVlKCdtb2RlbC5yZXR1cm5zJykgYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPikuaXJyO1xuICAgIGV4cGVjdChmbGlwcGVkSXJyKS50b0JlQ2xvc2VUbyh2YXJpYW50LmlyciwgMTApO1xuICAgIGV4cGVjdChmbGlwcGVkSXJyKS50b0JlTGVzc1RoYW4oYmFzZUlycik7IC8vIG1vcmUgdGF4LCBsZXNzIHN3ZWVwLCB3b3JzZSByZXR1cm5zXG5cbiAgICAvLyBzdHJ1Y3R1cmFsIHNoYXJpbmc6IHRoZSBmaXh0dXJlIHZhbHVlIHRoZSBkb2N1bWVudCBzaGlwcGVkIGlzIHVudG91Y2hlZCwgYW5kIHRoZVxuICAgIC8vIGNlbGxzIHRoYXQgbmV2ZXIgZGVjbGFyZWQgdGhlIGFzc3VtcHRpb25zIGZpeHR1cmUgYXJlIHVuY2hhbmdlZFxuICAgIGV4cGVjdCgob3JpZ2luYWxBc3N1bXB0aW9ucyBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+W10pWzBdLnRheF9yYXRlKS50b0JlKDAuMjUpO1xuICAgIGV4cGVjdCgoZXh0ZXJuYWxzWydmaXh0dXJlcy5hc3N1bXB0aW9ucyddIS52YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+W10pWzBdLnRheF9yYXRlKS50b0JlKDAuMzApO1xuICAgIGV4cGVjdChlbmdpbmUudmFsdWUoJ21vZGVsLmx0bV9lYml0ZGEnKSkudG9CZShiYXNlTHRtKTtcbiAgICBleHBlY3QoZXh0ZXJuYWxzWydwYXJhbXMudGF4X3JhdGUnXT8udmFsdWUpLnRvQmUoMC4zMCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLE9BQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLGFBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLFlBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLGdCQUFBLEdBQUFQLE9BQUE7QUFHQSxJQUFBUSxJQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxTQUFBLEdBQUFULE9BQUE7QUFDQSxJQUFBVSxjQUFBLEdBQUFWLE9BQUE7QUFBNEQsU0FBQVcseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQSxJQW5CNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFnQkEsTUFBTVcsSUFBSSxHQUFHLElBQUFDLGlCQUFPLEVBQUMsSUFBQUMsc0JBQWEsRUFBQ0MsZUFBQSxDQUFZQyxHQUFHLENBQUMsQ0FBQztBQUNwRCxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsY0FBSSxFQUFDTixJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUVwRSxlQUFlTyxVQUFVQSxDQUFDQyxJQUFZLEVBQUU7RUFDdEMsTUFBTUMsS0FBNkIsR0FBRyxDQUFDLENBQUM7RUFDeEMsZUFBZUMsSUFBSUEsQ0FBQ0MsR0FBVyxFQUFFQyxNQUFNLEdBQUcsRUFBRSxFQUFpQjtJQUMzRCxNQUFNO01BQUVDO0lBQVEsQ0FBQyxHQUFHLE1BQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUFoQyx1QkFBQSxDQUFBaEIsT0FBQSxDQUFhLGtCQUFrQixHQUFDO0lBQ3BELEtBQUssTUFBTWlELEtBQUssSUFBSSxNQUFNSixPQUFPLENBQUNGLEdBQUcsRUFBRTtNQUFFTyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUMsRUFBRTtNQUMvRCxNQUFNQyxHQUFHLEdBQUdQLE1BQU0sS0FBSyxFQUFFLEdBQUdLLEtBQUssQ0FBQ0csSUFBSSxHQUFHLEdBQUdSLE1BQU0sSUFBSUssS0FBSyxDQUFDRyxJQUFJLEVBQUU7TUFDbEUsSUFBSUgsS0FBSyxDQUFDSSxXQUFXLENBQUMsQ0FBQyxFQUFFLE1BQU1YLElBQUksQ0FBQyxJQUFBSixjQUFJLEVBQUNLLEdBQUcsRUFBRU0sS0FBSyxDQUFDRyxJQUFJLENBQUMsRUFBRUQsR0FBRyxDQUFDLENBQUMsS0FDM0RWLEtBQUssQ0FBQyxJQUFBSCxjQUFJLEVBQUNFLElBQUksRUFBRVcsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLElBQUFHLGtCQUFRLEVBQUMsSUFBQWhCLGNBQUksRUFBQ0ssR0FBRyxFQUFFTSxLQUFLLENBQUNHLElBQUksQ0FBQyxFQUFFLE1BQU0sQ0FBQztJQUM3RTtFQUNGO0VBQ0EsTUFBTVYsSUFBSSxDQUFDLElBQUFKLGNBQUksRUFBQ0QsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0VBQ2xDLE9BQU8sSUFBQWtCLDBCQUFZLEVBQUNkLEtBQUssQ0FBQztBQUM1QjtBQUVBLGVBQWVlLFFBQVFBLENBQUEsRUFBMkU7RUFDaEcsTUFBTUMsTUFBTSxHQUFHLE1BQU0sSUFBQUMsb0JBQVksRUFBQyxNQUFNbkIsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQztFQUN6RSxNQUFNb0IsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQyxNQUFNLElBQUFQLGtCQUFRLEVBQUMsSUFBQWhCLGNBQUksRUFBQ0QsSUFBSSxFQUFFLGVBQWUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0VBQ2hGLE9BQU87SUFBRW9CLE1BQU07SUFBRUU7RUFBUyxDQUFDO0FBQzdCO0FBRUEsU0FBU0csWUFBWUEsQ0FBQ0wsTUFBc0IsRUFBaUM7RUFDM0UsTUFBTU0sU0FBd0MsR0FBRyxDQUFDLENBQUM7RUFDbkQsS0FBSyxNQUFNQyxFQUFFLElBQUlQLE1BQU0sQ0FBQ1EsUUFBUSxFQUFFO0lBQ2hDRixTQUFTLENBQUMsWUFBWUMsRUFBRSxDQUFDWixJQUFJLEVBQUUsQ0FBQyxHQUFHO01BQUVjLEtBQUssRUFBRUYsRUFBRSxDQUFDRyxLQUFLLENBQUNDLElBQUk7TUFBRUMsSUFBSSxFQUFFO0lBQVMsQ0FBQztFQUM3RTtFQUNBLEtBQUssTUFBTSxDQUFDakIsSUFBSSxFQUFFYyxLQUFLLENBQUMsSUFBSTFDLE1BQU0sQ0FBQzhDLE9BQU8sQ0FBQ2IsTUFBTSxDQUFDYyxRQUFRLENBQUNDLE1BQU0sQ0FBQyxFQUFFO0lBQ2xFVCxTQUFTLENBQUMsVUFBVVgsSUFBSSxFQUFFLENBQUMsR0FBRztNQUFFYyxLQUFLO01BQUVHLElBQUksRUFBRTtJQUFTLENBQUM7RUFDekQ7RUFDQSxPQUFPTixTQUFTO0FBQ2xCO0FBRUEsSUFBQVUsZ0JBQVEsRUFBQyx3QkFBd0IsRUFBRSxNQUFNO0VBQ3ZDLElBQUFDLFVBQUUsRUFBQyw4Q0FBOEMsRUFBRSxZQUFZO0lBQzdELE1BQU07TUFBRWpCO0lBQU8sQ0FBQyxHQUFHLE1BQU1ELFFBQVEsQ0FBQyxDQUFDO0lBQ25DLElBQUFtQixjQUFNLEVBQUNsQixNQUFNLENBQUNtQixVQUFVLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUMxQixJQUFJLENBQUMsQ0FBQyxDQUFDMkIsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3pFLElBQUFKLGNBQU0sRUFBQ2xCLE1BQU0sQ0FBQ1EsUUFBUSxDQUFDWSxHQUFHLENBQUVHLENBQUMsSUFBS0EsQ0FBQyxDQUFDNUIsSUFBSSxDQUFDLENBQUM2QixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNGLE9BQU8sQ0FBQyxDQUN4RCxhQUFhLEVBQUUsa0JBQWtCLEVBQUUsaUJBQWlCLEVBQUUscUJBQXFCLEVBQzNFLFVBQVUsRUFBRSxrQkFBa0IsRUFBRSxXQUFXLENBQzVDLENBQUM7SUFDRixJQUFBSixjQUFNLEVBQUNsQixNQUFNLENBQUN5QixXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDTixPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzlFLENBQUMsQ0FBQztFQUVGLElBQUFMLFVBQUUsRUFBQyw2Q0FBNkMsRUFBRSxZQUFZO0lBQzVELE1BQU07TUFBRWpCLE1BQU07TUFBRUU7SUFBUyxDQUFDLEdBQUcsTUFBTUgsUUFBUSxDQUFDLENBQUM7SUFDN0MsTUFBTThCLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQzFDaEUsTUFBTSxDQUFDaUUsV0FBVyxDQUFDaEMsTUFBTSxDQUFDbUIsVUFBVSxDQUFDQyxHQUFHLENBQUVDLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUMxQixJQUFJLEVBQUUwQixDQUFDLENBQUNZLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDcEU7TUFBRUMsU0FBUyxFQUFFLElBQUFDLGtDQUFpQixFQUFDO0lBQUUsQ0FDbkMsQ0FBQztJQUNELE1BQU1DLElBQUksR0FBRyxNQUFNUCxNQUFNLENBQUNRLEdBQUcsQ0FBQ2hDLFlBQVksQ0FBQ0wsTUFBTSxDQUFDLENBQUM7SUFDbkQsSUFBQWtCLGNBQU0sRUFBQyxDQUFDLEdBQUdrQixJQUFJLENBQUNFLE1BQU0sQ0FBQ3pCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDUyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBRTlDLE1BQU1pQixFQUFFLEdBQUdyQyxRQUFRLENBQUNzQyxZQUFzQztJQUMxRCxNQUFNQyxJQUFJLEdBQUd2QyxRQUFRLENBQUN1QyxJQUE4QjtJQUNwRCxNQUFNQyxLQUFLLEdBQUd4QyxRQUFRLENBQUN5QyxRQUFvQztJQUMzRCxNQUFNQyxHQUFHLEdBQUcxQyxRQUFRLENBQUMyQyxTQUFxQztJQUUxRCxJQUFBM0IsY0FBTSxFQUFDVyxNQUFNLENBQUNwQixLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDcUMsV0FBVyxDQUFDNUMsUUFBUSxDQUFDNkMsVUFBVSxFQUFZLENBQUMsQ0FBQztJQUV0RixNQUFNQyxHQUFHLEdBQUduQixNQUFNLENBQUNwQixLQUFLLENBQUMsb0JBQW9CLENBQTJCO0lBQ3hFLElBQUFTLGNBQU0sRUFBQzhCLEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLENBQUNILFdBQVcsQ0FBQ1AsRUFBRSxDQUFDVSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ2hELElBQUEvQixjQUFNLEVBQUM4QixHQUFHLENBQUNFLGNBQWMsQ0FBQyxDQUFDSixXQUFXLENBQUNQLEVBQUUsQ0FBQ1csY0FBYyxFQUFFLENBQUMsQ0FBQztJQUM1RCxJQUFBaEMsY0FBTSxFQUFDOEIsR0FBRyxDQUFDRyxJQUFJLENBQUMsQ0FBQ0wsV0FBVyxDQUFDUCxFQUFFLENBQUNZLElBQUksRUFBRSxDQUFDLENBQUM7SUFDeEMsSUFBQWpDLGNBQU0sRUFBQzhCLEdBQUcsQ0FBQ0ksT0FBTyxHQUFHSixHQUFHLENBQUNHLElBQUksQ0FBQyxDQUFDTCxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUVoRCxNQUFNTyxHQUFHLEdBQUd4QixNQUFNLENBQUNwQixLQUFLLENBQUMsaUJBQWlCLENBQTZCO0lBQ3ZFLElBQUFTLGNBQU0sRUFBQ21DLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDMUIsS0FBSyxJQUFJbEYsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUM3QixJQUFBNkMsY0FBTSxFQUFDbUMsR0FBRyxDQUFDaEYsQ0FBQyxDQUFDLENBQUNtRixPQUFPLENBQUMsQ0FBQ1YsV0FBVyxDQUFDRixHQUFHLENBQUN2RSxDQUFDLENBQUMsQ0FBQ21GLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDckQsSUFBQXRDLGNBQU0sRUFBQ21DLEdBQUcsQ0FBQ2hGLENBQUMsQ0FBQyxDQUFDb0YsTUFBTSxDQUFDLENBQUNYLFdBQVcsQ0FBQ0YsR0FBRyxDQUFDdkUsQ0FBQyxDQUFDLENBQUNvRixNQUFNLEVBQUUsQ0FBQyxDQUFDO01BQ25ELElBQUF2QyxjQUFNLEVBQUNtQyxHQUFHLENBQUNoRixDQUFDLENBQUMsQ0FBQ3FGLFNBQVMsQ0FBQyxDQUFDWixXQUFXLENBQUNGLEdBQUcsQ0FBQ3ZFLENBQUMsQ0FBQyxDQUFDcUYsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUMzRDtJQUVBLE1BQU1DLE1BQU0sR0FBRzlCLE1BQU0sQ0FBQ3BCLEtBQUssQ0FBQyxxQkFBcUIsQ0FBNkI7SUFDOUUsS0FBSyxJQUFJcEMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUM3QixJQUFBNkMsY0FBTSxFQUFDeUMsTUFBTSxDQUFDdEYsQ0FBQyxDQUFDLENBQUN1RixPQUFPLENBQUMsQ0FBQ2QsV0FBVyxDQUFDSixLQUFLLENBQUNyRSxDQUFDLENBQUMsQ0FBQ3VGLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDMUQsSUFBQTFDLGNBQU0sRUFBQ3lDLE1BQU0sQ0FBQ3RGLENBQUMsQ0FBQyxDQUFDd0YsUUFBUSxDQUFDLENBQUNmLFdBQVcsQ0FBQ0osS0FBSyxDQUFDckUsQ0FBQyxDQUFDLENBQUN3RixRQUFRLEVBQUUsQ0FBQyxDQUFDO01BQzVELElBQUEzQyxjQUFNLEVBQUN5QyxNQUFNLENBQUN0RixDQUFDLENBQUMsQ0FBQ3lGLFFBQVEsQ0FBQyxDQUFDaEIsV0FBVyxDQUFDSixLQUFLLENBQUNyRSxDQUFDLENBQUMsQ0FBQ3lGLFFBQVEsRUFBRSxDQUFDLENBQUM7TUFDNUQsSUFBQTVDLGNBQU0sRUFBQ3lDLE1BQU0sQ0FBQ3RGLENBQUMsQ0FBQyxDQUFDMEYsUUFBUSxDQUFDLENBQUNqQixXQUFXLENBQUNKLEtBQUssQ0FBQ3JFLENBQUMsQ0FBQyxDQUFDMEYsUUFBUSxFQUFFLENBQUMsQ0FBQztNQUM1RCxJQUFBN0MsY0FBTSxFQUFDeUMsTUFBTSxDQUFDdEYsQ0FBQyxDQUFDLENBQUMyRixRQUFRLENBQUMsQ0FBQ2xCLFdBQVcsQ0FBQ0osS0FBSyxDQUFDckUsQ0FBQyxDQUFDLENBQUMyRixRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQzlEO0lBRUEsTUFBTUMsSUFBSSxHQUFHcEMsTUFBTSxDQUFDcEIsS0FBSyxDQUFDLGVBQWUsQ0FBMkI7SUFDcEUsSUFBQVMsY0FBTSxFQUFDK0MsSUFBSSxDQUFDQyxXQUFXLENBQUMsQ0FBQ3BCLFdBQVcsQ0FBQ0wsSUFBSSxDQUFDeUIsV0FBVyxFQUFFLENBQUMsQ0FBQztJQUN6RCxJQUFBaEQsY0FBTSxFQUFDK0MsSUFBSSxDQUFDRSxHQUFHLENBQUMsQ0FBQ3JCLFdBQVcsQ0FBQ0wsSUFBSSxDQUFDMEIsR0FBRyxFQUFFLEVBQUUsQ0FBQztJQUMxQyxJQUFBakQsY0FBTSxFQUFDK0MsSUFBSSxDQUFDRyxJQUFJLENBQUMsQ0FBQ3RCLFdBQVcsQ0FBQ0wsSUFBSSxDQUFDMkIsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUUzQyxNQUFNQyxHQUFHLEdBQUd4QyxNQUFNLENBQUNwQixLQUFLLENBQUMsbUJBQW1CLENBQTJCO0lBQ3ZFLElBQUFTLGNBQU0sRUFBQ21ELEdBQUcsQ0FBQ0YsR0FBRyxDQUFDLENBQUNyQixXQUFXLENBQUU1QyxRQUFRLENBQUNvRSxRQUFRLENBQTRCSCxHQUFHLEVBQUUsRUFBRSxDQUFDO0lBRWxGLElBQUFqRCxjQUFNLEVBQUNXLE1BQU0sQ0FBQ3BCLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUNxQyxXQUFXLENBQy9ENUMsUUFBUSxDQUFDcUUsdUJBQXVCLEVBQVksQ0FDOUMsQ0FBQztJQUVELE1BQU1DLElBQUksR0FBRzNDLE1BQU0sQ0FBQ3BCLEtBQUssQ0FBQyxtQkFBbUIsQ0FBNkI7SUFDMUUsTUFBTWdFLEtBQUssR0FBR3ZFLFFBQVEsQ0FBQ3dFLGdCQUE0QztJQUNuRSxJQUFBeEQsY0FBTSxFQUFDc0QsSUFBSSxDQUFDbEIsTUFBTSxDQUFDLENBQUNDLElBQUksQ0FBQyxFQUFFLENBQUM7SUFDNUIsS0FBSyxJQUFJbEYsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHLEVBQUUsRUFBRUEsQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUM5QixJQUFBNkMsY0FBTSxFQUFDc0QsSUFBSSxDQUFDbkcsQ0FBQyxDQUFDLENBQUM4RixHQUFHLENBQUMsQ0FBQ3JCLFdBQVcsQ0FBQzJCLEtBQUssQ0FBQ3BHLENBQUMsQ0FBQyxDQUFDOEYsR0FBRyxFQUFFLEVBQUUsQ0FBQztNQUNqRCxJQUFBakQsY0FBTSxFQUFDc0QsSUFBSSxDQUFDbkcsQ0FBQyxDQUFDLENBQUM2RSxjQUFjLENBQUMsQ0FBQ0osV0FBVyxDQUFDMkIsS0FBSyxDQUFDcEcsQ0FBQyxDQUFDLENBQUM2RSxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ3hFO0lBQ0E7SUFDQSxNQUFNeUIsTUFBTSxHQUFHSCxJQUFJLENBQUNJLElBQUksQ0FBRXZILENBQUMsSUFBS0EsQ0FBQyxDQUFDd0gsYUFBYSxLQUFLLEdBQUcsSUFBSXhILENBQUMsQ0FBQ3lILFNBQVMsS0FBSyxHQUFHLENBQUM7SUFDL0UsSUFBQTVELGNBQU0sRUFBQ3lELE1BQU0sRUFBRVIsR0FBRyxDQUFDLENBQUNaLElBQUksQ0FBQ1UsSUFBSSxDQUFDRSxHQUFHLENBQUM7O0lBRWxDO0lBQ0E7SUFDQSxLQUFLLE1BQU1ZLENBQUMsSUFBSU4sS0FBSyxFQUFFO01BQ3JCLE1BQU1PLEtBQUssR0FBRyxDQUFDLENBQUNELENBQUMsQ0FBQzdCLGNBQWMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU2QixDQUFDLENBQUNiLFdBQVcsQ0FBQztNQUM1RCxNQUFNZSxLQUFLLEdBQUk1SCxDQUFTLElBQWEySCxLQUFLLENBQUNFLE1BQU0sQ0FBQyxDQUFDQyxHQUFHLEVBQUVDLEVBQUUsRUFBRTlILENBQUMsS0FBSzZILEdBQUcsR0FBR0MsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHL0gsQ0FBQyxLQUFLQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO01BQzdGLElBQUkrSCxFQUFFLEdBQUcsQ0FBQyxJQUFJO01BQ2QsSUFBSUMsRUFBRSxHQUFHLEVBQUU7TUFDWCxLQUFLLElBQUlqSCxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUcsR0FBRyxFQUFFQSxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQy9CLE1BQU1rSCxHQUFHLEdBQUcsQ0FBQ0YsRUFBRSxHQUFHQyxFQUFFLElBQUksQ0FBQztRQUN6QixJQUFJTCxLQUFLLENBQUNNLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRUYsRUFBRSxHQUFHRSxHQUFHLENBQUMsS0FDeEJELEVBQUUsR0FBR0MsR0FBRztNQUNmO01BQ0EsTUFBTTtRQUFFcEI7TUFBSSxDQUFDLEdBQUcsTUFBQTlFLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUFoQyx1QkFBQSxDQUFBaEIsT0FBQSxDQUFhLHdCQUF3QixHQUFDO01BQ3RELElBQUEyRSxjQUFNLEVBQUNzRSxJQUFJLENBQUNDLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQ2EsS0FBSyxDQUFDLEdBQUcsQ0FBQ0ssRUFBRSxHQUFHQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksbUJBQW1CLENBQUMsS0FBSyxDQUFDO0lBQ3pFO0VBQ0YsQ0FBQyxDQUFDO0VBRUYsSUFBQXpFLFVBQUUsRUFBQyxvRkFBb0YsRUFBRSxZQUFZO0lBQ25HLE1BQU07TUFBRWpCO0lBQU8sQ0FBQyxHQUFHLE1BQU1ELFFBQVEsQ0FBQyxDQUFDO0lBQ25DLE1BQU04QixNQUFNLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsV0FBVyxDQUMxQ2hFLE1BQU0sQ0FBQ2lFLFdBQVcsQ0FBQ2hDLE1BQU0sQ0FBQ21CLFVBQVUsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDMUIsSUFBSSxFQUFFMEIsQ0FBQyxDQUFDWSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQ3BFO01BQUVDLFNBQVMsRUFBRSxJQUFBQyxrQ0FBaUIsRUFBQztJQUFFLENBQ25DLENBQUM7SUFDRCxNQUFNTixNQUFNLENBQUNRLEdBQUcsQ0FBQ2hDLFlBQVksQ0FBQ0wsTUFBTSxDQUFDLENBQUM7SUFDdEMsTUFBTTJGLE9BQU8sR0FBRyxNQUFNOUQsTUFBTSxDQUFDK0QsUUFBUSxDQUFDLENBQUM7SUFFdkMsSUFBQTFFLGNBQU0sRUFBQ3lFLE9BQU8sQ0FBQ0UsSUFBSSxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7SUFDdkMsTUFBTUMsT0FBaUIsR0FBRyxFQUFFO0lBQzVCLEtBQUssTUFBTSxDQUFDQyxPQUFPLEVBQUUzSSxDQUFDLENBQUMsSUFBSXNJLE9BQU8sRUFBRTtNQUNsQyxLQUFLLE1BQU1NLENBQUMsSUFBSTVJLENBQUMsQ0FBQzZJLFFBQVEsRUFBRTtRQUMxQixJQUFJLENBQUNELENBQUMsQ0FBQzdELElBQUksRUFBRTJELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDLEdBQUdILE9BQU8sTUFBTUMsQ0FBQyxDQUFDRyxFQUFFLEtBQUtILENBQUMsQ0FBQ0ksT0FBTyxFQUFFLENBQUM7TUFDakU7SUFDRjtJQUNBLElBQUFuRixjQUFNLEVBQUM2RSxPQUFPLENBQUMsQ0FBQ3pFLE9BQU8sQ0FBQyxFQUFFLENBQUM7O0lBRTNCO0lBQ0E7SUFDQSxNQUFNZ0YsT0FBTyxHQUFHWCxPQUFPLENBQUNoSSxHQUFHLENBQUMsaUJBQWlCLENBQUMsRUFBRXVJLFFBQVEsQ0FBQ3RCLElBQUksQ0FBRXFCLENBQUMsSUFBS0EsQ0FBQyxDQUFDRyxFQUFFLEtBQUssb0JBQW9CLENBQUM7SUFDbkcsSUFBQWxGLGNBQU0sRUFBQ29GLE9BQU8sRUFBRWxFLElBQUksQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNoQztJQUNBLE1BQU1nRCxRQUFRLEdBQUdaLE9BQU8sQ0FBQ2hJLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFdUksUUFBUSxDQUFDdEIsSUFBSSxDQUFFcUIsQ0FBQyxJQUFLQSxDQUFDLENBQUNHLEVBQUUsS0FBSyxxQkFBcUIsQ0FBQztJQUN4RyxJQUFBbEYsY0FBTSxFQUFDcUYsUUFBUSxFQUFFbkUsSUFBSSxDQUFDLENBQUNtQixJQUFJLENBQUMsSUFBSSxDQUFDOztJQUVqQztJQUNBO0lBQ0EsS0FBSyxNQUFNeUMsT0FBTyxJQUFJLENBQ3BCLGtCQUFrQixFQUFFLG9CQUFvQixFQUFFLHdCQUF3QixFQUFFLGlCQUFpQixFQUNyRixxQkFBcUIsRUFBRSx5QkFBeUIsRUFBRSxlQUFlLEVBQUUsbUJBQW1CLEVBQ3RGLG1CQUFtQixFQUFFLCtCQUErQixDQUNyRCxFQUFFO01BQ0QsSUFBQTlFLGNBQU0sRUFBQ3lFLE9BQU8sQ0FBQ2hJLEdBQUcsQ0FBQ3FJLE9BQU8sQ0FBQyxFQUFFUSxPQUFPLEVBQUUsZUFBZVIsT0FBTyxFQUFFLENBQUMsQ0FBQ3pDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDbkY7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBdEMsVUFBRSxFQUFDLGlFQUFpRSxFQUFFLFlBQVk7SUFDaEYsTUFBTTtNQUFFakI7SUFBTyxDQUFDLEdBQUcsTUFBTUQsUUFBUSxDQUFDLENBQUM7SUFDbkMsTUFBTTBHLFFBQVEsR0FBR3pHLE1BQU0sQ0FBQzBHLFNBQVMsQ0FBQzlCLElBQUksQ0FBRXRILENBQUMsSUFBS0EsQ0FBQyxDQUFDcUMsSUFBSSxLQUFLLGNBQWMsQ0FBQztJQUN4RSxJQUFBdUIsY0FBTSxFQUFDdUYsUUFBUSxDQUFDLENBQUNFLFdBQVcsQ0FBQyxDQUFDO0lBQzlCLE1BQU1DLEtBQUssR0FBRyxJQUFBQyxrQkFBYSxFQUFDSixRQUFRLENBQUV4RSxNQUFNLENBQUM7SUFDN0MsTUFBTTZFLFVBQVUsR0FBRyxJQUFBQywwQkFBZ0IsRUFBQ0gsS0FBSyxDQUFDO0lBQzFDLElBQUExRixjQUFNLEVBQUM0RixVQUFVLENBQUNyRixXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDTixPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ2hGLElBQUFKLGNBQU0sRUFBQzRGLFVBQVUsQ0FBQ0UsWUFBWSxDQUFDLENBQUMxRixPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzdDLENBQUMsQ0FBQzs7RUFFRjtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUFMLFVBQUUsRUFBQyxvRUFBb0UsRUFBRSxZQUFZO0lBQ25GLE1BQU07TUFBRWpCLE1BQU07TUFBRUU7SUFBUyxDQUFDLEdBQUcsTUFBTUgsUUFBUSxDQUFDLENBQUM7SUFDN0MsTUFBTThCLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQzFDaEUsTUFBTSxDQUFDaUUsV0FBVyxDQUFDaEMsTUFBTSxDQUFDbUIsVUFBVSxDQUFDQyxHQUFHLENBQUVDLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUMxQixJQUFJLEVBQUUwQixDQUFDLENBQUNZLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDcEU7TUFBRUMsU0FBUyxFQUFFLElBQUFDLGtDQUFpQixFQUFDO0lBQUUsQ0FDbkMsQ0FBQztJQUNELE1BQU07TUFBRTdCLFNBQVM7TUFBRTJHO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGdDQUFpQixFQUFDbEgsTUFBTSxDQUFDO0lBQzFELE1BQU02QixNQUFNLENBQUNRLEdBQUcsQ0FBQy9CLFNBQVMsQ0FBQztJQUUzQixJQUFBWSxjQUFNLEVBQUMrRixTQUFTLENBQUNFLFFBQVEsQ0FBQyxDQUFDN0YsT0FBTyxDQUFDO01BQUU4RixJQUFJLEVBQUUsc0JBQXNCO01BQUVDLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUN4RixJQUFBbkcsY0FBTSxFQUFDWixTQUFTLENBQUMsaUJBQWlCLENBQUMsRUFBRUcsS0FBSyxDQUFDLENBQUM4QyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3RELE1BQU0rRCxPQUFPLEdBQUl6RixNQUFNLENBQUNwQixLQUFLLENBQUMsZUFBZSxDQUFDLENBQTRCMEQsR0FBRztJQUM3RSxNQUFNb0QsT0FBTyxHQUFHMUYsTUFBTSxDQUFDcEIsS0FBSyxDQUFDLGtCQUFrQixDQUFDOztJQUVoRDtJQUNBLElBQUkrRyxVQUFVLEdBQUcsS0FBSztJQUN0QixNQUFNQyxRQUFRLEdBQUcsSUFBQUMsOEJBQWUsRUFDOUI7TUFBRTdGLE1BQU07TUFBRXZCLFNBQVM7TUFBRTJHLFNBQVM7TUFBRUwsS0FBSyxFQUFFLEVBQUU7TUFBRWUsS0FBSyxFQUFFLEdBQUc7TUFBRWxHLFdBQVcsRUFBRSxFQUFFO01BQUUyQixPQUFPLEVBQUUsQ0FBQyxDQUFDO01BQUVwRCxNQUFNO01BQUU0SCxZQUFZLEVBQUUsRUFBRTtNQUFFQyxZQUFZLEVBQUUsRUFBRTtNQUFFQyxtQkFBbUIsRUFBRTtJQUFNLENBQUMsRUFDN0osTUFBTTtNQUFFTixVQUFVLEdBQUcsSUFBSTtJQUFFLENBQzdCLENBQUM7SUFDRCxNQUFNTyxtQkFBbUIsR0FBR3pILFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFFRyxLQUFLO0lBQ3BFZ0gsUUFBUSxDQUFDTyxRQUFRLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQztJQUNuQyxPQUFPLENBQUNSLFVBQVUsRUFBRSxNQUFNLElBQUluSSxPQUFPLENBQUVoQyxDQUFDLElBQUs0SyxVQUFVLENBQUM1SyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFOUQsTUFBTTZLLE9BQU8sR0FBR2hJLFFBQVEsQ0FBQ2lJLGFBQW9FO0lBQzdGLE1BQU16RixLQUFLLEdBQUdiLE1BQU0sQ0FBQ3BCLEtBQUssQ0FBQyxxQkFBcUIsQ0FBNkI7SUFDN0UsSUFBQVMsY0FBTSxFQUFDd0IsS0FBSyxDQUFDWSxNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM1QixLQUFLLElBQUlsRixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLElBQUksQ0FBQyxFQUFFO01BQzdCLElBQUE2QyxjQUFNLEVBQUN3QixLQUFLLENBQUNyRSxDQUFDLENBQUMsQ0FBQ3VGLE9BQU8sQ0FBQyxDQUFDZCxXQUFXLENBQUNvRixPQUFPLENBQUN2RixRQUFRLENBQUN0RSxDQUFDLENBQUMsQ0FBQ3VGLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDcEUsSUFBQTFDLGNBQU0sRUFBQ3dCLEtBQUssQ0FBQ3JFLENBQUMsQ0FBQyxDQUFDeUYsUUFBUSxDQUFDLENBQUNoQixXQUFXLENBQUNvRixPQUFPLENBQUN2RixRQUFRLENBQUN0RSxDQUFDLENBQUMsQ0FBQ3lGLFFBQVEsRUFBRSxDQUFDLENBQUM7SUFDeEU7SUFDQSxNQUFNc0UsVUFBVSxHQUFJdkcsTUFBTSxDQUFDcEIsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUE0QjBELEdBQUc7SUFDaEYsSUFBQWpELGNBQU0sRUFBQ2tILFVBQVUsQ0FBQyxDQUFDdEYsV0FBVyxDQUFDb0YsT0FBTyxDQUFDL0QsR0FBRyxFQUFFLEVBQUUsQ0FBQztJQUMvQyxJQUFBakQsY0FBTSxFQUFDa0gsVUFBVSxDQUFDLENBQUNDLFlBQVksQ0FBQ2YsT0FBTyxDQUFDLENBQUMsQ0FBQzs7SUFFMUM7SUFDQTtJQUNBLElBQUFwRyxjQUFNLEVBQUU2RyxtQkFBbUIsQ0FBOEIsQ0FBQyxDQUFDLENBQUNaLFFBQVEsQ0FBQyxDQUFDNUQsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNoRixJQUFBckMsY0FBTSxFQUFFWixTQUFTLENBQUMsc0JBQXNCLENBQUMsQ0FBRUcsS0FBSyxDQUE4QixDQUFDLENBQUMsQ0FBQzBHLFFBQVEsQ0FBQyxDQUFDNUQsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNyRyxJQUFBckMsY0FBTSxFQUFDVyxNQUFNLENBQUNwQixLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDOEMsSUFBSSxDQUFDZ0UsT0FBTyxDQUFDO0lBQ3RELElBQUFyRyxjQUFNLEVBQUNaLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFRyxLQUFLLENBQUMsQ0FBQzhDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDeEQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119