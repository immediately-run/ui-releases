var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _suiteReport = require("../engine/suiteReport.ts");
var _useOverlayDialog = require("./useOverlayDialog.ts");
var _WorkbookPanelBody = _interopRequireDefault(require("./WorkbookPanelBody.tsx"));
var _ScratchPad = _interopRequireDefault(require("./ScratchPad.tsx"));
var _VocabularySection = _interopRequireDefault(require("./VocabularySection.tsx"));
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The review surface — workbook panel (design brief surface 3; §6). One card per cell:
// name, doc, value preview, and the **coverage state** chip; test cards render beneath their
// subject with kind labels. The verdict rule is load-bearing (§6, review-2): `validated`
// requires a non-example-based leg (metamorphic/property); example-only coverage reads
// `pinned`, never "tested" — the four states must stay visually distinct or the testing
// story is theater. Author-side surface (viewers never see worksheets, brief A3): opened
// from the report header, closed by default, run-mode report untouched. Card clicks open
// the value inspector (App owns the inspected cell, shared with the on-pixel affordance).
//
// The vocabulary section (DOCUMENT_NAVIGATOR_SPEC Part A) rides at the bottom too —
// panel chrome, derived from the closed catalog, so "what can I use as an input knob?"
// has an answer inside the product.
//
// The scratch pad (WHATIF_SHADOW_EVALUATION_SPEC §1.2) rides at the bottom: an unsaved
// worksheet evaluated through the shadow session, sharing this panel's suite results as
// the verdict-diff base. Its buffer text is App-owned (§1.4 — survives panel close).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function WorkbookPanel({
  session,
  verdicts,
  onInspect,
  onClose,
  onOpenAuthors,
  scratchText,
  onScratchChange
}) {
  _s();
  // The panel's dialog contract (R3-610): this component mounts with the open panel, so
  // the hook's effect runs at mount — focus in (Run suite, the first focusable), Tab wrap,
  // keyed close → the same onClose as the header's Close, focus back to the
  // `rk-review-toggle` captured at open. No `enabled` flag: mount/unmount IS the gate.
  const panelRef = (0, _useOverlayDialog.useOverlayDialog)(onClose);
  const engine = session.engine;
  const {
    results,
    error,
    running,
    rerun
  } = verdicts;
  const cells = engine.cells();
  // S4a (R3-231): the workbook-level answer in one line, from the SAME verdicts the cards
  // below render — the in-platform equivalent of a test-runner summary, no terminal.
  const report = (0, _suiteReport.summarizeSuite)(cells, results);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("aside", {
    className: "rk-wb-panel",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": "Workbook review",
    ref: panelRef,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "rk-wb-head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
        children: "Workbook"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-wb-actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-wb-run",
          onClick: rerun,
          disabled: running,
          children: running ? 'Running…' : 'Run suite'
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-wb-close",
          onClick: onOpenAuthors,
          children: "Author's view"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-wb-close",
          onClick: onClose,
          children: "Close"
        })]
      })]
    }), error !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wb-error",
      children: error
    }), results === null && error === null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wb-note",
      children: "Running suites\u2026"
    }), results !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `rk-wb-summary ${report.ok ? 'rk-wb-summary--ok' : 'rk-wb-summary--fail'}`,
      role: "status",
      children: report.line
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_WorkbookPanelBody.default, {
      cells: cells,
      tests: engine.tests(),
      results: results,
      valueOf: id => engine.value(id),
      onInspect: onInspect
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ScratchPad.default, {
      session: session,
      baseVerdicts: results,
      text: scratchText,
      onTextChange: onScratchChange
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_VocabularySection.default, {})]
  });
}
_s(WorkbookPanel, "wSHkw0BBaJENrS4vSt0Xz6IEyAk=", false, function () {
  return [_useOverlayDialog.useOverlayDialog];
});
_c = WorkbookPanel;
var _default = exports.default = WorkbookPanel;
var _c;
$RefreshReg$(_c, "WorkbookPanel");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc3VpdGVSZXBvcnQiLCJyZXF1aXJlIiwiX3VzZU92ZXJsYXlEaWFsb2ciLCJfV29ya2Jvb2tQYW5lbEJvZHkiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1NjcmF0Y2hQYWQiLCJfVm9jYWJ1bGFyeVNlY3Rpb24iLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiV29ya2Jvb2tQYW5lbCIsInNlc3Npb24iLCJ2ZXJkaWN0cyIsIm9uSW5zcGVjdCIsIm9uQ2xvc2UiLCJvbk9wZW5BdXRob3JzIiwic2NyYXRjaFRleHQiLCJvblNjcmF0Y2hDaGFuZ2UiLCJwYW5lbFJlZiIsInVzZU92ZXJsYXlEaWFsb2ciLCJlbmdpbmUiLCJyZXN1bHRzIiwiZXJyb3IiLCJydW5uaW5nIiwicmVydW4iLCJjZWxscyIsInJlcG9ydCIsInN1bW1hcml6ZVN1aXRlIiwianN4cyIsImNsYXNzTmFtZSIsInJvbGUiLCJyZWYiLCJjaGlsZHJlbiIsImpzeCIsInR5cGUiLCJvbkNsaWNrIiwiZGlzYWJsZWQiLCJvayIsImxpbmUiLCJ0ZXN0cyIsInZhbHVlT2YiLCJpZCIsInZhbHVlIiwiYmFzZVZlcmRpY3RzIiwidGV4dCIsIm9uVGV4dENoYW5nZSIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV29ya2Jvb2tQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHJldmlldyBzdXJmYWNlIOKAlCB3b3JrYm9vayBwYW5lbCAoZGVzaWduIGJyaWVmIHN1cmZhY2UgMzsgwqc2KS4gT25lIGNhcmQgcGVyIGNlbGw6XG4vLyBuYW1lLCBkb2MsIHZhbHVlIHByZXZpZXcsIGFuZCB0aGUgKipjb3ZlcmFnZSBzdGF0ZSoqIGNoaXA7IHRlc3QgY2FyZHMgcmVuZGVyIGJlbmVhdGggdGhlaXJcbi8vIHN1YmplY3Qgd2l0aCBraW5kIGxhYmVscy4gVGhlIHZlcmRpY3QgcnVsZSBpcyBsb2FkLWJlYXJpbmcgKMKnNiwgcmV2aWV3LTIpOiBgdmFsaWRhdGVkYFxuLy8gcmVxdWlyZXMgYSBub24tZXhhbXBsZS1iYXNlZCBsZWcgKG1ldGFtb3JwaGljL3Byb3BlcnR5KTsgZXhhbXBsZS1vbmx5IGNvdmVyYWdlIHJlYWRzXG4vLyBgcGlubmVkYCwgbmV2ZXIgXCJ0ZXN0ZWRcIiDigJQgdGhlIGZvdXIgc3RhdGVzIG11c3Qgc3RheSB2aXN1YWxseSBkaXN0aW5jdCBvciB0aGUgdGVzdGluZ1xuLy8gc3RvcnkgaXMgdGhlYXRlci4gQXV0aG9yLXNpZGUgc3VyZmFjZSAodmlld2VycyBuZXZlciBzZWUgd29ya3NoZWV0cywgYnJpZWYgQTMpOiBvcGVuZWRcbi8vIGZyb20gdGhlIHJlcG9ydCBoZWFkZXIsIGNsb3NlZCBieSBkZWZhdWx0LCBydW4tbW9kZSByZXBvcnQgdW50b3VjaGVkLiBDYXJkIGNsaWNrcyBvcGVuXG4vLyB0aGUgdmFsdWUgaW5zcGVjdG9yIChBcHAgb3ducyB0aGUgaW5zcGVjdGVkIGNlbGwsIHNoYXJlZCB3aXRoIHRoZSBvbi1waXhlbCBhZmZvcmRhbmNlKS5cbi8vXG4vLyBUaGUgdm9jYWJ1bGFyeSBzZWN0aW9uIChET0NVTUVOVF9OQVZJR0FUT1JfU1BFQyBQYXJ0IEEpIHJpZGVzIGF0IHRoZSBib3R0b20gdG9vIOKAlFxuLy8gcGFuZWwgY2hyb21lLCBkZXJpdmVkIGZyb20gdGhlIGNsb3NlZCBjYXRhbG9nLCBzbyBcIndoYXQgY2FuIEkgdXNlIGFzIGFuIGlucHV0IGtub2I/XCJcbi8vIGhhcyBhbiBhbnN3ZXIgaW5zaWRlIHRoZSBwcm9kdWN0LlxuLy9cbi8vIFRoZSBzY3JhdGNoIHBhZCAoV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMgwqcxLjIpIHJpZGVzIGF0IHRoZSBib3R0b206IGFuIHVuc2F2ZWRcbi8vIHdvcmtzaGVldCBldmFsdWF0ZWQgdGhyb3VnaCB0aGUgc2hhZG93IHNlc3Npb24sIHNoYXJpbmcgdGhpcyBwYW5lbCdzIHN1aXRlIHJlc3VsdHMgYXNcbi8vIHRoZSB2ZXJkaWN0LWRpZmYgYmFzZS4gSXRzIGJ1ZmZlciB0ZXh0IGlzIEFwcC1vd25lZCAowqcxLjQg4oCUIHN1cnZpdmVzIHBhbmVsIGNsb3NlKS5cbmltcG9ydCB0eXBlIHsgU3ViamVjdFJlc3VsdCB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXIvcHJvdG9jb2wudHMnO1xuaW1wb3J0IHsgc3VtbWFyaXplU3VpdGUgfSBmcm9tICcuLi9lbmdpbmUvc3VpdGVSZXBvcnQudHMnO1xuaW1wb3J0IHR5cGUgeyBSZXBvcnRTZXNzaW9uIH0gZnJvbSAnLi9yZXBvcnRTZXNzaW9uLnRzJztcbmltcG9ydCB7IHVzZU92ZXJsYXlEaWFsb2cgfSBmcm9tICcuL3VzZU92ZXJsYXlEaWFsb2cudHMnO1xuaW1wb3J0IFdvcmtib29rUGFuZWxCb2R5IGZyb20gJy4vV29ya2Jvb2tQYW5lbEJvZHkudHN4JztcbmltcG9ydCBTY3JhdGNoUGFkIGZyb20gJy4vU2NyYXRjaFBhZC50c3gnO1xuaW1wb3J0IFZvY2FidWxhcnlTZWN0aW9uIGZyb20gJy4vVm9jYWJ1bGFyeVNlY3Rpb24udHN4JztcbmltcG9ydCAnLi93b3JrYm9vay1wYW5lbC5jc3MnO1xuXG5pbnRlcmZhY2UgV29ya2Jvb2tQYW5lbFByb3BzIHtcbiAgc2Vzc2lvbjogUmVwb3J0U2Vzc2lvbjtcbiAgLyoqXG4gICAqIFRoZSBhcHAtbGV2ZWwgc3VpdGUgc3RhdGUgKEFVVEhPUlNfVklFV19TUEVDIMKnMy40LCBHLUFWLTEwKTogT05FIGB1c2VWZXJkaWN0c2BcbiAgICogb3duZWQgYnkgQXBwIGRyaXZlcyB0aGlzIHBhbmVsLCB0aGUgaW5zcGVjdG9yLCBhbmQgdGhlIGF1dGhvcidzIHZpZXcg4oCUIHRoZSBob29rJ3NcbiAgICogb3duIFwibXVzdCBub3QgYmUgY29tcHV0ZWQgdHdpY2VcIiBjb250cmFjdCwgcHJldmlvdXNseSB2aW9sYXRlZCBieSBhIHNlY29uZFxuICAgKiBpbnN0YW50aWF0aW9uIGhlcmUuXG4gICAqL1xuICB2ZXJkaWN0czoge1xuICAgIHJlc3VsdHM6IE1hcDxzdHJpbmcsIFN1YmplY3RSZXN1bHQ+IHwgbnVsbDtcbiAgICBlcnJvcjogc3RyaW5nIHwgbnVsbDtcbiAgICBydW5uaW5nOiBib29sZWFuO1xuICAgIHJlcnVuOiAoKSA9PiB2b2lkO1xuICB9O1xuICAvKiogT3BlbiB0aGUgdmFsdWUgaW5zcGVjdG9yIG9uIGEgY2VsbCAoY2FyZCBjbGljaykuICovXG4gIG9uSW5zcGVjdDogKGNlbGxJZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAvKiogT3BlbiB0aGUgYXV0aG9yJ3MgdmlldyAoQVVUSE9SU19WSUVXX1NQRUMgwqcxLjIg4oCUIHRoaXMgcGFuZWwgaXMgaXRzIGRvb3IpLiAqL1xuICBvbk9wZW5BdXRob3JzOiAoKSA9PiB2b2lkO1xuICAvKiogVGhlIHNjcmF0Y2ggcGFkJ3Mgc2Vzc2lvbi1zY29wZWQgYnVmZmVyIHRleHQgKEFwcCBvd25zIGl0OyBzcGVjIMKnMS40KS4gKi9cbiAgc2NyYXRjaFRleHQ6IHN0cmluZztcbiAgb25TY3JhdGNoQ2hhbmdlOiAodGV4dDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBXb3JrYm9va1BhbmVsKHsgc2Vzc2lvbiwgdmVyZGljdHMsIG9uSW5zcGVjdCwgb25DbG9zZSwgb25PcGVuQXV0aG9ycywgc2NyYXRjaFRleHQsIG9uU2NyYXRjaENoYW5nZSB9OiBXb3JrYm9va1BhbmVsUHJvcHMpIHtcbiAgLy8gVGhlIHBhbmVsJ3MgZGlhbG9nIGNvbnRyYWN0IChSMy02MTApOiB0aGlzIGNvbXBvbmVudCBtb3VudHMgd2l0aCB0aGUgb3BlbiBwYW5lbCwgc29cbiAgLy8gdGhlIGhvb2sncyBlZmZlY3QgcnVucyBhdCBtb3VudCDigJQgZm9jdXMgaW4gKFJ1biBzdWl0ZSwgdGhlIGZpcnN0IGZvY3VzYWJsZSksIFRhYiB3cmFwLFxuICAvLyBrZXllZCBjbG9zZSDihpIgdGhlIHNhbWUgb25DbG9zZSBhcyB0aGUgaGVhZGVyJ3MgQ2xvc2UsIGZvY3VzIGJhY2sgdG8gdGhlXG4gIC8vIGByay1yZXZpZXctdG9nZ2xlYCBjYXB0dXJlZCBhdCBvcGVuLiBObyBgZW5hYmxlZGAgZmxhZzogbW91bnQvdW5tb3VudCBJUyB0aGUgZ2F0ZS5cbiAgY29uc3QgcGFuZWxSZWYgPSB1c2VPdmVybGF5RGlhbG9nPEhUTUxFbGVtZW50PihvbkNsb3NlKTtcbiAgY29uc3QgZW5naW5lID0gc2Vzc2lvbi5lbmdpbmU7XG4gIGNvbnN0IHsgcmVzdWx0cywgZXJyb3IsIHJ1bm5pbmcsIHJlcnVuIH0gPSB2ZXJkaWN0cztcbiAgY29uc3QgY2VsbHMgPSBlbmdpbmUuY2VsbHMoKTtcbiAgLy8gUzRhIChSMy0yMzEpOiB0aGUgd29ya2Jvb2stbGV2ZWwgYW5zd2VyIGluIG9uZSBsaW5lLCBmcm9tIHRoZSBTQU1FIHZlcmRpY3RzIHRoZSBjYXJkc1xuICAvLyBiZWxvdyByZW5kZXIg4oCUIHRoZSBpbi1wbGF0Zm9ybSBlcXVpdmFsZW50IG9mIGEgdGVzdC1ydW5uZXIgc3VtbWFyeSwgbm8gdGVybWluYWwuXG4gIGNvbnN0IHJlcG9ydCA9IHN1bW1hcml6ZVN1aXRlKGNlbGxzLCByZXN1bHRzKTtcblxuICByZXR1cm4gKFxuICAgIDxhc2lkZSBjbGFzc05hbWU9XCJyay13Yi1wYW5lbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJXb3JrYm9vayByZXZpZXdcIiByZWY9e3BhbmVsUmVmfT5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicmstd2ItaGVhZFwiPlxuICAgICAgICA8aDI+V29ya2Jvb2s8L2gyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdiLWFjdGlvbnNcIj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyay13Yi1ydW5cIiBvbkNsaWNrPXtyZXJ1bn0gZGlzYWJsZWQ9e3J1bm5pbmd9PlxuICAgICAgICAgICAge3J1bm5pbmcgPyAnUnVubmluZ+KApicgOiAnUnVuIHN1aXRlJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyay13Yi1jbG9zZVwiIG9uQ2xpY2s9e29uT3BlbkF1dGhvcnN9PlxuICAgICAgICAgICAgQXV0aG9yJ3Mgdmlld1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICBDbG9zZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAge2Vycm9yICE9PSBudWxsICYmIDxkaXYgY2xhc3NOYW1lPVwicmstd2ItZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxuICAgICAge3Jlc3VsdHMgPT09IG51bGwgJiYgZXJyb3IgPT09IG51bGwgJiYgPGRpdiBjbGFzc05hbWU9XCJyay13Yi1ub3RlXCI+UnVubmluZyBzdWl0ZXPigKY8L2Rpdj59XG4gICAgICB7cmVzdWx0cyAhPT0gbnVsbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcmstd2Itc3VtbWFyeSAke3JlcG9ydC5vayA/ICdyay13Yi1zdW1tYXJ5LS1vaycgOiAncmstd2Itc3VtbWFyeS0tZmFpbCd9YH0gcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgIHtyZXBvcnQubGluZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgPFdvcmtib29rUGFuZWxCb2R5XG4gICAgICAgIGNlbGxzPXtjZWxsc31cbiAgICAgICAgdGVzdHM9e2VuZ2luZS50ZXN0cygpfVxuICAgICAgICByZXN1bHRzPXtyZXN1bHRzfVxuICAgICAgICB2YWx1ZU9mPXsoaWQpID0+IGVuZ2luZS52YWx1ZShpZCl9XG4gICAgICAgIG9uSW5zcGVjdD17b25JbnNwZWN0fVxuICAgICAgLz5cbiAgICAgIDxTY3JhdGNoUGFkIHNlc3Npb249e3Nlc3Npb259IGJhc2VWZXJkaWN0cz17cmVzdWx0c30gdGV4dD17c2NyYXRjaFRleHR9IG9uVGV4dENoYW5nZT17b25TY3JhdGNoQ2hhbmdlfSAvPlxuICAgICAgPFZvY2FidWxhcnlTZWN0aW9uIC8+XG4gICAgPC9hc2lkZT5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgV29ya2Jvb2tQYW5lbDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBaUJBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLGlCQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxrQkFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUksV0FBQSxHQUFBRCxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUssa0JBQUEsR0FBQUYsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBQSxPQUFBO0FBQThCLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQXZCOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBTCx1QkFBQU0sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWtDQSxTQUFTRyxhQUFhQSxDQUFDO0VBQUVDLE9BQU87RUFBRUMsUUFBUTtFQUFFQyxTQUFTO0VBQUVDLE9BQU87RUFBRUMsYUFBYTtFQUFFQyxXQUFXO0VBQUVDO0FBQW9DLENBQUMsRUFBRTtFQUFBWixFQUFBO0VBQ2pJO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTWEsUUFBUSxHQUFHLElBQUFDLGtDQUFnQixFQUFjTCxPQUFPLENBQUM7RUFDdkQsTUFBTU0sTUFBTSxHQUFHVCxPQUFPLENBQUNTLE1BQU07RUFDN0IsTUFBTTtJQUFFQyxPQUFPO0lBQUVDLEtBQUs7SUFBRUMsT0FBTztJQUFFQztFQUFNLENBQUMsR0FBR1osUUFBUTtFQUNuRCxNQUFNYSxLQUFLLEdBQUdMLE1BQU0sQ0FBQ0ssS0FBSyxDQUFDLENBQUM7RUFDNUI7RUFDQTtFQUNBLE1BQU1DLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDRixLQUFLLEVBQUVKLE9BQU8sQ0FBQztFQUU3QyxvQkFDRSxJQUFBakIsV0FBQSxDQUFBd0IsSUFBQTtJQUFPQyxTQUFTLEVBQUMsYUFBYTtJQUFDQyxJQUFJLEVBQUMsUUFBUTtJQUFDLGNBQVcsTUFBTTtJQUFDLGNBQVcsaUJBQWlCO0lBQUNDLEdBQUcsRUFBRWIsUUFBUztJQUFBYyxRQUFBLGdCQUN4RyxJQUFBNUIsV0FBQSxDQUFBd0IsSUFBQTtNQUFRQyxTQUFTLEVBQUMsWUFBWTtNQUFBRyxRQUFBLGdCQUM1QixJQUFBNUIsV0FBQSxDQUFBNkIsR0FBQTtRQUFBRCxRQUFBLEVBQUk7TUFBUSxDQUFJLENBQUMsZUFDakIsSUFBQTVCLFdBQUEsQ0FBQXdCLElBQUE7UUFBS0MsU0FBUyxFQUFDLGVBQWU7UUFBQUcsUUFBQSxnQkFDNUIsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUE7VUFBUUMsSUFBSSxFQUFDLFFBQVE7VUFBQ0wsU0FBUyxFQUFDLFdBQVc7VUFBQ00sT0FBTyxFQUFFWCxLQUFNO1VBQUNZLFFBQVEsRUFBRWIsT0FBUTtVQUFBUyxRQUFBLEVBQzNFVCxPQUFPLEdBQUcsVUFBVSxHQUFHO1FBQVcsQ0FDN0IsQ0FBQyxlQUNULElBQUFuQixXQUFBLENBQUE2QixHQUFBO1VBQVFDLElBQUksRUFBQyxRQUFRO1VBQUNMLFNBQVMsRUFBQyxhQUFhO1VBQUNNLE9BQU8sRUFBRXBCLGFBQWM7VUFBQWlCLFFBQUEsRUFBQztRQUV0RSxDQUFRLENBQUMsZUFDVCxJQUFBNUIsV0FBQSxDQUFBNkIsR0FBQTtVQUFRQyxJQUFJLEVBQUMsUUFBUTtVQUFDTCxTQUFTLEVBQUMsYUFBYTtVQUFDTSxPQUFPLEVBQUVyQixPQUFRO1VBQUFrQixRQUFBLEVBQUM7UUFFaEUsQ0FBUSxDQUFDO01BQUEsQ0FDTixDQUFDO0lBQUEsQ0FDQSxDQUFDLEVBQ1JWLEtBQUssS0FBSyxJQUFJLGlCQUFJLElBQUFsQixXQUFBLENBQUE2QixHQUFBO01BQUtKLFNBQVMsRUFBQyxhQUFhO01BQUFHLFFBQUEsRUFBRVY7SUFBSyxDQUFNLENBQUMsRUFDNURELE9BQU8sS0FBSyxJQUFJLElBQUlDLEtBQUssS0FBSyxJQUFJLGlCQUFJLElBQUFsQixXQUFBLENBQUE2QixHQUFBO01BQUtKLFNBQVMsRUFBQyxZQUFZO01BQUFHLFFBQUEsRUFBQztJQUFlLENBQUssQ0FBQyxFQUN2RlgsT0FBTyxLQUFLLElBQUksaUJBQ2YsSUFBQWpCLFdBQUEsQ0FBQTZCLEdBQUE7TUFBS0osU0FBUyxFQUFFLGlCQUFpQkgsTUFBTSxDQUFDVyxFQUFFLEdBQUcsbUJBQW1CLEdBQUcscUJBQXFCLEVBQUc7TUFBQ1AsSUFBSSxFQUFDLFFBQVE7TUFBQUUsUUFBQSxFQUN0R04sTUFBTSxDQUFDWTtJQUFJLENBQ1QsQ0FDTixlQUNELElBQUFsQyxXQUFBLENBQUE2QixHQUFBLEVBQUNqQyxrQkFBQSxDQUFBUyxPQUFpQjtNQUNoQmdCLEtBQUssRUFBRUEsS0FBTTtNQUNiYyxLQUFLLEVBQUVuQixNQUFNLENBQUNtQixLQUFLLENBQUMsQ0FBRTtNQUN0QmxCLE9BQU8sRUFBRUEsT0FBUTtNQUNqQm1CLE9BQU8sRUFBR0MsRUFBRSxJQUFLckIsTUFBTSxDQUFDc0IsS0FBSyxDQUFDRCxFQUFFLENBQUU7TUFDbEM1QixTQUFTLEVBQUVBO0lBQVUsQ0FDdEIsQ0FBQyxlQUNGLElBQUFULFdBQUEsQ0FBQTZCLEdBQUEsRUFBQy9CLFdBQUEsQ0FBQU8sT0FBVTtNQUFDRSxPQUFPLEVBQUVBLE9BQVE7TUFBQ2dDLFlBQVksRUFBRXRCLE9BQVE7TUFBQ3VCLElBQUksRUFBRTVCLFdBQVk7TUFBQzZCLFlBQVksRUFBRTVCO0lBQWdCLENBQUUsQ0FBQyxlQUN6RyxJQUFBYixXQUFBLENBQUE2QixHQUFBLEVBQUM5QixrQkFBQSxDQUFBTSxPQUFpQixJQUFFLENBQUM7RUFBQSxDQUNoQixDQUFDO0FBRVo7QUFBQ0osRUFBQSxDQS9DUUssYUFBYTtFQUFBLFFBS0hTLGtDQUFnQjtBQUFBO0FBQUEyQixFQUFBLEdBTDFCcEMsYUFBYTtBQUFBLElBQUFxQyxRQUFBLEdBQUFDLE9BQUEsQ0FBQXZDLE9BQUEsR0FpRFBDLGFBQWE7QUFBQSxJQUFBb0MsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}