"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _vitest = require("vitest");
var stdlib = _interopRequireWildcard(require("../stdlib/index.ts"));
var _engine = require("./engine.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// Test-input resolution + the two lanes (ARCHITECTURE_PLAN §6, R3-373). A test's declared
// inputs resolve against the same published state a cell's do, then split by local name:
// name-matched entries SUBSTITUTe (the subject formula re-runs over `{ ...live, ...sub }`;
// the holdout shape), name-unmatched entries are AUXILIARY context for `expect`/`relation`
// only (an oracle fixture) and never feed the formula. Authoring errors — an unresolvable
// reference, an absent external, a subject error over the fixture — fail the test with a
// message, never a silent null. The subject's published live value is untouched either way.

const liveOrders = [{
  month: '2026-01',
  eur: 100
}, {
  month: '2026-02',
  eur: 50
}, {
  month: '2026-01',
  eur: 40
}];
const holdoutOrders = [{
  month: '2026-01',
  eur: 30
}, {
  month: '2026-02',
  eur: 10
}];
const SOURCES = {
  revenue: `
    import { cell, testCell, expectEqual } from "@reckoner/stdlib";

    export const by_month = cell({
      doc: "revenue by month for a region",
      inputs: { orders: "feeds.orders", region: "params.region" },
      formula: ({ orders, region }) =>
        orders
          .filter((r) => region === "all" || r.region === region)
          .reduce((a, r) => a + r.eur, 0),
    });

    export const holdout_check = testCell({
      kind: "specification",
      subject: "revenue.by_month",
      inputs: { orders: "fixtures.orders_holdout" },
      expect: ({ result }) => expectEqual(result, 40),
    });

    export const wrong_name = testCell({
      kind: "specification",
      subject: "revenue.by_month",
      inputs: { orderz: "fixtures.orders_holdout" },
      expect: ({ result, inputs }) =>
        result === 190 && inputs.orderz.length === 2
          ? { pass: true, message: "live subject + auxiliary fixture both visible; the unmatched name never fed the formula" }
          : { pass: false, message: "result " + result + ", aux rows " + (inputs.orderz && inputs.orderz.length) },
    });

    export const absent_fixture = testCell({
      kind: "specification",
      subject: "revenue.by_month",
      inputs: { ghost: "fixtures.no_such_fixture" },
      expect: () => ({ pass: true, message: "unreached" }),
    });

    export const unknown_ref = testCell({
      kind: "specification",
      subject: "revenue.by_month",
      inputs: { orders: "ghost_sheet.rows" },
      expect: ({ result }) => expectEqual(result, 40),
    });
  `
};
function makeEngine() {
  return _engine.Engine.fromSources(SOURCES, stdlib);
}
function externals() {
  return {
    'feeds.orders': {
      value: liveOrders,
      tier: 'live'
    },
    'params.region': {
      value: 'all',
      tier: 'static'
    },
    'fixtures.orders_holdout': {
      value: holdoutOrders,
      tier: 'static'
    }
  };
}
(0, _vitest.describe)('Engine.runTests — fixture substitution (§6)', () => {
  (0, _vitest.it)('a declaring test runs the subject over its inputs; the live value is untouched', () => {
    const engine = makeEngine();
    engine.run(externals());
    // live: 100 + 50 + 40 = 190; substituted: 30 + 10 = 40 — the expect asserts 40 and passes
    (0, _vitest.expect)(engine.value('revenue.by_month')).toBe(190);

    // outcomes preserve declaration order: holdout_check, wrong_name, unknown_ref
    const outcomes = engine.runTests().get('revenue.by_month').outcomes;
    (0, _vitest.expect)(outcomes[0].result.pass).toBe(true);
    (0, _vitest.expect)(engine.value('revenue.by_month')).toBe(190); // the published value never changed
  });
  (0, _vitest.it)('partial substitution keeps the un-substituted inputs live', () => {
    const sources = {
      revenue: `
        import { cell, testCell, expectEqual } from "@reckoner/stdlib";
        export const total = cell({
          doc: "revenue total",
          inputs: { orders: "feeds.orders", tax: "params.tax" },
          formula: ({ orders, tax }) => orders.reduce((a, r) => a + r.eur, 0) * tax,
        });
        export const check = testCell({
          kind: "specification",
          subject: "revenue.total",
          inputs: { orders: "fixtures.orders_holdout" },
          expect: ({ result }) => expectEqual(result, 80), // 40 (fixture) × 2 (live tax)
        });
      `
    };
    const engine = _engine.Engine.fromSources(sources, stdlib);
    engine.run({
      'feeds.orders': {
        value: liveOrders,
        tier: 'live'
      },
      'params.tax': {
        value: 2,
        tier: 'static'
      },
      'fixtures.orders_holdout': {
        value: holdoutOrders,
        tier: 'static'
      }
    });
    const verdicts = engine.runTests();
    const outcome = verdicts.get('revenue.total').outcomes[0];
    (0, _vitest.expect)(outcome.result.pass).toBe(true);
  });
  (0, _vitest.it)('a name the subject does not declare is auxiliary: expect sees it, the formula does not', () => {
    const engine = makeEngine();
    engine.run(externals());
    const outcomes = engine.runTests().get('revenue.by_month').outcomes;
    const wrong = outcomes.find(o => o.result.message?.includes('never fed the formula'));
    (0, _vitest.expect)(wrong).toBeDefined();
    (0, _vitest.expect)(wrong.result.pass).toBe(true); // the live value (190) proves no substitution happened
  });
  (0, _vitest.it)('an absent external fails the test loudly, never a silent null', () => {
    const engine = makeEngine();
    engine.run(externals());
    const outcomes = engine.runTests().get('revenue.by_month').outcomes;
    const absent = outcomes.find(o => o.result.message?.includes('fixtures.no_such_fixture'));
    (0, _vitest.expect)(absent).toBeDefined();
    (0, _vitest.expect)(absent.result.pass).toBe(false);
    (0, _vitest.expect)(absent.result.message).toContain('absent external');
  });
  (0, _vitest.it)('an unresolvable test-input reference fails the test with the build-style diagnostic', () => {
    const engine = makeEngine();
    engine.run(externals());
    const outcomes = engine.runTests().get('revenue.by_month').outcomes;
    const unknown = outcomes.find(o => o.result.message?.includes('unknown cell'));
    (0, _vitest.expect)(unknown).toBeDefined();
    (0, _vitest.expect)(unknown.result.pass).toBe(false);
  });
  (0, _vitest.it)('a subject error over the substituted inputs is a failing test, not a crashed suite', () => {
    const sources = {
      revenue: `
        import { cell, testCell, expectEqual } from "@reckoner/stdlib";
        export const shout = cell({
          doc: "uppercases the input",
          inputs: { name: "params.name" },
          formula: ({ name }) => name.toUpperCase(),
        });
        export const check = testCell({
          kind: "specification",
          subject: "revenue.shout",
          inputs: { name: "fixtures.numeric" },
          expect: ({ result }) => expectEqual(result, "X"),
        });
      `
    };
    const engine = _engine.Engine.fromSources(sources, stdlib);
    engine.run({
      'params.name': {
        value: 'ada',
        tier: 'static'
      },
      'fixtures.numeric': {
        value: 7,
        tier: 'static'
      }
    });
    const outcome = engine.runTests().get('revenue.shout').outcomes[0];
    (0, _vitest.expect)(outcome.result.pass).toBe(false);
    (0, _vitest.expect)(outcome.result.message).toContain('subject errored over substituted inputs');
    // and the whole suite map still settles with a verdict
    (0, _vitest.expect)(engine.runTests().get('revenue.shout').verdict).toBe('failing');
  });
  (0, _vitest.it)('a metamorphic relation rides the substituted base (transform of the fixture, not the live feed)', () => {
    const sources = {
      revenue: `
        import { cell, testCell, permutationInvariance } from "@reckoner/stdlib";
        export const total = cell({
          doc: "sum of eur",
          inputs: { orders: "feeds.orders" },
          formula: ({ orders }) => orders.reduce((a, r) => a + r.eur, 0),
        });
        export const permuted = testCell({
          kind: "metamorphic",
          subject: "revenue.total",
          inputs: { orders: "fixtures.orders_holdout" },
          relation: permutationInvariance({ over: "orders" }),
        });
      `
    };
    const engine = _engine.Engine.fromSources(sources, stdlib);
    engine.run({
      'feeds.orders': {
        value: liveOrders,
        tier: 'live'
      },
      'fixtures.orders_holdout': {
        value: holdoutOrders,
        tier: 'static'
      }
    });
    const suite = engine.runTests().get('revenue.total');
    (0, _vitest.expect)(suite.outcomes[0].result.pass).toBe(true);
    (0, _vitest.expect)(suite.verdict).toBe('validated');
  });
  (0, _vitest.it)('a test with no declared inputs still asserts over the live subject value', () => {
    const sources = {
      revenue: `
        import { cell, testCell, expectEqual } from "@reckoner/stdlib";
        export const total = cell({
          doc: "sum",
          inputs: { orders: "feeds.orders" },
          formula: ({ orders }) => orders.reduce((a, r) => a + r.eur, 0),
        });
        export const live_check = testCell({
          kind: "characterization",
          subject: "revenue.total",
          expect: ({ result }) => expectEqual(result, 190),
        });
      `
    };
    const engine = _engine.Engine.fromSources(sources, stdlib);
    engine.run({
      'feeds.orders': {
        value: liveOrders,
        tier: 'live'
      }
    });
    const suite = engine.runTests().get('revenue.total');
    (0, _vitest.expect)(suite.outcomes[0].result.pass).toBe(true);
    (0, _vitest.expect)(suite.verdict).toBe('pinned'); // example-based only, per §6
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsInN0ZGxpYiIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX2VuZ2luZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsImxpdmVPcmRlcnMiLCJtb250aCIsImV1ciIsImhvbGRvdXRPcmRlcnMiLCJTT1VSQ0VTIiwicmV2ZW51ZSIsIm1ha2VFbmdpbmUiLCJFbmdpbmUiLCJmcm9tU291cmNlcyIsImV4dGVybmFscyIsInZhbHVlIiwidGllciIsImRlc2NyaWJlIiwiaXQiLCJlbmdpbmUiLCJydW4iLCJleHBlY3QiLCJ0b0JlIiwib3V0Y29tZXMiLCJydW5UZXN0cyIsInJlc3VsdCIsInBhc3MiLCJzb3VyY2VzIiwidmVyZGljdHMiLCJvdXRjb21lIiwid3JvbmciLCJmaW5kIiwibyIsIm1lc3NhZ2UiLCJpbmNsdWRlcyIsInRvQmVEZWZpbmVkIiwiYWJzZW50IiwidG9Db250YWluIiwidW5rbm93biIsInZlcmRpY3QiLCJzdWl0ZSJdLCJzb3VyY2VzIjpbInN1YnN0aXR1dGlvbi50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRlc3QtaW5wdXQgcmVzb2x1dGlvbiArIHRoZSB0d28gbGFuZXMgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnNiwgUjMtMzczKS4gQSB0ZXN0J3MgZGVjbGFyZWRcbi8vIGlucHV0cyByZXNvbHZlIGFnYWluc3QgdGhlIHNhbWUgcHVibGlzaGVkIHN0YXRlIGEgY2VsbCdzIGRvLCB0aGVuIHNwbGl0IGJ5IGxvY2FsIG5hbWU6XG4vLyBuYW1lLW1hdGNoZWQgZW50cmllcyBTVUJTVElUVVRlICh0aGUgc3ViamVjdCBmb3JtdWxhIHJlLXJ1bnMgb3ZlciBgeyAuLi5saXZlLCAuLi5zdWIgfWA7XG4vLyB0aGUgaG9sZG91dCBzaGFwZSksIG5hbWUtdW5tYXRjaGVkIGVudHJpZXMgYXJlIEFVWElMSUFSWSBjb250ZXh0IGZvciBgZXhwZWN0YC9gcmVsYXRpb25gXG4vLyBvbmx5IChhbiBvcmFjbGUgZml4dHVyZSkgYW5kIG5ldmVyIGZlZWQgdGhlIGZvcm11bGEuIEF1dGhvcmluZyBlcnJvcnMg4oCUIGFuIHVucmVzb2x2YWJsZVxuLy8gcmVmZXJlbmNlLCBhbiBhYnNlbnQgZXh0ZXJuYWwsIGEgc3ViamVjdCBlcnJvciBvdmVyIHRoZSBmaXh0dXJlIOKAlCBmYWlsIHRoZSB0ZXN0IHdpdGggYVxuLy8gbWVzc2FnZSwgbmV2ZXIgYSBzaWxlbnQgbnVsbC4gVGhlIHN1YmplY3QncyBwdWJsaXNoZWQgbGl2ZSB2YWx1ZSBpcyB1bnRvdWNoZWQgZWl0aGVyIHdheS5cblxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0ICogYXMgc3RkbGliIGZyb20gJy4uL3N0ZGxpYi9pbmRleC50cyc7XG5pbXBvcnQgdHlwZSB7IFJvdyB9IGZyb20gJy4uL3N0ZGxpYi90eXBlcy50cyc7XG5pbXBvcnQgdHlwZSB7IEV4dGVybmFsVmFsdWUgfSBmcm9tICcuL3R5cGVzLnRzJztcbmltcG9ydCB7IEVuZ2luZSB9IGZyb20gJy4vZW5naW5lLnRzJztcblxuY29uc3QgbGl2ZU9yZGVyczogUm93W10gPSBbXG4gIHsgbW9udGg6ICcyMDI2LTAxJywgZXVyOiAxMDAgfSxcbiAgeyBtb250aDogJzIwMjYtMDInLCBldXI6IDUwIH0sXG4gIHsgbW9udGg6ICcyMDI2LTAxJywgZXVyOiA0MCB9LFxuXTtcblxuY29uc3QgaG9sZG91dE9yZGVyczogUm93W10gPSBbXG4gIHsgbW9udGg6ICcyMDI2LTAxJywgZXVyOiAzMCB9LFxuICB7IG1vbnRoOiAnMjAyNi0wMicsIGV1cjogMTAgfSxcbl07XG5cbmNvbnN0IFNPVVJDRVM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIHJldmVudWU6IGBcbiAgICBpbXBvcnQgeyBjZWxsLCB0ZXN0Q2VsbCwgZXhwZWN0RXF1YWwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG4gICAgZXhwb3J0IGNvbnN0IGJ5X21vbnRoID0gY2VsbCh7XG4gICAgICBkb2M6IFwicmV2ZW51ZSBieSBtb250aCBmb3IgYSByZWdpb25cIixcbiAgICAgIGlucHV0czogeyBvcmRlcnM6IFwiZmVlZHMub3JkZXJzXCIsIHJlZ2lvbjogXCJwYXJhbXMucmVnaW9uXCIgfSxcbiAgICAgIGZvcm11bGE6ICh7IG9yZGVycywgcmVnaW9uIH0pID0+XG4gICAgICAgIG9yZGVyc1xuICAgICAgICAgIC5maWx0ZXIoKHIpID0+IHJlZ2lvbiA9PT0gXCJhbGxcIiB8fCByLnJlZ2lvbiA9PT0gcmVnaW9uKVxuICAgICAgICAgIC5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLmV1ciwgMCksXG4gICAgfSk7XG5cbiAgICBleHBvcnQgY29uc3QgaG9sZG91dF9jaGVjayA9IHRlc3RDZWxsKHtcbiAgICAgIGtpbmQ6IFwic3BlY2lmaWNhdGlvblwiLFxuICAgICAgc3ViamVjdDogXCJyZXZlbnVlLmJ5X21vbnRoXCIsXG4gICAgICBpbnB1dHM6IHsgb3JkZXJzOiBcImZpeHR1cmVzLm9yZGVyc19ob2xkb3V0XCIgfSxcbiAgICAgIGV4cGVjdDogKHsgcmVzdWx0IH0pID0+IGV4cGVjdEVxdWFsKHJlc3VsdCwgNDApLFxuICAgIH0pO1xuXG4gICAgZXhwb3J0IGNvbnN0IHdyb25nX25hbWUgPSB0ZXN0Q2VsbCh7XG4gICAgICBraW5kOiBcInNwZWNpZmljYXRpb25cIixcbiAgICAgIHN1YmplY3Q6IFwicmV2ZW51ZS5ieV9tb250aFwiLFxuICAgICAgaW5wdXRzOiB7IG9yZGVyejogXCJmaXh0dXJlcy5vcmRlcnNfaG9sZG91dFwiIH0sXG4gICAgICBleHBlY3Q6ICh7IHJlc3VsdCwgaW5wdXRzIH0pID0+XG4gICAgICAgIHJlc3VsdCA9PT0gMTkwICYmIGlucHV0cy5vcmRlcnoubGVuZ3RoID09PSAyXG4gICAgICAgICAgPyB7IHBhc3M6IHRydWUsIG1lc3NhZ2U6IFwibGl2ZSBzdWJqZWN0ICsgYXV4aWxpYXJ5IGZpeHR1cmUgYm90aCB2aXNpYmxlOyB0aGUgdW5tYXRjaGVkIG5hbWUgbmV2ZXIgZmVkIHRoZSBmb3JtdWxhXCIgfVxuICAgICAgICAgIDogeyBwYXNzOiBmYWxzZSwgbWVzc2FnZTogXCJyZXN1bHQgXCIgKyByZXN1bHQgKyBcIiwgYXV4IHJvd3MgXCIgKyAoaW5wdXRzLm9yZGVyeiAmJiBpbnB1dHMub3JkZXJ6Lmxlbmd0aCkgfSxcbiAgICB9KTtcblxuICAgIGV4cG9ydCBjb25zdCBhYnNlbnRfZml4dHVyZSA9IHRlc3RDZWxsKHtcbiAgICAgIGtpbmQ6IFwic3BlY2lmaWNhdGlvblwiLFxuICAgICAgc3ViamVjdDogXCJyZXZlbnVlLmJ5X21vbnRoXCIsXG4gICAgICBpbnB1dHM6IHsgZ2hvc3Q6IFwiZml4dHVyZXMubm9fc3VjaF9maXh0dXJlXCIgfSxcbiAgICAgIGV4cGVjdDogKCkgPT4gKHsgcGFzczogdHJ1ZSwgbWVzc2FnZTogXCJ1bnJlYWNoZWRcIiB9KSxcbiAgICB9KTtcblxuICAgIGV4cG9ydCBjb25zdCB1bmtub3duX3JlZiA9IHRlc3RDZWxsKHtcbiAgICAgIGtpbmQ6IFwic3BlY2lmaWNhdGlvblwiLFxuICAgICAgc3ViamVjdDogXCJyZXZlbnVlLmJ5X21vbnRoXCIsXG4gICAgICBpbnB1dHM6IHsgb3JkZXJzOiBcImdob3N0X3NoZWV0LnJvd3NcIiB9LFxuICAgICAgZXhwZWN0OiAoeyByZXN1bHQgfSkgPT4gZXhwZWN0RXF1YWwocmVzdWx0LCA0MCksXG4gICAgfSk7XG4gIGAsXG59O1xuXG5mdW5jdGlvbiBtYWtlRW5naW5lKCk6IEVuZ2luZSB7XG4gIHJldHVybiBFbmdpbmUuZnJvbVNvdXJjZXMoU09VUkNFUywgc3RkbGliKTtcbn1cblxuZnVuY3Rpb24gZXh0ZXJuYWxzKCk6IFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+IHtcbiAgcmV0dXJuIHtcbiAgICAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogbGl2ZU9yZGVycywgdGllcjogJ2xpdmUnIH0sXG4gICAgJ3BhcmFtcy5yZWdpb24nOiB7IHZhbHVlOiAnYWxsJywgdGllcjogJ3N0YXRpYycgfSxcbiAgICAnZml4dHVyZXMub3JkZXJzX2hvbGRvdXQnOiB7IHZhbHVlOiBob2xkb3V0T3JkZXJzLCB0aWVyOiAnc3RhdGljJyB9LFxuICB9O1xufVxuXG5kZXNjcmliZSgnRW5naW5lLnJ1blRlc3RzIOKAlCBmaXh0dXJlIHN1YnN0aXR1dGlvbiAowqc2KScsICgpID0+IHtcbiAgaXQoJ2EgZGVjbGFyaW5nIHRlc3QgcnVucyB0aGUgc3ViamVjdCBvdmVyIGl0cyBpbnB1dHM7IHRoZSBsaXZlIHZhbHVlIGlzIHVudG91Y2hlZCcsICgpID0+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBtYWtlRW5naW5lKCk7XG4gICAgZW5naW5lLnJ1bihleHRlcm5hbHMoKSk7XG4gICAgLy8gbGl2ZTogMTAwICsgNTAgKyA0MCA9IDE5MDsgc3Vic3RpdHV0ZWQ6IDMwICsgMTAgPSA0MCDigJQgdGhlIGV4cGVjdCBhc3NlcnRzIDQwIGFuZCBwYXNzZXNcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdyZXZlbnVlLmJ5X21vbnRoJykpLnRvQmUoMTkwKTtcblxuICAgIC8vIG91dGNvbWVzIHByZXNlcnZlIGRlY2xhcmF0aW9uIG9yZGVyOiBob2xkb3V0X2NoZWNrLCB3cm9uZ19uYW1lLCB1bmtub3duX3JlZlxuICAgIGNvbnN0IG91dGNvbWVzID0gZW5naW5lLnJ1blRlc3RzKCkuZ2V0KCdyZXZlbnVlLmJ5X21vbnRoJykhLm91dGNvbWVzO1xuICAgIGV4cGVjdChvdXRjb21lc1swXS5yZXN1bHQucGFzcykudG9CZSh0cnVlKTtcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdyZXZlbnVlLmJ5X21vbnRoJykpLnRvQmUoMTkwKTsgLy8gdGhlIHB1Ymxpc2hlZCB2YWx1ZSBuZXZlciBjaGFuZ2VkXG4gIH0pO1xuXG4gIGl0KCdwYXJ0aWFsIHN1YnN0aXR1dGlvbiBrZWVwcyB0aGUgdW4tc3Vic3RpdHV0ZWQgaW5wdXRzIGxpdmUnLCAoKSA9PiB7XG4gICAgY29uc3Qgc291cmNlcyA9IHtcbiAgICAgIHJldmVudWU6IGBcbiAgICAgICAgaW1wb3J0IHsgY2VsbCwgdGVzdENlbGwsIGV4cGVjdEVxdWFsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbiAgICAgICAgZXhwb3J0IGNvbnN0IHRvdGFsID0gY2VsbCh7XG4gICAgICAgICAgZG9jOiBcInJldmVudWUgdG90YWxcIixcbiAgICAgICAgICBpbnB1dHM6IHsgb3JkZXJzOiBcImZlZWRzLm9yZGVyc1wiLCB0YXg6IFwicGFyYW1zLnRheFwiIH0sXG4gICAgICAgICAgZm9ybXVsYTogKHsgb3JkZXJzLCB0YXggfSkgPT4gb3JkZXJzLnJlZHVjZSgoYSwgcikgPT4gYSArIHIuZXVyLCAwKSAqIHRheCxcbiAgICAgICAgfSk7XG4gICAgICAgIGV4cG9ydCBjb25zdCBjaGVjayA9IHRlc3RDZWxsKHtcbiAgICAgICAgICBraW5kOiBcInNwZWNpZmljYXRpb25cIixcbiAgICAgICAgICBzdWJqZWN0OiBcInJldmVudWUudG90YWxcIixcbiAgICAgICAgICBpbnB1dHM6IHsgb3JkZXJzOiBcImZpeHR1cmVzLm9yZGVyc19ob2xkb3V0XCIgfSxcbiAgICAgICAgICBleHBlY3Q6ICh7IHJlc3VsdCB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIDgwKSwgLy8gNDAgKGZpeHR1cmUpIMOXIDIgKGxpdmUgdGF4KVxuICAgICAgICB9KTtcbiAgICAgIGAsXG4gICAgfTtcbiAgICBjb25zdCBlbmdpbmUgPSBFbmdpbmUuZnJvbVNvdXJjZXMoc291cmNlcywgc3RkbGliKTtcbiAgICBlbmdpbmUucnVuKHtcbiAgICAgICdmZWVkcy5vcmRlcnMnOiB7IHZhbHVlOiBsaXZlT3JkZXJzLCB0aWVyOiAnbGl2ZScgfSxcbiAgICAgICdwYXJhbXMudGF4JzogeyB2YWx1ZTogMiwgdGllcjogJ3N0YXRpYycgfSxcbiAgICAgICdmaXh0dXJlcy5vcmRlcnNfaG9sZG91dCc6IHsgdmFsdWU6IGhvbGRvdXRPcmRlcnMsIHRpZXI6ICdzdGF0aWMnIH0sXG4gICAgfSk7XG4gICAgY29uc3QgdmVyZGljdHMgPSBlbmdpbmUucnVuVGVzdHMoKTtcbiAgICBjb25zdCBvdXRjb21lID0gdmVyZGljdHMuZ2V0KCdyZXZlbnVlLnRvdGFsJykhLm91dGNvbWVzWzBdO1xuICAgIGV4cGVjdChvdXRjb21lLnJlc3VsdC5wYXNzKS50b0JlKHRydWUpO1xuICB9KTtcblxuICBpdCgnYSBuYW1lIHRoZSBzdWJqZWN0IGRvZXMgbm90IGRlY2xhcmUgaXMgYXV4aWxpYXJ5OiBleHBlY3Qgc2VlcyBpdCwgdGhlIGZvcm11bGEgZG9lcyBub3QnLCAoKSA9PiB7XG4gICAgY29uc3QgZW5naW5lID0gbWFrZUVuZ2luZSgpO1xuICAgIGVuZ2luZS5ydW4oZXh0ZXJuYWxzKCkpO1xuICAgIGNvbnN0IG91dGNvbWVzID0gZW5naW5lLnJ1blRlc3RzKCkuZ2V0KCdyZXZlbnVlLmJ5X21vbnRoJykhLm91dGNvbWVzO1xuICAgIGNvbnN0IHdyb25nID0gb3V0Y29tZXMuZmluZCgobykgPT4gby5yZXN1bHQubWVzc2FnZT8uaW5jbHVkZXMoJ25ldmVyIGZlZCB0aGUgZm9ybXVsYScpKTtcbiAgICBleHBlY3Qod3JvbmcpLnRvQmVEZWZpbmVkKCk7XG4gICAgZXhwZWN0KHdyb25nIS5yZXN1bHQucGFzcykudG9CZSh0cnVlKTsgLy8gdGhlIGxpdmUgdmFsdWUgKDE5MCkgcHJvdmVzIG5vIHN1YnN0aXR1dGlvbiBoYXBwZW5lZFxuICB9KTtcblxuICBpdCgnYW4gYWJzZW50IGV4dGVybmFsIGZhaWxzIHRoZSB0ZXN0IGxvdWRseSwgbmV2ZXIgYSBzaWxlbnQgbnVsbCcsICgpID0+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBtYWtlRW5naW5lKCk7XG4gICAgZW5naW5lLnJ1bihleHRlcm5hbHMoKSk7XG4gICAgY29uc3Qgb3V0Y29tZXMgPSBlbmdpbmUucnVuVGVzdHMoKS5nZXQoJ3JldmVudWUuYnlfbW9udGgnKSEub3V0Y29tZXM7XG4gICAgY29uc3QgYWJzZW50ID0gb3V0Y29tZXMuZmluZCgobykgPT4gby5yZXN1bHQubWVzc2FnZT8uaW5jbHVkZXMoJ2ZpeHR1cmVzLm5vX3N1Y2hfZml4dHVyZScpKTtcbiAgICBleHBlY3QoYWJzZW50KS50b0JlRGVmaW5lZCgpO1xuICAgIGV4cGVjdChhYnNlbnQhLnJlc3VsdC5wYXNzKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3QoYWJzZW50IS5yZXN1bHQubWVzc2FnZSkudG9Db250YWluKCdhYnNlbnQgZXh0ZXJuYWwnKTtcbiAgfSk7XG5cbiAgaXQoJ2FuIHVucmVzb2x2YWJsZSB0ZXN0LWlucHV0IHJlZmVyZW5jZSBmYWlscyB0aGUgdGVzdCB3aXRoIHRoZSBidWlsZC1zdHlsZSBkaWFnbm9zdGljJywgKCkgPT4ge1xuICAgIGNvbnN0IGVuZ2luZSA9IG1ha2VFbmdpbmUoKTtcbiAgICBlbmdpbmUucnVuKGV4dGVybmFscygpKTtcbiAgICBjb25zdCBvdXRjb21lcyA9IGVuZ2luZS5ydW5UZXN0cygpLmdldCgncmV2ZW51ZS5ieV9tb250aCcpIS5vdXRjb21lcztcbiAgICBjb25zdCB1bmtub3duID0gb3V0Y29tZXMuZmluZCgobykgPT4gby5yZXN1bHQubWVzc2FnZT8uaW5jbHVkZXMoJ3Vua25vd24gY2VsbCcpKTtcbiAgICBleHBlY3QodW5rbm93bikudG9CZURlZmluZWQoKTtcbiAgICBleHBlY3QodW5rbm93biEucmVzdWx0LnBhc3MpLnRvQmUoZmFsc2UpO1xuICB9KTtcblxuICBpdCgnYSBzdWJqZWN0IGVycm9yIG92ZXIgdGhlIHN1YnN0aXR1dGVkIGlucHV0cyBpcyBhIGZhaWxpbmcgdGVzdCwgbm90IGEgY3Jhc2hlZCBzdWl0ZScsICgpID0+IHtcbiAgICBjb25zdCBzb3VyY2VzID0ge1xuICAgICAgcmV2ZW51ZTogYFxuICAgICAgICBpbXBvcnQgeyBjZWxsLCB0ZXN0Q2VsbCwgZXhwZWN0RXF1YWwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuICAgICAgICBleHBvcnQgY29uc3Qgc2hvdXQgPSBjZWxsKHtcbiAgICAgICAgICBkb2M6IFwidXBwZXJjYXNlcyB0aGUgaW5wdXRcIixcbiAgICAgICAgICBpbnB1dHM6IHsgbmFtZTogXCJwYXJhbXMubmFtZVwiIH0sXG4gICAgICAgICAgZm9ybXVsYTogKHsgbmFtZSB9KSA9PiBuYW1lLnRvVXBwZXJDYXNlKCksXG4gICAgICAgIH0pO1xuICAgICAgICBleHBvcnQgY29uc3QgY2hlY2sgPSB0ZXN0Q2VsbCh7XG4gICAgICAgICAga2luZDogXCJzcGVjaWZpY2F0aW9uXCIsXG4gICAgICAgICAgc3ViamVjdDogXCJyZXZlbnVlLnNob3V0XCIsXG4gICAgICAgICAgaW5wdXRzOiB7IG5hbWU6IFwiZml4dHVyZXMubnVtZXJpY1wiIH0sXG4gICAgICAgICAgZXhwZWN0OiAoeyByZXN1bHQgfSkgPT4gZXhwZWN0RXF1YWwocmVzdWx0LCBcIlhcIiksXG4gICAgICAgIH0pO1xuICAgICAgYCxcbiAgICB9O1xuICAgIGNvbnN0IGVuZ2luZSA9IEVuZ2luZS5mcm9tU291cmNlcyhzb3VyY2VzLCBzdGRsaWIpO1xuICAgIGVuZ2luZS5ydW4oeyAncGFyYW1zLm5hbWUnOiB7IHZhbHVlOiAnYWRhJywgdGllcjogJ3N0YXRpYycgfSwgJ2ZpeHR1cmVzLm51bWVyaWMnOiB7IHZhbHVlOiA3LCB0aWVyOiAnc3RhdGljJyB9IH0pO1xuICAgIGNvbnN0IG91dGNvbWUgPSBlbmdpbmUucnVuVGVzdHMoKS5nZXQoJ3JldmVudWUuc2hvdXQnKSEub3V0Y29tZXNbMF07XG4gICAgZXhwZWN0KG91dGNvbWUucmVzdWx0LnBhc3MpLnRvQmUoZmFsc2UpO1xuICAgIGV4cGVjdChvdXRjb21lLnJlc3VsdC5tZXNzYWdlKS50b0NvbnRhaW4oJ3N1YmplY3QgZXJyb3JlZCBvdmVyIHN1YnN0aXR1dGVkIGlucHV0cycpO1xuICAgIC8vIGFuZCB0aGUgd2hvbGUgc3VpdGUgbWFwIHN0aWxsIHNldHRsZXMgd2l0aCBhIHZlcmRpY3RcbiAgICBleHBlY3QoZW5naW5lLnJ1blRlc3RzKCkuZ2V0KCdyZXZlbnVlLnNob3V0JykhLnZlcmRpY3QpLnRvQmUoJ2ZhaWxpbmcnKTtcbiAgfSk7XG5cbiAgaXQoJ2EgbWV0YW1vcnBoaWMgcmVsYXRpb24gcmlkZXMgdGhlIHN1YnN0aXR1dGVkIGJhc2UgKHRyYW5zZm9ybSBvZiB0aGUgZml4dHVyZSwgbm90IHRoZSBsaXZlIGZlZWQpJywgKCkgPT4ge1xuICAgIGNvbnN0IHNvdXJjZXMgPSB7XG4gICAgICByZXZlbnVlOiBgXG4gICAgICAgIGltcG9ydCB7IGNlbGwsIHRlc3RDZWxsLCBwZXJtdXRhdGlvbkludmFyaWFuY2UgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuICAgICAgICBleHBvcnQgY29uc3QgdG90YWwgPSBjZWxsKHtcbiAgICAgICAgICBkb2M6IFwic3VtIG9mIGV1clwiLFxuICAgICAgICAgIGlucHV0czogeyBvcmRlcnM6IFwiZmVlZHMub3JkZXJzXCIgfSxcbiAgICAgICAgICBmb3JtdWxhOiAoeyBvcmRlcnMgfSkgPT4gb3JkZXJzLnJlZHVjZSgoYSwgcikgPT4gYSArIHIuZXVyLCAwKSxcbiAgICAgICAgfSk7XG4gICAgICAgIGV4cG9ydCBjb25zdCBwZXJtdXRlZCA9IHRlc3RDZWxsKHtcbiAgICAgICAgICBraW5kOiBcIm1ldGFtb3JwaGljXCIsXG4gICAgICAgICAgc3ViamVjdDogXCJyZXZlbnVlLnRvdGFsXCIsXG4gICAgICAgICAgaW5wdXRzOiB7IG9yZGVyczogXCJmaXh0dXJlcy5vcmRlcnNfaG9sZG91dFwiIH0sXG4gICAgICAgICAgcmVsYXRpb246IHBlcm11dGF0aW9uSW52YXJpYW5jZSh7IG92ZXI6IFwib3JkZXJzXCIgfSksXG4gICAgICAgIH0pO1xuICAgICAgYCxcbiAgICB9O1xuICAgIGNvbnN0IGVuZ2luZSA9IEVuZ2luZS5mcm9tU291cmNlcyhzb3VyY2VzLCBzdGRsaWIpO1xuICAgIGVuZ2luZS5ydW4oe1xuICAgICAgJ2ZlZWRzLm9yZGVycyc6IHsgdmFsdWU6IGxpdmVPcmRlcnMsIHRpZXI6ICdsaXZlJyB9LFxuICAgICAgJ2ZpeHR1cmVzLm9yZGVyc19ob2xkb3V0JzogeyB2YWx1ZTogaG9sZG91dE9yZGVycywgdGllcjogJ3N0YXRpYycgfSxcbiAgICB9KTtcbiAgICBjb25zdCBzdWl0ZSA9IGVuZ2luZS5ydW5UZXN0cygpLmdldCgncmV2ZW51ZS50b3RhbCcpITtcbiAgICBleHBlY3Qoc3VpdGUub3V0Y29tZXNbMF0ucmVzdWx0LnBhc3MpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHN1aXRlLnZlcmRpY3QpLnRvQmUoJ3ZhbGlkYXRlZCcpO1xuICB9KTtcblxuICBpdCgnYSB0ZXN0IHdpdGggbm8gZGVjbGFyZWQgaW5wdXRzIHN0aWxsIGFzc2VydHMgb3ZlciB0aGUgbGl2ZSBzdWJqZWN0IHZhbHVlJywgKCkgPT4ge1xuICAgIGNvbnN0IHNvdXJjZXMgPSB7XG4gICAgICByZXZlbnVlOiBgXG4gICAgICAgIGltcG9ydCB7IGNlbGwsIHRlc3RDZWxsLCBleHBlY3RFcXVhbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG4gICAgICAgIGV4cG9ydCBjb25zdCB0b3RhbCA9IGNlbGwoe1xuICAgICAgICAgIGRvYzogXCJzdW1cIixcbiAgICAgICAgICBpbnB1dHM6IHsgb3JkZXJzOiBcImZlZWRzLm9yZGVyc1wiIH0sXG4gICAgICAgICAgZm9ybXVsYTogKHsgb3JkZXJzIH0pID0+IG9yZGVycy5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLmV1ciwgMCksXG4gICAgICAgIH0pO1xuICAgICAgICBleHBvcnQgY29uc3QgbGl2ZV9jaGVjayA9IHRlc3RDZWxsKHtcbiAgICAgICAgICBraW5kOiBcImNoYXJhY3Rlcml6YXRpb25cIixcbiAgICAgICAgICBzdWJqZWN0OiBcInJldmVudWUudG90YWxcIixcbiAgICAgICAgICBleHBlY3Q6ICh7IHJlc3VsdCB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIDE5MCksXG4gICAgICAgIH0pO1xuICAgICAgYCxcbiAgICB9O1xuICAgIGNvbnN0IGVuZ2luZSA9IEVuZ2luZS5mcm9tU291cmNlcyhzb3VyY2VzLCBzdGRsaWIpO1xuICAgIGVuZ2luZS5ydW4oeyAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogbGl2ZU9yZGVycywgdGllcjogJ2xpdmUnIH0gfSk7XG4gICAgY29uc3Qgc3VpdGUgPSBlbmdpbmUucnVuVGVzdHMoKS5nZXQoJ3JldmVudWUudG90YWwnKSE7XG4gICAgZXhwZWN0KHN1aXRlLm91dGNvbWVzWzBdLnJlc3VsdC5wYXNzKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChzdWl0ZS52ZXJkaWN0KS50b0JlKCdwaW5uZWQnKTsgLy8gZXhhbXBsZS1iYXNlZCBvbmx5LCBwZXIgwqc2XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFRQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFDLHVCQUFBLENBQUFGLE9BQUE7QUFHQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFBcUMsU0FBQUkseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUgsd0JBQUFHLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxVQUFBLFNBQUFKLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBSyxPQUFBLEVBQUFMLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBRyxHQUFBLENBQUFOLENBQUEsVUFBQUcsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsT0FBQVEsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZCxDQUFBLG9CQUFBYyxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBaEIsQ0FBQSxFQUFBYyxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFiLENBQUEsRUFBQWMsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZCxDQUFBLENBQUFjLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFMLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFlLEdBQUEsQ0FBQWxCLENBQUEsRUFBQVEsQ0FBQSxHQUFBQSxDQUFBO0FBWnJDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVFBLE1BQU1XLFVBQWlCLEdBQUcsQ0FDeEI7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRUMsR0FBRyxFQUFFO0FBQUksQ0FBQyxFQUM5QjtFQUFFRCxLQUFLLEVBQUUsU0FBUztFQUFFQyxHQUFHLEVBQUU7QUFBRyxDQUFDLEVBQzdCO0VBQUVELEtBQUssRUFBRSxTQUFTO0VBQUVDLEdBQUcsRUFBRTtBQUFHLENBQUMsQ0FDOUI7QUFFRCxNQUFNQyxhQUFvQixHQUFHLENBQzNCO0VBQUVGLEtBQUssRUFBRSxTQUFTO0VBQUVDLEdBQUcsRUFBRTtBQUFHLENBQUMsRUFDN0I7RUFBRUQsS0FBSyxFQUFFLFNBQVM7RUFBRUMsR0FBRyxFQUFFO0FBQUcsQ0FBQyxDQUM5QjtBQUVELE1BQU1FLE9BQStCLEdBQUc7RUFDdENDLE9BQU8sRUFBRTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFFRCxTQUFTQyxVQUFVQSxDQUFBLEVBQVc7RUFDNUIsT0FBT0MsY0FBTSxDQUFDQyxXQUFXLENBQUNKLE9BQU8sRUFBRTNCLE1BQU0sQ0FBQztBQUM1QztBQUVBLFNBQVNnQyxTQUFTQSxDQUFBLEVBQWtDO0VBQ2xELE9BQU87SUFDTCxjQUFjLEVBQUU7TUFBRUMsS0FBSyxFQUFFVixVQUFVO01BQUVXLElBQUksRUFBRTtJQUFPLENBQUM7SUFDbkQsZUFBZSxFQUFFO01BQUVELEtBQUssRUFBRSxLQUFLO01BQUVDLElBQUksRUFBRTtJQUFTLENBQUM7SUFDakQseUJBQXlCLEVBQUU7TUFBRUQsS0FBSyxFQUFFUCxhQUFhO01BQUVRLElBQUksRUFBRTtJQUFTO0VBQ3BFLENBQUM7QUFDSDtBQUVBLElBQUFDLGdCQUFRLEVBQUMsNkNBQTZDLEVBQUUsTUFBTTtFQUM1RCxJQUFBQyxVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsTUFBTTtJQUN6RixNQUFNQyxNQUFNLEdBQUdSLFVBQVUsQ0FBQyxDQUFDO0lBQzNCUSxNQUFNLENBQUNDLEdBQUcsQ0FBQ04sU0FBUyxDQUFDLENBQUMsQ0FBQztJQUN2QjtJQUNBLElBQUFPLGNBQU0sRUFBQ0YsTUFBTSxDQUFDSixLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDTyxJQUFJLENBQUMsR0FBRyxDQUFDOztJQUVsRDtJQUNBLE1BQU1DLFFBQVEsR0FBR0osTUFBTSxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUFDL0IsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUU4QixRQUFRO0lBQ3BFLElBQUFGLGNBQU0sRUFBQ0UsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLElBQUksQ0FBQyxDQUFDSixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFDLElBQUFELGNBQU0sRUFBQ0YsTUFBTSxDQUFDSixLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUN0RCxDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxNQUFNUyxPQUFPLEdBQUc7TUFDZGpCLE9BQU8sRUFBRTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksQ0FBQztJQUNELE1BQU1TLE1BQU0sR0FBR1AsY0FBTSxDQUFDQyxXQUFXLENBQUNjLE9BQU8sRUFBRTdDLE1BQU0sQ0FBQztJQUNsRHFDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDO01BQ1QsY0FBYyxFQUFFO1FBQUVMLEtBQUssRUFBRVYsVUFBVTtRQUFFVyxJQUFJLEVBQUU7TUFBTyxDQUFDO01BQ25ELFlBQVksRUFBRTtRQUFFRCxLQUFLLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUU7TUFBUyxDQUFDO01BQzFDLHlCQUF5QixFQUFFO1FBQUVELEtBQUssRUFBRVAsYUFBYTtRQUFFUSxJQUFJLEVBQUU7TUFBUztJQUNwRSxDQUFDLENBQUM7SUFDRixNQUFNWSxRQUFRLEdBQUdULE1BQU0sQ0FBQ0ssUUFBUSxDQUFDLENBQUM7SUFDbEMsTUFBTUssT0FBTyxHQUFHRCxRQUFRLENBQUNuQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUU4QixRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQzFELElBQUFGLGNBQU0sRUFBQ1EsT0FBTyxDQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxDQUFDSixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3hDLENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQyx3RkFBd0YsRUFBRSxNQUFNO0lBQ2pHLE1BQU1DLE1BQU0sR0FBR1IsVUFBVSxDQUFDLENBQUM7SUFDM0JRLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDTixTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1TLFFBQVEsR0FBR0osTUFBTSxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUFDL0IsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUU4QixRQUFRO0lBQ3BFLE1BQU1PLEtBQUssR0FBR1AsUUFBUSxDQUFDUSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDUCxNQUFNLENBQUNRLE9BQU8sRUFBRUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDdkYsSUFBQWIsY0FBTSxFQUFDUyxLQUFLLENBQUMsQ0FBQ0ssV0FBVyxDQUFDLENBQUM7SUFDM0IsSUFBQWQsY0FBTSxFQUFDUyxLQUFLLENBQUVMLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLENBQUNKLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ3pDLENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQywrREFBK0QsRUFBRSxNQUFNO0lBQ3hFLE1BQU1DLE1BQU0sR0FBR1IsVUFBVSxDQUFDLENBQUM7SUFDM0JRLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDTixTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1TLFFBQVEsR0FBR0osTUFBTSxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUFDL0IsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUU4QixRQUFRO0lBQ3BFLE1BQU1hLE1BQU0sR0FBR2IsUUFBUSxDQUFDUSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDUCxNQUFNLENBQUNRLE9BQU8sRUFBRUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDM0YsSUFBQWIsY0FBTSxFQUFDZSxNQUFNLENBQUMsQ0FBQ0QsV0FBVyxDQUFDLENBQUM7SUFDNUIsSUFBQWQsY0FBTSxFQUFDZSxNQUFNLENBQUVYLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLENBQUNKLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDdkMsSUFBQUQsY0FBTSxFQUFDZSxNQUFNLENBQUVYLE1BQU0sQ0FBQ1EsT0FBTyxDQUFDLENBQUNJLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQztFQUM3RCxDQUFDLENBQUM7RUFFRixJQUFBbkIsVUFBRSxFQUFDLHFGQUFxRixFQUFFLE1BQU07SUFDOUYsTUFBTUMsTUFBTSxHQUFHUixVQUFVLENBQUMsQ0FBQztJQUMzQlEsTUFBTSxDQUFDQyxHQUFHLENBQUNOLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDdkIsTUFBTVMsUUFBUSxHQUFHSixNQUFNLENBQUNLLFFBQVEsQ0FBQyxDQUFDLENBQUMvQixHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBRThCLFFBQVE7SUFDcEUsTUFBTWUsT0FBTyxHQUFHZixRQUFRLENBQUNRLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNQLE1BQU0sQ0FBQ1EsT0FBTyxFQUFFQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDaEYsSUFBQWIsY0FBTSxFQUFDaUIsT0FBTyxDQUFDLENBQUNILFdBQVcsQ0FBQyxDQUFDO0lBQzdCLElBQUFkLGNBQU0sRUFBQ2lCLE9BQU8sQ0FBRWIsTUFBTSxDQUFDQyxJQUFJLENBQUMsQ0FBQ0osSUFBSSxDQUFDLEtBQUssQ0FBQztFQUMxQyxDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsb0ZBQW9GLEVBQUUsTUFBTTtJQUM3RixNQUFNUyxPQUFPLEdBQUc7TUFDZGpCLE9BQU8sRUFBRTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksQ0FBQztJQUNELE1BQU1TLE1BQU0sR0FBR1AsY0FBTSxDQUFDQyxXQUFXLENBQUNjLE9BQU8sRUFBRTdDLE1BQU0sQ0FBQztJQUNsRHFDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDO01BQUUsYUFBYSxFQUFFO1FBQUVMLEtBQUssRUFBRSxLQUFLO1FBQUVDLElBQUksRUFBRTtNQUFTLENBQUM7TUFBRSxrQkFBa0IsRUFBRTtRQUFFRCxLQUFLLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUU7TUFBUztJQUFFLENBQUMsQ0FBQztJQUNqSCxNQUFNYSxPQUFPLEdBQUdWLE1BQU0sQ0FBQ0ssUUFBUSxDQUFDLENBQUMsQ0FBQy9CLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBRThCLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsSUFBQUYsY0FBTSxFQUFDUSxPQUFPLENBQUNKLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLENBQUNKLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDdkMsSUFBQUQsY0FBTSxFQUFDUSxPQUFPLENBQUNKLE1BQU0sQ0FBQ1EsT0FBTyxDQUFDLENBQUNJLFNBQVMsQ0FBQyx5Q0FBeUMsQ0FBQztJQUNuRjtJQUNBLElBQUFoQixjQUFNLEVBQUNGLE1BQU0sQ0FBQ0ssUUFBUSxDQUFDLENBQUMsQ0FBQy9CLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBRThDLE9BQU8sQ0FBQyxDQUFDakIsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUN6RSxDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsaUdBQWlHLEVBQUUsTUFBTTtJQUMxRyxNQUFNUyxPQUFPLEdBQUc7TUFDZGpCLE9BQU8sRUFBRTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksQ0FBQztJQUNELE1BQU1TLE1BQU0sR0FBR1AsY0FBTSxDQUFDQyxXQUFXLENBQUNjLE9BQU8sRUFBRTdDLE1BQU0sQ0FBQztJQUNsRHFDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDO01BQ1QsY0FBYyxFQUFFO1FBQUVMLEtBQUssRUFBRVYsVUFBVTtRQUFFVyxJQUFJLEVBQUU7TUFBTyxDQUFDO01BQ25ELHlCQUF5QixFQUFFO1FBQUVELEtBQUssRUFBRVAsYUFBYTtRQUFFUSxJQUFJLEVBQUU7TUFBUztJQUNwRSxDQUFDLENBQUM7SUFDRixNQUFNd0IsS0FBSyxHQUFHckIsTUFBTSxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUFDL0IsR0FBRyxDQUFDLGVBQWUsQ0FBRTtJQUNyRCxJQUFBNEIsY0FBTSxFQUFDbUIsS0FBSyxDQUFDakIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLElBQUksQ0FBQyxDQUFDSixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2hELElBQUFELGNBQU0sRUFBQ21CLEtBQUssQ0FBQ0QsT0FBTyxDQUFDLENBQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3pDLENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0lBQ25GLE1BQU1TLE9BQU8sR0FBRztNQUNkakIsT0FBTyxFQUFFO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksQ0FBQztJQUNELE1BQU1TLE1BQU0sR0FBR1AsY0FBTSxDQUFDQyxXQUFXLENBQUNjLE9BQU8sRUFBRTdDLE1BQU0sQ0FBQztJQUNsRHFDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUVMLEtBQUssRUFBRVYsVUFBVTtRQUFFVyxJQUFJLEVBQUU7TUFBTztJQUFFLENBQUMsQ0FBQztJQUNuRSxNQUFNd0IsS0FBSyxHQUFHckIsTUFBTSxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUFDL0IsR0FBRyxDQUFDLGVBQWUsQ0FBRTtJQUNyRCxJQUFBNEIsY0FBTSxFQUFDbUIsS0FBSyxDQUFDakIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLElBQUksQ0FBQyxDQUFDSixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2hELElBQUFELGNBQU0sRUFBQ21CLEtBQUssQ0FBQ0QsT0FBTyxDQUFDLENBQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztFQUN4QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=