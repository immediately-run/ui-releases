"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useMounts = useMounts;
var _react = require("react");
var _mounts = require("@immediately-run/sdk/mounts");
// The live mount set for the dispatched-workbook flow (open-workbook provider). The
// host's repo-load dispatch mounts the corpus BEFORE the viewer runs, but a mount can
// also be announced a beat after boot — so this observes `onMountsChange` and the
// session rebuilds when the workbook resolution actually changes (never mid-document:
// the resolution latches on the first content mount, matching Grove's boot rule).

// The per-module subpath, deliberately: the SDK root pulls in `tasks.ts`, which
// registers a host listener at module load and throws in plain vite dev (no host
// transport). `mounts` is documented side-effect-clean for exactly this reason.

/** A snapshot of the mount set that re-renders on change; empty under vite dev. */
function useMounts() {
  const [mounts, setMounts] = (0, _react.useState)(() => {
    try {
      return [...(0, _mounts.getMounts)()];
    } catch {
      return []; // no host runtime (vite dev) — the seed document flow
    }
  });
  (0, _react.useEffect)(() => {
    try {
      return (0, _mounts.onMountsChange)(next => setMounts([...next]));
    } catch {
      return undefined; // no host runtime — nothing to observe
    }
  }, []);
  return mounts;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX21vdW50cyIsInVzZU1vdW50cyIsIm1vdW50cyIsInNldE1vdW50cyIsInVzZVN0YXRlIiwiZ2V0TW91bnRzIiwidXNlRWZmZWN0Iiwib25Nb3VudHNDaGFuZ2UiLCJuZXh0IiwidW5kZWZpbmVkIl0sInNvdXJjZXMiOlsidXNlTW91bnRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBsaXZlIG1vdW50IHNldCBmb3IgdGhlIGRpc3BhdGNoZWQtd29ya2Jvb2sgZmxvdyAob3Blbi13b3JrYm9vayBwcm92aWRlcikuIFRoZVxuLy8gaG9zdCdzIHJlcG8tbG9hZCBkaXNwYXRjaCBtb3VudHMgdGhlIGNvcnB1cyBCRUZPUkUgdGhlIHZpZXdlciBydW5zLCBidXQgYSBtb3VudCBjYW5cbi8vIGFsc28gYmUgYW5ub3VuY2VkIGEgYmVhdCBhZnRlciBib290IOKAlCBzbyB0aGlzIG9ic2VydmVzIGBvbk1vdW50c0NoYW5nZWAgYW5kIHRoZVxuLy8gc2Vzc2lvbiByZWJ1aWxkcyB3aGVuIHRoZSB3b3JrYm9vayByZXNvbHV0aW9uIGFjdHVhbGx5IGNoYW5nZXMgKG5ldmVyIG1pZC1kb2N1bWVudDpcbi8vIHRoZSByZXNvbHV0aW9uIGxhdGNoZXMgb24gdGhlIGZpcnN0IGNvbnRlbnQgbW91bnQsIG1hdGNoaW5nIEdyb3ZlJ3MgYm9vdCBydWxlKS5cblxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0Jztcbi8vIFRoZSBwZXItbW9kdWxlIHN1YnBhdGgsIGRlbGliZXJhdGVseTogdGhlIFNESyByb290IHB1bGxzIGluIGB0YXNrcy50c2AsIHdoaWNoXG4vLyByZWdpc3RlcnMgYSBob3N0IGxpc3RlbmVyIGF0IG1vZHVsZSBsb2FkIGFuZCB0aHJvd3MgaW4gcGxhaW4gdml0ZSBkZXYgKG5vIGhvc3Rcbi8vIHRyYW5zcG9ydCkuIGBtb3VudHNgIGlzIGRvY3VtZW50ZWQgc2lkZS1lZmZlY3QtY2xlYW4gZm9yIGV4YWN0bHkgdGhpcyByZWFzb24uXG5pbXBvcnQgeyBnZXRNb3VudHMsIG9uTW91bnRzQ2hhbmdlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvbW91bnRzJztcbmltcG9ydCB0eXBlIHsgU2FuZGJveE1vdW50IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvbW91bnRzJztcblxuLyoqIEEgc25hcHNob3Qgb2YgdGhlIG1vdW50IHNldCB0aGF0IHJlLXJlbmRlcnMgb24gY2hhbmdlOyBlbXB0eSB1bmRlciB2aXRlIGRldi4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNb3VudHMoKTogcmVhZG9ubHkgU2FuZGJveE1vdW50W10ge1xuICBjb25zdCBbbW91bnRzLCBzZXRNb3VudHNdID0gdXNlU3RhdGU8cmVhZG9ubHkgU2FuZGJveE1vdW50W10+KCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIFsuLi5nZXRNb3VudHMoKV07XG4gICAgfSBjYXRjaCB7XG4gICAgICByZXR1cm4gW107IC8vIG5vIGhvc3QgcnVudGltZSAodml0ZSBkZXYpIOKAlCB0aGUgc2VlZCBkb2N1bWVudCBmbG93XG4gICAgfVxuICB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gb25Nb3VudHNDaGFuZ2UoKG5leHQpID0+IHNldE1vdW50cyhbLi4ubmV4dF0pKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7IC8vIG5vIGhvc3QgcnVudGltZSDigJQgbm90aGluZyB0byBvYnNlcnZlXG4gICAgfVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIG1vdW50cztcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBSUEsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBVkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7O0FBSUE7QUFDTyxTQUFTRSxTQUFTQSxDQUFBLEVBQTRCO0VBQ25ELE1BQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQTBCLE1BQU07SUFDbEUsSUFBSTtNQUNGLE9BQU8sQ0FBQyxHQUFHLElBQUFDLGlCQUFTLEVBQUMsQ0FBQyxDQUFDO0lBQ3pCLENBQUMsQ0FBQyxNQUFNO01BQ04sT0FBTyxFQUFFLENBQUMsQ0FBQztJQUNiO0VBQ0YsQ0FBQyxDQUFDO0VBRUYsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSTtNQUNGLE9BQU8sSUFBQUMsc0JBQWMsRUFBRUMsSUFBSSxJQUFLTCxTQUFTLENBQUMsQ0FBQyxHQUFHSyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELENBQUMsQ0FBQyxNQUFNO01BQ04sT0FBT0MsU0FBUyxDQUFDLENBQUM7SUFDcEI7RUFDRixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sT0FBT1AsTUFBTTtBQUNmIiwiaWdub3JlTGlzdCI6W119