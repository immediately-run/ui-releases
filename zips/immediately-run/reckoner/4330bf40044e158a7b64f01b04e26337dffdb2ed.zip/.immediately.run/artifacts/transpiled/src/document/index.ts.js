"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "compareVersions", {
  enumerable: true,
  get: function () {
    return _semver.compareVersions;
  }
});
Object.defineProperty(exports, "loadDocument", {
  enumerable: true,
  get: function () {
    return _loader.loadDocument;
  }
});
Object.defineProperty(exports, "parseFeedConfig", {
  enumerable: true,
  get: function () {
    return _feeds.parseFeedConfig;
  }
});
Object.defineProperty(exports, "parseFixtureFrame", {
  enumerable: true,
  get: function () {
    return _fixtures.parseFixtureFrame;
  }
});
Object.defineProperty(exports, "parseManifest", {
  enumerable: true,
  get: function () {
    return _manifest.parseManifest;
  }
});
Object.defineProperty(exports, "parseVersion", {
  enumerable: true,
  get: function () {
    return _semver.parseVersion;
  }
});
Object.defineProperty(exports, "resolveCompat", {
  enumerable: true,
  get: function () {
    return _compat.resolveCompat;
  }
});
Object.defineProperty(exports, "satisfies", {
  enumerable: true,
  get: function () {
    return _semver.satisfies;
  }
});
Object.defineProperty(exports, "validateExternalReferences", {
  enumerable: true,
  get: function () {
    return _xref.validateExternalReferences;
  }
});
Object.defineProperty(exports, "validateFixtureProvenance", {
  enumerable: true,
  get: function () {
    return _xref.validateFixtureProvenance;
  }
});
var _manifest = require("./manifest.ts");
var _feeds = require("./feeds.ts");
var _fixtures = require("./fixtures.ts");
var _loader = require("./loader.ts");
var _xref = require("./xref.ts");
var _compat = require("./compat.ts");
var _semver = require("./semver.ts");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbWFuaWZlc3QiLCJyZXF1aXJlIiwiX2ZlZWRzIiwiX2ZpeHR1cmVzIiwiX2xvYWRlciIsIl94cmVmIiwiX2NvbXBhdCIsIl9zZW12ZXIiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgUmVja29uZXIgZG9jdW1lbnQgbW9kZWwgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnMzsgRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDKS5cbi8vXG4vLyBUeXBlcyArIHB1cmUgdmFsaWRhdG9ycyBmb3IgdGhlIGRvY3VtZW50J3MgcGxhaW4gZmlsZXMgKGByZWNrb25lci5qc29uYCwgZmVlZHMsXG4vLyBmaXh0dXJlcyksIGEgZmlsZXN5c3RlbS1wb3J0IGxvYWRlciB0aGF0IGFzc2VtYmxlcyBhIGBMb2FkZWREb2N1bWVudGAgd2l0aCBkaWFnbm9zdGljcyxcbi8vIGFuZCB0aGUgdmVyc2lvbi1jb21wYXRpYmlsaXR5IHJlc29sdXRpb24gcnVsZS4gV29ya3NoZWV0L3RlbXBsYXRlICpzb3VyY2UqIGlzIGNhcnJpZWQgYXNcbi8vIHJhdyB0ZXh0IOKAlCBleGVjdXRpbmcgaXQgKHRoZSBTRVMgZW5naW5lKSBhbmQgcmVuZGVyaW5nIGl0ICh0aGUgU0RLIHNhZmUgcmVuZGVyZXIpIGFyZVxuLy8gb3RoZXIgcmVhbG1zJyBqb2JzLlxuLy9cbi8vIERlZmVycmVkICh0cmFja2VkLCBmb2xsb3ctdXApOiBob3N0LXNpZGUgYGNvbXBhdGAgZGVyaXZhdGlvbiBieSBzdGF0aWMgYW5hbHlzaXMgb2Zcbi8vIHdvcmtzaGVldCBpbXBvcnRzIC8gdGVtcGxhdGUgY29tcG9uZW50IHVzZXMgYXQgc2F2ZSB0aW1lIChET0NVTUVOVF9WRVJTSU9OSU5HIMKnMSDigJQgdGhpc1xuLy8gbW9kdWxlIHZhbGlkYXRlcyBhbmQgcmVzb2x2ZXMgYW4gKmV4aXN0aW5nKiBlbnZlbG9wZTsgZGVyaXZpbmcgaXQgaXMgYSBzYXZlLXRpbWUgaG9zdFxuLy8gZmVhdHVyZSkuIENyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uIGlzIHNoaXBwZWQgKGB4cmVmLnRzYCk6IGZpeHR1cmUgYHNvdXJjZUZlZWRgXG4vLyByZWZlcmVuY2VzIGFyZSBjaGVja2VkIGF0IGxvYWQ7IHdvcmtzaGVldCBleHRlcm5hbCByZWZlcmVuY2VzIGFyZSB2YWxpZGF0ZWQgd2hlcmUgdGhlXG4vLyBldmFsdWF0ZWQgd29ya2Jvb2sgbWVldHMgdGhlIGxvYWRlZCBkb2N1bWVudCAoYHZhbGlkYXRlRXh0ZXJuYWxSZWZlcmVuY2VzYCkuXG5cbmV4cG9ydCB0eXBlIHtcbiAgQXV0aG9yZWRXaXRoLFxuICBDb21wYXRCbG9jayxcbiAgRGlhZ25vc3RpY1NldmVyaXR5LFxuICBEb2N1bWVudERpYWdub3N0aWMsXG4gIERvY3VtZW50UmVhZGVyLFxuICBGZWVkQXV0aCxcbiAgRmVlZENvbmZpZyxcbiAgRmVlZEZpbGUsXG4gIEZlZWRSZXRlbnRpb24sXG4gIEZpeHR1cmVGaWxlLFxuICBGaXh0dXJlRnJhbWUsXG4gIEZpeHR1cmVQcm92ZW5hbmNlLFxuICBMb2FkZWREb2N1bWVudCxcbiAgUmVja29uZXJNYW5pZmVzdCxcbiAgU291cmNlRmlsZSxcbn0gZnJvbSAnLi90eXBlcy50cyc7XG5cbmV4cG9ydCB7IHBhcnNlTWFuaWZlc3QgfSBmcm9tICcuL21hbmlmZXN0LnRzJztcbmV4cG9ydCB7IHBhcnNlRmVlZENvbmZpZyB9IGZyb20gJy4vZmVlZHMudHMnO1xuZXhwb3J0IHsgcGFyc2VGaXh0dXJlRnJhbWUgfSBmcm9tICcuL2ZpeHR1cmVzLnRzJztcbmV4cG9ydCB7IGxvYWREb2N1bWVudCB9IGZyb20gJy4vbG9hZGVyLnRzJztcbmV4cG9ydCB7IHZhbGlkYXRlRXh0ZXJuYWxSZWZlcmVuY2VzLCB2YWxpZGF0ZUZpeHR1cmVQcm92ZW5hbmNlIH0gZnJvbSAnLi94cmVmLnRzJztcbmV4cG9ydCB0eXBlIHsgRXh0ZXJuYWxSZWZlcmVuY2UsIFhSZWZBdmFpbGFiaWxpdHkgfSBmcm9tICcuL3hyZWYudHMnO1xuZXhwb3J0IHsgcmVzb2x2ZUNvbXBhdCB9IGZyb20gJy4vY29tcGF0LnRzJztcbmV4cG9ydCB0eXBlIHsgQXBwVmVyc2lvbnMsIENvbXBhdFZlcmRpY3QgfSBmcm9tICcuL2NvbXBhdC50cyc7XG5leHBvcnQgeyBjb21wYXJlVmVyc2lvbnMsIHBhcnNlVmVyc2lvbiwgc2F0aXNmaWVzIH0gZnJvbSAnLi9zZW12ZXIudHMnO1xuZXhwb3J0IHR5cGUgeyBTZW1WZXIgfSBmcm9tICcuL3NlbXZlci50cyc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUNBLElBQUFBLFNBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLEtBQUEsR0FBQUosT0FBQTtBQUVBLElBQUFLLE9BQUEsR0FBQUwsT0FBQTtBQUVBLElBQUFNLE9BQUEsR0FBQU4sT0FBQSIsImlnbm9yZUxpc3QiOltdfQ==