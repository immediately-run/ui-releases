"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
var _vitest = require("vitest");
var _index = require("../stdlib/index.ts");
var _testrunner = require("./testrunner.ts");
(0, _vitest.describe)('classifyCell — the review-surface verdict (§6)', () => {
  (0, _vitest.it)('no tests → untested', () => {
    (0, _vitest.expect)((0, _testrunner.classifyCell)([])).toBe('untested');
  });
  (0, _vitest.it)('any failure → failing', () => {
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'metamorphic',
      pass: true
    }, {
      kind: 'specification',
      pass: false
    }])).toBe('failing');
  });
  (0, _vitest.it)('a passing metamorphic/property leg → validated', () => {
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'metamorphic',
      pass: true
    }])).toBe('validated');
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'property',
      pass: true
    }, {
      kind: 'characterization',
      pass: true
    }])).toBe('validated');
  });
  (0, _vitest.it)('only example-based passing tests → pinned, not validated', () => {
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'characterization',
      pass: true
    }])).toBe('pinned');
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'specification',
      pass: true
    }, {
      kind: 'characterization',
      pass: true
    }])).toBe('pinned');
  });

  // G-HRM-8 (`HOLDOUT_REDACTED_MOUNT_SPEC` §6, roadmap R3-228). A holdout test is emitted
  // as a `specification` cell, and this is the assertion that keeps D9 honest about what
  // it bought: the mechanism closes the trivial read, it does NOT make the formula
  // correct. §5.1's test-oracle channel and §5.2's affine reconstruction both survive
  // path separation, so a green holdout run is a tripwire — and a review surface that
  // promoted it to "validated" would be claiming exactly the certification two adversarial
  // passes withdrew.
  //
  // The rule this pins predates D9 (it is §6's example-based/oracle-free split). It is
  // asserted here under the gate's name so the ladder has a test that fails if a later
  // change to the verdict rule quietly re-promotes a holdout-only cell.
  (0, _vitest.it)('G-HRM-8: a holdout-only cell is pinned, never validated — a tripwire, not a proof', () => {
    // The mainline shape: the host withheld rows and emitted one `specification` test.
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'specification',
      pass: true
    }])).toBe('pinned');
    // Piling on more holdout legs does not add up to validation.
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'specification',
      pass: true
    }, {
      kind: 'specification',
      pass: true
    }, {
      kind: 'specification',
      pass: true
    }])).toBe('pinned');
    // Only an oracle-free leg promotes it — and that leg needs no hidden data at all.
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'specification',
      pass: true
    }, {
      kind: 'metamorphic',
      pass: true
    }])).toBe('validated');
    // The tripwire still fires: a broken held-out row is a real, loud signal.
    (0, _vitest.expect)((0, _testrunner.classifyCell)([{
      kind: 'specification',
      pass: false
    }])).toBe('failing');
  });
});
(0, _vitest.describe)('runTest — expect', () => {
  (0, _vitest.it)('runs an example-based assertion over the subject value', () => {
    const t = (0, _index.testCell)({
      kind: 'specification',
      subject: 'revenue.total',
      inputs: {
        rows: 'fixtures.holdout'
      },
      expect: ({
        result
      }) => (0, _index.expectClose)(result, 48_120, {
        rel: 0.01
      })
    });
    (0, _vitest.expect)((0, _testrunner.runTest)(t, {
      subject: 48_600,
      inputs: {}
    }).pass).toBe(true);
    (0, _vitest.expect)((0, _testrunner.runTest)(t, {
      subject: 60_000,
      inputs: {}
    }).pass).toBe(false);
  });
});
(0, _vitest.describe)('runTest — metamorphic relation with reevaluate', () => {
  // subject: revenue by month = groupBy(month) → sum(amount)
  const byMonth = (0, _index.cell)({
    doc: 'revenue by month',
    inputs: {
      orders: 'feeds.orders'
    },
    formula: ({
      orders
    }) => (0, _index.table)(orders).groupBy('month').rollup({
      revenue: (0, _index.sum)('amount')
    }).rows()
  });
  const orders = [{
    month: '2026-01',
    amount: 100
  }, {
    month: '2026-02',
    amount: 50
  }, {
    month: '2026-01',
    amount: 40
  }];
  const result = byMonth.formula({
    orders
  });
  (0, _vitest.it)('permutation invariance passes — the runner transforms the input and re-runs', () => {
    const t = (0, _index.testCell)({
      kind: 'metamorphic',
      subject: 'revenue.by_month',
      inputs: {
        orders: 'feeds.orders'
      },
      relation: (0, _index.permutationInvariance)({
        over: 'orders'
      })
    });
    const out = (0, _testrunner.runTest)(t, {
      subject: result,
      inputs: {
        orders
      },
      reevaluate: inputs => byMonth.formula(inputs)
    });
    (0, _vitest.expect)(out.pass).toBe(true);
  });
  (0, _vitest.it)('fails when the subject is not actually invariant', () => {
    const t = (0, _index.testCell)({
      kind: 'metamorphic',
      subject: 'x',
      inputs: {
        orders: 'feeds.orders'
      },
      relation: (0, _index.permutationInvariance)({
        over: 'orders'
      })
    });
    // a subject that echoes input order is NOT permutation-invariant
    const out = (0, _testrunner.runTest)(t, {
      subject: orders,
      inputs: {
        orders
      },
      reevaluate: inputs => inputs.orders
    });
    (0, _vitest.expect)(out.pass).toBe(false);
  });
  (0, _vitest.it)('a relation needing reevaluate reports cleanly when the port is missing', () => {
    const t = (0, _index.testCell)({
      kind: 'metamorphic',
      subject: 'x',
      inputs: {
        orders: 'feeds.orders'
      },
      relation: (0, _index.permutationInvariance)({
        over: 'orders'
      })
    });
    (0, _vitest.expect)((0, _testrunner.runTest)(t, {
      subject: result,
      inputs: {
        orders
      }
    }).pass).toBe(false);
  });
});
(0, _vitest.describe)('runTest — conservation (no reevaluate needed)', () => {
  (0, _vitest.it)('checks the row-reconciliation identity on the subject', () => {
    const t = (0, _index.testCell)({
      kind: 'metamorphic',
      subject: 'mrr.movements',
      inputs: {
        m: 'fixtures.movements'
      },
      relation: (0, _index.conservation)({
        components: ['start', 'movement'],
        equals: 'end'
      })
    });
    const good = [{
      start: 1000,
      movement: 160,
      end: 1160
    }];
    const bad = [{
      start: 1000,
      movement: 160,
      end: 9999
    }];
    (0, _vitest.expect)((0, _testrunner.runTest)(t, {
      subject: good,
      inputs: {}
    }).pass).toBe(true);
    (0, _vitest.expect)((0, _testrunner.runTest)(t, {
      subject: bad,
      inputs: {}
    }).pass).toBe(false);
  });
});
(0, _vitest.describe)('runSuite — verdict over a subject cell', () => {
  (0, _vitest.it)('a metamorphic pass promotes the cell to validated', () => {
    const orders = [{
      month: '2026-01',
      amount: 10
    }];
    const byMonth = (0, _index.cell)({
      doc: 'rev',
      inputs: {
        orders: 'feeds.orders'
      },
      formula: ({
        orders
      }) => (0, _index.table)(orders).groupBy('month').rollup({
        revenue: (0, _index.sum)('amount')
      }).rows()
    });
    const result = byMonth.formula({
      orders
    });
    const tests = [(0, _index.testCell)({
      kind: 'characterization',
      subject: 'revenue.by_month',
      inputs: {
        orders: 'feeds.orders'
      },
      expect: ({
        result: r
      }) => ({
        pass: Array.isArray(r),
        message: 'shape'
      })
    }), (0, _index.testCell)({
      kind: 'metamorphic',
      subject: 'revenue.by_month',
      inputs: {
        orders: 'feeds.orders'
      },
      relation: (0, _index.permutationInvariance)({
        over: 'orders'
      })
    })];
    const suite = (0, _testrunner.runSuite)(tests, () => ({
      subject: result,
      inputs: {
        orders
      },
      reevaluate: inputs => byMonth.formula(inputs)
    }));
    (0, _vitest.expect)(suite.outcomes.every(o => o.result.pass)).toBe(true);
    (0, _vitest.expect)(suite.verdict).toBe('validated');
  });
});
(0, _vitest.describe)('the test→subject input lanes (§6, R3-373)', () => {
  // The split itself (name-matched → substitution with subject re-run; name-unmatched →
  // auxiliary context that never feeds the formula) is exercised end-to-end in
  // engine.test.ts / asyncEngine.test.ts / engineWorker.test.ts, where the subject
  // formula exists to re-run. Here the contract that stays in this module: a context
  // error fails the outcome loudly, never a silent null.

  (0, _vitest.it)('runTest fails with the context error, never a silent null', () => {
    const t = (0, _index.testCell)({
      kind: 'specification',
      subject: 'x.y',
      expect: () => ({
        pass: true,
        message: 'unreached'
      })
    });
    const r = (0, _testrunner.runTest)(t, {
      subject: null,
      inputs: {},
      error: 'test "x.y_holdout" input "rows" references absent external "fixtures.orders_holdout".'
    });
    (0, _vitest.expect)(r.pass).toBe(false);
    (0, _vitest.expect)(r.message).toContain('rows');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9pbmRleCIsIl90ZXN0cnVubmVyIiwiZGVzY3JpYmUiLCJpdCIsImV4cGVjdCIsImNsYXNzaWZ5Q2VsbCIsInRvQmUiLCJraW5kIiwicGFzcyIsInQiLCJ0ZXN0Q2VsbCIsInN1YmplY3QiLCJpbnB1dHMiLCJyb3dzIiwicmVzdWx0IiwiZXhwZWN0Q2xvc2UiLCJyZWwiLCJydW5UZXN0IiwiYnlNb250aCIsImNlbGwiLCJkb2MiLCJvcmRlcnMiLCJmb3JtdWxhIiwidGFibGUiLCJncm91cEJ5Iiwicm9sbHVwIiwicmV2ZW51ZSIsInN1bSIsIm1vbnRoIiwiYW1vdW50IiwicmVsYXRpb24iLCJwZXJtdXRhdGlvbkludmFyaWFuY2UiLCJvdmVyIiwib3V0IiwicmVldmFsdWF0ZSIsIm0iLCJjb25zZXJ2YXRpb24iLCJjb21wb25lbnRzIiwiZXF1YWxzIiwiZ29vZCIsInN0YXJ0IiwibW92ZW1lbnQiLCJlbmQiLCJiYWQiLCJ0ZXN0cyIsInIiLCJBcnJheSIsImlzQXJyYXkiLCJtZXNzYWdlIiwic3VpdGUiLCJydW5TdWl0ZSIsIm91dGNvbWVzIiwiZXZlcnkiLCJvIiwidmVyZGljdCIsImVycm9yIiwidG9Db250YWluIl0sInNvdXJjZXMiOlsidGVzdHJ1bm5lci50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0IH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7XG4gIGNlbGwsXG4gIHRlc3RDZWxsLFxuICB0YWJsZSxcbiAgc3VtLFxuICBwZXJtdXRhdGlvbkludmFyaWFuY2UsXG4gIGNvbnNlcnZhdGlvbixcbiAgZXhwZWN0Q2xvc2UsXG59IGZyb20gJy4uL3N0ZGxpYi9pbmRleC50cyc7XG5pbXBvcnQgeyBydW5UZXN0LCBydW5TdWl0ZSwgY2xhc3NpZnlDZWxsIH0gZnJvbSAnLi90ZXN0cnVubmVyLnRzJztcbmltcG9ydCB0eXBlIHsgUm93LCBWYWx1ZSB9IGZyb20gJy4uL3N0ZGxpYi90eXBlcy50cyc7XG5cbmRlc2NyaWJlKCdjbGFzc2lmeUNlbGwg4oCUIHRoZSByZXZpZXctc3VyZmFjZSB2ZXJkaWN0ICjCpzYpJywgKCkgPT4ge1xuICBpdCgnbm8gdGVzdHMg4oaSIHVudGVzdGVkJywgKCkgPT4ge1xuICAgIGV4cGVjdChjbGFzc2lmeUNlbGwoW10pKS50b0JlKCd1bnRlc3RlZCcpO1xuICB9KTtcblxuICBpdCgnYW55IGZhaWx1cmUg4oaSIGZhaWxpbmcnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGNsYXNzaWZ5Q2VsbChbeyBraW5kOiAnbWV0YW1vcnBoaWMnLCBwYXNzOiB0cnVlIH0sIHsga2luZDogJ3NwZWNpZmljYXRpb24nLCBwYXNzOiBmYWxzZSB9XSkpLnRvQmUoJ2ZhaWxpbmcnKTtcbiAgfSk7XG5cbiAgaXQoJ2EgcGFzc2luZyBtZXRhbW9ycGhpYy9wcm9wZXJ0eSBsZWcg4oaSIHZhbGlkYXRlZCcsICgpID0+IHtcbiAgICBleHBlY3QoY2xhc3NpZnlDZWxsKFt7IGtpbmQ6ICdtZXRhbW9ycGhpYycsIHBhc3M6IHRydWUgfV0pKS50b0JlKCd2YWxpZGF0ZWQnKTtcbiAgICBleHBlY3QoY2xhc3NpZnlDZWxsKFt7IGtpbmQ6ICdwcm9wZXJ0eScsIHBhc3M6IHRydWUgfSwgeyBraW5kOiAnY2hhcmFjdGVyaXphdGlvbicsIHBhc3M6IHRydWUgfV0pKS50b0JlKCd2YWxpZGF0ZWQnKTtcbiAgfSk7XG5cbiAgaXQoJ29ubHkgZXhhbXBsZS1iYXNlZCBwYXNzaW5nIHRlc3RzIOKGkiBwaW5uZWQsIG5vdCB2YWxpZGF0ZWQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGNsYXNzaWZ5Q2VsbChbeyBraW5kOiAnY2hhcmFjdGVyaXphdGlvbicsIHBhc3M6IHRydWUgfV0pKS50b0JlKCdwaW5uZWQnKTtcbiAgICBleHBlY3QoY2xhc3NpZnlDZWxsKFt7IGtpbmQ6ICdzcGVjaWZpY2F0aW9uJywgcGFzczogdHJ1ZSB9LCB7IGtpbmQ6ICdjaGFyYWN0ZXJpemF0aW9uJywgcGFzczogdHJ1ZSB9XSkpLnRvQmUoJ3Bpbm5lZCcpO1xuICB9KTtcblxuICAvLyBHLUhSTS04IChgSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TUEVDYCDCpzYsIHJvYWRtYXAgUjMtMjI4KS4gQSBob2xkb3V0IHRlc3QgaXMgZW1pdHRlZFxuICAvLyBhcyBhIGBzcGVjaWZpY2F0aW9uYCBjZWxsLCBhbmQgdGhpcyBpcyB0aGUgYXNzZXJ0aW9uIHRoYXQga2VlcHMgRDkgaG9uZXN0IGFib3V0IHdoYXRcbiAgLy8gaXQgYm91Z2h0OiB0aGUgbWVjaGFuaXNtIGNsb3NlcyB0aGUgdHJpdmlhbCByZWFkLCBpdCBkb2VzIE5PVCBtYWtlIHRoZSBmb3JtdWxhXG4gIC8vIGNvcnJlY3QuIMKnNS4xJ3MgdGVzdC1vcmFjbGUgY2hhbm5lbCBhbmQgwqc1LjIncyBhZmZpbmUgcmVjb25zdHJ1Y3Rpb24gYm90aCBzdXJ2aXZlXG4gIC8vIHBhdGggc2VwYXJhdGlvbiwgc28gYSBncmVlbiBob2xkb3V0IHJ1biBpcyBhIHRyaXB3aXJlIOKAlCBhbmQgYSByZXZpZXcgc3VyZmFjZSB0aGF0XG4gIC8vIHByb21vdGVkIGl0IHRvIFwidmFsaWRhdGVkXCIgd291bGQgYmUgY2xhaW1pbmcgZXhhY3RseSB0aGUgY2VydGlmaWNhdGlvbiB0d28gYWR2ZXJzYXJpYWxcbiAgLy8gcGFzc2VzIHdpdGhkcmV3LlxuICAvL1xuICAvLyBUaGUgcnVsZSB0aGlzIHBpbnMgcHJlZGF0ZXMgRDkgKGl0IGlzIMKnNidzIGV4YW1wbGUtYmFzZWQvb3JhY2xlLWZyZWUgc3BsaXQpLiBJdCBpc1xuICAvLyBhc3NlcnRlZCBoZXJlIHVuZGVyIHRoZSBnYXRlJ3MgbmFtZSBzbyB0aGUgbGFkZGVyIGhhcyBhIHRlc3QgdGhhdCBmYWlscyBpZiBhIGxhdGVyXG4gIC8vIGNoYW5nZSB0byB0aGUgdmVyZGljdCBydWxlIHF1aWV0bHkgcmUtcHJvbW90ZXMgYSBob2xkb3V0LW9ubHkgY2VsbC5cbiAgaXQoJ0ctSFJNLTg6IGEgaG9sZG91dC1vbmx5IGNlbGwgaXMgcGlubmVkLCBuZXZlciB2YWxpZGF0ZWQg4oCUIGEgdHJpcHdpcmUsIG5vdCBhIHByb29mJywgKCkgPT4ge1xuICAgIC8vIFRoZSBtYWlubGluZSBzaGFwZTogdGhlIGhvc3Qgd2l0aGhlbGQgcm93cyBhbmQgZW1pdHRlZCBvbmUgYHNwZWNpZmljYXRpb25gIHRlc3QuXG4gICAgZXhwZWN0KGNsYXNzaWZ5Q2VsbChbeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHBhc3M6IHRydWUgfV0pKS50b0JlKCdwaW5uZWQnKTtcbiAgICAvLyBQaWxpbmcgb24gbW9yZSBob2xkb3V0IGxlZ3MgZG9lcyBub3QgYWRkIHVwIHRvIHZhbGlkYXRpb24uXG4gICAgZXhwZWN0KFxuICAgICAgY2xhc3NpZnlDZWxsKFtcbiAgICAgICAgeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHBhc3M6IHRydWUgfSxcbiAgICAgICAgeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHBhc3M6IHRydWUgfSxcbiAgICAgICAgeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHBhc3M6IHRydWUgfSxcbiAgICAgIF0pLFxuICAgICkudG9CZSgncGlubmVkJyk7XG4gICAgLy8gT25seSBhbiBvcmFjbGUtZnJlZSBsZWcgcHJvbW90ZXMgaXQg4oCUIGFuZCB0aGF0IGxlZyBuZWVkcyBubyBoaWRkZW4gZGF0YSBhdCBhbGwuXG4gICAgZXhwZWN0KGNsYXNzaWZ5Q2VsbChbeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHBhc3M6IHRydWUgfSwgeyBraW5kOiAnbWV0YW1vcnBoaWMnLCBwYXNzOiB0cnVlIH1dKSkudG9CZSgndmFsaWRhdGVkJyk7XG4gICAgLy8gVGhlIHRyaXB3aXJlIHN0aWxsIGZpcmVzOiBhIGJyb2tlbiBoZWxkLW91dCByb3cgaXMgYSByZWFsLCBsb3VkIHNpZ25hbC5cbiAgICBleHBlY3QoY2xhc3NpZnlDZWxsKFt7IGtpbmQ6ICdzcGVjaWZpY2F0aW9uJywgcGFzczogZmFsc2UgfV0pKS50b0JlKCdmYWlsaW5nJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdydW5UZXN0IOKAlCBleHBlY3QnLCAoKSA9PiB7XG4gIGl0KCdydW5zIGFuIGV4YW1wbGUtYmFzZWQgYXNzZXJ0aW9uIG92ZXIgdGhlIHN1YmplY3QgdmFsdWUnLCAoKSA9PiB7XG4gICAgY29uc3QgdCA9IHRlc3RDZWxsKHtcbiAgICAgIGtpbmQ6ICdzcGVjaWZpY2F0aW9uJyxcbiAgICAgIHN1YmplY3Q6ICdyZXZlbnVlLnRvdGFsJyxcbiAgICAgIGlucHV0czogeyByb3dzOiAnZml4dHVyZXMuaG9sZG91dCcgfSxcbiAgICAgIGV4cGVjdDogKHsgcmVzdWx0IH0pID0+IGV4cGVjdENsb3NlKHJlc3VsdCBhcyBudW1iZXIsIDQ4XzEyMCwgeyByZWw6IDAuMDEgfSksXG4gICAgfSk7XG4gICAgZXhwZWN0KHJ1blRlc3QodCwgeyBzdWJqZWN0OiA0OF82MDAsIGlucHV0czoge30gfSkucGFzcykudG9CZSh0cnVlKTtcbiAgICBleHBlY3QocnVuVGVzdCh0LCB7IHN1YmplY3Q6IDYwXzAwMCwgaW5wdXRzOiB7fSB9KS5wYXNzKS50b0JlKGZhbHNlKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ3J1blRlc3Qg4oCUIG1ldGFtb3JwaGljIHJlbGF0aW9uIHdpdGggcmVldmFsdWF0ZScsICgpID0+IHtcbiAgLy8gc3ViamVjdDogcmV2ZW51ZSBieSBtb250aCA9IGdyb3VwQnkobW9udGgpIOKGkiBzdW0oYW1vdW50KVxuICBjb25zdCBieU1vbnRoID0gY2VsbCh7XG4gICAgZG9jOiAncmV2ZW51ZSBieSBtb250aCcsXG4gICAgaW5wdXRzOiB7IG9yZGVyczogJ2ZlZWRzLm9yZGVycycgfSxcbiAgICBmb3JtdWxhOiAoeyBvcmRlcnMgfSkgPT5cbiAgICAgIHRhYmxlKG9yZGVycyBhcyBSb3dbXSlcbiAgICAgICAgLmdyb3VwQnkoJ21vbnRoJylcbiAgICAgICAgLnJvbGx1cCh7IHJldmVudWU6IHN1bSgnYW1vdW50JykgfSlcbiAgICAgICAgLnJvd3MoKSxcbiAgfSk7XG4gIGNvbnN0IG9yZGVyczogUm93W10gPSBbXG4gICAgeyBtb250aDogJzIwMjYtMDEnLCBhbW91bnQ6IDEwMCB9LFxuICAgIHsgbW9udGg6ICcyMDI2LTAyJywgYW1vdW50OiA1MCB9LFxuICAgIHsgbW9udGg6ICcyMDI2LTAxJywgYW1vdW50OiA0MCB9LFxuICBdO1xuICBjb25zdCByZXN1bHQgPSBieU1vbnRoLmZvcm11bGEoeyBvcmRlcnMgfSkgYXMgVmFsdWU7XG5cbiAgaXQoJ3Blcm11dGF0aW9uIGludmFyaWFuY2UgcGFzc2VzIOKAlCB0aGUgcnVubmVyIHRyYW5zZm9ybXMgdGhlIGlucHV0IGFuZCByZS1ydW5zJywgKCkgPT4ge1xuICAgIGNvbnN0IHQgPSB0ZXN0Q2VsbCh7XG4gICAgICBraW5kOiAnbWV0YW1vcnBoaWMnLFxuICAgICAgc3ViamVjdDogJ3JldmVudWUuYnlfbW9udGgnLFxuICAgICAgaW5wdXRzOiB7IG9yZGVyczogJ2ZlZWRzLm9yZGVycycgfSxcbiAgICAgIHJlbGF0aW9uOiBwZXJtdXRhdGlvbkludmFyaWFuY2UoeyBvdmVyOiAnb3JkZXJzJyB9KSxcbiAgICB9KTtcbiAgICBjb25zdCBvdXQgPSBydW5UZXN0KHQsIHtcbiAgICAgIHN1YmplY3Q6IHJlc3VsdCxcbiAgICAgIGlucHV0czogeyBvcmRlcnMgfSxcbiAgICAgIHJlZXZhbHVhdGU6IChpbnB1dHMpID0+IGJ5TW9udGguZm9ybXVsYShpbnB1dHMpIGFzIFZhbHVlLFxuICAgIH0pO1xuICAgIGV4cGVjdChvdXQucGFzcykudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoJ2ZhaWxzIHdoZW4gdGhlIHN1YmplY3QgaXMgbm90IGFjdHVhbGx5IGludmFyaWFudCcsICgpID0+IHtcbiAgICBjb25zdCB0ID0gdGVzdENlbGwoe1xuICAgICAga2luZDogJ21ldGFtb3JwaGljJyxcbiAgICAgIHN1YmplY3Q6ICd4JyxcbiAgICAgIGlucHV0czogeyBvcmRlcnM6ICdmZWVkcy5vcmRlcnMnIH0sXG4gICAgICByZWxhdGlvbjogcGVybXV0YXRpb25JbnZhcmlhbmNlKHsgb3ZlcjogJ29yZGVycycgfSksXG4gICAgfSk7XG4gICAgLy8gYSBzdWJqZWN0IHRoYXQgZWNob2VzIGlucHV0IG9yZGVyIGlzIE5PVCBwZXJtdXRhdGlvbi1pbnZhcmlhbnRcbiAgICBjb25zdCBvdXQgPSBydW5UZXN0KHQsIHtcbiAgICAgIHN1YmplY3Q6IG9yZGVycyxcbiAgICAgIGlucHV0czogeyBvcmRlcnMgfSxcbiAgICAgIHJlZXZhbHVhdGU6IChpbnB1dHMpID0+IGlucHV0cy5vcmRlcnMsXG4gICAgfSk7XG4gICAgZXhwZWN0KG91dC5wYXNzKS50b0JlKGZhbHNlKTtcbiAgfSk7XG5cbiAgaXQoJ2EgcmVsYXRpb24gbmVlZGluZyByZWV2YWx1YXRlIHJlcG9ydHMgY2xlYW5seSB3aGVuIHRoZSBwb3J0IGlzIG1pc3NpbmcnLCAoKSA9PiB7XG4gICAgY29uc3QgdCA9IHRlc3RDZWxsKHtcbiAgICAgIGtpbmQ6ICdtZXRhbW9ycGhpYycsXG4gICAgICBzdWJqZWN0OiAneCcsXG4gICAgICBpbnB1dHM6IHsgb3JkZXJzOiAnZmVlZHMub3JkZXJzJyB9LFxuICAgICAgcmVsYXRpb246IHBlcm11dGF0aW9uSW52YXJpYW5jZSh7IG92ZXI6ICdvcmRlcnMnIH0pLFxuICAgIH0pO1xuICAgIGV4cGVjdChydW5UZXN0KHQsIHsgc3ViamVjdDogcmVzdWx0LCBpbnB1dHM6IHsgb3JkZXJzIH0gfSkucGFzcykudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdydW5UZXN0IOKAlCBjb25zZXJ2YXRpb24gKG5vIHJlZXZhbHVhdGUgbmVlZGVkKScsICgpID0+IHtcbiAgaXQoJ2NoZWNrcyB0aGUgcm93LXJlY29uY2lsaWF0aW9uIGlkZW50aXR5IG9uIHRoZSBzdWJqZWN0JywgKCkgPT4ge1xuICAgIGNvbnN0IHQgPSB0ZXN0Q2VsbCh7XG4gICAgICBraW5kOiAnbWV0YW1vcnBoaWMnLFxuICAgICAgc3ViamVjdDogJ21yci5tb3ZlbWVudHMnLFxuICAgICAgaW5wdXRzOiB7IG06ICdmaXh0dXJlcy5tb3ZlbWVudHMnIH0sXG4gICAgICByZWxhdGlvbjogY29uc2VydmF0aW9uKHsgY29tcG9uZW50czogWydzdGFydCcsICdtb3ZlbWVudCddLCBlcXVhbHM6ICdlbmQnIH0pLFxuICAgIH0pO1xuICAgIGNvbnN0IGdvb2QgPSBbeyBzdGFydDogMTAwMCwgbW92ZW1lbnQ6IDE2MCwgZW5kOiAxMTYwIH1dO1xuICAgIGNvbnN0IGJhZCA9IFt7IHN0YXJ0OiAxMDAwLCBtb3ZlbWVudDogMTYwLCBlbmQ6IDk5OTkgfV07XG4gICAgZXhwZWN0KHJ1blRlc3QodCwgeyBzdWJqZWN0OiBnb29kLCBpbnB1dHM6IHt9IH0pLnBhc3MpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHJ1blRlc3QodCwgeyBzdWJqZWN0OiBiYWQsIGlucHV0czoge30gfSkucGFzcykudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdydW5TdWl0ZSDigJQgdmVyZGljdCBvdmVyIGEgc3ViamVjdCBjZWxsJywgKCkgPT4ge1xuICBpdCgnYSBtZXRhbW9ycGhpYyBwYXNzIHByb21vdGVzIHRoZSBjZWxsIHRvIHZhbGlkYXRlZCcsICgpID0+IHtcbiAgICBjb25zdCBvcmRlcnM6IFJvd1tdID0gW3sgbW9udGg6ICcyMDI2LTAxJywgYW1vdW50OiAxMCB9XTtcbiAgICBjb25zdCBieU1vbnRoID0gY2VsbCh7XG4gICAgICBkb2M6ICdyZXYnLFxuICAgICAgaW5wdXRzOiB7IG9yZGVyczogJ2ZlZWRzLm9yZGVycycgfSxcbiAgICAgIGZvcm11bGE6ICh7IG9yZGVycyB9KSA9PiB0YWJsZShvcmRlcnMgYXMgUm93W10pLmdyb3VwQnkoJ21vbnRoJykucm9sbHVwKHsgcmV2ZW51ZTogc3VtKCdhbW91bnQnKSB9KS5yb3dzKCksXG4gICAgfSk7XG4gICAgY29uc3QgcmVzdWx0ID0gYnlNb250aC5mb3JtdWxhKHsgb3JkZXJzIH0pIGFzIFZhbHVlO1xuXG4gICAgY29uc3QgdGVzdHMgPSBbXG4gICAgICB0ZXN0Q2VsbCh7XG4gICAgICAgIGtpbmQ6ICdjaGFyYWN0ZXJpemF0aW9uJyxcbiAgICAgICAgc3ViamVjdDogJ3JldmVudWUuYnlfbW9udGgnLFxuICAgICAgICBpbnB1dHM6IHsgb3JkZXJzOiAnZmVlZHMub3JkZXJzJyB9LFxuICAgICAgICBleHBlY3Q6ICh7IHJlc3VsdDogciB9KSA9PiAoeyBwYXNzOiBBcnJheS5pc0FycmF5KHIpLCBtZXNzYWdlOiAnc2hhcGUnIH0pLFxuICAgICAgfSksXG4gICAgICB0ZXN0Q2VsbCh7XG4gICAgICAgIGtpbmQ6ICdtZXRhbW9ycGhpYycsXG4gICAgICAgIHN1YmplY3Q6ICdyZXZlbnVlLmJ5X21vbnRoJyxcbiAgICAgICAgaW5wdXRzOiB7IG9yZGVyczogJ2ZlZWRzLm9yZGVycycgfSxcbiAgICAgICAgcmVsYXRpb246IHBlcm11dGF0aW9uSW52YXJpYW5jZSh7IG92ZXI6ICdvcmRlcnMnIH0pLFxuICAgICAgfSksXG4gICAgXTtcblxuICAgIGNvbnN0IHN1aXRlID0gcnVuU3VpdGUodGVzdHMsICgpID0+ICh7XG4gICAgICBzdWJqZWN0OiByZXN1bHQsXG4gICAgICBpbnB1dHM6IHsgb3JkZXJzIH0sXG4gICAgICByZWV2YWx1YXRlOiAoaW5wdXRzKSA9PiBieU1vbnRoLmZvcm11bGEoaW5wdXRzKSBhcyBWYWx1ZSxcbiAgICB9KSk7XG4gICAgZXhwZWN0KHN1aXRlLm91dGNvbWVzLmV2ZXJ5KChvKSA9PiBvLnJlc3VsdC5wYXNzKSkudG9CZSh0cnVlKTtcbiAgICBleHBlY3Qoc3VpdGUudmVyZGljdCkudG9CZSgndmFsaWRhdGVkJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd0aGUgdGVzdOKGknN1YmplY3QgaW5wdXQgbGFuZXMgKMKnNiwgUjMtMzczKScsICgpID0+IHtcbiAgLy8gVGhlIHNwbGl0IGl0c2VsZiAobmFtZS1tYXRjaGVkIOKGkiBzdWJzdGl0dXRpb24gd2l0aCBzdWJqZWN0IHJlLXJ1bjsgbmFtZS11bm1hdGNoZWQg4oaSXG4gIC8vIGF1eGlsaWFyeSBjb250ZXh0IHRoYXQgbmV2ZXIgZmVlZHMgdGhlIGZvcm11bGEpIGlzIGV4ZXJjaXNlZCBlbmQtdG8tZW5kIGluXG4gIC8vIGVuZ2luZS50ZXN0LnRzIC8gYXN5bmNFbmdpbmUudGVzdC50cyAvIGVuZ2luZVdvcmtlci50ZXN0LnRzLCB3aGVyZSB0aGUgc3ViamVjdFxuICAvLyBmb3JtdWxhIGV4aXN0cyB0byByZS1ydW4uIEhlcmUgdGhlIGNvbnRyYWN0IHRoYXQgc3RheXMgaW4gdGhpcyBtb2R1bGU6IGEgY29udGV4dFxuICAvLyBlcnJvciBmYWlscyB0aGUgb3V0Y29tZSBsb3VkbHksIG5ldmVyIGEgc2lsZW50IG51bGwuXG5cbiAgaXQoJ3J1blRlc3QgZmFpbHMgd2l0aCB0aGUgY29udGV4dCBlcnJvciwgbmV2ZXIgYSBzaWxlbnQgbnVsbCcsICgpID0+IHtcbiAgICBjb25zdCB0ID0gdGVzdENlbGwoeyBraW5kOiAnc3BlY2lmaWNhdGlvbicsIHN1YmplY3Q6ICd4LnknLCBleHBlY3Q6ICgpID0+ICh7IHBhc3M6IHRydWUsIG1lc3NhZ2U6ICd1bnJlYWNoZWQnIH0pIH0pO1xuICAgIGNvbnN0IHIgPSBydW5UZXN0KHQsIHsgc3ViamVjdDogbnVsbCwgaW5wdXRzOiB7fSwgZXJyb3I6ICd0ZXN0IFwieC55X2hvbGRvdXRcIiBpbnB1dCBcInJvd3NcIiByZWZlcmVuY2VzIGFic2VudCBleHRlcm5hbCBcImZpeHR1cmVzLm9yZGVyc19ob2xkb3V0XCIuJyB9KTtcbiAgICBleHBlY3Qoci5wYXNzKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Qoci5tZXNzYWdlKS50b0NvbnRhaW4oJ3Jvd3MnKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQVNBLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUdBLElBQUFHLGdCQUFRLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtFQUMvRCxJQUFBQyxVQUFFLEVBQUMscUJBQXFCLEVBQUUsTUFBTTtJQUM5QixJQUFBQyxjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsVUFBVSxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyx1QkFBdUIsRUFBRSxNQUFNO0lBQ2hDLElBQUFDLGNBQU0sRUFBQyxJQUFBQyx3QkFBWSxFQUFDLENBQUM7TUFBRUUsSUFBSSxFQUFFLGFBQWE7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxFQUFFO01BQUVELElBQUksRUFBRSxlQUFlO01BQUVDLElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNySCxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtJQUN6RCxJQUFBQyxjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUM3RSxJQUFBRixjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxVQUFVO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsRUFBRTtNQUFFRCxJQUFJLEVBQUUsa0JBQWtCO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQztFQUN0SCxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsMERBQTBELEVBQUUsTUFBTTtJQUNuRSxJQUFBQyxjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxrQkFBa0I7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRixJQUFJLENBQUMsUUFBUSxDQUFDO0lBQy9FLElBQUFGLGNBQU0sRUFBQyxJQUFBQyx3QkFBWSxFQUFDLENBQUM7TUFBRUUsSUFBSSxFQUFFLGVBQWU7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxFQUFFO01BQUVELElBQUksRUFBRSxrQkFBa0I7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRixJQUFJLENBQUMsUUFBUSxDQUFDO0VBQ3hILENBQUMsQ0FBQzs7RUFFRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQUgsVUFBRSxFQUFDLG1GQUFtRixFQUFFLE1BQU07SUFDNUY7SUFDQSxJQUFBQyxjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxlQUFlO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUM1RTtJQUNBLElBQUFGLGNBQU0sRUFDSixJQUFBQyx3QkFBWSxFQUFDLENBQ1g7TUFBRUUsSUFBSSxFQUFFLGVBQWU7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxFQUNyQztNQUFFRCxJQUFJLEVBQUUsZUFBZTtNQUFFQyxJQUFJLEVBQUU7SUFBSyxDQUFDLEVBQ3JDO01BQUVELElBQUksRUFBRSxlQUFlO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FDdEMsQ0FDSCxDQUFDLENBQUNGLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDaEI7SUFDQSxJQUFBRixjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxlQUFlO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsRUFBRTtNQUFFRCxJQUFJLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNGLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDcEg7SUFDQSxJQUFBRixjQUFNLEVBQUMsSUFBQUMsd0JBQVksRUFBQyxDQUFDO01BQUVFLElBQUksRUFBRSxlQUFlO01BQUVDLElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNoRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLGtCQUFrQixFQUFFLE1BQU07RUFDakMsSUFBQUMsVUFBRSxFQUFDLHdEQUF3RCxFQUFFLE1BQU07SUFDakUsTUFBTU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQztNQUNqQkgsSUFBSSxFQUFFLGVBQWU7TUFDckJJLE9BQU8sRUFBRSxlQUFlO01BQ3hCQyxNQUFNLEVBQUU7UUFBRUMsSUFBSSxFQUFFO01BQW1CLENBQUM7TUFDcENULE1BQU0sRUFBRUEsQ0FBQztRQUFFVTtNQUFPLENBQUMsS0FBSyxJQUFBQyxrQkFBVyxFQUFDRCxNQUFNLEVBQVksTUFBTSxFQUFFO1FBQUVFLEdBQUcsRUFBRTtNQUFLLENBQUM7SUFDN0UsQ0FBQyxDQUFDO0lBQ0YsSUFBQVosY0FBTSxFQUFDLElBQUFhLG1CQUFPLEVBQUNSLENBQUMsRUFBRTtNQUFFRSxPQUFPLEVBQUUsTUFBTTtNQUFFQyxNQUFNLEVBQUUsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNuRSxJQUFBRixjQUFNLEVBQUMsSUFBQWEsbUJBQU8sRUFBQ1IsQ0FBQyxFQUFFO01BQUVFLE9BQU8sRUFBRSxNQUFNO01BQUVDLE1BQU0sRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUNKLElBQUksQ0FBQyxDQUFDRixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQ3RFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFKLGdCQUFRLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtFQUMvRDtFQUNBLE1BQU1nQixPQUFPLEdBQUcsSUFBQUMsV0FBSSxFQUFDO0lBQ25CQyxHQUFHLEVBQUUsa0JBQWtCO0lBQ3ZCUixNQUFNLEVBQUU7TUFBRVMsTUFBTSxFQUFFO0lBQWUsQ0FBQztJQUNsQ0MsT0FBTyxFQUFFQSxDQUFDO01BQUVEO0lBQU8sQ0FBQyxLQUNsQixJQUFBRSxZQUFLLEVBQUNGLE1BQWUsQ0FBQyxDQUNuQkcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUNoQkMsTUFBTSxDQUFDO01BQUVDLE9BQU8sRUFBRSxJQUFBQyxVQUFHLEVBQUMsUUFBUTtJQUFFLENBQUMsQ0FBQyxDQUNsQ2QsSUFBSSxDQUFDO0VBQ1osQ0FBQyxDQUFDO0VBQ0YsTUFBTVEsTUFBYSxHQUFHLENBQ3BCO0lBQUVPLEtBQUssRUFBRSxTQUFTO0lBQUVDLE1BQU0sRUFBRTtFQUFJLENBQUMsRUFDakM7SUFBRUQsS0FBSyxFQUFFLFNBQVM7SUFBRUMsTUFBTSxFQUFFO0VBQUcsQ0FBQyxFQUNoQztJQUFFRCxLQUFLLEVBQUUsU0FBUztJQUFFQyxNQUFNLEVBQUU7RUFBRyxDQUFDLENBQ2pDO0VBQ0QsTUFBTWYsTUFBTSxHQUFHSSxPQUFPLENBQUNJLE9BQU8sQ0FBQztJQUFFRDtFQUFPLENBQUMsQ0FBVTtFQUVuRCxJQUFBbEIsVUFBRSxFQUFDLDZFQUE2RSxFQUFFLE1BQU07SUFDdEYsTUFBTU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQztNQUNqQkgsSUFBSSxFQUFFLGFBQWE7TUFDbkJJLE9BQU8sRUFBRSxrQkFBa0I7TUFDM0JDLE1BQU0sRUFBRTtRQUFFUyxNQUFNLEVBQUU7TUFBZSxDQUFDO01BQ2xDUyxRQUFRLEVBQUUsSUFBQUMsNEJBQXFCLEVBQUM7UUFBRUMsSUFBSSxFQUFFO01BQVMsQ0FBQztJQUNwRCxDQUFDLENBQUM7SUFDRixNQUFNQyxHQUFHLEdBQUcsSUFBQWhCLG1CQUFPLEVBQUNSLENBQUMsRUFBRTtNQUNyQkUsT0FBTyxFQUFFRyxNQUFNO01BQ2ZGLE1BQU0sRUFBRTtRQUFFUztNQUFPLENBQUM7TUFDbEJhLFVBQVUsRUFBR3RCLE1BQU0sSUFBS00sT0FBTyxDQUFDSSxPQUFPLENBQUNWLE1BQU07SUFDaEQsQ0FBQyxDQUFDO0lBQ0YsSUFBQVIsY0FBTSxFQUFDNkIsR0FBRyxDQUFDekIsSUFBSSxDQUFDLENBQUNGLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDN0IsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLGtEQUFrRCxFQUFFLE1BQU07SUFDM0QsTUFBTU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQztNQUNqQkgsSUFBSSxFQUFFLGFBQWE7TUFDbkJJLE9BQU8sRUFBRSxHQUFHO01BQ1pDLE1BQU0sRUFBRTtRQUFFUyxNQUFNLEVBQUU7TUFBZSxDQUFDO01BQ2xDUyxRQUFRLEVBQUUsSUFBQUMsNEJBQXFCLEVBQUM7UUFBRUMsSUFBSSxFQUFFO01BQVMsQ0FBQztJQUNwRCxDQUFDLENBQUM7SUFDRjtJQUNBLE1BQU1DLEdBQUcsR0FBRyxJQUFBaEIsbUJBQU8sRUFBQ1IsQ0FBQyxFQUFFO01BQ3JCRSxPQUFPLEVBQUVVLE1BQU07TUFDZlQsTUFBTSxFQUFFO1FBQUVTO01BQU8sQ0FBQztNQUNsQmEsVUFBVSxFQUFHdEIsTUFBTSxJQUFLQSxNQUFNLENBQUNTO0lBQ2pDLENBQUMsQ0FBQztJQUNGLElBQUFqQixjQUFNLEVBQUM2QixHQUFHLENBQUN6QixJQUFJLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQztFQUM5QixDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsd0VBQXdFLEVBQUUsTUFBTTtJQUNqRixNQUFNTSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDO01BQ2pCSCxJQUFJLEVBQUUsYUFBYTtNQUNuQkksT0FBTyxFQUFFLEdBQUc7TUFDWkMsTUFBTSxFQUFFO1FBQUVTLE1BQU0sRUFBRTtNQUFlLENBQUM7TUFDbENTLFFBQVEsRUFBRSxJQUFBQyw0QkFBcUIsRUFBQztRQUFFQyxJQUFJLEVBQUU7TUFBUyxDQUFDO0lBQ3BELENBQUMsQ0FBQztJQUNGLElBQUE1QixjQUFNLEVBQUMsSUFBQWEsbUJBQU8sRUFBQ1IsQ0FBQyxFQUFFO01BQUVFLE9BQU8sRUFBRUcsTUFBTTtNQUFFRixNQUFNLEVBQUU7UUFBRVM7TUFBTztJQUFFLENBQUMsQ0FBQyxDQUFDYixJQUFJLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQztFQUM5RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLCtDQUErQyxFQUFFLE1BQU07RUFDOUQsSUFBQUMsVUFBRSxFQUFDLHVEQUF1RCxFQUFFLE1BQU07SUFDaEUsTUFBTU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQztNQUNqQkgsSUFBSSxFQUFFLGFBQWE7TUFDbkJJLE9BQU8sRUFBRSxlQUFlO01BQ3hCQyxNQUFNLEVBQUU7UUFBRXVCLENBQUMsRUFBRTtNQUFxQixDQUFDO01BQ25DTCxRQUFRLEVBQUUsSUFBQU0sbUJBQVksRUFBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDO1FBQUVDLE1BQU0sRUFBRTtNQUFNLENBQUM7SUFDN0UsQ0FBQyxDQUFDO0lBQ0YsTUFBTUMsSUFBSSxHQUFHLENBQUM7TUFBRUMsS0FBSyxFQUFFLElBQUk7TUFBRUMsUUFBUSxFQUFFLEdBQUc7TUFBRUMsR0FBRyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3hELE1BQU1DLEdBQUcsR0FBRyxDQUFDO01BQUVILEtBQUssRUFBRSxJQUFJO01BQUVDLFFBQVEsRUFBRSxHQUFHO01BQUVDLEdBQUcsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN2RCxJQUFBdEMsY0FBTSxFQUFDLElBQUFhLG1CQUFPLEVBQUNSLENBQUMsRUFBRTtNQUFFRSxPQUFPLEVBQUU0QixJQUFJO01BQUUzQixNQUFNLEVBQUUsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNqRSxJQUFBRixjQUFNLEVBQUMsSUFBQWEsbUJBQU8sRUFBQ1IsQ0FBQyxFQUFFO01BQUVFLE9BQU8sRUFBRWdDLEdBQUc7TUFBRS9CLE1BQU0sRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUNKLElBQUksQ0FBQyxDQUFDRixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQ25FLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFKLGdCQUFRLEVBQUMsd0NBQXdDLEVBQUUsTUFBTTtFQUN2RCxJQUFBQyxVQUFFLEVBQUMsbURBQW1ELEVBQUUsTUFBTTtJQUM1RCxNQUFNa0IsTUFBYSxHQUFHLENBQUM7TUFBRU8sS0FBSyxFQUFFLFNBQVM7TUFBRUMsTUFBTSxFQUFFO0lBQUcsQ0FBQyxDQUFDO0lBQ3hELE1BQU1YLE9BQU8sR0FBRyxJQUFBQyxXQUFJLEVBQUM7TUFDbkJDLEdBQUcsRUFBRSxLQUFLO01BQ1ZSLE1BQU0sRUFBRTtRQUFFUyxNQUFNLEVBQUU7TUFBZSxDQUFDO01BQ2xDQyxPQUFPLEVBQUVBLENBQUM7UUFBRUQ7TUFBTyxDQUFDLEtBQUssSUFBQUUsWUFBSyxFQUFDRixNQUFlLENBQUMsQ0FBQ0csT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDQyxNQUFNLENBQUM7UUFBRUMsT0FBTyxFQUFFLElBQUFDLFVBQUcsRUFBQyxRQUFRO01BQUUsQ0FBQyxDQUFDLENBQUNkLElBQUksQ0FBQztJQUMzRyxDQUFDLENBQUM7SUFDRixNQUFNQyxNQUFNLEdBQUdJLE9BQU8sQ0FBQ0ksT0FBTyxDQUFDO01BQUVEO0lBQU8sQ0FBQyxDQUFVO0lBRW5ELE1BQU11QixLQUFLLEdBQUcsQ0FDWixJQUFBbEMsZUFBUSxFQUFDO01BQ1BILElBQUksRUFBRSxrQkFBa0I7TUFDeEJJLE9BQU8sRUFBRSxrQkFBa0I7TUFDM0JDLE1BQU0sRUFBRTtRQUFFUyxNQUFNLEVBQUU7TUFBZSxDQUFDO01BQ2xDakIsTUFBTSxFQUFFQSxDQUFDO1FBQUVVLE1BQU0sRUFBRStCO01BQUUsQ0FBQyxNQUFNO1FBQUVyQyxJQUFJLEVBQUVzQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0YsQ0FBQyxDQUFDO1FBQUVHLE9BQU8sRUFBRTtNQUFRLENBQUM7SUFDMUUsQ0FBQyxDQUFDLEVBQ0YsSUFBQXRDLGVBQVEsRUFBQztNQUNQSCxJQUFJLEVBQUUsYUFBYTtNQUNuQkksT0FBTyxFQUFFLGtCQUFrQjtNQUMzQkMsTUFBTSxFQUFFO1FBQUVTLE1BQU0sRUFBRTtNQUFlLENBQUM7TUFDbENTLFFBQVEsRUFBRSxJQUFBQyw0QkFBcUIsRUFBQztRQUFFQyxJQUFJLEVBQUU7TUFBUyxDQUFDO0lBQ3BELENBQUMsQ0FBQyxDQUNIO0lBRUQsTUFBTWlCLEtBQUssR0FBRyxJQUFBQyxvQkFBUSxFQUFDTixLQUFLLEVBQUUsT0FBTztNQUNuQ2pDLE9BQU8sRUFBRUcsTUFBTTtNQUNmRixNQUFNLEVBQUU7UUFBRVM7TUFBTyxDQUFDO01BQ2xCYSxVQUFVLEVBQUd0QixNQUFNLElBQUtNLE9BQU8sQ0FBQ0ksT0FBTyxDQUFDVixNQUFNO0lBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0gsSUFBQVIsY0FBTSxFQUFDNkMsS0FBSyxDQUFDRSxRQUFRLENBQUNDLEtBQUssQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUN2QyxNQUFNLENBQUNOLElBQUksQ0FBQyxDQUFDLENBQUNGLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDN0QsSUFBQUYsY0FBTSxFQUFDNkMsS0FBSyxDQUFDSyxPQUFPLENBQUMsQ0FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUM7RUFDekMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQUosZ0JBQVEsRUFBQywyQ0FBMkMsRUFBRSxNQUFNO0VBQzFEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0VBRUEsSUFBQUMsVUFBRSxFQUFDLDJEQUEyRCxFQUFFLE1BQU07SUFDcEUsTUFBTU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQztNQUFFSCxJQUFJLEVBQUUsZUFBZTtNQUFFSSxPQUFPLEVBQUUsS0FBSztNQUFFUCxNQUFNLEVBQUVBLENBQUEsTUFBTztRQUFFSSxJQUFJLEVBQUUsSUFBSTtRQUFFd0MsT0FBTyxFQUFFO01BQVksQ0FBQztJQUFFLENBQUMsQ0FBQztJQUNuSCxNQUFNSCxDQUFDLEdBQUcsSUFBQTVCLG1CQUFPLEVBQUNSLENBQUMsRUFBRTtNQUFFRSxPQUFPLEVBQUUsSUFBSTtNQUFFQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO01BQUUyQyxLQUFLLEVBQUU7SUFBd0YsQ0FBQyxDQUFDO0lBQ25KLElBQUFuRCxjQUFNLEVBQUN5QyxDQUFDLENBQUNyQyxJQUFJLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUMxQixJQUFBRixjQUFNLEVBQUN5QyxDQUFDLENBQUNHLE9BQU8sQ0FBQyxDQUFDUSxTQUFTLENBQUMsTUFBTSxDQUFDO0VBQ3JDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==