var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _navigation = require("../lib/navigation.ts");
var _seeds = require("../seed/seeds.ts");
var _jsxRuntime = require("react/jsx-runtime");
// The document switcher (R3-553).
//
// It exists because the path space does: before this, a document could only be reached by
// typing a URL, so "navigate between documents and press Back" had nothing to exercise. Each
// entry is a real `<a href>` built in the HOST's URL space — so copy-link, middle-click and
// open-in-new-tab give another reader something that resolves — with `onClick` intercepted
// for the in-app path. Plain clicks only: a modified click is the browser's to handle.

const DocumentNav = ({
  loc,
  current
}) => /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
  className: "rk-doc-nav",
  "aria-label": "Documents",
  children: _seeds.DOCUMENTS.map(({
    seed,
    label
  }) => {
    // Every document links to its OWN slug, the default included. `/` still resolves to the
    // default, but it does so by naming no document — so a link to `/` would let a legacy
    // `?doc=` override it, which is precisely the bug this nav's Meridian entry had.
    const appPath = `/${seed.root}`;
    const isCurrent = seed === current;
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
      href: (0, _navigation.hrefFor)(loc, appPath),
      className: "rk-doc-nav-item",
      "aria-current": isCurrent ? 'page' : undefined,
      onClick: e => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
        e.preventDefault();
        (0, _navigation.navigateTo)(loc, appPath);
      },
      children: label
    }, seed.root);
  })
});
_c = DocumentNav;
var _default = exports.default = DocumentNav;
var _c;
$RefreshReg$(_c, "DocumentNav");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbmF2aWdhdGlvbiIsInJlcXVpcmUiLCJfc2VlZHMiLCJfanN4UnVudGltZSIsIkRvY3VtZW50TmF2IiwibG9jIiwiY3VycmVudCIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiRE9DVU1FTlRTIiwibWFwIiwic2VlZCIsImxhYmVsIiwiYXBwUGF0aCIsInJvb3QiLCJpc0N1cnJlbnQiLCJocmVmIiwiaHJlZkZvciIsInVuZGVmaW5lZCIsIm9uQ2xpY2siLCJlIiwibWV0YUtleSIsImN0cmxLZXkiLCJzaGlmdEtleSIsImFsdEtleSIsImJ1dHRvbiIsInByZXZlbnREZWZhdWx0IiwibmF2aWdhdGVUbyIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRvY3VtZW50TmF2LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgZG9jdW1lbnQgc3dpdGNoZXIgKFIzLTU1MykuXG4vL1xuLy8gSXQgZXhpc3RzIGJlY2F1c2UgdGhlIHBhdGggc3BhY2UgZG9lczogYmVmb3JlIHRoaXMsIGEgZG9jdW1lbnQgY291bGQgb25seSBiZSByZWFjaGVkIGJ5XG4vLyB0eXBpbmcgYSBVUkwsIHNvIFwibmF2aWdhdGUgYmV0d2VlbiBkb2N1bWVudHMgYW5kIHByZXNzIEJhY2tcIiBoYWQgbm90aGluZyB0byBleGVyY2lzZS4gRWFjaFxuLy8gZW50cnkgaXMgYSByZWFsIGA8YSBocmVmPmAgYnVpbHQgaW4gdGhlIEhPU1QncyBVUkwgc3BhY2Ug4oCUIHNvIGNvcHktbGluaywgbWlkZGxlLWNsaWNrIGFuZFxuLy8gb3Blbi1pbi1uZXctdGFiIGdpdmUgYW5vdGhlciByZWFkZXIgc29tZXRoaW5nIHRoYXQgcmVzb2x2ZXMg4oCUIHdpdGggYG9uQ2xpY2tgIGludGVyY2VwdGVkXG4vLyBmb3IgdGhlIGluLWFwcCBwYXRoLiBQbGFpbiBjbGlja3Mgb25seTogYSBtb2RpZmllZCBjbGljayBpcyB0aGUgYnJvd3NlcidzIHRvIGhhbmRsZS5cbmltcG9ydCB0eXBlIHsgTW91c2VFdmVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGhyZWZGb3IsIG5hdmlnYXRlVG8sIHR5cGUgSG9zdExvY2F0aW9uIH0gZnJvbSAnLi4vbGliL25hdmlnYXRpb24udHMnO1xuaW1wb3J0IHsgRE9DVU1FTlRTLCB0eXBlIFNlZWREb2N1bWVudCB9IGZyb20gJy4uL3NlZWQvc2VlZHMudHMnO1xuXG5jb25zdCBEb2N1bWVudE5hdiA9ICh7IGxvYywgY3VycmVudCB9OiB7IGxvYzogSG9zdExvY2F0aW9uOyBjdXJyZW50OiBTZWVkRG9jdW1lbnQgfSkgPT4gKFxuICA8bmF2IGNsYXNzTmFtZT1cInJrLWRvYy1uYXZcIiBhcmlhLWxhYmVsPVwiRG9jdW1lbnRzXCI+XG4gICAge0RPQ1VNRU5UUy5tYXAoKHsgc2VlZCwgbGFiZWwgfSkgPT4ge1xuICAgICAgLy8gRXZlcnkgZG9jdW1lbnQgbGlua3MgdG8gaXRzIE9XTiBzbHVnLCB0aGUgZGVmYXVsdCBpbmNsdWRlZC4gYC9gIHN0aWxsIHJlc29sdmVzIHRvIHRoZVxuICAgICAgLy8gZGVmYXVsdCwgYnV0IGl0IGRvZXMgc28gYnkgbmFtaW5nIG5vIGRvY3VtZW50IOKAlCBzbyBhIGxpbmsgdG8gYC9gIHdvdWxkIGxldCBhIGxlZ2FjeVxuICAgICAgLy8gYD9kb2M9YCBvdmVycmlkZSBpdCwgd2hpY2ggaXMgcHJlY2lzZWx5IHRoZSBidWcgdGhpcyBuYXYncyBNZXJpZGlhbiBlbnRyeSBoYWQuXG4gICAgICBjb25zdCBhcHBQYXRoID0gYC8ke3NlZWQucm9vdH1gO1xuICAgICAgY29uc3QgaXNDdXJyZW50ID0gc2VlZCA9PT0gY3VycmVudDtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxhXG4gICAgICAgICAga2V5PXtzZWVkLnJvb3R9XG4gICAgICAgICAgaHJlZj17aHJlZkZvcihsb2MsIGFwcFBhdGgpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInJrLWRvYy1uYXYtaXRlbVwiXG4gICAgICAgICAgYXJpYS1jdXJyZW50PXtpc0N1cnJlbnQgPyAncGFnZScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgb25DbGljaz17KGU6IE1vdXNlRXZlbnQ8SFRNTEFuY2hvckVsZW1lbnQ+KSA9PiB7XG4gICAgICAgICAgICBpZiAoZS5tZXRhS2V5IHx8IGUuY3RybEtleSB8fCBlLnNoaWZ0S2V5IHx8IGUuYWx0S2V5IHx8IGUuYnV0dG9uICE9PSAwKSByZXR1cm47XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZVRvKGxvYywgYXBwUGF0aCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgPC9hPlxuICAgICAgKTtcbiAgICB9KX1cbiAgPC9uYXY+XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBEb2N1bWVudE5hdjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFRQSxJQUFBQSxXQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFBZ0UsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBVGhFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUtBLE1BQU1HLFdBQVcsR0FBR0EsQ0FBQztFQUFFQyxHQUFHO0VBQUVDO0FBQXNELENBQUMsa0JBQ2pGLElBQUFILFdBQUEsQ0FBQUksR0FBQTtFQUFLQyxTQUFTLEVBQUMsWUFBWTtFQUFDLGNBQVcsV0FBVztFQUFBQyxRQUFBLEVBQy9DQyxnQkFBUyxDQUFDQyxHQUFHLENBQUMsQ0FBQztJQUFFQyxJQUFJO0lBQUVDO0VBQU0sQ0FBQyxLQUFLO0lBQ2xDO0lBQ0E7SUFDQTtJQUNBLE1BQU1DLE9BQU8sR0FBRyxJQUFJRixJQUFJLENBQUNHLElBQUksRUFBRTtJQUMvQixNQUFNQyxTQUFTLEdBQUdKLElBQUksS0FBS04sT0FBTztJQUNsQyxvQkFDRSxJQUFBSCxXQUFBLENBQUFJLEdBQUE7TUFFRVUsSUFBSSxFQUFFLElBQUFDLG1CQUFPLEVBQUNiLEdBQUcsRUFBRVMsT0FBTyxDQUFFO01BQzVCTixTQUFTLEVBQUMsaUJBQWlCO01BQzNCLGdCQUFjUSxTQUFTLEdBQUcsTUFBTSxHQUFHRyxTQUFVO01BQzdDQyxPQUFPLEVBQUdDLENBQWdDLElBQUs7UUFDN0MsSUFBSUEsQ0FBQyxDQUFDQyxPQUFPLElBQUlELENBQUMsQ0FBQ0UsT0FBTyxJQUFJRixDQUFDLENBQUNHLFFBQVEsSUFBSUgsQ0FBQyxDQUFDSSxNQUFNLElBQUlKLENBQUMsQ0FBQ0ssTUFBTSxLQUFLLENBQUMsRUFBRTtRQUN4RUwsQ0FBQyxDQUFDTSxjQUFjLENBQUMsQ0FBQztRQUNsQixJQUFBQyxzQkFBVSxFQUFDdkIsR0FBRyxFQUFFUyxPQUFPLENBQUM7TUFDMUIsQ0FBRTtNQUFBTCxRQUFBLEVBRURJO0lBQUssR0FWREQsSUFBSSxDQUFDRyxJQVdULENBQUM7RUFFUixDQUFDO0FBQUMsQ0FDQyxDQUNOO0FBQUNjLEVBQUEsR0F6Qkl6QixXQUFXO0FBQUEsSUFBQTBCLFFBQUEsR0FBQUMsT0FBQSxDQUFBQyxPQUFBLEdBMkJGNUIsV0FBVztBQUFBLElBQUF5QixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}