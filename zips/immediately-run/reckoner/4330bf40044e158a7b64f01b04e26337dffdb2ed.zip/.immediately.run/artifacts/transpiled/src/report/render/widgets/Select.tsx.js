var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Select;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _attrs = require("../attrs.ts");
var _useParam = require("./useParam.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Select widget — writes a `params.<name>` from a closed literal `options` list (§3.3). The
// declared options double as validation: the widget can only produce values from its set.
function Select({
  node
}) {
  _s();
  const name = (0, _attrs.attrString)(node, 'name') ?? '';
  const options = (0, _attrs.attrStringArray)(node, 'options');
  const def = (0, _attrs.attrString)(node, 'default') ?? options[0] ?? '';
  const {
    value,
    set
  } = (0, _useParam.useParam)(name, def);
  const current = typeof value === 'string' ? value : def;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
    className: "rk-widget rk-widget-select",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rk-widget-label",
      children: name
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("select", {
      value: current,
      onChange: e => set(e.target.value),
      children: options.map(o => /*#__PURE__*/(0, _jsxRuntime.jsx)("option", {
        value: o,
        children: o
      }, o))
    })]
  });
}
_s(Select, "P5g961Dx7UfkNf2t68spDCPaBwI=", false, function () {
  return [_useParam.useParam];
});
_c = Select;
var _c;
$RefreshReg$(_c, "Select");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3VzZVBhcmFtIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlNlbGVjdCIsIm5vZGUiLCJuYW1lIiwiYXR0clN0cmluZyIsIm9wdGlvbnMiLCJhdHRyU3RyaW5nQXJyYXkiLCJkZWYiLCJ2YWx1ZSIsInNldCIsInVzZVBhcmFtIiwiY3VycmVudCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsIm1hcCIsIm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNlbGVjdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gU2VsZWN0IHdpZGdldCDigJQgd3JpdGVzIGEgYHBhcmFtcy48bmFtZT5gIGZyb20gYSBjbG9zZWQgbGl0ZXJhbCBgb3B0aW9uc2AgbGlzdCAowqczLjMpLiBUaGVcbi8vIGRlY2xhcmVkIG9wdGlvbnMgZG91YmxlIGFzIHZhbGlkYXRpb246IHRoZSB3aWRnZXQgY2FuIG9ubHkgcHJvZHVjZSB2YWx1ZXMgZnJvbSBpdHMgc2V0LlxuaW1wb3J0IHR5cGUgeyBDb21wb25lbnROb2RlIH0gZnJvbSAnLi4vLi4vbm9kZXMudHMnO1xuaW1wb3J0IHsgYXR0clN0cmluZywgYXR0clN0cmluZ0FycmF5IH0gZnJvbSAnLi4vYXR0cnMudHMnO1xuaW1wb3J0IHsgdXNlUGFyYW0gfSBmcm9tICcuL3VzZVBhcmFtLnRzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VsZWN0KHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCBuYW1lID0gYXR0clN0cmluZyhub2RlLCAnbmFtZScpID8/ICcnO1xuICBjb25zdCBvcHRpb25zID0gYXR0clN0cmluZ0FycmF5KG5vZGUsICdvcHRpb25zJyk7XG4gIGNvbnN0IGRlZiA9IGF0dHJTdHJpbmcobm9kZSwgJ2RlZmF1bHQnKSA/PyBvcHRpb25zWzBdID8/ICcnO1xuICBjb25zdCB7IHZhbHVlLCBzZXQgfSA9IHVzZVBhcmFtKG5hbWUsIGRlZik7XG4gIGNvbnN0IGN1cnJlbnQgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gdmFsdWUgOiBkZWY7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIGNsYXNzTmFtZT1cInJrLXdpZGdldCByay13aWRnZXQtc2VsZWN0XCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay13aWRnZXQtbGFiZWxcIj57bmFtZX08L3NwYW4+XG4gICAgICA8c2VsZWN0IHZhbHVlPXtjdXJyZW50fSBvbkNoYW5nZT17KGUpID0+IHNldChlLnRhcmdldC52YWx1ZSl9PlxuICAgICAgICB7b3B0aW9ucy5tYXAoKG8pID0+IChcbiAgICAgICAgICA8b3B0aW9uIGtleT17b30gdmFsdWU9e299PlxuICAgICAgICAgICAge299XG4gICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICkpfVxuICAgICAgPC9zZWxlY3Q+XG4gICAgPC9sYWJlbD5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFHQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFBeUMsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBSnpDO0FBQ0E7QUFLZSxTQUFTQyxNQUFNQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBSCxFQUFBO0VBQ2hFLE1BQU1JLElBQUksR0FBRyxJQUFBQyxpQkFBVSxFQUFDRixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRTtFQUMzQyxNQUFNRyxPQUFPLEdBQUcsSUFBQUMsc0JBQWUsRUFBQ0osSUFBSSxFQUFFLFNBQVMsQ0FBQztFQUNoRCxNQUFNSyxHQUFHLEdBQUcsSUFBQUgsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtFQUMzRCxNQUFNO0lBQUVHLEtBQUs7SUFBRUM7RUFBSSxDQUFDLEdBQUcsSUFBQUMsa0JBQVEsRUFBQ1AsSUFBSSxFQUFFSSxHQUFHLENBQUM7RUFDMUMsTUFBTUksT0FBTyxHQUFHLE9BQU9ILEtBQUssS0FBSyxRQUFRLEdBQUdBLEtBQUssR0FBR0QsR0FBRztFQUN2RCxvQkFDRSxJQUFBVCxXQUFBLENBQUFjLElBQUE7SUFBT0MsU0FBUyxFQUFDLDRCQUE0QjtJQUFBQyxRQUFBLGdCQUMzQyxJQUFBaEIsV0FBQSxDQUFBaUIsR0FBQTtNQUFNRixTQUFTLEVBQUMsaUJBQWlCO01BQUFDLFFBQUEsRUFBRVg7SUFBSSxDQUFPLENBQUMsZUFDL0MsSUFBQUwsV0FBQSxDQUFBaUIsR0FBQTtNQUFRUCxLQUFLLEVBQUVHLE9BQVE7TUFBQ0ssUUFBUSxFQUFHQyxDQUFDLElBQUtSLEdBQUcsQ0FBQ1EsQ0FBQyxDQUFDQyxNQUFNLENBQUNWLEtBQUssQ0FBRTtNQUFBTSxRQUFBLEVBQzFEVCxPQUFPLENBQUNjLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDYixJQUFBdEIsV0FBQSxDQUFBaUIsR0FBQTtRQUFnQlAsS0FBSyxFQUFFWSxDQUFFO1FBQUFOLFFBQUEsRUFDdEJNO01BQUMsR0FEU0EsQ0FFTCxDQUNUO0lBQUMsQ0FDSSxDQUFDO0VBQUEsQ0FDSixDQUFDO0FBRVo7QUFBQ3JCLEVBQUEsQ0FsQnVCRSxNQUFNO0VBQUEsUUFJTFMsa0JBQVE7QUFBQTtBQUFBVyxFQUFBLEdBSlRwQixNQUFNO0FBQUEsSUFBQW9CLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}