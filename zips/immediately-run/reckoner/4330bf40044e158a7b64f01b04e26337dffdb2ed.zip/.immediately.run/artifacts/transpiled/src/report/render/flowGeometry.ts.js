"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MAX_FLOW_NODES = exports.MAX_FLOW_EDGES = exports.FLOW_TONES = exports.FLOW_SHAPES = exports.FLOW_MARGIN = exports.DEFAULT_NODE_W = exports.DEFAULT_NODE_H = exports.BUFFER_TRIANGLE_W = void 0;
exports.anchors = anchors;
exports.annotationLayout = annotationLayout;
exports.flowAriaLabel = flowAriaLabel;
exports.parseVia = parseVia;
exports.pathD = pathD;
exports.planFlow = planFlow;
exports.pointAt = pointAt;
exports.polyline = polyline;
exports.polylineLength = polylineLength;
exports.readFlow = readFlow;
exports.viewBox = viewBox;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.flat-map.js");
require("core-js/modules/esnext.iterator.map.js");
// Flow — the pure half of the data-positioned node/edge diagram (ARCHITECTURE_PLAN §3.3).
// Layout comes from the data: every node carries its own top-left `x,y` in diagram units and
// every edge its own optional waypoints, so there is no auto-layout, no force simulation and
// no layout library — the template never computes (§3.3.1 "never an expression") and the
// drawing is stable across captures. This module turns the two bound tables into a checked
// model (loud on any malformed row — never a partial silent drawing) and does the geometry:
// `via` parsing, anchor choice, the polyline, its length, the point at a fraction along it,
// the annotation layout and the viewBox. No React; unit-tested directly.

const FLOW_SHAPES = exports.FLOW_SHAPES = ['box', 'pill', 'diamond', 'note'];
const FLOW_TONES = exports.FLOW_TONES = ['agent', 'operator', 'owner', 'ci', 'neutral'];
/** Size and count caps: a diagram past these is a broken tile, not a hairball. */
const MAX_FLOW_NODES = exports.MAX_FLOW_NODES = 80;
const MAX_FLOW_EDGES = exports.MAX_FLOW_EDGES = 160;
const DEFAULT_NODE_W = exports.DEFAULT_NODE_W = 140;
const DEFAULT_NODE_H = exports.DEFAULT_NODE_H = 56;
/** The viewBox margin around every node, waypoint and annotation. */
const FLOW_MARGIN = exports.FLOW_MARGIN = 24;
/** The value-stream-map inventory triangle's width (diagram units). */
const BUFFER_TRIANGLE_W = exports.BUFFER_TRIANGLE_W = 22;
// ── via ──────────────────────────────────────────────────────────────────────────────

/** Parse `via` — whitespace-separated `x,y` pairs (diagram units). Empty/absent → no waypoints. */
function parseVia(via) {
  if (via === undefined || via.trim() === '') return {
    ok: true,
    data: []
  };
  const points = [];
  for (const pair of via.trim().split(/\s+/)) {
    const m = /^(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/.exec(pair);
    if (m === null) return {
      ok: false,
      reason: `malformed waypoint "${pair}" (expected "x,y")`
    };
    points.push({
      x: Number(m[1]),
      y: Number(m[2])
    });
  }
  return {
    ok: true,
    data: points
  };
}

// ── row checking ─────────────────────────────────────────────────────────────────────

const isNum = v => typeof v === 'number' && Number.isFinite(v);
const absent = v => v === undefined || v === null;
function optionalNumber(row, key) {
  const v = row[key];
  if (absent(v)) return {
    ok: true,
    data: undefined
  };
  return isNum(v) ? {
    ok: true,
    data: v
  } : {
    ok: false,
    reason: `"${key}" is not a number`
  };
}
function optionalString(row, key) {
  const v = row[key];
  if (absent(v)) return {
    ok: true,
    data: undefined
  };
  return typeof v === 'string' ? {
    ok: true,
    data: v
  } : {
    ok: false,
    reason: `"${key}" is not a string`
  };
}
function optionalBool(row, key) {
  const v = row[key];
  if (absent(v)) return {
    ok: true,
    data: false
  };
  return typeof v === 'boolean' ? {
    ok: true,
    data: v
  } : {
    ok: false,
    reason: `"${key}" is not true/false`
  };
}
function optionalEnum(row, key, values, fallback) {
  const v = row[key];
  if (absent(v)) return {
    ok: true,
    data: fallback
  };
  return typeof v === 'string' && values.includes(v) ? {
    ok: true,
    data: v
  } : {
    ok: false,
    reason: `"${key}" must be one of ${values.join(', ')}`
  };
}
function checkNode(row, i) {
  const where = typeof row.id === 'string' && row.id !== '' ? `node "${row.id}"` : `node row ${i + 1}`;
  const fail = reason => ({
    ok: false,
    reason: `${where}: ${reason}`
  });
  if (typeof row.id !== 'string' || row.id === '') return fail('missing "id"');
  if (absent(row.x)) return fail('missing "x"');
  if (absent(row.y)) return fail('missing "y"');
  if (!isNum(row.x)) return fail('"x" is not a number');
  if (!isNum(row.y)) return fail('"y" is not a number');
  const label = optionalString(row, 'label');
  if (!label.ok) return fail(label.reason);
  const sub = optionalString(row, 'sub');
  if (!sub.ok) return fail(sub.reason);
  const w = optionalNumber(row, 'w');
  if (!w.ok) return fail(w.reason);
  const h = optionalNumber(row, 'h');
  if (!h.ok) return fail(h.reason);
  if (w.data !== undefined && w.data <= 0 || h.data !== undefined && h.data <= 0) return fail('"w"/"h" must be positive');
  const shape = optionalEnum(row, 'shape', FLOW_SHAPES, 'box');
  if (!shape.ok) return fail(shape.reason);
  const tone = optionalEnum(row, 'tone', FLOW_TONES, 'neutral');
  if (!tone.ok) return fail(tone.reason);
  return {
    ok: true,
    data: {
      id: row.id,
      label: label.data ?? row.id,
      ...(sub.data !== undefined ? {
        sub: sub.data
      } : {}),
      x: row.x,
      y: row.y,
      w: w.data ?? DEFAULT_NODE_W,
      h: h.data ?? DEFAULT_NODE_H,
      shape: shape.data,
      tone: tone.data
    }
  };
}
function checkEdge(row, i, ids) {
  const named = typeof row.from === 'string' && typeof row.to === 'string';
  const where = named ? `edge ${String(row.from)} → ${String(row.to)}` : `edge row ${i + 1}`;
  const fail = reason => ({
    ok: false,
    reason: `${where}: ${reason}`
  });
  if (typeof row.from !== 'string' || row.from === '') return fail('missing "from"');
  if (typeof row.to !== 'string' || row.to === '') return fail('missing "to"');
  if (!ids.has(row.from)) return fail(`unknown node id "${row.from}"`);
  if (!ids.has(row.to)) return fail(`unknown node id "${row.to}"`);
  const viaStr = optionalString(row, 'via');
  if (!viaStr.ok) return fail(viaStr.reason);
  const via = parseVia(viaStr.data);
  if (!via.ok) return fail(via.reason);
  const label = optionalString(row, 'label');
  if (!label.ok) return fail(label.reason);
  const rawValue = row.value;
  if (!absent(rawValue) && typeof rawValue !== 'string' && !isNum(rawValue)) return fail('"value" must be text or a number');
  const tone = optionalEnum(row, 'tone', FLOW_TONES, 'neutral');
  if (!tone.ok) return fail(tone.reason);
  const alert = optionalBool(row, 'alert');
  if (!alert.ok) return fail(alert.reason);
  const dashed = optionalBool(row, 'dashed');
  if (!dashed.ok) return fail(dashed.reason);
  const buffer = optionalBool(row, 'buffer');
  if (!buffer.ok) return fail(buffer.reason);
  const at = optionalNumber(row, 'at');
  if (!at.ok) return fail(at.reason);
  if (at.data !== undefined && (at.data < 0 || at.data > 1)) return fail('"at" must be between 0 and 1');
  return {
    ok: true,
    data: {
      from: row.from,
      to: row.to,
      via: via.data,
      ...(label.data !== undefined ? {
        label: label.data
      } : {}),
      ...(!absent(rawValue) ? {
        value: String(rawValue)
      } : {}),
      tone: tone.data,
      alert: alert.data,
      dashed: dashed.data,
      at: at.data ?? 0.5,
      buffer: buffer.data
    }
  };
}

/**
 * Check both tables into a `FlowModel`. The first offending row (by id where it has one)
 * is the reason; there is no partial result.
 */
function readFlow(nodeRows, edgeRows) {
  if (nodeRows.length === 0) return {
    ok: false,
    reason: 'no nodes to draw'
  };
  if (nodeRows.length > MAX_FLOW_NODES) return {
    ok: false,
    reason: `${nodeRows.length} nodes exceeds the ${MAX_FLOW_NODES}-node cap`
  };
  if (edgeRows.length > MAX_FLOW_EDGES) return {
    ok: false,
    reason: `${edgeRows.length} edges exceeds the ${MAX_FLOW_EDGES}-edge cap`
  };
  const nodes = [];
  const ids = new Set();
  for (let i = 0; i < nodeRows.length; i++) {
    const n = checkNode(nodeRows[i], i);
    if (!n.ok) return n;
    if (ids.has(n.data.id)) return {
      ok: false,
      reason: `node "${n.data.id}": duplicate id`
    };
    ids.add(n.data.id);
    nodes.push(n.data);
  }
  const edges = [];
  for (let i = 0; i < edgeRows.length; i++) {
    const e = checkEdge(edgeRows[i], i, ids);
    if (!e.ok) return e;
    edges.push(e.data);
  }
  return {
    ok: true,
    data: {
      nodes,
      edges
    }
  };
}

// ── geometry ─────────────────────────────────────────────────────────────────────────

/**
 * The edge's two anchors. The end is always the target's left-middle. The start is the
 * source's right-middle — except when the target lies wholly below the source and not
 * wholly to its right (`to.y ≥ from.y + from.h` and `to.x < from.x + from.w`), where it
 * leaves from the source's bottom-middle (a drop to the next row). Any other routing is
 * the author's, through `via`.
 */
function anchors(from, to) {
  const toRight = to.x >= from.x + from.w;
  const below = to.y >= from.y + from.h;
  const start = !toRight && below ? {
    x: from.x + from.w / 2,
    y: from.y + from.h
  } : {
    x: from.x + from.w,
    y: from.y + from.h / 2
  };
  return {
    start,
    end: {
      x: to.x,
      y: to.y + to.h / 2
    }
  };
}

/** The polyline: start anchor → waypoints → end anchor, straight segments between them. */
function polyline(from, to, via) {
  const {
    start,
    end
  } = anchors(from, to);
  return [start, ...via, end];
}
function polylineLength(points) {
  let total = 0;
  for (let i = 1; i < points.length; i++) total += Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
  return total;
}

/** The point at fraction `t` (clamped to [0,1]) of the polyline's length. */
function pointAt(points, t) {
  if (points.length === 0) return {
    x: 0,
    y: 0
  };
  const total = polylineLength(points);
  if (total === 0) return {
    ...points[0]
  };
  let remaining = Math.max(0, Math.min(1, t)) * total;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    const seg = Math.hypot(b.x - a.x, b.y - a.y);
    if (remaining <= seg && seg > 0) {
      const f = remaining / seg;
      return {
        x: a.x + (b.x - a.x) * f,
        y: a.y + (b.y - a.y) * f
      };
    }
    remaining -= seg;
  }
  return {
    ...points[points.length - 1]
  };
}

/** The SVG path `d` for a polyline. */
function pathD(points) {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'}${round(p.x)} ${round(p.y)}`).join(' ');
}
const round = n => Math.round(n * 100) / 100;

/** A rough text width (diagram units) — enough to keep annotations inside the viewBox. */
const CHAR_W = 7;
/**
 * Where an annotation's parts go around its anchor point `p`. Plain annotation: label and
 * value stacked just above the line. Buffer: an inventory triangle (apex up,
 * `BUFFER_TRIANGLE_W` wide) centered on the line with the text stacked beneath it.
 */
function annotationLayout(p, a) {
  const lines = [a.label, a.value].filter(s => s !== undefined && s !== '');
  const textW = Math.max(0, ...lines.map(s => s.length * CHAR_W));
  const halfW = Math.max(a.buffer ? BUFFER_TRIANGLE_W / 2 : 0, textW / 2);
  if (a.buffer) {
    const half = BUFFER_TRIANGLE_W / 2;
    const triangle = `${round(p.x)},${round(p.y - 10)} ${round(p.x + half)},${round(p.y + 9)} ${round(p.x - half)},${round(p.y + 9)}`;
    let y = p.y + 9;
    const labelY = a.label ? y += 15 : undefined;
    const valueY = a.value !== undefined && a.value !== '' ? y += 15 : undefined;
    return {
      triangle,
      labelY,
      valueY,
      x: p.x,
      box: {
        x0: p.x - halfW,
        y0: p.y - 10,
        x1: p.x + halfW,
        y1: y + 4
      }
    };
  }
  const hasValue = a.value !== undefined && a.value !== '';
  const valueY = hasValue ? p.y - 6 : undefined;
  const labelY = a.label ? hasValue ? p.y - 21 : p.y - 6 : undefined;
  const top = (labelY ?? valueY ?? p.y) - 12;
  return {
    labelY,
    valueY,
    x: p.x,
    box: {
      x0: p.x - halfW,
      y0: top,
      x1: p.x + halfW,
      y1: p.y
    }
  };
}
/** The bounding box of all nodes, all polyline points and all annotation extents, plus `FLOW_MARGIN`. */
function viewBox(nodes, polylines, annotations) {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  const add = (ax, ay, bx, by) => {
    x0 = Math.min(x0, ax);
    y0 = Math.min(y0, ay);
    x1 = Math.max(x1, bx);
    y1 = Math.max(y1, by);
  };
  for (const n of nodes) add(n.x, n.y, n.x + n.w, n.y + n.h);
  for (const line of polylines) for (const p of line) add(p.x, p.y, p.x, p.y);
  for (const a of annotations) add(a.box.x0, a.box.y0, a.box.x1, a.box.y1);
  if (!Number.isFinite(x0)) return {
    x: 0,
    y: 0,
    w: FLOW_MARGIN * 2,
    h: FLOW_MARGIN * 2
  };
  return {
    x: x0 - FLOW_MARGIN,
    y: y0 - FLOW_MARGIN,
    w: x1 - x0 + FLOW_MARGIN * 2,
    h: y1 - y0 + FLOW_MARGIN * 2
  };
}

/** The full drawing plan for a checked model — what the component renders, pure. */

function planFlow(model) {
  const byId = new Map(model.nodes.map(n => [n.id, n]));
  const edges = model.edges.map(edge => {
    const points = polyline(byId.get(edge.from), byId.get(edge.to), edge.via);
    const annotated = edge.buffer || (edge.label ?? '') !== '' || (edge.value ?? '') !== '';
    const annotation = annotated ? annotationLayout(pointAt(points, edge.at), edge) : undefined;
    return {
      edge,
      points,
      d: pathD(points),
      ...(annotation ? {
        annotation
      } : {})
    };
  });
  const vb = viewBox(model.nodes, edges.map(e => e.points), edges.flatMap(e => e.annotation ? [e.annotation] : []));
  return {
    nodes: model.nodes,
    edges,
    viewBox: vb
  };
}

/** The screen-reader text: title, then each annotated edge as "from → to: label value". */
function flowAriaLabel(title, plan) {
  const byId = new Map(plan.nodes.map(n => [n.id, n.label]));
  const head = `${title ?? 'Flow diagram'}: ${plan.nodes.length} ${plan.nodes.length === 1 ? 'node' : 'nodes'}, ${plan.edges.length} ${plan.edges.length === 1 ? 'connection' : 'connections'}.`;
  const notes = plan.edges.filter(e => e.annotation !== undefined).map(({
    edge
  }) => {
    const text = [edge.label, edge.value].filter(s => s !== undefined && s !== '').join(' ');
    return `${byId.get(edge.from)} → ${byId.get(edge.to)}: ${text}${edge.alert ? ' (alert)' : ''}`;
  });
  return notes.length === 0 ? head : `${head} ${notes.join('; ')}.`;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJGTE9XX1NIQVBFUyIsImV4cG9ydHMiLCJGTE9XX1RPTkVTIiwiTUFYX0ZMT1dfTk9ERVMiLCJNQVhfRkxPV19FREdFUyIsIkRFRkFVTFRfTk9ERV9XIiwiREVGQVVMVF9OT0RFX0giLCJGTE9XX01BUkdJTiIsIkJVRkZFUl9UUklBTkdMRV9XIiwicGFyc2VWaWEiLCJ2aWEiLCJ1bmRlZmluZWQiLCJ0cmltIiwib2siLCJkYXRhIiwicG9pbnRzIiwicGFpciIsInNwbGl0IiwibSIsImV4ZWMiLCJyZWFzb24iLCJwdXNoIiwieCIsIk51bWJlciIsInkiLCJpc051bSIsInYiLCJpc0Zpbml0ZSIsImFic2VudCIsIm9wdGlvbmFsTnVtYmVyIiwicm93Iiwia2V5Iiwib3B0aW9uYWxTdHJpbmciLCJvcHRpb25hbEJvb2wiLCJvcHRpb25hbEVudW0iLCJ2YWx1ZXMiLCJmYWxsYmFjayIsImluY2x1ZGVzIiwiam9pbiIsImNoZWNrTm9kZSIsImkiLCJ3aGVyZSIsImlkIiwiZmFpbCIsImxhYmVsIiwic3ViIiwidyIsImgiLCJzaGFwZSIsInRvbmUiLCJjaGVja0VkZ2UiLCJpZHMiLCJuYW1lZCIsImZyb20iLCJ0byIsIlN0cmluZyIsImhhcyIsInZpYVN0ciIsInJhd1ZhbHVlIiwidmFsdWUiLCJhbGVydCIsImRhc2hlZCIsImJ1ZmZlciIsImF0IiwicmVhZEZsb3ciLCJub2RlUm93cyIsImVkZ2VSb3dzIiwibGVuZ3RoIiwibm9kZXMiLCJTZXQiLCJuIiwiYWRkIiwiZWRnZXMiLCJlIiwiYW5jaG9ycyIsInRvUmlnaHQiLCJiZWxvdyIsInN0YXJ0IiwiZW5kIiwicG9seWxpbmUiLCJwb2x5bGluZUxlbmd0aCIsInRvdGFsIiwiTWF0aCIsImh5cG90IiwicG9pbnRBdCIsInQiLCJyZW1haW5pbmciLCJtYXgiLCJtaW4iLCJhIiwiYiIsInNlZyIsImYiLCJwYXRoRCIsIm1hcCIsInAiLCJyb3VuZCIsIkNIQVJfVyIsImFubm90YXRpb25MYXlvdXQiLCJsaW5lcyIsImZpbHRlciIsInMiLCJ0ZXh0VyIsImhhbGZXIiwiaGFsZiIsInRyaWFuZ2xlIiwibGFiZWxZIiwidmFsdWVZIiwiYm94IiwieDAiLCJ5MCIsIngxIiwieTEiLCJoYXNWYWx1ZSIsInRvcCIsInZpZXdCb3giLCJwb2x5bGluZXMiLCJhbm5vdGF0aW9ucyIsIkluZmluaXR5IiwiYXgiLCJheSIsImJ4IiwiYnkiLCJsaW5lIiwicGxhbkZsb3ciLCJtb2RlbCIsImJ5SWQiLCJNYXAiLCJlZGdlIiwiZ2V0IiwiYW5ub3RhdGVkIiwiYW5ub3RhdGlvbiIsImQiLCJ2YiIsImZsYXRNYXAiLCJmbG93QXJpYUxhYmVsIiwidGl0bGUiLCJwbGFuIiwiaGVhZCIsIm5vdGVzIiwidGV4dCJdLCJzb3VyY2VzIjpbImZsb3dHZW9tZXRyeS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBGbG93IOKAlCB0aGUgcHVyZSBoYWxmIG9mIHRoZSBkYXRhLXBvc2l0aW9uZWQgbm9kZS9lZGdlIGRpYWdyYW0gKEFSQ0hJVEVDVFVSRV9QTEFOIMKnMy4zKS5cbi8vIExheW91dCBjb21lcyBmcm9tIHRoZSBkYXRhOiBldmVyeSBub2RlIGNhcnJpZXMgaXRzIG93biB0b3AtbGVmdCBgeCx5YCBpbiBkaWFncmFtIHVuaXRzIGFuZFxuLy8gZXZlcnkgZWRnZSBpdHMgb3duIG9wdGlvbmFsIHdheXBvaW50cywgc28gdGhlcmUgaXMgbm8gYXV0by1sYXlvdXQsIG5vIGZvcmNlIHNpbXVsYXRpb24gYW5kXG4vLyBubyBsYXlvdXQgbGlicmFyeSDigJQgdGhlIHRlbXBsYXRlIG5ldmVyIGNvbXB1dGVzICjCpzMuMy4xIFwibmV2ZXIgYW4gZXhwcmVzc2lvblwiKSBhbmQgdGhlXG4vLyBkcmF3aW5nIGlzIHN0YWJsZSBhY3Jvc3MgY2FwdHVyZXMuIFRoaXMgbW9kdWxlIHR1cm5zIHRoZSB0d28gYm91bmQgdGFibGVzIGludG8gYSBjaGVja2VkXG4vLyBtb2RlbCAobG91ZCBvbiBhbnkgbWFsZm9ybWVkIHJvdyDigJQgbmV2ZXIgYSBwYXJ0aWFsIHNpbGVudCBkcmF3aW5nKSBhbmQgZG9lcyB0aGUgZ2VvbWV0cnk6XG4vLyBgdmlhYCBwYXJzaW5nLCBhbmNob3IgY2hvaWNlLCB0aGUgcG9seWxpbmUsIGl0cyBsZW5ndGgsIHRoZSBwb2ludCBhdCBhIGZyYWN0aW9uIGFsb25nIGl0LFxuLy8gdGhlIGFubm90YXRpb24gbGF5b3V0IGFuZCB0aGUgdmlld0JveC4gTm8gUmVhY3Q7IHVuaXQtdGVzdGVkIGRpcmVjdGx5LlxuXG5pbXBvcnQgdHlwZSB7IFJvdywgVmFsdWUgfSBmcm9tICcuLi8uLi9zdGRsaWIvdHlwZXMudHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFB0IHtcbiAgeDogbnVtYmVyO1xuICB5OiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQm94IHtcbiAgeDogbnVtYmVyO1xuICB5OiBudW1iZXI7XG4gIHc6IG51bWJlcjtcbiAgaDogbnVtYmVyO1xufVxuXG5leHBvcnQgY29uc3QgRkxPV19TSEFQRVMgPSBbJ2JveCcsICdwaWxsJywgJ2RpYW1vbmQnLCAnbm90ZSddIGFzIGNvbnN0O1xuZXhwb3J0IGNvbnN0IEZMT1dfVE9ORVMgPSBbJ2FnZW50JywgJ29wZXJhdG9yJywgJ293bmVyJywgJ2NpJywgJ25ldXRyYWwnXSBhcyBjb25zdDtcbmV4cG9ydCB0eXBlIEZsb3dTaGFwZSA9ICh0eXBlb2YgRkxPV19TSEFQRVMpW251bWJlcl07XG5leHBvcnQgdHlwZSBGbG93VG9uZSA9ICh0eXBlb2YgRkxPV19UT05FUylbbnVtYmVyXTtcblxuLyoqIFNpemUgYW5kIGNvdW50IGNhcHM6IGEgZGlhZ3JhbSBwYXN0IHRoZXNlIGlzIGEgYnJva2VuIHRpbGUsIG5vdCBhIGhhaXJiYWxsLiAqL1xuZXhwb3J0IGNvbnN0IE1BWF9GTE9XX05PREVTID0gODA7XG5leHBvcnQgY29uc3QgTUFYX0ZMT1dfRURHRVMgPSAxNjA7XG5leHBvcnQgY29uc3QgREVGQVVMVF9OT0RFX1cgPSAxNDA7XG5leHBvcnQgY29uc3QgREVGQVVMVF9OT0RFX0ggPSA1Njtcbi8qKiBUaGUgdmlld0JveCBtYXJnaW4gYXJvdW5kIGV2ZXJ5IG5vZGUsIHdheXBvaW50IGFuZCBhbm5vdGF0aW9uLiAqL1xuZXhwb3J0IGNvbnN0IEZMT1dfTUFSR0lOID0gMjQ7XG4vKiogVGhlIHZhbHVlLXN0cmVhbS1tYXAgaW52ZW50b3J5IHRyaWFuZ2xlJ3Mgd2lkdGggKGRpYWdyYW0gdW5pdHMpLiAqL1xuZXhwb3J0IGNvbnN0IEJVRkZFUl9UUklBTkdMRV9XID0gMjI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmxvd05vZGUgZXh0ZW5kcyBCb3gge1xuICBpZDogc3RyaW5nO1xuICBsYWJlbDogc3RyaW5nO1xuICBzdWI/OiBzdHJpbmc7XG4gIHNoYXBlOiBGbG93U2hhcGU7XG4gIHRvbmU6IEZsb3dUb25lO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEZsb3dFZGdlIHtcbiAgZnJvbTogc3RyaW5nO1xuICB0bzogc3RyaW5nO1xuICB2aWE6IFB0W107XG4gIGxhYmVsPzogc3RyaW5nO1xuICB2YWx1ZT86IHN0cmluZztcbiAgdG9uZTogRmxvd1RvbmU7XG4gIGFsZXJ0OiBib29sZWFuO1xuICBkYXNoZWQ6IGJvb2xlYW47XG4gIGF0OiBudW1iZXI7XG4gIGJ1ZmZlcjogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBGbG93TW9kZWwge1xuICBub2RlczogRmxvd05vZGVbXTtcbiAgZWRnZXM6IEZsb3dFZGdlW107XG59XG5cbmV4cG9ydCB0eXBlIENoZWNrZWQ8VD4gPSB7IG9rOiB0cnVlOyBkYXRhOiBUIH0gfCB7IG9rOiBmYWxzZTsgcmVhc29uOiBzdHJpbmcgfTtcblxuLy8g4pSA4pSAIHZpYSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIFBhcnNlIGB2aWFgIOKAlCB3aGl0ZXNwYWNlLXNlcGFyYXRlZCBgeCx5YCBwYWlycyAoZGlhZ3JhbSB1bml0cykuIEVtcHR5L2Fic2VudCDihpIgbm8gd2F5cG9pbnRzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlVmlhKHZpYTogc3RyaW5nIHwgdW5kZWZpbmVkKTogQ2hlY2tlZDxQdFtdPiB7XG4gIGlmICh2aWEgPT09IHVuZGVmaW5lZCB8fCB2aWEudHJpbSgpID09PSAnJykgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IFtdIH07XG4gIGNvbnN0IHBvaW50czogUHRbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHBhaXIgb2YgdmlhLnRyaW0oKS5zcGxpdCgvXFxzKy8pKSB7XG4gICAgY29uc3QgbSA9IC9eKC0/XFxkKyg/OlxcLlxcZCspPyksKC0/XFxkKyg/OlxcLlxcZCspPykkLy5leGVjKHBhaXIpO1xuICAgIGlmIChtID09PSBudWxsKSByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogYG1hbGZvcm1lZCB3YXlwb2ludCBcIiR7cGFpcn1cIiAoZXhwZWN0ZWQgXCJ4LHlcIilgIH07XG4gICAgcG9pbnRzLnB1c2goeyB4OiBOdW1iZXIobVsxXSksIHk6IE51bWJlcihtWzJdKSB9KTtcbiAgfVxuICByZXR1cm4geyBvazogdHJ1ZSwgZGF0YTogcG9pbnRzIH07XG59XG5cbi8vIOKUgOKUgCByb3cgY2hlY2tpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmNvbnN0IGlzTnVtID0gKHY6IFZhbHVlIHwgdW5kZWZpbmVkKTogdiBpcyBudW1iZXIgPT4gdHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KTtcbmNvbnN0IGFic2VudCA9ICh2OiBWYWx1ZSB8IHVuZGVmaW5lZCk6IGJvb2xlYW4gPT4gdiA9PT0gdW5kZWZpbmVkIHx8IHYgPT09IG51bGw7XG5cbmZ1bmN0aW9uIG9wdGlvbmFsTnVtYmVyKHJvdzogUm93LCBrZXk6IHN0cmluZyk6IENoZWNrZWQ8bnVtYmVyIHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IHYgPSByb3dba2V5XTtcbiAgaWYgKGFic2VudCh2KSkgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9O1xuICByZXR1cm4gaXNOdW0odikgPyB7IG9rOiB0cnVlLCBkYXRhOiB2IH0gOiB7IG9rOiBmYWxzZSwgcmVhc29uOiBgXCIke2tleX1cIiBpcyBub3QgYSBudW1iZXJgIH07XG59XG5cbmZ1bmN0aW9uIG9wdGlvbmFsU3RyaW5nKHJvdzogUm93LCBrZXk6IHN0cmluZyk6IENoZWNrZWQ8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IHYgPSByb3dba2V5XTtcbiAgaWYgKGFic2VudCh2KSkgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9O1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnID8geyBvazogdHJ1ZSwgZGF0YTogdiB9IDogeyBvazogZmFsc2UsIHJlYXNvbjogYFwiJHtrZXl9XCIgaXMgbm90IGEgc3RyaW5nYCB9O1xufVxuXG5mdW5jdGlvbiBvcHRpb25hbEJvb2wocm93OiBSb3csIGtleTogc3RyaW5nKTogQ2hlY2tlZDxib29sZWFuPiB7XG4gIGNvbnN0IHYgPSByb3dba2V5XTtcbiAgaWYgKGFic2VudCh2KSkgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IGZhbHNlIH07XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8geyBvazogdHJ1ZSwgZGF0YTogdiB9IDogeyBvazogZmFsc2UsIHJlYXNvbjogYFwiJHtrZXl9XCIgaXMgbm90IHRydWUvZmFsc2VgIH07XG59XG5cbmZ1bmN0aW9uIG9wdGlvbmFsRW51bTxUIGV4dGVuZHMgc3RyaW5nPihyb3c6IFJvdywga2V5OiBzdHJpbmcsIHZhbHVlczogcmVhZG9ubHkgVFtdLCBmYWxsYmFjazogVCk6IENoZWNrZWQ8VD4ge1xuICBjb25zdCB2ID0gcm93W2tleV07XG4gIGlmIChhYnNlbnQodikpIHJldHVybiB7IG9rOiB0cnVlLCBkYXRhOiBmYWxsYmFjayB9O1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmICh2YWx1ZXMgYXMgcmVhZG9ubHkgc3RyaW5nW10pLmluY2x1ZGVzKHYpXG4gICAgPyB7IG9rOiB0cnVlLCBkYXRhOiB2IGFzIFQgfVxuICAgIDogeyBvazogZmFsc2UsIHJlYXNvbjogYFwiJHtrZXl9XCIgbXVzdCBiZSBvbmUgb2YgJHt2YWx1ZXMuam9pbignLCAnKX1gIH07XG59XG5cbmZ1bmN0aW9uIGNoZWNrTm9kZShyb3c6IFJvdywgaTogbnVtYmVyKTogQ2hlY2tlZDxGbG93Tm9kZT4ge1xuICBjb25zdCB3aGVyZSA9IHR5cGVvZiByb3cuaWQgPT09ICdzdHJpbmcnICYmIHJvdy5pZCAhPT0gJycgPyBgbm9kZSBcIiR7cm93LmlkfVwiYCA6IGBub2RlIHJvdyAke2kgKyAxfWA7XG4gIGNvbnN0IGZhaWwgPSAocmVhc29uOiBzdHJpbmcpOiBDaGVja2VkPEZsb3dOb2RlPiA9PiAoeyBvazogZmFsc2UsIHJlYXNvbjogYCR7d2hlcmV9OiAke3JlYXNvbn1gIH0pO1xuICBpZiAodHlwZW9mIHJvdy5pZCAhPT0gJ3N0cmluZycgfHwgcm93LmlkID09PSAnJykgcmV0dXJuIGZhaWwoJ21pc3NpbmcgXCJpZFwiJyk7XG4gIGlmIChhYnNlbnQocm93LngpKSByZXR1cm4gZmFpbCgnbWlzc2luZyBcInhcIicpO1xuICBpZiAoYWJzZW50KHJvdy55KSkgcmV0dXJuIGZhaWwoJ21pc3NpbmcgXCJ5XCInKTtcbiAgaWYgKCFpc051bShyb3cueCkpIHJldHVybiBmYWlsKCdcInhcIiBpcyBub3QgYSBudW1iZXInKTtcbiAgaWYgKCFpc051bShyb3cueSkpIHJldHVybiBmYWlsKCdcInlcIiBpcyBub3QgYSBudW1iZXInKTtcbiAgY29uc3QgbGFiZWwgPSBvcHRpb25hbFN0cmluZyhyb3csICdsYWJlbCcpO1xuICBpZiAoIWxhYmVsLm9rKSByZXR1cm4gZmFpbChsYWJlbC5yZWFzb24pO1xuICBjb25zdCBzdWIgPSBvcHRpb25hbFN0cmluZyhyb3csICdzdWInKTtcbiAgaWYgKCFzdWIub2spIHJldHVybiBmYWlsKHN1Yi5yZWFzb24pO1xuICBjb25zdCB3ID0gb3B0aW9uYWxOdW1iZXIocm93LCAndycpO1xuICBpZiAoIXcub2spIHJldHVybiBmYWlsKHcucmVhc29uKTtcbiAgY29uc3QgaCA9IG9wdGlvbmFsTnVtYmVyKHJvdywgJ2gnKTtcbiAgaWYgKCFoLm9rKSByZXR1cm4gZmFpbChoLnJlYXNvbik7XG4gIGlmICgody5kYXRhICE9PSB1bmRlZmluZWQgJiYgdy5kYXRhIDw9IDApIHx8IChoLmRhdGEgIT09IHVuZGVmaW5lZCAmJiBoLmRhdGEgPD0gMCkpIHJldHVybiBmYWlsKCdcIndcIi9cImhcIiBtdXN0IGJlIHBvc2l0aXZlJyk7XG4gIGNvbnN0IHNoYXBlID0gb3B0aW9uYWxFbnVtKHJvdywgJ3NoYXBlJywgRkxPV19TSEFQRVMsICdib3gnKTtcbiAgaWYgKCFzaGFwZS5vaykgcmV0dXJuIGZhaWwoc2hhcGUucmVhc29uKTtcbiAgY29uc3QgdG9uZSA9IG9wdGlvbmFsRW51bShyb3csICd0b25lJywgRkxPV19UT05FUywgJ25ldXRyYWwnKTtcbiAgaWYgKCF0b25lLm9rKSByZXR1cm4gZmFpbCh0b25lLnJlYXNvbik7XG4gIHJldHVybiB7XG4gICAgb2s6IHRydWUsXG4gICAgZGF0YToge1xuICAgICAgaWQ6IHJvdy5pZCxcbiAgICAgIGxhYmVsOiBsYWJlbC5kYXRhID8/IHJvdy5pZCxcbiAgICAgIC4uLihzdWIuZGF0YSAhPT0gdW5kZWZpbmVkID8geyBzdWI6IHN1Yi5kYXRhIH0gOiB7fSksXG4gICAgICB4OiByb3cueCxcbiAgICAgIHk6IHJvdy55LFxuICAgICAgdzogdy5kYXRhID8/IERFRkFVTFRfTk9ERV9XLFxuICAgICAgaDogaC5kYXRhID8/IERFRkFVTFRfTk9ERV9ILFxuICAgICAgc2hhcGU6IHNoYXBlLmRhdGEsXG4gICAgICB0b25lOiB0b25lLmRhdGEsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gY2hlY2tFZGdlKHJvdzogUm93LCBpOiBudW1iZXIsIGlkczogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IENoZWNrZWQ8Rmxvd0VkZ2U+IHtcbiAgY29uc3QgbmFtZWQgPSB0eXBlb2Ygcm93LmZyb20gPT09ICdzdHJpbmcnICYmIHR5cGVvZiByb3cudG8gPT09ICdzdHJpbmcnO1xuICBjb25zdCB3aGVyZSA9IG5hbWVkID8gYGVkZ2UgJHtTdHJpbmcocm93LmZyb20pfSDihpIgJHtTdHJpbmcocm93LnRvKX1gIDogYGVkZ2Ugcm93ICR7aSArIDF9YDtcbiAgY29uc3QgZmFpbCA9IChyZWFzb246IHN0cmluZyk6IENoZWNrZWQ8Rmxvd0VkZ2U+ID0+ICh7IG9rOiBmYWxzZSwgcmVhc29uOiBgJHt3aGVyZX06ICR7cmVhc29ufWAgfSk7XG4gIGlmICh0eXBlb2Ygcm93LmZyb20gIT09ICdzdHJpbmcnIHx8IHJvdy5mcm9tID09PSAnJykgcmV0dXJuIGZhaWwoJ21pc3NpbmcgXCJmcm9tXCInKTtcbiAgaWYgKHR5cGVvZiByb3cudG8gIT09ICdzdHJpbmcnIHx8IHJvdy50byA9PT0gJycpIHJldHVybiBmYWlsKCdtaXNzaW5nIFwidG9cIicpO1xuICBpZiAoIWlkcy5oYXMocm93LmZyb20pKSByZXR1cm4gZmFpbChgdW5rbm93biBub2RlIGlkIFwiJHtyb3cuZnJvbX1cImApO1xuICBpZiAoIWlkcy5oYXMocm93LnRvKSkgcmV0dXJuIGZhaWwoYHVua25vd24gbm9kZSBpZCBcIiR7cm93LnRvfVwiYCk7XG4gIGNvbnN0IHZpYVN0ciA9IG9wdGlvbmFsU3RyaW5nKHJvdywgJ3ZpYScpO1xuICBpZiAoIXZpYVN0ci5vaykgcmV0dXJuIGZhaWwodmlhU3RyLnJlYXNvbik7XG4gIGNvbnN0IHZpYSA9IHBhcnNlVmlhKHZpYVN0ci5kYXRhKTtcbiAgaWYgKCF2aWEub2spIHJldHVybiBmYWlsKHZpYS5yZWFzb24pO1xuICBjb25zdCBsYWJlbCA9IG9wdGlvbmFsU3RyaW5nKHJvdywgJ2xhYmVsJyk7XG4gIGlmICghbGFiZWwub2spIHJldHVybiBmYWlsKGxhYmVsLnJlYXNvbik7XG4gIGNvbnN0IHJhd1ZhbHVlID0gcm93LnZhbHVlO1xuICBpZiAoIWFic2VudChyYXdWYWx1ZSkgJiYgdHlwZW9mIHJhd1ZhbHVlICE9PSAnc3RyaW5nJyAmJiAhaXNOdW0ocmF3VmFsdWUpKSByZXR1cm4gZmFpbCgnXCJ2YWx1ZVwiIG11c3QgYmUgdGV4dCBvciBhIG51bWJlcicpO1xuICBjb25zdCB0b25lID0gb3B0aW9uYWxFbnVtKHJvdywgJ3RvbmUnLCBGTE9XX1RPTkVTLCAnbmV1dHJhbCcpO1xuICBpZiAoIXRvbmUub2spIHJldHVybiBmYWlsKHRvbmUucmVhc29uKTtcbiAgY29uc3QgYWxlcnQgPSBvcHRpb25hbEJvb2wocm93LCAnYWxlcnQnKTtcbiAgaWYgKCFhbGVydC5vaykgcmV0dXJuIGZhaWwoYWxlcnQucmVhc29uKTtcbiAgY29uc3QgZGFzaGVkID0gb3B0aW9uYWxCb29sKHJvdywgJ2Rhc2hlZCcpO1xuICBpZiAoIWRhc2hlZC5vaykgcmV0dXJuIGZhaWwoZGFzaGVkLnJlYXNvbik7XG4gIGNvbnN0IGJ1ZmZlciA9IG9wdGlvbmFsQm9vbChyb3csICdidWZmZXInKTtcbiAgaWYgKCFidWZmZXIub2spIHJldHVybiBmYWlsKGJ1ZmZlci5yZWFzb24pO1xuICBjb25zdCBhdCA9IG9wdGlvbmFsTnVtYmVyKHJvdywgJ2F0Jyk7XG4gIGlmICghYXQub2spIHJldHVybiBmYWlsKGF0LnJlYXNvbik7XG4gIGlmIChhdC5kYXRhICE9PSB1bmRlZmluZWQgJiYgKGF0LmRhdGEgPCAwIHx8IGF0LmRhdGEgPiAxKSkgcmV0dXJuIGZhaWwoJ1wiYXRcIiBtdXN0IGJlIGJldHdlZW4gMCBhbmQgMScpO1xuICByZXR1cm4ge1xuICAgIG9rOiB0cnVlLFxuICAgIGRhdGE6IHtcbiAgICAgIGZyb206IHJvdy5mcm9tLFxuICAgICAgdG86IHJvdy50byxcbiAgICAgIHZpYTogdmlhLmRhdGEsXG4gICAgICAuLi4obGFiZWwuZGF0YSAhPT0gdW5kZWZpbmVkID8geyBsYWJlbDogbGFiZWwuZGF0YSB9IDoge30pLFxuICAgICAgLi4uKCFhYnNlbnQocmF3VmFsdWUpID8geyB2YWx1ZTogU3RyaW5nKHJhd1ZhbHVlKSB9IDoge30pLFxuICAgICAgdG9uZTogdG9uZS5kYXRhLFxuICAgICAgYWxlcnQ6IGFsZXJ0LmRhdGEsXG4gICAgICBkYXNoZWQ6IGRhc2hlZC5kYXRhLFxuICAgICAgYXQ6IGF0LmRhdGEgPz8gMC41LFxuICAgICAgYnVmZmVyOiBidWZmZXIuZGF0YSxcbiAgICB9LFxuICB9O1xufVxuXG4vKipcbiAqIENoZWNrIGJvdGggdGFibGVzIGludG8gYSBgRmxvd01vZGVsYC4gVGhlIGZpcnN0IG9mZmVuZGluZyByb3cgKGJ5IGlkIHdoZXJlIGl0IGhhcyBvbmUpXG4gKiBpcyB0aGUgcmVhc29uOyB0aGVyZSBpcyBubyBwYXJ0aWFsIHJlc3VsdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlYWRGbG93KG5vZGVSb3dzOiByZWFkb25seSBSb3dbXSwgZWRnZVJvd3M6IHJlYWRvbmx5IFJvd1tdKTogQ2hlY2tlZDxGbG93TW9kZWw+IHtcbiAgaWYgKG5vZGVSb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHsgb2s6IGZhbHNlLCByZWFzb246ICdubyBub2RlcyB0byBkcmF3JyB9O1xuICBpZiAobm9kZVJvd3MubGVuZ3RoID4gTUFYX0ZMT1dfTk9ERVMpIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiBgJHtub2RlUm93cy5sZW5ndGh9IG5vZGVzIGV4Y2VlZHMgdGhlICR7TUFYX0ZMT1dfTk9ERVN9LW5vZGUgY2FwYCB9O1xuICBpZiAoZWRnZVJvd3MubGVuZ3RoID4gTUFYX0ZMT1dfRURHRVMpIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiBgJHtlZGdlUm93cy5sZW5ndGh9IGVkZ2VzIGV4Y2VlZHMgdGhlICR7TUFYX0ZMT1dfRURHRVN9LWVkZ2UgY2FwYCB9O1xuICBjb25zdCBub2RlczogRmxvd05vZGVbXSA9IFtdO1xuICBjb25zdCBpZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBub2RlUm93cy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG4gPSBjaGVja05vZGUobm9kZVJvd3NbaV0sIGkpO1xuICAgIGlmICghbi5vaykgcmV0dXJuIG47XG4gICAgaWYgKGlkcy5oYXMobi5kYXRhLmlkKSkgcmV0dXJuIHsgb2s6IGZhbHNlLCByZWFzb246IGBub2RlIFwiJHtuLmRhdGEuaWR9XCI6IGR1cGxpY2F0ZSBpZGAgfTtcbiAgICBpZHMuYWRkKG4uZGF0YS5pZCk7XG4gICAgbm9kZXMucHVzaChuLmRhdGEpO1xuICB9XG4gIGNvbnN0IGVkZ2VzOiBGbG93RWRnZVtdID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZWRnZVJvd3MubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBlID0gY2hlY2tFZGdlKGVkZ2VSb3dzW2ldLCBpLCBpZHMpO1xuICAgIGlmICghZS5vaykgcmV0dXJuIGU7XG4gICAgZWRnZXMucHVzaChlLmRhdGEpO1xuICB9XG4gIHJldHVybiB7IG9rOiB0cnVlLCBkYXRhOiB7IG5vZGVzLCBlZGdlcyB9IH07XG59XG5cbi8vIOKUgOKUgCBnZW9tZXRyeSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiBUaGUgZWRnZSdzIHR3byBhbmNob3JzLiBUaGUgZW5kIGlzIGFsd2F5cyB0aGUgdGFyZ2V0J3MgbGVmdC1taWRkbGUuIFRoZSBzdGFydCBpcyB0aGVcbiAqIHNvdXJjZSdzIHJpZ2h0LW1pZGRsZSDigJQgZXhjZXB0IHdoZW4gdGhlIHRhcmdldCBsaWVzIHdob2xseSBiZWxvdyB0aGUgc291cmNlIGFuZCBub3RcbiAqIHdob2xseSB0byBpdHMgcmlnaHQgKGB0by55IOKJpSBmcm9tLnkgKyBmcm9tLmhgIGFuZCBgdG8ueCA8IGZyb20ueCArIGZyb20ud2ApLCB3aGVyZSBpdFxuICogbGVhdmVzIGZyb20gdGhlIHNvdXJjZSdzIGJvdHRvbS1taWRkbGUgKGEgZHJvcCB0byB0aGUgbmV4dCByb3cpLiBBbnkgb3RoZXIgcm91dGluZyBpc1xuICogdGhlIGF1dGhvcidzLCB0aHJvdWdoIGB2aWFgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYW5jaG9ycyhmcm9tOiBCb3gsIHRvOiBCb3gpOiB7IHN0YXJ0OiBQdDsgZW5kOiBQdCB9IHtcbiAgY29uc3QgdG9SaWdodCA9IHRvLnggPj0gZnJvbS54ICsgZnJvbS53O1xuICBjb25zdCBiZWxvdyA9IHRvLnkgPj0gZnJvbS55ICsgZnJvbS5oO1xuICBjb25zdCBzdGFydCA9ICF0b1JpZ2h0ICYmIGJlbG93ID8geyB4OiBmcm9tLnggKyBmcm9tLncgLyAyLCB5OiBmcm9tLnkgKyBmcm9tLmggfSA6IHsgeDogZnJvbS54ICsgZnJvbS53LCB5OiBmcm9tLnkgKyBmcm9tLmggLyAyIH07XG4gIHJldHVybiB7IHN0YXJ0LCBlbmQ6IHsgeDogdG8ueCwgeTogdG8ueSArIHRvLmggLyAyIH0gfTtcbn1cblxuLyoqIFRoZSBwb2x5bGluZTogc3RhcnQgYW5jaG9yIOKGkiB3YXlwb2ludHMg4oaSIGVuZCBhbmNob3IsIHN0cmFpZ2h0IHNlZ21lbnRzIGJldHdlZW4gdGhlbS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwb2x5bGluZShmcm9tOiBCb3gsIHRvOiBCb3gsIHZpYTogcmVhZG9ubHkgUHRbXSk6IFB0W10ge1xuICBjb25zdCB7IHN0YXJ0LCBlbmQgfSA9IGFuY2hvcnMoZnJvbSwgdG8pO1xuICByZXR1cm4gW3N0YXJ0LCAuLi52aWEsIGVuZF07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwb2x5bGluZUxlbmd0aChwb2ludHM6IHJlYWRvbmx5IFB0W10pOiBudW1iZXIge1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGxldCBpID0gMTsgaSA8IHBvaW50cy5sZW5ndGg7IGkrKykgdG90YWwgKz0gTWF0aC5oeXBvdChwb2ludHNbaV0ueCAtIHBvaW50c1tpIC0gMV0ueCwgcG9pbnRzW2ldLnkgLSBwb2ludHNbaSAtIDFdLnkpO1xuICByZXR1cm4gdG90YWw7XG59XG5cbi8qKiBUaGUgcG9pbnQgYXQgZnJhY3Rpb24gYHRgIChjbGFtcGVkIHRvIFswLDFdKSBvZiB0aGUgcG9seWxpbmUncyBsZW5ndGguICovXG5leHBvcnQgZnVuY3Rpb24gcG9pbnRBdChwb2ludHM6IHJlYWRvbmx5IFB0W10sIHQ6IG51bWJlcik6IFB0IHtcbiAgaWYgKHBvaW50cy5sZW5ndGggPT09IDApIHJldHVybiB7IHg6IDAsIHk6IDAgfTtcbiAgY29uc3QgdG90YWwgPSBwb2x5bGluZUxlbmd0aChwb2ludHMpO1xuICBpZiAodG90YWwgPT09IDApIHJldHVybiB7IC4uLnBvaW50c1swXSB9O1xuICBsZXQgcmVtYWluaW5nID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgdCkpICogdG90YWw7XG4gIGZvciAobGV0IGkgPSAxOyBpIDwgcG9pbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgYSA9IHBvaW50c1tpIC0gMV07XG4gICAgY29uc3QgYiA9IHBvaW50c1tpXTtcbiAgICBjb25zdCBzZWcgPSBNYXRoLmh5cG90KGIueCAtIGEueCwgYi55IC0gYS55KTtcbiAgICBpZiAocmVtYWluaW5nIDw9IHNlZyAmJiBzZWcgPiAwKSB7XG4gICAgICBjb25zdCBmID0gcmVtYWluaW5nIC8gc2VnO1xuICAgICAgcmV0dXJuIHsgeDogYS54ICsgKGIueCAtIGEueCkgKiBmLCB5OiBhLnkgKyAoYi55IC0gYS55KSAqIGYgfTtcbiAgICB9XG4gICAgcmVtYWluaW5nIC09IHNlZztcbiAgfVxuICByZXR1cm4geyAuLi5wb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdIH07XG59XG5cbi8qKiBUaGUgU1ZHIHBhdGggYGRgIGZvciBhIHBvbHlsaW5lLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhdGhEKHBvaW50czogcmVhZG9ubHkgUHRbXSk6IHN0cmluZyB7XG4gIHJldHVybiBwb2ludHMubWFwKChwLCBpKSA9PiBgJHtpID09PSAwID8gJ00nIDogJ0wnfSR7cm91bmQocC54KX0gJHtyb3VuZChwLnkpfWApLmpvaW4oJyAnKTtcbn1cblxuY29uc3Qgcm91bmQgPSAobjogbnVtYmVyKTogbnVtYmVyID0+IE1hdGgucm91bmQobiAqIDEwMCkgLyAxMDA7XG5cbi8qKiBBIHJvdWdoIHRleHQgd2lkdGggKGRpYWdyYW0gdW5pdHMpIOKAlCBlbm91Z2ggdG8ga2VlcCBhbm5vdGF0aW9ucyBpbnNpZGUgdGhlIHZpZXdCb3guICovXG5jb25zdCBDSEFSX1cgPSA3O1xuXG5leHBvcnQgaW50ZXJmYWNlIEFubm90YXRpb25MYXlvdXQge1xuICAvKiogVHJpYW5nbGUgdmVydGljZXMgYXMgYW4gU1ZHIGBwb2ludHNgIHN0cmluZywgcHJlc2VudCBvbmx5IGZvciBhIGJ1ZmZlci4gKi9cbiAgdHJpYW5nbGU/OiBzdHJpbmc7XG4gIGxhYmVsWT86IG51bWJlcjtcbiAgdmFsdWVZPzogbnVtYmVyO1xuICB4OiBudW1iZXI7XG4gIC8qKiBFeHRlbnQgb2YgZXZlcnl0aGluZyB0aGUgYW5ub3RhdGlvbiBkcmF3cy4gKi9cbiAgYm94OiB7IHgwOiBudW1iZXI7IHkwOiBudW1iZXI7IHgxOiBudW1iZXI7IHkxOiBudW1iZXIgfTtcbn1cblxuLyoqXG4gKiBXaGVyZSBhbiBhbm5vdGF0aW9uJ3MgcGFydHMgZ28gYXJvdW5kIGl0cyBhbmNob3IgcG9pbnQgYHBgLiBQbGFpbiBhbm5vdGF0aW9uOiBsYWJlbCBhbmRcbiAqIHZhbHVlIHN0YWNrZWQganVzdCBhYm92ZSB0aGUgbGluZS4gQnVmZmVyOiBhbiBpbnZlbnRvcnkgdHJpYW5nbGUgKGFwZXggdXAsXG4gKiBgQlVGRkVSX1RSSUFOR0xFX1dgIHdpZGUpIGNlbnRlcmVkIG9uIHRoZSBsaW5lIHdpdGggdGhlIHRleHQgc3RhY2tlZCBiZW5lYXRoIGl0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gYW5ub3RhdGlvbkxheW91dChwOiBQdCwgYTogeyBsYWJlbD86IHN0cmluZzsgdmFsdWU/OiBzdHJpbmc7IGJ1ZmZlcjogYm9vbGVhbiB9KTogQW5ub3RhdGlvbkxheW91dCB7XG4gIGNvbnN0IGxpbmVzID0gW2EubGFiZWwsIGEudmFsdWVdLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHMgIT09IHVuZGVmaW5lZCAmJiBzICE9PSAnJyk7XG4gIGNvbnN0IHRleHRXID0gTWF0aC5tYXgoMCwgLi4ubGluZXMubWFwKChzKSA9PiBzLmxlbmd0aCAqIENIQVJfVykpO1xuICBjb25zdCBoYWxmVyA9IE1hdGgubWF4KGEuYnVmZmVyID8gQlVGRkVSX1RSSUFOR0xFX1cgLyAyIDogMCwgdGV4dFcgLyAyKTtcbiAgaWYgKGEuYnVmZmVyKSB7XG4gICAgY29uc3QgaGFsZiA9IEJVRkZFUl9UUklBTkdMRV9XIC8gMjtcbiAgICBjb25zdCB0cmlhbmdsZSA9IGAke3JvdW5kKHAueCl9LCR7cm91bmQocC55IC0gMTApfSAke3JvdW5kKHAueCArIGhhbGYpfSwke3JvdW5kKHAueSArIDkpfSAke3JvdW5kKHAueCAtIGhhbGYpfSwke3JvdW5kKHAueSArIDkpfWA7XG4gICAgbGV0IHkgPSBwLnkgKyA5O1xuICAgIGNvbnN0IGxhYmVsWSA9IGEubGFiZWwgPyAoeSArPSAxNSkgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgdmFsdWVZID0gYS52YWx1ZSAhPT0gdW5kZWZpbmVkICYmIGEudmFsdWUgIT09ICcnID8gKHkgKz0gMTUpIDogdW5kZWZpbmVkO1xuICAgIHJldHVybiB7IHRyaWFuZ2xlLCBsYWJlbFksIHZhbHVlWSwgeDogcC54LCBib3g6IHsgeDA6IHAueCAtIGhhbGZXLCB5MDogcC55IC0gMTAsIHgxOiBwLnggKyBoYWxmVywgeTE6IHkgKyA0IH0gfTtcbiAgfVxuICBjb25zdCBoYXNWYWx1ZSA9IGEudmFsdWUgIT09IHVuZGVmaW5lZCAmJiBhLnZhbHVlICE9PSAnJztcbiAgY29uc3QgdmFsdWVZID0gaGFzVmFsdWUgPyBwLnkgLSA2IDogdW5kZWZpbmVkO1xuICBjb25zdCBsYWJlbFkgPSBhLmxhYmVsID8gKGhhc1ZhbHVlID8gcC55IC0gMjEgOiBwLnkgLSA2KSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgdG9wID0gKGxhYmVsWSA/PyB2YWx1ZVkgPz8gcC55KSAtIDEyO1xuICByZXR1cm4geyBsYWJlbFksIHZhbHVlWSwgeDogcC54LCBib3g6IHsgeDA6IHAueCAtIGhhbGZXLCB5MDogdG9wLCB4MTogcC54ICsgaGFsZlcsIHkxOiBwLnkgfSB9O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFZpZXdCb3gge1xuICB4OiBudW1iZXI7XG4gIHk6IG51bWJlcjtcbiAgdzogbnVtYmVyO1xuICBoOiBudW1iZXI7XG59XG5cbi8qKiBUaGUgYm91bmRpbmcgYm94IG9mIGFsbCBub2RlcywgYWxsIHBvbHlsaW5lIHBvaW50cyBhbmQgYWxsIGFubm90YXRpb24gZXh0ZW50cywgcGx1cyBgRkxPV19NQVJHSU5gLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZpZXdCb3gobm9kZXM6IHJlYWRvbmx5IEJveFtdLCBwb2x5bGluZXM6IHJlYWRvbmx5IChyZWFkb25seSBQdFtdKVtdLCBhbm5vdGF0aW9uczogcmVhZG9ubHkgQW5ub3RhdGlvbkxheW91dFtdKTogVmlld0JveCB7XG4gIGxldCB4MCA9IEluZmluaXR5O1xuICBsZXQgeTAgPSBJbmZpbml0eTtcbiAgbGV0IHgxID0gLUluZmluaXR5O1xuICBsZXQgeTEgPSAtSW5maW5pdHk7XG4gIGNvbnN0IGFkZCA9IChheDogbnVtYmVyLCBheTogbnVtYmVyLCBieDogbnVtYmVyLCBieTogbnVtYmVyKTogdm9pZCA9PiB7XG4gICAgeDAgPSBNYXRoLm1pbih4MCwgYXgpO1xuICAgIHkwID0gTWF0aC5taW4oeTAsIGF5KTtcbiAgICB4MSA9IE1hdGgubWF4KHgxLCBieCk7XG4gICAgeTEgPSBNYXRoLm1heCh5MSwgYnkpO1xuICB9O1xuICBmb3IgKGNvbnN0IG4gb2Ygbm9kZXMpIGFkZChuLngsIG4ueSwgbi54ICsgbi53LCBuLnkgKyBuLmgpO1xuICBmb3IgKGNvbnN0IGxpbmUgb2YgcG9seWxpbmVzKSBmb3IgKGNvbnN0IHAgb2YgbGluZSkgYWRkKHAueCwgcC55LCBwLngsIHAueSk7XG4gIGZvciAoY29uc3QgYSBvZiBhbm5vdGF0aW9ucykgYWRkKGEuYm94LngwLCBhLmJveC55MCwgYS5ib3gueDEsIGEuYm94LnkxKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoeDApKSByZXR1cm4geyB4OiAwLCB5OiAwLCB3OiBGTE9XX01BUkdJTiAqIDIsIGg6IEZMT1dfTUFSR0lOICogMiB9O1xuICByZXR1cm4geyB4OiB4MCAtIEZMT1dfTUFSR0lOLCB5OiB5MCAtIEZMT1dfTUFSR0lOLCB3OiB4MSAtIHgwICsgRkxPV19NQVJHSU4gKiAyLCBoOiB5MSAtIHkwICsgRkxPV19NQVJHSU4gKiAyIH07XG59XG5cbi8qKiBUaGUgZnVsbCBkcmF3aW5nIHBsYW4gZm9yIGEgY2hlY2tlZCBtb2RlbCDigJQgd2hhdCB0aGUgY29tcG9uZW50IHJlbmRlcnMsIHB1cmUuICovXG5leHBvcnQgaW50ZXJmYWNlIEZsb3dQbGFuIHtcbiAgbm9kZXM6IEZsb3dOb2RlW107XG4gIGVkZ2VzOiB7IGVkZ2U6IEZsb3dFZGdlOyBwb2ludHM6IFB0W107IGQ6IHN0cmluZzsgYW5ub3RhdGlvbj86IEFubm90YXRpb25MYXlvdXQgfVtdO1xuICB2aWV3Qm94OiBWaWV3Qm94O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGxhbkZsb3cobW9kZWw6IEZsb3dNb2RlbCk6IEZsb3dQbGFuIHtcbiAgY29uc3QgYnlJZCA9IG5ldyBNYXAobW9kZWwubm9kZXMubWFwKChuKSA9PiBbbi5pZCwgbl0pKTtcbiAgY29uc3QgZWRnZXMgPSBtb2RlbC5lZGdlcy5tYXAoKGVkZ2UpID0+IHtcbiAgICBjb25zdCBwb2ludHMgPSBwb2x5bGluZShieUlkLmdldChlZGdlLmZyb20pISwgYnlJZC5nZXQoZWRnZS50bykhLCBlZGdlLnZpYSk7XG4gICAgY29uc3QgYW5ub3RhdGVkID0gZWRnZS5idWZmZXIgfHwgKGVkZ2UubGFiZWwgPz8gJycpICE9PSAnJyB8fCAoZWRnZS52YWx1ZSA/PyAnJykgIT09ICcnO1xuICAgIGNvbnN0IGFubm90YXRpb24gPSBhbm5vdGF0ZWQgPyBhbm5vdGF0aW9uTGF5b3V0KHBvaW50QXQocG9pbnRzLCBlZGdlLmF0KSwgZWRnZSkgOiB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHsgZWRnZSwgcG9pbnRzLCBkOiBwYXRoRChwb2ludHMpLCAuLi4oYW5ub3RhdGlvbiA/IHsgYW5ub3RhdGlvbiB9IDoge30pIH07XG4gIH0pO1xuICBjb25zdCB2YiA9IHZpZXdCb3goXG4gICAgbW9kZWwubm9kZXMsXG4gICAgZWRnZXMubWFwKChlKSA9PiBlLnBvaW50cyksXG4gICAgZWRnZXMuZmxhdE1hcCgoZSkgPT4gKGUuYW5ub3RhdGlvbiA/IFtlLmFubm90YXRpb25dIDogW10pKSxcbiAgKTtcbiAgcmV0dXJuIHsgbm9kZXM6IG1vZGVsLm5vZGVzLCBlZGdlcywgdmlld0JveDogdmIgfTtcbn1cblxuLyoqIFRoZSBzY3JlZW4tcmVhZGVyIHRleHQ6IHRpdGxlLCB0aGVuIGVhY2ggYW5ub3RhdGVkIGVkZ2UgYXMgXCJmcm9tIOKGkiB0bzogbGFiZWwgdmFsdWVcIi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmbG93QXJpYUxhYmVsKHRpdGxlOiBzdHJpbmcgfCB1bmRlZmluZWQsIHBsYW46IEZsb3dQbGFuKTogc3RyaW5nIHtcbiAgY29uc3QgYnlJZCA9IG5ldyBNYXAocGxhbi5ub2Rlcy5tYXAoKG4pID0+IFtuLmlkLCBuLmxhYmVsXSkpO1xuICBjb25zdCBoZWFkID0gYCR7dGl0bGUgPz8gJ0Zsb3cgZGlhZ3JhbSd9OiAke3BsYW4ubm9kZXMubGVuZ3RofSAke3BsYW4ubm9kZXMubGVuZ3RoID09PSAxID8gJ25vZGUnIDogJ25vZGVzJ30sICR7cGxhbi5lZGdlcy5sZW5ndGh9ICR7cGxhbi5lZGdlcy5sZW5ndGggPT09IDEgPyAnY29ubmVjdGlvbicgOiAnY29ubmVjdGlvbnMnfS5gO1xuICBjb25zdCBub3RlcyA9IHBsYW4uZWRnZXNcbiAgICAuZmlsdGVyKChlKSA9PiBlLmFubm90YXRpb24gIT09IHVuZGVmaW5lZClcbiAgICAubWFwKCh7IGVkZ2UgfSkgPT4ge1xuICAgICAgY29uc3QgdGV4dCA9IFtlZGdlLmxhYmVsLCBlZGdlLnZhbHVlXS5maWx0ZXIoKHMpID0+IHMgIT09IHVuZGVmaW5lZCAmJiBzICE9PSAnJykuam9pbignICcpO1xuICAgICAgcmV0dXJuIGAke2J5SWQuZ2V0KGVkZ2UuZnJvbSl9IOKGkiAke2J5SWQuZ2V0KGVkZ2UudG8pfTogJHt0ZXh0fSR7ZWRnZS5hbGVydCA/ICcgKGFsZXJ0KScgOiAnJ31gO1xuICAgIH0pO1xuICByZXR1cm4gbm90ZXMubGVuZ3RoID09PSAwID8gaGVhZCA6IGAke2hlYWR9ICR7bm90ZXMuam9pbignOyAnKX0uYDtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFnQk8sTUFBTUEsV0FBVyxHQUFBQyxPQUFBLENBQUFELFdBQUEsR0FBRyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBVTtBQUMvRCxNQUFNRSxVQUFVLEdBQUFELE9BQUEsQ0FBQUMsVUFBQSxHQUFHLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBVTtBQUlsRjtBQUNPLE1BQU1DLGNBQWMsR0FBQUYsT0FBQSxDQUFBRSxjQUFBLEdBQUcsRUFBRTtBQUN6QixNQUFNQyxjQUFjLEdBQUFILE9BQUEsQ0FBQUcsY0FBQSxHQUFHLEdBQUc7QUFDMUIsTUFBTUMsY0FBYyxHQUFBSixPQUFBLENBQUFJLGNBQUEsR0FBRyxHQUFHO0FBQzFCLE1BQU1DLGNBQWMsR0FBQUwsT0FBQSxDQUFBSyxjQUFBLEdBQUcsRUFBRTtBQUNoQztBQUNPLE1BQU1DLFdBQVcsR0FBQU4sT0FBQSxDQUFBTSxXQUFBLEdBQUcsRUFBRTtBQUM3QjtBQUNPLE1BQU1DLGlCQUFpQixHQUFBUCxPQUFBLENBQUFPLGlCQUFBLEdBQUcsRUFBRTtBQThCbkM7O0FBRUE7QUFDTyxTQUFTQyxRQUFRQSxDQUFDQyxHQUF1QixFQUFpQjtFQUMvRCxJQUFJQSxHQUFHLEtBQUtDLFNBQVMsSUFBSUQsR0FBRyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxPQUFPO0lBQUVDLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRTtFQUFHLENBQUM7RUFDekUsTUFBTUMsTUFBWSxHQUFHLEVBQUU7RUFDdkIsS0FBSyxNQUFNQyxJQUFJLElBQUlOLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBQ0ssS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO0lBQzFDLE1BQU1DLENBQUMsR0FBRyx1Q0FBdUMsQ0FBQ0MsSUFBSSxDQUFDSCxJQUFJLENBQUM7SUFDNUQsSUFBSUUsQ0FBQyxLQUFLLElBQUksRUFBRSxPQUFPO01BQUVMLEVBQUUsRUFBRSxLQUFLO01BQUVPLE1BQU0sRUFBRSx1QkFBdUJKLElBQUk7SUFBcUIsQ0FBQztJQUM3RkQsTUFBTSxDQUFDTSxJQUFJLENBQUM7TUFBRUMsQ0FBQyxFQUFFQyxNQUFNLENBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFFTSxDQUFDLEVBQUVELE1BQU0sQ0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQztFQUNuRDtFQUNBLE9BQU87SUFBRUwsRUFBRSxFQUFFLElBQUk7SUFBRUMsSUFBSSxFQUFFQztFQUFPLENBQUM7QUFDbkM7O0FBRUE7O0FBRUEsTUFBTVUsS0FBSyxHQUFJQyxDQUFvQixJQUFrQixPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUFJSCxNQUFNLENBQUNJLFFBQVEsQ0FBQ0QsQ0FBQyxDQUFDO0FBQ2hHLE1BQU1FLE1BQU0sR0FBSUYsQ0FBb0IsSUFBY0EsQ0FBQyxLQUFLZixTQUFTLElBQUllLENBQUMsS0FBSyxJQUFJO0FBRS9FLFNBQVNHLGNBQWNBLENBQUNDLEdBQVEsRUFBRUMsR0FBVyxFQUErQjtFQUMxRSxNQUFNTCxDQUFDLEdBQUdJLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDO0VBQ2xCLElBQUlILE1BQU0sQ0FBQ0YsQ0FBQyxDQUFDLEVBQUUsT0FBTztJQUFFYixFQUFFLEVBQUUsSUFBSTtJQUFFQyxJQUFJLEVBQUVIO0VBQVUsQ0FBQztFQUNuRCxPQUFPYyxLQUFLLENBQUNDLENBQUMsQ0FBQyxHQUFHO0lBQUViLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRVk7RUFBRSxDQUFDLEdBQUc7SUFBRWIsRUFBRSxFQUFFLEtBQUs7SUFBRU8sTUFBTSxFQUFFLElBQUlXLEdBQUc7RUFBb0IsQ0FBQztBQUM3RjtBQUVBLFNBQVNDLGNBQWNBLENBQUNGLEdBQVEsRUFBRUMsR0FBVyxFQUErQjtFQUMxRSxNQUFNTCxDQUFDLEdBQUdJLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDO0VBQ2xCLElBQUlILE1BQU0sQ0FBQ0YsQ0FBQyxDQUFDLEVBQUUsT0FBTztJQUFFYixFQUFFLEVBQUUsSUFBSTtJQUFFQyxJQUFJLEVBQUVIO0VBQVUsQ0FBQztFQUNuRCxPQUFPLE9BQU9lLENBQUMsS0FBSyxRQUFRLEdBQUc7SUFBRWIsRUFBRSxFQUFFLElBQUk7SUFBRUMsSUFBSSxFQUFFWTtFQUFFLENBQUMsR0FBRztJQUFFYixFQUFFLEVBQUUsS0FBSztJQUFFTyxNQUFNLEVBQUUsSUFBSVcsR0FBRztFQUFvQixDQUFDO0FBQzFHO0FBRUEsU0FBU0UsWUFBWUEsQ0FBQ0gsR0FBUSxFQUFFQyxHQUFXLEVBQW9CO0VBQzdELE1BQU1MLENBQUMsR0FBR0ksR0FBRyxDQUFDQyxHQUFHLENBQUM7RUFDbEIsSUFBSUgsTUFBTSxDQUFDRixDQUFDLENBQUMsRUFBRSxPQUFPO0lBQUViLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRTtFQUFNLENBQUM7RUFDL0MsT0FBTyxPQUFPWSxDQUFDLEtBQUssU0FBUyxHQUFHO0lBQUViLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRVk7RUFBRSxDQUFDLEdBQUc7SUFBRWIsRUFBRSxFQUFFLEtBQUs7SUFBRU8sTUFBTSxFQUFFLElBQUlXLEdBQUc7RUFBc0IsQ0FBQztBQUM3RztBQUVBLFNBQVNHLFlBQVlBLENBQW1CSixHQUFRLEVBQUVDLEdBQVcsRUFBRUksTUFBb0IsRUFBRUMsUUFBVyxFQUFjO0VBQzVHLE1BQU1WLENBQUMsR0FBR0ksR0FBRyxDQUFDQyxHQUFHLENBQUM7RUFDbEIsSUFBSUgsTUFBTSxDQUFDRixDQUFDLENBQUMsRUFBRSxPQUFPO0lBQUViLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRXNCO0VBQVMsQ0FBQztFQUNsRCxPQUFPLE9BQU9WLENBQUMsS0FBSyxRQUFRLElBQUtTLE1BQU0sQ0FBdUJFLFFBQVEsQ0FBQ1gsQ0FBQyxDQUFDLEdBQ3JFO0lBQUViLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRVk7RUFBTyxDQUFDLEdBQzFCO0lBQUViLEVBQUUsRUFBRSxLQUFLO0lBQUVPLE1BQU0sRUFBRSxJQUFJVyxHQUFHLG9CQUFvQkksTUFBTSxDQUFDRyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQUcsQ0FBQztBQUMzRTtBQUVBLFNBQVNDLFNBQVNBLENBQUNULEdBQVEsRUFBRVUsQ0FBUyxFQUFxQjtFQUN6RCxNQUFNQyxLQUFLLEdBQUcsT0FBT1gsR0FBRyxDQUFDWSxFQUFFLEtBQUssUUFBUSxJQUFJWixHQUFHLENBQUNZLEVBQUUsS0FBSyxFQUFFLEdBQUcsU0FBU1osR0FBRyxDQUFDWSxFQUFFLEdBQUcsR0FBRyxZQUFZRixDQUFDLEdBQUcsQ0FBQyxFQUFFO0VBQ3BHLE1BQU1HLElBQUksR0FBSXZCLE1BQWMsS0FBeUI7SUFBRVAsRUFBRSxFQUFFLEtBQUs7SUFBRU8sTUFBTSxFQUFFLEdBQUdxQixLQUFLLEtBQUtyQixNQUFNO0VBQUcsQ0FBQyxDQUFDO0VBQ2xHLElBQUksT0FBT1UsR0FBRyxDQUFDWSxFQUFFLEtBQUssUUFBUSxJQUFJWixHQUFHLENBQUNZLEVBQUUsS0FBSyxFQUFFLEVBQUUsT0FBT0MsSUFBSSxDQUFDLGNBQWMsQ0FBQztFQUM1RSxJQUFJZixNQUFNLENBQUNFLEdBQUcsQ0FBQ1IsQ0FBQyxDQUFDLEVBQUUsT0FBT3FCLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDN0MsSUFBSWYsTUFBTSxDQUFDRSxHQUFHLENBQUNOLENBQUMsQ0FBQyxFQUFFLE9BQU9tQixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzdDLElBQUksQ0FBQ2xCLEtBQUssQ0FBQ0ssR0FBRyxDQUFDUixDQUFDLENBQUMsRUFBRSxPQUFPcUIsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0VBQ3JELElBQUksQ0FBQ2xCLEtBQUssQ0FBQ0ssR0FBRyxDQUFDTixDQUFDLENBQUMsRUFBRSxPQUFPbUIsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0VBQ3JELE1BQU1DLEtBQUssR0FBR1osY0FBYyxDQUFDRixHQUFHLEVBQUUsT0FBTyxDQUFDO0VBQzFDLElBQUksQ0FBQ2MsS0FBSyxDQUFDL0IsRUFBRSxFQUFFLE9BQU84QixJQUFJLENBQUNDLEtBQUssQ0FBQ3hCLE1BQU0sQ0FBQztFQUN4QyxNQUFNeUIsR0FBRyxHQUFHYixjQUFjLENBQUNGLEdBQUcsRUFBRSxLQUFLLENBQUM7RUFDdEMsSUFBSSxDQUFDZSxHQUFHLENBQUNoQyxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ0UsR0FBRyxDQUFDekIsTUFBTSxDQUFDO0VBQ3BDLE1BQU0wQixDQUFDLEdBQUdqQixjQUFjLENBQUNDLEdBQUcsRUFBRSxHQUFHLENBQUM7RUFDbEMsSUFBSSxDQUFDZ0IsQ0FBQyxDQUFDakMsRUFBRSxFQUFFLE9BQU84QixJQUFJLENBQUNHLENBQUMsQ0FBQzFCLE1BQU0sQ0FBQztFQUNoQyxNQUFNMkIsQ0FBQyxHQUFHbEIsY0FBYyxDQUFDQyxHQUFHLEVBQUUsR0FBRyxDQUFDO0VBQ2xDLElBQUksQ0FBQ2lCLENBQUMsQ0FBQ2xDLEVBQUUsRUFBRSxPQUFPOEIsSUFBSSxDQUFDSSxDQUFDLENBQUMzQixNQUFNLENBQUM7RUFDaEMsSUFBSzBCLENBQUMsQ0FBQ2hDLElBQUksS0FBS0gsU0FBUyxJQUFJbUMsQ0FBQyxDQUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBTWlDLENBQUMsQ0FBQ2pDLElBQUksS0FBS0gsU0FBUyxJQUFJb0MsQ0FBQyxDQUFDakMsSUFBSSxJQUFJLENBQUUsRUFBRSxPQUFPNkIsSUFBSSxDQUFDLDBCQUEwQixDQUFDO0VBQzNILE1BQU1LLEtBQUssR0FBR2QsWUFBWSxDQUFDSixHQUFHLEVBQUUsT0FBTyxFQUFFOUIsV0FBVyxFQUFFLEtBQUssQ0FBQztFQUM1RCxJQUFJLENBQUNnRCxLQUFLLENBQUNuQyxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ0ssS0FBSyxDQUFDNUIsTUFBTSxDQUFDO0VBQ3hDLE1BQU02QixJQUFJLEdBQUdmLFlBQVksQ0FBQ0osR0FBRyxFQUFFLE1BQU0sRUFBRTVCLFVBQVUsRUFBRSxTQUFTLENBQUM7RUFDN0QsSUFBSSxDQUFDK0MsSUFBSSxDQUFDcEMsRUFBRSxFQUFFLE9BQU84QixJQUFJLENBQUNNLElBQUksQ0FBQzdCLE1BQU0sQ0FBQztFQUN0QyxPQUFPO0lBQ0xQLEVBQUUsRUFBRSxJQUFJO0lBQ1JDLElBQUksRUFBRTtNQUNKNEIsRUFBRSxFQUFFWixHQUFHLENBQUNZLEVBQUU7TUFDVkUsS0FBSyxFQUFFQSxLQUFLLENBQUM5QixJQUFJLElBQUlnQixHQUFHLENBQUNZLEVBQUU7TUFDM0IsSUFBSUcsR0FBRyxDQUFDL0IsSUFBSSxLQUFLSCxTQUFTLEdBQUc7UUFBRWtDLEdBQUcsRUFBRUEsR0FBRyxDQUFDL0I7TUFBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7TUFDcERRLENBQUMsRUFBRVEsR0FBRyxDQUFDUixDQUFDO01BQ1JFLENBQUMsRUFBRU0sR0FBRyxDQUFDTixDQUFDO01BQ1JzQixDQUFDLEVBQUVBLENBQUMsQ0FBQ2hDLElBQUksSUFBSVQsY0FBYztNQUMzQjBDLENBQUMsRUFBRUEsQ0FBQyxDQUFDakMsSUFBSSxJQUFJUixjQUFjO01BQzNCMEMsS0FBSyxFQUFFQSxLQUFLLENBQUNsQyxJQUFJO01BQ2pCbUMsSUFBSSxFQUFFQSxJQUFJLENBQUNuQztJQUNiO0VBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBU29DLFNBQVNBLENBQUNwQixHQUFRLEVBQUVVLENBQVMsRUFBRVcsR0FBd0IsRUFBcUI7RUFDbkYsTUFBTUMsS0FBSyxHQUFHLE9BQU90QixHQUFHLENBQUN1QixJQUFJLEtBQUssUUFBUSxJQUFJLE9BQU92QixHQUFHLENBQUN3QixFQUFFLEtBQUssUUFBUTtFQUN4RSxNQUFNYixLQUFLLEdBQUdXLEtBQUssR0FBRyxRQUFRRyxNQUFNLENBQUN6QixHQUFHLENBQUN1QixJQUFJLENBQUMsTUFBTUUsTUFBTSxDQUFDekIsR0FBRyxDQUFDd0IsRUFBRSxDQUFDLEVBQUUsR0FBRyxZQUFZZCxDQUFDLEdBQUcsQ0FBQyxFQUFFO0VBQzFGLE1BQU1HLElBQUksR0FBSXZCLE1BQWMsS0FBeUI7SUFBRVAsRUFBRSxFQUFFLEtBQUs7SUFBRU8sTUFBTSxFQUFFLEdBQUdxQixLQUFLLEtBQUtyQixNQUFNO0VBQUcsQ0FBQyxDQUFDO0VBQ2xHLElBQUksT0FBT1UsR0FBRyxDQUFDdUIsSUFBSSxLQUFLLFFBQVEsSUFBSXZCLEdBQUcsQ0FBQ3VCLElBQUksS0FBSyxFQUFFLEVBQUUsT0FBT1YsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0VBQ2xGLElBQUksT0FBT2IsR0FBRyxDQUFDd0IsRUFBRSxLQUFLLFFBQVEsSUFBSXhCLEdBQUcsQ0FBQ3dCLEVBQUUsS0FBSyxFQUFFLEVBQUUsT0FBT1gsSUFBSSxDQUFDLGNBQWMsQ0FBQztFQUM1RSxJQUFJLENBQUNRLEdBQUcsQ0FBQ0ssR0FBRyxDQUFDMUIsR0FBRyxDQUFDdUIsSUFBSSxDQUFDLEVBQUUsT0FBT1YsSUFBSSxDQUFDLG9CQUFvQmIsR0FBRyxDQUFDdUIsSUFBSSxHQUFHLENBQUM7RUFDcEUsSUFBSSxDQUFDRixHQUFHLENBQUNLLEdBQUcsQ0FBQzFCLEdBQUcsQ0FBQ3dCLEVBQUUsQ0FBQyxFQUFFLE9BQU9YLElBQUksQ0FBQyxvQkFBb0JiLEdBQUcsQ0FBQ3dCLEVBQUUsR0FBRyxDQUFDO0VBQ2hFLE1BQU1HLE1BQU0sR0FBR3pCLGNBQWMsQ0FBQ0YsR0FBRyxFQUFFLEtBQUssQ0FBQztFQUN6QyxJQUFJLENBQUMyQixNQUFNLENBQUM1QyxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ2MsTUFBTSxDQUFDckMsTUFBTSxDQUFDO0VBQzFDLE1BQU1WLEdBQUcsR0FBR0QsUUFBUSxDQUFDZ0QsTUFBTSxDQUFDM0MsSUFBSSxDQUFDO0VBQ2pDLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ2pDLEdBQUcsQ0FBQ1UsTUFBTSxDQUFDO0VBQ3BDLE1BQU13QixLQUFLLEdBQUdaLGNBQWMsQ0FBQ0YsR0FBRyxFQUFFLE9BQU8sQ0FBQztFQUMxQyxJQUFJLENBQUNjLEtBQUssQ0FBQy9CLEVBQUUsRUFBRSxPQUFPOEIsSUFBSSxDQUFDQyxLQUFLLENBQUN4QixNQUFNLENBQUM7RUFDeEMsTUFBTXNDLFFBQVEsR0FBRzVCLEdBQUcsQ0FBQzZCLEtBQUs7RUFDMUIsSUFBSSxDQUFDL0IsTUFBTSxDQUFDOEIsUUFBUSxDQUFDLElBQUksT0FBT0EsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDakMsS0FBSyxDQUFDaUMsUUFBUSxDQUFDLEVBQUUsT0FBT2YsSUFBSSxDQUFDLGtDQUFrQyxDQUFDO0VBQzFILE1BQU1NLElBQUksR0FBR2YsWUFBWSxDQUFDSixHQUFHLEVBQUUsTUFBTSxFQUFFNUIsVUFBVSxFQUFFLFNBQVMsQ0FBQztFQUM3RCxJQUFJLENBQUMrQyxJQUFJLENBQUNwQyxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ00sSUFBSSxDQUFDN0IsTUFBTSxDQUFDO0VBQ3RDLE1BQU13QyxLQUFLLEdBQUczQixZQUFZLENBQUNILEdBQUcsRUFBRSxPQUFPLENBQUM7RUFDeEMsSUFBSSxDQUFDOEIsS0FBSyxDQUFDL0MsRUFBRSxFQUFFLE9BQU84QixJQUFJLENBQUNpQixLQUFLLENBQUN4QyxNQUFNLENBQUM7RUFDeEMsTUFBTXlDLE1BQU0sR0FBRzVCLFlBQVksQ0FBQ0gsR0FBRyxFQUFFLFFBQVEsQ0FBQztFQUMxQyxJQUFJLENBQUMrQixNQUFNLENBQUNoRCxFQUFFLEVBQUUsT0FBTzhCLElBQUksQ0FBQ2tCLE1BQU0sQ0FBQ3pDLE1BQU0sQ0FBQztFQUMxQyxNQUFNMEMsTUFBTSxHQUFHN0IsWUFBWSxDQUFDSCxHQUFHLEVBQUUsUUFBUSxDQUFDO0VBQzFDLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQ2pELEVBQUUsRUFBRSxPQUFPOEIsSUFBSSxDQUFDbUIsTUFBTSxDQUFDMUMsTUFBTSxDQUFDO0VBQzFDLE1BQU0yQyxFQUFFLEdBQUdsQyxjQUFjLENBQUNDLEdBQUcsRUFBRSxJQUFJLENBQUM7RUFDcEMsSUFBSSxDQUFDaUMsRUFBRSxDQUFDbEQsRUFBRSxFQUFFLE9BQU84QixJQUFJLENBQUNvQixFQUFFLENBQUMzQyxNQUFNLENBQUM7RUFDbEMsSUFBSTJDLEVBQUUsQ0FBQ2pELElBQUksS0FBS0gsU0FBUyxLQUFLb0QsRUFBRSxDQUFDakQsSUFBSSxHQUFHLENBQUMsSUFBSWlELEVBQUUsQ0FBQ2pELElBQUksR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPNkIsSUFBSSxDQUFDLDhCQUE4QixDQUFDO0VBQ3RHLE9BQU87SUFDTDlCLEVBQUUsRUFBRSxJQUFJO0lBQ1JDLElBQUksRUFBRTtNQUNKdUMsSUFBSSxFQUFFdkIsR0FBRyxDQUFDdUIsSUFBSTtNQUNkQyxFQUFFLEVBQUV4QixHQUFHLENBQUN3QixFQUFFO01BQ1Y1QyxHQUFHLEVBQUVBLEdBQUcsQ0FBQ0ksSUFBSTtNQUNiLElBQUk4QixLQUFLLENBQUM5QixJQUFJLEtBQUtILFNBQVMsR0FBRztRQUFFaUMsS0FBSyxFQUFFQSxLQUFLLENBQUM5QjtNQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUMxRCxJQUFJLENBQUNjLE1BQU0sQ0FBQzhCLFFBQVEsQ0FBQyxHQUFHO1FBQUVDLEtBQUssRUFBRUosTUFBTSxDQUFDRyxRQUFRO01BQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO01BQ3pEVCxJQUFJLEVBQUVBLElBQUksQ0FBQ25DLElBQUk7TUFDZjhDLEtBQUssRUFBRUEsS0FBSyxDQUFDOUMsSUFBSTtNQUNqQitDLE1BQU0sRUFBRUEsTUFBTSxDQUFDL0MsSUFBSTtNQUNuQmlELEVBQUUsRUFBRUEsRUFBRSxDQUFDakQsSUFBSSxJQUFJLEdBQUc7TUFDbEJnRCxNQUFNLEVBQUVBLE1BQU0sQ0FBQ2hEO0lBQ2pCO0VBQ0YsQ0FBQztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2tELFFBQVFBLENBQUNDLFFBQXdCLEVBQUVDLFFBQXdCLEVBQXNCO0VBQy9GLElBQUlELFFBQVEsQ0FBQ0UsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUV0RCxFQUFFLEVBQUUsS0FBSztJQUFFTyxNQUFNLEVBQUU7RUFBbUIsQ0FBQztFQUMzRSxJQUFJNkMsUUFBUSxDQUFDRSxNQUFNLEdBQUdoRSxjQUFjLEVBQUUsT0FBTztJQUFFVSxFQUFFLEVBQUUsS0FBSztJQUFFTyxNQUFNLEVBQUUsR0FBRzZDLFFBQVEsQ0FBQ0UsTUFBTSxzQkFBc0JoRSxjQUFjO0VBQVksQ0FBQztFQUNySSxJQUFJK0QsUUFBUSxDQUFDQyxNQUFNLEdBQUcvRCxjQUFjLEVBQUUsT0FBTztJQUFFUyxFQUFFLEVBQUUsS0FBSztJQUFFTyxNQUFNLEVBQUUsR0FBRzhDLFFBQVEsQ0FBQ0MsTUFBTSxzQkFBc0IvRCxjQUFjO0VBQVksQ0FBQztFQUNySSxNQUFNZ0UsS0FBaUIsR0FBRyxFQUFFO0VBQzVCLE1BQU1qQixHQUFHLEdBQUcsSUFBSWtCLEdBQUcsQ0FBUyxDQUFDO0VBQzdCLEtBQUssSUFBSTdCLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3lCLFFBQVEsQ0FBQ0UsTUFBTSxFQUFFM0IsQ0FBQyxFQUFFLEVBQUU7SUFDeEMsTUFBTThCLENBQUMsR0FBRy9CLFNBQVMsQ0FBQzBCLFFBQVEsQ0FBQ3pCLENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUM7SUFDbkMsSUFBSSxDQUFDOEIsQ0FBQyxDQUFDekQsRUFBRSxFQUFFLE9BQU95RCxDQUFDO0lBQ25CLElBQUluQixHQUFHLENBQUNLLEdBQUcsQ0FBQ2MsQ0FBQyxDQUFDeEQsSUFBSSxDQUFDNEIsRUFBRSxDQUFDLEVBQUUsT0FBTztNQUFFN0IsRUFBRSxFQUFFLEtBQUs7TUFBRU8sTUFBTSxFQUFFLFNBQVNrRCxDQUFDLENBQUN4RCxJQUFJLENBQUM0QixFQUFFO0lBQWtCLENBQUM7SUFDekZTLEdBQUcsQ0FBQ29CLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDeEQsSUFBSSxDQUFDNEIsRUFBRSxDQUFDO0lBQ2xCMEIsS0FBSyxDQUFDL0MsSUFBSSxDQUFDaUQsQ0FBQyxDQUFDeEQsSUFBSSxDQUFDO0VBQ3BCO0VBQ0EsTUFBTTBELEtBQWlCLEdBQUcsRUFBRTtFQUM1QixLQUFLLElBQUloQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUcwQixRQUFRLENBQUNDLE1BQU0sRUFBRTNCLENBQUMsRUFBRSxFQUFFO0lBQ3hDLE1BQU1pQyxDQUFDLEdBQUd2QixTQUFTLENBQUNnQixRQUFRLENBQUMxQixDQUFDLENBQUMsRUFBRUEsQ0FBQyxFQUFFVyxHQUFHLENBQUM7SUFDeEMsSUFBSSxDQUFDc0IsQ0FBQyxDQUFDNUQsRUFBRSxFQUFFLE9BQU80RCxDQUFDO0lBQ25CRCxLQUFLLENBQUNuRCxJQUFJLENBQUNvRCxDQUFDLENBQUMzRCxJQUFJLENBQUM7RUFDcEI7RUFDQSxPQUFPO0lBQUVELEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRTtNQUFFc0QsS0FBSztNQUFFSTtJQUFNO0VBQUUsQ0FBQztBQUM3Qzs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNFLE9BQU9BLENBQUNyQixJQUFTLEVBQUVDLEVBQU8sRUFBMEI7RUFDbEUsTUFBTXFCLE9BQU8sR0FBR3JCLEVBQUUsQ0FBQ2hDLENBQUMsSUFBSStCLElBQUksQ0FBQy9CLENBQUMsR0FBRytCLElBQUksQ0FBQ1AsQ0FBQztFQUN2QyxNQUFNOEIsS0FBSyxHQUFHdEIsRUFBRSxDQUFDOUIsQ0FBQyxJQUFJNkIsSUFBSSxDQUFDN0IsQ0FBQyxHQUFHNkIsSUFBSSxDQUFDTixDQUFDO0VBQ3JDLE1BQU04QixLQUFLLEdBQUcsQ0FBQ0YsT0FBTyxJQUFJQyxLQUFLLEdBQUc7SUFBRXRELENBQUMsRUFBRStCLElBQUksQ0FBQy9CLENBQUMsR0FBRytCLElBQUksQ0FBQ1AsQ0FBQyxHQUFHLENBQUM7SUFBRXRCLENBQUMsRUFBRTZCLElBQUksQ0FBQzdCLENBQUMsR0FBRzZCLElBQUksQ0FBQ047RUFBRSxDQUFDLEdBQUc7SUFBRXpCLENBQUMsRUFBRStCLElBQUksQ0FBQy9CLENBQUMsR0FBRytCLElBQUksQ0FBQ1AsQ0FBQztJQUFFdEIsQ0FBQyxFQUFFNkIsSUFBSSxDQUFDN0IsQ0FBQyxHQUFHNkIsSUFBSSxDQUFDTixDQUFDLEdBQUc7RUFBRSxDQUFDO0VBQ2pJLE9BQU87SUFBRThCLEtBQUs7SUFBRUMsR0FBRyxFQUFFO01BQUV4RCxDQUFDLEVBQUVnQyxFQUFFLENBQUNoQyxDQUFDO01BQUVFLENBQUMsRUFBRThCLEVBQUUsQ0FBQzlCLENBQUMsR0FBRzhCLEVBQUUsQ0FBQ1AsQ0FBQyxHQUFHO0lBQUU7RUFBRSxDQUFDO0FBQ3hEOztBQUVBO0FBQ08sU0FBU2dDLFFBQVFBLENBQUMxQixJQUFTLEVBQUVDLEVBQU8sRUFBRTVDLEdBQWtCLEVBQVE7RUFDckUsTUFBTTtJQUFFbUUsS0FBSztJQUFFQztFQUFJLENBQUMsR0FBR0osT0FBTyxDQUFDckIsSUFBSSxFQUFFQyxFQUFFLENBQUM7RUFDeEMsT0FBTyxDQUFDdUIsS0FBSyxFQUFFLEdBQUduRSxHQUFHLEVBQUVvRSxHQUFHLENBQUM7QUFDN0I7QUFFTyxTQUFTRSxjQUFjQSxDQUFDakUsTUFBcUIsRUFBVTtFQUM1RCxJQUFJa0UsS0FBSyxHQUFHLENBQUM7RUFDYixLQUFLLElBQUl6QyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUd6QixNQUFNLENBQUNvRCxNQUFNLEVBQUUzQixDQUFDLEVBQUUsRUFBRXlDLEtBQUssSUFBSUMsSUFBSSxDQUFDQyxLQUFLLENBQUNwRSxNQUFNLENBQUN5QixDQUFDLENBQUMsQ0FBQ2xCLENBQUMsR0FBR1AsTUFBTSxDQUFDeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDbEIsQ0FBQyxFQUFFUCxNQUFNLENBQUN5QixDQUFDLENBQUMsQ0FBQ2hCLENBQUMsR0FBR1QsTUFBTSxDQUFDeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDaEIsQ0FBQyxDQUFDO0VBQ3pILE9BQU95RCxLQUFLO0FBQ2Q7O0FBRUE7QUFDTyxTQUFTRyxPQUFPQSxDQUFDckUsTUFBcUIsRUFBRXNFLENBQVMsRUFBTTtFQUM1RCxJQUFJdEUsTUFBTSxDQUFDb0QsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUU3QyxDQUFDLEVBQUUsQ0FBQztJQUFFRSxDQUFDLEVBQUU7RUFBRSxDQUFDO0VBQzlDLE1BQU15RCxLQUFLLEdBQUdELGNBQWMsQ0FBQ2pFLE1BQU0sQ0FBQztFQUNwQyxJQUFJa0UsS0FBSyxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUUsR0FBR2xFLE1BQU0sQ0FBQyxDQUFDO0VBQUUsQ0FBQztFQUN4QyxJQUFJdUUsU0FBUyxHQUFHSixJQUFJLENBQUNLLEdBQUcsQ0FBQyxDQUFDLEVBQUVMLElBQUksQ0FBQ00sR0FBRyxDQUFDLENBQUMsRUFBRUgsQ0FBQyxDQUFDLENBQUMsR0FBR0osS0FBSztFQUNuRCxLQUFLLElBQUl6QyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUd6QixNQUFNLENBQUNvRCxNQUFNLEVBQUUzQixDQUFDLEVBQUUsRUFBRTtJQUN0QyxNQUFNaUQsQ0FBQyxHQUFHMUUsTUFBTSxDQUFDeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN2QixNQUFNa0QsQ0FBQyxHQUFHM0UsTUFBTSxDQUFDeUIsQ0FBQyxDQUFDO0lBQ25CLE1BQU1tRCxHQUFHLEdBQUdULElBQUksQ0FBQ0MsS0FBSyxDQUFDTyxDQUFDLENBQUNwRSxDQUFDLEdBQUdtRSxDQUFDLENBQUNuRSxDQUFDLEVBQUVvRSxDQUFDLENBQUNsRSxDQUFDLEdBQUdpRSxDQUFDLENBQUNqRSxDQUFDLENBQUM7SUFDNUMsSUFBSThELFNBQVMsSUFBSUssR0FBRyxJQUFJQSxHQUFHLEdBQUcsQ0FBQyxFQUFFO01BQy9CLE1BQU1DLENBQUMsR0FBR04sU0FBUyxHQUFHSyxHQUFHO01BQ3pCLE9BQU87UUFBRXJFLENBQUMsRUFBRW1FLENBQUMsQ0FBQ25FLENBQUMsR0FBRyxDQUFDb0UsQ0FBQyxDQUFDcEUsQ0FBQyxHQUFHbUUsQ0FBQyxDQUFDbkUsQ0FBQyxJQUFJc0UsQ0FBQztRQUFFcEUsQ0FBQyxFQUFFaUUsQ0FBQyxDQUFDakUsQ0FBQyxHQUFHLENBQUNrRSxDQUFDLENBQUNsRSxDQUFDLEdBQUdpRSxDQUFDLENBQUNqRSxDQUFDLElBQUlvRTtNQUFFLENBQUM7SUFDL0Q7SUFDQU4sU0FBUyxJQUFJSyxHQUFHO0VBQ2xCO0VBQ0EsT0FBTztJQUFFLEdBQUc1RSxNQUFNLENBQUNBLE1BQU0sQ0FBQ29ELE1BQU0sR0FBRyxDQUFDO0VBQUUsQ0FBQztBQUN6Qzs7QUFFQTtBQUNPLFNBQVMwQixLQUFLQSxDQUFDOUUsTUFBcUIsRUFBVTtFQUNuRCxPQUFPQSxNQUFNLENBQUMrRSxHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFdkQsQ0FBQyxLQUFLLEdBQUdBLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBR3dELEtBQUssQ0FBQ0QsQ0FBQyxDQUFDekUsQ0FBQyxDQUFDLElBQUkwRSxLQUFLLENBQUNELENBQUMsQ0FBQ3ZFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQ2MsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUM1RjtBQUVBLE1BQU0wRCxLQUFLLEdBQUkxQixDQUFTLElBQWFZLElBQUksQ0FBQ2MsS0FBSyxDQUFDMUIsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUc7O0FBRTlEO0FBQ0EsTUFBTTJCLE1BQU0sR0FBRyxDQUFDO0FBWWhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTQyxnQkFBZ0JBLENBQUNILENBQUssRUFBRU4sQ0FBc0QsRUFBb0I7RUFDaEgsTUFBTVUsS0FBSyxHQUFHLENBQUNWLENBQUMsQ0FBQzdDLEtBQUssRUFBRTZDLENBQUMsQ0FBQzlCLEtBQUssQ0FBQyxDQUFDeUMsTUFBTSxDQUFFQyxDQUFDLElBQWtCQSxDQUFDLEtBQUsxRixTQUFTLElBQUkwRixDQUFDLEtBQUssRUFBRSxDQUFDO0VBQ3hGLE1BQU1DLEtBQUssR0FBR3BCLElBQUksQ0FBQ0ssR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHWSxLQUFLLENBQUNMLEdBQUcsQ0FBRU8sQ0FBQyxJQUFLQSxDQUFDLENBQUNsQyxNQUFNLEdBQUc4QixNQUFNLENBQUMsQ0FBQztFQUNqRSxNQUFNTSxLQUFLLEdBQUdyQixJQUFJLENBQUNLLEdBQUcsQ0FBQ0UsQ0FBQyxDQUFDM0IsTUFBTSxHQUFHdEQsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRThGLEtBQUssR0FBRyxDQUFDLENBQUM7RUFDdkUsSUFBSWIsQ0FBQyxDQUFDM0IsTUFBTSxFQUFFO0lBQ1osTUFBTTBDLElBQUksR0FBR2hHLGlCQUFpQixHQUFHLENBQUM7SUFDbEMsTUFBTWlHLFFBQVEsR0FBRyxHQUFHVCxLQUFLLENBQUNELENBQUMsQ0FBQ3pFLENBQUMsQ0FBQyxJQUFJMEUsS0FBSyxDQUFDRCxDQUFDLENBQUN2RSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUl3RSxLQUFLLENBQUNELENBQUMsQ0FBQ3pFLENBQUMsR0FBR2tGLElBQUksQ0FBQyxJQUFJUixLQUFLLENBQUNELENBQUMsQ0FBQ3ZFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSXdFLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDekUsQ0FBQyxHQUFHa0YsSUFBSSxDQUFDLElBQUlSLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDdkUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO0lBQ2pJLElBQUlBLENBQUMsR0FBR3VFLENBQUMsQ0FBQ3ZFLENBQUMsR0FBRyxDQUFDO0lBQ2YsTUFBTWtGLE1BQU0sR0FBR2pCLENBQUMsQ0FBQzdDLEtBQUssR0FBSXBCLENBQUMsSUFBSSxFQUFFLEdBQUliLFNBQVM7SUFDOUMsTUFBTWdHLE1BQU0sR0FBR2xCLENBQUMsQ0FBQzlCLEtBQUssS0FBS2hELFNBQVMsSUFBSThFLENBQUMsQ0FBQzlCLEtBQUssS0FBSyxFQUFFLEdBQUluQyxDQUFDLElBQUksRUFBRSxHQUFJYixTQUFTO0lBQzlFLE9BQU87TUFBRThGLFFBQVE7TUFBRUMsTUFBTTtNQUFFQyxNQUFNO01BQUVyRixDQUFDLEVBQUV5RSxDQUFDLENBQUN6RSxDQUFDO01BQUVzRixHQUFHLEVBQUU7UUFBRUMsRUFBRSxFQUFFZCxDQUFDLENBQUN6RSxDQUFDLEdBQUdpRixLQUFLO1FBQUVPLEVBQUUsRUFBRWYsQ0FBQyxDQUFDdkUsQ0FBQyxHQUFHLEVBQUU7UUFBRXVGLEVBQUUsRUFBRWhCLENBQUMsQ0FBQ3pFLENBQUMsR0FBR2lGLEtBQUs7UUFBRVMsRUFBRSxFQUFFeEYsQ0FBQyxHQUFHO01BQUU7SUFBRSxDQUFDO0VBQ2pIO0VBQ0EsTUFBTXlGLFFBQVEsR0FBR3hCLENBQUMsQ0FBQzlCLEtBQUssS0FBS2hELFNBQVMsSUFBSThFLENBQUMsQ0FBQzlCLEtBQUssS0FBSyxFQUFFO0VBQ3hELE1BQU1nRCxNQUFNLEdBQUdNLFFBQVEsR0FBR2xCLENBQUMsQ0FBQ3ZFLENBQUMsR0FBRyxDQUFDLEdBQUdiLFNBQVM7RUFDN0MsTUFBTStGLE1BQU0sR0FBR2pCLENBQUMsQ0FBQzdDLEtBQUssR0FBSXFFLFFBQVEsR0FBR2xCLENBQUMsQ0FBQ3ZFLENBQUMsR0FBRyxFQUFFLEdBQUd1RSxDQUFDLENBQUN2RSxDQUFDLEdBQUcsQ0FBQyxHQUFJYixTQUFTO0VBQ3BFLE1BQU11RyxHQUFHLEdBQUcsQ0FBQ1IsTUFBTSxJQUFJQyxNQUFNLElBQUlaLENBQUMsQ0FBQ3ZFLENBQUMsSUFBSSxFQUFFO0VBQzFDLE9BQU87SUFBRWtGLE1BQU07SUFBRUMsTUFBTTtJQUFFckYsQ0FBQyxFQUFFeUUsQ0FBQyxDQUFDekUsQ0FBQztJQUFFc0YsR0FBRyxFQUFFO01BQUVDLEVBQUUsRUFBRWQsQ0FBQyxDQUFDekUsQ0FBQyxHQUFHaUYsS0FBSztNQUFFTyxFQUFFLEVBQUVJLEdBQUc7TUFBRUgsRUFBRSxFQUFFaEIsQ0FBQyxDQUFDekUsQ0FBQyxHQUFHaUYsS0FBSztNQUFFUyxFQUFFLEVBQUVqQixDQUFDLENBQUN2RTtJQUFFO0VBQUUsQ0FBQztBQUNoRztBQVNBO0FBQ08sU0FBUzJGLE9BQU9BLENBQUMvQyxLQUFxQixFQUFFZ0QsU0FBcUMsRUFBRUMsV0FBd0MsRUFBVztFQUN2SSxJQUFJUixFQUFFLEdBQUdTLFFBQVE7RUFDakIsSUFBSVIsRUFBRSxHQUFHUSxRQUFRO0VBQ2pCLElBQUlQLEVBQUUsR0FBRyxDQUFDTyxRQUFRO0VBQ2xCLElBQUlOLEVBQUUsR0FBRyxDQUFDTSxRQUFRO0VBQ2xCLE1BQU0vQyxHQUFHLEdBQUdBLENBQUNnRCxFQUFVLEVBQUVDLEVBQVUsRUFBRUMsRUFBVSxFQUFFQyxFQUFVLEtBQVc7SUFDcEViLEVBQUUsR0FBRzNCLElBQUksQ0FBQ00sR0FBRyxDQUFDcUIsRUFBRSxFQUFFVSxFQUFFLENBQUM7SUFDckJULEVBQUUsR0FBRzVCLElBQUksQ0FBQ00sR0FBRyxDQUFDc0IsRUFBRSxFQUFFVSxFQUFFLENBQUM7SUFDckJULEVBQUUsR0FBRzdCLElBQUksQ0FBQ0ssR0FBRyxDQUFDd0IsRUFBRSxFQUFFVSxFQUFFLENBQUM7SUFDckJULEVBQUUsR0FBRzlCLElBQUksQ0FBQ0ssR0FBRyxDQUFDeUIsRUFBRSxFQUFFVSxFQUFFLENBQUM7RUFDdkIsQ0FBQztFQUNELEtBQUssTUFBTXBELENBQUMsSUFBSUYsS0FBSyxFQUFFRyxHQUFHLENBQUNELENBQUMsQ0FBQ2hELENBQUMsRUFBRWdELENBQUMsQ0FBQzlDLENBQUMsRUFBRThDLENBQUMsQ0FBQ2hELENBQUMsR0FBR2dELENBQUMsQ0FBQ3hCLENBQUMsRUFBRXdCLENBQUMsQ0FBQzlDLENBQUMsR0FBRzhDLENBQUMsQ0FBQ3ZCLENBQUMsQ0FBQztFQUMxRCxLQUFLLE1BQU00RSxJQUFJLElBQUlQLFNBQVMsRUFBRSxLQUFLLE1BQU1yQixDQUFDLElBQUk0QixJQUFJLEVBQUVwRCxHQUFHLENBQUN3QixDQUFDLENBQUN6RSxDQUFDLEVBQUV5RSxDQUFDLENBQUN2RSxDQUFDLEVBQUV1RSxDQUFDLENBQUN6RSxDQUFDLEVBQUV5RSxDQUFDLENBQUN2RSxDQUFDLENBQUM7RUFDM0UsS0FBSyxNQUFNaUUsQ0FBQyxJQUFJNEIsV0FBVyxFQUFFOUMsR0FBRyxDQUFDa0IsQ0FBQyxDQUFDbUIsR0FBRyxDQUFDQyxFQUFFLEVBQUVwQixDQUFDLENBQUNtQixHQUFHLENBQUNFLEVBQUUsRUFBRXJCLENBQUMsQ0FBQ21CLEdBQUcsQ0FBQ0csRUFBRSxFQUFFdEIsQ0FBQyxDQUFDbUIsR0FBRyxDQUFDSSxFQUFFLENBQUM7RUFDeEUsSUFBSSxDQUFDekYsTUFBTSxDQUFDSSxRQUFRLENBQUNrRixFQUFFLENBQUMsRUFBRSxPQUFPO0lBQUV2RixDQUFDLEVBQUUsQ0FBQztJQUFFRSxDQUFDLEVBQUUsQ0FBQztJQUFFc0IsQ0FBQyxFQUFFdkMsV0FBVyxHQUFHLENBQUM7SUFBRXdDLENBQUMsRUFBRXhDLFdBQVcsR0FBRztFQUFFLENBQUM7RUFDdkYsT0FBTztJQUFFZSxDQUFDLEVBQUV1RixFQUFFLEdBQUd0RyxXQUFXO0lBQUVpQixDQUFDLEVBQUVzRixFQUFFLEdBQUd2RyxXQUFXO0lBQUV1QyxDQUFDLEVBQUVpRSxFQUFFLEdBQUdGLEVBQUUsR0FBR3RHLFdBQVcsR0FBRyxDQUFDO0lBQUV3QyxDQUFDLEVBQUVpRSxFQUFFLEdBQUdGLEVBQUUsR0FBR3ZHLFdBQVcsR0FBRztFQUFFLENBQUM7QUFDakg7O0FBRUE7O0FBT08sU0FBU3FILFFBQVFBLENBQUNDLEtBQWdCLEVBQVk7RUFDbkQsTUFBTUMsSUFBSSxHQUFHLElBQUlDLEdBQUcsQ0FBQ0YsS0FBSyxDQUFDekQsS0FBSyxDQUFDMEIsR0FBRyxDQUFFeEIsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQzVCLEVBQUUsRUFBRTRCLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkQsTUFBTUUsS0FBSyxHQUFHcUQsS0FBSyxDQUFDckQsS0FBSyxDQUFDc0IsR0FBRyxDQUFFa0MsSUFBSSxJQUFLO0lBQ3RDLE1BQU1qSCxNQUFNLEdBQUdnRSxRQUFRLENBQUMrQyxJQUFJLENBQUNHLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDM0UsSUFBSSxDQUFDLEVBQUd5RSxJQUFJLENBQUNHLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDMUUsRUFBRSxDQUFDLEVBQUcwRSxJQUFJLENBQUN0SCxHQUFHLENBQUM7SUFDM0UsTUFBTXdILFNBQVMsR0FBR0YsSUFBSSxDQUFDbEUsTUFBTSxJQUFJLENBQUNrRSxJQUFJLENBQUNwRixLQUFLLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDb0YsSUFBSSxDQUFDckUsS0FBSyxJQUFJLEVBQUUsTUFBTSxFQUFFO0lBQ3ZGLE1BQU13RSxVQUFVLEdBQUdELFNBQVMsR0FBR2hDLGdCQUFnQixDQUFDZCxPQUFPLENBQUNyRSxNQUFNLEVBQUVpSCxJQUFJLENBQUNqRSxFQUFFLENBQUMsRUFBRWlFLElBQUksQ0FBQyxHQUFHckgsU0FBUztJQUMzRixPQUFPO01BQUVxSCxJQUFJO01BQUVqSCxNQUFNO01BQUVxSCxDQUFDLEVBQUV2QyxLQUFLLENBQUM5RSxNQUFNLENBQUM7TUFBRSxJQUFJb0gsVUFBVSxHQUFHO1FBQUVBO01BQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUFFLENBQUM7RUFDbEYsQ0FBQyxDQUFDO0VBQ0YsTUFBTUUsRUFBRSxHQUFHbEIsT0FBTyxDQUNoQlUsS0FBSyxDQUFDekQsS0FBSyxFQUNYSSxLQUFLLENBQUNzQixHQUFHLENBQUVyQixDQUFDLElBQUtBLENBQUMsQ0FBQzFELE1BQU0sQ0FBQyxFQUMxQnlELEtBQUssQ0FBQzhELE9BQU8sQ0FBRTdELENBQUMsSUFBTUEsQ0FBQyxDQUFDMEQsVUFBVSxHQUFHLENBQUMxRCxDQUFDLENBQUMwRCxVQUFVLENBQUMsR0FBRyxFQUFHLENBQzNELENBQUM7RUFDRCxPQUFPO0lBQUUvRCxLQUFLLEVBQUV5RCxLQUFLLENBQUN6RCxLQUFLO0lBQUVJLEtBQUs7SUFBRTJDLE9BQU8sRUFBRWtCO0VBQUcsQ0FBQztBQUNuRDs7QUFFQTtBQUNPLFNBQVNFLGFBQWFBLENBQUNDLEtBQXlCLEVBQUVDLElBQWMsRUFBVTtFQUMvRSxNQUFNWCxJQUFJLEdBQUcsSUFBSUMsR0FBRyxDQUFDVSxJQUFJLENBQUNyRSxLQUFLLENBQUMwQixHQUFHLENBQUV4QixDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDNUIsRUFBRSxFQUFFNEIsQ0FBQyxDQUFDMUIsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUM1RCxNQUFNOEYsSUFBSSxHQUFHLEdBQUdGLEtBQUssSUFBSSxjQUFjLEtBQUtDLElBQUksQ0FBQ3JFLEtBQUssQ0FBQ0QsTUFBTSxJQUFJc0UsSUFBSSxDQUFDckUsS0FBSyxDQUFDRCxNQUFNLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPLEtBQUtzRSxJQUFJLENBQUNqRSxLQUFLLENBQUNMLE1BQU0sSUFBSXNFLElBQUksQ0FBQ2pFLEtBQUssQ0FBQ0wsTUFBTSxLQUFLLENBQUMsR0FBRyxZQUFZLEdBQUcsYUFBYSxHQUFHO0VBQzlMLE1BQU13RSxLQUFLLEdBQUdGLElBQUksQ0FBQ2pFLEtBQUssQ0FDckI0QixNQUFNLENBQUUzQixDQUFDLElBQUtBLENBQUMsQ0FBQzBELFVBQVUsS0FBS3hILFNBQVMsQ0FBQyxDQUN6Q21GLEdBQUcsQ0FBQyxDQUFDO0lBQUVrQztFQUFLLENBQUMsS0FBSztJQUNqQixNQUFNWSxJQUFJLEdBQUcsQ0FBQ1osSUFBSSxDQUFDcEYsS0FBSyxFQUFFb0YsSUFBSSxDQUFDckUsS0FBSyxDQUFDLENBQUN5QyxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxLQUFLMUYsU0FBUyxJQUFJMEYsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDL0QsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUMxRixPQUFPLEdBQUd3RixJQUFJLENBQUNHLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDM0UsSUFBSSxDQUFDLE1BQU15RSxJQUFJLENBQUNHLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDMUUsRUFBRSxDQUFDLEtBQUtzRixJQUFJLEdBQUdaLElBQUksQ0FBQ3BFLEtBQUssR0FBRyxVQUFVLEdBQUcsRUFBRSxFQUFFO0VBQ2hHLENBQUMsQ0FBQztFQUNKLE9BQU8rRSxLQUFLLENBQUN4RSxNQUFNLEtBQUssQ0FBQyxHQUFHdUUsSUFBSSxHQUFHLEdBQUdBLElBQUksSUFBSUMsS0FBSyxDQUFDckcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQ25FIiwiaWdub3JlTGlzdCI6W119