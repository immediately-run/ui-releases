"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.checkBufferCoversWindows = checkBufferCoversWindows;
var _window = require("../stdlib/window.ts");
// The static buffer-covers-window check (ARCHITECTURE_PLAN §5.3). "The engine statically checks
// the declarable constraint **buffer ≥ longest dependent window** and reports violations at edit
// time." A formula that windows `1h` over a feed the connector only retains for `30m` can never
// see a full window — that is an authoring error, catchable before a single frame arrives. Pure:
// it compares declared durations, no runtime data.
//
// A time window over a **count-retained** feed (`keepLast`, no `keepFor`) cannot be verified
// statically — coverage then depends on the arrival rate — so it is a *warning*, not a pass and
// not a hard error.

/** A window declared at an input site (`{ feed, window }` on a cell), for the diagnostic. */

/**
 * Check every declared window against its feed's retention. `retentions` maps feed name →
 * policy. An unknown feed, or a window longer than a time-bounded buffer, is an error; a window
 * over a count-only (or unbounded) buffer is a warning.
 */
function checkBufferCoversWindows(retentions, windows) {
  const out = [];
  for (const w of windows) {
    const windowMs = (0, _window.parseDuration)(w.window);
    const policy = retentions[w.feed];
    if (policy === undefined) {
      out.push({
        severity: 'error',
        feed: w.feed,
        window: w.window,
        site: w.site,
        message: `window over unknown feed "${w.feed}".`
      });
      continue;
    }
    if (policy.keepFor === undefined) {
      out.push({
        severity: 'warning',
        feed: w.feed,
        window: w.window,
        site: w.site,
        message: `feed "${w.feed}" has no keepFor — a ${w.window} window over a count-retained buffer can't be guaranteed statically.`
      });
      continue;
    }
    if (windowMs > (0, _window.parseDuration)(policy.keepFor)) {
      out.push({
        severity: 'error',
        feed: w.feed,
        window: w.window,
        site: w.site,
        message: `window ${w.window} exceeds feed "${w.feed}" retention keepFor=${policy.keepFor}.`
      });
    }
  }
  return out;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfd2luZG93IiwicmVxdWlyZSIsImNoZWNrQnVmZmVyQ292ZXJzV2luZG93cyIsInJldGVudGlvbnMiLCJ3aW5kb3dzIiwib3V0IiwidyIsIndpbmRvd01zIiwicGFyc2VEdXJhdGlvbiIsIndpbmRvdyIsInBvbGljeSIsImZlZWQiLCJ1bmRlZmluZWQiLCJwdXNoIiwic2V2ZXJpdHkiLCJzaXRlIiwibWVzc2FnZSIsImtlZXBGb3IiXSwic291cmNlcyI6WyJjb25zdHJhaW50cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgc3RhdGljIGJ1ZmZlci1jb3ZlcnMtd2luZG93IGNoZWNrIChBUkNISVRFQ1RVUkVfUExBTiDCpzUuMykuIFwiVGhlIGVuZ2luZSBzdGF0aWNhbGx5IGNoZWNrc1xuLy8gdGhlIGRlY2xhcmFibGUgY29uc3RyYWludCAqKmJ1ZmZlciDiiaUgbG9uZ2VzdCBkZXBlbmRlbnQgd2luZG93KiogYW5kIHJlcG9ydHMgdmlvbGF0aW9ucyBhdCBlZGl0XG4vLyB0aW1lLlwiIEEgZm9ybXVsYSB0aGF0IHdpbmRvd3MgYDFoYCBvdmVyIGEgZmVlZCB0aGUgY29ubmVjdG9yIG9ubHkgcmV0YWlucyBmb3IgYDMwbWAgY2FuIG5ldmVyXG4vLyBzZWUgYSBmdWxsIHdpbmRvdyDigJQgdGhhdCBpcyBhbiBhdXRob3JpbmcgZXJyb3IsIGNhdGNoYWJsZSBiZWZvcmUgYSBzaW5nbGUgZnJhbWUgYXJyaXZlcy4gUHVyZTpcbi8vIGl0IGNvbXBhcmVzIGRlY2xhcmVkIGR1cmF0aW9ucywgbm8gcnVudGltZSBkYXRhLlxuLy9cbi8vIEEgdGltZSB3aW5kb3cgb3ZlciBhICoqY291bnQtcmV0YWluZWQqKiBmZWVkIChga2VlcExhc3RgLCBubyBga2VlcEZvcmApIGNhbm5vdCBiZSB2ZXJpZmllZFxuLy8gc3RhdGljYWxseSDigJQgY292ZXJhZ2UgdGhlbiBkZXBlbmRzIG9uIHRoZSBhcnJpdmFsIHJhdGUg4oCUIHNvIGl0IGlzIGEgKndhcm5pbmcqLCBub3QgYSBwYXNzIGFuZFxuLy8gbm90IGEgaGFyZCBlcnJvci5cblxuaW1wb3J0IHsgcGFyc2VEdXJhdGlvbiB9IGZyb20gJy4uL3N0ZGxpYi93aW5kb3cudHMnO1xuaW1wb3J0IHR5cGUgeyBSZXRlbnRpb25Qb2xpY3kgfSBmcm9tICcuL2J1ZmZlci50cyc7XG5cbi8qKiBBIHdpbmRvdyBkZWNsYXJlZCBhdCBhbiBpbnB1dCBzaXRlIChgeyBmZWVkLCB3aW5kb3cgfWAgb24gYSBjZWxsKSwgZm9yIHRoZSBkaWFnbm9zdGljLiAqL1xuZXhwb3J0IGludGVyZmFjZSBXaW5kb3dEZWNsIHtcbiAgZmVlZDogc3RyaW5nO1xuICB3aW5kb3c6IHN0cmluZztcbiAgLyoqIFRoZSBkZWNsYXJpbmcgY2VsbCBpZCwgZm9yIHRoZSBlZGl0LXRpbWUgZGlhZ25vc3RpYy4gKi9cbiAgc2l0ZTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvdmVyYWdlVmlvbGF0aW9uIHtcbiAgc2V2ZXJpdHk6ICdlcnJvcicgfCAnd2FybmluZyc7XG4gIGZlZWQ6IHN0cmluZztcbiAgd2luZG93OiBzdHJpbmc7XG4gIHNpdGU6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENoZWNrIGV2ZXJ5IGRlY2xhcmVkIHdpbmRvdyBhZ2FpbnN0IGl0cyBmZWVkJ3MgcmV0ZW50aW9uLiBgcmV0ZW50aW9uc2AgbWFwcyBmZWVkIG5hbWUg4oaSXG4gKiBwb2xpY3kuIEFuIHVua25vd24gZmVlZCwgb3IgYSB3aW5kb3cgbG9uZ2VyIHRoYW4gYSB0aW1lLWJvdW5kZWQgYnVmZmVyLCBpcyBhbiBlcnJvcjsgYSB3aW5kb3dcbiAqIG92ZXIgYSBjb3VudC1vbmx5IChvciB1bmJvdW5kZWQpIGJ1ZmZlciBpcyBhIHdhcm5pbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0J1ZmZlckNvdmVyc1dpbmRvd3MoXG4gIHJldGVudGlvbnM6IFJlY29yZDxzdHJpbmcsIFJldGVudGlvblBvbGljeT4sXG4gIHdpbmRvd3M6IHJlYWRvbmx5IFdpbmRvd0RlY2xbXSxcbik6IENvdmVyYWdlVmlvbGF0aW9uW10ge1xuICBjb25zdCBvdXQ6IENvdmVyYWdlVmlvbGF0aW9uW10gPSBbXTtcbiAgZm9yIChjb25zdCB3IG9mIHdpbmRvd3MpIHtcbiAgICBjb25zdCB3aW5kb3dNcyA9IHBhcnNlRHVyYXRpb24ody53aW5kb3cpO1xuICAgIGNvbnN0IHBvbGljeSA9IHJldGVudGlvbnNbdy5mZWVkXTtcbiAgICBpZiAocG9saWN5ID09PSB1bmRlZmluZWQpIHtcbiAgICAgIG91dC5wdXNoKHsgc2V2ZXJpdHk6ICdlcnJvcicsIGZlZWQ6IHcuZmVlZCwgd2luZG93OiB3LndpbmRvdywgc2l0ZTogdy5zaXRlLCBtZXNzYWdlOiBgd2luZG93IG92ZXIgdW5rbm93biBmZWVkIFwiJHt3LmZlZWR9XCIuYCB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAocG9saWN5LmtlZXBGb3IgPT09IHVuZGVmaW5lZCkge1xuICAgICAgb3V0LnB1c2goe1xuICAgICAgICBzZXZlcml0eTogJ3dhcm5pbmcnLFxuICAgICAgICBmZWVkOiB3LmZlZWQsXG4gICAgICAgIHdpbmRvdzogdy53aW5kb3csXG4gICAgICAgIHNpdGU6IHcuc2l0ZSxcbiAgICAgICAgbWVzc2FnZTogYGZlZWQgXCIke3cuZmVlZH1cIiBoYXMgbm8ga2VlcEZvciDigJQgYSAke3cud2luZG93fSB3aW5kb3cgb3ZlciBhIGNvdW50LXJldGFpbmVkIGJ1ZmZlciBjYW4ndCBiZSBndWFyYW50ZWVkIHN0YXRpY2FsbHkuYCxcbiAgICAgIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh3aW5kb3dNcyA+IHBhcnNlRHVyYXRpb24ocG9saWN5LmtlZXBGb3IpKSB7XG4gICAgICBvdXQucHVzaCh7XG4gICAgICAgIHNldmVyaXR5OiAnZXJyb3InLFxuICAgICAgICBmZWVkOiB3LmZlZWQsXG4gICAgICAgIHdpbmRvdzogdy53aW5kb3csXG4gICAgICAgIHNpdGU6IHcuc2l0ZSxcbiAgICAgICAgbWVzc2FnZTogYHdpbmRvdyAke3cud2luZG93fSBleGNlZWRzIGZlZWQgXCIke3cuZmVlZH1cIiByZXRlbnRpb24ga2VlcEZvcj0ke3BvbGljeS5rZWVwRm9yfS5gLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVVBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQVZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFLQTs7QUFnQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLHdCQUF3QkEsQ0FDdENDLFVBQTJDLEVBQzNDQyxPQUE4QixFQUNUO0VBQ3JCLE1BQU1DLEdBQXdCLEdBQUcsRUFBRTtFQUNuQyxLQUFLLE1BQU1DLENBQUMsSUFBSUYsT0FBTyxFQUFFO0lBQ3ZCLE1BQU1HLFFBQVEsR0FBRyxJQUFBQyxxQkFBYSxFQUFDRixDQUFDLENBQUNHLE1BQU0sQ0FBQztJQUN4QyxNQUFNQyxNQUFNLEdBQUdQLFVBQVUsQ0FBQ0csQ0FBQyxDQUFDSyxJQUFJLENBQUM7SUFDakMsSUFBSUQsTUFBTSxLQUFLRSxTQUFTLEVBQUU7TUFDeEJQLEdBQUcsQ0FBQ1EsSUFBSSxDQUFDO1FBQUVDLFFBQVEsRUFBRSxPQUFPO1FBQUVILElBQUksRUFBRUwsQ0FBQyxDQUFDSyxJQUFJO1FBQUVGLE1BQU0sRUFBRUgsQ0FBQyxDQUFDRyxNQUFNO1FBQUVNLElBQUksRUFBRVQsQ0FBQyxDQUFDUyxJQUFJO1FBQUVDLE9BQU8sRUFBRSw2QkFBNkJWLENBQUMsQ0FBQ0ssSUFBSTtNQUFLLENBQUMsQ0FBQztNQUMvSDtJQUNGO0lBQ0EsSUFBSUQsTUFBTSxDQUFDTyxPQUFPLEtBQUtMLFNBQVMsRUFBRTtNQUNoQ1AsR0FBRyxDQUFDUSxJQUFJLENBQUM7UUFDUEMsUUFBUSxFQUFFLFNBQVM7UUFDbkJILElBQUksRUFBRUwsQ0FBQyxDQUFDSyxJQUFJO1FBQ1pGLE1BQU0sRUFBRUgsQ0FBQyxDQUFDRyxNQUFNO1FBQ2hCTSxJQUFJLEVBQUVULENBQUMsQ0FBQ1MsSUFBSTtRQUNaQyxPQUFPLEVBQUUsU0FBU1YsQ0FBQyxDQUFDSyxJQUFJLHdCQUF3QkwsQ0FBQyxDQUFDRyxNQUFNO01BQzFELENBQUMsQ0FBQztNQUNGO0lBQ0Y7SUFDQSxJQUFJRixRQUFRLEdBQUcsSUFBQUMscUJBQWEsRUFBQ0UsTUFBTSxDQUFDTyxPQUFPLENBQUMsRUFBRTtNQUM1Q1osR0FBRyxDQUFDUSxJQUFJLENBQUM7UUFDUEMsUUFBUSxFQUFFLE9BQU87UUFDakJILElBQUksRUFBRUwsQ0FBQyxDQUFDSyxJQUFJO1FBQ1pGLE1BQU0sRUFBRUgsQ0FBQyxDQUFDRyxNQUFNO1FBQ2hCTSxJQUFJLEVBQUVULENBQUMsQ0FBQ1MsSUFBSTtRQUNaQyxPQUFPLEVBQUUsVUFBVVYsQ0FBQyxDQUFDRyxNQUFNLGtCQUFrQkgsQ0FBQyxDQUFDSyxJQUFJLHVCQUF1QkQsTUFBTSxDQUFDTyxPQUFPO01BQzFGLENBQUMsQ0FBQztJQUNKO0VBQ0Y7RUFDQSxPQUFPWixHQUFHO0FBQ1oiLCJpZ25vcmVMaXN0IjpbXX0=