var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ShowAbove;
var _attrs = require("../attrs.ts");
var _renderContext = require("../renderContext.ts");
var _useContainerWidth = require("../useContainerWidth.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // ShowAbove — conditional render when the measured dimension is ≥ a literal threshold
// (§3.3.1 point 4). Exactly one of `width`/`height` (container px, via ResizeObserver) or
// `dpr` (via matchMedia) selects the axis. This is conditional *render*, not `display:none` —
// a hidden subtree is never mounted (a hidden chart never draws) — and re-evaluated on
// resize/DPR change. Resize ≠ recompute: the data channel is untouched.
function ShowAbove({
  node
}) {
  _s();
  const renderNodes = (0, _renderContext.useRenderNodes)();
  const {
    ref,
    width,
    height
  } = (0, _useContainerWidth.useContainerSize)();
  const dpr = (0, _useContainerWidth.useDpr)();
  const wT = (0, _attrs.attrNumber)(node, 'width');
  const hT = (0, _attrs.attrNumber)(node, 'height');
  const dT = (0, _attrs.attrNumber)(node, 'dpr');
  const measured = wT !== undefined ? width : hT !== undefined ? height : dpr;
  const threshold = wT ?? hT ?? dT ?? 0;
  const show = measured >= threshold;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-responsive",
    ref: ref,
    "data-show": show || undefined,
    children: show ? renderNodes(node.children) : null
  });
}
_s(ShowAbove, "kiqUQUXWGmApBAzThmNmW8v4LJk=", false, function () {
  return [_renderContext.useRenderNodes, _useContainerWidth.useContainerSize, _useContainerWidth.useDpr];
});
_c = ShowAbove;
var _c;
$RefreshReg$(_c, "ShowAbove");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlbmRlckNvbnRleHQiLCJfdXNlQ29udGFpbmVyV2lkdGgiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiU2hvd0Fib3ZlIiwibm9kZSIsInJlbmRlck5vZGVzIiwidXNlUmVuZGVyTm9kZXMiLCJyZWYiLCJ3aWR0aCIsImhlaWdodCIsInVzZUNvbnRhaW5lclNpemUiLCJkcHIiLCJ1c2VEcHIiLCJ3VCIsImF0dHJOdW1iZXIiLCJoVCIsImRUIiwibWVhc3VyZWQiLCJ1bmRlZmluZWQiLCJ0aHJlc2hvbGQiLCJzaG93IiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNob3dBYm92ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gU2hvd0Fib3ZlIOKAlCBjb25kaXRpb25hbCByZW5kZXIgd2hlbiB0aGUgbWVhc3VyZWQgZGltZW5zaW9uIGlzIOKJpSBhIGxpdGVyYWwgdGhyZXNob2xkXG4vLyAowqczLjMuMSBwb2ludCA0KS4gRXhhY3RseSBvbmUgb2YgYHdpZHRoYC9gaGVpZ2h0YCAoY29udGFpbmVyIHB4LCB2aWEgUmVzaXplT2JzZXJ2ZXIpIG9yXG4vLyBgZHByYCAodmlhIG1hdGNoTWVkaWEpIHNlbGVjdHMgdGhlIGF4aXMuIFRoaXMgaXMgY29uZGl0aW9uYWwgKnJlbmRlciosIG5vdCBgZGlzcGxheTpub25lYCDigJRcbi8vIGEgaGlkZGVuIHN1YnRyZWUgaXMgbmV2ZXIgbW91bnRlZCAoYSBoaWRkZW4gY2hhcnQgbmV2ZXIgZHJhd3MpIOKAlCBhbmQgcmUtZXZhbHVhdGVkIG9uXG4vLyByZXNpemUvRFBSIGNoYW5nZS4gUmVzaXplIOKJoCByZWNvbXB1dGU6IHRoZSBkYXRhIGNoYW5uZWwgaXMgdW50b3VjaGVkLlxuaW1wb3J0IHR5cGUgeyBDb21wb25lbnROb2RlIH0gZnJvbSAnLi4vLi4vbm9kZXMudHMnO1xuaW1wb3J0IHsgYXR0ck51bWJlciB9IGZyb20gJy4uL2F0dHJzLnRzJztcbmltcG9ydCB7IHVzZVJlbmRlck5vZGVzIH0gZnJvbSAnLi4vcmVuZGVyQ29udGV4dC50cyc7XG5pbXBvcnQgeyB1c2VDb250YWluZXJTaXplLCB1c2VEcHIgfSBmcm9tICcuLi91c2VDb250YWluZXJXaWR0aC50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNob3dBYm92ZSh7IG5vZGUgfTogeyBub2RlOiBDb21wb25lbnROb2RlIH0pIHtcbiAgY29uc3QgcmVuZGVyTm9kZXMgPSB1c2VSZW5kZXJOb2RlcygpO1xuICBjb25zdCB7IHJlZiwgd2lkdGgsIGhlaWdodCB9ID0gdXNlQ29udGFpbmVyU2l6ZSgpO1xuICBjb25zdCBkcHIgPSB1c2VEcHIoKTtcblxuICBjb25zdCB3VCA9IGF0dHJOdW1iZXIobm9kZSwgJ3dpZHRoJyk7XG4gIGNvbnN0IGhUID0gYXR0ck51bWJlcihub2RlLCAnaGVpZ2h0Jyk7XG4gIGNvbnN0IGRUID0gYXR0ck51bWJlcihub2RlLCAnZHByJyk7XG5cbiAgY29uc3QgbWVhc3VyZWQgPSB3VCAhPT0gdW5kZWZpbmVkID8gd2lkdGggOiBoVCAhPT0gdW5kZWZpbmVkID8gaGVpZ2h0IDogZHByO1xuICBjb25zdCB0aHJlc2hvbGQgPSB3VCA/PyBoVCA/PyBkVCA/PyAwO1xuICBjb25zdCBzaG93ID0gbWVhc3VyZWQgPj0gdGhyZXNob2xkO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZXNwb25zaXZlXCIgcmVmPXtyZWZ9IGRhdGEtc2hvdz17c2hvdyB8fCB1bmRlZmluZWR9PlxuICAgICAge3Nob3cgPyByZW5kZXJOb2Rlcyhub2RlLmNoaWxkcmVuKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU1BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGtCQUFBLEdBQUFGLE9BQUE7QUFBbUUsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBUm5FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNZSxTQUFTQyxTQUFTQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBSCxFQUFBO0VBQ25FLE1BQU1JLFdBQVcsR0FBRyxJQUFBQyw2QkFBYyxFQUFDLENBQUM7RUFDcEMsTUFBTTtJQUFFQyxHQUFHO0lBQUVDLEtBQUs7SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQUMsbUNBQWdCLEVBQUMsQ0FBQztFQUNqRCxNQUFNQyxHQUFHLEdBQUcsSUFBQUMseUJBQU0sRUFBQyxDQUFDO0VBRXBCLE1BQU1DLEVBQUUsR0FBRyxJQUFBQyxpQkFBVSxFQUFDVixJQUFJLEVBQUUsT0FBTyxDQUFDO0VBQ3BDLE1BQU1XLEVBQUUsR0FBRyxJQUFBRCxpQkFBVSxFQUFDVixJQUFJLEVBQUUsUUFBUSxDQUFDO0VBQ3JDLE1BQU1ZLEVBQUUsR0FBRyxJQUFBRixpQkFBVSxFQUFDVixJQUFJLEVBQUUsS0FBSyxDQUFDO0VBRWxDLE1BQU1hLFFBQVEsR0FBR0osRUFBRSxLQUFLSyxTQUFTLEdBQUdWLEtBQUssR0FBR08sRUFBRSxLQUFLRyxTQUFTLEdBQUdULE1BQU0sR0FBR0UsR0FBRztFQUMzRSxNQUFNUSxTQUFTLEdBQUdOLEVBQUUsSUFBSUUsRUFBRSxJQUFJQyxFQUFFLElBQUksQ0FBQztFQUNyQyxNQUFNSSxJQUFJLEdBQUdILFFBQVEsSUFBSUUsU0FBUztFQUVsQyxvQkFDRSxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsZUFBZTtJQUFDZixHQUFHLEVBQUVBLEdBQUk7SUFBQyxhQUFXYSxJQUFJLElBQUlGLFNBQVU7SUFBQUssUUFBQSxFQUNuRUgsSUFBSSxHQUFHZixXQUFXLENBQUNELElBQUksQ0FBQ21CLFFBQVEsQ0FBQyxHQUFHO0VBQUksQ0FDdEMsQ0FBQztBQUVWO0FBQUN0QixFQUFBLENBbEJ1QkUsU0FBUztFQUFBLFFBQ1hHLDZCQUFjLEVBQ0hJLG1DQUFnQixFQUNuQ0UseUJBQU07QUFBQTtBQUFBWSxFQUFBLEdBSElyQixTQUFTO0FBQUEsSUFBQXFCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}