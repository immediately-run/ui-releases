var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Facets;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _bindingsContext = require("../bindingsContext.ts");
var _shape = require("../shape.ts");
var _attrs = require("../attrs.ts");
var _chartEncoding = require("../chartEncoding.ts");
var _ChartFigure = _interopRequireDefault(require("./ChartFigure.tsx"));
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _TierSlot = _interopRequireDefault(require("./TierSlot.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Facets — small-multiples (§3.3: "the endorsed alternative to cramming series"). Binds a
// `source`, partitions its rows by the `by` field, and draws one copy of the wrapped Chart per
// partition through the same ChartFigure. The inner Chart inherits Facets' source (its own is
// omitted, per the validator), so faceting is one binding split many ways — no per-facet
// binding names. Non-table / non-ok source → broken tile.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Facets({
  node
}) {
  _s();
  const source = (0, _attrs.attrString)(node, 'source');
  const by = (0, _attrs.attrString)(node, 'by');
  const bound = (0, _bindingsContext.useSource)(source);
  if (bound.status !== 'ok') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "Facets",
      reason: bound.message ?? 'unavailable',
      variant: bound.status === 'missing' ? 'needs-access' : 'error'
    });
  }
  const rows = (0, _shape.asRows)(bound.value);
  if (!rows.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Facets",
    reason: rows.reason
  });
  const chart = node.children.find(c => c.type === 'component' && c.name === 'Chart');
  if (chart === undefined) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Facets",
    reason: "expects one <Chart> child"
  });
  if (by === undefined) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Facets",
    reason: "missing \"by\" field"
  });
  const enc = (0, _chartEncoding.readChartEncoding)(chart);

  // Partition rows by the facet field, preserving first-seen order.
  const groups = new Map();
  const order = [];
  for (const r of rows.data) {
    const key = (0, _shape.labelField)(r, by);
    if (!groups.has(key)) {
      groups.set(key, []);
      order.push(key);
    }
    groups.get(key).push(r);
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("figure", {
    className: "rk-tile rk-facets",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TierSlot.default, {
      tier: bound.tier
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-facets-grid",
      children: order.map(key => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-facet",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "rk-facet-title",
          children: key
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ChartFigure.default, {
          rows: groups.get(key),
          enc: enc,
          ariaLabel: `${enc.kind} for ${key}`
        })]
      }, key))
    })]
  });
}
_s(Facets, "5joLNnTxqRabjF7FIIG70b60L3g=", false, function () {
  return [_bindingsContext.useSource];
});
_c = Facets;
var _c;
$RefreshReg$(_c, "Facets");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9zaGFwZSIsIl9hdHRycyIsIl9jaGFydEVuY29kaW5nIiwiX0NoYXJ0RmlndXJlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Ccm9rZW5UaWxlIiwiX1RpZXJTbG90IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkZhY2V0cyIsIm5vZGUiLCJzb3VyY2UiLCJhdHRyU3RyaW5nIiwiYnkiLCJib3VuZCIsInVzZVNvdXJjZSIsInN0YXR1cyIsImpzeCIsImNvbXBvbmVudCIsInJlYXNvbiIsIm1lc3NhZ2UiLCJ2YXJpYW50Iiwicm93cyIsImFzUm93cyIsInZhbHVlIiwib2siLCJjaGFydCIsImNoaWxkcmVuIiwiZmluZCIsImMiLCJ0eXBlIiwibmFtZSIsInVuZGVmaW5lZCIsImVuYyIsInJlYWRDaGFydEVuY29kaW5nIiwiZ3JvdXBzIiwiTWFwIiwib3JkZXIiLCJyIiwiZGF0YSIsImtleSIsImxhYmVsRmllbGQiLCJoYXMiLCJzZXQiLCJwdXNoIiwiZ2V0IiwianN4cyIsImNsYXNzTmFtZSIsInRpZXIiLCJtYXAiLCJhcmlhTGFiZWwiLCJraW5kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGYWNldHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEZhY2V0cyDigJQgc21hbGwtbXVsdGlwbGVzICjCpzMuMzogXCJ0aGUgZW5kb3JzZWQgYWx0ZXJuYXRpdmUgdG8gY3JhbW1pbmcgc2VyaWVzXCIpLiBCaW5kcyBhXG4vLyBgc291cmNlYCwgcGFydGl0aW9ucyBpdHMgcm93cyBieSB0aGUgYGJ5YCBmaWVsZCwgYW5kIGRyYXdzIG9uZSBjb3B5IG9mIHRoZSB3cmFwcGVkIENoYXJ0IHBlclxuLy8gcGFydGl0aW9uIHRocm91Z2ggdGhlIHNhbWUgQ2hhcnRGaWd1cmUuIFRoZSBpbm5lciBDaGFydCBpbmhlcml0cyBGYWNldHMnIHNvdXJjZSAoaXRzIG93biBpc1xuLy8gb21pdHRlZCwgcGVyIHRoZSB2YWxpZGF0b3IpLCBzbyBmYWNldGluZyBpcyBvbmUgYmluZGluZyBzcGxpdCBtYW55IHdheXMg4oCUIG5vIHBlci1mYWNldFxuLy8gYmluZGluZyBuYW1lcy4gTm9uLXRhYmxlIC8gbm9uLW9rIHNvdXJjZSDihpIgYnJva2VuIHRpbGUuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyB1c2VTb3VyY2UgfSBmcm9tICcuLi9iaW5kaW5nc0NvbnRleHQudHMnO1xuaW1wb3J0IHsgYXNSb3dzLCBsYWJlbEZpZWxkIH0gZnJvbSAnLi4vc2hhcGUudHMnO1xuaW1wb3J0IHsgYXR0clN0cmluZyB9IGZyb20gJy4uL2F0dHJzLnRzJztcbmltcG9ydCB7IHJlYWRDaGFydEVuY29kaW5nIH0gZnJvbSAnLi4vY2hhcnRFbmNvZGluZy50cyc7XG5pbXBvcnQgQ2hhcnRGaWd1cmUgZnJvbSAnLi9DaGFydEZpZ3VyZS50c3gnO1xuaW1wb3J0IEJyb2tlblRpbGUgZnJvbSAnLi9Ccm9rZW5UaWxlLnRzeCc7XG5pbXBvcnQgVGllclNsb3QgZnJvbSAnLi9UaWVyU2xvdC50c3gnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGYWNldHMoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHNvdXJjZSA9IGF0dHJTdHJpbmcobm9kZSwgJ3NvdXJjZScpO1xuICBjb25zdCBieSA9IGF0dHJTdHJpbmcobm9kZSwgJ2J5Jyk7XG4gIGNvbnN0IGJvdW5kID0gdXNlU291cmNlKHNvdXJjZSk7XG5cbiAgaWYgKGJvdW5kLnN0YXR1cyAhPT0gJ29rJykge1xuICAgIHJldHVybiA8QnJva2VuVGlsZSBjb21wb25lbnQ9XCJGYWNldHNcIiByZWFzb249e2JvdW5kLm1lc3NhZ2UgPz8gJ3VuYXZhaWxhYmxlJ30gdmFyaWFudD17Ym91bmQuc3RhdHVzID09PSAnbWlzc2luZycgPyAnbmVlZHMtYWNjZXNzJyA6ICdlcnJvcid9IC8+O1xuICB9XG4gIGNvbnN0IHJvd3MgPSBhc1Jvd3MoYm91bmQudmFsdWUpO1xuICBpZiAoIXJvd3Mub2spIHJldHVybiA8QnJva2VuVGlsZSBjb21wb25lbnQ9XCJGYWNldHNcIiByZWFzb249e3Jvd3MucmVhc29ufSAvPjtcblxuICBjb25zdCBjaGFydCA9IG5vZGUuY2hpbGRyZW4uZmluZCgoYyk6IGMgaXMgQ29tcG9uZW50Tm9kZSA9PiBjLnR5cGUgPT09ICdjb21wb25lbnQnICYmIGMubmFtZSA9PT0gJ0NoYXJ0Jyk7XG4gIGlmIChjaGFydCA9PT0gdW5kZWZpbmVkKSByZXR1cm4gPEJyb2tlblRpbGUgY29tcG9uZW50PVwiRmFjZXRzXCIgcmVhc29uPVwiZXhwZWN0cyBvbmUgPENoYXJ0PiBjaGlsZFwiIC8+O1xuICBpZiAoYnkgPT09IHVuZGVmaW5lZCkgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIkZhY2V0c1wiIHJlYXNvbj0nbWlzc2luZyBcImJ5XCIgZmllbGQnIC8+O1xuICBjb25zdCBlbmMgPSByZWFkQ2hhcnRFbmNvZGluZyhjaGFydCk7XG5cbiAgLy8gUGFydGl0aW9uIHJvd3MgYnkgdGhlIGZhY2V0IGZpZWxkLCBwcmVzZXJ2aW5nIGZpcnN0LXNlZW4gb3JkZXIuXG4gIGNvbnN0IGdyb3VwcyA9IG5ldyBNYXA8c3RyaW5nLCB0eXBlb2Ygcm93cy5kYXRhPigpO1xuICBjb25zdCBvcmRlcjogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCByIG9mIHJvd3MuZGF0YSkge1xuICAgIGNvbnN0IGtleSA9IGxhYmVsRmllbGQociwgYnkpO1xuICAgIGlmICghZ3JvdXBzLmhhcyhrZXkpKSB7XG4gICAgICBncm91cHMuc2V0KGtleSwgW10pO1xuICAgICAgb3JkZXIucHVzaChrZXkpO1xuICAgIH1cbiAgICBncm91cHMuZ2V0KGtleSkhLnB1c2gocik7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwicmstdGlsZSByay1mYWNldHNcIj5cbiAgICAgIDxUaWVyU2xvdCB0aWVyPXtib3VuZC50aWVyfSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1mYWNldHMtZ3JpZFwiPlxuICAgICAgICB7b3JkZXIubWFwKChrZXkpID0+IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWZhY2V0XCIga2V5PXtrZXl9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1mYWNldC10aXRsZVwiPntrZXl9PC9kaXY+XG4gICAgICAgICAgICA8Q2hhcnRGaWd1cmUgcm93cz17Z3JvdXBzLmdldChrZXkpIX0gZW5jPXtlbmN9IGFyaWFMYWJlbD17YCR7ZW5jLmtpbmR9IGZvciAke2tleX1gfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZmlndXJlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQU1BLElBQUFBLGdCQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxjQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxZQUFBLEdBQUFDLHNCQUFBLENBQUFMLE9BQUE7QUFDQSxJQUFBTSxXQUFBLEdBQUFELHNCQUFBLENBQUFMLE9BQUE7QUFDQSxJQUFBTyxTQUFBLEdBQUFGLHNCQUFBLENBQUFMLE9BQUE7QUFBc0MsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsSUFBQVMsRUFBQSxHQUFBQyxZQUFBLElBWnRDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBTCx1QkFBQU0sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVVlLFNBQVNHLE1BQU1BLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDaEUsTUFBTU8sTUFBTSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxRQUFRLENBQUM7RUFDekMsTUFBTUcsRUFBRSxHQUFHLElBQUFELGlCQUFVLEVBQUNGLElBQUksRUFBRSxJQUFJLENBQUM7RUFDakMsTUFBTUksS0FBSyxHQUFHLElBQUFDLDBCQUFTLEVBQUNKLE1BQU0sQ0FBQztFQUUvQixJQUFJRyxLQUFLLENBQUNFLE1BQU0sS0FBSyxJQUFJLEVBQUU7SUFDekIsb0JBQU8sSUFBQWIsV0FBQSxDQUFBYyxHQUFBLEVBQUNoQixXQUFBLENBQUFPLE9BQVU7TUFBQ1UsU0FBUyxFQUFDLFFBQVE7TUFBQ0MsTUFBTSxFQUFFTCxLQUFLLENBQUNNLE9BQU8sSUFBSSxhQUFjO01BQUNDLE9BQU8sRUFBRVAsS0FBSyxDQUFDRSxNQUFNLEtBQUssU0FBUyxHQUFHLGNBQWMsR0FBRztJQUFRLENBQUUsQ0FBQztFQUNsSjtFQUNBLE1BQU1NLElBQUksR0FBRyxJQUFBQyxhQUFNLEVBQUNULEtBQUssQ0FBQ1UsS0FBSyxDQUFDO0VBQ2hDLElBQUksQ0FBQ0YsSUFBSSxDQUFDRyxFQUFFLEVBQUUsb0JBQU8sSUFBQXRCLFdBQUEsQ0FBQWMsR0FBQSxFQUFDaEIsV0FBQSxDQUFBTyxPQUFVO0lBQUNVLFNBQVMsRUFBQyxRQUFRO0lBQUNDLE1BQU0sRUFBRUcsSUFBSSxDQUFDSDtFQUFPLENBQUUsQ0FBQztFQUUzRSxNQUFNTyxLQUFLLEdBQUdoQixJQUFJLENBQUNpQixRQUFRLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUF5QkEsQ0FBQyxDQUFDQyxJQUFJLEtBQUssV0FBVyxJQUFJRCxDQUFDLENBQUNFLElBQUksS0FBSyxPQUFPLENBQUM7RUFDekcsSUFBSUwsS0FBSyxLQUFLTSxTQUFTLEVBQUUsb0JBQU8sSUFBQTdCLFdBQUEsQ0FBQWMsR0FBQSxFQUFDaEIsV0FBQSxDQUFBTyxPQUFVO0lBQUNVLFNBQVMsRUFBQyxRQUFRO0lBQUNDLE1BQU0sRUFBQztFQUEyQixDQUFFLENBQUM7RUFDcEcsSUFBSU4sRUFBRSxLQUFLbUIsU0FBUyxFQUFFLG9CQUFPLElBQUE3QixXQUFBLENBQUFjLEdBQUEsRUFBQ2hCLFdBQUEsQ0FBQU8sT0FBVTtJQUFDVSxTQUFTLEVBQUMsUUFBUTtJQUFDQyxNQUFNLEVBQUM7RUFBb0IsQ0FBRSxDQUFDO0VBQzFGLE1BQU1jLEdBQUcsR0FBRyxJQUFBQyxnQ0FBaUIsRUFBQ1IsS0FBSyxDQUFDOztFQUVwQztFQUNBLE1BQU1TLE1BQU0sR0FBRyxJQUFJQyxHQUFHLENBQTJCLENBQUM7RUFDbEQsTUFBTUMsS0FBZSxHQUFHLEVBQUU7RUFDMUIsS0FBSyxNQUFNQyxDQUFDLElBQUloQixJQUFJLENBQUNpQixJQUFJLEVBQUU7SUFDekIsTUFBTUMsR0FBRyxHQUFHLElBQUFDLGlCQUFVLEVBQUNILENBQUMsRUFBRXpCLEVBQUUsQ0FBQztJQUM3QixJQUFJLENBQUNzQixNQUFNLENBQUNPLEdBQUcsQ0FBQ0YsR0FBRyxDQUFDLEVBQUU7TUFDcEJMLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDSCxHQUFHLEVBQUUsRUFBRSxDQUFDO01BQ25CSCxLQUFLLENBQUNPLElBQUksQ0FBQ0osR0FBRyxDQUFDO0lBQ2pCO0lBQ0FMLE1BQU0sQ0FBQ1UsR0FBRyxDQUFDTCxHQUFHLENBQUMsQ0FBRUksSUFBSSxDQUFDTixDQUFDLENBQUM7RUFDMUI7RUFFQSxvQkFDRSxJQUFBbkMsV0FBQSxDQUFBMkMsSUFBQTtJQUFRQyxTQUFTLEVBQUMsbUJBQW1CO0lBQUFwQixRQUFBLGdCQUNuQyxJQUFBeEIsV0FBQSxDQUFBYyxHQUFBLEVBQUNmLFNBQUEsQ0FBQU0sT0FBUTtNQUFDd0MsSUFBSSxFQUFFbEMsS0FBSyxDQUFDa0M7SUFBSyxDQUFFLENBQUMsZUFDOUIsSUFBQTdDLFdBQUEsQ0FBQWMsR0FBQTtNQUFLOEIsU0FBUyxFQUFDLGdCQUFnQjtNQUFBcEIsUUFBQSxFQUM1QlUsS0FBSyxDQUFDWSxHQUFHLENBQUVULEdBQUcsaUJBQ2IsSUFBQXJDLFdBQUEsQ0FBQTJDLElBQUE7UUFBS0MsU0FBUyxFQUFDLFVBQVU7UUFBQXBCLFFBQUEsZ0JBQ3ZCLElBQUF4QixXQUFBLENBQUFjLEdBQUE7VUFBSzhCLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQXBCLFFBQUEsRUFBRWE7UUFBRyxDQUFNLENBQUMsZUFDM0MsSUFBQXJDLFdBQUEsQ0FBQWMsR0FBQSxFQUFDbEIsWUFBQSxDQUFBUyxPQUFXO1VBQUNjLElBQUksRUFBRWEsTUFBTSxDQUFDVSxHQUFHLENBQUNMLEdBQUcsQ0FBRztVQUFDUCxHQUFHLEVBQUVBLEdBQUk7VUFBQ2lCLFNBQVMsRUFBRSxHQUFHakIsR0FBRyxDQUFDa0IsSUFBSSxRQUFRWCxHQUFHO1FBQUcsQ0FBRSxDQUFDO01BQUEsR0FGekRBLEdBRzFCLENBQ047SUFBQyxDQUNDLENBQUM7RUFBQSxDQUNBLENBQUM7QUFFYjtBQUFDcEMsRUFBQSxDQXpDdUJLLE1BQU07RUFBQSxRQUdkTSwwQkFBUztBQUFBO0FBQUFxQyxFQUFBLEdBSEQzQyxNQUFNO0FBQUEsSUFBQTJDLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}