"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
require("core-js/modules/web.dom-exception.stack.js");
require("core-js/modules/web.structured-clone.js");
var _vitest = require("vitest");
var _loader = require("../document/loader.ts");
var _asyncEngine = require("../engine/asyncEngine.ts");
var _workerTransport = require("../engine/workerTransport.ts");
var _reportSession = require("./reportSession.ts");
var _memoryReader = require("./memoryReader.ts");
var _whatif = require("./whatif.ts");
// The shadow-run orchestrator, end to end over the in-process transport
// (WHATIF_SHADOW_EVALUATION_SPEC §2, gates G-WIF-2/3/4/5/6/6a/10): a real document through
// the real loader, a real base engine, and runShadow over it — asserting the counterfactual
// changes, the pinned baseline's immunity to a moving base session, the deep-copied
// externals (the in-process shared-reference hole, WIF-R1), scratch additivity, verdict
// flips, the durable-subject refusal, and the re-run cross-reference validation.

const MODEL_SHEET = `import { cell } from "@reckoner/stdlib";

export const base_total = cell({
  doc: "sum of fixture rows",
  inputs: { rows: "fixtures.rows" },
  formula: ({ rows }) => rows.reduce((a, r) => a + r.v, 0),
});

export const scaled = cell({
  doc: "total times the factor param",
  inputs: { total: "model.base_total", factor: "params.factor" },
  formula: ({ total, factor }) => total * factor,
});

export const unrelated = cell({
  doc: "independent of everything",
  inputs: {},
  formula: () => 7,
});
`;
const CHECKS_SHEET = `import { testCell, expectEqual } from "@reckoner/stdlib";

export const scaled_matches = testCell({
  kind: "specification",
  subject: "model.scaled",
  expect: ({ result, inputs }) => expectEqual(result, inputs.total * inputs.factor),
});
`;
function docFiles() {
  return {
    '/doc/reckoner.json': JSON.stringify({
      format: 1,
      compat: {
        stdlib: '>=0.1.0',
        catalog: '>=0.1.0'
      },
      worksheets: ['model.sheet.js', 'checks.sheet.js'],
      params: {
        factor: 2
      },
      title: 'What-if harness'
    }),
    '/doc/worksheets/model.sheet.js': MODEL_SHEET,
    '/doc/worksheets/checks.sheet.js': CHECKS_SHEET,
    '/doc/fixtures/rows.frame.json': JSON.stringify({
      rows: [{
        v: 1
      }, {
        v: 2
      }, {
        v: 3
      }],
      tier: 'static'
    })
  };
}

// The loader's DocumentReader over the flat file map (the loader.test.ts shape).
function reader(files) {
  return (0, _memoryReader.memoryReader)(files);
}
async function makeSession() {
  const loaded = await (0, _loader.loadDocument)(reader(docFiles()), '/doc');
  (0, _vitest.expect)(loaded.diagnostics.filter(d => d.severity === 'error')).toEqual([]);
  const sources = Object.fromEntries(loaded.worksheets.map(w => [w.name, w.source]));
  const engine = await _asyncEngine.AsyncEngine.fromSources(sources, {
    transport: (0, _workerTransport.inMemoryTransport)()
  });
  const {
    externals,
    paramRefs
  } = (0, _reportSession.assembleExternals)(loaded);
  await engine.run(externals);
  return {
    engine,
    externals,
    paramRefs,
    nodes: [],
    title: 'What-if harness',
    diagnostics: [],
    sources,
    loaded,
    runtimeFeeds: [],
    authorsNodes: [],
    authorsFromDocument: false
  };
}
function baseKeys(session) {
  return new Map(session.engine.cells().map(c => [c.id, session.engine.result(c.id)?.key]));
}
(0, _vitest.describe)('runShadow — formula variants (G-WIF-2, G-WIF-4)', () => {
  (0, _vitest.it)('changes the varied cell and its dependents in the shadow while the base stays bit-identical', async () => {
    const session = await makeSession();
    const before = baseKeys(session);
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'model.base_total': '({ rows }) => rows.reduce((a, r) => a + r.v, 0) + 100'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.pass.errors.size).toBe(0);
    (0, _vitest.expect)(out.valueOf('model.base_total')).toBe(106);
    (0, _vitest.expect)(out.valueOf('model.scaled')).toBe(212);
    (0, _vitest.expect)(out.valueOf('model.unrelated')).toBe(7);
    const changed = out.deltas.map(d => d.id).sort();
    (0, _vitest.expect)(changed).toEqual(['model.base_total', 'model.scaled']);
    // G-WIF-4: every changed cell is inside the dependents closure of the varied cell.
    for (const id of changed) (0, _vitest.expect)(out.closure.has(id)).toBe(true);

    // The base engine's published results are untouched by the shadow run.
    (0, _vitest.expect)(baseKeys(session)).toEqual(before);
  });
  (0, _vitest.it)('deep-copies the baseline externals: a row-mutating variant cannot corrupt the base session (WIF-R1)', async () => {
    const session = await makeSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'model.base_total': '({ rows }) => { rows.push({ v: 1000 }); return rows.length; }'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);

    // Force a fresh base pass over the (hopefully unmutated) fixture rows.
    await session.engine.update({
      'params.factor': {
        value: 3,
        tier: 'static'
      }
    });
    (0, _vitest.expect)(session.engine.value('model.base_total')).toBe(6);
    (0, _vitest.expect)(session.engine.value('model.scaled')).toBe(18);
  });
  (0, _vitest.it)('surfaces a splice refusal as a typed outcome, never a wrong patch', async () => {
    const session = await makeSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'model.nope': '() => 0'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(false);
    if (out.ok) return;
    (0, _vitest.expect)(out.refusal.code).toBe('unknown-cell');
  });
  (0, _vitest.it)('surfaces a variant that no longer parses as a build-error refusal', async () => {
    const session = await makeSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'model.unrelated': '() => {'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(false);
    if (out.ok) return;
    (0, _vitest.expect)(out.refusal.code).toBe('build-error');
  });
});
(0, _vitest.describe)('runShadow — the pinned baseline (G-WIF-3, G-WIF-4 ticking case)', () => {
  (0, _vitest.it)('settledSnapshot waits for an un-awaited update and returns a coherent, copied pair', async () => {
    const session = await makeSession();
    // Fire-and-forget: the snapshot must include this write and the pass it produced.
    void session.engine.update({
      'params.factor': {
        value: 5,
        tier: 'static'
      }
    });
    const snap = await session.engine.settledSnapshot();
    (0, _vitest.expect)(snap.externals['params.factor'].value).toBe(5);
    (0, _vitest.expect)(snap.pass.results.get('model.scaled')?.value).toBe(30);

    // Feed-buffer keys written straight into the engine appear in the snapshot…
    await session.engine.update({
      'feedBuffers.x': {
        value: [{
          t: 1
        }],
        tier: 'live'
      }
    });
    const snap2 = await session.engine.settledSnapshot();
    (0, _vitest.expect)(snap2.externals['feedBuffers.x'].value).toEqual([{
      t: 1
    }]);
    // …and are copies: mutating the returned value cannot reach the engine.
    snap2.externals['feedBuffers.x'].value.push({
      t: 2
    });
    const snap3 = await session.engine.settledSnapshot();
    (0, _vitest.expect)(snap3.externals['feedBuffers.x'].value).toEqual([{
      t: 1
    }]);
  });
  (0, _vitest.it)('a no-variant shadow over a moving base reports zero deltas against its pinned baseline', async () => {
    const session = await makeSession();
    const baseVerdicts = await session.engine.runTests();

    // A base write racing the run: the snapshot settles it into the baseline, so the
    // shadow computes over the same epoch and the diff is empty (no spurious deltas).
    void session.engine.update({
      'params.factor': {
        value: 9,
        tier: 'static'
      }
    });
    const out = await (0, _whatif.runShadow)(session, {}, (0, _workerTransport.inMemoryTransport)(), baseVerdicts);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.deltas).toEqual([]);
    (0, _vitest.expect)(out.verdictFlips).toEqual([]);
    (0, _vitest.expect)(out.baseline.results.get('model.scaled')?.value).toBe(54);
  });
});
(0, _vitest.describe)('runShadow — scratch (G-WIF-5, G-WIF-6a, G-WIF-10)', () => {
  const SCRATCH = `import { cell, testCell, expectEqual } from "@reckoner/stdlib";

export const probe = cell({
  doc: "ten times the base total",
  inputs: { t: "model.base_total" },
  formula: ({ t }) => t * 10,
});

export const probe_check = testCell({
  kind: "specification",
  subject: "scratch.probe",
  expect: ({ result }) => expectEqual(result, 60),
});
`;
  (0, _vitest.it)('a scratch-only run is additive: durable values and verdicts untouched, scratch cells first-class', async () => {
    const session = await makeSession();
    const baseVerdicts = await session.engine.runTests();
    const before = baseKeys(session);
    const out = await (0, _whatif.runShadow)(session, {
      scratch: SCRATCH
    }, (0, _workerTransport.inMemoryTransport)(), baseVerdicts);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.deltas).toEqual([]);
    (0, _vitest.expect)(baseKeys(session)).toEqual(before);
    (0, _vitest.expect)(out.valueOf('scratch.probe')).toBe(60);
    (0, _vitest.expect)(out.verdicts.get('scratch.probe')?.verdict).not.toBe('untested');
    // The only verdict difference is the scratch subject appearing.
    (0, _vitest.expect)(out.verdictFlips.map(f => f.subject)).toEqual(['scratch.probe']);
    // Scratch cells render as cards: they are in the shadow's cell list.
    (0, _vitest.expect)(out.cells.some(c => c.id === 'scratch.probe')).toBe(true);
  });
  (0, _vitest.it)('refuses a scratch test that targets a durable subject (G-WIF-6a)', async () => {
    const session = await makeSession();
    const hostile = `import { cell, testCell, expectEqual } from "@reckoner/stdlib";

export const sneaky = testCell({
  kind: "specification",
  subject: "model.scaled",
  expect: ({ result }) => expectEqual(result, -1),
});
`;
    const out = await (0, _whatif.runShadow)(session, {
      scratch: hostile
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(false);
    if (out.ok) return;
    (0, _vitest.expect)(out.refusal.code).toBe('scratch-subject');
    (0, _vitest.expect)(out.refusal.message).toContain('model.scaled');
  });
  (0, _vitest.it)('re-runs cross-reference validation: a typo’d external is a diagnostic, not a silent null (G-WIF-10)', async () => {
    const session = await makeSession();
    const typo = `import { cell } from "@reckoner/stdlib";

export const oops = cell({
  doc: "reads a fixture that does not exist",
  inputs: { r: "fixtures.rowz" },
  formula: ({ r }) => r,
});
`;
    const out = await (0, _whatif.runShadow)(session, {
      scratch: typo
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.diagnostics.some(d => d.message.includes('rowz'))).toBe(true);
  });
});
(0, _vitest.describe)('runShadow — verdict flips (G-WIF-6)', () => {
  (0, _vitest.it)('a test-breaking variant flips the subject in the shadow suite; base verdicts untouched', async () => {
    const session = await makeSession();
    const baseVerdicts = await session.engine.runTests();
    const baseScaled = baseVerdicts.get('model.scaled')?.verdict;
    (0, _vitest.expect)(baseScaled).toBeDefined();
    (0, _vitest.expect)(baseScaled).not.toBe('failing');
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'model.scaled': '({ total, factor }) => total * factor + 1'
      }
    }, (0, _workerTransport.inMemoryTransport)(), baseVerdicts);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.verdicts.get('model.scaled')?.verdict).toBe('failing');
    (0, _vitest.expect)(out.verdictFlips).toEqual([{
      subject: 'model.scaled',
      before: baseScaled,
      after: 'failing'
    }]);

    // The base suite still reports the original verdict.
    const after = await session.engine.runTests();
    (0, _vitest.expect)(after.get('model.scaled')?.verdict).toBe(baseScaled);
  });
});
(0, _vitest.describe)('runShadow — span splice through the real build (R3-427)', () => {
  const TWINS_SHEET = `import { cell } from "@reckoner/stdlib";

export const one = cell({
  doc: "the first twin",
  inputs: {},
  formula: () => 1,
});

export const two = cell({
  doc: "the second twin — identical formula text",
  inputs: {},
  formula: () => 1,
});

export const short_sub = cell({
  doc: "a formula that is a substring of longer_sub's",
  inputs: {},
  formula: () => 5 + 1,
});

export const longer_sub = cell({
  doc: "contains short_sub's text as a substring",
  inputs: {},
  formula: () => 5 + 12,
});
`;
  async function twinsSession() {
    const files = {
      '/doc/reckoner.json': JSON.stringify({
        format: 1,
        compat: {
          stdlib: '>=0.1.0',
          catalog: '>=0.1.0'
        },
        worksheets: ['twins.sheet.js'],
        params: {},
        title: 'Twins'
      }),
      '/doc/worksheets/twins.sheet.js': TWINS_SHEET
    };
    const loaded = await (0, _loader.loadDocument)(reader(files), '/doc');
    const sources = Object.fromEntries(loaded.worksheets.map(w => [w.name, w.source]));
    const engine = await _asyncEngine.AsyncEngine.fromSources(sources, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    const {
      externals,
      paramRefs
    } = (0, _reportSession.assembleExternals)(loaded);
    await engine.run(externals);
    return {
      engine,
      externals,
      paramRefs,
      nodes: [],
      title: 'Twins',
      diagnostics: [],
      sources,
      loaded,
      runtimeFeeds: [],
      authorsNodes: [],
      authorsFromDocument: false
    };
  }
  (0, _vitest.it)('descriptors carry structured-clone-safe spans from the build', async () => {
    const session = await twinsSession();
    const one = session.engine.cells().find(c => c.id === 'twins.one');
    (0, _vitest.expect)(one?.span).toBeDefined();
    (0, _vitest.expect)(one?.span?.line).toBe(3);
    const cloned = structuredClone(one);
    (0, _vitest.expect)(cloned?.span).toEqual(one?.span);
    (0, _vitest.expect)(session.engine.tests().every(t => t.subject !== undefined)).toBe(true);
  });
  (0, _vitest.it)('identical formula text in two cells: each splices its OWN block — no formula-ambiguous', async () => {
    const session = await twinsSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'twins.two': '() => 22'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.valueOf('twins.two')).toBe(22);
    (0, _vitest.expect)(out.valueOf('twins.one')).toBe(1); // the other twin untouched
    (0, _vitest.expect)(out.deltas.map(d => d.id)).toEqual(['twins.two']);
  });
  (0, _vitest.it)('a formula that is a substring of another cell splices without refusal', async () => {
    const session = await twinsSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'twins.short_sub': '() => 5 + 100'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.valueOf('twins.short_sub')).toBe(105);
    (0, _vitest.expect)(out.valueOf('twins.longer_sub')).toBe(17); // untouched
  });
  (0, _vitest.it)('both variants at once, same worksheet — descending-block application keeps every span valid', async () => {
    const session = await twinsSession();
    const out = await (0, _whatif.runShadow)(session, {
      variants: {
        'twins.one': '() => 11',
        'twins.two': '() => 22'
      }
    }, (0, _workerTransport.inMemoryTransport)(), null);
    (0, _vitest.expect)(out.ok).toBe(true);
    if (!out.ok) return;
    (0, _vitest.expect)(out.valueOf('twins.one')).toBe(11);
    (0, _vitest.expect)(out.valueOf('twins.two')).toBe(22);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9sb2FkZXIiLCJfYXN5bmNFbmdpbmUiLCJfd29ya2VyVHJhbnNwb3J0IiwiX3JlcG9ydFNlc3Npb24iLCJfbWVtb3J5UmVhZGVyIiwiX3doYXRpZiIsIk1PREVMX1NIRUVUIiwiQ0hFQ0tTX1NIRUVUIiwiZG9jRmlsZXMiLCJKU09OIiwic3RyaW5naWZ5IiwiZm9ybWF0IiwiY29tcGF0Iiwic3RkbGliIiwiY2F0YWxvZyIsIndvcmtzaGVldHMiLCJwYXJhbXMiLCJmYWN0b3IiLCJ0aXRsZSIsInJvd3MiLCJ2IiwidGllciIsInJlYWRlciIsImZpbGVzIiwibWVtb3J5UmVhZGVyIiwibWFrZVNlc3Npb24iLCJsb2FkZWQiLCJsb2FkRG9jdW1lbnQiLCJleHBlY3QiLCJkaWFnbm9zdGljcyIsImZpbHRlciIsImQiLCJzZXZlcml0eSIsInRvRXF1YWwiLCJzb3VyY2VzIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJtYXAiLCJ3IiwibmFtZSIsInNvdXJjZSIsImVuZ2luZSIsIkFzeW5jRW5naW5lIiwiZnJvbVNvdXJjZXMiLCJ0cmFuc3BvcnQiLCJpbk1lbW9yeVRyYW5zcG9ydCIsImV4dGVybmFscyIsInBhcmFtUmVmcyIsImFzc2VtYmxlRXh0ZXJuYWxzIiwicnVuIiwibm9kZXMiLCJydW50aW1lRmVlZHMiLCJhdXRob3JzTm9kZXMiLCJhdXRob3JzRnJvbURvY3VtZW50IiwiYmFzZUtleXMiLCJzZXNzaW9uIiwiTWFwIiwiY2VsbHMiLCJjIiwiaWQiLCJyZXN1bHQiLCJrZXkiLCJkZXNjcmliZSIsIml0IiwiYmVmb3JlIiwib3V0IiwicnVuU2hhZG93IiwidmFyaWFudHMiLCJvayIsInRvQmUiLCJwYXNzIiwiZXJyb3JzIiwic2l6ZSIsInZhbHVlT2YiLCJjaGFuZ2VkIiwiZGVsdGFzIiwic29ydCIsImNsb3N1cmUiLCJoYXMiLCJ1cGRhdGUiLCJ2YWx1ZSIsInJlZnVzYWwiLCJjb2RlIiwic25hcCIsInNldHRsZWRTbmFwc2hvdCIsInJlc3VsdHMiLCJnZXQiLCJ0Iiwic25hcDIiLCJwdXNoIiwic25hcDMiLCJiYXNlVmVyZGljdHMiLCJydW5UZXN0cyIsInZlcmRpY3RGbGlwcyIsImJhc2VsaW5lIiwiU0NSQVRDSCIsInNjcmF0Y2giLCJ2ZXJkaWN0cyIsInZlcmRpY3QiLCJub3QiLCJmIiwic3ViamVjdCIsInNvbWUiLCJob3N0aWxlIiwibWVzc2FnZSIsInRvQ29udGFpbiIsInR5cG8iLCJpbmNsdWRlcyIsImJhc2VTY2FsZWQiLCJ0b0JlRGVmaW5lZCIsImFmdGVyIiwiVFdJTlNfU0hFRVQiLCJ0d2luc1Nlc3Npb24iLCJvbmUiLCJmaW5kIiwic3BhbiIsImxpbmUiLCJjbG9uZWQiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJ0ZXN0cyIsImV2ZXJ5IiwidW5kZWZpbmVkIl0sInNvdXJjZXMiOlsid2hhdGlmLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHNoYWRvdy1ydW4gb3JjaGVzdHJhdG9yLCBlbmQgdG8gZW5kIG92ZXIgdGhlIGluLXByb2Nlc3MgdHJhbnNwb3J0XG4vLyAoV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMgwqcyLCBnYXRlcyBHLVdJRi0yLzMvNC81LzYvNmEvMTApOiBhIHJlYWwgZG9jdW1lbnQgdGhyb3VnaFxuLy8gdGhlIHJlYWwgbG9hZGVyLCBhIHJlYWwgYmFzZSBlbmdpbmUsIGFuZCBydW5TaGFkb3cgb3ZlciBpdCDigJQgYXNzZXJ0aW5nIHRoZSBjb3VudGVyZmFjdHVhbFxuLy8gY2hhbmdlcywgdGhlIHBpbm5lZCBiYXNlbGluZSdzIGltbXVuaXR5IHRvIGEgbW92aW5nIGJhc2Ugc2Vzc2lvbiwgdGhlIGRlZXAtY29waWVkXG4vLyBleHRlcm5hbHMgKHRoZSBpbi1wcm9jZXNzIHNoYXJlZC1yZWZlcmVuY2UgaG9sZSwgV0lGLVIxKSwgc2NyYXRjaCBhZGRpdGl2aXR5LCB2ZXJkaWN0XG4vLyBmbGlwcywgdGhlIGR1cmFibGUtc3ViamVjdCByZWZ1c2FsLCBhbmQgdGhlIHJlLXJ1biBjcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvbi5cbmltcG9ydCB7IGRlc2NyaWJlLCBleHBlY3QsIGl0IH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGxvYWREb2N1bWVudCB9IGZyb20gJy4uL2RvY3VtZW50L2xvYWRlci50cyc7XG5pbXBvcnQgdHlwZSB7IERvY3VtZW50UmVhZGVyIH0gZnJvbSAnLi4vZG9jdW1lbnQvdHlwZXMudHMnO1xuaW1wb3J0IHsgQXN5bmNFbmdpbmUgfSBmcm9tICcuLi9lbmdpbmUvYXN5bmNFbmdpbmUudHMnO1xuaW1wb3J0IHsgaW5NZW1vcnlUcmFuc3BvcnQgfSBmcm9tICcuLi9lbmdpbmUvd29ya2VyVHJhbnNwb3J0LnRzJztcbmltcG9ydCB7IGFzc2VtYmxlRXh0ZXJuYWxzIH0gZnJvbSAnLi9yZXBvcnRTZXNzaW9uLnRzJztcbmltcG9ydCB0eXBlIHsgUmVwb3J0U2Vzc2lvbiB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgeyBtZW1vcnlSZWFkZXIgfSBmcm9tICcuL21lbW9yeVJlYWRlci50cyc7XG5pbXBvcnQgeyBydW5TaGFkb3cgfSBmcm9tICcuL3doYXRpZi50cyc7XG5cbmNvbnN0IE1PREVMX1NIRUVUID0gYGltcG9ydCB7IGNlbGwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG5leHBvcnQgY29uc3QgYmFzZV90b3RhbCA9IGNlbGwoe1xuICBkb2M6IFwic3VtIG9mIGZpeHR1cmUgcm93c1wiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5yb3dzXCIgfSxcbiAgZm9ybXVsYTogKHsgcm93cyB9KSA9PiByb3dzLnJlZHVjZSgoYSwgcikgPT4gYSArIHIudiwgMCksXG59KTtcblxuZXhwb3J0IGNvbnN0IHNjYWxlZCA9IGNlbGwoe1xuICBkb2M6IFwidG90YWwgdGltZXMgdGhlIGZhY3RvciBwYXJhbVwiLFxuICBpbnB1dHM6IHsgdG90YWw6IFwibW9kZWwuYmFzZV90b3RhbFwiLCBmYWN0b3I6IFwicGFyYW1zLmZhY3RvclwiIH0sXG4gIGZvcm11bGE6ICh7IHRvdGFsLCBmYWN0b3IgfSkgPT4gdG90YWwgKiBmYWN0b3IsXG59KTtcblxuZXhwb3J0IGNvbnN0IHVucmVsYXRlZCA9IGNlbGwoe1xuICBkb2M6IFwiaW5kZXBlbmRlbnQgb2YgZXZlcnl0aGluZ1wiLFxuICBpbnB1dHM6IHt9LFxuICBmb3JtdWxhOiAoKSA9PiA3LFxufSk7XG5gO1xuXG5jb25zdCBDSEVDS1NfU0hFRVQgPSBgaW1wb3J0IHsgdGVzdENlbGwsIGV4cGVjdEVxdWFsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcblxuZXhwb3J0IGNvbnN0IHNjYWxlZF9tYXRjaGVzID0gdGVzdENlbGwoe1xuICBraW5kOiBcInNwZWNpZmljYXRpb25cIixcbiAgc3ViamVjdDogXCJtb2RlbC5zY2FsZWRcIixcbiAgZXhwZWN0OiAoeyByZXN1bHQsIGlucHV0cyB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIGlucHV0cy50b3RhbCAqIGlucHV0cy5mYWN0b3IpLFxufSk7XG5gO1xuXG5mdW5jdGlvbiBkb2NGaWxlcygpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgcmV0dXJuIHtcbiAgICAnL2RvYy9yZWNrb25lci5qc29uJzogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgZm9ybWF0OiAxLFxuICAgICAgY29tcGF0OiB7IHN0ZGxpYjogJz49MC4xLjAnLCBjYXRhbG9nOiAnPj0wLjEuMCcgfSxcbiAgICAgIHdvcmtzaGVldHM6IFsnbW9kZWwuc2hlZXQuanMnLCAnY2hlY2tzLnNoZWV0LmpzJ10sXG4gICAgICBwYXJhbXM6IHsgZmFjdG9yOiAyIH0sXG4gICAgICB0aXRsZTogJ1doYXQtaWYgaGFybmVzcycsXG4gICAgfSksXG4gICAgJy9kb2Mvd29ya3NoZWV0cy9tb2RlbC5zaGVldC5qcyc6IE1PREVMX1NIRUVULFxuICAgICcvZG9jL3dvcmtzaGVldHMvY2hlY2tzLnNoZWV0LmpzJzogQ0hFQ0tTX1NIRUVULFxuICAgICcvZG9jL2ZpeHR1cmVzL3Jvd3MuZnJhbWUuanNvbic6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgIHJvd3M6IFt7IHY6IDEgfSwgeyB2OiAyIH0sIHsgdjogMyB9XSxcbiAgICAgIHRpZXI6ICdzdGF0aWMnLFxuICAgIH0pLFxuICB9O1xufVxuXG4vLyBUaGUgbG9hZGVyJ3MgRG9jdW1lbnRSZWFkZXIgb3ZlciB0aGUgZmxhdCBmaWxlIG1hcCAodGhlIGxvYWRlci50ZXN0LnRzIHNoYXBlKS5cbmZ1bmN0aW9uIHJlYWRlcihmaWxlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IERvY3VtZW50UmVhZGVyIHtcbiAgcmV0dXJuIG1lbW9yeVJlYWRlcihmaWxlcyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1ha2VTZXNzaW9uKCk6IFByb21pc2U8UmVwb3J0U2Vzc2lvbj4ge1xuICBjb25zdCBsb2FkZWQgPSBhd2FpdCBsb2FkRG9jdW1lbnQocmVhZGVyKGRvY0ZpbGVzKCkpLCAnL2RvYycpO1xuICBleHBlY3QobG9hZGVkLmRpYWdub3N0aWNzLmZpbHRlcigoZCkgPT4gZC5zZXZlcml0eSA9PT0gJ2Vycm9yJykpLnRvRXF1YWwoW10pO1xuICBjb25zdCBzb3VyY2VzID0gT2JqZWN0LmZyb21FbnRyaWVzKGxvYWRlZC53b3Jrc2hlZXRzLm1hcCgodykgPT4gW3cubmFtZSwgdy5zb3VyY2VdKSk7XG4gIGNvbnN0IGVuZ2luZSA9IGF3YWl0IEFzeW5jRW5naW5lLmZyb21Tb3VyY2VzKHNvdXJjZXMsIHsgdHJhbnNwb3J0OiBpbk1lbW9yeVRyYW5zcG9ydCgpIH0pO1xuICBjb25zdCB7IGV4dGVybmFscywgcGFyYW1SZWZzIH0gPSBhc3NlbWJsZUV4dGVybmFscyhsb2FkZWQpO1xuICBhd2FpdCBlbmdpbmUucnVuKGV4dGVybmFscyk7XG4gIHJldHVybiB7XG4gICAgZW5naW5lLFxuICAgIGV4dGVybmFscyxcbiAgICBwYXJhbVJlZnMsXG4gICAgbm9kZXM6IFtdLFxuICAgIHRpdGxlOiAnV2hhdC1pZiBoYXJuZXNzJyxcbiAgICBkaWFnbm9zdGljczogW10sXG4gICAgc291cmNlcyxcbiAgICBsb2FkZWQsXG4gICAgcnVudGltZUZlZWRzOiBbXSxcbiAgICBhdXRob3JzTm9kZXM6IFtdLFxuICAgIGF1dGhvcnNGcm9tRG9jdW1lbnQ6IGZhbHNlLFxuICB9O1xufVxuXG5mdW5jdGlvbiBiYXNlS2V5cyhzZXNzaW9uOiBSZXBvcnRTZXNzaW9uKTogTWFwPHN0cmluZywgc3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIHJldHVybiBuZXcgTWFwKHNlc3Npb24uZW5naW5lLmNlbGxzKCkubWFwKChjKSA9PiBbYy5pZCwgc2Vzc2lvbi5lbmdpbmUucmVzdWx0KGMuaWQpPy5rZXldKSk7XG59XG5cbmRlc2NyaWJlKCdydW5TaGFkb3cg4oCUIGZvcm11bGEgdmFyaWFudHMgKEctV0lGLTIsIEctV0lGLTQpJywgKCkgPT4ge1xuICBpdCgnY2hhbmdlcyB0aGUgdmFyaWVkIGNlbGwgYW5kIGl0cyBkZXBlbmRlbnRzIGluIHRoZSBzaGFkb3cgd2hpbGUgdGhlIGJhc2Ugc3RheXMgYml0LWlkZW50aWNhbCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgbWFrZVNlc3Npb24oKTtcbiAgICBjb25zdCBiZWZvcmUgPSBiYXNlS2V5cyhzZXNzaW9uKTtcblxuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhcbiAgICAgIHNlc3Npb24sXG4gICAgICB7IHZhcmlhbnRzOiB7ICdtb2RlbC5iYXNlX3RvdGFsJzogJyh7IHJvd3MgfSkgPT4gcm93cy5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLnYsIDApICsgMTAwJyB9IH0sXG4gICAgICBpbk1lbW9yeVRyYW5zcG9ydCgpLFxuICAgICAgbnVsbCxcbiAgICApO1xuICAgIGV4cGVjdChvdXQub2spLnRvQmUodHJ1ZSk7XG4gICAgaWYgKCFvdXQub2spIHJldHVybjtcblxuICAgIGV4cGVjdChvdXQucGFzcy5lcnJvcnMuc2l6ZSkudG9CZSgwKTtcbiAgICBleHBlY3Qob3V0LnZhbHVlT2YoJ21vZGVsLmJhc2VfdG90YWwnKSkudG9CZSgxMDYpO1xuICAgIGV4cGVjdChvdXQudmFsdWVPZignbW9kZWwuc2NhbGVkJykpLnRvQmUoMjEyKTtcbiAgICBleHBlY3Qob3V0LnZhbHVlT2YoJ21vZGVsLnVucmVsYXRlZCcpKS50b0JlKDcpO1xuXG4gICAgY29uc3QgY2hhbmdlZCA9IG91dC5kZWx0YXMubWFwKChkKSA9PiBkLmlkKS5zb3J0KCk7XG4gICAgZXhwZWN0KGNoYW5nZWQpLnRvRXF1YWwoWydtb2RlbC5iYXNlX3RvdGFsJywgJ21vZGVsLnNjYWxlZCddKTtcbiAgICAvLyBHLVdJRi00OiBldmVyeSBjaGFuZ2VkIGNlbGwgaXMgaW5zaWRlIHRoZSBkZXBlbmRlbnRzIGNsb3N1cmUgb2YgdGhlIHZhcmllZCBjZWxsLlxuICAgIGZvciAoY29uc3QgaWQgb2YgY2hhbmdlZCkgZXhwZWN0KG91dC5jbG9zdXJlLmhhcyhpZCkpLnRvQmUodHJ1ZSk7XG5cbiAgICAvLyBUaGUgYmFzZSBlbmdpbmUncyBwdWJsaXNoZWQgcmVzdWx0cyBhcmUgdW50b3VjaGVkIGJ5IHRoZSBzaGFkb3cgcnVuLlxuICAgIGV4cGVjdChiYXNlS2V5cyhzZXNzaW9uKSkudG9FcXVhbChiZWZvcmUpO1xuICB9KTtcblxuICBpdCgnZGVlcC1jb3BpZXMgdGhlIGJhc2VsaW5lIGV4dGVybmFsczogYSByb3ctbXV0YXRpbmcgdmFyaWFudCBjYW5ub3QgY29ycnVwdCB0aGUgYmFzZSBzZXNzaW9uIChXSUYtUjEpJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuXG4gICAgY29uc3Qgb3V0ID0gYXdhaXQgcnVuU2hhZG93KFxuICAgICAgc2Vzc2lvbixcbiAgICAgIHsgdmFyaWFudHM6IHsgJ21vZGVsLmJhc2VfdG90YWwnOiAnKHsgcm93cyB9KSA9PiB7IHJvd3MucHVzaCh7IHY6IDEwMDAgfSk7IHJldHVybiByb3dzLmxlbmd0aDsgfScgfSB9LFxuICAgICAgaW5NZW1vcnlUcmFuc3BvcnQoKSxcbiAgICAgIG51bGwsXG4gICAgKTtcbiAgICBleHBlY3Qob3V0Lm9rKS50b0JlKHRydWUpO1xuXG4gICAgLy8gRm9yY2UgYSBmcmVzaCBiYXNlIHBhc3Mgb3ZlciB0aGUgKGhvcGVmdWxseSB1bm11dGF0ZWQpIGZpeHR1cmUgcm93cy5cbiAgICBhd2FpdCBzZXNzaW9uLmVuZ2luZS51cGRhdGUoeyAncGFyYW1zLmZhY3Rvcic6IHsgdmFsdWU6IDMsIHRpZXI6ICdzdGF0aWMnIH0gfSk7XG4gICAgZXhwZWN0KHNlc3Npb24uZW5naW5lLnZhbHVlKCdtb2RlbC5iYXNlX3RvdGFsJykpLnRvQmUoNik7XG4gICAgZXhwZWN0KHNlc3Npb24uZW5naW5lLnZhbHVlKCdtb2RlbC5zY2FsZWQnKSkudG9CZSgxOCk7XG4gIH0pO1xuXG4gIGl0KCdzdXJmYWNlcyBhIHNwbGljZSByZWZ1c2FsIGFzIGEgdHlwZWQgb3V0Y29tZSwgbmV2ZXIgYSB3cm9uZyBwYXRjaCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgbWFrZVNlc3Npb24oKTtcbiAgICBjb25zdCBvdXQgPSBhd2FpdCBydW5TaGFkb3coXG4gICAgICBzZXNzaW9uLFxuICAgICAgeyB2YXJpYW50czogeyAnbW9kZWwubm9wZSc6ICcoKSA9PiAwJyB9IH0sXG4gICAgICBpbk1lbW9yeVRyYW5zcG9ydCgpLFxuICAgICAgbnVsbCxcbiAgICApO1xuICAgIGV4cGVjdChvdXQub2spLnRvQmUoZmFsc2UpO1xuICAgIGlmIChvdXQub2spIHJldHVybjtcbiAgICBleHBlY3Qob3V0LnJlZnVzYWwuY29kZSkudG9CZSgndW5rbm93bi1jZWxsJyk7XG4gIH0pO1xuXG4gIGl0KCdzdXJmYWNlcyBhIHZhcmlhbnQgdGhhdCBubyBsb25nZXIgcGFyc2VzIGFzIGEgYnVpbGQtZXJyb3IgcmVmdXNhbCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgbWFrZVNlc3Npb24oKTtcbiAgICBjb25zdCBvdXQgPSBhd2FpdCBydW5TaGFkb3coXG4gICAgICBzZXNzaW9uLFxuICAgICAgeyB2YXJpYW50czogeyAnbW9kZWwudW5yZWxhdGVkJzogJygpID0+IHsnIH0gfSxcbiAgICAgIGluTWVtb3J5VHJhbnNwb3J0KCksXG4gICAgICBudWxsLFxuICAgICk7XG4gICAgZXhwZWN0KG91dC5vaykudG9CZShmYWxzZSk7XG4gICAgaWYgKG91dC5vaykgcmV0dXJuO1xuICAgIGV4cGVjdChvdXQucmVmdXNhbC5jb2RlKS50b0JlKCdidWlsZC1lcnJvcicpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgncnVuU2hhZG93IOKAlCB0aGUgcGlubmVkIGJhc2VsaW5lIChHLVdJRi0zLCBHLVdJRi00IHRpY2tpbmcgY2FzZSknLCAoKSA9PiB7XG4gIGl0KCdzZXR0bGVkU25hcHNob3Qgd2FpdHMgZm9yIGFuIHVuLWF3YWl0ZWQgdXBkYXRlIGFuZCByZXR1cm5zIGEgY29oZXJlbnQsIGNvcGllZCBwYWlyJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIC8vIEZpcmUtYW5kLWZvcmdldDogdGhlIHNuYXBzaG90IG11c3QgaW5jbHVkZSB0aGlzIHdyaXRlIGFuZCB0aGUgcGFzcyBpdCBwcm9kdWNlZC5cbiAgICB2b2lkIHNlc3Npb24uZW5naW5lLnVwZGF0ZSh7ICdwYXJhbXMuZmFjdG9yJzogeyB2YWx1ZTogNSwgdGllcjogJ3N0YXRpYycgfSB9KTtcbiAgICBjb25zdCBzbmFwID0gYXdhaXQgc2Vzc2lvbi5lbmdpbmUuc2V0dGxlZFNuYXBzaG90KCk7XG4gICAgZXhwZWN0KHNuYXAuZXh0ZXJuYWxzWydwYXJhbXMuZmFjdG9yJ10udmFsdWUpLnRvQmUoNSk7XG4gICAgZXhwZWN0KHNuYXAucGFzcy5yZXN1bHRzLmdldCgnbW9kZWwuc2NhbGVkJyk/LnZhbHVlKS50b0JlKDMwKTtcblxuICAgIC8vIEZlZWQtYnVmZmVyIGtleXMgd3JpdHRlbiBzdHJhaWdodCBpbnRvIHRoZSBlbmdpbmUgYXBwZWFyIGluIHRoZSBzbmFwc2hvdOKAplxuICAgIGF3YWl0IHNlc3Npb24uZW5naW5lLnVwZGF0ZSh7ICdmZWVkQnVmZmVycy54JzogeyB2YWx1ZTogW3sgdDogMSB9XSwgdGllcjogJ2xpdmUnIH0gfSk7XG4gICAgY29uc3Qgc25hcDIgPSBhd2FpdCBzZXNzaW9uLmVuZ2luZS5zZXR0bGVkU25hcHNob3QoKTtcbiAgICBleHBlY3Qoc25hcDIuZXh0ZXJuYWxzWydmZWVkQnVmZmVycy54J10udmFsdWUpLnRvRXF1YWwoW3sgdDogMSB9XSk7XG4gICAgLy8g4oCmYW5kIGFyZSBjb3BpZXM6IG11dGF0aW5nIHRoZSByZXR1cm5lZCB2YWx1ZSBjYW5ub3QgcmVhY2ggdGhlIGVuZ2luZS5cbiAgICAoc25hcDIuZXh0ZXJuYWxzWydmZWVkQnVmZmVycy54J10udmFsdWUgYXMgeyB0OiBudW1iZXIgfVtdKS5wdXNoKHsgdDogMiB9KTtcbiAgICBjb25zdCBzbmFwMyA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnNldHRsZWRTbmFwc2hvdCgpO1xuICAgIGV4cGVjdChzbmFwMy5leHRlcm5hbHNbJ2ZlZWRCdWZmZXJzLngnXS52YWx1ZSkudG9FcXVhbChbeyB0OiAxIH1dKTtcbiAgfSk7XG5cbiAgaXQoJ2Egbm8tdmFyaWFudCBzaGFkb3cgb3ZlciBhIG1vdmluZyBiYXNlIHJlcG9ydHMgemVybyBkZWx0YXMgYWdhaW5zdCBpdHMgcGlubmVkIGJhc2VsaW5lJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIGNvbnN0IGJhc2VWZXJkaWN0cyA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnJ1blRlc3RzKCk7XG5cbiAgICAvLyBBIGJhc2Ugd3JpdGUgcmFjaW5nIHRoZSBydW46IHRoZSBzbmFwc2hvdCBzZXR0bGVzIGl0IGludG8gdGhlIGJhc2VsaW5lLCBzbyB0aGVcbiAgICAvLyBzaGFkb3cgY29tcHV0ZXMgb3ZlciB0aGUgc2FtZSBlcG9jaCBhbmQgdGhlIGRpZmYgaXMgZW1wdHkgKG5vIHNwdXJpb3VzIGRlbHRhcykuXG4gICAgdm9pZCBzZXNzaW9uLmVuZ2luZS51cGRhdGUoeyAncGFyYW1zLmZhY3Rvcic6IHsgdmFsdWU6IDksIHRpZXI6ICdzdGF0aWMnIH0gfSk7XG4gICAgY29uc3Qgb3V0ID0gYXdhaXQgcnVuU2hhZG93KHNlc3Npb24sIHt9LCBpbk1lbW9yeVRyYW5zcG9ydCgpLCBiYXNlVmVyZGljdHMpO1xuICAgIGV4cGVjdChvdXQub2spLnRvQmUodHJ1ZSk7XG4gICAgaWYgKCFvdXQub2spIHJldHVybjtcbiAgICBleHBlY3Qob3V0LmRlbHRhcykudG9FcXVhbChbXSk7XG4gICAgZXhwZWN0KG91dC52ZXJkaWN0RmxpcHMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChvdXQuYmFzZWxpbmUucmVzdWx0cy5nZXQoJ21vZGVsLnNjYWxlZCcpPy52YWx1ZSkudG9CZSg1NCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdydW5TaGFkb3cg4oCUIHNjcmF0Y2ggKEctV0lGLTUsIEctV0lGLTZhLCBHLVdJRi0xMCknLCAoKSA9PiB7XG4gIGNvbnN0IFNDUkFUQ0ggPSBgaW1wb3J0IHsgY2VsbCwgdGVzdENlbGwsIGV4cGVjdEVxdWFsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcblxuZXhwb3J0IGNvbnN0IHByb2JlID0gY2VsbCh7XG4gIGRvYzogXCJ0ZW4gdGltZXMgdGhlIGJhc2UgdG90YWxcIixcbiAgaW5wdXRzOiB7IHQ6IFwibW9kZWwuYmFzZV90b3RhbFwiIH0sXG4gIGZvcm11bGE6ICh7IHQgfSkgPT4gdCAqIDEwLFxufSk7XG5cbmV4cG9ydCBjb25zdCBwcm9iZV9jaGVjayA9IHRlc3RDZWxsKHtcbiAga2luZDogXCJzcGVjaWZpY2F0aW9uXCIsXG4gIHN1YmplY3Q6IFwic2NyYXRjaC5wcm9iZVwiLFxuICBleHBlY3Q6ICh7IHJlc3VsdCB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIDYwKSxcbn0pO1xuYDtcblxuICBpdCgnYSBzY3JhdGNoLW9ubHkgcnVuIGlzIGFkZGl0aXZlOiBkdXJhYmxlIHZhbHVlcyBhbmQgdmVyZGljdHMgdW50b3VjaGVkLCBzY3JhdGNoIGNlbGxzIGZpcnN0LWNsYXNzJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIGNvbnN0IGJhc2VWZXJkaWN0cyA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgY29uc3QgYmVmb3JlID0gYmFzZUtleXMoc2Vzc2lvbik7XG5cbiAgICBjb25zdCBvdXQgPSBhd2FpdCBydW5TaGFkb3coc2Vzc2lvbiwgeyBzY3JhdGNoOiBTQ1JBVENIIH0sIGluTWVtb3J5VHJhbnNwb3J0KCksIGJhc2VWZXJkaWN0cyk7XG4gICAgZXhwZWN0KG91dC5vaykudG9CZSh0cnVlKTtcbiAgICBpZiAoIW91dC5vaykgcmV0dXJuO1xuXG4gICAgZXhwZWN0KG91dC5kZWx0YXMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChiYXNlS2V5cyhzZXNzaW9uKSkudG9FcXVhbChiZWZvcmUpO1xuICAgIGV4cGVjdChvdXQudmFsdWVPZignc2NyYXRjaC5wcm9iZScpKS50b0JlKDYwKTtcbiAgICBleHBlY3Qob3V0LnZlcmRpY3RzLmdldCgnc2NyYXRjaC5wcm9iZScpPy52ZXJkaWN0KS5ub3QudG9CZSgndW50ZXN0ZWQnKTtcbiAgICAvLyBUaGUgb25seSB2ZXJkaWN0IGRpZmZlcmVuY2UgaXMgdGhlIHNjcmF0Y2ggc3ViamVjdCBhcHBlYXJpbmcuXG4gICAgZXhwZWN0KG91dC52ZXJkaWN0RmxpcHMubWFwKChmKSA9PiBmLnN1YmplY3QpKS50b0VxdWFsKFsnc2NyYXRjaC5wcm9iZSddKTtcbiAgICAvLyBTY3JhdGNoIGNlbGxzIHJlbmRlciBhcyBjYXJkczogdGhleSBhcmUgaW4gdGhlIHNoYWRvdydzIGNlbGwgbGlzdC5cbiAgICBleHBlY3Qob3V0LmNlbGxzLnNvbWUoKGMpID0+IGMuaWQgPT09ICdzY3JhdGNoLnByb2JlJykpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCdyZWZ1c2VzIGEgc2NyYXRjaCB0ZXN0IHRoYXQgdGFyZ2V0cyBhIGR1cmFibGUgc3ViamVjdCAoRy1XSUYtNmEpJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIGNvbnN0IGhvc3RpbGUgPSBgaW1wb3J0IHsgY2VsbCwgdGVzdENlbGwsIGV4cGVjdEVxdWFsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcblxuZXhwb3J0IGNvbnN0IHNuZWFreSA9IHRlc3RDZWxsKHtcbiAga2luZDogXCJzcGVjaWZpY2F0aW9uXCIsXG4gIHN1YmplY3Q6IFwibW9kZWwuc2NhbGVkXCIsXG4gIGV4cGVjdDogKHsgcmVzdWx0IH0pID0+IGV4cGVjdEVxdWFsKHJlc3VsdCwgLTEpLFxufSk7XG5gO1xuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhzZXNzaW9uLCB7IHNjcmF0Y2g6IGhvc3RpbGUgfSwgaW5NZW1vcnlUcmFuc3BvcnQoKSwgbnVsbCk7XG4gICAgZXhwZWN0KG91dC5vaykudG9CZShmYWxzZSk7XG4gICAgaWYgKG91dC5vaykgcmV0dXJuO1xuICAgIGV4cGVjdChvdXQucmVmdXNhbC5jb2RlKS50b0JlKCdzY3JhdGNoLXN1YmplY3QnKTtcbiAgICBleHBlY3Qob3V0LnJlZnVzYWwubWVzc2FnZSkudG9Db250YWluKCdtb2RlbC5zY2FsZWQnKTtcbiAgfSk7XG5cbiAgaXQoJ3JlLXJ1bnMgY3Jvc3MtcmVmZXJlbmNlIHZhbGlkYXRpb246IGEgdHlwb+KAmWQgZXh0ZXJuYWwgaXMgYSBkaWFnbm9zdGljLCBub3QgYSBzaWxlbnQgbnVsbCAoRy1XSUYtMTApJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIGNvbnN0IHR5cG8gPSBgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5cbmV4cG9ydCBjb25zdCBvb3BzID0gY2VsbCh7XG4gIGRvYzogXCJyZWFkcyBhIGZpeHR1cmUgdGhhdCBkb2VzIG5vdCBleGlzdFwiLFxuICBpbnB1dHM6IHsgcjogXCJmaXh0dXJlcy5yb3d6XCIgfSxcbiAgZm9ybXVsYTogKHsgciB9KSA9PiByLFxufSk7XG5gO1xuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhzZXNzaW9uLCB7IHNjcmF0Y2g6IHR5cG8gfSwgaW5NZW1vcnlUcmFuc3BvcnQoKSwgbnVsbCk7XG4gICAgZXhwZWN0KG91dC5vaykudG9CZSh0cnVlKTtcbiAgICBpZiAoIW91dC5vaykgcmV0dXJuO1xuICAgIGV4cGVjdChvdXQuZGlhZ25vc3RpY3Muc29tZSgoZCkgPT4gZC5tZXNzYWdlLmluY2x1ZGVzKCdyb3d6JykpKS50b0JlKHRydWUpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgncnVuU2hhZG93IOKAlCB2ZXJkaWN0IGZsaXBzIChHLVdJRi02KScsICgpID0+IHtcbiAgaXQoJ2EgdGVzdC1icmVha2luZyB2YXJpYW50IGZsaXBzIHRoZSBzdWJqZWN0IGluIHRoZSBzaGFkb3cgc3VpdGU7IGJhc2UgdmVyZGljdHMgdW50b3VjaGVkJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBtYWtlU2Vzc2lvbigpO1xuICAgIGNvbnN0IGJhc2VWZXJkaWN0cyA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgY29uc3QgYmFzZVNjYWxlZCA9IGJhc2VWZXJkaWN0cy5nZXQoJ21vZGVsLnNjYWxlZCcpPy52ZXJkaWN0O1xuICAgIGV4cGVjdChiYXNlU2NhbGVkKS50b0JlRGVmaW5lZCgpO1xuICAgIGV4cGVjdChiYXNlU2NhbGVkKS5ub3QudG9CZSgnZmFpbGluZycpO1xuXG4gICAgY29uc3Qgb3V0ID0gYXdhaXQgcnVuU2hhZG93KFxuICAgICAgc2Vzc2lvbixcbiAgICAgIHsgdmFyaWFudHM6IHsgJ21vZGVsLnNjYWxlZCc6ICcoeyB0b3RhbCwgZmFjdG9yIH0pID0+IHRvdGFsICogZmFjdG9yICsgMScgfSB9LFxuICAgICAgaW5NZW1vcnlUcmFuc3BvcnQoKSxcbiAgICAgIGJhc2VWZXJkaWN0cyxcbiAgICApO1xuICAgIGV4cGVjdChvdXQub2spLnRvQmUodHJ1ZSk7XG4gICAgaWYgKCFvdXQub2spIHJldHVybjtcblxuICAgIGV4cGVjdChvdXQudmVyZGljdHMuZ2V0KCdtb2RlbC5zY2FsZWQnKT8udmVyZGljdCkudG9CZSgnZmFpbGluZycpO1xuICAgIGV4cGVjdChvdXQudmVyZGljdEZsaXBzKS50b0VxdWFsKFt7IHN1YmplY3Q6ICdtb2RlbC5zY2FsZWQnLCBiZWZvcmU6IGJhc2VTY2FsZWQsIGFmdGVyOiAnZmFpbGluZycgfV0pO1xuXG4gICAgLy8gVGhlIGJhc2Ugc3VpdGUgc3RpbGwgcmVwb3J0cyB0aGUgb3JpZ2luYWwgdmVyZGljdC5cbiAgICBjb25zdCBhZnRlciA9IGF3YWl0IHNlc3Npb24uZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgZXhwZWN0KGFmdGVyLmdldCgnbW9kZWwuc2NhbGVkJyk/LnZlcmRpY3QpLnRvQmUoYmFzZVNjYWxlZCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdydW5TaGFkb3cg4oCUIHNwYW4gc3BsaWNlIHRocm91Z2ggdGhlIHJlYWwgYnVpbGQgKFIzLTQyNyknLCAoKSA9PiB7XG4gIGNvbnN0IFRXSU5TX1NIRUVUID0gYGltcG9ydCB7IGNlbGwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG5leHBvcnQgY29uc3Qgb25lID0gY2VsbCh7XG4gIGRvYzogXCJ0aGUgZmlyc3QgdHdpblwiLFxuICBpbnB1dHM6IHt9LFxuICBmb3JtdWxhOiAoKSA9PiAxLFxufSk7XG5cbmV4cG9ydCBjb25zdCB0d28gPSBjZWxsKHtcbiAgZG9jOiBcInRoZSBzZWNvbmQgdHdpbiDigJQgaWRlbnRpY2FsIGZvcm11bGEgdGV4dFwiLFxuICBpbnB1dHM6IHt9LFxuICBmb3JtdWxhOiAoKSA9PiAxLFxufSk7XG5cbmV4cG9ydCBjb25zdCBzaG9ydF9zdWIgPSBjZWxsKHtcbiAgZG9jOiBcImEgZm9ybXVsYSB0aGF0IGlzIGEgc3Vic3RyaW5nIG9mIGxvbmdlcl9zdWInc1wiLFxuICBpbnB1dHM6IHt9LFxuICBmb3JtdWxhOiAoKSA9PiA1ICsgMSxcbn0pO1xuXG5leHBvcnQgY29uc3QgbG9uZ2VyX3N1YiA9IGNlbGwoe1xuICBkb2M6IFwiY29udGFpbnMgc2hvcnRfc3ViJ3MgdGV4dCBhcyBhIHN1YnN0cmluZ1wiLFxuICBpbnB1dHM6IHt9LFxuICBmb3JtdWxhOiAoKSA9PiA1ICsgMTIsXG59KTtcbmA7XG5cbiAgYXN5bmMgZnVuY3Rpb24gdHdpbnNTZXNzaW9uKCk6IFByb21pc2U8UmVwb3J0U2Vzc2lvbj4ge1xuICAgIGNvbnN0IGZpbGVzID0ge1xuICAgICAgJy9kb2MvcmVja29uZXIuanNvbic6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgZm9ybWF0OiAxLFxuICAgICAgICBjb21wYXQ6IHsgc3RkbGliOiAnPj0wLjEuMCcsIGNhdGFsb2c6ICc+PTAuMS4wJyB9LFxuICAgICAgICB3b3Jrc2hlZXRzOiBbJ3R3aW5zLnNoZWV0LmpzJ10sXG4gICAgICAgIHBhcmFtczoge30sXG4gICAgICAgIHRpdGxlOiAnVHdpbnMnLFxuICAgICAgfSksXG4gICAgICAnL2RvYy93b3Jrc2hlZXRzL3R3aW5zLnNoZWV0LmpzJzogVFdJTlNfU0hFRVQsXG4gICAgfTtcbiAgICBjb25zdCBsb2FkZWQgPSBhd2FpdCBsb2FkRG9jdW1lbnQocmVhZGVyKGZpbGVzKSwgJy9kb2MnKTtcbiAgICBjb25zdCBzb3VyY2VzID0gT2JqZWN0LmZyb21FbnRyaWVzKGxvYWRlZC53b3Jrc2hlZXRzLm1hcCgodykgPT4gW3cubmFtZSwgdy5zb3VyY2VdKSk7XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoc291cmNlcywgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSk7XG4gICAgY29uc3QgeyBleHRlcm5hbHMsIHBhcmFtUmVmcyB9ID0gYXNzZW1ibGVFeHRlcm5hbHMobG9hZGVkKTtcbiAgICBhd2FpdCBlbmdpbmUucnVuKGV4dGVybmFscyk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGVuZ2luZSwgZXh0ZXJuYWxzLCBwYXJhbVJlZnMsIG5vZGVzOiBbXSwgdGl0bGU6ICdUd2lucycsIGRpYWdub3N0aWNzOiBbXSxcbiAgICAgIHNvdXJjZXMsIGxvYWRlZCwgcnVudGltZUZlZWRzOiBbXSwgYXV0aG9yc05vZGVzOiBbXSwgYXV0aG9yc0Zyb21Eb2N1bWVudDogZmFsc2UsXG4gICAgfTtcbiAgfVxuXG4gIGl0KCdkZXNjcmlwdG9ycyBjYXJyeSBzdHJ1Y3R1cmVkLWNsb25lLXNhZmUgc3BhbnMgZnJvbSB0aGUgYnVpbGQnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHR3aW5zU2Vzc2lvbigpO1xuICAgIGNvbnN0IG9uZSA9IHNlc3Npb24uZW5naW5lLmNlbGxzKCkuZmluZCgoYykgPT4gYy5pZCA9PT0gJ3R3aW5zLm9uZScpO1xuICAgIGV4cGVjdChvbmU/LnNwYW4pLnRvQmVEZWZpbmVkKCk7XG4gICAgZXhwZWN0KG9uZT8uc3Bhbj8ubGluZSkudG9CZSgzKTtcbiAgICBjb25zdCBjbG9uZWQgPSBzdHJ1Y3R1cmVkQ2xvbmUob25lKTtcbiAgICBleHBlY3QoY2xvbmVkPy5zcGFuKS50b0VxdWFsKG9uZT8uc3Bhbik7XG4gICAgZXhwZWN0KHNlc3Npb24uZW5naW5lLnRlc3RzKCkuZXZlcnkoKHQpID0+IHQuc3ViamVjdCAhPT0gdW5kZWZpbmVkKSkudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoJ2lkZW50aWNhbCBmb3JtdWxhIHRleHQgaW4gdHdvIGNlbGxzOiBlYWNoIHNwbGljZXMgaXRzIE9XTiBibG9jayDigJQgbm8gZm9ybXVsYS1hbWJpZ3VvdXMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHR3aW5zU2Vzc2lvbigpO1xuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhzZXNzaW9uLCB7IHZhcmlhbnRzOiB7ICd0d2lucy50d28nOiAnKCkgPT4gMjInIH0gfSwgaW5NZW1vcnlUcmFuc3BvcnQoKSwgbnVsbCk7XG4gICAgZXhwZWN0KG91dC5vaykudG9CZSh0cnVlKTtcbiAgICBpZiAoIW91dC5vaykgcmV0dXJuO1xuICAgIGV4cGVjdChvdXQudmFsdWVPZigndHdpbnMudHdvJykpLnRvQmUoMjIpO1xuICAgIGV4cGVjdChvdXQudmFsdWVPZigndHdpbnMub25lJykpLnRvQmUoMSk7IC8vIHRoZSBvdGhlciB0d2luIHVudG91Y2hlZFxuICAgIGV4cGVjdChvdXQuZGVsdGFzLm1hcCgoZCkgPT4gZC5pZCkpLnRvRXF1YWwoWyd0d2lucy50d28nXSk7XG4gIH0pO1xuXG4gIGl0KCdhIGZvcm11bGEgdGhhdCBpcyBhIHN1YnN0cmluZyBvZiBhbm90aGVyIGNlbGwgc3BsaWNlcyB3aXRob3V0IHJlZnVzYWwnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHR3aW5zU2Vzc2lvbigpO1xuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhzZXNzaW9uLCB7IHZhcmlhbnRzOiB7ICd0d2lucy5zaG9ydF9zdWInOiAnKCkgPT4gNSArIDEwMCcgfSB9LCBpbk1lbW9yeVRyYW5zcG9ydCgpLCBudWxsKTtcbiAgICBleHBlY3Qob3V0Lm9rKS50b0JlKHRydWUpO1xuICAgIGlmICghb3V0Lm9rKSByZXR1cm47XG4gICAgZXhwZWN0KG91dC52YWx1ZU9mKCd0d2lucy5zaG9ydF9zdWInKSkudG9CZSgxMDUpO1xuICAgIGV4cGVjdChvdXQudmFsdWVPZigndHdpbnMubG9uZ2VyX3N1YicpKS50b0JlKDE3KTsgLy8gdW50b3VjaGVkXG4gIH0pO1xuXG4gIGl0KCdib3RoIHZhcmlhbnRzIGF0IG9uY2UsIHNhbWUgd29ya3NoZWV0IOKAlCBkZXNjZW5kaW5nLWJsb2NrIGFwcGxpY2F0aW9uIGtlZXBzIGV2ZXJ5IHNwYW4gdmFsaWQnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHR3aW5zU2Vzc2lvbigpO1xuICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1blNoYWRvdyhcbiAgICAgIHNlc3Npb24sXG4gICAgICB7IHZhcmlhbnRzOiB7ICd0d2lucy5vbmUnOiAnKCkgPT4gMTEnLCAndHdpbnMudHdvJzogJygpID0+IDIyJyB9IH0sXG4gICAgICBpbk1lbW9yeVRyYW5zcG9ydCgpLFxuICAgICAgbnVsbCxcbiAgICApO1xuICAgIGV4cGVjdChvdXQub2spLnRvQmUodHJ1ZSk7XG4gICAgaWYgKCFvdXQub2spIHJldHVybjtcbiAgICBleHBlY3Qob3V0LnZhbHVlT2YoJ3R3aW5zLm9uZScpKS50b0JlKDExKTtcbiAgICBleHBlY3Qob3V0LnZhbHVlT2YoJ3R3aW5zLnR3bycpKS50b0JlKDIyKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQU1BLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUVBLElBQUFFLFlBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGdCQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxjQUFBLEdBQUFKLE9BQUE7QUFFQSxJQUFBSyxhQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxPQUFBLEdBQUFOLE9BQUE7QUFkQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBV0EsTUFBTU8sV0FBVyxHQUFHO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFFRCxNQUFNQyxZQUFZLEdBQUc7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUVELFNBQVNDLFFBQVFBLENBQUEsRUFBMkI7RUFDMUMsT0FBTztJQUNMLG9CQUFvQixFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUNuQ0MsTUFBTSxFQUFFLENBQUM7TUFDVEMsTUFBTSxFQUFFO1FBQUVDLE1BQU0sRUFBRSxTQUFTO1FBQUVDLE9BQU8sRUFBRTtNQUFVLENBQUM7TUFDakRDLFVBQVUsRUFBRSxDQUFDLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDO01BQ2pEQyxNQUFNLEVBQUU7UUFBRUMsTUFBTSxFQUFFO01BQUUsQ0FBQztNQUNyQkMsS0FBSyxFQUFFO0lBQ1QsQ0FBQyxDQUFDO0lBQ0YsZ0NBQWdDLEVBQUVaLFdBQVc7SUFDN0MsaUNBQWlDLEVBQUVDLFlBQVk7SUFDL0MsK0JBQStCLEVBQUVFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzlDUyxJQUFJLEVBQUUsQ0FBQztRQUFFQyxDQUFDLEVBQUU7TUFBRSxDQUFDLEVBQUU7UUFBRUEsQ0FBQyxFQUFFO01BQUUsQ0FBQyxFQUFFO1FBQUVBLENBQUMsRUFBRTtNQUFFLENBQUMsQ0FBQztNQUNwQ0MsSUFBSSxFQUFFO0lBQ1IsQ0FBQztFQUNILENBQUM7QUFDSDs7QUFFQTtBQUNBLFNBQVNDLE1BQU1BLENBQUNDLEtBQTZCLEVBQWtCO0VBQzdELE9BQU8sSUFBQUMsMEJBQVksRUFBQ0QsS0FBSyxDQUFDO0FBQzVCO0FBRUEsZUFBZUUsV0FBV0EsQ0FBQSxFQUEyQjtFQUNuRCxNQUFNQyxNQUFNLEdBQUcsTUFBTSxJQUFBQyxvQkFBWSxFQUFDTCxNQUFNLENBQUNkLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUM7RUFDN0QsSUFBQW9CLGNBQU0sRUFBQ0YsTUFBTSxDQUFDRyxXQUFXLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzVFLE1BQU1DLE9BQU8sR0FBR0MsTUFBTSxDQUFDQyxXQUFXLENBQUNWLE1BQU0sQ0FBQ1gsVUFBVSxDQUFDc0IsR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxJQUFJLEVBQUVELENBQUMsQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNwRixNQUFNQyxNQUFNLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsV0FBVyxDQUFDVCxPQUFPLEVBQUU7SUFBRVUsU0FBUyxFQUFFLElBQUFDLGtDQUFpQixFQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3pGLE1BQU07SUFBRUMsU0FBUztJQUFFQztFQUFVLENBQUMsR0FBRyxJQUFBQyxnQ0FBaUIsRUFBQ3RCLE1BQU0sQ0FBQztFQUMxRCxNQUFNZSxNQUFNLENBQUNRLEdBQUcsQ0FBQ0gsU0FBUyxDQUFDO0VBQzNCLE9BQU87SUFDTEwsTUFBTTtJQUNOSyxTQUFTO0lBQ1RDLFNBQVM7SUFDVEcsS0FBSyxFQUFFLEVBQUU7SUFDVGhDLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJXLFdBQVcsRUFBRSxFQUFFO0lBQ2ZLLE9BQU87SUFDUFIsTUFBTTtJQUNOeUIsWUFBWSxFQUFFLEVBQUU7SUFDaEJDLFlBQVksRUFBRSxFQUFFO0lBQ2hCQyxtQkFBbUIsRUFBRTtFQUN2QixDQUFDO0FBQ0g7QUFFQSxTQUFTQyxRQUFRQSxDQUFDQyxPQUFzQixFQUFtQztFQUN6RSxPQUFPLElBQUlDLEdBQUcsQ0FBQ0QsT0FBTyxDQUFDZCxNQUFNLENBQUNnQixLQUFLLENBQUMsQ0FBQyxDQUFDcEIsR0FBRyxDQUFFcUIsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ0MsRUFBRSxFQUFFSixPQUFPLENBQUNkLE1BQU0sQ0FBQ21CLE1BQU0sQ0FBQ0YsQ0FBQyxDQUFDQyxFQUFFLENBQUMsRUFBRUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUM3RjtBQUVBLElBQUFDLGdCQUFRLEVBQUMsaURBQWlELEVBQUUsTUFBTTtFQUNoRSxJQUFBQyxVQUFFLEVBQUMsNkZBQTZGLEVBQUUsWUFBWTtJQUM1RyxNQUFNUixPQUFPLEdBQUcsTUFBTTlCLFdBQVcsQ0FBQyxDQUFDO0lBQ25DLE1BQU11QyxNQUFNLEdBQUdWLFFBQVEsQ0FBQ0MsT0FBTyxDQUFDO0lBRWhDLE1BQU1VLEdBQUcsR0FBRyxNQUFNLElBQUFDLGlCQUFTLEVBQ3pCWCxPQUFPLEVBQ1A7TUFBRVksUUFBUSxFQUFFO1FBQUUsa0JBQWtCLEVBQUU7TUFBd0Q7SUFBRSxDQUFDLEVBQzdGLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQ25CLElBQ0YsQ0FBQztJQUNELElBQUFqQixjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3pCLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFFYixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDSyxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLENBQUNILElBQUksQ0FBQyxDQUFDLENBQUM7SUFDcEMsSUFBQXpDLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ1EsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQ0osSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNqRCxJQUFBekMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDUSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ0osSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUM3QyxJQUFBekMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDUSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRTlDLE1BQU1LLE9BQU8sR0FBR1QsR0FBRyxDQUFDVSxNQUFNLENBQUN0QyxHQUFHLENBQUVOLENBQUMsSUFBS0EsQ0FBQyxDQUFDNEIsRUFBRSxDQUFDLENBQUNpQixJQUFJLENBQUMsQ0FBQztJQUNsRCxJQUFBaEQsY0FBTSxFQUFDOEMsT0FBTyxDQUFDLENBQUN6QyxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUM3RDtJQUNBLEtBQUssTUFBTTBCLEVBQUUsSUFBSWUsT0FBTyxFQUFFLElBQUE5QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNZLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDbkIsRUFBRSxDQUFDLENBQUMsQ0FBQ1UsSUFBSSxDQUFDLElBQUksQ0FBQzs7SUFFaEU7SUFDQSxJQUFBekMsY0FBTSxFQUFDMEIsUUFBUSxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDdEIsT0FBTyxDQUFDK0IsTUFBTSxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFELFVBQUUsRUFBQyxxR0FBcUcsRUFBRSxZQUFZO0lBQ3BILE1BQU1SLE9BQU8sR0FBRyxNQUFNOUIsV0FBVyxDQUFDLENBQUM7SUFFbkMsTUFBTXdDLEdBQUcsR0FBRyxNQUFNLElBQUFDLGlCQUFTLEVBQ3pCWCxPQUFPLEVBQ1A7TUFBRVksUUFBUSxFQUFFO1FBQUUsa0JBQWtCLEVBQUU7TUFBZ0U7SUFBRSxDQUFDLEVBQ3JHLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQ25CLElBQ0YsQ0FBQztJQUNELElBQUFqQixjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDOztJQUV6QjtJQUNBLE1BQU1kLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDc0MsTUFBTSxDQUFDO01BQUUsZUFBZSxFQUFFO1FBQUVDLEtBQUssRUFBRSxDQUFDO1FBQUUzRCxJQUFJLEVBQUU7TUFBUztJQUFFLENBQUMsQ0FBQztJQUM5RSxJQUFBTyxjQUFNLEVBQUMyQixPQUFPLENBQUNkLE1BQU0sQ0FBQ3VDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNYLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDeEQsSUFBQXpDLGNBQU0sRUFBQzJCLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDdUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNYLElBQUksQ0FBQyxFQUFFLENBQUM7RUFDdkQsQ0FBQyxDQUFDO0VBRUYsSUFBQU4sVUFBRSxFQUFDLG1FQUFtRSxFQUFFLFlBQVk7SUFDbEYsTUFBTVIsT0FBTyxHQUFHLE1BQU05QixXQUFXLENBQUMsQ0FBQztJQUNuQyxNQUFNd0MsR0FBRyxHQUFHLE1BQU0sSUFBQUMsaUJBQVMsRUFDekJYLE9BQU8sRUFDUDtNQUFFWSxRQUFRLEVBQUU7UUFBRSxZQUFZLEVBQUU7TUFBVTtJQUFFLENBQUMsRUFDekMsSUFBQXRCLGtDQUFpQixFQUFDLENBQUMsRUFDbkIsSUFDRixDQUFDO0lBQ0QsSUFBQWpCLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ0csRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDMUIsSUFBSUosR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFDWixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDZ0IsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQztFQUMvQyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsbUVBQW1FLEVBQUUsWUFBWTtJQUNsRixNQUFNUixPQUFPLEdBQUcsTUFBTTlCLFdBQVcsQ0FBQyxDQUFDO0lBQ25DLE1BQU13QyxHQUFHLEdBQUcsTUFBTSxJQUFBQyxpQkFBUyxFQUN6QlgsT0FBTyxFQUNQO01BQUVZLFFBQVEsRUFBRTtRQUFFLGlCQUFpQixFQUFFO01BQVU7SUFBRSxDQUFDLEVBQzlDLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQ25CLElBQ0YsQ0FBQztJQUNELElBQUFqQixjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQzFCLElBQUlKLEdBQUcsQ0FBQ0csRUFBRSxFQUFFO0lBQ1osSUFBQXhDLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ2dCLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUNiLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQVAsZ0JBQVEsRUFBQyxpRUFBaUUsRUFBRSxNQUFNO0VBQ2hGLElBQUFDLFVBQUUsRUFBQyxvRkFBb0YsRUFBRSxZQUFZO0lBQ25HLE1BQU1SLE9BQU8sR0FBRyxNQUFNOUIsV0FBVyxDQUFDLENBQUM7SUFDbkM7SUFDQSxLQUFLOEIsT0FBTyxDQUFDZCxNQUFNLENBQUNzQyxNQUFNLENBQUM7TUFBRSxlQUFlLEVBQUU7UUFBRUMsS0FBSyxFQUFFLENBQUM7UUFBRTNELElBQUksRUFBRTtNQUFTO0lBQUUsQ0FBQyxDQUFDO0lBQzdFLE1BQU04RCxJQUFJLEdBQUcsTUFBTTVCLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDMkMsZUFBZSxDQUFDLENBQUM7SUFDbkQsSUFBQXhELGNBQU0sRUFBQ3VELElBQUksQ0FBQ3JDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQ2tDLEtBQUssQ0FBQyxDQUFDWCxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3JELElBQUF6QyxjQUFNLEVBQUN1RCxJQUFJLENBQUNiLElBQUksQ0FBQ2UsT0FBTyxDQUFDQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUVOLEtBQUssQ0FBQyxDQUFDWCxJQUFJLENBQUMsRUFBRSxDQUFDOztJQUU3RDtJQUNBLE1BQU1kLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDc0MsTUFBTSxDQUFDO01BQUUsZUFBZSxFQUFFO1FBQUVDLEtBQUssRUFBRSxDQUFDO1VBQUVPLENBQUMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUFFbEUsSUFBSSxFQUFFO01BQU87SUFBRSxDQUFDLENBQUM7SUFDckYsTUFBTW1FLEtBQUssR0FBRyxNQUFNakMsT0FBTyxDQUFDZCxNQUFNLENBQUMyQyxlQUFlLENBQUMsQ0FBQztJQUNwRCxJQUFBeEQsY0FBTSxFQUFDNEQsS0FBSyxDQUFDMUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDa0MsS0FBSyxDQUFDLENBQUMvQyxPQUFPLENBQUMsQ0FBQztNQUFFc0QsQ0FBQyxFQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDbEU7SUFDQ0MsS0FBSyxDQUFDMUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDa0MsS0FBSyxDQUFxQlMsSUFBSSxDQUFDO01BQUVGLENBQUMsRUFBRTtJQUFFLENBQUMsQ0FBQztJQUMxRSxNQUFNRyxLQUFLLEdBQUcsTUFBTW5DLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDMkMsZUFBZSxDQUFDLENBQUM7SUFDcEQsSUFBQXhELGNBQU0sRUFBQzhELEtBQUssQ0FBQzVDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQ2tDLEtBQUssQ0FBQyxDQUFDL0MsT0FBTyxDQUFDLENBQUM7TUFBRXNELENBQUMsRUFBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3BFLENBQUMsQ0FBQztFQUVGLElBQUF4QixVQUFFLEVBQUMsd0ZBQXdGLEVBQUUsWUFBWTtJQUN2RyxNQUFNUixPQUFPLEdBQUcsTUFBTTlCLFdBQVcsQ0FBQyxDQUFDO0lBQ25DLE1BQU1rRSxZQUFZLEdBQUcsTUFBTXBDLE9BQU8sQ0FBQ2QsTUFBTSxDQUFDbUQsUUFBUSxDQUFDLENBQUM7O0lBRXBEO0lBQ0E7SUFDQSxLQUFLckMsT0FBTyxDQUFDZCxNQUFNLENBQUNzQyxNQUFNLENBQUM7TUFBRSxlQUFlLEVBQUU7UUFBRUMsS0FBSyxFQUFFLENBQUM7UUFBRTNELElBQUksRUFBRTtNQUFTO0lBQUUsQ0FBQyxDQUFDO0lBQzdFLE1BQU00QyxHQUFHLEdBQUcsTUFBTSxJQUFBQyxpQkFBUyxFQUFDWCxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBQVYsa0NBQWlCLEVBQUMsQ0FBQyxFQUFFOEMsWUFBWSxDQUFDO0lBQzNFLElBQUEvRCxjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3pCLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFDYixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDVSxNQUFNLENBQUMsQ0FBQzFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDOUIsSUFBQUwsY0FBTSxFQUFDcUMsR0FBRyxDQUFDNEIsWUFBWSxDQUFDLENBQUM1RCxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ3BDLElBQUFMLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQzZCLFFBQVEsQ0FBQ1QsT0FBTyxDQUFDQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUVOLEtBQUssQ0FBQyxDQUFDWCxJQUFJLENBQUMsRUFBRSxDQUFDO0VBQ2xFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFQLGdCQUFRLEVBQUMsbURBQW1ELEVBQUUsTUFBTTtFQUNsRSxNQUFNaUMsT0FBTyxHQUFHO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7RUFFQyxJQUFBaEMsVUFBRSxFQUFDLGtHQUFrRyxFQUFFLFlBQVk7SUFDakgsTUFBTVIsT0FBTyxHQUFHLE1BQU05QixXQUFXLENBQUMsQ0FBQztJQUNuQyxNQUFNa0UsWUFBWSxHQUFHLE1BQU1wQyxPQUFPLENBQUNkLE1BQU0sQ0FBQ21ELFFBQVEsQ0FBQyxDQUFDO0lBQ3BELE1BQU01QixNQUFNLEdBQUdWLFFBQVEsQ0FBQ0MsT0FBTyxDQUFDO0lBRWhDLE1BQU1VLEdBQUcsR0FBRyxNQUFNLElBQUFDLGlCQUFTLEVBQUNYLE9BQU8sRUFBRTtNQUFFeUMsT0FBTyxFQUFFRDtJQUFRLENBQUMsRUFBRSxJQUFBbEQsa0NBQWlCLEVBQUMsQ0FBQyxFQUFFOEMsWUFBWSxDQUFDO0lBQzdGLElBQUEvRCxjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3pCLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFFYixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDVSxNQUFNLENBQUMsQ0FBQzFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDOUIsSUFBQUwsY0FBTSxFQUFDMEIsUUFBUSxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDdEIsT0FBTyxDQUFDK0IsTUFBTSxDQUFDO0lBQ3pDLElBQUFwQyxjQUFNLEVBQUNxQyxHQUFHLENBQUNRLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsRUFBRSxDQUFDO0lBQzdDLElBQUF6QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNnQyxRQUFRLENBQUNYLEdBQUcsQ0FBQyxlQUFlLENBQUMsRUFBRVksT0FBTyxDQUFDLENBQUNDLEdBQUcsQ0FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDdkU7SUFDQSxJQUFBekMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDNEIsWUFBWSxDQUFDeEQsR0FBRyxDQUFFK0QsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUNwRSxPQUFPLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUN6RTtJQUNBLElBQUFMLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ1IsS0FBSyxDQUFDNkMsSUFBSSxDQUFFNUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBSyxlQUFlLENBQUMsQ0FBQyxDQUFDVSxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3BFLENBQUMsQ0FBQztFQUVGLElBQUFOLFVBQUUsRUFBQyxrRUFBa0UsRUFBRSxZQUFZO0lBQ2pGLE1BQU1SLE9BQU8sR0FBRyxNQUFNOUIsV0FBVyxDQUFDLENBQUM7SUFDbkMsTUFBTThFLE9BQU8sR0FBRztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0lBQ0csTUFBTXRDLEdBQUcsR0FBRyxNQUFNLElBQUFDLGlCQUFTLEVBQUNYLE9BQU8sRUFBRTtNQUFFeUMsT0FBTyxFQUFFTztJQUFRLENBQUMsRUFBRSxJQUFBMUQsa0NBQWlCLEVBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztJQUNyRixJQUFBakIsY0FBTSxFQUFDcUMsR0FBRyxDQUFDRyxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUMxQixJQUFJSixHQUFHLENBQUNHLEVBQUUsRUFBRTtJQUNaLElBQUF4QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNnQixPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDYixJQUFJLENBQUMsaUJBQWlCLENBQUM7SUFDaEQsSUFBQXpDLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ2dCLE9BQU8sQ0FBQ3VCLE9BQU8sQ0FBQyxDQUFDQyxTQUFTLENBQUMsY0FBYyxDQUFDO0VBQ3ZELENBQUMsQ0FBQztFQUVGLElBQUExQyxVQUFFLEVBQUMscUdBQXFHLEVBQUUsWUFBWTtJQUNwSCxNQUFNUixPQUFPLEdBQUcsTUFBTTlCLFdBQVcsQ0FBQyxDQUFDO0lBQ25DLE1BQU1pRixJQUFJLEdBQUc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztJQUNHLE1BQU16QyxHQUFHLEdBQUcsTUFBTSxJQUFBQyxpQkFBUyxFQUFDWCxPQUFPLEVBQUU7TUFBRXlDLE9BQU8sRUFBRVU7SUFBSyxDQUFDLEVBQUUsSUFBQTdELGtDQUFpQixFQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDbEYsSUFBQWpCLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ0csRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDekIsSUFBSSxDQUFDSixHQUFHLENBQUNHLEVBQUUsRUFBRTtJQUNiLElBQUF4QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNwQyxXQUFXLENBQUN5RSxJQUFJLENBQUV2RSxDQUFDLElBQUtBLENBQUMsQ0FBQ3lFLE9BQU8sQ0FBQ0csUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDNUUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQVAsZ0JBQVEsRUFBQyxxQ0FBcUMsRUFBRSxNQUFNO0VBQ3BELElBQUFDLFVBQUUsRUFBQyx3RkFBd0YsRUFBRSxZQUFZO0lBQ3ZHLE1BQU1SLE9BQU8sR0FBRyxNQUFNOUIsV0FBVyxDQUFDLENBQUM7SUFDbkMsTUFBTWtFLFlBQVksR0FBRyxNQUFNcEMsT0FBTyxDQUFDZCxNQUFNLENBQUNtRCxRQUFRLENBQUMsQ0FBQztJQUNwRCxNQUFNZ0IsVUFBVSxHQUFHakIsWUFBWSxDQUFDTCxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUVZLE9BQU87SUFDNUQsSUFBQXRFLGNBQU0sRUFBQ2dGLFVBQVUsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztJQUNoQyxJQUFBakYsY0FBTSxFQUFDZ0YsVUFBVSxDQUFDLENBQUNULEdBQUcsQ0FBQzlCLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFdEMsTUFBTUosR0FBRyxHQUFHLE1BQU0sSUFBQUMsaUJBQVMsRUFDekJYLE9BQU8sRUFDUDtNQUFFWSxRQUFRLEVBQUU7UUFBRSxjQUFjLEVBQUU7TUFBNEM7SUFBRSxDQUFDLEVBQzdFLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQ25COEMsWUFDRixDQUFDO0lBQ0QsSUFBQS9ELGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ0csRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDekIsSUFBSSxDQUFDSixHQUFHLENBQUNHLEVBQUUsRUFBRTtJQUViLElBQUF4QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNnQyxRQUFRLENBQUNYLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRVksT0FBTyxDQUFDLENBQUM3QixJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ2pFLElBQUF6QyxjQUFNLEVBQUNxQyxHQUFHLENBQUM0QixZQUFZLENBQUMsQ0FBQzVELE9BQU8sQ0FBQyxDQUFDO01BQUVvRSxPQUFPLEVBQUUsY0FBYztNQUFFckMsTUFBTSxFQUFFNEMsVUFBVTtNQUFFRSxLQUFLLEVBQUU7SUFBVSxDQUFDLENBQUMsQ0FBQzs7SUFFckc7SUFDQSxNQUFNQSxLQUFLLEdBQUcsTUFBTXZELE9BQU8sQ0FBQ2QsTUFBTSxDQUFDbUQsUUFBUSxDQUFDLENBQUM7SUFDN0MsSUFBQWhFLGNBQU0sRUFBQ2tGLEtBQUssQ0FBQ3hCLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRVksT0FBTyxDQUFDLENBQUM3QixJQUFJLENBQUN1QyxVQUFVLENBQUM7RUFDN0QsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQTlDLGdCQUFRLEVBQUMseURBQXlELEVBQUUsTUFBTTtFQUN4RSxNQUFNaUQsV0FBVyxHQUFHO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7RUFFQyxlQUFlQyxZQUFZQSxDQUFBLEVBQTJCO0lBQ3BELE1BQU16RixLQUFLLEdBQUc7TUFDWixvQkFBb0IsRUFBRWQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDbkNDLE1BQU0sRUFBRSxDQUFDO1FBQ1RDLE1BQU0sRUFBRTtVQUFFQyxNQUFNLEVBQUUsU0FBUztVQUFFQyxPQUFPLEVBQUU7UUFBVSxDQUFDO1FBQ2pEQyxVQUFVLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QkMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWRSxLQUFLLEVBQUU7TUFDVCxDQUFDLENBQUM7TUFDRixnQ0FBZ0MsRUFBRTZGO0lBQ3BDLENBQUM7SUFDRCxNQUFNckYsTUFBTSxHQUFHLE1BQU0sSUFBQUMsb0JBQVksRUFBQ0wsTUFBTSxDQUFDQyxLQUFLLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDeEQsTUFBTVcsT0FBTyxHQUFHQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ1YsTUFBTSxDQUFDWCxVQUFVLENBQUNzQixHQUFHLENBQUVDLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNDLElBQUksRUFBRUQsQ0FBQyxDQUFDRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ3BGLE1BQU1DLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQUNULE9BQU8sRUFBRTtNQUFFVSxTQUFTLEVBQUUsSUFBQUMsa0NBQWlCLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFDekYsTUFBTTtNQUFFQyxTQUFTO01BQUVDO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGdDQUFpQixFQUFDdEIsTUFBTSxDQUFDO0lBQzFELE1BQU1lLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDSCxTQUFTLENBQUM7SUFDM0IsT0FBTztNQUNMTCxNQUFNO01BQUVLLFNBQVM7TUFBRUMsU0FBUztNQUFFRyxLQUFLLEVBQUUsRUFBRTtNQUFFaEMsS0FBSyxFQUFFLE9BQU87TUFBRVcsV0FBVyxFQUFFLEVBQUU7TUFDeEVLLE9BQU87TUFBRVIsTUFBTTtNQUFFeUIsWUFBWSxFQUFFLEVBQUU7TUFBRUMsWUFBWSxFQUFFLEVBQUU7TUFBRUMsbUJBQW1CLEVBQUU7SUFDNUUsQ0FBQztFQUNIO0VBRUEsSUFBQVUsVUFBRSxFQUFDLDhEQUE4RCxFQUFFLFlBQVk7SUFDN0UsTUFBTVIsT0FBTyxHQUFHLE1BQU15RCxZQUFZLENBQUMsQ0FBQztJQUNwQyxNQUFNQyxHQUFHLEdBQUcxRCxPQUFPLENBQUNkLE1BQU0sQ0FBQ2dCLEtBQUssQ0FBQyxDQUFDLENBQUN5RCxJQUFJLENBQUV4RCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsRUFBRSxLQUFLLFdBQVcsQ0FBQztJQUNwRSxJQUFBL0IsY0FBTSxFQUFDcUYsR0FBRyxFQUFFRSxJQUFJLENBQUMsQ0FBQ04sV0FBVyxDQUFDLENBQUM7SUFDL0IsSUFBQWpGLGNBQU0sRUFBQ3FGLEdBQUcsRUFBRUUsSUFBSSxFQUFFQyxJQUFJLENBQUMsQ0FBQy9DLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDL0IsTUFBTWdELE1BQU0sR0FBR0MsZUFBZSxDQUFDTCxHQUFHLENBQUM7SUFDbkMsSUFBQXJGLGNBQU0sRUFBQ3lGLE1BQU0sRUFBRUYsSUFBSSxDQUFDLENBQUNsRixPQUFPLENBQUNnRixHQUFHLEVBQUVFLElBQUksQ0FBQztJQUN2QyxJQUFBdkYsY0FBTSxFQUFDMkIsT0FBTyxDQUFDZCxNQUFNLENBQUM4RSxLQUFLLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUVqQyxDQUFDLElBQUtBLENBQUMsQ0FBQ2MsT0FBTyxLQUFLb0IsU0FBUyxDQUFDLENBQUMsQ0FBQ3BELElBQUksQ0FBQyxJQUFJLENBQUM7RUFDakYsQ0FBQyxDQUFDO0VBRUYsSUFBQU4sVUFBRSxFQUFDLHdGQUF3RixFQUFFLFlBQVk7SUFDdkcsTUFBTVIsT0FBTyxHQUFHLE1BQU15RCxZQUFZLENBQUMsQ0FBQztJQUNwQyxNQUFNL0MsR0FBRyxHQUFHLE1BQU0sSUFBQUMsaUJBQVMsRUFBQ1gsT0FBTyxFQUFFO01BQUVZLFFBQVEsRUFBRTtRQUFFLFdBQVcsRUFBRTtNQUFXO0lBQUUsQ0FBQyxFQUFFLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBQzFHLElBQUFqQixjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3pCLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFDYixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDUSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ0osSUFBSSxDQUFDLEVBQUUsQ0FBQztJQUN6QyxJQUFBekMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDUSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ0osSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUMsSUFBQXpDLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ1UsTUFBTSxDQUFDdEMsR0FBRyxDQUFFTixDQUFDLElBQUtBLENBQUMsQ0FBQzRCLEVBQUUsQ0FBQyxDQUFDLENBQUMxQixPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztFQUM1RCxDQUFDLENBQUM7RUFFRixJQUFBOEIsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEYsTUFBTVIsT0FBTyxHQUFHLE1BQU15RCxZQUFZLENBQUMsQ0FBQztJQUNwQyxNQUFNL0MsR0FBRyxHQUFHLE1BQU0sSUFBQUMsaUJBQVMsRUFBQ1gsT0FBTyxFQUFFO01BQUVZLFFBQVEsRUFBRTtRQUFFLGlCQUFpQixFQUFFO01BQWdCO0lBQUUsQ0FBQyxFQUFFLElBQUF0QixrQ0FBaUIsRUFBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBQ3JILElBQUFqQixjQUFNLEVBQUNxQyxHQUFHLENBQUNHLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3pCLElBQUksQ0FBQ0osR0FBRyxDQUFDRyxFQUFFLEVBQUU7SUFDYixJQUFBeEMsY0FBTSxFQUFDcUMsR0FBRyxDQUFDUSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2hELElBQUF6QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNRLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNKLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3BELENBQUMsQ0FBQztFQUVGLElBQUFOLFVBQUUsRUFBQyw2RkFBNkYsRUFBRSxZQUFZO0lBQzVHLE1BQU1SLE9BQU8sR0FBRyxNQUFNeUQsWUFBWSxDQUFDLENBQUM7SUFDcEMsTUFBTS9DLEdBQUcsR0FBRyxNQUFNLElBQUFDLGlCQUFTLEVBQ3pCWCxPQUFPLEVBQ1A7TUFBRVksUUFBUSxFQUFFO1FBQUUsV0FBVyxFQUFFLFVBQVU7UUFBRSxXQUFXLEVBQUU7TUFBVztJQUFFLENBQUMsRUFDbEUsSUFBQXRCLGtDQUFpQixFQUFDLENBQUMsRUFDbkIsSUFDRixDQUFDO0lBQ0QsSUFBQWpCLGNBQU0sRUFBQ3FDLEdBQUcsQ0FBQ0csRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDekIsSUFBSSxDQUFDSixHQUFHLENBQUNHLEVBQUUsRUFBRTtJQUNiLElBQUF4QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNRLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsRUFBRSxDQUFDO0lBQ3pDLElBQUF6QyxjQUFNLEVBQUNxQyxHQUFHLENBQUNRLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsRUFBRSxDQUFDO0VBQzNDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==