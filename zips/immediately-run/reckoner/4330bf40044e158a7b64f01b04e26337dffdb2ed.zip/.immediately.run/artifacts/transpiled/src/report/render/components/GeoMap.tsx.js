var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GeoMap;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _bindingsContext = require("../bindingsContext.ts");
var _shape = require("../shape.ts");
var _attrs = require("../attrs.ts");
var _format = require("../format.ts");
var _chartMath = require("../chartMath.ts");
var _palette = require("../palette.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _TierSlot = _interopRequireDefault(require("./TierSlot.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Map — geographic display (§3.3), registered under the catalog name `Map`. Two kinds:
//   • point — plots lat/lon on an equirectangular plane (SVG), value → mark size.
//   • choropleth — v1 ships a **region breakdown**: ranked horizontal bars per region, colored
//     by a sequential value scale. Real polygon geography needs a boundary atlas (topojson);
//     that is a deferred enrichment (noted in src/report/index.ts). The breakdown is honest,
//     legible, and degrades cleanly — never a blank map. Non-table / non-ok source → broken tile.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function GeoMap({
  node
}) {
  _s();
  const kind = (0, _attrs.attrString)(node, 'kind') === 'point' ? 'point' : 'choropleth';
  const bound = (0, _bindingsContext.useSource)((0, _attrs.attrString)(node, 'source'));
  if (bound.status !== 'ok') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "Map",
      reason: bound.message ?? 'unavailable',
      variant: bound.status === 'missing' ? 'needs-access' : 'error'
    });
  }
  const rows = (0, _shape.asRows)(bound.value);
  if (!rows.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Map",
    reason: rows.reason
  });
  if (kind === 'point') {
    const latF = (0, _attrs.attrString)(node, 'lat') ?? 'lat';
    const lonF = (0, _attrs.attrString)(node, 'lon') ?? 'lon';
    const valF = (0, _attrs.attrString)(node, 'value');
    const lonD = (0, _chartMath.niceDomain)(rows.data.map(r => (0, _shape.numericField)(r, lonF)));
    const latD = (0, _chartMath.niceDomain)(rows.data.map(r => (0, _shape.numericField)(r, latF)));
    const x = (0, _chartMath.linearScale)(lonD, [20, 700]);
    const y = (0, _chartMath.linearScale)(latD, [190, 20]); // lat grows up
    const vals = valF ? rows.data.map(r => (0, _shape.numericField)(r, valF) ?? 0) : [];
    const vMax = vals.length ? Math.max(1, ...vals) : 1;
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("figure", {
      className: "rk-tile rk-map",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TierSlot.default, {
        tier: bound.tier
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
        viewBox: "0 0 720 210",
        preserveAspectRatio: "xMidYMid meet",
        className: "rk-chart-svg",
        role: "img",
        "aria-label": "point map",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("rect", {
          x: 0,
          y: 0,
          width: 720,
          height: 210,
          className: "rk-map-bg"
        }), rows.data.map((r, i) => {
          const lon = (0, _shape.numericField)(r, lonF);
          const lat = (0, _shape.numericField)(r, latF);
          if (lon === null || lat === null) return null;
          const rad = valF ? 3 + 9 * Math.sqrt(Math.max(0, ((0, _shape.numericField)(r, valF) ?? 0) / vMax)) : 5;
          return /*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
            cx: x(lon),
            cy: y(lat),
            r: rad,
            fill: (0, _palette.seriesColor)(0),
            fillOpacity: 0.7
          }, i);
        })]
      })]
    });
  }

  // choropleth → region breakdown
  const regionF = (0, _attrs.attrString)(node, 'region') ?? 'region';
  const valF = (0, _attrs.attrString)(node, 'value') ?? 'value';
  const items = rows.data.map(r => ({
    region: (0, _shape.labelField)(r, regionF),
    value: (0, _shape.numericField)(r, valF) ?? 0
  })).sort((a, b) => b.value - a.value);
  const max = Math.max(1, ...items.map(it => it.value));
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("figure", {
    className: "rk-tile rk-map rk-map-breakdown",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TierSlot.default, {
      tier: bound.tier
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "rk-map-rows",
      children: items.map((it, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "rk-map-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-map-region",
          children: it.region
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-map-bar",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rk-map-fill",
            style: {
              width: `${it.value / max * 100}%`,
              background: (0, _palette.sequentialColor)(it.value / max)
            }
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-map-val",
          children: (0, _format.formatNumber)(it.value)
        })]
      }, i))
    })]
  });
}
_s(GeoMap, "5joLNnTxqRabjF7FIIG70b60L3g=", false, function () {
  return [_bindingsContext.useSource];
});
_c = GeoMap;
var _c;
$RefreshReg$(_c, "GeoMap");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9zaGFwZSIsIl9hdHRycyIsIl9mb3JtYXQiLCJfY2hhcnRNYXRoIiwiX3BhbGV0dGUiLCJfQnJva2VuVGlsZSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfVGllclNsb3QiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiR2VvTWFwIiwibm9kZSIsImtpbmQiLCJhdHRyU3RyaW5nIiwiYm91bmQiLCJ1c2VTb3VyY2UiLCJzdGF0dXMiLCJqc3giLCJjb21wb25lbnQiLCJyZWFzb24iLCJtZXNzYWdlIiwidmFyaWFudCIsInJvd3MiLCJhc1Jvd3MiLCJ2YWx1ZSIsIm9rIiwibGF0RiIsImxvbkYiLCJ2YWxGIiwibG9uRCIsIm5pY2VEb21haW4iLCJkYXRhIiwibWFwIiwiciIsIm51bWVyaWNGaWVsZCIsImxhdEQiLCJ4IiwibGluZWFyU2NhbGUiLCJ5IiwidmFscyIsInZNYXgiLCJsZW5ndGgiLCJNYXRoIiwibWF4IiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwidGllciIsInZpZXdCb3giLCJwcmVzZXJ2ZUFzcGVjdFJhdGlvIiwicm9sZSIsIndpZHRoIiwiaGVpZ2h0IiwiaSIsImxvbiIsImxhdCIsInJhZCIsInNxcnQiLCJjeCIsImN5IiwiZmlsbCIsInNlcmllc0NvbG9yIiwiZmlsbE9wYWNpdHkiLCJyZWdpb25GIiwiaXRlbXMiLCJyZWdpb24iLCJsYWJlbEZpZWxkIiwic29ydCIsImEiLCJiIiwiaXQiLCJzdHlsZSIsImJhY2tncm91bmQiLCJzZXF1ZW50aWFsQ29sb3IiLCJmb3JtYXROdW1iZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkdlb01hcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTWFwIOKAlCBnZW9ncmFwaGljIGRpc3BsYXkgKMKnMy4zKSwgcmVnaXN0ZXJlZCB1bmRlciB0aGUgY2F0YWxvZyBuYW1lIGBNYXBgLiBUd28ga2luZHM6XG4vLyAgIOKAoiBwb2ludCDigJQgcGxvdHMgbGF0L2xvbiBvbiBhbiBlcXVpcmVjdGFuZ3VsYXIgcGxhbmUgKFNWRyksIHZhbHVlIOKGkiBtYXJrIHNpemUuXG4vLyAgIOKAoiBjaG9yb3BsZXRoIOKAlCB2MSBzaGlwcyBhICoqcmVnaW9uIGJyZWFrZG93bioqOiByYW5rZWQgaG9yaXpvbnRhbCBiYXJzIHBlciByZWdpb24sIGNvbG9yZWRcbi8vICAgICBieSBhIHNlcXVlbnRpYWwgdmFsdWUgc2NhbGUuIFJlYWwgcG9seWdvbiBnZW9ncmFwaHkgbmVlZHMgYSBib3VuZGFyeSBhdGxhcyAodG9wb2pzb24pO1xuLy8gICAgIHRoYXQgaXMgYSBkZWZlcnJlZCBlbnJpY2htZW50IChub3RlZCBpbiBzcmMvcmVwb3J0L2luZGV4LnRzKS4gVGhlIGJyZWFrZG93biBpcyBob25lc3QsXG4vLyAgICAgbGVnaWJsZSwgYW5kIGRlZ3JhZGVzIGNsZWFubHkg4oCUIG5ldmVyIGEgYmxhbmsgbWFwLiBOb24tdGFibGUgLyBub24tb2sgc291cmNlIOKGkiBicm9rZW4gdGlsZS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IHVzZVNvdXJjZSB9IGZyb20gJy4uL2JpbmRpbmdzQ29udGV4dC50cyc7XG5pbXBvcnQgeyBhc1Jvd3MsIG51bWVyaWNGaWVsZCwgbGFiZWxGaWVsZCB9IGZyb20gJy4uL3NoYXBlLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyBmb3JtYXROdW1iZXIgfSBmcm9tICcuLi9mb3JtYXQudHMnO1xuaW1wb3J0IHsgbGluZWFyU2NhbGUsIG5pY2VEb21haW4gfSBmcm9tICcuLi9jaGFydE1hdGgudHMnO1xuaW1wb3J0IHsgc2VxdWVudGlhbENvbG9yLCBzZXJpZXNDb2xvciB9IGZyb20gJy4uL3BhbGV0dGUudHMnO1xuaW1wb3J0IEJyb2tlblRpbGUgZnJvbSAnLi9Ccm9rZW5UaWxlLnRzeCc7XG5pbXBvcnQgVGllclNsb3QgZnJvbSAnLi9UaWVyU2xvdC50c3gnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHZW9NYXAoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IGtpbmQgPSBhdHRyU3RyaW5nKG5vZGUsICdraW5kJykgPT09ICdwb2ludCcgPyAncG9pbnQnIDogJ2Nob3JvcGxldGgnO1xuICBjb25zdCBib3VuZCA9IHVzZVNvdXJjZShhdHRyU3RyaW5nKG5vZGUsICdzb3VyY2UnKSk7XG5cbiAgaWYgKGJvdW5kLnN0YXR1cyAhPT0gJ29rJykge1xuICAgIHJldHVybiA8QnJva2VuVGlsZSBjb21wb25lbnQ9XCJNYXBcIiByZWFzb249e2JvdW5kLm1lc3NhZ2UgPz8gJ3VuYXZhaWxhYmxlJ30gdmFyaWFudD17Ym91bmQuc3RhdHVzID09PSAnbWlzc2luZycgPyAnbmVlZHMtYWNjZXNzJyA6ICdlcnJvcid9IC8+O1xuICB9XG4gIGNvbnN0IHJvd3MgPSBhc1Jvd3MoYm91bmQudmFsdWUpO1xuICBpZiAoIXJvd3Mub2spIHJldHVybiA8QnJva2VuVGlsZSBjb21wb25lbnQ9XCJNYXBcIiByZWFzb249e3Jvd3MucmVhc29ufSAvPjtcblxuICBpZiAoa2luZCA9PT0gJ3BvaW50Jykge1xuICAgIGNvbnN0IGxhdEYgPSBhdHRyU3RyaW5nKG5vZGUsICdsYXQnKSA/PyAnbGF0JztcbiAgICBjb25zdCBsb25GID0gYXR0clN0cmluZyhub2RlLCAnbG9uJykgPz8gJ2xvbic7XG4gICAgY29uc3QgdmFsRiA9IGF0dHJTdHJpbmcobm9kZSwgJ3ZhbHVlJyk7XG4gICAgY29uc3QgbG9uRCA9IG5pY2VEb21haW4ocm93cy5kYXRhLm1hcCgocikgPT4gbnVtZXJpY0ZpZWxkKHIsIGxvbkYpKSk7XG4gICAgY29uc3QgbGF0RCA9IG5pY2VEb21haW4ocm93cy5kYXRhLm1hcCgocikgPT4gbnVtZXJpY0ZpZWxkKHIsIGxhdEYpKSk7XG4gICAgY29uc3QgeCA9IGxpbmVhclNjYWxlKGxvbkQsIFsyMCwgNzAwXSk7XG4gICAgY29uc3QgeSA9IGxpbmVhclNjYWxlKGxhdEQsIFsxOTAsIDIwXSk7IC8vIGxhdCBncm93cyB1cFxuICAgIGNvbnN0IHZhbHMgPSB2YWxGID8gcm93cy5kYXRhLm1hcCgocikgPT4gbnVtZXJpY0ZpZWxkKHIsIHZhbEYpID8/IDApIDogW107XG4gICAgY29uc3Qgdk1heCA9IHZhbHMubGVuZ3RoID8gTWF0aC5tYXgoMSwgLi4udmFscykgOiAxO1xuICAgIHJldHVybiAoXG4gICAgICA8ZmlndXJlIGNsYXNzTmFtZT1cInJrLXRpbGUgcmstbWFwXCI+XG4gICAgICAgIDxUaWVyU2xvdCB0aWVyPXtib3VuZC50aWVyfSAvPlxuICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgNzIwIDIxMFwiIHByZXNlcnZlQXNwZWN0UmF0aW89XCJ4TWlkWU1pZCBtZWV0XCIgY2xhc3NOYW1lPVwicmstY2hhcnQtc3ZnXCIgcm9sZT1cImltZ1wiIGFyaWEtbGFiZWw9XCJwb2ludCBtYXBcIj5cbiAgICAgICAgICA8cmVjdCB4PXswfSB5PXswfSB3aWR0aD17NzIwfSBoZWlnaHQ9ezIxMH0gY2xhc3NOYW1lPVwicmstbWFwLWJnXCIgLz5cbiAgICAgICAgICB7cm93cy5kYXRhLm1hcCgociwgaSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbG9uID0gbnVtZXJpY0ZpZWxkKHIsIGxvbkYpO1xuICAgICAgICAgICAgY29uc3QgbGF0ID0gbnVtZXJpY0ZpZWxkKHIsIGxhdEYpO1xuICAgICAgICAgICAgaWYgKGxvbiA9PT0gbnVsbCB8fCBsYXQgPT09IG51bGwpIHJldHVybiBudWxsO1xuICAgICAgICAgICAgY29uc3QgcmFkID0gdmFsRiA/IDMgKyA5ICogTWF0aC5zcXJ0KE1hdGgubWF4KDAsIChudW1lcmljRmllbGQociwgdmFsRikgPz8gMCkgLyB2TWF4KSkgOiA1O1xuICAgICAgICAgICAgcmV0dXJuIDxjaXJjbGUga2V5PXtpfSBjeD17eChsb24pfSBjeT17eShsYXQpfSByPXtyYWR9IGZpbGw9e3Nlcmllc0NvbG9yKDApfSBmaWxsT3BhY2l0eT17MC43fSAvPjtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9zdmc+XG4gICAgICA8L2ZpZ3VyZT5cbiAgICApO1xuICB9XG5cbiAgLy8gY2hvcm9wbGV0aCDihpIgcmVnaW9uIGJyZWFrZG93blxuICBjb25zdCByZWdpb25GID0gYXR0clN0cmluZyhub2RlLCAncmVnaW9uJykgPz8gJ3JlZ2lvbic7XG4gIGNvbnN0IHZhbEYgPSBhdHRyU3RyaW5nKG5vZGUsICd2YWx1ZScpID8/ICd2YWx1ZSc7XG4gIGNvbnN0IGl0ZW1zID0gcm93cy5kYXRhXG4gICAgLm1hcCgocikgPT4gKHsgcmVnaW9uOiBsYWJlbEZpZWxkKHIsIHJlZ2lvbkYpLCB2YWx1ZTogbnVtZXJpY0ZpZWxkKHIsIHZhbEYpID8/IDAgfSkpXG4gICAgLnNvcnQoKGEsIGIpID0+IGIudmFsdWUgLSBhLnZhbHVlKTtcbiAgY29uc3QgbWF4ID0gTWF0aC5tYXgoMSwgLi4uaXRlbXMubWFwKChpdCkgPT4gaXQudmFsdWUpKTtcbiAgcmV0dXJuIChcbiAgICA8ZmlndXJlIGNsYXNzTmFtZT1cInJrLXRpbGUgcmstbWFwIHJrLW1hcC1icmVha2Rvd25cIj5cbiAgICAgIDxUaWVyU2xvdCB0aWVyPXtib3VuZC50aWVyfSAvPlxuICAgICAgPHVsIGNsYXNzTmFtZT1cInJrLW1hcC1yb3dzXCI+XG4gICAgICAgIHtpdGVtcy5tYXAoKGl0LCBpKSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17aX0gY2xhc3NOYW1lPVwicmstbWFwLXJvd1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstbWFwLXJlZ2lvblwiPntpdC5yZWdpb259PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstbWFwLWJhclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1tYXAtZmlsbFwiIHN0eWxlPXt7IHdpZHRoOiBgJHsoaXQudmFsdWUgLyBtYXgpICogMTAwfSVgLCBiYWNrZ3JvdW5kOiBzZXF1ZW50aWFsQ29sb3IoaXQudmFsdWUgLyBtYXgpIH19IC8+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1tYXAtdmFsXCI+e2Zvcm1hdE51bWJlcihpdC52YWx1ZSl9PC9zcGFuPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICkpfVxuICAgICAgPC91bD5cbiAgICA8L2ZpZ3VyZT5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFPQSxJQUFBQSxnQkFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsT0FBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksVUFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssUUFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sV0FBQSxHQUFBQyxzQkFBQSxDQUFBUCxPQUFBO0FBQ0EsSUFBQVEsU0FBQSxHQUFBRCxzQkFBQSxDQUFBUCxPQUFBO0FBQXNDLElBQUFTLFdBQUEsR0FBQVQsT0FBQTtBQUFBLElBQUFVLEVBQUEsR0FBQUMsWUFBQSxJQWR0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSix1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVdlLFNBQVNHLE1BQU1BLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDaEUsTUFBTU8sSUFBSSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxNQUFNLENBQUMsS0FBSyxPQUFPLEdBQUcsT0FBTyxHQUFHLFlBQVk7RUFDMUUsTUFBTUcsS0FBSyxHQUFHLElBQUFDLDBCQUFTLEVBQUMsSUFBQUYsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0VBRW5ELElBQUlHLEtBQUssQ0FBQ0UsTUFBTSxLQUFLLElBQUksRUFBRTtJQUN6QixvQkFBTyxJQUFBWixXQUFBLENBQUFhLEdBQUEsRUFBQ2hCLFdBQUEsQ0FBQVEsT0FBVTtNQUFDUyxTQUFTLEVBQUMsS0FBSztNQUFDQyxNQUFNLEVBQUVMLEtBQUssQ0FBQ00sT0FBTyxJQUFJLGFBQWM7TUFBQ0MsT0FBTyxFQUFFUCxLQUFLLENBQUNFLE1BQU0sS0FBSyxTQUFTLEdBQUcsY0FBYyxHQUFHO0lBQVEsQ0FBRSxDQUFDO0VBQy9JO0VBQ0EsTUFBTU0sSUFBSSxHQUFHLElBQUFDLGFBQU0sRUFBQ1QsS0FBSyxDQUFDVSxLQUFLLENBQUM7RUFDaEMsSUFBSSxDQUFDRixJQUFJLENBQUNHLEVBQUUsRUFBRSxvQkFBTyxJQUFBckIsV0FBQSxDQUFBYSxHQUFBLEVBQUNoQixXQUFBLENBQUFRLE9BQVU7SUFBQ1MsU0FBUyxFQUFDLEtBQUs7SUFBQ0MsTUFBTSxFQUFFRyxJQUFJLENBQUNIO0VBQU8sQ0FBRSxDQUFDO0VBRXhFLElBQUlQLElBQUksS0FBSyxPQUFPLEVBQUU7SUFDcEIsTUFBTWMsSUFBSSxHQUFHLElBQUFiLGlCQUFVLEVBQUNGLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxLQUFLO0lBQzdDLE1BQU1nQixJQUFJLEdBQUcsSUFBQWQsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLEtBQUs7SUFDN0MsTUFBTWlCLElBQUksR0FBRyxJQUFBZixpQkFBVSxFQUFDRixJQUFJLEVBQUUsT0FBTyxDQUFDO0lBQ3RDLE1BQU1rQixJQUFJLEdBQUcsSUFBQUMscUJBQVUsRUFBQ1IsSUFBSSxDQUFDUyxJQUFJLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLElBQUFDLG1CQUFZLEVBQUNELENBQUMsRUFBRU4sSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNwRSxNQUFNUSxJQUFJLEdBQUcsSUFBQUwscUJBQVUsRUFBQ1IsSUFBSSxDQUFDUyxJQUFJLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLElBQUFDLG1CQUFZLEVBQUNELENBQUMsRUFBRVAsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNwRSxNQUFNVSxDQUFDLEdBQUcsSUFBQUMsc0JBQVcsRUFBQ1IsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3RDLE1BQU1TLENBQUMsR0FBRyxJQUFBRCxzQkFBVyxFQUFDRixJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hDLE1BQU1JLElBQUksR0FBR1gsSUFBSSxHQUFHTixJQUFJLENBQUNTLElBQUksQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUssSUFBQUMsbUJBQVksRUFBQ0QsQ0FBQyxFQUFFTCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO0lBQ3pFLE1BQU1ZLElBQUksR0FBR0QsSUFBSSxDQUFDRSxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHSixJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ25ELG9CQUNFLElBQUFuQyxXQUFBLENBQUF3QyxJQUFBO01BQVFDLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQUMsUUFBQSxnQkFDaEMsSUFBQTFDLFdBQUEsQ0FBQWEsR0FBQSxFQUFDZCxTQUFBLENBQUFNLE9BQVE7UUFBQ3NDLElBQUksRUFBRWpDLEtBQUssQ0FBQ2lDO01BQUssQ0FBRSxDQUFDLGVBQzlCLElBQUEzQyxXQUFBLENBQUF3QyxJQUFBO1FBQUtJLE9BQU8sRUFBQyxhQUFhO1FBQUNDLG1CQUFtQixFQUFDLGVBQWU7UUFBQ0osU0FBUyxFQUFDLGNBQWM7UUFBQ0ssSUFBSSxFQUFDLEtBQUs7UUFBQyxjQUFXLFdBQVc7UUFBQUosUUFBQSxnQkFDdkgsSUFBQTFDLFdBQUEsQ0FBQWEsR0FBQTtVQUFNbUIsQ0FBQyxFQUFFLENBQUU7VUFBQ0UsQ0FBQyxFQUFFLENBQUU7VUFBQ2EsS0FBSyxFQUFFLEdBQUk7VUFBQ0MsTUFBTSxFQUFFLEdBQUk7VUFBQ1AsU0FBUyxFQUFDO1FBQVcsQ0FBRSxDQUFDLEVBQ2xFdkIsSUFBSSxDQUFDUyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDQyxDQUFDLEVBQUVvQixDQUFDLEtBQUs7VUFDdkIsTUFBTUMsR0FBRyxHQUFHLElBQUFwQixtQkFBWSxFQUFDRCxDQUFDLEVBQUVOLElBQUksQ0FBQztVQUNqQyxNQUFNNEIsR0FBRyxHQUFHLElBQUFyQixtQkFBWSxFQUFDRCxDQUFDLEVBQUVQLElBQUksQ0FBQztVQUNqQyxJQUFJNEIsR0FBRyxLQUFLLElBQUksSUFBSUMsR0FBRyxLQUFLLElBQUksRUFBRSxPQUFPLElBQUk7VUFDN0MsTUFBTUMsR0FBRyxHQUFHNUIsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUdjLElBQUksQ0FBQ2UsSUFBSSxDQUFDZixJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFBVCxtQkFBWSxFQUFDRCxDQUFDLEVBQUVMLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSVksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO1VBQzFGLG9CQUFPLElBQUFwQyxXQUFBLENBQUFhLEdBQUE7WUFBZ0J5QyxFQUFFLEVBQUV0QixDQUFDLENBQUNrQixHQUFHLENBQUU7WUFBQ0ssRUFBRSxFQUFFckIsQ0FBQyxDQUFDaUIsR0FBRyxDQUFFO1lBQUN0QixDQUFDLEVBQUV1QixHQUFJO1lBQUNJLElBQUksRUFBRSxJQUFBQyxvQkFBVyxFQUFDLENBQUMsQ0FBRTtZQUFDQyxXQUFXLEVBQUU7VUFBSSxHQUExRVQsQ0FBNEUsQ0FBQztRQUNuRyxDQUFDLENBQUM7TUFBQSxDQUNDLENBQUM7SUFBQSxDQUNBLENBQUM7RUFFYjs7RUFFQTtFQUNBLE1BQU1VLE9BQU8sR0FBRyxJQUFBbEQsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVE7RUFDdEQsTUFBTWlCLElBQUksR0FBRyxJQUFBZixpQkFBVSxFQUFDRixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksT0FBTztFQUNqRCxNQUFNcUQsS0FBSyxHQUFHMUMsSUFBSSxDQUFDUyxJQUFJLENBQ3BCQyxHQUFHLENBQUVDLENBQUMsS0FBTTtJQUFFZ0MsTUFBTSxFQUFFLElBQUFDLGlCQUFVLEVBQUNqQyxDQUFDLEVBQUU4QixPQUFPLENBQUM7SUFBRXZDLEtBQUssRUFBRSxJQUFBVSxtQkFBWSxFQUFDRCxDQUFDLEVBQUVMLElBQUksQ0FBQyxJQUFJO0VBQUUsQ0FBQyxDQUFDLENBQUMsQ0FDbkZ1QyxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUtBLENBQUMsQ0FBQzdDLEtBQUssR0FBRzRDLENBQUMsQ0FBQzVDLEtBQUssQ0FBQztFQUNwQyxNQUFNbUIsR0FBRyxHQUFHRCxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBR3FCLEtBQUssQ0FBQ2hDLEdBQUcsQ0FBRXNDLEVBQUUsSUFBS0EsRUFBRSxDQUFDOUMsS0FBSyxDQUFDLENBQUM7RUFDdkQsb0JBQ0UsSUFBQXBCLFdBQUEsQ0FBQXdDLElBQUE7SUFBUUMsU0FBUyxFQUFDLGlDQUFpQztJQUFBQyxRQUFBLGdCQUNqRCxJQUFBMUMsV0FBQSxDQUFBYSxHQUFBLEVBQUNkLFNBQUEsQ0FBQU0sT0FBUTtNQUFDc0MsSUFBSSxFQUFFakMsS0FBSyxDQUFDaUM7SUFBSyxDQUFFLENBQUMsZUFDOUIsSUFBQTNDLFdBQUEsQ0FBQWEsR0FBQTtNQUFJNEIsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxFQUN4QmtCLEtBQUssQ0FBQ2hDLEdBQUcsQ0FBQyxDQUFDc0MsRUFBRSxFQUFFakIsQ0FBQyxrQkFDZixJQUFBakQsV0FBQSxDQUFBd0MsSUFBQTtRQUFZQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLGdCQUNoQyxJQUFBMUMsV0FBQSxDQUFBYSxHQUFBO1VBQU00QixTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEVBQUV3QixFQUFFLENBQUNMO1FBQU0sQ0FBTyxDQUFDLGVBQ2xELElBQUE3RCxXQUFBLENBQUFhLEdBQUE7VUFBTTRCLFNBQVMsRUFBQyxZQUFZO1VBQUFDLFFBQUEsZUFDMUIsSUFBQTFDLFdBQUEsQ0FBQWEsR0FBQTtZQUFNNEIsU0FBUyxFQUFDLGFBQWE7WUFBQzBCLEtBQUssRUFBRTtjQUFFcEIsS0FBSyxFQUFFLEdBQUltQixFQUFFLENBQUM5QyxLQUFLLEdBQUdtQixHQUFHLEdBQUksR0FBRyxHQUFHO2NBQUU2QixVQUFVLEVBQUUsSUFBQUMsd0JBQWUsRUFBQ0gsRUFBRSxDQUFDOUMsS0FBSyxHQUFHbUIsR0FBRztZQUFFO1VBQUUsQ0FBRTtRQUFDLENBQ3pILENBQUMsZUFDUCxJQUFBdkMsV0FBQSxDQUFBYSxHQUFBO1VBQU00QixTQUFTLEVBQUMsWUFBWTtVQUFBQyxRQUFBLEVBQUUsSUFBQTRCLG9CQUFZLEVBQUNKLEVBQUUsQ0FBQzlDLEtBQUs7UUFBQyxDQUFPLENBQUM7TUFBQSxHQUxyRDZCLENBTUwsQ0FDTDtJQUFDLENBQ0EsQ0FBQztFQUFBLENBQ0MsQ0FBQztBQUViO0FBQUNoRCxFQUFBLENBNUR1QkssTUFBTTtFQUFBLFFBRWRLLDBCQUFTO0FBQUE7QUFBQTRELEVBQUEsR0FGRGpFLE1BQU07QUFBQSxJQUFBaUUsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}