"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _vitest = require("vitest");
var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
// Platform guards: source-level invariants that only fail on immediately.run (the
// "works in vite dev, breaks on the platform" trap). Vitest runs in Node; these read the
// repo's own source and fail loudly at test time, not in a user's browser.

/** Modules exempt from each guard, with the reason each is safe. */
const IMPORT_META_EXEMPT = new Set([
// vite-only dev entry — the platform never loads it (entry is App.tsx's default export).
'src/main.tsx',
// the one sanctioned home of import.meta.url, reached only via dynamic import inside
// makeTransport's try/catch, so its parse failure on the platform is catchable.
'src/app/workerUrl.ts']);
function* tsFiles(dir) {
  for (const name of (0, _nodeFs.readdirSync)(dir)) {
    const p = (0, _nodePath.join)(dir, name);
    if ((0, _nodeFs.statSync)(p).isDirectory()) yield* tsFiles(p);else if (/\.(ts|tsx)$/.test(name) && !/\.test\.(ts|tsx)$/.test(name)) yield p;
  }
}

/** Strip line + block comments (crude but sufficient: we only need to not match prose). */
function withoutComments(source) {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '');
}
(0, _vitest.describe)('the immediately.run compatibility guards', () => {
  (0, _vitest.it)('no module the platform loads contains import.meta (outside the two exempt files)', () => {
    const offenders = [];
    for (const path of tsFiles((0, _nodePath.join)(process.cwd(), 'src'))) {
      // Normalize to the repo-relative `src/...` path (the walker yields absolute paths).
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      if (IMPORT_META_EXEMPT.has(relFromSrc)) continue;
      if (/import\.meta/.test(withoutComments((0, _nodeFs.readFileSync)(path, 'utf8')))) offenders.push(relFromSrc);
    }
    // Rationale: the platform transpiles ESM→CJS and evaluates classic scripts, where
    // import.meta is a parse-time SyntaxError that kills the whole module — caught live on
    // 2026-08-24 when the reckoner demo first ran on production.
    (0, _vitest.expect)(offenders).toEqual([]);
  });
  (0, _vitest.it)('no module STATICALLY value-imports the SDK task surface (DOCUMENT_NAVIGATOR_SPEC §4.1)', () => {
    const offenders = [];
    for (const path of tsFiles((0, _nodePath.join)(process.cwd(), 'src'))) {
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      const source = withoutComments((0, _nodeFs.readFileSync)(path, 'utf8'));
      // `import type … from '@immediately-run/sdk[/tasks]'` is erased at compile time and
      // is fine; a VALUE import of the task surface is not. `await import(...)` is not a
      // static import statement and so never matches.
      const statics = source.match(/^\s*import\s+(?!type\b)[^;]*from\s*['"]@immediately-run\/sdk(?:\/tasks)?['"]/gm) ?? [];
      for (const stmt of statics) {
        // Only the task surface carries the load-time listener; the root barrel re-exports it.
        if (/@immediately-run\/sdk(\/tasks)?['"]$/.test(stmt.trim())) offenders.push(relFromSrc);
      }
    }
    // Rationale: `@immediately-run/sdk/tasks` calls addListener('task-input', …) at module
    // load, which throws with no host transport — a white screen in plain `vite dev` and in
    // any host-less render. The delegation must reach it via `await import()` inside its
    // handler (the pattern makeTransport already uses for workerUrl). `mounts` is
    // side-effect-clean and is imported normally in useMounts.ts.
    (0, _vitest.expect)(offenders).toEqual([]);
  });
});

// G-DN-B10's reckoner half (R3-447): the manifest `invokes` declaration is the
// self-restriction that admits the edit-file task — an artifact no test read before,
// so deleting it left every suite green (the "ships dark, permanently" failure mode
// DN-R6 records). Pinned here, beside the other source-level platform contracts.
(0, _vitest.describe)('the manifest declares what it invokes (DOCUMENT_NAVIGATOR_SPEC G-DN-B10)', () => {
  (0, _vitest.it)('package.json declares invokes: edit-file at the contract version 1.0', () => {
    const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(__dirname, '../../package.json'), 'utf8'));
    const invokes = pkg['immediately.run']?.invokes ?? [];
    const editFile = invokes.find(i => i.task === 'edit-file');
    (0, _vitest.expect)(editFile).toMatchObject({
      task: 'edit-file',
      version: '1.0'
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9ub2RlRnMiLCJfbm9kZVBhdGgiLCJJTVBPUlRfTUVUQV9FWEVNUFQiLCJTZXQiLCJ0c0ZpbGVzIiwiZGlyIiwibmFtZSIsInJlYWRkaXJTeW5jIiwicCIsImpvaW4iLCJzdGF0U3luYyIsImlzRGlyZWN0b3J5IiwidGVzdCIsIndpdGhvdXRDb21tZW50cyIsInNvdXJjZSIsInJlcGxhY2UiLCJkZXNjcmliZSIsIml0Iiwib2ZmZW5kZXJzIiwicGF0aCIsInByb2Nlc3MiLCJjd2QiLCJyZWxGcm9tU3JjIiwic3BsaXQiLCJoYXMiLCJyZWFkRmlsZVN5bmMiLCJwdXNoIiwiZXhwZWN0IiwidG9FcXVhbCIsInN0YXRpY3MiLCJtYXRjaCIsInN0bXQiLCJ0cmltIiwicGtnIiwiSlNPTiIsInBhcnNlIiwiX19kaXJuYW1lIiwiaW52b2tlcyIsImVkaXRGaWxlIiwiZmluZCIsImkiLCJ0YXNrIiwidG9NYXRjaE9iamVjdCIsInZlcnNpb24iXSwic291cmNlcyI6WyJwbGF0Zm9ybUd1YXJkcy50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFBsYXRmb3JtIGd1YXJkczogc291cmNlLWxldmVsIGludmFyaWFudHMgdGhhdCBvbmx5IGZhaWwgb24gaW1tZWRpYXRlbHkucnVuICh0aGVcbi8vIFwid29ya3MgaW4gdml0ZSBkZXYsIGJyZWFrcyBvbiB0aGUgcGxhdGZvcm1cIiB0cmFwKS4gVml0ZXN0IHJ1bnMgaW4gTm9kZTsgdGhlc2UgcmVhZCB0aGVcbi8vIHJlcG8ncyBvd24gc291cmNlIGFuZCBmYWlsIGxvdWRseSBhdCB0ZXN0IHRpbWUsIG5vdCBpbiBhIHVzZXIncyBicm93c2VyLlxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgcmVhZEZpbGVTeW5jLCByZWFkZGlyU3luYywgc3RhdFN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGpvaW4gfSBmcm9tICdub2RlOnBhdGgnO1xuXG4vKiogTW9kdWxlcyBleGVtcHQgZnJvbSBlYWNoIGd1YXJkLCB3aXRoIHRoZSByZWFzb24gZWFjaCBpcyBzYWZlLiAqL1xuY29uc3QgSU1QT1JUX01FVEFfRVhFTVBUID0gbmV3IFNldChbXG4gIC8vIHZpdGUtb25seSBkZXYgZW50cnkg4oCUIHRoZSBwbGF0Zm9ybSBuZXZlciBsb2FkcyBpdCAoZW50cnkgaXMgQXBwLnRzeCdzIGRlZmF1bHQgZXhwb3J0KS5cbiAgJ3NyYy9tYWluLnRzeCcsXG4gIC8vIHRoZSBvbmUgc2FuY3Rpb25lZCBob21lIG9mIGltcG9ydC5tZXRhLnVybCwgcmVhY2hlZCBvbmx5IHZpYSBkeW5hbWljIGltcG9ydCBpbnNpZGVcbiAgLy8gbWFrZVRyYW5zcG9ydCdzIHRyeS9jYXRjaCwgc28gaXRzIHBhcnNlIGZhaWx1cmUgb24gdGhlIHBsYXRmb3JtIGlzIGNhdGNoYWJsZS5cbiAgJ3NyYy9hcHAvd29ya2VyVXJsLnRzJyxcbl0pO1xuXG5mdW5jdGlvbiogdHNGaWxlcyhkaXI6IHN0cmluZyk6IEdlbmVyYXRvcjxzdHJpbmc+IHtcbiAgZm9yIChjb25zdCBuYW1lIG9mIHJlYWRkaXJTeW5jKGRpcikpIHtcbiAgICBjb25zdCBwID0gam9pbihkaXIsIG5hbWUpO1xuICAgIGlmIChzdGF0U3luYyhwKS5pc0RpcmVjdG9yeSgpKSB5aWVsZCogdHNGaWxlcyhwKTtcbiAgICBlbHNlIGlmICgvXFwuKHRzfHRzeCkkLy50ZXN0KG5hbWUpICYmICEvXFwudGVzdFxcLih0c3x0c3gpJC8udGVzdChuYW1lKSkgeWllbGQgcDtcbiAgfVxufVxuXG4vKiogU3RyaXAgbGluZSArIGJsb2NrIGNvbW1lbnRzIChjcnVkZSBidXQgc3VmZmljaWVudDogd2Ugb25seSBuZWVkIHRvIG5vdCBtYXRjaCBwcm9zZSkuICovXG5mdW5jdGlvbiB3aXRob3V0Q29tbWVudHMoc291cmNlOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc291cmNlLnJlcGxhY2UoL1xcL1xcKltcXHNcXFNdKj9cXCpcXC8vZywgJycpLnJlcGxhY2UoLyhefFxccylcXC9cXC8uKiQvZ20sICcnKTtcbn1cblxuZGVzY3JpYmUoJ3RoZSBpbW1lZGlhdGVseS5ydW4gY29tcGF0aWJpbGl0eSBndWFyZHMnLCAoKSA9PiB7XG4gIGl0KCdubyBtb2R1bGUgdGhlIHBsYXRmb3JtIGxvYWRzIGNvbnRhaW5zIGltcG9ydC5tZXRhIChvdXRzaWRlIHRoZSB0d28gZXhlbXB0IGZpbGVzKScsICgpID0+IHtcbiAgICBjb25zdCBvZmZlbmRlcnM6IHN0cmluZ1tdID0gW107XG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHRzRmlsZXMoam9pbihwcm9jZXNzLmN3ZCgpLCAnc3JjJykpKSB7XG4gICAgICAvLyBOb3JtYWxpemUgdG8gdGhlIHJlcG8tcmVsYXRpdmUgYHNyYy8uLi5gIHBhdGggKHRoZSB3YWxrZXIgeWllbGRzIGFic29sdXRlIHBhdGhzKS5cbiAgICAgIGNvbnN0IHJlbEZyb21TcmMgPSBgc3JjLyR7cGF0aC5zcGxpdCgvWy9cXFxcXXNyY1svXFxcXF0vKVsxXT8ucmVwbGFjZSgvXFxcXC9nLCAnLycpID8/ICcnfWA7XG4gICAgICBpZiAoSU1QT1JUX01FVEFfRVhFTVBULmhhcyhyZWxGcm9tU3JjKSkgY29udGludWU7XG4gICAgICBpZiAoL2ltcG9ydFxcLm1ldGEvLnRlc3Qod2l0aG91dENvbW1lbnRzKHJlYWRGaWxlU3luYyhwYXRoLCAndXRmOCcpKSkpIG9mZmVuZGVycy5wdXNoKHJlbEZyb21TcmMpO1xuICAgIH1cbiAgICAvLyBSYXRpb25hbGU6IHRoZSBwbGF0Zm9ybSB0cmFuc3BpbGVzIEVTTeKGkkNKUyBhbmQgZXZhbHVhdGVzIGNsYXNzaWMgc2NyaXB0cywgd2hlcmVcbiAgICAvLyBpbXBvcnQubWV0YSBpcyBhIHBhcnNlLXRpbWUgU3ludGF4RXJyb3IgdGhhdCBraWxscyB0aGUgd2hvbGUgbW9kdWxlIOKAlCBjYXVnaHQgbGl2ZSBvblxuICAgIC8vIDIwMjYtMDgtMjQgd2hlbiB0aGUgcmVja29uZXIgZGVtbyBmaXJzdCByYW4gb24gcHJvZHVjdGlvbi5cbiAgICBleHBlY3Qob2ZmZW5kZXJzKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgaXQoJ25vIG1vZHVsZSBTVEFUSUNBTExZIHZhbHVlLWltcG9ydHMgdGhlIFNESyB0YXNrIHN1cmZhY2UgKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIMKnNC4xKScsICgpID0+IHtcbiAgICBjb25zdCBvZmZlbmRlcnM6IHN0cmluZ1tdID0gW107XG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHRzRmlsZXMoam9pbihwcm9jZXNzLmN3ZCgpLCAnc3JjJykpKSB7XG4gICAgICBjb25zdCByZWxGcm9tU3JjID0gYHNyYy8ke3BhdGguc3BsaXQoL1svXFxcXF1zcmNbL1xcXFxdLylbMV0/LnJlcGxhY2UoL1xcXFwvZywgJy8nKSA/PyAnJ31gO1xuICAgICAgY29uc3Qgc291cmNlID0gd2l0aG91dENvbW1lbnRzKHJlYWRGaWxlU3luYyhwYXRoLCAndXRmOCcpKTtcbiAgICAgIC8vIGBpbXBvcnQgdHlwZSDigKYgZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGtbL3Rhc2tzXSdgIGlzIGVyYXNlZCBhdCBjb21waWxlIHRpbWUgYW5kXG4gICAgICAvLyBpcyBmaW5lOyBhIFZBTFVFIGltcG9ydCBvZiB0aGUgdGFzayBzdXJmYWNlIGlzIG5vdC4gYGF3YWl0IGltcG9ydCguLi4pYCBpcyBub3QgYVxuICAgICAgLy8gc3RhdGljIGltcG9ydCBzdGF0ZW1lbnQgYW5kIHNvIG5ldmVyIG1hdGNoZXMuXG4gICAgICBjb25zdCBzdGF0aWNzID0gc291cmNlLm1hdGNoKC9eXFxzKmltcG9ydFxccysoPyF0eXBlXFxiKVteO10qZnJvbVxccypbJ1wiXUBpbW1lZGlhdGVseS1ydW5cXC9zZGsoPzpcXC90YXNrcyk/WydcIl0vZ20pID8/IFtdO1xuICAgICAgZm9yIChjb25zdCBzdG10IG9mIHN0YXRpY3MpIHtcbiAgICAgICAgLy8gT25seSB0aGUgdGFzayBzdXJmYWNlIGNhcnJpZXMgdGhlIGxvYWQtdGltZSBsaXN0ZW5lcjsgdGhlIHJvb3QgYmFycmVsIHJlLWV4cG9ydHMgaXQuXG4gICAgICAgIGlmICgvQGltbWVkaWF0ZWx5LXJ1blxcL3NkayhcXC90YXNrcyk/WydcIl0kLy50ZXN0KHN0bXQudHJpbSgpKSkgb2ZmZW5kZXJzLnB1c2gocmVsRnJvbVNyYyk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFJhdGlvbmFsZTogYEBpbW1lZGlhdGVseS1ydW4vc2RrL3Rhc2tzYCBjYWxscyBhZGRMaXN0ZW5lcigndGFzay1pbnB1dCcsIOKApikgYXQgbW9kdWxlXG4gICAgLy8gbG9hZCwgd2hpY2ggdGhyb3dzIHdpdGggbm8gaG9zdCB0cmFuc3BvcnQg4oCUIGEgd2hpdGUgc2NyZWVuIGluIHBsYWluIGB2aXRlIGRldmAgYW5kIGluXG4gICAgLy8gYW55IGhvc3QtbGVzcyByZW5kZXIuIFRoZSBkZWxlZ2F0aW9uIG11c3QgcmVhY2ggaXQgdmlhIGBhd2FpdCBpbXBvcnQoKWAgaW5zaWRlIGl0c1xuICAgIC8vIGhhbmRsZXIgKHRoZSBwYXR0ZXJuIG1ha2VUcmFuc3BvcnQgYWxyZWFkeSB1c2VzIGZvciB3b3JrZXJVcmwpLiBgbW91bnRzYCBpc1xuICAgIC8vIHNpZGUtZWZmZWN0LWNsZWFuIGFuZCBpcyBpbXBvcnRlZCBub3JtYWxseSBpbiB1c2VNb3VudHMudHMuXG4gICAgZXhwZWN0KG9mZmVuZGVycykudG9FcXVhbChbXSk7XG4gIH0pO1xufSk7XG5cbi8vIEctRE4tQjEwJ3MgcmVja29uZXIgaGFsZiAoUjMtNDQ3KTogdGhlIG1hbmlmZXN0IGBpbnZva2VzYCBkZWNsYXJhdGlvbiBpcyB0aGVcbi8vIHNlbGYtcmVzdHJpY3Rpb24gdGhhdCBhZG1pdHMgdGhlIGVkaXQtZmlsZSB0YXNrIOKAlCBhbiBhcnRpZmFjdCBubyB0ZXN0IHJlYWQgYmVmb3JlLFxuLy8gc28gZGVsZXRpbmcgaXQgbGVmdCBldmVyeSBzdWl0ZSBncmVlbiAodGhlIFwic2hpcHMgZGFyaywgcGVybWFuZW50bHlcIiBmYWlsdXJlIG1vZGVcbi8vIEROLVI2IHJlY29yZHMpLiBQaW5uZWQgaGVyZSwgYmVzaWRlIHRoZSBvdGhlciBzb3VyY2UtbGV2ZWwgcGxhdGZvcm0gY29udHJhY3RzLlxuZGVzY3JpYmUoJ3RoZSBtYW5pZmVzdCBkZWNsYXJlcyB3aGF0IGl0IGludm9rZXMgKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIEctRE4tQjEwKScsICgpID0+IHtcbiAgaXQoJ3BhY2thZ2UuanNvbiBkZWNsYXJlcyBpbnZva2VzOiBlZGl0LWZpbGUgYXQgdGhlIGNvbnRyYWN0IHZlcnNpb24gMS4wJywgKCkgPT4ge1xuICAgIGNvbnN0IHBrZyA9IEpTT04ucGFyc2UocmVhZEZpbGVTeW5jKGpvaW4oX19kaXJuYW1lLCAnLi4vLi4vcGFja2FnZS5qc29uJyksICd1dGY4JykpIGFzIHtcbiAgICAgICdpbW1lZGlhdGVseS5ydW4nPzogeyBpbnZva2VzPzogeyB0YXNrOiBzdHJpbmc7IHZlcnNpb246IHN0cmluZyB9W10gfTtcbiAgICB9O1xuICAgIGNvbnN0IGludm9rZXMgPSBwa2dbJ2ltbWVkaWF0ZWx5LnJ1biddPy5pbnZva2VzID8/IFtdO1xuICAgIGNvbnN0IGVkaXRGaWxlID0gaW52b2tlcy5maW5kKChpKSA9PiBpLnRhc2sgPT09ICdlZGl0LWZpbGUnKTtcbiAgICBleHBlY3QoZWRpdEZpbGUpLnRvTWF0Y2hPYmplY3QoeyB0YXNrOiAnZWRpdC1maWxlJywgdmVyc2lvbjogJzEuMCcgfSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxTQUFBLEdBQUFGLE9BQUE7QUFMQTtBQUNBO0FBQ0E7O0FBS0E7QUFDQSxNQUFNRyxrQkFBa0IsR0FBRyxJQUFJQyxHQUFHLENBQUM7QUFDakM7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLHNCQUFzQixDQUN2QixDQUFDO0FBRUYsVUFBVUMsT0FBT0EsQ0FBQ0MsR0FBVyxFQUFxQjtFQUNoRCxLQUFLLE1BQU1DLElBQUksSUFBSSxJQUFBQyxtQkFBVyxFQUFDRixHQUFHLENBQUMsRUFBRTtJQUNuQyxNQUFNRyxDQUFDLEdBQUcsSUFBQUMsY0FBSSxFQUFDSixHQUFHLEVBQUVDLElBQUksQ0FBQztJQUN6QixJQUFJLElBQUFJLGdCQUFRLEVBQUNGLENBQUMsQ0FBQyxDQUFDRyxXQUFXLENBQUMsQ0FBQyxFQUFFLE9BQU9QLE9BQU8sQ0FBQ0ksQ0FBQyxDQUFDLENBQUMsS0FDNUMsSUFBSSxhQUFhLENBQUNJLElBQUksQ0FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQ00sSUFBSSxDQUFDTixJQUFJLENBQUMsRUFBRSxNQUFNRSxDQUFDO0VBQy9FO0FBQ0Y7O0FBRUE7QUFDQSxTQUFTSyxlQUFlQSxDQUFDQyxNQUFjLEVBQVU7RUFDL0MsT0FBT0EsTUFBTSxDQUFDQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUNBLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUM7QUFDL0U7QUFFQSxJQUFBQyxnQkFBUSxFQUFDLDBDQUEwQyxFQUFFLE1BQU07RUFDekQsSUFBQUMsVUFBRSxFQUFDLGtGQUFrRixFQUFFLE1BQU07SUFDM0YsTUFBTUMsU0FBbUIsR0FBRyxFQUFFO0lBQzlCLEtBQUssTUFBTUMsSUFBSSxJQUFJZixPQUFPLENBQUMsSUFBQUssY0FBSSxFQUFDVyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTtNQUN0RDtNQUNBLE1BQU1DLFVBQVUsR0FBRyxPQUFPSCxJQUFJLENBQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRVIsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUU7TUFDckYsSUFBSWIsa0JBQWtCLENBQUNzQixHQUFHLENBQUNGLFVBQVUsQ0FBQyxFQUFFO01BQ3hDLElBQUksY0FBYyxDQUFDVixJQUFJLENBQUNDLGVBQWUsQ0FBQyxJQUFBWSxvQkFBWSxFQUFDTixJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFRCxTQUFTLENBQUNRLElBQUksQ0FBQ0osVUFBVSxDQUFDO0lBQ2xHO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUssY0FBTSxFQUFDVCxTQUFTLENBQUMsQ0FBQ1UsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUMvQixDQUFDLENBQUM7RUFFRixJQUFBWCxVQUFFLEVBQUMsd0ZBQXdGLEVBQUUsTUFBTTtJQUNqRyxNQUFNQyxTQUFtQixHQUFHLEVBQUU7SUFDOUIsS0FBSyxNQUFNQyxJQUFJLElBQUlmLE9BQU8sQ0FBQyxJQUFBSyxjQUFJLEVBQUNXLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFO01BQ3RELE1BQU1DLFVBQVUsR0FBRyxPQUFPSCxJQUFJLENBQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRVIsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUU7TUFDckYsTUFBTUQsTUFBTSxHQUFHRCxlQUFlLENBQUMsSUFBQVksb0JBQVksRUFBQ04sSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQzFEO01BQ0E7TUFDQTtNQUNBLE1BQU1VLE9BQU8sR0FBR2YsTUFBTSxDQUFDZ0IsS0FBSyxDQUFDLGdGQUFnRixDQUFDLElBQUksRUFBRTtNQUNwSCxLQUFLLE1BQU1DLElBQUksSUFBSUYsT0FBTyxFQUFFO1FBQzFCO1FBQ0EsSUFBSSxzQ0FBc0MsQ0FBQ2pCLElBQUksQ0FBQ21CLElBQUksQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFZCxTQUFTLENBQUNRLElBQUksQ0FBQ0osVUFBVSxDQUFDO01BQzFGO0lBQ0Y7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUssY0FBTSxFQUFDVCxTQUFTLENBQUMsQ0FBQ1UsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUMvQixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBWixnQkFBUSxFQUFDLDBFQUEwRSxFQUFFLE1BQU07RUFDekYsSUFBQUMsVUFBRSxFQUFDLHNFQUFzRSxFQUFFLE1BQU07SUFDL0UsTUFBTWdCLEdBQUcsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQVYsb0JBQVksRUFBQyxJQUFBaEIsY0FBSSxFQUFDMkIsU0FBUyxFQUFFLG9CQUFvQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBRWpGO0lBQ0QsTUFBTUMsT0FBTyxHQUFHSixHQUFHLENBQUMsaUJBQWlCLENBQUMsRUFBRUksT0FBTyxJQUFJLEVBQUU7SUFDckQsTUFBTUMsUUFBUSxHQUFHRCxPQUFPLENBQUNFLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxXQUFXLENBQUM7SUFDNUQsSUFBQWQsY0FBTSxFQUFDVyxRQUFRLENBQUMsQ0FBQ0ksYUFBYSxDQUFDO01BQUVELElBQUksRUFBRSxXQUFXO01BQUVFLE9BQU8sRUFBRTtJQUFNLENBQUMsQ0FBQztFQUN2RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=