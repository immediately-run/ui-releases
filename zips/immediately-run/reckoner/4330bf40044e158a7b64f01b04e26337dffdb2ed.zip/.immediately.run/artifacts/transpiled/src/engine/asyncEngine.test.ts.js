"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _asyncEngine = require("./asyncEngine.ts");
var _engine = require("./engine.ts");
var _workerTransport = require("./workerTransport.ts");
var _engineWorker = require("./worker/engineWorker.ts");
var stdlib = _interopRequireWildcard(require("../stdlib/index.ts"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const SOURCES = {
  sheet: `import { cell } from "@reckoner/stdlib";
export const total = cell({ doc: "sum rows", inputs: { rows: "fixtures.data" }, formula: ({ rows }) => rows.reduce((a, r) => a + r.v, 0) });
export const scaled = cell({ doc: "scale by k", inputs: { t: "sheet.total", k: "params.k" }, formula: ({ t, k }) => t * k });
`
};
const EXTERNALS = {
  'fixtures.data': {
    value: [{
      v: 1
    }, {
      v: 2
    }, {
      v: 3
    }],
    tier: 'static'
  },
  'params.k': {
    value: 2,
    tier: 'static'
  }
};

// A controllable transport: runs the real worker body in-process, but can withhold a cell's
// response (a wedged worker, for the watchdog) or delay responses (for supersession), and
// counts restarts + eval posts.
function makeTransport(opts = {}) {
  let worker = (0, _engineWorker.createEngineWorker)();
  let handler = () => {};
  let restarts = 0;
  let evalPosts = 0;
  return {
    transport: {
      post(msg) {
        if (msg.type === 'build') {
          try {
            handler({
              type: 'built',
              descriptor: worker.build(msg.sources)
            });
          } catch (e) {
            handler({
              type: 'build-error',
              message: e.message
            });
          }
          return;
        }
        if (msg.type === 'run-tests') {
          try {
            handler({
              type: 'test-results',
              token: msg.token,
              suites: worker.runSuites(msg.suites)
            });
          } catch (e) {
            handler({
              type: 'eval-error',
              token: msg.token,
              id: '(run-tests)',
              message: e.message
            });
          }
          return;
        }
        evalPosts++;
        if (opts.stuck?.has(msg.id)) return; // withhold → the host watchdog must fire
        const run = () => {
          Promise.resolve().then(() => worker.eval(msg.id, msg.inputs)).then(value => handler({
            type: 'result',
            token: msg.token,
            id: msg.id,
            value
          })).catch(e => handler({
            type: 'eval-error',
            token: msg.token,
            id: msg.id,
            message: e.message
          }));
        };
        if (opts.evalDelayMs) setTimeout(run, opts.evalDelayMs);else run();
      },
      onMessage(h) {
        handler = h;
      },
      restart() {
        restarts++;
        worker = (0, _engineWorker.createEngineWorker)();
      },
      dispose() {}
    },
    restarts: () => restarts,
    evalPosts: () => evalPosts
  };
}
(0, _vitest.describe)('AsyncEngine', () => {
  (0, _vitest.it)('computes the same results as the sync Engine over the worker', async () => {
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    const pass = await engine.run(EXTERNALS);
    const sync = _engine.Engine.fromSources(SOURCES, {
      ...stdlib
    });
    sync.run(EXTERNALS);
    (0, _vitest.expect)(engine.value('sheet.total')).toBe(6);
    (0, _vitest.expect)(engine.value('sheet.scaled')).toBe(12);
    (0, _vitest.expect)(engine.value('sheet.total')).toBe(sync.value('sheet.total'));
    (0, _vitest.expect)(engine.value('sheet.scaled')).toBe(sync.value('sheet.scaled'));
    (0, _vitest.expect)(pass.results.get('sheet.scaled')?.tier).toBe('static');
    (0, _vitest.expect)(pass.errors.size).toBe(0);
  });
  (0, _vitest.it)('propagates a thrown formula as a lattice error to dependents', async () => {
    const sources = {
      sheet: `import { cell } from "@reckoner/stdlib";
export const boom = cell({ doc: "throws", inputs: {}, formula: () => { throw new Error("kaboom"); } });
export const useBoom = cell({ doc: "uses boom", inputs: { b: "sheet.boom" }, formula: ({ b }) => b });
`
    };
    const engine = await _asyncEngine.AsyncEngine.fromSources(sources, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run({});
    (0, _vitest.expect)(engine.error('sheet.boom')).toMatch(/kaboom/);
    (0, _vitest.expect)(engine.error('sheet.useBoom')).toMatch(/input "sheet.boom" errored/);
    (0, _vitest.expect)(engine.value('sheet.useBoom')).toBeUndefined();
  });
  (0, _vitest.it)('reports a dependency cycle as an error on every cell', async () => {
    const sources = {
      s: `import { cell } from "@reckoner/stdlib";
export const a = cell({ doc: "a", inputs: { b: "s.b" }, formula: ({ b }) => b });
export const b = cell({ doc: "b", inputs: { a: "s.a" }, formula: ({ a }) => a });
`
    };
    const engine = await _asyncEngine.AsyncEngine.fromSources(sources, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    const pass = await engine.run({});
    (0, _vitest.expect)(pass.errors.get('s.a')).toMatch(/cycle/);
    (0, _vitest.expect)(pass.errors.get('s.b')).toMatch(/cycle/);
  });
  (0, _vitest.it)('watchdog: a wedged cell times out → terminate + rebuild + quarantine → dependents error', async () => {
    const ctl = makeTransport({
      stuck: new Set(['sheet.total'])
    });
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: ctl.transport,
      evalBudgetMs: 15,
      breaker: {
        hardLimit: 1,
        windowMs: 1000,
        softSuppressMs: 100
      }
    });
    const pass = await engine.run(EXTERNALS);
    (0, _vitest.expect)(ctl.restarts()).toBe(1); // the wedged worker was terminated + rebuilt
    (0, _vitest.expect)(engine.error('sheet.total')).toMatch(/timed out/);
    (0, _vitest.expect)(pass.quarantined).toContain('sheet.total');
    (0, _vitest.expect)(engine.error('sheet.scaled')).toMatch(/errored/); // dependent gets the lattice error

    // Re-arm clears the quarantine; a fresh worker (nothing wedged) settles normally — proving
    // the engine recovers rather than staying permanently broken.
    engine.rearm('sheet.total');
    const engine2 = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine2.run(EXTERNALS);
    (0, _vitest.expect)(engine2.value('sheet.total')).toBe(6);
  });
  (0, _vitest.it)('single-slot supersession: overlapping updates coalesce into one follow-up pass', async () => {
    const ctl = makeTransport({
      evalDelayMs: 10
    });
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: ctl.transport
    });
    const p1 = engine.run(EXTERNALS); // pass 1 in flight (delayed)
    engine.update({
      'params.k': {
        value: 5,
        tier: 'static'
      }
    }); // superseded before it runs
    const p3 = engine.update({
      'params.k': {
        value: 7,
        tier: 'static'
      }
    }); // the survivor
    await Promise.all([p1, p3]);
    (0, _vitest.expect)(engine.value('sheet.scaled')).toBe(42); // 6 * 7 (last update won)
    // Two passes only (initial + one coalesced), 2 cells each → 4 eval posts, not 6.
    (0, _vitest.expect)(ctl.evalPosts()).toBe(4);
  });
  (0, _vitest.it)('awaits an async formula (a formula may return a promise)', async () => {
    const sources = {
      sheet: `import { cell } from "@reckoner/stdlib";
export const a = cell({ doc: "async", inputs: { x: "params.x" }, formula: async ({ x }) => x + 100 });
`
    };
    const engine = await _asyncEngine.AsyncEngine.fromSources(sources, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run({
      'params.x': {
        value: 5,
        tier: 'static'
      }
    });
    (0, _vitest.expect)(engine.value('sheet.a')).toBe(105); // awaited, not a Promise
  });
});
(0, _vitest.describe)('AsyncEngine.runTests — the review surface over the real transport', () => {
  const SOURCES = {
    live: `import { cell, testCell, expectEqual, property } from "@reckoner/stdlib";
export const total = cell({ doc: "sum", inputs: { rows: "feeds.orders" }, formula: ({ rows }) => rows.reduce((a, r) => a + r.eur, 0) });
export const total_check = testCell({ kind: "specification", subject: "live.total", expect: ({ result }) => expectEqual(result, 30) });
export const total_sane = testCell({ kind: "property", subject: "live.total", relation: property("non-negative", (r) => r >= 0) });
export const untouched = cell({ doc: "no tests", inputs: { t: "live.total" }, formula: ({ t }) => t + 1 });
`
  };
  (0, _vitest.it)('runs suites worker-side and returns per-subject verdicts (example+property → validated)', async () => {
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run({
      'feeds.orders': {
        value: [{
          eur: 10
        }, {
          eur: 20
        }],
        tier: 'live'
      }
    });
    const verdicts = await engine.runTests();
    (0, _vitest.expect)(verdicts.get('live.total')?.verdict).toBe('validated');
    // cells without tests are absent — the panel renders them `untested`
    (0, _vitest.expect)(verdicts.has('live.untouched')).toBe(false);
    const check = verdicts.get('live.total').outcomes.find(o => o.id === 'live.total_check');
    (0, _vitest.expect)(check.kind).toBe('specification');
    (0, _vitest.expect)(check.pass).toBe(true);
  });
  (0, _vitest.it)('a broken expectation fails the suite and the verdict reads failing', async () => {
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run({
      'feeds.orders': {
        value: [{
          eur: 1
        }],
        tier: 'live'
      }
    });
    const verdicts = await engine.runTests();
    (0, _vitest.expect)(verdicts.get('live.total')?.verdict).toBe('failing');
  });
  (0, _vitest.it)('a wedged suite times out, restarts the worker, and rejects — the render path recovers', async () => {
    const base = (0, _workerTransport.inMemoryTransport)();
    let withholdTests = false;
    const withholding = {
      post(msg) {
        if (msg.type === 'run-tests' && withholdTests) return; // the wedged-worker shape
        base.post(msg);
      },
      onMessage(h) {
        base.onMessage(h);
      },
      restart() {
        withholdTests = false;
        base.restart();
      },
      dispose() {
        base.dispose();
      }
    };
    const engine = await _asyncEngine.AsyncEngine.fromSources(SOURCES, {
      transport: withholding,
      evalBudgetMs: 20
    });
    await engine.run({
      'feeds.orders': {
        value: [{
          eur: 10
        }],
        tier: 'live'
      }
    });
    withholdTests = true;
    await (0, _vitest.expect)(engine.runTests()).rejects.toThrow(/timed out/);
    // the worker was restarted and rebuilt — the render pipeline still evaluates
    await engine.run({
      'feeds.orders': {
        value: [{
          eur: 5
        }],
        tier: 'live'
      }
    });
    (0, _vitest.expect)(engine.value('live.total')).toBe(5);
  });
});
(0, _vitest.describe)('AsyncEngine.runTests — declared test inputs (R3-373)', () => {
  const SRC = {
    sheet: `import { cell, testCell, expectClose } from "@reckoner/stdlib";
export const total = cell({ doc: "sum", inputs: { rows: "fixtures.data", k: "params.k" }, formula: ({ rows, k }) => rows.reduce((a, r) => a + r.v, 0) * k });
export const holdout = testCell({ kind: "specification", subject: "sheet.total", inputs: { rows: "fixtures.data_holdout", oracle: "fixtures.oracle" }, expect: ({ result, inputs }) => expectClose(result, inputs.oracle[0].expected, { abs: 1e-9 }) });
export const bad_ref = testCell({ kind: "specification", subject: "sheet.total", inputs: { ghost: "fixtures.no_such_fixture" }, expect: () => ({ pass: true, message: "unreached" }) });
export const live_check = testCell({ kind: "specification", subject: "sheet.total", expect: ({ result }) => expectClose(result, 12, { abs: 1e-9 }) });
`
  };
  async function built() {
    const engine = await _asyncEngine.AsyncEngine.fromSources(SRC, {
      transport: (0, _workerTransport.inMemoryTransport)()
    });
    await engine.run({
      'fixtures.data': {
        value: [{
          v: 1
        }, {
          v: 2
        }, {
          v: 3
        }],
        tier: 'static'
      },
      'fixtures.data_holdout': {
        value: [{
          v: 10
        }, {
          v: 5
        }],
        tier: 'static'
      },
      'fixtures.oracle': {
        value: [{
          expected: 30
        }],
        tier: 'static'
      },
      'params.k': {
        value: 2,
        tier: 'static'
      }
    });
    return engine;
  }
  (0, _vitest.it)('name-matched inputs substitute and re-run the subject; name-unmatched are auxiliary', async () => {
    const engine = await built();
    const results = await engine.runTests();
    // holdout: rows → [10, 5] substituted, params.k stays live (2) → (10+5)*2 = 30, and the
    // oracle arrives as auxiliary context — the pass proves both lanes are wired.
    const holdout = results.get('sheet.total')?.outcomes.find(o => o.id === 'sheet.holdout');
    (0, _vitest.expect)(holdout?.pass).toBe(true);
  });
  (0, _vitest.it)('an unresolvable test-input reference fails that test with a message, never silent null', async () => {
    const engine = await built();
    const results = await engine.runTests();
    const bad = results.get('sheet.total')?.outcomes.find(o => o.id === 'sheet.bad_ref');
    (0, _vitest.expect)(bad?.pass).toBe(false);
    (0, _vitest.expect)(bad?.message).toContain('fixtures.no_such_fixture');
  });
  (0, _vitest.it)('a test with no declared inputs still asserts the live value', async () => {
    const engine = await built();
    const results = await engine.runTests();
    const live = results.get('sheet.total')?.outcomes.find(o => o.id === 'sheet.live_check');
    (0, _vitest.expect)(live?.pass).toBe(true);
  });
  (0, _vitest.it)('the sync Engine agrees with the async path', async () => {
    const engine = await built();
    const asyncResults = await engine.runTests();
    const sync = _engine.Engine.fromSources(SRC, {
      ...stdlib
    });
    sync.run({
      'fixtures.data': {
        value: [{
          v: 1
        }, {
          v: 2
        }, {
          v: 3
        }],
        tier: 'static'
      },
      'fixtures.data_holdout': {
        value: [{
          v: 10
        }, {
          v: 5
        }],
        tier: 'static'
      },
      'fixtures.oracle': {
        value: [{
          expected: 30
        }],
        tier: 'static'
      },
      'params.k': {
        value: 2,
        tier: 'static'
      }
    });
    // Suite outcomes carry no ids in the sync path — compare pass/fail by declaration order.
    for (const [subject, suite] of sync.runTests()) {
      const asyncOutcomes = asyncResults.get(subject).outcomes;
      const passes = suite.outcomes.map(o => o.result.pass);
      const asyncPasses = asyncOutcomes.map(o => o.pass);
      (0, _vitest.expect)(asyncPasses, subject).toEqual(passes);
      // holdout + live_check green, bad_ref failing loudly — in BOTH engines.
      (0, _vitest.expect)(passes, subject).toEqual([true, false, true]);
    }
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9hc3luY0VuZ2luZSIsIl9lbmdpbmUiLCJfd29ya2VyVHJhbnNwb3J0IiwiX2VuZ2luZVdvcmtlciIsInN0ZGxpYiIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwiU09VUkNFUyIsInNoZWV0IiwiRVhURVJOQUxTIiwidmFsdWUiLCJ2IiwidGllciIsIm1ha2VUcmFuc3BvcnQiLCJvcHRzIiwid29ya2VyIiwiY3JlYXRlRW5naW5lV29ya2VyIiwiaGFuZGxlciIsInJlc3RhcnRzIiwiZXZhbFBvc3RzIiwidHJhbnNwb3J0IiwicG9zdCIsIm1zZyIsInR5cGUiLCJkZXNjcmlwdG9yIiwiYnVpbGQiLCJzb3VyY2VzIiwibWVzc2FnZSIsInRva2VuIiwic3VpdGVzIiwicnVuU3VpdGVzIiwiaWQiLCJzdHVjayIsInJ1biIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsImV2YWwiLCJpbnB1dHMiLCJjYXRjaCIsImV2YWxEZWxheU1zIiwic2V0VGltZW91dCIsIm9uTWVzc2FnZSIsImgiLCJyZXN0YXJ0IiwiZGlzcG9zZSIsImRlc2NyaWJlIiwiaXQiLCJlbmdpbmUiLCJBc3luY0VuZ2luZSIsImZyb21Tb3VyY2VzIiwiaW5NZW1vcnlUcmFuc3BvcnQiLCJwYXNzIiwic3luYyIsIkVuZ2luZSIsImV4cGVjdCIsInRvQmUiLCJyZXN1bHRzIiwiZXJyb3JzIiwic2l6ZSIsImVycm9yIiwidG9NYXRjaCIsInRvQmVVbmRlZmluZWQiLCJzIiwiY3RsIiwiU2V0IiwiZXZhbEJ1ZGdldE1zIiwiYnJlYWtlciIsImhhcmRMaW1pdCIsIndpbmRvd01zIiwic29mdFN1cHByZXNzTXMiLCJxdWFyYW50aW5lZCIsInRvQ29udGFpbiIsInJlYXJtIiwiZW5naW5lMiIsInAxIiwidXBkYXRlIiwicDMiLCJhbGwiLCJsaXZlIiwiZXVyIiwidmVyZGljdHMiLCJydW5UZXN0cyIsInZlcmRpY3QiLCJjaGVjayIsIm91dGNvbWVzIiwiZmluZCIsIm8iLCJraW5kIiwiYmFzZSIsIndpdGhob2xkVGVzdHMiLCJ3aXRoaG9sZGluZyIsInJlamVjdHMiLCJ0b1Rocm93IiwiU1JDIiwiYnVpbHQiLCJleHBlY3RlZCIsImhvbGRvdXQiLCJiYWQiLCJhc3luY1Jlc3VsdHMiLCJzdWJqZWN0Iiwic3VpdGUiLCJhc3luY091dGNvbWVzIiwicGFzc2VzIiwibWFwIiwicmVzdWx0IiwiYXN5bmNQYXNzZXMiLCJ0b0VxdWFsIl0sInNvdXJjZXMiOlsiYXN5bmNFbmdpbmUudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBBc3luY0VuZ2luZSB9IGZyb20gJy4vYXN5bmNFbmdpbmUudHMnO1xuaW1wb3J0IHsgRW5naW5lIH0gZnJvbSAnLi9lbmdpbmUudHMnO1xuaW1wb3J0IHsgaW5NZW1vcnlUcmFuc3BvcnQgfSBmcm9tICcuL3dvcmtlclRyYW5zcG9ydC50cyc7XG5pbXBvcnQgeyBjcmVhdGVFbmdpbmVXb3JrZXIgfSBmcm9tICcuL3dvcmtlci9lbmdpbmVXb3JrZXIudHMnO1xuaW1wb3J0IHR5cGUgeyBXb3JrZXJUcmFuc3BvcnQgfSBmcm9tICcuL3dvcmtlclRyYW5zcG9ydC50cyc7XG5pbXBvcnQgdHlwZSB7IFdvcmtlclJlc3BvbnNlIH0gZnJvbSAnLi93b3JrZXIvcHJvdG9jb2wudHMnO1xuaW1wb3J0IHR5cGUgeyBFeHRlcm5hbFZhbHVlIH0gZnJvbSAnLi90eXBlcy50cyc7XG5pbXBvcnQgKiBhcyBzdGRsaWIgZnJvbSAnLi4vc3RkbGliL2luZGV4LnRzJztcblxuY29uc3QgU09VUkNFUyA9IHtcbiAgc2hlZXQ6IGBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbmV4cG9ydCBjb25zdCB0b3RhbCA9IGNlbGwoeyBkb2M6IFwic3VtIHJvd3NcIiwgaW5wdXRzOiB7IHJvd3M6IFwiZml4dHVyZXMuZGF0YVwiIH0sIGZvcm11bGE6ICh7IHJvd3MgfSkgPT4gcm93cy5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLnYsIDApIH0pO1xuZXhwb3J0IGNvbnN0IHNjYWxlZCA9IGNlbGwoeyBkb2M6IFwic2NhbGUgYnkga1wiLCBpbnB1dHM6IHsgdDogXCJzaGVldC50b3RhbFwiLCBrOiBcInBhcmFtcy5rXCIgfSwgZm9ybXVsYTogKHsgdCwgayB9KSA9PiB0ICogayB9KTtcbmAsXG59O1xuY29uc3QgRVhURVJOQUxTOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPiA9IHtcbiAgJ2ZpeHR1cmVzLmRhdGEnOiB7IHZhbHVlOiBbeyB2OiAxIH0sIHsgdjogMiB9LCB7IHY6IDMgfV0sIHRpZXI6ICdzdGF0aWMnIH0sXG4gICdwYXJhbXMuayc6IHsgdmFsdWU6IDIsIHRpZXI6ICdzdGF0aWMnIH0sXG59O1xuXG4vLyBBIGNvbnRyb2xsYWJsZSB0cmFuc3BvcnQ6IHJ1bnMgdGhlIHJlYWwgd29ya2VyIGJvZHkgaW4tcHJvY2VzcywgYnV0IGNhbiB3aXRoaG9sZCBhIGNlbGwnc1xuLy8gcmVzcG9uc2UgKGEgd2VkZ2VkIHdvcmtlciwgZm9yIHRoZSB3YXRjaGRvZykgb3IgZGVsYXkgcmVzcG9uc2VzIChmb3Igc3VwZXJzZXNzaW9uKSwgYW5kXG4vLyBjb3VudHMgcmVzdGFydHMgKyBldmFsIHBvc3RzLlxuZnVuY3Rpb24gbWFrZVRyYW5zcG9ydChvcHRzOiB7IHN0dWNrPzogU2V0PHN0cmluZz47IGV2YWxEZWxheU1zPzogbnVtYmVyIH0gPSB7fSk6IHtcbiAgdHJhbnNwb3J0OiBXb3JrZXJUcmFuc3BvcnQ7XG4gIHJlc3RhcnRzOiAoKSA9PiBudW1iZXI7XG4gIGV2YWxQb3N0czogKCkgPT4gbnVtYmVyO1xufSB7XG4gIGxldCB3b3JrZXIgPSBjcmVhdGVFbmdpbmVXb3JrZXIoKTtcbiAgbGV0IGhhbmRsZXI6IChtOiBXb3JrZXJSZXNwb25zZSkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICBsZXQgcmVzdGFydHMgPSAwO1xuICBsZXQgZXZhbFBvc3RzID0gMDtcbiAgcmV0dXJuIHtcbiAgICB0cmFuc3BvcnQ6IHtcbiAgICAgIHBvc3QobXNnKSB7XG4gICAgICAgIGlmIChtc2cudHlwZSA9PT0gJ2J1aWxkJykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBoYW5kbGVyKHsgdHlwZTogJ2J1aWx0JywgZGVzY3JpcHRvcjogd29ya2VyLmJ1aWxkKG1zZy5zb3VyY2VzKSB9KTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBoYW5kbGVyKHsgdHlwZTogJ2J1aWxkLWVycm9yJywgbWVzc2FnZTogKGUgYXMgRXJyb3IpLm1lc3NhZ2UgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobXNnLnR5cGUgPT09ICdydW4tdGVzdHMnKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGhhbmRsZXIoeyB0eXBlOiAndGVzdC1yZXN1bHRzJywgdG9rZW46IG1zZy50b2tlbiwgc3VpdGVzOiB3b3JrZXIucnVuU3VpdGVzKG1zZy5zdWl0ZXMpIH0pO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGhhbmRsZXIoeyB0eXBlOiAnZXZhbC1lcnJvcicsIHRva2VuOiBtc2cudG9rZW4sIGlkOiAnKHJ1bi10ZXN0cyknLCBtZXNzYWdlOiAoZSBhcyBFcnJvcikubWVzc2FnZSB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGV2YWxQb3N0cysrO1xuICAgICAgICBpZiAob3B0cy5zdHVjaz8uaGFzKG1zZy5pZCkpIHJldHVybjsgLy8gd2l0aGhvbGQg4oaSIHRoZSBob3N0IHdhdGNoZG9nIG11c3QgZmlyZVxuICAgICAgICBjb25zdCBydW4gPSAoKTogdm9pZCA9PiB7XG4gICAgICAgICAgUHJvbWlzZS5yZXNvbHZlKClcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHdvcmtlci5ldmFsKG1zZy5pZCwgbXNnLmlucHV0cykpXG4gICAgICAgICAgICAudGhlbigodmFsdWUpID0+IGhhbmRsZXIoeyB0eXBlOiAncmVzdWx0JywgdG9rZW46IG1zZy50b2tlbiwgaWQ6IG1zZy5pZCwgdmFsdWUgfSkpXG4gICAgICAgICAgICAuY2F0Y2goKGUpID0+IGhhbmRsZXIoeyB0eXBlOiAnZXZhbC1lcnJvcicsIHRva2VuOiBtc2cudG9rZW4sIGlkOiBtc2cuaWQsIG1lc3NhZ2U6IChlIGFzIEVycm9yKS5tZXNzYWdlIH0pKTtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKG9wdHMuZXZhbERlbGF5TXMpIHNldFRpbWVvdXQocnVuLCBvcHRzLmV2YWxEZWxheU1zKTtcbiAgICAgICAgZWxzZSBydW4oKTtcbiAgICAgIH0sXG4gICAgICBvbk1lc3NhZ2UoaCkge1xuICAgICAgICBoYW5kbGVyID0gaDtcbiAgICAgIH0sXG4gICAgICByZXN0YXJ0KCkge1xuICAgICAgICByZXN0YXJ0cysrO1xuICAgICAgICB3b3JrZXIgPSBjcmVhdGVFbmdpbmVXb3JrZXIoKTtcbiAgICAgIH0sXG4gICAgICBkaXNwb3NlKCkge30sXG4gICAgfSxcbiAgICByZXN0YXJ0czogKCkgPT4gcmVzdGFydHMsXG4gICAgZXZhbFBvc3RzOiAoKSA9PiBldmFsUG9zdHMsXG4gIH07XG59XG5cbmRlc2NyaWJlKCdBc3luY0VuZ2luZScsICgpID0+IHtcbiAgaXQoJ2NvbXB1dGVzIHRoZSBzYW1lIHJlc3VsdHMgYXMgdGhlIHN5bmMgRW5naW5lIG92ZXIgdGhlIHdvcmtlcicsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhTT1VSQ0VTLCB7IHRyYW5zcG9ydDogaW5NZW1vcnlUcmFuc3BvcnQoKSB9KTtcbiAgICBjb25zdCBwYXNzID0gYXdhaXQgZW5naW5lLnJ1bihFWFRFUk5BTFMpO1xuXG4gICAgY29uc3Qgc3luYyA9IEVuZ2luZS5mcm9tU291cmNlcyhTT1VSQ0VTLCB7IC4uLnN0ZGxpYiB9KTtcbiAgICBzeW5jLnJ1bihFWFRFUk5BTFMpO1xuXG4gICAgZXhwZWN0KGVuZ2luZS52YWx1ZSgnc2hlZXQudG90YWwnKSkudG9CZSg2KTtcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdzaGVldC5zY2FsZWQnKSkudG9CZSgxMik7XG4gICAgZXhwZWN0KGVuZ2luZS52YWx1ZSgnc2hlZXQudG90YWwnKSkudG9CZShzeW5jLnZhbHVlKCdzaGVldC50b3RhbCcpKTtcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdzaGVldC5zY2FsZWQnKSkudG9CZShzeW5jLnZhbHVlKCdzaGVldC5zY2FsZWQnKSk7XG4gICAgZXhwZWN0KHBhc3MucmVzdWx0cy5nZXQoJ3NoZWV0LnNjYWxlZCcpPy50aWVyKS50b0JlKCdzdGF0aWMnKTtcbiAgICBleHBlY3QocGFzcy5lcnJvcnMuc2l6ZSkudG9CZSgwKTtcbiAgfSk7XG5cbiAgaXQoJ3Byb3BhZ2F0ZXMgYSB0aHJvd24gZm9ybXVsYSBhcyBhIGxhdHRpY2UgZXJyb3IgdG8gZGVwZW5kZW50cycsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzb3VyY2VzID0ge1xuICAgICAgc2hlZXQ6IGBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbmV4cG9ydCBjb25zdCBib29tID0gY2VsbCh7IGRvYzogXCJ0aHJvd3NcIiwgaW5wdXRzOiB7fSwgZm9ybXVsYTogKCkgPT4geyB0aHJvdyBuZXcgRXJyb3IoXCJrYWJvb21cIik7IH0gfSk7XG5leHBvcnQgY29uc3QgdXNlQm9vbSA9IGNlbGwoeyBkb2M6IFwidXNlcyBib29tXCIsIGlucHV0czogeyBiOiBcInNoZWV0LmJvb21cIiB9LCBmb3JtdWxhOiAoeyBiIH0pID0+IGIgfSk7XG5gLFxuICAgIH07XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoc291cmNlcywgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSk7XG4gICAgYXdhaXQgZW5naW5lLnJ1bih7fSk7XG4gICAgZXhwZWN0KGVuZ2luZS5lcnJvcignc2hlZXQuYm9vbScpKS50b01hdGNoKC9rYWJvb20vKTtcbiAgICBleHBlY3QoZW5naW5lLmVycm9yKCdzaGVldC51c2VCb29tJykpLnRvTWF0Y2goL2lucHV0IFwic2hlZXQuYm9vbVwiIGVycm9yZWQvKTtcbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdzaGVldC51c2VCb29tJykpLnRvQmVVbmRlZmluZWQoKTtcbiAgfSk7XG5cbiAgaXQoJ3JlcG9ydHMgYSBkZXBlbmRlbmN5IGN5Y2xlIGFzIGFuIGVycm9yIG9uIGV2ZXJ5IGNlbGwnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc291cmNlcyA9IHtcbiAgICAgIHM6IGBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbmV4cG9ydCBjb25zdCBhID0gY2VsbCh7IGRvYzogXCJhXCIsIGlucHV0czogeyBiOiBcInMuYlwiIH0sIGZvcm11bGE6ICh7IGIgfSkgPT4gYiB9KTtcbmV4cG9ydCBjb25zdCBiID0gY2VsbCh7IGRvYzogXCJiXCIsIGlucHV0czogeyBhOiBcInMuYVwiIH0sIGZvcm11bGE6ICh7IGEgfSkgPT4gYSB9KTtcbmAsXG4gICAgfTtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhzb3VyY2VzLCB7IHRyYW5zcG9ydDogaW5NZW1vcnlUcmFuc3BvcnQoKSB9KTtcbiAgICBjb25zdCBwYXNzID0gYXdhaXQgZW5naW5lLnJ1bih7fSk7XG4gICAgZXhwZWN0KHBhc3MuZXJyb3JzLmdldCgncy5hJykpLnRvTWF0Y2goL2N5Y2xlLyk7XG4gICAgZXhwZWN0KHBhc3MuZXJyb3JzLmdldCgncy5iJykpLnRvTWF0Y2goL2N5Y2xlLyk7XG4gIH0pO1xuXG4gIGl0KCd3YXRjaGRvZzogYSB3ZWRnZWQgY2VsbCB0aW1lcyBvdXQg4oaSIHRlcm1pbmF0ZSArIHJlYnVpbGQgKyBxdWFyYW50aW5lIOKGkiBkZXBlbmRlbnRzIGVycm9yJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGN0bCA9IG1ha2VUcmFuc3BvcnQoeyBzdHVjazogbmV3IFNldChbJ3NoZWV0LnRvdGFsJ10pIH0pO1xuICAgIGNvbnN0IGVuZ2luZSA9IGF3YWl0IEFzeW5jRW5naW5lLmZyb21Tb3VyY2VzKFNPVVJDRVMsIHtcbiAgICAgIHRyYW5zcG9ydDogY3RsLnRyYW5zcG9ydCxcbiAgICAgIGV2YWxCdWRnZXRNczogMTUsXG4gICAgICBicmVha2VyOiB7IGhhcmRMaW1pdDogMSwgd2luZG93TXM6IDEwMDAsIHNvZnRTdXBwcmVzc01zOiAxMDAgfSxcbiAgICB9KTtcbiAgICBjb25zdCBwYXNzID0gYXdhaXQgZW5naW5lLnJ1bihFWFRFUk5BTFMpO1xuXG4gICAgZXhwZWN0KGN0bC5yZXN0YXJ0cygpKS50b0JlKDEpOyAvLyB0aGUgd2VkZ2VkIHdvcmtlciB3YXMgdGVybWluYXRlZCArIHJlYnVpbHRcbiAgICBleHBlY3QoZW5naW5lLmVycm9yKCdzaGVldC50b3RhbCcpKS50b01hdGNoKC90aW1lZCBvdXQvKTtcbiAgICBleHBlY3QocGFzcy5xdWFyYW50aW5lZCkudG9Db250YWluKCdzaGVldC50b3RhbCcpO1xuICAgIGV4cGVjdChlbmdpbmUuZXJyb3IoJ3NoZWV0LnNjYWxlZCcpKS50b01hdGNoKC9lcnJvcmVkLyk7IC8vIGRlcGVuZGVudCBnZXRzIHRoZSBsYXR0aWNlIGVycm9yXG5cbiAgICAvLyBSZS1hcm0gY2xlYXJzIHRoZSBxdWFyYW50aW5lOyBhIGZyZXNoIHdvcmtlciAobm90aGluZyB3ZWRnZWQpIHNldHRsZXMgbm9ybWFsbHkg4oCUIHByb3ZpbmdcbiAgICAvLyB0aGUgZW5naW5lIHJlY292ZXJzIHJhdGhlciB0aGFuIHN0YXlpbmcgcGVybWFuZW50bHkgYnJva2VuLlxuICAgIGVuZ2luZS5yZWFybSgnc2hlZXQudG90YWwnKTtcbiAgICBjb25zdCBlbmdpbmUyID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoU09VUkNFUywgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSk7XG4gICAgYXdhaXQgZW5naW5lMi5ydW4oRVhURVJOQUxTKTtcbiAgICBleHBlY3QoZW5naW5lMi52YWx1ZSgnc2hlZXQudG90YWwnKSkudG9CZSg2KTtcbiAgfSk7XG5cbiAgaXQoJ3NpbmdsZS1zbG90IHN1cGVyc2Vzc2lvbjogb3ZlcmxhcHBpbmcgdXBkYXRlcyBjb2FsZXNjZSBpbnRvIG9uZSBmb2xsb3ctdXAgcGFzcycsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBjdGwgPSBtYWtlVHJhbnNwb3J0KHsgZXZhbERlbGF5TXM6IDEwIH0pO1xuICAgIGNvbnN0IGVuZ2luZSA9IGF3YWl0IEFzeW5jRW5naW5lLmZyb21Tb3VyY2VzKFNPVVJDRVMsIHsgdHJhbnNwb3J0OiBjdGwudHJhbnNwb3J0IH0pO1xuXG4gICAgY29uc3QgcDEgPSBlbmdpbmUucnVuKEVYVEVSTkFMUyk7IC8vIHBhc3MgMSBpbiBmbGlnaHQgKGRlbGF5ZWQpXG4gICAgZW5naW5lLnVwZGF0ZSh7ICdwYXJhbXMuayc6IHsgdmFsdWU6IDUsIHRpZXI6ICdzdGF0aWMnIH0gfSk7IC8vIHN1cGVyc2VkZWQgYmVmb3JlIGl0IHJ1bnNcbiAgICBjb25zdCBwMyA9IGVuZ2luZS51cGRhdGUoeyAncGFyYW1zLmsnOiB7IHZhbHVlOiA3LCB0aWVyOiAnc3RhdGljJyB9IH0pOyAvLyB0aGUgc3Vydml2b3JcbiAgICBhd2FpdCBQcm9taXNlLmFsbChbcDEsIHAzXSk7XG5cbiAgICBleHBlY3QoZW5naW5lLnZhbHVlKCdzaGVldC5zY2FsZWQnKSkudG9CZSg0Mik7IC8vIDYgKiA3IChsYXN0IHVwZGF0ZSB3b24pXG4gICAgLy8gVHdvIHBhc3NlcyBvbmx5IChpbml0aWFsICsgb25lIGNvYWxlc2NlZCksIDIgY2VsbHMgZWFjaCDihpIgNCBldmFsIHBvc3RzLCBub3QgNi5cbiAgICBleHBlY3QoY3RsLmV2YWxQb3N0cygpKS50b0JlKDQpO1xuICB9KTtcblxuICBpdCgnYXdhaXRzIGFuIGFzeW5jIGZvcm11bGEgKGEgZm9ybXVsYSBtYXkgcmV0dXJuIGEgcHJvbWlzZSknLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc291cmNlcyA9IHtcbiAgICAgIHNoZWV0OiBgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5leHBvcnQgY29uc3QgYSA9IGNlbGwoeyBkb2M6IFwiYXN5bmNcIiwgaW5wdXRzOiB7IHg6IFwicGFyYW1zLnhcIiB9LCBmb3JtdWxhOiBhc3luYyAoeyB4IH0pID0+IHggKyAxMDAgfSk7XG5gLFxuICAgIH07XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoc291cmNlcywgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSk7XG4gICAgYXdhaXQgZW5naW5lLnJ1bih7ICdwYXJhbXMueCc6IHsgdmFsdWU6IDUsIHRpZXI6ICdzdGF0aWMnIH0gfSk7XG4gICAgZXhwZWN0KGVuZ2luZS52YWx1ZSgnc2hlZXQuYScpKS50b0JlKDEwNSk7IC8vIGF3YWl0ZWQsIG5vdCBhIFByb21pc2VcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ0FzeW5jRW5naW5lLnJ1blRlc3RzIOKAlCB0aGUgcmV2aWV3IHN1cmZhY2Ugb3ZlciB0aGUgcmVhbCB0cmFuc3BvcnQnLCAoKSA9PiB7XG4gIGNvbnN0IFNPVVJDRVMgPSB7XG4gICAgbGl2ZTogYGltcG9ydCB7IGNlbGwsIHRlc3RDZWxsLCBleHBlY3RFcXVhbCwgcHJvcGVydHkgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuZXhwb3J0IGNvbnN0IHRvdGFsID0gY2VsbCh7IGRvYzogXCJzdW1cIiwgaW5wdXRzOiB7IHJvd3M6IFwiZmVlZHMub3JkZXJzXCIgfSwgZm9ybXVsYTogKHsgcm93cyB9KSA9PiByb3dzLnJlZHVjZSgoYSwgcikgPT4gYSArIHIuZXVyLCAwKSB9KTtcbmV4cG9ydCBjb25zdCB0b3RhbF9jaGVjayA9IHRlc3RDZWxsKHsga2luZDogXCJzcGVjaWZpY2F0aW9uXCIsIHN1YmplY3Q6IFwibGl2ZS50b3RhbFwiLCBleHBlY3Q6ICh7IHJlc3VsdCB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIDMwKSB9KTtcbmV4cG9ydCBjb25zdCB0b3RhbF9zYW5lID0gdGVzdENlbGwoeyBraW5kOiBcInByb3BlcnR5XCIsIHN1YmplY3Q6IFwibGl2ZS50b3RhbFwiLCByZWxhdGlvbjogcHJvcGVydHkoXCJub24tbmVnYXRpdmVcIiwgKHIpID0+IHIgPj0gMCkgfSk7XG5leHBvcnQgY29uc3QgdW50b3VjaGVkID0gY2VsbCh7IGRvYzogXCJubyB0ZXN0c1wiLCBpbnB1dHM6IHsgdDogXCJsaXZlLnRvdGFsXCIgfSwgZm9ybXVsYTogKHsgdCB9KSA9PiB0ICsgMSB9KTtcbmAsXG4gIH07XG5cbiAgaXQoJ3J1bnMgc3VpdGVzIHdvcmtlci1zaWRlIGFuZCByZXR1cm5zIHBlci1zdWJqZWN0IHZlcmRpY3RzIChleGFtcGxlK3Byb3BlcnR5IOKGkiB2YWxpZGF0ZWQpJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGVuZ2luZSA9IGF3YWl0IEFzeW5jRW5naW5lLmZyb21Tb3VyY2VzKFNPVVJDRVMsIHsgdHJhbnNwb3J0OiBpbk1lbW9yeVRyYW5zcG9ydCgpIH0pO1xuICAgIGF3YWl0IGVuZ2luZS5ydW4oeyAnZmVlZHMub3JkZXJzJzogeyB2YWx1ZTogW3sgZXVyOiAxMCB9LCB7IGV1cjogMjAgfV0sIHRpZXI6ICdsaXZlJyB9IH0pO1xuICAgIGNvbnN0IHZlcmRpY3RzID0gYXdhaXQgZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgZXhwZWN0KHZlcmRpY3RzLmdldCgnbGl2ZS50b3RhbCcpPy52ZXJkaWN0KS50b0JlKCd2YWxpZGF0ZWQnKTtcbiAgICAvLyBjZWxscyB3aXRob3V0IHRlc3RzIGFyZSBhYnNlbnQg4oCUIHRoZSBwYW5lbCByZW5kZXJzIHRoZW0gYHVudGVzdGVkYFxuICAgIGV4cGVjdCh2ZXJkaWN0cy5oYXMoJ2xpdmUudW50b3VjaGVkJykpLnRvQmUoZmFsc2UpO1xuICAgIGNvbnN0IGNoZWNrID0gdmVyZGljdHMuZ2V0KCdsaXZlLnRvdGFsJykhLm91dGNvbWVzLmZpbmQoKG8pID0+IG8uaWQgPT09ICdsaXZlLnRvdGFsX2NoZWNrJykhO1xuICAgIGV4cGVjdChjaGVjay5raW5kKS50b0JlKCdzcGVjaWZpY2F0aW9uJyk7XG4gICAgZXhwZWN0KGNoZWNrLnBhc3MpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCdhIGJyb2tlbiBleHBlY3RhdGlvbiBmYWlscyB0aGUgc3VpdGUgYW5kIHRoZSB2ZXJkaWN0IHJlYWRzIGZhaWxpbmcnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgQXN5bmNFbmdpbmUuZnJvbVNvdXJjZXMoU09VUkNFUywgeyB0cmFuc3BvcnQ6IGluTWVtb3J5VHJhbnNwb3J0KCkgfSk7XG4gICAgYXdhaXQgZW5naW5lLnJ1bih7ICdmZWVkcy5vcmRlcnMnOiB7IHZhbHVlOiBbeyBldXI6IDEgfV0sIHRpZXI6ICdsaXZlJyB9IH0pO1xuICAgIGNvbnN0IHZlcmRpY3RzID0gYXdhaXQgZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgZXhwZWN0KHZlcmRpY3RzLmdldCgnbGl2ZS50b3RhbCcpPy52ZXJkaWN0KS50b0JlKCdmYWlsaW5nJyk7XG4gIH0pO1xuXG4gIGl0KCdhIHdlZGdlZCBzdWl0ZSB0aW1lcyBvdXQsIHJlc3RhcnRzIHRoZSB3b3JrZXIsIGFuZCByZWplY3RzIOKAlCB0aGUgcmVuZGVyIHBhdGggcmVjb3ZlcnMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgYmFzZSA9IGluTWVtb3J5VHJhbnNwb3J0KCk7XG4gICAgbGV0IHdpdGhob2xkVGVzdHMgPSBmYWxzZTtcbiAgICBjb25zdCB3aXRoaG9sZGluZzogdHlwZW9mIGJhc2UgPSB7XG4gICAgICBwb3N0KG1zZykge1xuICAgICAgICBpZiAobXNnLnR5cGUgPT09ICdydW4tdGVzdHMnICYmIHdpdGhob2xkVGVzdHMpIHJldHVybjsgLy8gdGhlIHdlZGdlZC13b3JrZXIgc2hhcGVcbiAgICAgICAgYmFzZS5wb3N0KG1zZyk7XG4gICAgICB9LFxuICAgICAgb25NZXNzYWdlKGgpIHtcbiAgICAgICAgYmFzZS5vbk1lc3NhZ2UoaCk7XG4gICAgICB9LFxuICAgICAgcmVzdGFydCgpIHtcbiAgICAgICAgd2l0aGhvbGRUZXN0cyA9IGZhbHNlO1xuICAgICAgICBiYXNlLnJlc3RhcnQoKTtcbiAgICAgIH0sXG4gICAgICBkaXNwb3NlKCkge1xuICAgICAgICBiYXNlLmRpc3Bvc2UoKTtcbiAgICAgIH0sXG4gICAgfTtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhTT1VSQ0VTLCB7XG4gICAgICB0cmFuc3BvcnQ6IHdpdGhob2xkaW5nLFxuICAgICAgZXZhbEJ1ZGdldE1zOiAyMCxcbiAgICB9KTtcbiAgICBhd2FpdCBlbmdpbmUucnVuKHsgJ2ZlZWRzLm9yZGVycyc6IHsgdmFsdWU6IFt7IGV1cjogMTAgfV0sIHRpZXI6ICdsaXZlJyB9IH0pO1xuICAgIHdpdGhob2xkVGVzdHMgPSB0cnVlO1xuICAgIGF3YWl0IGV4cGVjdChlbmdpbmUucnVuVGVzdHMoKSkucmVqZWN0cy50b1Rocm93KC90aW1lZCBvdXQvKTtcbiAgICAvLyB0aGUgd29ya2VyIHdhcyByZXN0YXJ0ZWQgYW5kIHJlYnVpbHQg4oCUIHRoZSByZW5kZXIgcGlwZWxpbmUgc3RpbGwgZXZhbHVhdGVzXG4gICAgYXdhaXQgZW5naW5lLnJ1bih7ICdmZWVkcy5vcmRlcnMnOiB7IHZhbHVlOiBbeyBldXI6IDUgfV0sIHRpZXI6ICdsaXZlJyB9IH0pO1xuICAgIGV4cGVjdChlbmdpbmUudmFsdWUoJ2xpdmUudG90YWwnKSkudG9CZSg1KTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ0FzeW5jRW5naW5lLnJ1blRlc3RzIOKAlCBkZWNsYXJlZCB0ZXN0IGlucHV0cyAoUjMtMzczKScsICgpID0+IHtcbiAgY29uc3QgU1JDID0ge1xuICAgIHNoZWV0OiBgaW1wb3J0IHsgY2VsbCwgdGVzdENlbGwsIGV4cGVjdENsb3NlIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbmV4cG9ydCBjb25zdCB0b3RhbCA9IGNlbGwoeyBkb2M6IFwic3VtXCIsIGlucHV0czogeyByb3dzOiBcImZpeHR1cmVzLmRhdGFcIiwgazogXCJwYXJhbXMua1wiIH0sIGZvcm11bGE6ICh7IHJvd3MsIGsgfSkgPT4gcm93cy5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLnYsIDApICogayB9KTtcbmV4cG9ydCBjb25zdCBob2xkb3V0ID0gdGVzdENlbGwoeyBraW5kOiBcInNwZWNpZmljYXRpb25cIiwgc3ViamVjdDogXCJzaGVldC50b3RhbFwiLCBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5kYXRhX2hvbGRvdXRcIiwgb3JhY2xlOiBcImZpeHR1cmVzLm9yYWNsZVwiIH0sIGV4cGVjdDogKHsgcmVzdWx0LCBpbnB1dHMgfSkgPT4gZXhwZWN0Q2xvc2UocmVzdWx0LCBpbnB1dHMub3JhY2xlWzBdLmV4cGVjdGVkLCB7IGFiczogMWUtOSB9KSB9KTtcbmV4cG9ydCBjb25zdCBiYWRfcmVmID0gdGVzdENlbGwoeyBraW5kOiBcInNwZWNpZmljYXRpb25cIiwgc3ViamVjdDogXCJzaGVldC50b3RhbFwiLCBpbnB1dHM6IHsgZ2hvc3Q6IFwiZml4dHVyZXMubm9fc3VjaF9maXh0dXJlXCIgfSwgZXhwZWN0OiAoKSA9PiAoeyBwYXNzOiB0cnVlLCBtZXNzYWdlOiBcInVucmVhY2hlZFwiIH0pIH0pO1xuZXhwb3J0IGNvbnN0IGxpdmVfY2hlY2sgPSB0ZXN0Q2VsbCh7IGtpbmQ6IFwic3BlY2lmaWNhdGlvblwiLCBzdWJqZWN0OiBcInNoZWV0LnRvdGFsXCIsIGV4cGVjdDogKHsgcmVzdWx0IH0pID0+IGV4cGVjdENsb3NlKHJlc3VsdCwgMTIsIHsgYWJzOiAxZS05IH0pIH0pO1xuYCxcbiAgfTtcblxuICBhc3luYyBmdW5jdGlvbiBidWlsdCgpIHtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBBc3luY0VuZ2luZS5mcm9tU291cmNlcyhTUkMsIHsgdHJhbnNwb3J0OiBpbk1lbW9yeVRyYW5zcG9ydCgpIH0pO1xuICAgIGF3YWl0IGVuZ2luZS5ydW4oe1xuICAgICAgJ2ZpeHR1cmVzLmRhdGEnOiB7IHZhbHVlOiBbeyB2OiAxIH0sIHsgdjogMiB9LCB7IHY6IDMgfV0sIHRpZXI6ICdzdGF0aWMnIH0sXG4gICAgICAnZml4dHVyZXMuZGF0YV9ob2xkb3V0JzogeyB2YWx1ZTogW3sgdjogMTAgfSwgeyB2OiA1IH1dLCB0aWVyOiAnc3RhdGljJyB9LFxuICAgICAgJ2ZpeHR1cmVzLm9yYWNsZSc6IHsgdmFsdWU6IFt7IGV4cGVjdGVkOiAzMCB9XSwgdGllcjogJ3N0YXRpYycgfSxcbiAgICAgICdwYXJhbXMuayc6IHsgdmFsdWU6IDIsIHRpZXI6ICdzdGF0aWMnIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIGVuZ2luZTtcbiAgfVxuXG4gIGl0KCduYW1lLW1hdGNoZWQgaW5wdXRzIHN1YnN0aXR1dGUgYW5kIHJlLXJ1biB0aGUgc3ViamVjdDsgbmFtZS11bm1hdGNoZWQgYXJlIGF1eGlsaWFyeScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBidWlsdCgpO1xuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBlbmdpbmUucnVuVGVzdHMoKTtcbiAgICAvLyBob2xkb3V0OiByb3dzIOKGkiBbMTAsIDVdIHN1YnN0aXR1dGVkLCBwYXJhbXMuayBzdGF5cyBsaXZlICgyKSDihpIgKDEwKzUpKjIgPSAzMCwgYW5kIHRoZVxuICAgIC8vIG9yYWNsZSBhcnJpdmVzIGFzIGF1eGlsaWFyeSBjb250ZXh0IOKAlCB0aGUgcGFzcyBwcm92ZXMgYm90aCBsYW5lcyBhcmUgd2lyZWQuXG4gICAgY29uc3QgaG9sZG91dCA9IHJlc3VsdHMuZ2V0KCdzaGVldC50b3RhbCcpPy5vdXRjb21lcy5maW5kKChvKSA9PiBvLmlkID09PSAnc2hlZXQuaG9sZG91dCcpO1xuICAgIGV4cGVjdChob2xkb3V0Py5wYXNzKS50b0JlKHRydWUpO1xuICB9KTtcblxuICBpdCgnYW4gdW5yZXNvbHZhYmxlIHRlc3QtaW5wdXQgcmVmZXJlbmNlIGZhaWxzIHRoYXQgdGVzdCB3aXRoIGEgbWVzc2FnZSwgbmV2ZXIgc2lsZW50IG51bGwnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZW5naW5lID0gYXdhaXQgYnVpbHQoKTtcbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgZW5naW5lLnJ1blRlc3RzKCk7XG4gICAgY29uc3QgYmFkID0gcmVzdWx0cy5nZXQoJ3NoZWV0LnRvdGFsJyk/Lm91dGNvbWVzLmZpbmQoKG8pID0+IG8uaWQgPT09ICdzaGVldC5iYWRfcmVmJyk7XG4gICAgZXhwZWN0KGJhZD8ucGFzcykudG9CZShmYWxzZSk7XG4gICAgZXhwZWN0KGJhZD8ubWVzc2FnZSkudG9Db250YWluKCdmaXh0dXJlcy5ub19zdWNoX2ZpeHR1cmUnKTtcbiAgfSk7XG5cbiAgaXQoJ2EgdGVzdCB3aXRoIG5vIGRlY2xhcmVkIGlucHV0cyBzdGlsbCBhc3NlcnRzIHRoZSBsaXZlIHZhbHVlJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGVuZ2luZSA9IGF3YWl0IGJ1aWx0KCk7XG4gICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGVuZ2luZS5ydW5UZXN0cygpO1xuICAgIGNvbnN0IGxpdmUgPSByZXN1bHRzLmdldCgnc2hlZXQudG90YWwnKT8ub3V0Y29tZXMuZmluZCgobykgPT4gby5pZCA9PT0gJ3NoZWV0LmxpdmVfY2hlY2snKTtcbiAgICBleHBlY3QobGl2ZT8ucGFzcykudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBzeW5jIEVuZ2luZSBhZ3JlZXMgd2l0aCB0aGUgYXN5bmMgcGF0aCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBhd2FpdCBidWlsdCgpO1xuICAgIGNvbnN0IGFzeW5jUmVzdWx0cyA9IGF3YWl0IGVuZ2luZS5ydW5UZXN0cygpO1xuICAgIGNvbnN0IHN5bmMgPSBFbmdpbmUuZnJvbVNvdXJjZXMoU1JDLCB7IC4uLnN0ZGxpYiB9KTtcbiAgICBzeW5jLnJ1bih7XG4gICAgICAnZml4dHVyZXMuZGF0YSc6IHsgdmFsdWU6IFt7IHY6IDEgfSwgeyB2OiAyIH0sIHsgdjogMyB9XSwgdGllcjogJ3N0YXRpYycgfSxcbiAgICAgICdmaXh0dXJlcy5kYXRhX2hvbGRvdXQnOiB7IHZhbHVlOiBbeyB2OiAxMCB9LCB7IHY6IDUgfV0sIHRpZXI6ICdzdGF0aWMnIH0sXG4gICAgICAnZml4dHVyZXMub3JhY2xlJzogeyB2YWx1ZTogW3sgZXhwZWN0ZWQ6IDMwIH1dLCB0aWVyOiAnc3RhdGljJyB9LFxuICAgICAgJ3BhcmFtcy5rJzogeyB2YWx1ZTogMiwgdGllcjogJ3N0YXRpYycgfSxcbiAgICB9KTtcbiAgICAvLyBTdWl0ZSBvdXRjb21lcyBjYXJyeSBubyBpZHMgaW4gdGhlIHN5bmMgcGF0aCDigJQgY29tcGFyZSBwYXNzL2ZhaWwgYnkgZGVjbGFyYXRpb24gb3JkZXIuXG4gICAgZm9yIChjb25zdCBbc3ViamVjdCwgc3VpdGVdIG9mIHN5bmMucnVuVGVzdHMoKSkge1xuICAgICAgY29uc3QgYXN5bmNPdXRjb21lcyA9IGFzeW5jUmVzdWx0cy5nZXQoc3ViamVjdCkhLm91dGNvbWVzO1xuICAgICAgY29uc3QgcGFzc2VzID0gc3VpdGUub3V0Y29tZXMubWFwKChvKSA9PiBvLnJlc3VsdC5wYXNzKTtcbiAgICAgIGNvbnN0IGFzeW5jUGFzc2VzID0gYXN5bmNPdXRjb21lcy5tYXAoKG8pID0+IG8ucGFzcyk7XG4gICAgICBleHBlY3QoYXN5bmNQYXNzZXMsIHN1YmplY3QpLnRvRXF1YWwocGFzc2VzKTtcbiAgICAgIC8vIGhvbGRvdXQgKyBsaXZlX2NoZWNrIGdyZWVuLCBiYWRfcmVmIGZhaWxpbmcgbG91ZGx5IOKAlCBpbiBCT1RIIGVuZ2luZXMuXG4gICAgICBleHBlY3QocGFzc2VzLCBzdWJqZWN0KS50b0VxdWFsKFt0cnVlLCBmYWxzZSwgdHJ1ZV0pO1xuICAgIH1cbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxnQkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksYUFBQSxHQUFBSixPQUFBO0FBSUEsSUFBQUssTUFBQSxHQUFBQyx1QkFBQSxDQUFBTixPQUFBO0FBQTZDLFNBQUFPLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFGLHdCQUFBRSxDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUksVUFBQSxTQUFBSixDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQUssT0FBQSxFQUFBTCxDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUcsR0FBQSxDQUFBTixDQUFBLFVBQUFHLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLE9BQUFRLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWQsQ0FBQSxvQkFBQWMsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWhCLENBQUEsRUFBQWMsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBYixDQUFBLEVBQUFjLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWQsQ0FBQSxDQUFBYyxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTCxDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZSxHQUFBLENBQUFsQixDQUFBLEVBQUFRLENBQUEsR0FBQUEsQ0FBQTtBQUU3QyxNQUFNVyxPQUFPLEdBQUc7RUFDZEMsS0FBSyxFQUFFO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELE1BQU1DLFNBQXdDLEdBQUc7RUFDL0MsZUFBZSxFQUFFO0lBQUVDLEtBQUssRUFBRSxDQUFDO01BQUVDLENBQUMsRUFBRTtJQUFFLENBQUMsRUFBRTtNQUFFQSxDQUFDLEVBQUU7SUFBRSxDQUFDLEVBQUU7TUFBRUEsQ0FBQyxFQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQUVDLElBQUksRUFBRTtFQUFTLENBQUM7RUFDMUUsVUFBVSxFQUFFO0lBQUVGLEtBQUssRUFBRSxDQUFDO0lBQUVFLElBQUksRUFBRTtFQUFTO0FBQ3pDLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsYUFBYUEsQ0FBQ0MsSUFBbUQsR0FBRyxDQUFDLENBQUMsRUFJN0U7RUFDQSxJQUFJQyxNQUFNLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztFQUNqQyxJQUFJQyxPQUFvQyxHQUFHQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0VBQ25ELElBQUlDLFFBQVEsR0FBRyxDQUFDO0VBQ2hCLElBQUlDLFNBQVMsR0FBRyxDQUFDO0VBQ2pCLE9BQU87SUFDTEMsU0FBUyxFQUFFO01BQ1RDLElBQUlBLENBQUNDLEdBQUcsRUFBRTtRQUNSLElBQUlBLEdBQUcsQ0FBQ0MsSUFBSSxLQUFLLE9BQU8sRUFBRTtVQUN4QixJQUFJO1lBQ0ZOLE9BQU8sQ0FBQztjQUFFTSxJQUFJLEVBQUUsT0FBTztjQUFFQyxVQUFVLEVBQUVULE1BQU0sQ0FBQ1UsS0FBSyxDQUFDSCxHQUFHLENBQUNJLE9BQU87WUFBRSxDQUFDLENBQUM7VUFDbkUsQ0FBQyxDQUFDLE9BQU90QyxDQUFDLEVBQUU7WUFDVjZCLE9BQU8sQ0FBQztjQUFFTSxJQUFJLEVBQUUsYUFBYTtjQUFFSSxPQUFPLEVBQUd2QyxDQUFDLENBQVd1QztZQUFRLENBQUMsQ0FBQztVQUNqRTtVQUNBO1FBQ0Y7UUFDQSxJQUFJTCxHQUFHLENBQUNDLElBQUksS0FBSyxXQUFXLEVBQUU7VUFDNUIsSUFBSTtZQUNGTixPQUFPLENBQUM7Y0FBRU0sSUFBSSxFQUFFLGNBQWM7Y0FBRUssS0FBSyxFQUFFTixHQUFHLENBQUNNLEtBQUs7Y0FBRUMsTUFBTSxFQUFFZCxNQUFNLENBQUNlLFNBQVMsQ0FBQ1IsR0FBRyxDQUFDTyxNQUFNO1lBQUUsQ0FBQyxDQUFDO1VBQzNGLENBQUMsQ0FBQyxPQUFPekMsQ0FBQyxFQUFFO1lBQ1Y2QixPQUFPLENBQUM7Y0FBRU0sSUFBSSxFQUFFLFlBQVk7Y0FBRUssS0FBSyxFQUFFTixHQUFHLENBQUNNLEtBQUs7Y0FBRUcsRUFBRSxFQUFFLGFBQWE7Y0FBRUosT0FBTyxFQUFHdkMsQ0FBQyxDQUFXdUM7WUFBUSxDQUFDLENBQUM7VUFDckc7VUFDQTtRQUNGO1FBQ0FSLFNBQVMsRUFBRTtRQUNYLElBQUlMLElBQUksQ0FBQ2tCLEtBQUssRUFBRXRDLEdBQUcsQ0FBQzRCLEdBQUcsQ0FBQ1MsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDO1FBQ3JDLE1BQU1FLEdBQUcsR0FBR0EsQ0FBQSxLQUFZO1VBQ3RCQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQ2RDLElBQUksQ0FBQyxNQUFNckIsTUFBTSxDQUFDc0IsSUFBSSxDQUFDZixHQUFHLENBQUNTLEVBQUUsRUFBRVQsR0FBRyxDQUFDZ0IsTUFBTSxDQUFDLENBQUMsQ0FDM0NGLElBQUksQ0FBRTFCLEtBQUssSUFBS08sT0FBTyxDQUFDO1lBQUVNLElBQUksRUFBRSxRQUFRO1lBQUVLLEtBQUssRUFBRU4sR0FBRyxDQUFDTSxLQUFLO1lBQUVHLEVBQUUsRUFBRVQsR0FBRyxDQUFDUyxFQUFFO1lBQUVyQjtVQUFNLENBQUMsQ0FBQyxDQUFDLENBQ2pGNkIsS0FBSyxDQUFFbkQsQ0FBQyxJQUFLNkIsT0FBTyxDQUFDO1lBQUVNLElBQUksRUFBRSxZQUFZO1lBQUVLLEtBQUssRUFBRU4sR0FBRyxDQUFDTSxLQUFLO1lBQUVHLEVBQUUsRUFBRVQsR0FBRyxDQUFDUyxFQUFFO1lBQUVKLE9BQU8sRUFBR3ZDLENBQUMsQ0FBV3VDO1VBQVEsQ0FBQyxDQUFDLENBQUM7UUFDL0csQ0FBQztRQUNELElBQUliLElBQUksQ0FBQzBCLFdBQVcsRUFBRUMsVUFBVSxDQUFDUixHQUFHLEVBQUVuQixJQUFJLENBQUMwQixXQUFXLENBQUMsQ0FBQyxLQUNuRFAsR0FBRyxDQUFDLENBQUM7TUFDWixDQUFDO01BQ0RTLFNBQVNBLENBQUNDLENBQUMsRUFBRTtRQUNYMUIsT0FBTyxHQUFHMEIsQ0FBQztNQUNiLENBQUM7TUFDREMsT0FBT0EsQ0FBQSxFQUFHO1FBQ1IxQixRQUFRLEVBQUU7UUFDVkgsTUFBTSxHQUFHLElBQUFDLGdDQUFrQixFQUFDLENBQUM7TUFDL0IsQ0FBQztNQUNENkIsT0FBT0EsQ0FBQSxFQUFHLENBQUM7SUFDYixDQUFDO0lBQ0QzQixRQUFRLEVBQUVBLENBQUEsS0FBTUEsUUFBUTtJQUN4QkMsU0FBUyxFQUFFQSxDQUFBLEtBQU1BO0VBQ25CLENBQUM7QUFDSDtBQUVBLElBQUEyQixnQkFBUSxFQUFDLGFBQWEsRUFBRSxNQUFNO0VBQzVCLElBQUFDLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxZQUFZO0lBQzdFLE1BQU1DLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQUMzQyxPQUFPLEVBQUU7TUFBRWEsU0FBUyxFQUFFLElBQUErQixrQ0FBaUIsRUFBQztJQUFFLENBQUMsQ0FBQztJQUN6RixNQUFNQyxJQUFJLEdBQUcsTUFBTUosTUFBTSxDQUFDZixHQUFHLENBQUN4QixTQUFTLENBQUM7SUFFeEMsTUFBTTRDLElBQUksR0FBR0MsY0FBTSxDQUFDSixXQUFXLENBQUMzQyxPQUFPLEVBQUU7TUFBRSxHQUFHdEI7SUFBTyxDQUFDLENBQUM7SUFDdkRvRSxJQUFJLENBQUNwQixHQUFHLENBQUN4QixTQUFTLENBQUM7SUFFbkIsSUFBQThDLGNBQU0sRUFBQ1AsTUFBTSxDQUFDdEMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM4QyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzNDLElBQUFELGNBQU0sRUFBQ1AsTUFBTSxDQUFDdEMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM4QyxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQzdDLElBQUFELGNBQU0sRUFBQ1AsTUFBTSxDQUFDdEMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM4QyxJQUFJLENBQUNILElBQUksQ0FBQzNDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNuRSxJQUFBNkMsY0FBTSxFQUFDUCxNQUFNLENBQUN0QyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQzhDLElBQUksQ0FBQ0gsSUFBSSxDQUFDM0MsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3JFLElBQUE2QyxjQUFNLEVBQUNILElBQUksQ0FBQ0ssT0FBTyxDQUFDOUQsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFFaUIsSUFBSSxDQUFDLENBQUM0QyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQzdELElBQUFELGNBQU0sRUFBQ0gsSUFBSSxDQUFDTSxNQUFNLENBQUNDLElBQUksQ0FBQyxDQUFDSCxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2xDLENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQyw4REFBOEQsRUFBRSxZQUFZO0lBQzdFLE1BQU1yQixPQUFPLEdBQUc7TUFDZGxCLEtBQUssRUFBRTtBQUNiO0FBQ0E7QUFDQTtJQUNJLENBQUM7SUFDRCxNQUFNd0MsTUFBTSxHQUFHLE1BQU1DLHdCQUFXLENBQUNDLFdBQVcsQ0FBQ3hCLE9BQU8sRUFBRTtNQUFFTixTQUFTLEVBQUUsSUFBQStCLGtDQUFpQixFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pGLE1BQU1ILE1BQU0sQ0FBQ2YsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BCLElBQUFzQixjQUFNLEVBQUNQLE1BQU0sQ0FBQ1ksS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDcEQsSUFBQU4sY0FBTSxFQUFDUCxNQUFNLENBQUNZLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsNEJBQTRCLENBQUM7SUFDM0UsSUFBQU4sY0FBTSxFQUFDUCxNQUFNLENBQUN0QyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ29ELGFBQWEsQ0FBQyxDQUFDO0VBQ3ZELENBQUMsQ0FBQztFQUVGLElBQUFmLFVBQUUsRUFBQyxzREFBc0QsRUFBRSxZQUFZO0lBQ3JFLE1BQU1yQixPQUFPLEdBQUc7TUFDZHFDLENBQUMsRUFBRTtBQUNUO0FBQ0E7QUFDQTtJQUNJLENBQUM7SUFDRCxNQUFNZixNQUFNLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsV0FBVyxDQUFDeEIsT0FBTyxFQUFFO01BQUVOLFNBQVMsRUFBRSxJQUFBK0Isa0NBQWlCLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFDekYsTUFBTUMsSUFBSSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ2YsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pDLElBQUFzQixjQUFNLEVBQUNILElBQUksQ0FBQ00sTUFBTSxDQUFDL0QsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUNrRSxPQUFPLENBQUMsT0FBTyxDQUFDO0lBQy9DLElBQUFOLGNBQU0sRUFBQ0gsSUFBSSxDQUFDTSxNQUFNLENBQUMvRCxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQ2tFLE9BQU8sQ0FBQyxPQUFPLENBQUM7RUFDakQsQ0FBQyxDQUFDO0VBRUYsSUFBQWQsVUFBRSxFQUFDLHlGQUF5RixFQUFFLFlBQVk7SUFDeEcsTUFBTWlCLEdBQUcsR0FBR25ELGFBQWEsQ0FBQztNQUFFbUIsS0FBSyxFQUFFLElBQUlpQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDOUQsTUFBTWpCLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQUMzQyxPQUFPLEVBQUU7TUFDcERhLFNBQVMsRUFBRTRDLEdBQUcsQ0FBQzVDLFNBQVM7TUFDeEI4QyxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsT0FBTyxFQUFFO1FBQUVDLFNBQVMsRUFBRSxDQUFDO1FBQUVDLFFBQVEsRUFBRSxJQUFJO1FBQUVDLGNBQWMsRUFBRTtNQUFJO0lBQy9ELENBQUMsQ0FBQztJQUNGLE1BQU1sQixJQUFJLEdBQUcsTUFBTUosTUFBTSxDQUFDZixHQUFHLENBQUN4QixTQUFTLENBQUM7SUFFeEMsSUFBQThDLGNBQU0sRUFBQ1MsR0FBRyxDQUFDOUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDc0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDaEMsSUFBQUQsY0FBTSxFQUFDUCxNQUFNLENBQUNZLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsV0FBVyxDQUFDO0lBQ3hELElBQUFOLGNBQU0sRUFBQ0gsSUFBSSxDQUFDbUIsV0FBVyxDQUFDLENBQUNDLFNBQVMsQ0FBQyxhQUFhLENBQUM7SUFDakQsSUFBQWpCLGNBQU0sRUFBQ1AsTUFBTSxDQUFDWSxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7O0lBRXpEO0lBQ0E7SUFDQWIsTUFBTSxDQUFDeUIsS0FBSyxDQUFDLGFBQWEsQ0FBQztJQUMzQixNQUFNQyxPQUFPLEdBQUcsTUFBTXpCLHdCQUFXLENBQUNDLFdBQVcsQ0FBQzNDLE9BQU8sRUFBRTtNQUFFYSxTQUFTLEVBQUUsSUFBQStCLGtDQUFpQixFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzFGLE1BQU11QixPQUFPLENBQUN6QyxHQUFHLENBQUN4QixTQUFTLENBQUM7SUFDNUIsSUFBQThDLGNBQU0sRUFBQ21CLE9BQU8sQ0FBQ2hFLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDOEMsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUM5QyxDQUFDLENBQUM7RUFFRixJQUFBVCxVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsWUFBWTtJQUMvRixNQUFNaUIsR0FBRyxHQUFHbkQsYUFBYSxDQUFDO01BQUUyQixXQUFXLEVBQUU7SUFBRyxDQUFDLENBQUM7SUFDOUMsTUFBTVEsTUFBTSxHQUFHLE1BQU1DLHdCQUFXLENBQUNDLFdBQVcsQ0FBQzNDLE9BQU8sRUFBRTtNQUFFYSxTQUFTLEVBQUU0QyxHQUFHLENBQUM1QztJQUFVLENBQUMsQ0FBQztJQUVuRixNQUFNdUQsRUFBRSxHQUFHM0IsTUFBTSxDQUFDZixHQUFHLENBQUN4QixTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2xDdUMsTUFBTSxDQUFDNEIsTUFBTSxDQUFDO01BQUUsVUFBVSxFQUFFO1FBQUVsRSxLQUFLLEVBQUUsQ0FBQztRQUFFRSxJQUFJLEVBQUU7TUFBUztJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0QsTUFBTWlFLEVBQUUsR0FBRzdCLE1BQU0sQ0FBQzRCLE1BQU0sQ0FBQztNQUFFLFVBQVUsRUFBRTtRQUFFbEUsS0FBSyxFQUFFLENBQUM7UUFBRUUsSUFBSSxFQUFFO01BQVM7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1zQixPQUFPLENBQUM0QyxHQUFHLENBQUMsQ0FBQ0gsRUFBRSxFQUFFRSxFQUFFLENBQUMsQ0FBQztJQUUzQixJQUFBdEIsY0FBTSxFQUFDUCxNQUFNLENBQUN0QyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQzhDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9DO0lBQ0EsSUFBQUQsY0FBTSxFQUFDUyxHQUFHLENBQUM3QyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUNxQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2pDLENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQywwREFBMEQsRUFBRSxZQUFZO0lBQ3pFLE1BQU1yQixPQUFPLEdBQUc7TUFDZGxCLEtBQUssRUFBRTtBQUNiO0FBQ0E7SUFDSSxDQUFDO0lBQ0QsTUFBTXdDLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQUN4QixPQUFPLEVBQUU7TUFBRU4sU0FBUyxFQUFFLElBQUErQixrQ0FBaUIsRUFBQztJQUFFLENBQUMsQ0FBQztJQUN6RixNQUFNSCxNQUFNLENBQUNmLEdBQUcsQ0FBQztNQUFFLFVBQVUsRUFBRTtRQUFFdkIsS0FBSyxFQUFFLENBQUM7UUFBRUUsSUFBSSxFQUFFO01BQVM7SUFBRSxDQUFDLENBQUM7SUFDOUQsSUFBQTJDLGNBQU0sRUFBQ1AsTUFBTSxDQUFDdEMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM4QyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUM3QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBVixnQkFBUSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07RUFDbEYsTUFBTXZDLE9BQU8sR0FBRztJQUNkd0UsSUFBSSxFQUFFO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLENBQUM7RUFFRCxJQUFBaEMsVUFBRSxFQUFDLHlGQUF5RixFQUFFLFlBQVk7SUFDeEcsTUFBTUMsTUFBTSxHQUFHLE1BQU1DLHdCQUFXLENBQUNDLFdBQVcsQ0FBQzNDLE9BQU8sRUFBRTtNQUFFYSxTQUFTLEVBQUUsSUFBQStCLGtDQUFpQixFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pGLE1BQU1ILE1BQU0sQ0FBQ2YsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUV2QixLQUFLLEVBQUUsQ0FBQztVQUFFc0UsR0FBRyxFQUFFO1FBQUcsQ0FBQyxFQUFFO1VBQUVBLEdBQUcsRUFBRTtRQUFHLENBQUMsQ0FBQztRQUFFcEUsSUFBSSxFQUFFO01BQU87SUFBRSxDQUFDLENBQUM7SUFDekYsTUFBTXFFLFFBQVEsR0FBRyxNQUFNakMsTUFBTSxDQUFDa0MsUUFBUSxDQUFDLENBQUM7SUFDeEMsSUFBQTNCLGNBQU0sRUFBQzBCLFFBQVEsQ0FBQ3RGLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRXdGLE9BQU8sQ0FBQyxDQUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUM3RDtJQUNBLElBQUFELGNBQU0sRUFBQzBCLFFBQVEsQ0FBQ3ZGLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM4RCxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ2xELE1BQU00QixLQUFLLEdBQUdILFFBQVEsQ0FBQ3RGLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBRTBGLFFBQVEsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3hELEVBQUUsS0FBSyxrQkFBa0IsQ0FBRTtJQUM1RixJQUFBd0IsY0FBTSxFQUFDNkIsS0FBSyxDQUFDSSxJQUFJLENBQUMsQ0FBQ2hDLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDeEMsSUFBQUQsY0FBTSxFQUFDNkIsS0FBSyxDQUFDaEMsSUFBSSxDQUFDLENBQUNJLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDL0IsQ0FBQyxDQUFDO0VBRUYsSUFBQVQsVUFBRSxFQUFDLG9FQUFvRSxFQUFFLFlBQVk7SUFDbkYsTUFBTUMsTUFBTSxHQUFHLE1BQU1DLHdCQUFXLENBQUNDLFdBQVcsQ0FBQzNDLE9BQU8sRUFBRTtNQUFFYSxTQUFTLEVBQUUsSUFBQStCLGtDQUFpQixFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pGLE1BQU1ILE1BQU0sQ0FBQ2YsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUV2QixLQUFLLEVBQUUsQ0FBQztVQUFFc0UsR0FBRyxFQUFFO1FBQUUsQ0FBQyxDQUFDO1FBQUVwRSxJQUFJLEVBQUU7TUFBTztJQUFFLENBQUMsQ0FBQztJQUMzRSxNQUFNcUUsUUFBUSxHQUFHLE1BQU1qQyxNQUFNLENBQUNrQyxRQUFRLENBQUMsQ0FBQztJQUN4QyxJQUFBM0IsY0FBTSxFQUFDMEIsUUFBUSxDQUFDdEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFd0YsT0FBTyxDQUFDLENBQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDO0VBQzdELENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQyx1RkFBdUYsRUFBRSxZQUFZO0lBQ3RHLE1BQU0wQyxJQUFJLEdBQUcsSUFBQXRDLGtDQUFpQixFQUFDLENBQUM7SUFDaEMsSUFBSXVDLGFBQWEsR0FBRyxLQUFLO0lBQ3pCLE1BQU1DLFdBQXdCLEdBQUc7TUFDL0J0RSxJQUFJQSxDQUFDQyxHQUFHLEVBQUU7UUFDUixJQUFJQSxHQUFHLENBQUNDLElBQUksS0FBSyxXQUFXLElBQUltRSxhQUFhLEVBQUUsT0FBTyxDQUFDO1FBQ3ZERCxJQUFJLENBQUNwRSxJQUFJLENBQUNDLEdBQUcsQ0FBQztNQUNoQixDQUFDO01BQ0RvQixTQUFTQSxDQUFDQyxDQUFDLEVBQUU7UUFDWDhDLElBQUksQ0FBQy9DLFNBQVMsQ0FBQ0MsQ0FBQyxDQUFDO01BQ25CLENBQUM7TUFDREMsT0FBT0EsQ0FBQSxFQUFHO1FBQ1I4QyxhQUFhLEdBQUcsS0FBSztRQUNyQkQsSUFBSSxDQUFDN0MsT0FBTyxDQUFDLENBQUM7TUFDaEIsQ0FBQztNQUNEQyxPQUFPQSxDQUFBLEVBQUc7UUFDUjRDLElBQUksQ0FBQzVDLE9BQU8sQ0FBQyxDQUFDO01BQ2hCO0lBQ0YsQ0FBQztJQUNELE1BQU1HLE1BQU0sR0FBRyxNQUFNQyx3QkFBVyxDQUFDQyxXQUFXLENBQUMzQyxPQUFPLEVBQUU7TUFDcERhLFNBQVMsRUFBRXVFLFdBQVc7TUFDdEJ6QixZQUFZLEVBQUU7SUFDaEIsQ0FBQyxDQUFDO0lBQ0YsTUFBTWxCLE1BQU0sQ0FBQ2YsR0FBRyxDQUFDO01BQUUsY0FBYyxFQUFFO1FBQUV2QixLQUFLLEVBQUUsQ0FBQztVQUFFc0UsR0FBRyxFQUFFO1FBQUcsQ0FBQyxDQUFDO1FBQUVwRSxJQUFJLEVBQUU7TUFBTztJQUFFLENBQUMsQ0FBQztJQUM1RThFLGFBQWEsR0FBRyxJQUFJO0lBQ3BCLE1BQU0sSUFBQW5DLGNBQU0sRUFBQ1AsTUFBTSxDQUFDa0MsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDVSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxXQUFXLENBQUM7SUFDNUQ7SUFDQSxNQUFNN0MsTUFBTSxDQUFDZixHQUFHLENBQUM7TUFBRSxjQUFjLEVBQUU7UUFBRXZCLEtBQUssRUFBRSxDQUFDO1VBQUVzRSxHQUFHLEVBQUU7UUFBRSxDQUFDLENBQUM7UUFBRXBFLElBQUksRUFBRTtNQUFPO0lBQUUsQ0FBQyxDQUFDO0lBQzNFLElBQUEyQyxjQUFNLEVBQUNQLE1BQU0sQ0FBQ3RDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDOEMsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUM1QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBVixnQkFBUSxFQUFDLHNEQUFzRCxFQUFFLE1BQU07RUFDckUsTUFBTWdELEdBQUcsR0FBRztJQUNWdEYsS0FBSyxFQUFFO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLENBQUM7RUFFRCxlQUFldUYsS0FBS0EsQ0FBQSxFQUFHO0lBQ3JCLE1BQU0vQyxNQUFNLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsV0FBVyxDQUFDNEMsR0FBRyxFQUFFO01BQUUxRSxTQUFTLEVBQUUsSUFBQStCLGtDQUFpQixFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3JGLE1BQU1ILE1BQU0sQ0FBQ2YsR0FBRyxDQUFDO01BQ2YsZUFBZSxFQUFFO1FBQUV2QixLQUFLLEVBQUUsQ0FBQztVQUFFQyxDQUFDLEVBQUU7UUFBRSxDQUFDLEVBQUU7VUFBRUEsQ0FBQyxFQUFFO1FBQUUsQ0FBQyxFQUFFO1VBQUVBLENBQUMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUFFQyxJQUFJLEVBQUU7TUFBUyxDQUFDO01BQzFFLHVCQUF1QixFQUFFO1FBQUVGLEtBQUssRUFBRSxDQUFDO1VBQUVDLENBQUMsRUFBRTtRQUFHLENBQUMsRUFBRTtVQUFFQSxDQUFDLEVBQUU7UUFBRSxDQUFDLENBQUM7UUFBRUMsSUFBSSxFQUFFO01BQVMsQ0FBQztNQUN6RSxpQkFBaUIsRUFBRTtRQUFFRixLQUFLLEVBQUUsQ0FBQztVQUFFc0YsUUFBUSxFQUFFO1FBQUcsQ0FBQyxDQUFDO1FBQUVwRixJQUFJLEVBQUU7TUFBUyxDQUFDO01BQ2hFLFVBQVUsRUFBRTtRQUFFRixLQUFLLEVBQUUsQ0FBQztRQUFFRSxJQUFJLEVBQUU7TUFBUztJQUN6QyxDQUFDLENBQUM7SUFDRixPQUFPb0MsTUFBTTtFQUNmO0VBRUEsSUFBQUQsVUFBRSxFQUFDLHFGQUFxRixFQUFFLFlBQVk7SUFDcEcsTUFBTUMsTUFBTSxHQUFHLE1BQU0rQyxLQUFLLENBQUMsQ0FBQztJQUM1QixNQUFNdEMsT0FBTyxHQUFHLE1BQU1ULE1BQU0sQ0FBQ2tDLFFBQVEsQ0FBQyxDQUFDO0lBQ3ZDO0lBQ0E7SUFDQSxNQUFNZSxPQUFPLEdBQUd4QyxPQUFPLENBQUM5RCxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUwRixRQUFRLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUN4RCxFQUFFLEtBQUssZUFBZSxDQUFDO0lBQzFGLElBQUF3QixjQUFNLEVBQUMwQyxPQUFPLEVBQUU3QyxJQUFJLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQztFQUNsQyxDQUFDLENBQUM7RUFFRixJQUFBVCxVQUFFLEVBQUMsd0ZBQXdGLEVBQUUsWUFBWTtJQUN2RyxNQUFNQyxNQUFNLEdBQUcsTUFBTStDLEtBQUssQ0FBQyxDQUFDO0lBQzVCLE1BQU10QyxPQUFPLEdBQUcsTUFBTVQsTUFBTSxDQUFDa0MsUUFBUSxDQUFDLENBQUM7SUFDdkMsTUFBTWdCLEdBQUcsR0FBR3pDLE9BQU8sQ0FBQzlELEdBQUcsQ0FBQyxhQUFhLENBQUMsRUFBRTBGLFFBQVEsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3hELEVBQUUsS0FBSyxlQUFlLENBQUM7SUFDdEYsSUFBQXdCLGNBQU0sRUFBQzJDLEdBQUcsRUFBRTlDLElBQUksQ0FBQyxDQUFDSSxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQzdCLElBQUFELGNBQU0sRUFBQzJDLEdBQUcsRUFBRXZFLE9BQU8sQ0FBQyxDQUFDNkMsU0FBUyxDQUFDLDBCQUEwQixDQUFDO0VBQzVELENBQUMsQ0FBQztFQUVGLElBQUF6QixVQUFFLEVBQUMsNkRBQTZELEVBQUUsWUFBWTtJQUM1RSxNQUFNQyxNQUFNLEdBQUcsTUFBTStDLEtBQUssQ0FBQyxDQUFDO0lBQzVCLE1BQU10QyxPQUFPLEdBQUcsTUFBTVQsTUFBTSxDQUFDa0MsUUFBUSxDQUFDLENBQUM7SUFDdkMsTUFBTUgsSUFBSSxHQUFHdEIsT0FBTyxDQUFDOUQsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFFMEYsUUFBUSxDQUFDQyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDeEQsRUFBRSxLQUFLLGtCQUFrQixDQUFDO0lBQzFGLElBQUF3QixjQUFNLEVBQUN3QixJQUFJLEVBQUUzQixJQUFJLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQztFQUMvQixDQUFDLENBQUM7RUFFRixJQUFBVCxVQUFFLEVBQUMsNENBQTRDLEVBQUUsWUFBWTtJQUMzRCxNQUFNQyxNQUFNLEdBQUcsTUFBTStDLEtBQUssQ0FBQyxDQUFDO0lBQzVCLE1BQU1JLFlBQVksR0FBRyxNQUFNbkQsTUFBTSxDQUFDa0MsUUFBUSxDQUFDLENBQUM7SUFDNUMsTUFBTTdCLElBQUksR0FBR0MsY0FBTSxDQUFDSixXQUFXLENBQUM0QyxHQUFHLEVBQUU7TUFBRSxHQUFHN0c7SUFBTyxDQUFDLENBQUM7SUFDbkRvRSxJQUFJLENBQUNwQixHQUFHLENBQUM7TUFDUCxlQUFlLEVBQUU7UUFBRXZCLEtBQUssRUFBRSxDQUFDO1VBQUVDLENBQUMsRUFBRTtRQUFFLENBQUMsRUFBRTtVQUFFQSxDQUFDLEVBQUU7UUFBRSxDQUFDLEVBQUU7VUFBRUEsQ0FBQyxFQUFFO1FBQUUsQ0FBQyxDQUFDO1FBQUVDLElBQUksRUFBRTtNQUFTLENBQUM7TUFDMUUsdUJBQXVCLEVBQUU7UUFBRUYsS0FBSyxFQUFFLENBQUM7VUFBRUMsQ0FBQyxFQUFFO1FBQUcsQ0FBQyxFQUFFO1VBQUVBLENBQUMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUFFQyxJQUFJLEVBQUU7TUFBUyxDQUFDO01BQ3pFLGlCQUFpQixFQUFFO1FBQUVGLEtBQUssRUFBRSxDQUFDO1VBQUVzRixRQUFRLEVBQUU7UUFBRyxDQUFDLENBQUM7UUFBRXBGLElBQUksRUFBRTtNQUFTLENBQUM7TUFDaEUsVUFBVSxFQUFFO1FBQUVGLEtBQUssRUFBRSxDQUFDO1FBQUVFLElBQUksRUFBRTtNQUFTO0lBQ3pDLENBQUMsQ0FBQztJQUNGO0lBQ0EsS0FBSyxNQUFNLENBQUN3RixPQUFPLEVBQUVDLEtBQUssQ0FBQyxJQUFJaEQsSUFBSSxDQUFDNkIsUUFBUSxDQUFDLENBQUMsRUFBRTtNQUM5QyxNQUFNb0IsYUFBYSxHQUFHSCxZQUFZLENBQUN4RyxHQUFHLENBQUN5RyxPQUFPLENBQUMsQ0FBRWYsUUFBUTtNQUN6RCxNQUFNa0IsTUFBTSxHQUFHRixLQUFLLENBQUNoQixRQUFRLENBQUNtQixHQUFHLENBQUVqQixDQUFDLElBQUtBLENBQUMsQ0FBQ2tCLE1BQU0sQ0FBQ3JELElBQUksQ0FBQztNQUN2RCxNQUFNc0QsV0FBVyxHQUFHSixhQUFhLENBQUNFLEdBQUcsQ0FBRWpCLENBQUMsSUFBS0EsQ0FBQyxDQUFDbkMsSUFBSSxDQUFDO01BQ3BELElBQUFHLGNBQU0sRUFBQ21ELFdBQVcsRUFBRU4sT0FBTyxDQUFDLENBQUNPLE9BQU8sQ0FBQ0osTUFBTSxDQUFDO01BQzVDO01BQ0EsSUFBQWhELGNBQU0sRUFBQ2dELE1BQU0sRUFBRUgsT0FBTyxDQUFDLENBQUNPLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDdEQ7RUFDRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=