var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ShowWhen;
var _bindingsContext = require("../bindingsContext.ts");
var _renderContext = require("../renderContext.ts");
var _attrs = require("../attrs.ts");
var _shape = require("../shape.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _BrokenBoundTile = _interopRequireDefault(require("./BrokenBoundTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // ShowWhen — conditional render by data (§3.3): the children render only when the bound
// cell is exactly `true`. One attribute, one test — the template never computes
// (§3.3.1 "never an expression"), so the worksheet owns the condition as a named, testable
// cell and the template only names it; a template that needs "else" binds a second cell.
// Truthiness is refused by the asBoolean shape guard — a cell that starts returning a count
// must not silently flip the render. A hidden subtree is never mounted (no display:none),
// and unlike ShowAbove this adds no wrapper element: it measures nothing, and a wrapper div
// would only disturb Row's grid. A binding that cannot answer is loud, never silent: an
// alarm hidden because its cell broke is the worst silent failure this component could add.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function ShowWhen({
  node
}) {
  _s();
  const bound = (0, _bindingsContext.useSource)((0, _attrs.attrString)(node, 'source'));
  const renderNodes = (0, _renderContext.useRenderNodes)();
  if (bound.status !== 'ok') return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenBoundTile.default, {
    component: "ShowWhen",
    bound: bound
  });
  const flag = (0, _shape.asBoolean)(bound.value);
  if (!flag.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "ShowWhen",
    reason: flag.reason
  });
  return flag.data ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_jsxRuntime.Fragment, {
    children: renderNodes(node.children)
  }) : null;
}
_s(ShowWhen, "/Yz2Xx3c7Vs7qqPhjutHLaXAjTw=", false, function () {
  return [_bindingsContext.useSource, _renderContext.useRenderNodes];
});
_c = ShowWhen;
var _c;
$RefreshReg$(_c, "ShowWhen");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9yZW5kZXJDb250ZXh0IiwiX2F0dHJzIiwiX3NoYXBlIiwiX0Jyb2tlblRpbGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0Jyb2tlbkJvdW5kVGlsZSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJTaG93V2hlbiIsIm5vZGUiLCJib3VuZCIsInVzZVNvdXJjZSIsImF0dHJTdHJpbmciLCJyZW5kZXJOb2RlcyIsInVzZVJlbmRlck5vZGVzIiwic3RhdHVzIiwianN4IiwiY29tcG9uZW50IiwiZmxhZyIsImFzQm9vbGVhbiIsInZhbHVlIiwib2siLCJyZWFzb24iLCJkYXRhIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2hvd1doZW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFNob3dXaGVuIOKAlCBjb25kaXRpb25hbCByZW5kZXIgYnkgZGF0YSAowqczLjMpOiB0aGUgY2hpbGRyZW4gcmVuZGVyIG9ubHkgd2hlbiB0aGUgYm91bmRcbi8vIGNlbGwgaXMgZXhhY3RseSBgdHJ1ZWAuIE9uZSBhdHRyaWJ1dGUsIG9uZSB0ZXN0IOKAlCB0aGUgdGVtcGxhdGUgbmV2ZXIgY29tcHV0ZXNcbi8vICjCpzMuMy4xIFwibmV2ZXIgYW4gZXhwcmVzc2lvblwiKSwgc28gdGhlIHdvcmtzaGVldCBvd25zIHRoZSBjb25kaXRpb24gYXMgYSBuYW1lZCwgdGVzdGFibGVcbi8vIGNlbGwgYW5kIHRoZSB0ZW1wbGF0ZSBvbmx5IG5hbWVzIGl0OyBhIHRlbXBsYXRlIHRoYXQgbmVlZHMgXCJlbHNlXCIgYmluZHMgYSBzZWNvbmQgY2VsbC5cbi8vIFRydXRoaW5lc3MgaXMgcmVmdXNlZCBieSB0aGUgYXNCb29sZWFuIHNoYXBlIGd1YXJkIOKAlCBhIGNlbGwgdGhhdCBzdGFydHMgcmV0dXJuaW5nIGEgY291bnRcbi8vIG11c3Qgbm90IHNpbGVudGx5IGZsaXAgdGhlIHJlbmRlci4gQSBoaWRkZW4gc3VidHJlZSBpcyBuZXZlciBtb3VudGVkIChubyBkaXNwbGF5Om5vbmUpLFxuLy8gYW5kIHVubGlrZSBTaG93QWJvdmUgdGhpcyBhZGRzIG5vIHdyYXBwZXIgZWxlbWVudDogaXQgbWVhc3VyZXMgbm90aGluZywgYW5kIGEgd3JhcHBlciBkaXZcbi8vIHdvdWxkIG9ubHkgZGlzdHVyYiBSb3cncyBncmlkLiBBIGJpbmRpbmcgdGhhdCBjYW5ub3QgYW5zd2VyIGlzIGxvdWQsIG5ldmVyIHNpbGVudDogYW5cbi8vIGFsYXJtIGhpZGRlbiBiZWNhdXNlIGl0cyBjZWxsIGJyb2tlIGlzIHRoZSB3b3JzdCBzaWxlbnQgZmFpbHVyZSB0aGlzIGNvbXBvbmVudCBjb3VsZCBhZGQuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyB1c2VTb3VyY2UgfSBmcm9tICcuLi9iaW5kaW5nc0NvbnRleHQudHMnO1xuaW1wb3J0IHsgdXNlUmVuZGVyTm9kZXMgfSBmcm9tICcuLi9yZW5kZXJDb250ZXh0LnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyBhc0Jvb2xlYW4gfSBmcm9tICcuLi9zaGFwZS50cyc7XG5pbXBvcnQgQnJva2VuVGlsZSBmcm9tICcuL0Jyb2tlblRpbGUudHN4JztcbmltcG9ydCBCcm9rZW5Cb3VuZFRpbGUgZnJvbSAnLi9Ccm9rZW5Cb3VuZFRpbGUudHN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2hvd1doZW4oeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IGJvdW5kID0gdXNlU291cmNlKGF0dHJTdHJpbmcobm9kZSwgJ3NvdXJjZScpKTtcbiAgY29uc3QgcmVuZGVyTm9kZXMgPSB1c2VSZW5kZXJOb2RlcygpO1xuXG4gIGlmIChib3VuZC5zdGF0dXMgIT09ICdvaycpIHJldHVybiA8QnJva2VuQm91bmRUaWxlIGNvbXBvbmVudD1cIlNob3dXaGVuXCIgYm91bmQ9e2JvdW5kfSAvPjtcbiAgY29uc3QgZmxhZyA9IGFzQm9vbGVhbihib3VuZC52YWx1ZSk7XG4gIGlmICghZmxhZy5vaykgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIlNob3dXaGVuXCIgcmVhc29uPXtmbGFnLnJlYXNvbn0gLz47XG4gIHJldHVybiBmbGFnLmRhdGEgPyA8PntyZW5kZXJOb2Rlcyhub2RlLmNoaWxkcmVuKX08Lz4gOiBudWxsO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFVQSxJQUFBQSxnQkFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsY0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsTUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksV0FBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU0sZ0JBQUEsR0FBQUQsc0JBQUEsQ0FBQUwsT0FBQTtBQUFvRCxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFBQSxJQUFBUSxFQUFBLEdBQUFDLFlBQUEsSUFmcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUosdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFTZSxTQUFTRyxRQUFRQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBTixFQUFBO0VBQ2xFLE1BQU1PLEtBQUssR0FBRyxJQUFBQywwQkFBUyxFQUFDLElBQUFDLGlCQUFVLEVBQUNILElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztFQUNuRCxNQUFNSSxXQUFXLEdBQUcsSUFBQUMsNkJBQWMsRUFBQyxDQUFDO0VBRXBDLElBQUlKLEtBQUssQ0FBQ0ssTUFBTSxLQUFLLElBQUksRUFBRSxvQkFBTyxJQUFBYixXQUFBLENBQUFjLEdBQUEsRUFBQ2YsZ0JBQUEsQ0FBQU0sT0FBZTtJQUFDVSxTQUFTLEVBQUMsVUFBVTtJQUFDUCxLQUFLLEVBQUVBO0VBQU0sQ0FBRSxDQUFDO0VBQ3hGLE1BQU1RLElBQUksR0FBRyxJQUFBQyxnQkFBUyxFQUFDVCxLQUFLLENBQUNVLEtBQUssQ0FBQztFQUNuQyxJQUFJLENBQUNGLElBQUksQ0FBQ0csRUFBRSxFQUFFLG9CQUFPLElBQUFuQixXQUFBLENBQUFjLEdBQUEsRUFBQ2pCLFdBQUEsQ0FBQVEsT0FBVTtJQUFDVSxTQUFTLEVBQUMsVUFBVTtJQUFDSyxNQUFNLEVBQUVKLElBQUksQ0FBQ0k7RUFBTyxDQUFFLENBQUM7RUFDN0UsT0FBT0osSUFBSSxDQUFDSyxJQUFJLGdCQUFHLElBQUFyQixXQUFBLENBQUFjLEdBQUEsRUFBQWQsV0FBQSxDQUFBc0IsUUFBQTtJQUFBQyxRQUFBLEVBQUdaLFdBQVcsQ0FBQ0osSUFBSSxDQUFDZ0IsUUFBUTtFQUFDLENBQUcsQ0FBQyxHQUFHLElBQUk7QUFDN0Q7QUFBQ3RCLEVBQUEsQ0FSdUJLLFFBQVE7RUFBQSxRQUNoQkcsMEJBQVMsRUFDSEcsNkJBQWM7QUFBQTtBQUFBWSxFQUFBLEdBRlpsQixRQUFRO0FBQUEsSUFBQWtCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}