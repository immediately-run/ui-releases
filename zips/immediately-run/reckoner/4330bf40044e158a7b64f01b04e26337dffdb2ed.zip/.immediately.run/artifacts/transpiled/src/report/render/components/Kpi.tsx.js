var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Kpi;
var _bindingsContext = require("../bindingsContext.ts");
var _shape = require("../shape.ts");
var _attrs = require("../attrs.ts");
var _format = require("../format.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _TierSlot = _interopRequireDefault(require("./TierSlot.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Kpi — the "just show the number" stat card (§3.3). Binds a scalar `source`, optionally a
// scalar `compare` (prior value) rendered as a signed relative delta. `format` selects
// number/currency/percent. The tier slot is reserved for the host badge (never drawn here).
// A non-scalar or non-ok binding degrades to a marked broken tile.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Kpi({
  node
}) {
  _s();
  const source = (0, _attrs.attrString)(node, 'source');
  const format = (0, _attrs.attrString)(node, 'format') ?? 'number';
  const unit = (0, _attrs.attrString)(node, 'unit');
  const bound = (0, _bindingsContext.useSource)(source);
  const compare = (0, _bindingsContext.useSource)((0, _attrs.attrString)(node, 'compare'));
  if (bound.status !== 'ok') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "Kpi",
      reason: bound.message ?? 'unavailable',
      variant: bound.status === 'missing' ? 'needs-access' : 'error'
    });
  }
  const scalar = (0, _shape.asScalar)(bound.value);
  if (!scalar.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Kpi",
    reason: scalar.reason
  });
  const showDelta = compare.status === 'ok' && typeof compare.value === 'number' && typeof scalar.data === 'number';
  const delta = showDelta ? (0, _format.formatDelta)(scalar.data, compare.value, format) : undefined;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-kpi rk-tile",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TierSlot.default, {
      tier: bound.tier
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-kpi-value",
      children: (0, _format.formatScalar)(scalar.data, format, unit)
    }), delta && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-kpi-delta",
      "data-direction": delta.direction,
      children: delta.label
    })]
  });
}
_s(Kpi, "OScmRmXHcR+s8Ye89sc+2ajXy0o=", false, function () {
  return [_bindingsContext.useSource, _bindingsContext.useSource];
});
_c = Kpi;
var _c;
$RefreshReg$(_c, "Kpi");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9zaGFwZSIsIl9hdHRycyIsIl9mb3JtYXQiLCJfQnJva2VuVGlsZSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfVGllclNsb3QiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiS3BpIiwibm9kZSIsInNvdXJjZSIsImF0dHJTdHJpbmciLCJmb3JtYXQiLCJ1bml0IiwiYm91bmQiLCJ1c2VTb3VyY2UiLCJjb21wYXJlIiwic3RhdHVzIiwianN4IiwiY29tcG9uZW50IiwicmVhc29uIiwibWVzc2FnZSIsInZhcmlhbnQiLCJzY2FsYXIiLCJhc1NjYWxhciIsInZhbHVlIiwib2siLCJzaG93RGVsdGEiLCJkYXRhIiwiZGVsdGEiLCJmb3JtYXREZWx0YSIsInVuZGVmaW5lZCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsInRpZXIiLCJmb3JtYXRTY2FsYXIiLCJkaXJlY3Rpb24iLCJsYWJlbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiS3BpLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBLcGkg4oCUIHRoZSBcImp1c3Qgc2hvdyB0aGUgbnVtYmVyXCIgc3RhdCBjYXJkICjCpzMuMykuIEJpbmRzIGEgc2NhbGFyIGBzb3VyY2VgLCBvcHRpb25hbGx5IGFcbi8vIHNjYWxhciBgY29tcGFyZWAgKHByaW9yIHZhbHVlKSByZW5kZXJlZCBhcyBhIHNpZ25lZCByZWxhdGl2ZSBkZWx0YS4gYGZvcm1hdGAgc2VsZWN0c1xuLy8gbnVtYmVyL2N1cnJlbmN5L3BlcmNlbnQuIFRoZSB0aWVyIHNsb3QgaXMgcmVzZXJ2ZWQgZm9yIHRoZSBob3N0IGJhZGdlIChuZXZlciBkcmF3biBoZXJlKS5cbi8vIEEgbm9uLXNjYWxhciBvciBub24tb2sgYmluZGluZyBkZWdyYWRlcyB0byBhIG1hcmtlZCBicm9rZW4gdGlsZS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IHVzZVNvdXJjZSB9IGZyb20gJy4uL2JpbmRpbmdzQ29udGV4dC50cyc7XG5pbXBvcnQgeyBhc1NjYWxhciB9IGZyb20gJy4uL3NoYXBlLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyBmb3JtYXRTY2FsYXIsIGZvcm1hdERlbHRhIH0gZnJvbSAnLi4vZm9ybWF0LnRzJztcbmltcG9ydCB0eXBlIHsgTnVtYmVyRm9ybWF0IH0gZnJvbSAnLi4vZm9ybWF0LnRzJztcbmltcG9ydCBCcm9rZW5UaWxlIGZyb20gJy4vQnJva2VuVGlsZS50c3gnO1xuaW1wb3J0IFRpZXJTbG90IGZyb20gJy4vVGllclNsb3QudHN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gS3BpKHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCBzb3VyY2UgPSBhdHRyU3RyaW5nKG5vZGUsICdzb3VyY2UnKTtcbiAgY29uc3QgZm9ybWF0ID0gKGF0dHJTdHJpbmcobm9kZSwgJ2Zvcm1hdCcpID8/ICdudW1iZXInKSBhcyBOdW1iZXJGb3JtYXQ7XG4gIGNvbnN0IHVuaXQgPSBhdHRyU3RyaW5nKG5vZGUsICd1bml0Jyk7XG4gIGNvbnN0IGJvdW5kID0gdXNlU291cmNlKHNvdXJjZSk7XG4gIGNvbnN0IGNvbXBhcmUgPSB1c2VTb3VyY2UoYXR0clN0cmluZyhub2RlLCAnY29tcGFyZScpKTtcblxuICBpZiAoYm91bmQuc3RhdHVzICE9PSAnb2snKSB7XG4gICAgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIktwaVwiIHJlYXNvbj17Ym91bmQubWVzc2FnZSA/PyAndW5hdmFpbGFibGUnfSB2YXJpYW50PXtib3VuZC5zdGF0dXMgPT09ICdtaXNzaW5nJyA/ICduZWVkcy1hY2Nlc3MnIDogJ2Vycm9yJ30gLz47XG4gIH1cbiAgY29uc3Qgc2NhbGFyID0gYXNTY2FsYXIoYm91bmQudmFsdWUpO1xuICBpZiAoIXNjYWxhci5vaykgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIktwaVwiIHJlYXNvbj17c2NhbGFyLnJlYXNvbn0gLz47XG5cbiAgY29uc3Qgc2hvd0RlbHRhID0gY29tcGFyZS5zdGF0dXMgPT09ICdvaycgJiYgdHlwZW9mIGNvbXBhcmUudmFsdWUgPT09ICdudW1iZXInICYmIHR5cGVvZiBzY2FsYXIuZGF0YSA9PT0gJ251bWJlcic7XG4gIGNvbnN0IGRlbHRhID0gc2hvd0RlbHRhID8gZm9ybWF0RGVsdGEoc2NhbGFyLmRhdGEgYXMgbnVtYmVyLCBjb21wYXJlLnZhbHVlIGFzIG51bWJlciwgZm9ybWF0KSA6IHVuZGVmaW5lZDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmsta3BpIHJrLXRpbGVcIj5cbiAgICAgIDxUaWVyU2xvdCB0aWVyPXtib3VuZC50aWVyfSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1rcGktdmFsdWVcIj57Zm9ybWF0U2NhbGFyKHNjYWxhci5kYXRhLCBmb3JtYXQsIHVuaXQpfTwvZGl2PlxuICAgICAge2RlbHRhICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1rcGktZGVsdGFcIiBkYXRhLWRpcmVjdGlvbj17ZGVsdGEuZGlyZWN0aW9ufT5cbiAgICAgICAgICB7ZGVsdGEubGFiZWx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsZ0JBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUgsT0FBQTtBQUVBLElBQUFJLFdBQUEsR0FBQUMsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFNLFNBQUEsR0FBQUQsc0JBQUEsQ0FBQUwsT0FBQTtBQUFzQyxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFBQSxJQUFBUSxFQUFBLEdBQUFDLFlBQUEsSUFYdEM7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSix1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVVlLFNBQVNHLEdBQUdBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDN0QsTUFBTU8sTUFBTSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxRQUFRLENBQUM7RUFDekMsTUFBTUcsTUFBTSxHQUFJLElBQUFELGlCQUFVLEVBQUNGLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxRQUF5QjtFQUN2RSxNQUFNSSxJQUFJLEdBQUcsSUFBQUYsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUNyQyxNQUFNSyxLQUFLLEdBQUcsSUFBQUMsMEJBQVMsRUFBQ0wsTUFBTSxDQUFDO0VBQy9CLE1BQU1NLE9BQU8sR0FBRyxJQUFBRCwwQkFBUyxFQUFDLElBQUFKLGlCQUFVLEVBQUNGLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztFQUV0RCxJQUFJSyxLQUFLLENBQUNHLE1BQU0sS0FBSyxJQUFJLEVBQUU7SUFDekIsb0JBQU8sSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDbkIsV0FBQSxDQUFBUSxPQUFVO01BQUNZLFNBQVMsRUFBQyxLQUFLO01BQUNDLE1BQU0sRUFBRU4sS0FBSyxDQUFDTyxPQUFPLElBQUksYUFBYztNQUFDQyxPQUFPLEVBQUVSLEtBQUssQ0FBQ0csTUFBTSxLQUFLLFNBQVMsR0FBRyxjQUFjLEdBQUc7SUFBUSxDQUFFLENBQUM7RUFDL0k7RUFDQSxNQUFNTSxNQUFNLEdBQUcsSUFBQUMsZUFBUSxFQUFDVixLQUFLLENBQUNXLEtBQUssQ0FBQztFQUNwQyxJQUFJLENBQUNGLE1BQU0sQ0FBQ0csRUFBRSxFQUFFLG9CQUFPLElBQUF4QixXQUFBLENBQUFnQixHQUFBLEVBQUNuQixXQUFBLENBQUFRLE9BQVU7SUFBQ1ksU0FBUyxFQUFDLEtBQUs7SUFBQ0MsTUFBTSxFQUFFRyxNQUFNLENBQUNIO0VBQU8sQ0FBRSxDQUFDO0VBRTVFLE1BQU1PLFNBQVMsR0FBR1gsT0FBTyxDQUFDQyxNQUFNLEtBQUssSUFBSSxJQUFJLE9BQU9ELE9BQU8sQ0FBQ1MsS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPRixNQUFNLENBQUNLLElBQUksS0FBSyxRQUFRO0VBQ2pILE1BQU1DLEtBQUssR0FBR0YsU0FBUyxHQUFHLElBQUFHLG1CQUFXLEVBQUNQLE1BQU0sQ0FBQ0ssSUFBSSxFQUFZWixPQUFPLENBQUNTLEtBQUssRUFBWWIsTUFBTSxDQUFDLEdBQUdtQixTQUFTO0VBRXpHLG9CQUNFLElBQUE3QixXQUFBLENBQUE4QixJQUFBO0lBQUtDLFNBQVMsRUFBQyxnQkFBZ0I7SUFBQUMsUUFBQSxnQkFDN0IsSUFBQWhDLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2pCLFNBQUEsQ0FBQU0sT0FBUTtNQUFDNEIsSUFBSSxFQUFFckIsS0FBSyxDQUFDcUI7SUFBSyxDQUFFLENBQUMsZUFDOUIsSUFBQWpDLFdBQUEsQ0FBQWdCLEdBQUE7TUFBS2UsU0FBUyxFQUFDLGNBQWM7TUFBQUMsUUFBQSxFQUFFLElBQUFFLG9CQUFZLEVBQUNiLE1BQU0sQ0FBQ0ssSUFBSSxFQUFFaEIsTUFBTSxFQUFFQyxJQUFJO0lBQUMsQ0FBTSxDQUFDLEVBQzVFZ0IsS0FBSyxpQkFDSixJQUFBM0IsV0FBQSxDQUFBZ0IsR0FBQTtNQUFLZSxTQUFTLEVBQUMsY0FBYztNQUFDLGtCQUFnQkosS0FBSyxDQUFDUSxTQUFVO01BQUFILFFBQUEsRUFDM0RMLEtBQUssQ0FBQ1M7SUFBSyxDQUNULENBQ047RUFBQSxDQUNFLENBQUM7QUFFVjtBQUFDbkMsRUFBQSxDQTNCdUJLLEdBQUc7RUFBQSxRQUlYTywwQkFBUyxFQUNQQSwwQkFBUztBQUFBO0FBQUF3QixFQUFBLEdBTEgvQixHQUFHO0FBQUEsSUFBQStCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}