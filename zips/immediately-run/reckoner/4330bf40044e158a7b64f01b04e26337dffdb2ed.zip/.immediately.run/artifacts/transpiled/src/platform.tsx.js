var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _boot = require("@immediately-run/sdk/boot");
var _App = _interopRequireDefault(require("./App.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The entry immediately.run runs (`package.json` → `main`). NOT the `vite dev` entry — that
// is `src/main.tsx`, reached through `index.html`, and it must stay SDK-free.
//
// Why this file has to exist at all (R3-553). The platform resolves an app's entry from
// `package.json` (`main`/`source`/`module`, then the preset defaults). With none of them
// present, reckoner had no entry, so the host served its read-only boot default — literally
// `boot();` — which installs the SDK's DEFAULT_ROUTING_SPEC: `/` → `MainContent`,
// `/files/*` → `FileRouter`, and **everything else → ErrorNotFound**. `MainContent` then
// redirects `/` to `/files/src/App.tsx`, which is why every published reckoner URL reads
// `…/main/files/src/App.tsx?doc=usage`: the app owned no path space at all, and the document
// selector had nowhere to live except the query string — where the host forwards it only at
// boot, so in-app navigation and Back could never work.
//
// `boot({ children })` is the fix, and deliberately not `boot({ routingSpec })`: given
// children, the SDK installs CATCH_ALL_ROUTING_SPEC — every `sandboxPath` matches — and
// renders them inside the navigation providers. Dispatch then stays in one place (the seed
// picker) instead of being split across a host route table and the app's own routing, which
// would have to agree with each other. It also means no not-found rule to own, and no need to
// enumerate the legacy URLs: they fall through the same normaliser as everything else.
//
// The `vite dev` split is the reason this is a separate file rather than a branch inside
// `main.tsx`: importing the SDK's `boot` reaches for the host transport at module load, which
// throws outright when there is no host.

(0, _boot.boot)({
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYm9vdCIsInJlcXVpcmUiLCJfQXBwIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiYm9vdCIsImNoaWxkcmVuIiwianN4Il0sInNvdXJjZXMiOlsicGxhdGZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlbnRyeSBpbW1lZGlhdGVseS5ydW4gcnVucyAoYHBhY2thZ2UuanNvbmAg4oaSIGBtYWluYCkuIE5PVCB0aGUgYHZpdGUgZGV2YCBlbnRyeSDigJQgdGhhdFxuLy8gaXMgYHNyYy9tYWluLnRzeGAsIHJlYWNoZWQgdGhyb3VnaCBgaW5kZXguaHRtbGAsIGFuZCBpdCBtdXN0IHN0YXkgU0RLLWZyZWUuXG4vL1xuLy8gV2h5IHRoaXMgZmlsZSBoYXMgdG8gZXhpc3QgYXQgYWxsIChSMy01NTMpLiBUaGUgcGxhdGZvcm0gcmVzb2x2ZXMgYW4gYXBwJ3MgZW50cnkgZnJvbVxuLy8gYHBhY2thZ2UuanNvbmAgKGBtYWluYC9gc291cmNlYC9gbW9kdWxlYCwgdGhlbiB0aGUgcHJlc2V0IGRlZmF1bHRzKS4gV2l0aCBub25lIG9mIHRoZW1cbi8vIHByZXNlbnQsIHJlY2tvbmVyIGhhZCBubyBlbnRyeSwgc28gdGhlIGhvc3Qgc2VydmVkIGl0cyByZWFkLW9ubHkgYm9vdCBkZWZhdWx0IOKAlCBsaXRlcmFsbHlcbi8vIGBib290KCk7YCDigJQgd2hpY2ggaW5zdGFsbHMgdGhlIFNESydzIERFRkFVTFRfUk9VVElOR19TUEVDOiBgL2Ag4oaSIGBNYWluQ29udGVudGAsXG4vLyBgL2ZpbGVzLypgIOKGkiBgRmlsZVJvdXRlcmAsIGFuZCAqKmV2ZXJ5dGhpbmcgZWxzZSDihpIgRXJyb3JOb3RGb3VuZCoqLiBgTWFpbkNvbnRlbnRgIHRoZW5cbi8vIHJlZGlyZWN0cyBgL2AgdG8gYC9maWxlcy9zcmMvQXBwLnRzeGAsIHdoaWNoIGlzIHdoeSBldmVyeSBwdWJsaXNoZWQgcmVja29uZXIgVVJMIHJlYWRzXG4vLyBg4oCmL21haW4vZmlsZXMvc3JjL0FwcC50c3g/ZG9jPXVzYWdlYDogdGhlIGFwcCBvd25lZCBubyBwYXRoIHNwYWNlIGF0IGFsbCwgYW5kIHRoZSBkb2N1bWVudFxuLy8gc2VsZWN0b3IgaGFkIG5vd2hlcmUgdG8gbGl2ZSBleGNlcHQgdGhlIHF1ZXJ5IHN0cmluZyDigJQgd2hlcmUgdGhlIGhvc3QgZm9yd2FyZHMgaXQgb25seSBhdFxuLy8gYm9vdCwgc28gaW4tYXBwIG5hdmlnYXRpb24gYW5kIEJhY2sgY291bGQgbmV2ZXIgd29yay5cbi8vXG4vLyBgYm9vdCh7IGNoaWxkcmVuIH0pYCBpcyB0aGUgZml4LCBhbmQgZGVsaWJlcmF0ZWx5IG5vdCBgYm9vdCh7IHJvdXRpbmdTcGVjIH0pYDogZ2l2ZW5cbi8vIGNoaWxkcmVuLCB0aGUgU0RLIGluc3RhbGxzIENBVENIX0FMTF9ST1VUSU5HX1NQRUMg4oCUIGV2ZXJ5IGBzYW5kYm94UGF0aGAgbWF0Y2hlcyDigJQgYW5kXG4vLyByZW5kZXJzIHRoZW0gaW5zaWRlIHRoZSBuYXZpZ2F0aW9uIHByb3ZpZGVycy4gRGlzcGF0Y2ggdGhlbiBzdGF5cyBpbiBvbmUgcGxhY2UgKHRoZSBzZWVkXG4vLyBwaWNrZXIpIGluc3RlYWQgb2YgYmVpbmcgc3BsaXQgYWNyb3NzIGEgaG9zdCByb3V0ZSB0YWJsZSBhbmQgdGhlIGFwcCdzIG93biByb3V0aW5nLCB3aGljaFxuLy8gd291bGQgaGF2ZSB0byBhZ3JlZSB3aXRoIGVhY2ggb3RoZXIuIEl0IGFsc28gbWVhbnMgbm8gbm90LWZvdW5kIHJ1bGUgdG8gb3duLCBhbmQgbm8gbmVlZCB0b1xuLy8gZW51bWVyYXRlIHRoZSBsZWdhY3kgVVJMczogdGhleSBmYWxsIHRocm91Z2ggdGhlIHNhbWUgbm9ybWFsaXNlciBhcyBldmVyeXRoaW5nIGVsc2UuXG4vL1xuLy8gVGhlIGB2aXRlIGRldmAgc3BsaXQgaXMgdGhlIHJlYXNvbiB0aGlzIGlzIGEgc2VwYXJhdGUgZmlsZSByYXRoZXIgdGhhbiBhIGJyYW5jaCBpbnNpZGVcbi8vIGBtYWluLnRzeGA6IGltcG9ydGluZyB0aGUgU0RLJ3MgYGJvb3RgIHJlYWNoZXMgZm9yIHRoZSBob3N0IHRyYW5zcG9ydCBhdCBtb2R1bGUgbG9hZCwgd2hpY2hcbi8vIHRocm93cyBvdXRyaWdodCB3aGVuIHRoZXJlIGlzIG5vIGhvc3QuXG5pbXBvcnQgeyBib290IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvYm9vdCc7XG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLnRzeCc7XG5cbmJvb3QoeyBjaGlsZHJlbjogPEFwcCAvPiB9KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUF1QkEsSUFBQUEsS0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQTRCLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBeEI1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBLElBQUFHLFVBQUksRUFBQztFQUFFQyxRQUFRLGVBQUUsSUFBQUwsV0FBQSxDQUFBTSxHQUFBLEVBQUNSLElBQUEsQ0FBQUssT0FBRyxJQUFFO0FBQUUsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}