var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _useOverlayDialog = require("./useOverlayDialog.ts");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$(); // @vitest-environment happy-dom
// The overlay-dialog contract (R3-610): focus in on open, Tab wrap read at keydown, Escape
// only while enabled, invoker restored on close — over a real component tree in a DOM, not
// a static render, because every one of those is an effect- or event-time behaviour. The
// two harness shapes mirror the two call sites: the dock (App holds the hook behind an
// `enabled` flag, the element conditionally rendered) and the workbook panel (the mounted
// component holds the hook itself, enabled by default).
// react-dom/client requires the act environment flag to flush effects deterministically.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const byId = id => {
  const el = document.getElementById(id);
  if (el === null) throw new Error(`no #${id}`);
  return el;
};

/** Dispatch a keydown from the element (bubbles to the overlay root, as a real key does). */
function key(el, k, shift = false) {
  el.dispatchEvent(new KeyboardEvent('keydown', {
    key: k,
    bubbles: true,
    cancelable: true,
    shiftKey: shift
  }));
}
function mount(tree) {
  const container = document.createElement('div');
  document.body.appendChild(container);
  const root = (0, _client.createRoot)(container);
  (0, _react.act)(() => root.render(tree));
  return {
    rerender: next => (0, _react.act)(() => root.render(next)),
    unmount: () => {
      (0, _react.act)(() => root.unmount());
      container.remove();
    }
  };
}

// — The dock shape: App owns the hook and the conditional element, `enabled` gating both. —
function DockHarness({
  open,
  enabled,
  onClose,
  lateFocusable
}) {
  _s();
  const ref = (0, _useOverlayDialog.useOverlayDialog)(onClose, {
    enabled
  });
  return /*#__PURE__*/(0, _react.createElement)('div', null, /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'invoker'
  }, 'Inspect'), open && /*#__PURE__*/(0, _react.createElement)('div', {
    id: 'overlay',
    ref
  }, /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'first'
  }, 'First'), /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'last'
  }, 'Last'), lateFocusable === true && /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'late'
  }, 'Late')));
}

// — The panel shape: the mounted component owns the hook, enabled defaults to true. —
_s(DockHarness, "fstH1UTjP4Futc6HHuL2J6ti2uk=", false, function () {
  return [_useOverlayDialog.useOverlayDialog];
});
_c = DockHarness;
function PanelHarness({
  open,
  onClose,
  invokerPresent = true
}) {
  return /*#__PURE__*/(0, _react.createElement)('div', null, invokerPresent && /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'invoker'
  }, 'Workbook'), open && /*#__PURE__*/(0, _react.createElement)('aside', {
    id: 'panel'
  }, /*#__PURE__*/(0, _react.createElement)(PanelBody, {
    onClose
  })));
}
_c2 = PanelHarness;
function PanelBody({
  onClose
}) {
  _s2();
  const ref = (0, _useOverlayDialog.useOverlayDialog)(onClose);
  return /*#__PURE__*/(0, _react.createElement)('aside', {
    id: 'overlay',
    ref
  }, /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'first'
  }, 'Close'));
}

// — The vocabulary shape: <details><summary> toggles with focusable content hidden while
// closed — the round-2 trap defect: summary is implicitly tabbable, the closed content is
// not, and the trap must read the REAL tab order, not the querySelectorAll hit list. —
_s2(PanelBody, "fstH1UTjP4Futc6HHuL2J6ti2uk=", false, function () {
  return [_useOverlayDialog.useOverlayDialog];
});
_c3 = PanelBody;
function DetailsHarness({
  detailsOpen,
  onClose
}) {
  _s3();
  const ref = (0, _useOverlayDialog.useOverlayDialog)(onClose);
  return /*#__PURE__*/(0, _react.createElement)('div', {
    id: 'overlay',
    ref
  }, /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'first'
  }, 'First'), /*#__PURE__*/(0, _react.createElement)('details', {
    id: 'entry',
    open: detailsOpen
  }, /*#__PURE__*/(0, _react.createElement)('summary', {
    id: 'sum'
  }, 'entry'), /*#__PURE__*/(0, _react.createElement)('button', {
    type: 'button',
    id: 'copy'
  }, 'Copy')));
}
_s3(DetailsHarness, "fstH1UTjP4Futc6HHuL2J6ti2uk=", false, function () {
  return [_useOverlayDialog.useOverlayDialog];
});
_c4 = DetailsHarness;
(0, _vitest.describe)('useOverlayDialog — the overlay contract (R3-610)', () => {
  (0, _vitest.it)('moves focus to the first focusable inside on enable, and restores the invoker on disable', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: false,
      onClose
    }));
    byId('invoker').focus();
    (0, _vitest.expect)(document.activeElement).toBe(byId('invoker'));
    h.rerender(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: true,
      onClose
    }));
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    h.rerender(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: false,
      onClose
    }));
    (0, _vitest.expect)(document.activeElement).toBe(byId('invoker'));
    h.unmount();
  });
  (0, _vitest.it)('the mounted-panel shape captures the invoker and restores it when the panel unmounts', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: false,
      onClose
    }));
    byId('invoker').focus();
    h.rerender(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: true,
      onClose
    }));
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    // The panel's own conditional unmount (App keeps rendering the header toggle) runs the
    // restore; the invoker survives, as the real rk-review-toggle does.
    h.rerender(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: false,
      onClose
    }));
    (0, _vitest.expect)(document.activeElement).toBe(byId('invoker'));
    h.unmount();
  });
  (0, _vitest.it)('focus lands on the overlay root itself when it has no focusable child', () => {
    var _s4 = $RefreshSig$();
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: true,
      onClose
    }));
    // The default harness has focusables; re-render a bare-root variant through the panel
    // shape with an empty overlay to hit the fallback.
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    function Bare() {
      _s4();
      const ref = (0, _useOverlayDialog.useOverlayDialog)(onClose);
      return /*#__PURE__*/(0, _react.createElement)('aside', {
        id: 'bare',
        ref
      });
    }
    _s4(Bare, "fstH1UTjP4Futc6HHuL2J6ti2uk=", false, function () {
      return [_useOverlayDialog.useOverlayDialog];
    });
    (0, _react.act)(() => root.render(/*#__PURE__*/(0, _react.createElement)(Bare)));
    const bare = byId('bare');
    (0, _vitest.expect)(document.activeElement).toBe(bare);
    (0, _vitest.expect)(bare.tabIndex).toBe(-1);
    (0, _react.act)(() => root.unmount());
    container.remove();
    h.unmount();
  });
  (0, _vitest.it)('Tab wraps both ways, including over a focusable that appears after mount', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: true,
      onClose
    }));
    byId('last').focus();
    let ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true
    });
    byId('last').dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true,
      shiftKey: true
    });
    byId('first').dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('last'));

    // A focusable mounted later (WhatIfPanel appearing inside the dock) joins the wrap —
    // the list is read at keydown, never cached at mount.
    h.rerender(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: true,
      onClose,
      lateFocusable: true
    }));
    byId('late').focus();
    ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true
    });
    byId('late').dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    h.unmount();
  });
  (0, _vitest.it)('Tab on the childless root is held, not released to the page behind', () => {
    var _s5 = $RefreshSig$();
    const onClose = _vitest.vi.fn();
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    function Bare() {
      _s5();
      const ref = (0, _useOverlayDialog.useOverlayDialog)(onClose);
      return /*#__PURE__*/(0, _react.createElement)('aside', {
        id: 'bare',
        ref
      });
    }
    _s5(Bare, "fstH1UTjP4Futc6HHuL2J6ti2uk=", false, function () {
      return [_useOverlayDialog.useOverlayDialog];
    });
    (0, _react.act)(() => root.render(/*#__PURE__*/(0, _react.createElement)(Bare)));
    const bare = byId('bare');
    const ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true
    });
    bare.dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(bare);
    (0, _react.act)(() => root.unmount());
    container.remove();
  });
  (0, _vitest.it)('Escape calls onClose while enabled, and never while disabled', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: true,
      onClose
    }));
    key(byId('first'), 'Escape');
    (0, _vitest.expect)(onClose).toHaveBeenCalledTimes(1);
    // enabled false → the listener is detached; Escape on the same tree does nothing.
    h.rerender(/*#__PURE__*/(0, _react.createElement)(DockHarness, {
      open: true,
      enabled: false,
      onClose
    }));
    key(byId('first'), 'Escape');
    (0, _vitest.expect)(onClose).toHaveBeenCalledTimes(1);
    h.unmount();
  });
  (0, _vitest.it)('an invoker that unmounted before the overlay closes does not throw', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: false,
      onClose
    }));
    byId('invoker').focus();
    h.rerender(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: true,
      onClose
    }));
    (0, _vitest.expect)(() => h.rerender(/*#__PURE__*/(0, _react.createElement)(PanelHarness, {
      open: true,
      onClose,
      invokerPresent: false
    }))).not.toThrow();
    (0, _vitest.expect)(() => h.unmount()).not.toThrow();
  });
  (0, _vitest.it)('a closed details entry: Tab from its summary wraps (the hidden Copy button is not the tail)', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DetailsHarness, {
      detailsOpen: false,
      onClose
    }));
    // The summary is the last VISIBLE focusable; the Copy button inside the closed
    // details is not tabbable and must not be counted as the wrap target.
    byId('sum').focus();
    const ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true
    });
    byId('sum').dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    // Backward wrap from the head lands on the visible summary, never the hidden button.
    const back = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true,
      shiftKey: true
    });
    byId('first').dispatchEvent(back);
    (0, _vitest.expect)(back.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('sum'));
    h.unmount();
  });
  (0, _vitest.it)('opening the details entry joins the trap: Tab from the Copy button wraps', () => {
    const onClose = _vitest.vi.fn();
    const h = mount(/*#__PURE__*/(0, _react.createElement)(DetailsHarness, {
      detailsOpen: false,
      onClose
    }));
    h.rerender(/*#__PURE__*/(0, _react.createElement)(DetailsHarness, {
      detailsOpen: true,
      onClose
    }));
    byId('copy').focus();
    const ev = new KeyboardEvent('keydown', {
      key: 'Tab',
      bubbles: true,
      cancelable: true
    });
    byId('copy').dispatchEvent(ev);
    (0, _vitest.expect)(ev.defaultPrevented).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe(byId('first'));
    h.unmount();
  });
});
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "DockHarness");
$RefreshReg$(_c2, "PanelHarness");
$RefreshReg$(_c3, "PanelBody");
$RefreshReg$(_c4, "DetailsHarness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfdXNlT3ZlcmxheURpYWxvZyIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiX3MzIiwiZ2xvYmFsVGhpcyIsIklTX1JFQUNUX0FDVF9FTlZJUk9OTUVOVCIsImJ5SWQiLCJpZCIsImVsIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsIkVycm9yIiwia2V5IiwiayIsInNoaWZ0IiwiZGlzcGF0Y2hFdmVudCIsIktleWJvYXJkRXZlbnQiLCJidWJibGVzIiwiY2FuY2VsYWJsZSIsInNoaWZ0S2V5IiwibW91bnQiLCJ0cmVlIiwiY29udGFpbmVyIiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwicmVuZGVyIiwicmVyZW5kZXIiLCJuZXh0IiwidW5tb3VudCIsInJlbW92ZSIsIkRvY2tIYXJuZXNzIiwib3BlbiIsImVuYWJsZWQiLCJvbkNsb3NlIiwibGF0ZUZvY3VzYWJsZSIsInJlZiIsInVzZU92ZXJsYXlEaWFsb2ciLCJ0eXBlIiwiX2MiLCJQYW5lbEhhcm5lc3MiLCJpbnZva2VyUHJlc2VudCIsIlBhbmVsQm9keSIsIl9jMiIsIl9jMyIsIkRldGFpbHNIYXJuZXNzIiwiZGV0YWlsc09wZW4iLCJfYzQiLCJkZXNjcmliZSIsIml0IiwidmkiLCJmbiIsImgiLCJmb2N1cyIsImV4cGVjdCIsImFjdGl2ZUVsZW1lbnQiLCJ0b0JlIiwiX3M0IiwiQmFyZSIsImJhcmUiLCJ0YWJJbmRleCIsImV2IiwiZGVmYXVsdFByZXZlbnRlZCIsIl9zNSIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsIm5vdCIsInRvVGhyb3ciLCJiYWNrIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidXNlT3ZlcmxheURpYWxvZy50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGhhcHB5LWRvbVxuLy8gVGhlIG92ZXJsYXktZGlhbG9nIGNvbnRyYWN0IChSMy02MTApOiBmb2N1cyBpbiBvbiBvcGVuLCBUYWIgd3JhcCByZWFkIGF0IGtleWRvd24sIEVzY2FwZVxuLy8gb25seSB3aGlsZSBlbmFibGVkLCBpbnZva2VyIHJlc3RvcmVkIG9uIGNsb3NlIOKAlCBvdmVyIGEgcmVhbCBjb21wb25lbnQgdHJlZSBpbiBhIERPTSwgbm90XG4vLyBhIHN0YXRpYyByZW5kZXIsIGJlY2F1c2UgZXZlcnkgb25lIG9mIHRob3NlIGlzIGFuIGVmZmVjdC0gb3IgZXZlbnQtdGltZSBiZWhhdmlvdXIuIFRoZVxuLy8gdHdvIGhhcm5lc3Mgc2hhcGVzIG1pcnJvciB0aGUgdHdvIGNhbGwgc2l0ZXM6IHRoZSBkb2NrIChBcHAgaG9sZHMgdGhlIGhvb2sgYmVoaW5kIGFuXG4vLyBgZW5hYmxlZGAgZmxhZywgdGhlIGVsZW1lbnQgY29uZGl0aW9uYWxseSByZW5kZXJlZCkgYW5kIHRoZSB3b3JrYm9vayBwYW5lbCAodGhlIG1vdW50ZWRcbi8vIGNvbXBvbmVudCBob2xkcyB0aGUgaG9vayBpdHNlbGYsIGVuYWJsZWQgYnkgZGVmYXVsdCkuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYWN0LCBjcmVhdGVFbGVtZW50LCB0eXBlIFJlYWN0RWxlbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QsIHR5cGUgUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheURpYWxvZyB9IGZyb20gJy4vdXNlT3ZlcmxheURpYWxvZy50cyc7XG5cbi8vIHJlYWN0LWRvbS9jbGllbnQgcmVxdWlyZXMgdGhlIGFjdCBlbnZpcm9ubWVudCBmbGFnIHRvIGZsdXNoIGVmZmVjdHMgZGV0ZXJtaW5pc3RpY2FsbHkuXG4oZ2xvYmFsVGhpcyBhcyB1bmtub3duIGFzIHsgSVNfUkVBQ1RfQUNUX0VOVklST05NRU5UOiBib29sZWFuIH0pLklTX1JFQUNUX0FDVF9FTlZJUk9OTUVOVCA9IHRydWU7XG5cbmNvbnN0IGJ5SWQgPSAoaWQ6IHN0cmluZyk6IEhUTUxFbGVtZW50ID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmIChlbCA9PT0gbnVsbCkgdGhyb3cgbmV3IEVycm9yKGBubyAjJHtpZH1gKTtcbiAgcmV0dXJuIGVsO1xufTtcblxuLyoqIERpc3BhdGNoIGEga2V5ZG93biBmcm9tIHRoZSBlbGVtZW50IChidWJibGVzIHRvIHRoZSBvdmVybGF5IHJvb3QsIGFzIGEgcmVhbCBrZXkgZG9lcykuICovXG5mdW5jdGlvbiBrZXkoZWw6IEVsZW1lbnQsIGs6IHN0cmluZywgc2hpZnQgPSBmYWxzZSk6IHZvaWQge1xuICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgeyBrZXk6IGssIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUsIHNoaWZ0S2V5OiBzaGlmdCB9KSk7XG59XG5cbmludGVyZmFjZSBNb3VudEhhbmRsZSB7XG4gIHJlcmVuZGVyOiAobmV4dDogUmVhY3RFbGVtZW50KSA9PiB2b2lkO1xuICB1bm1vdW50OiAoKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBtb3VudCh0cmVlOiBSZWFjdEVsZW1lbnQpOiBNb3VudEhhbmRsZSB7XG4gIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGNvbnRhaW5lcik7XG4gIGNvbnN0IHJvb3Q6IFJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gIGFjdCgoKSA9PiByb290LnJlbmRlcih0cmVlKSk7XG4gIHJldHVybiB7XG4gICAgcmVyZW5kZXI6IChuZXh0KSA9PiBhY3QoKCkgPT4gcm9vdC5yZW5kZXIobmV4dCkpLFxuICAgIHVubW91bnQ6ICgpID0+IHtcbiAgICAgIGFjdCgoKSA9PiByb290LnVubW91bnQoKSk7XG4gICAgICBjb250YWluZXIucmVtb3ZlKCk7XG4gICAgfSxcbiAgfTtcbn1cblxuLy8g4oCUIFRoZSBkb2NrIHNoYXBlOiBBcHAgb3ducyB0aGUgaG9vayBhbmQgdGhlIGNvbmRpdGlvbmFsIGVsZW1lbnQsIGBlbmFibGVkYCBnYXRpbmcgYm90aC4g4oCUXG5mdW5jdGlvbiBEb2NrSGFybmVzcyh7IG9wZW4sIGVuYWJsZWQsIG9uQ2xvc2UsIGxhdGVGb2N1c2FibGUgfTogeyBvcGVuOiBib29sZWFuOyBlbmFibGVkOiBib29sZWFuOyBvbkNsb3NlOiAoKSA9PiB2b2lkOyBsYXRlRm9jdXNhYmxlPzogYm9vbGVhbiB9KSB7XG4gIGNvbnN0IHJlZiA9IHVzZU92ZXJsYXlEaWFsb2c8SFRNTERpdkVsZW1lbnQ+KG9uQ2xvc2UsIHsgZW5hYmxlZCB9KTtcbiAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoXG4gICAgJ2RpdicsXG4gICAgbnVsbCxcbiAgICBjcmVhdGVFbGVtZW50KCdidXR0b24nLCB7IHR5cGU6ICdidXR0b24nLCBpZDogJ2ludm9rZXInIH0sICdJbnNwZWN0JyksXG4gICAgb3BlbiAmJlxuICAgICAgY3JlYXRlRWxlbWVudChcbiAgICAgICAgJ2RpdicsXG4gICAgICAgIHsgaWQ6ICdvdmVybGF5JywgcmVmIH0sXG4gICAgICAgIGNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicsIHsgdHlwZTogJ2J1dHRvbicsIGlkOiAnZmlyc3QnIH0sICdGaXJzdCcpLFxuICAgICAgICBjcmVhdGVFbGVtZW50KCdidXR0b24nLCB7IHR5cGU6ICdidXR0b24nLCBpZDogJ2xhc3QnIH0sICdMYXN0JyksXG4gICAgICAgIGxhdGVGb2N1c2FibGUgPT09IHRydWUgJiYgY3JlYXRlRWxlbWVudCgnYnV0dG9uJywgeyB0eXBlOiAnYnV0dG9uJywgaWQ6ICdsYXRlJyB9LCAnTGF0ZScpLFxuICAgICAgKSxcbiAgKTtcbn1cblxuLy8g4oCUIFRoZSBwYW5lbCBzaGFwZTogdGhlIG1vdW50ZWQgY29tcG9uZW50IG93bnMgdGhlIGhvb2ssIGVuYWJsZWQgZGVmYXVsdHMgdG8gdHJ1ZS4g4oCUXG5mdW5jdGlvbiBQYW5lbEhhcm5lc3MoeyBvcGVuLCBvbkNsb3NlLCBpbnZva2VyUHJlc2VudCA9IHRydWUgfTogeyBvcGVuOiBib29sZWFuOyBvbkNsb3NlOiAoKSA9PiB2b2lkOyBpbnZva2VyUHJlc2VudD86IGJvb2xlYW4gfSkge1xuICByZXR1cm4gY3JlYXRlRWxlbWVudChcbiAgICAnZGl2JyxcbiAgICBudWxsLFxuICAgIGludm9rZXJQcmVzZW50ICYmIGNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicsIHsgdHlwZTogJ2J1dHRvbicsIGlkOiAnaW52b2tlcicgfSwgJ1dvcmtib29rJyksXG4gICAgb3BlbiAmJlxuICAgICAgY3JlYXRlRWxlbWVudChcbiAgICAgICAgJ2FzaWRlJyxcbiAgICAgICAgeyBpZDogJ3BhbmVsJyB9LFxuICAgICAgICBjcmVhdGVFbGVtZW50KFBhbmVsQm9keSwgeyBvbkNsb3NlIH0pLFxuICAgICAgKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gUGFuZWxCb2R5KHsgb25DbG9zZSB9OiB7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICBjb25zdCByZWYgPSB1c2VPdmVybGF5RGlhbG9nPEhUTUxFbGVtZW50PihvbkNsb3NlKTtcbiAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoJ2FzaWRlJywgeyBpZDogJ292ZXJsYXknLCByZWYgfSwgY3JlYXRlRWxlbWVudCgnYnV0dG9uJywgeyB0eXBlOiAnYnV0dG9uJywgaWQ6ICdmaXJzdCcgfSwgJ0Nsb3NlJykpO1xufVxuXG4vLyDigJQgVGhlIHZvY2FidWxhcnkgc2hhcGU6IDxkZXRhaWxzPjxzdW1tYXJ5PiB0b2dnbGVzIHdpdGggZm9jdXNhYmxlIGNvbnRlbnQgaGlkZGVuIHdoaWxlXG4vLyBjbG9zZWQg4oCUIHRoZSByb3VuZC0yIHRyYXAgZGVmZWN0OiBzdW1tYXJ5IGlzIGltcGxpY2l0bHkgdGFiYmFibGUsIHRoZSBjbG9zZWQgY29udGVudCBpc1xuLy8gbm90LCBhbmQgdGhlIHRyYXAgbXVzdCByZWFkIHRoZSBSRUFMIHRhYiBvcmRlciwgbm90IHRoZSBxdWVyeVNlbGVjdG9yQWxsIGhpdCBsaXN0LiDigJRcbmZ1bmN0aW9uIERldGFpbHNIYXJuZXNzKHsgZGV0YWlsc09wZW4sIG9uQ2xvc2UgfTogeyBkZXRhaWxzT3BlbjogYm9vbGVhbjsgb25DbG9zZTogKCkgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IHJlZiA9IHVzZU92ZXJsYXlEaWFsb2c8SFRNTERpdkVsZW1lbnQ+KG9uQ2xvc2UpO1xuICByZXR1cm4gY3JlYXRlRWxlbWVudChcbiAgICAnZGl2JyxcbiAgICB7IGlkOiAnb3ZlcmxheScsIHJlZiB9LFxuICAgIGNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicsIHsgdHlwZTogJ2J1dHRvbicsIGlkOiAnZmlyc3QnIH0sICdGaXJzdCcpLFxuICAgIGNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGV0YWlscycsXG4gICAgICB7IGlkOiAnZW50cnknLCBvcGVuOiBkZXRhaWxzT3BlbiB9LFxuICAgICAgY3JlYXRlRWxlbWVudCgnc3VtbWFyeScsIHsgaWQ6ICdzdW0nIH0sICdlbnRyeScpLFxuICAgICAgY3JlYXRlRWxlbWVudCgnYnV0dG9uJywgeyB0eXBlOiAnYnV0dG9uJywgaWQ6ICdjb3B5JyB9LCAnQ29weScpLFxuICAgICksXG4gICk7XG59XG5cbmRlc2NyaWJlKCd1c2VPdmVybGF5RGlhbG9nIOKAlCB0aGUgb3ZlcmxheSBjb250cmFjdCAoUjMtNjEwKScsICgpID0+IHtcbiAgaXQoJ21vdmVzIGZvY3VzIHRvIHRoZSBmaXJzdCBmb2N1c2FibGUgaW5zaWRlIG9uIGVuYWJsZSwgYW5kIHJlc3RvcmVzIHRoZSBpbnZva2VyIG9uIGRpc2FibGUnLCAoKSA9PiB7XG4gICAgY29uc3Qgb25DbG9zZSA9IHZpLmZuKCk7XG4gICAgY29uc3QgaCA9IG1vdW50KGNyZWF0ZUVsZW1lbnQoRG9ja0hhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgZW5hYmxlZDogZmFsc2UsIG9uQ2xvc2UgfSkpO1xuICAgIGJ5SWQoJ2ludm9rZXInKS5mb2N1cygpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJ5SWQoJ2ludm9rZXInKSk7XG4gICAgaC5yZXJlbmRlcihjcmVhdGVFbGVtZW50KERvY2tIYXJuZXNzLCB7IG9wZW46IHRydWUsIGVuYWJsZWQ6IHRydWUsIG9uQ2xvc2UgfSkpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJ5SWQoJ2ZpcnN0JykpO1xuICAgIGgucmVyZW5kZXIoY3JlYXRlRWxlbWVudChEb2NrSGFybmVzcywgeyBvcGVuOiB0cnVlLCBlbmFibGVkOiBmYWxzZSwgb25DbG9zZSB9KSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoYnlJZCgnaW52b2tlcicpKTtcbiAgICBoLnVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBtb3VudGVkLXBhbmVsIHNoYXBlIGNhcHR1cmVzIHRoZSBpbnZva2VyIGFuZCByZXN0b3JlcyBpdCB3aGVuIHRoZSBwYW5lbCB1bm1vdW50cycsICgpID0+IHtcbiAgICBjb25zdCBvbkNsb3NlID0gdmkuZm4oKTtcbiAgICBjb25zdCBoID0gbW91bnQoY3JlYXRlRWxlbWVudChQYW5lbEhhcm5lc3MsIHsgb3BlbjogZmFsc2UsIG9uQ2xvc2UgfSkpO1xuICAgIGJ5SWQoJ2ludm9rZXInKS5mb2N1cygpO1xuICAgIGgucmVyZW5kZXIoY3JlYXRlRWxlbWVudChQYW5lbEhhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgb25DbG9zZSB9KSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoYnlJZCgnZmlyc3QnKSk7XG4gICAgLy8gVGhlIHBhbmVsJ3Mgb3duIGNvbmRpdGlvbmFsIHVubW91bnQgKEFwcCBrZWVwcyByZW5kZXJpbmcgdGhlIGhlYWRlciB0b2dnbGUpIHJ1bnMgdGhlXG4gICAgLy8gcmVzdG9yZTsgdGhlIGludm9rZXIgc3Vydml2ZXMsIGFzIHRoZSByZWFsIHJrLXJldmlldy10b2dnbGUgZG9lcy5cbiAgICBoLnJlcmVuZGVyKGNyZWF0ZUVsZW1lbnQoUGFuZWxIYXJuZXNzLCB7IG9wZW46IGZhbHNlLCBvbkNsb3NlIH0pKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShieUlkKCdpbnZva2VyJykpO1xuICAgIGgudW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnZm9jdXMgbGFuZHMgb24gdGhlIG92ZXJsYXkgcm9vdCBpdHNlbGYgd2hlbiBpdCBoYXMgbm8gZm9jdXNhYmxlIGNoaWxkJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uQ2xvc2UgPSB2aS5mbigpO1xuICAgIGNvbnN0IGggPSBtb3VudChjcmVhdGVFbGVtZW50KERvY2tIYXJuZXNzLCB7IG9wZW46IHRydWUsIGVuYWJsZWQ6IHRydWUsIG9uQ2xvc2UgfSkpO1xuICAgIC8vIFRoZSBkZWZhdWx0IGhhcm5lc3MgaGFzIGZvY3VzYWJsZXM7IHJlLXJlbmRlciBhIGJhcmUtcm9vdCB2YXJpYW50IHRocm91Z2ggdGhlIHBhbmVsXG4gICAgLy8gc2hhcGUgd2l0aCBhbiBlbXB0eSBvdmVybGF5IHRvIGhpdCB0aGUgZmFsbGJhY2suXG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIGNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gICAgZnVuY3Rpb24gQmFyZSgpIHtcbiAgICAgIGNvbnN0IHJlZiA9IHVzZU92ZXJsYXlEaWFsb2c8SFRNTEVsZW1lbnQ+KG9uQ2xvc2UpO1xuICAgICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoJ2FzaWRlJywgeyBpZDogJ2JhcmUnLCByZWYgfSk7XG4gICAgfVxuICAgIGFjdCgoKSA9PiByb290LnJlbmRlcihjcmVhdGVFbGVtZW50KEJhcmUpKSk7XG4gICAgY29uc3QgYmFyZSA9IGJ5SWQoJ2JhcmUnKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShiYXJlKTtcbiAgICBleHBlY3QoYmFyZS50YWJJbmRleCkudG9CZSgtMSk7XG4gICAgYWN0KCgpID0+IHJvb3QudW5tb3VudCgpKTtcbiAgICBjb250YWluZXIucmVtb3ZlKCk7XG4gICAgaC51bm1vdW50KCk7XG4gIH0pO1xuXG4gIGl0KCdUYWIgd3JhcHMgYm90aCB3YXlzLCBpbmNsdWRpbmcgb3ZlciBhIGZvY3VzYWJsZSB0aGF0IGFwcGVhcnMgYWZ0ZXIgbW91bnQnLCAoKSA9PiB7XG4gICAgY29uc3Qgb25DbG9zZSA9IHZpLmZuKCk7XG4gICAgY29uc3QgaCA9IG1vdW50KGNyZWF0ZUVsZW1lbnQoRG9ja0hhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgZW5hYmxlZDogdHJ1ZSwgb25DbG9zZSB9KSk7XG4gICAgYnlJZCgnbGFzdCcpLmZvY3VzKCk7XG4gICAgbGV0IGV2ID0gbmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCB7IGtleTogJ1RhYicsIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUgfSk7XG4gICAgYnlJZCgnbGFzdCcpLmRpc3BhdGNoRXZlbnQoZXYpO1xuICAgIGV4cGVjdChldi5kZWZhdWx0UHJldmVudGVkKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJ5SWQoJ2ZpcnN0JykpO1xuXG4gICAgZXYgPSBuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIHsga2V5OiAnVGFiJywgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSwgc2hpZnRLZXk6IHRydWUgfSk7XG4gICAgYnlJZCgnZmlyc3QnKS5kaXNwYXRjaEV2ZW50KGV2KTtcbiAgICBleHBlY3QoZXYuZGVmYXVsdFByZXZlbnRlZCkudG9CZSh0cnVlKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShieUlkKCdsYXN0JykpO1xuXG4gICAgLy8gQSBmb2N1c2FibGUgbW91bnRlZCBsYXRlciAoV2hhdElmUGFuZWwgYXBwZWFyaW5nIGluc2lkZSB0aGUgZG9jaykgam9pbnMgdGhlIHdyYXAg4oCUXG4gICAgLy8gdGhlIGxpc3QgaXMgcmVhZCBhdCBrZXlkb3duLCBuZXZlciBjYWNoZWQgYXQgbW91bnQuXG4gICAgaC5yZXJlbmRlcihjcmVhdGVFbGVtZW50KERvY2tIYXJuZXNzLCB7IG9wZW46IHRydWUsIGVuYWJsZWQ6IHRydWUsIG9uQ2xvc2UsIGxhdGVGb2N1c2FibGU6IHRydWUgfSkpO1xuICAgIGJ5SWQoJ2xhdGUnKS5mb2N1cygpO1xuICAgIGV2ID0gbmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCB7IGtleTogJ1RhYicsIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUgfSk7XG4gICAgYnlJZCgnbGF0ZScpLmRpc3BhdGNoRXZlbnQoZXYpO1xuICAgIGV4cGVjdChldi5kZWZhdWx0UHJldmVudGVkKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJ5SWQoJ2ZpcnN0JykpO1xuICAgIGgudW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnVGFiIG9uIHRoZSBjaGlsZGxlc3Mgcm9vdCBpcyBoZWxkLCBub3QgcmVsZWFzZWQgdG8gdGhlIHBhZ2UgYmVoaW5kJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uQ2xvc2UgPSB2aS5mbigpO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgICBjb25zdCByb290ID0gY3JlYXRlUm9vdChjb250YWluZXIpO1xuICAgIGZ1bmN0aW9uIEJhcmUoKSB7XG4gICAgICBjb25zdCByZWYgPSB1c2VPdmVybGF5RGlhbG9nPEhUTUxFbGVtZW50PihvbkNsb3NlKTtcbiAgICAgIHJldHVybiBjcmVhdGVFbGVtZW50KCdhc2lkZScsIHsgaWQ6ICdiYXJlJywgcmVmIH0pO1xuICAgIH1cbiAgICBhY3QoKCkgPT4gcm9vdC5yZW5kZXIoY3JlYXRlRWxlbWVudChCYXJlKSkpO1xuICAgIGNvbnN0IGJhcmUgPSBieUlkKCdiYXJlJyk7XG4gICAgY29uc3QgZXYgPSBuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIHsga2V5OiAnVGFiJywgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSB9KTtcbiAgICBiYXJlLmRpc3BhdGNoRXZlbnQoZXYpO1xuICAgIGV4cGVjdChldi5kZWZhdWx0UHJldmVudGVkKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJhcmUpO1xuICAgIGFjdCgoKSA9PiByb290LnVubW91bnQoKSk7XG4gICAgY29udGFpbmVyLnJlbW92ZSgpO1xuICB9KTtcblxuICBpdCgnRXNjYXBlIGNhbGxzIG9uQ2xvc2Ugd2hpbGUgZW5hYmxlZCwgYW5kIG5ldmVyIHdoaWxlIGRpc2FibGVkJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uQ2xvc2UgPSB2aS5mbigpO1xuICAgIGNvbnN0IGggPSBtb3VudChjcmVhdGVFbGVtZW50KERvY2tIYXJuZXNzLCB7IG9wZW46IHRydWUsIGVuYWJsZWQ6IHRydWUsIG9uQ2xvc2UgfSkpO1xuICAgIGtleShieUlkKCdmaXJzdCcpLCAnRXNjYXBlJyk7XG4gICAgZXhwZWN0KG9uQ2xvc2UpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICAvLyBlbmFibGVkIGZhbHNlIOKGkiB0aGUgbGlzdGVuZXIgaXMgZGV0YWNoZWQ7IEVzY2FwZSBvbiB0aGUgc2FtZSB0cmVlIGRvZXMgbm90aGluZy5cbiAgICBoLnJlcmVuZGVyKGNyZWF0ZUVsZW1lbnQoRG9ja0hhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgZW5hYmxlZDogZmFsc2UsIG9uQ2xvc2UgfSkpO1xuICAgIGtleShieUlkKCdmaXJzdCcpLCAnRXNjYXBlJyk7XG4gICAgZXhwZWN0KG9uQ2xvc2UpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBoLnVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ2FuIGludm9rZXIgdGhhdCB1bm1vdW50ZWQgYmVmb3JlIHRoZSBvdmVybGF5IGNsb3NlcyBkb2VzIG5vdCB0aHJvdycsICgpID0+IHtcbiAgICBjb25zdCBvbkNsb3NlID0gdmkuZm4oKTtcbiAgICBjb25zdCBoID0gbW91bnQoY3JlYXRlRWxlbWVudChQYW5lbEhhcm5lc3MsIHsgb3BlbjogZmFsc2UsIG9uQ2xvc2UgfSkpO1xuICAgIGJ5SWQoJ2ludm9rZXInKS5mb2N1cygpO1xuICAgIGgucmVyZW5kZXIoY3JlYXRlRWxlbWVudChQYW5lbEhhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgb25DbG9zZSB9KSk7XG4gICAgZXhwZWN0KCgpID0+IGgucmVyZW5kZXIoY3JlYXRlRWxlbWVudChQYW5lbEhhcm5lc3MsIHsgb3BlbjogdHJ1ZSwgb25DbG9zZSwgaW52b2tlclByZXNlbnQ6IGZhbHNlIH0pKSkubm90LnRvVGhyb3coKTtcbiAgICBleHBlY3QoKCkgPT4gaC51bm1vdW50KCkpLm5vdC50b1Rocm93KCk7XG4gIH0pO1xuXG4gIGl0KCdhIGNsb3NlZCBkZXRhaWxzIGVudHJ5OiBUYWIgZnJvbSBpdHMgc3VtbWFyeSB3cmFwcyAodGhlIGhpZGRlbiBDb3B5IGJ1dHRvbiBpcyBub3QgdGhlIHRhaWwpJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uQ2xvc2UgPSB2aS5mbigpO1xuICAgIGNvbnN0IGggPSBtb3VudChjcmVhdGVFbGVtZW50KERldGFpbHNIYXJuZXNzLCB7IGRldGFpbHNPcGVuOiBmYWxzZSwgb25DbG9zZSB9KSk7XG4gICAgLy8gVGhlIHN1bW1hcnkgaXMgdGhlIGxhc3QgVklTSUJMRSBmb2N1c2FibGU7IHRoZSBDb3B5IGJ1dHRvbiBpbnNpZGUgdGhlIGNsb3NlZFxuICAgIC8vIGRldGFpbHMgaXMgbm90IHRhYmJhYmxlIGFuZCBtdXN0IG5vdCBiZSBjb3VudGVkIGFzIHRoZSB3cmFwIHRhcmdldC5cbiAgICBieUlkKCdzdW0nKS5mb2N1cygpO1xuICAgIGNvbnN0IGV2ID0gbmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCB7IGtleTogJ1RhYicsIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUgfSk7XG4gICAgYnlJZCgnc3VtJykuZGlzcGF0Y2hFdmVudChldik7XG4gICAgZXhwZWN0KGV2LmRlZmF1bHRQcmV2ZW50ZWQpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoYnlJZCgnZmlyc3QnKSk7XG4gICAgLy8gQmFja3dhcmQgd3JhcCBmcm9tIHRoZSBoZWFkIGxhbmRzIG9uIHRoZSB2aXNpYmxlIHN1bW1hcnksIG5ldmVyIHRoZSBoaWRkZW4gYnV0dG9uLlxuICAgIGNvbnN0IGJhY2sgPSBuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIHsga2V5OiAnVGFiJywgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSwgc2hpZnRLZXk6IHRydWUgfSk7XG4gICAgYnlJZCgnZmlyc3QnKS5kaXNwYXRjaEV2ZW50KGJhY2spO1xuICAgIGV4cGVjdChiYWNrLmRlZmF1bHRQcmV2ZW50ZWQpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoYnlJZCgnc3VtJykpO1xuICAgIGgudW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnb3BlbmluZyB0aGUgZGV0YWlscyBlbnRyeSBqb2lucyB0aGUgdHJhcDogVGFiIGZyb20gdGhlIENvcHkgYnV0dG9uIHdyYXBzJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uQ2xvc2UgPSB2aS5mbigpO1xuICAgIGNvbnN0IGggPSBtb3VudChjcmVhdGVFbGVtZW50KERldGFpbHNIYXJuZXNzLCB7IGRldGFpbHNPcGVuOiBmYWxzZSwgb25DbG9zZSB9KSk7XG4gICAgaC5yZXJlbmRlcihjcmVhdGVFbGVtZW50KERldGFpbHNIYXJuZXNzLCB7IGRldGFpbHNPcGVuOiB0cnVlLCBvbkNsb3NlIH0pKTtcbiAgICBieUlkKCdjb3B5JykuZm9jdXMoKTtcbiAgICBjb25zdCBldiA9IG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgeyBrZXk6ICdUYWInLCBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlIH0pO1xuICAgIGJ5SWQoJ2NvcHknKS5kaXNwYXRjaEV2ZW50KGV2KTtcbiAgICBleHBlY3QoZXYuZGVmYXVsdFByZXZlbnRlZCkudG9CZSh0cnVlKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShieUlkKCdmaXJzdCcpKTtcbiAgICBoLnVubW91bnQoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFPQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxpQkFBQSxHQUFBSCxPQUFBO0FBQXlELElBQUFJLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUE7RUFBQUUsR0FBQSxHQUFBRixZQUFBLElBVnpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUE7QUFDQ0csVUFBVSxDQUFzREMsd0JBQXdCLEdBQUcsSUFBSTtBQUVoRyxNQUFNQyxJQUFJLEdBQUlDLEVBQVUsSUFBa0I7RUFDeEMsTUFBTUMsRUFBRSxHQUFHQyxRQUFRLENBQUNDLGNBQWMsQ0FBQ0gsRUFBRSxDQUFDO0VBQ3RDLElBQUlDLEVBQUUsS0FBSyxJQUFJLEVBQUUsTUFBTSxJQUFJRyxLQUFLLENBQUMsT0FBT0osRUFBRSxFQUFFLENBQUM7RUFDN0MsT0FBT0MsRUFBRTtBQUNYLENBQUM7O0FBRUQ7QUFDQSxTQUFTSSxHQUFHQSxDQUFDSixFQUFXLEVBQUVLLENBQVMsRUFBRUMsS0FBSyxHQUFHLEtBQUssRUFBUTtFQUN4RE4sRUFBRSxDQUFDTyxhQUFhLENBQUMsSUFBSUMsYUFBYSxDQUFDLFNBQVMsRUFBRTtJQUFFSixHQUFHLEVBQUVDLENBQUM7SUFBRUksT0FBTyxFQUFFLElBQUk7SUFBRUMsVUFBVSxFQUFFLElBQUk7SUFBRUMsUUFBUSxFQUFFTDtFQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzlHO0FBT0EsU0FBU00sS0FBS0EsQ0FBQ0MsSUFBa0IsRUFBZTtFQUM5QyxNQUFNQyxTQUFTLEdBQUdiLFFBQVEsQ0FBQ2MsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMvQ2QsUUFBUSxDQUFDZSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0gsU0FBUyxDQUFDO0VBQ3BDLE1BQU1JLElBQVUsR0FBRyxJQUFBQyxrQkFBVSxFQUFDTCxTQUFTLENBQUM7RUFDeEMsSUFBQU0sVUFBRyxFQUFDLE1BQU1GLElBQUksQ0FBQ0csTUFBTSxDQUFDUixJQUFJLENBQUMsQ0FBQztFQUM1QixPQUFPO0lBQ0xTLFFBQVEsRUFBR0MsSUFBSSxJQUFLLElBQUFILFVBQUcsRUFBQyxNQUFNRixJQUFJLENBQUNHLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDLENBQUM7SUFDaERDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO01BQ2IsSUFBQUosVUFBRyxFQUFDLE1BQU1GLElBQUksQ0FBQ00sT0FBTyxDQUFDLENBQUMsQ0FBQztNQUN6QlYsU0FBUyxDQUFDVyxNQUFNLENBQUMsQ0FBQztJQUNwQjtFQUNGLENBQUM7QUFDSDs7QUFFQTtBQUNBLFNBQVNDLFdBQVdBLENBQUM7RUFBRUMsSUFBSTtFQUFFQyxPQUFPO0VBQUVDLE9BQU87RUFBRUM7QUFBaUcsQ0FBQyxFQUFFO0VBQUF0QyxFQUFBO0VBQ2pKLE1BQU11QyxHQUFHLEdBQUcsSUFBQUMsa0NBQWdCLEVBQWlCSCxPQUFPLEVBQUU7SUFBRUQ7RUFBUSxDQUFDLENBQUM7RUFDbEUsb0JBQU8sSUFBQWIsb0JBQWEsRUFDbEIsS0FBSyxFQUNMLElBQUksZUFDSixJQUFBQSxvQkFBYSxFQUFDLFFBQVEsRUFBRTtJQUFFa0IsSUFBSSxFQUFFLFFBQVE7SUFBRWxDLEVBQUUsRUFBRTtFQUFVLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDckU0QixJQUFJLGlCQUNGLElBQUFaLG9CQUFhLEVBQ1gsS0FBSyxFQUNMO0lBQUVoQixFQUFFLEVBQUUsU0FBUztJQUFFZ0M7RUFBSSxDQUFDLGVBQ3RCLElBQUFoQixvQkFBYSxFQUFDLFFBQVEsRUFBRTtJQUFFa0IsSUFBSSxFQUFFLFFBQVE7SUFBRWxDLEVBQUUsRUFBRTtFQUFRLENBQUMsRUFBRSxPQUFPLENBQUMsZUFDakUsSUFBQWdCLG9CQUFhLEVBQUMsUUFBUSxFQUFFO0lBQUVrQixJQUFJLEVBQUUsUUFBUTtJQUFFbEMsRUFBRSxFQUFFO0VBQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUMvRCtCLGFBQWEsS0FBSyxJQUFJLGlCQUFJLElBQUFmLG9CQUFhLEVBQUMsUUFBUSxFQUFFO0lBQUVrQixJQUFJLEVBQUUsUUFBUTtJQUFFbEMsRUFBRSxFQUFFO0VBQU8sQ0FBQyxFQUFFLE1BQU0sQ0FDMUYsQ0FDSixDQUFDO0FBQ0g7O0FBRUE7QUFBQVAsRUFBQSxDQWpCU2tDLFdBQVc7RUFBQSxRQUNOTSxrQ0FBZ0I7QUFBQTtBQUFBRSxFQUFBLEdBRHJCUixXQUFXO0FBa0JwQixTQUFTUyxZQUFZQSxDQUFDO0VBQUVSLElBQUk7RUFBRUUsT0FBTztFQUFFTyxjQUFjLEdBQUc7QUFBdUUsQ0FBQyxFQUFFO0VBQ2hJLG9CQUFPLElBQUFyQixvQkFBYSxFQUNsQixLQUFLLEVBQ0wsSUFBSSxFQUNKcUIsY0FBYyxpQkFBSSxJQUFBckIsb0JBQWEsRUFBQyxRQUFRLEVBQUU7SUFBRWtCLElBQUksRUFBRSxRQUFRO0lBQUVsQyxFQUFFLEVBQUU7RUFBVSxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQ3hGNEIsSUFBSSxpQkFDRixJQUFBWixvQkFBYSxFQUNYLE9BQU8sRUFDUDtJQUFFaEIsRUFBRSxFQUFFO0VBQVEsQ0FBQyxlQUNmLElBQUFnQixvQkFBYSxFQUFDc0IsU0FBUyxFQUFFO0lBQUVSO0VBQVEsQ0FBQyxDQUN0QyxDQUNKLENBQUM7QUFDSDtBQUFDUyxHQUFBLEdBWlFILFlBQVk7QUFjckIsU0FBU0UsU0FBU0EsQ0FBQztFQUFFUjtBQUFpQyxDQUFDLEVBQUU7RUFBQW5DLEdBQUE7RUFDdkQsTUFBTXFDLEdBQUcsR0FBRyxJQUFBQyxrQ0FBZ0IsRUFBY0gsT0FBTyxDQUFDO0VBQ2xELG9CQUFPLElBQUFkLG9CQUFhLEVBQUMsT0FBTyxFQUFFO0lBQUVoQixFQUFFLEVBQUUsU0FBUztJQUFFZ0M7RUFBSSxDQUFDLGVBQUUsSUFBQWhCLG9CQUFhLEVBQUMsUUFBUSxFQUFFO0lBQUVrQixJQUFJLEVBQUUsUUFBUTtJQUFFbEMsRUFBRSxFQUFFO0VBQVEsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQzFIOztBQUVBO0FBQ0E7QUFDQTtBQUFBTCxHQUFBLENBUFMyQyxTQUFTO0VBQUEsUUFDSkwsa0NBQWdCO0FBQUE7QUFBQU8sR0FBQSxHQURyQkYsU0FBUztBQVFsQixTQUFTRyxjQUFjQSxDQUFDO0VBQUVDLFdBQVc7RUFBRVo7QUFBdUQsQ0FBQyxFQUFFO0VBQUFsQyxHQUFBO0VBQy9GLE1BQU1vQyxHQUFHLEdBQUcsSUFBQUMsa0NBQWdCLEVBQWlCSCxPQUFPLENBQUM7RUFDckQsb0JBQU8sSUFBQWQsb0JBQWEsRUFDbEIsS0FBSyxFQUNMO0lBQUVoQixFQUFFLEVBQUUsU0FBUztJQUFFZ0M7RUFBSSxDQUFDLGVBQ3RCLElBQUFoQixvQkFBYSxFQUFDLFFBQVEsRUFBRTtJQUFFa0IsSUFBSSxFQUFFLFFBQVE7SUFBRWxDLEVBQUUsRUFBRTtFQUFRLENBQUMsRUFBRSxPQUFPLENBQUMsZUFDakUsSUFBQWdCLG9CQUFhLEVBQ1gsU0FBUyxFQUNUO0lBQUVoQixFQUFFLEVBQUUsT0FBTztJQUFFNEIsSUFBSSxFQUFFYztFQUFZLENBQUMsZUFDbEMsSUFBQTFCLG9CQUFhLEVBQUMsU0FBUyxFQUFFO0lBQUVoQixFQUFFLEVBQUU7RUFBTSxDQUFDLEVBQUUsT0FBTyxDQUFDLGVBQ2hELElBQUFnQixvQkFBYSxFQUFDLFFBQVEsRUFBRTtJQUFFa0IsSUFBSSxFQUFFLFFBQVE7SUFBRWxDLEVBQUUsRUFBRTtFQUFPLENBQUMsRUFBRSxNQUFNLENBQ2hFLENBQ0YsQ0FBQztBQUNIO0FBQUNKLEdBQUEsQ0FiUTZDLGNBQWM7RUFBQSxRQUNUUixrQ0FBZ0I7QUFBQTtBQUFBVSxHQUFBLEdBRHJCRixjQUFjO0FBZXZCLElBQUFHLGdCQUFRLEVBQUMsa0RBQWtELEVBQUUsTUFBTTtFQUNqRSxJQUFBQyxVQUFFLEVBQUMsMEZBQTBGLEVBQUUsTUFBTTtJQUNuRyxNQUFNZixPQUFPLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1DLENBQUMsR0FBR25DLEtBQUssY0FBQyxJQUFBRyxvQkFBYSxFQUFDVyxXQUFXLEVBQUU7TUFBRUMsSUFBSSxFQUFFLElBQUk7TUFBRUMsT0FBTyxFQUFFLEtBQUs7TUFBRUM7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNwRi9CLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQ2tELEtBQUssQ0FBQyxDQUFDO0lBQ3ZCLElBQUFDLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDcERpRCxDQUFDLENBQUN6QixRQUFRLGNBQUMsSUFBQVAsb0JBQWEsRUFBQ1csV0FBVyxFQUFFO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLE9BQU8sRUFBRSxJQUFJO01BQUVDO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDOUUsSUFBQW9CLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNyRCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDbERpRCxDQUFDLENBQUN6QixRQUFRLGNBQUMsSUFBQVAsb0JBQWEsRUFBQ1csV0FBVyxFQUFFO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLE9BQU8sRUFBRSxLQUFLO01BQUVDO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDL0UsSUFBQW9CLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDcERpRCxDQUFDLENBQUN2QixPQUFPLENBQUMsQ0FBQztFQUNiLENBQUMsQ0FBQztFQUVGLElBQUFvQixVQUFFLEVBQUMsc0ZBQXNGLEVBQUUsTUFBTTtJQUMvRixNQUFNZixPQUFPLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1DLENBQUMsR0FBR25DLEtBQUssY0FBQyxJQUFBRyxvQkFBYSxFQUFDb0IsWUFBWSxFQUFFO01BQUVSLElBQUksRUFBRSxLQUFLO01BQUVFO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdEUvQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUNrRCxLQUFLLENBQUMsQ0FBQztJQUN2QkQsQ0FBQyxDQUFDekIsUUFBUSxjQUFDLElBQUFQLG9CQUFhLEVBQUNvQixZQUFZLEVBQUU7TUFBRVIsSUFBSSxFQUFFLElBQUk7TUFBRUU7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNoRSxJQUFBb0IsY0FBTSxFQUFDaEQsUUFBUSxDQUFDaUQsYUFBYSxDQUFDLENBQUNDLElBQUksQ0FBQ3JELElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNsRDtJQUNBO0lBQ0FpRCxDQUFDLENBQUN6QixRQUFRLGNBQUMsSUFBQVAsb0JBQWEsRUFBQ29CLFlBQVksRUFBRTtNQUFFUixJQUFJLEVBQUUsS0FBSztNQUFFRTtJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ2pFLElBQUFvQixjQUFNLEVBQUNoRCxRQUFRLENBQUNpRCxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDckQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3BEaUQsQ0FBQyxDQUFDdkIsT0FBTyxDQUFDLENBQUM7RUFDYixDQUFDLENBQUM7RUFFRixJQUFBb0IsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLE1BQU07SUFBQSxJQUFBUSxHQUFBLEdBQUEzRCxZQUFBO0lBQ2hGLE1BQU1vQyxPQUFPLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1DLENBQUMsR0FBR25DLEtBQUssY0FBQyxJQUFBRyxvQkFBYSxFQUFDVyxXQUFXLEVBQUU7TUFBRUMsSUFBSSxFQUFFLElBQUk7TUFBRUMsT0FBTyxFQUFFLElBQUk7TUFBRUM7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNuRjtJQUNBO0lBQ0EsTUFBTWYsU0FBUyxHQUFHYixRQUFRLENBQUNjLGFBQWEsQ0FBQyxLQUFLLENBQUM7SUFDL0NkLFFBQVEsQ0FBQ2UsSUFBSSxDQUFDQyxXQUFXLENBQUNILFNBQVMsQ0FBQztJQUNwQyxNQUFNSSxJQUFJLEdBQUcsSUFBQUMsa0JBQVUsRUFBQ0wsU0FBUyxDQUFDO0lBQ2xDLFNBQVN1QyxJQUFJQSxDQUFBLEVBQUc7TUFBQUQsR0FBQTtNQUNkLE1BQU1yQixHQUFHLEdBQUcsSUFBQUMsa0NBQWdCLEVBQWNILE9BQU8sQ0FBQztNQUNsRCxvQkFBTyxJQUFBZCxvQkFBYSxFQUFDLE9BQU8sRUFBRTtRQUFFaEIsRUFBRSxFQUFFLE1BQU07UUFBRWdDO01BQUksQ0FBQyxDQUFDO0lBQ3BEO0lBQUNxQixHQUFBLENBSFFDLElBQUk7TUFBQSxRQUNDckIsa0NBQWdCO0lBQUE7SUFHOUIsSUFBQVosVUFBRyxFQUFDLE1BQU1GLElBQUksQ0FBQ0csTUFBTSxjQUFDLElBQUFOLG9CQUFhLEVBQUNzQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzNDLE1BQU1DLElBQUksR0FBR3hELElBQUksQ0FBQyxNQUFNLENBQUM7SUFDekIsSUFBQW1ELGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNHLElBQUksQ0FBQztJQUN6QyxJQUFBTCxjQUFNLEVBQUNLLElBQUksQ0FBQ0MsUUFBUSxDQUFDLENBQUNKLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5QixJQUFBL0IsVUFBRyxFQUFDLE1BQU1GLElBQUksQ0FBQ00sT0FBTyxDQUFDLENBQUMsQ0FBQztJQUN6QlYsU0FBUyxDQUFDVyxNQUFNLENBQUMsQ0FBQztJQUNsQnNCLENBQUMsQ0FBQ3ZCLE9BQU8sQ0FBQyxDQUFDO0VBQ2IsQ0FBQyxDQUFDO0VBRUYsSUFBQW9CLFVBQUUsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0lBQ25GLE1BQU1mLE9BQU8sR0FBR2dCLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDdkIsTUFBTUMsQ0FBQyxHQUFHbkMsS0FBSyxjQUFDLElBQUFHLG9CQUFhLEVBQUNXLFdBQVcsRUFBRTtNQUFFQyxJQUFJLEVBQUUsSUFBSTtNQUFFQyxPQUFPLEVBQUUsSUFBSTtNQUFFQztJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ25GL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDa0QsS0FBSyxDQUFDLENBQUM7SUFDcEIsSUFBSVEsRUFBRSxHQUFHLElBQUloRCxhQUFhLENBQUMsU0FBUyxFQUFFO01BQUVKLEdBQUcsRUFBRSxLQUFLO01BQUVLLE9BQU8sRUFBRSxJQUFJO01BQUVDLFVBQVUsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN0RlosSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDUyxhQUFhLENBQUNpRCxFQUFFLENBQUM7SUFDOUIsSUFBQVAsY0FBTSxFQUFDTyxFQUFFLENBQUNDLGdCQUFnQixDQUFDLENBQUNOLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDdEMsSUFBQUYsY0FBTSxFQUFDaEQsUUFBUSxDQUFDaUQsYUFBYSxDQUFDLENBQUNDLElBQUksQ0FBQ3JELElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUVsRDBELEVBQUUsR0FBRyxJQUFJaEQsYUFBYSxDQUFDLFNBQVMsRUFBRTtNQUFFSixHQUFHLEVBQUUsS0FBSztNQUFFSyxPQUFPLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUUsSUFBSTtNQUFFQyxRQUFRLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDbEdiLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQ1MsYUFBYSxDQUFDaUQsRUFBRSxDQUFDO0lBQy9CLElBQUFQLGNBQU0sRUFBQ08sRUFBRSxDQUFDQyxnQkFBZ0IsQ0FBQyxDQUFDTixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3RDLElBQUFGLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNyRCxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7O0lBRWpEO0lBQ0E7SUFDQWlELENBQUMsQ0FBQ3pCLFFBQVEsY0FBQyxJQUFBUCxvQkFBYSxFQUFDVyxXQUFXLEVBQUU7TUFBRUMsSUFBSSxFQUFFLElBQUk7TUFBRUMsT0FBTyxFQUFFLElBQUk7TUFBRUMsT0FBTztNQUFFQyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQztJQUNuR2hDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQ2tELEtBQUssQ0FBQyxDQUFDO0lBQ3BCUSxFQUFFLEdBQUcsSUFBSWhELGFBQWEsQ0FBQyxTQUFTLEVBQUU7TUFBRUosR0FBRyxFQUFFLEtBQUs7TUFBRUssT0FBTyxFQUFFLElBQUk7TUFBRUMsVUFBVSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ2xGWixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUNTLGFBQWEsQ0FBQ2lELEVBQUUsQ0FBQztJQUM5QixJQUFBUCxjQUFNLEVBQUNPLEVBQUUsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQztJQUN0QyxJQUFBRixjQUFNLEVBQUNoRCxRQUFRLENBQUNpRCxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDckQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2xEaUQsQ0FBQyxDQUFDdkIsT0FBTyxDQUFDLENBQUM7RUFDYixDQUFDLENBQUM7RUFFRixJQUFBb0IsVUFBRSxFQUFDLG9FQUFvRSxFQUFFLE1BQU07SUFBQSxJQUFBYyxHQUFBLEdBQUFqRSxZQUFBO0lBQzdFLE1BQU1vQyxPQUFPLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1oQyxTQUFTLEdBQUdiLFFBQVEsQ0FBQ2MsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMvQ2QsUUFBUSxDQUFDZSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0gsU0FBUyxDQUFDO0lBQ3BDLE1BQU1JLElBQUksR0FBRyxJQUFBQyxrQkFBVSxFQUFDTCxTQUFTLENBQUM7SUFDbEMsU0FBU3VDLElBQUlBLENBQUEsRUFBRztNQUFBSyxHQUFBO01BQ2QsTUFBTTNCLEdBQUcsR0FBRyxJQUFBQyxrQ0FBZ0IsRUFBY0gsT0FBTyxDQUFDO01BQ2xELG9CQUFPLElBQUFkLG9CQUFhLEVBQUMsT0FBTyxFQUFFO1FBQUVoQixFQUFFLEVBQUUsTUFBTTtRQUFFZ0M7TUFBSSxDQUFDLENBQUM7SUFDcEQ7SUFBQzJCLEdBQUEsQ0FIUUwsSUFBSTtNQUFBLFFBQ0NyQixrQ0FBZ0I7SUFBQTtJQUc5QixJQUFBWixVQUFHLEVBQUMsTUFBTUYsSUFBSSxDQUFDRyxNQUFNLGNBQUMsSUFBQU4sb0JBQWEsRUFBQ3NDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDM0MsTUFBTUMsSUFBSSxHQUFHeEQsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUN6QixNQUFNMEQsRUFBRSxHQUFHLElBQUloRCxhQUFhLENBQUMsU0FBUyxFQUFFO01BQUVKLEdBQUcsRUFBRSxLQUFLO01BQUVLLE9BQU8sRUFBRSxJQUFJO01BQUVDLFVBQVUsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN4RjRDLElBQUksQ0FBQy9DLGFBQWEsQ0FBQ2lELEVBQUUsQ0FBQztJQUN0QixJQUFBUCxjQUFNLEVBQUNPLEVBQUUsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQztJQUN0QyxJQUFBRixjQUFNLEVBQUNoRCxRQUFRLENBQUNpRCxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDRyxJQUFJLENBQUM7SUFDekMsSUFBQWxDLFVBQUcsRUFBQyxNQUFNRixJQUFJLENBQUNNLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDekJWLFNBQVMsQ0FBQ1csTUFBTSxDQUFDLENBQUM7RUFDcEIsQ0FBQyxDQUFDO0VBRUYsSUFBQW1CLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxNQUFNO0lBQ3ZFLE1BQU1mLE9BQU8sR0FBR2dCLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDdkIsTUFBTUMsQ0FBQyxHQUFHbkMsS0FBSyxjQUFDLElBQUFHLG9CQUFhLEVBQUNXLFdBQVcsRUFBRTtNQUFFQyxJQUFJLEVBQUUsSUFBSTtNQUFFQyxPQUFPLEVBQUUsSUFBSTtNQUFFQztJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ25GekIsR0FBRyxDQUFDTixJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsUUFBUSxDQUFDO0lBQzVCLElBQUFtRCxjQUFNLEVBQUNwQixPQUFPLENBQUMsQ0FBQzhCLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUN4QztJQUNBWixDQUFDLENBQUN6QixRQUFRLGNBQUMsSUFBQVAsb0JBQWEsRUFBQ1csV0FBVyxFQUFFO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLE9BQU8sRUFBRSxLQUFLO01BQUVDO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDL0V6QixHQUFHLENBQUNOLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxRQUFRLENBQUM7SUFDNUIsSUFBQW1ELGNBQU0sRUFBQ3BCLE9BQU8sQ0FBQyxDQUFDOEIscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ3hDWixDQUFDLENBQUN2QixPQUFPLENBQUMsQ0FBQztFQUNiLENBQUMsQ0FBQztFQUVGLElBQUFvQixVQUFFLEVBQUMsb0VBQW9FLEVBQUUsTUFBTTtJQUM3RSxNQUFNZixPQUFPLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1DLENBQUMsR0FBR25DLEtBQUssY0FBQyxJQUFBRyxvQkFBYSxFQUFDb0IsWUFBWSxFQUFFO01BQUVSLElBQUksRUFBRSxLQUFLO01BQUVFO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdEUvQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUNrRCxLQUFLLENBQUMsQ0FBQztJQUN2QkQsQ0FBQyxDQUFDekIsUUFBUSxjQUFDLElBQUFQLG9CQUFhLEVBQUNvQixZQUFZLEVBQUU7TUFBRVIsSUFBSSxFQUFFLElBQUk7TUFBRUU7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNoRSxJQUFBb0IsY0FBTSxFQUFDLE1BQU1GLENBQUMsQ0FBQ3pCLFFBQVEsY0FBQyxJQUFBUCxvQkFBYSxFQUFDb0IsWUFBWSxFQUFFO01BQUVSLElBQUksRUFBRSxJQUFJO01BQUVFLE9BQU87TUFBRU8sY0FBYyxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDd0IsR0FBRyxDQUFDQyxPQUFPLENBQUMsQ0FBQztJQUNuSCxJQUFBWixjQUFNLEVBQUMsTUFBTUYsQ0FBQyxDQUFDdkIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDb0MsR0FBRyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUN6QyxDQUFDLENBQUM7RUFFRixJQUFBakIsVUFBRSxFQUFDLDZGQUE2RixFQUFFLE1BQU07SUFDdEcsTUFBTWYsT0FBTyxHQUFHZ0IsVUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQztJQUN2QixNQUFNQyxDQUFDLEdBQUduQyxLQUFLLGNBQUMsSUFBQUcsb0JBQWEsRUFBQ3lCLGNBQWMsRUFBRTtNQUFFQyxXQUFXLEVBQUUsS0FBSztNQUFFWjtJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQy9FO0lBQ0E7SUFDQS9CLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQ2tELEtBQUssQ0FBQyxDQUFDO0lBQ25CLE1BQU1RLEVBQUUsR0FBRyxJQUFJaEQsYUFBYSxDQUFDLFNBQVMsRUFBRTtNQUFFSixHQUFHLEVBQUUsS0FBSztNQUFFSyxPQUFPLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDeEZaLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQ1MsYUFBYSxDQUFDaUQsRUFBRSxDQUFDO0lBQzdCLElBQUFQLGNBQU0sRUFBQ08sRUFBRSxDQUFDQyxnQkFBZ0IsQ0FBQyxDQUFDTixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3RDLElBQUFGLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ2lELGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNyRCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDbEQ7SUFDQSxNQUFNZ0UsSUFBSSxHQUFHLElBQUl0RCxhQUFhLENBQUMsU0FBUyxFQUFFO01BQUVKLEdBQUcsRUFBRSxLQUFLO01BQUVLLE9BQU8sRUFBRSxJQUFJO01BQUVDLFVBQVUsRUFBRSxJQUFJO01BQUVDLFFBQVEsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUMxR2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDUyxhQUFhLENBQUN1RCxJQUFJLENBQUM7SUFDakMsSUFBQWIsY0FBTSxFQUFDYSxJQUFJLENBQUNMLGdCQUFnQixDQUFDLENBQUNOLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDeEMsSUFBQUYsY0FBTSxFQUFDaEQsUUFBUSxDQUFDaUQsYUFBYSxDQUFDLENBQUNDLElBQUksQ0FBQ3JELElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRGlELENBQUMsQ0FBQ3ZCLE9BQU8sQ0FBQyxDQUFDO0VBQ2IsQ0FBQyxDQUFDO0VBRUYsSUFBQW9CLFVBQUUsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0lBQ25GLE1BQU1mLE9BQU8sR0FBR2dCLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDdkIsTUFBTUMsQ0FBQyxHQUFHbkMsS0FBSyxjQUFDLElBQUFHLG9CQUFhLEVBQUN5QixjQUFjLEVBQUU7TUFBRUMsV0FBVyxFQUFFLEtBQUs7TUFBRVo7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUMvRWtCLENBQUMsQ0FBQ3pCLFFBQVEsY0FBQyxJQUFBUCxvQkFBYSxFQUFDeUIsY0FBYyxFQUFFO01BQUVDLFdBQVcsRUFBRSxJQUFJO01BQUVaO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDekUvQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUNrRCxLQUFLLENBQUMsQ0FBQztJQUNwQixNQUFNUSxFQUFFLEdBQUcsSUFBSWhELGFBQWEsQ0FBQyxTQUFTLEVBQUU7TUFBRUosR0FBRyxFQUFFLEtBQUs7TUFBRUssT0FBTyxFQUFFLElBQUk7TUFBRUMsVUFBVSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3hGWixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUNTLGFBQWEsQ0FBQ2lELEVBQUUsQ0FBQztJQUM5QixJQUFBUCxjQUFNLEVBQUNPLEVBQUUsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQztJQUN0QyxJQUFBRixjQUFNLEVBQUNoRCxRQUFRLENBQUNpRCxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDckQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2xEaUQsQ0FBQyxDQUFDdkIsT0FBTyxDQUFDLENBQUM7RUFDYixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFBQyxJQUFBVSxFQUFBLEVBQUFJLEdBQUEsRUFBQUMsR0FBQSxFQUFBRyxHQUFBO0FBQUFxQixZQUFBLENBQUE3QixFQUFBO0FBQUE2QixZQUFBLENBQUF6QixHQUFBO0FBQUF5QixZQUFBLENBQUF4QixHQUFBO0FBQUF3QixZQUFBLENBQUFyQixHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}