"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.inMemoryTransport = inMemoryTransport;
exports.workerTransport = workerTransport;
var _engineWorker = require("./worker/engineWorker.ts");
// The host's channel to a restartable, terminable worker (ARCHITECTURE_PLAN §4.1). The async
// engine drives evaluation through this port; keeping it an injected interface is what lets the
// engine be tested with an in-process worker (no real threads) and lets `restart()` model the
// terminate-and-rebuild the hard-runaway watchdog relies on.

/**
 * Runs the worker body in-process. Used in tests and as a main-thread fallback where a real
 * Worker/SES-lockdown context is unavailable. Responses are delivered on a microtask so callers
 * see async semantics. NOTE: it cannot interrupt a synchronous divergence (same thread) — the
 * hard-runaway watchdog path is exercised in tests with a transport double that simply withholds
 * a response, which is what a wedged worker looks like from the host's side.
 */
function inMemoryTransport() {
  let worker = (0, _engineWorker.createEngineWorker)();
  let handler = () => {};
  let disposed = false;
  const deliver = msg => {
    queueMicrotask(() => {
      if (!disposed) handler(msg);
    });
  };
  return {
    post(msg) {
      if (disposed) return;
      if (msg.type === 'build') {
        try {
          deliver({
            type: 'built',
            descriptor: worker.build(msg.sources)
          });
        } catch (e) {
          deliver({
            type: 'build-error',
            message: e.message
          });
        }
        return;
      }
      if (msg.type === 'run-tests') {
        try {
          deliver({
            type: 'test-results',
            token: msg.token,
            suites: worker.runSuites(msg.suites)
          });
        } catch (e) {
          deliver({
            type: 'eval-error',
            token: msg.token,
            id: '(run-tests)',
            message: e.message
          });
        }
        return;
      }
      // A formula may be async — await it before delivering (§4.1).
      Promise.resolve().then(() => worker.eval(msg.id, msg.inputs)).then(value => deliver({
        type: 'result',
        token: msg.token,
        id: msg.id,
        value
      })).catch(e => deliver({
        type: 'eval-error',
        token: msg.token,
        id: msg.id,
        message: e.message
      }));
    },
    onMessage(h) {
      handler = h;
    },
    restart() {
      worker = (0, _engineWorker.createEngineWorker)();
    },
    dispose() {
      disposed = true;
      handler = () => {};
    }
  };
}

/**
 * A real Web Worker transport. `createWorker` is injected so the (bundler-/standard-specific)
 * `new Worker(new URL('./entry/engine.ts', import.meta.url), { type: 'module' })` call lives at
 * the call site, not in this library. `restart()` is the watchdog's kill switch: `terminate()`
 * drops a wedged worker (and any in-flight eval) and a fresh one is spawned.
 */
function workerTransport(createWorker) {
  let worker = createWorker();
  let handler = () => {};
  let disposed = false;
  const wire = () => {
    worker.onmessage = e => handler(e.data);
  };
  wire();
  return {
    post(msg) {
      if (disposed) return;
      worker.postMessage(msg);
    },
    onMessage(h) {
      handler = h;
    },
    restart() {
      if (disposed) return;
      worker.terminate();
      worker = createWorker();
      wire();
    },
    dispose() {
      disposed = true;
      handler = () => {};
      worker.terminate();
    }
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZW5naW5lV29ya2VyIiwicmVxdWlyZSIsImluTWVtb3J5VHJhbnNwb3J0Iiwid29ya2VyIiwiY3JlYXRlRW5naW5lV29ya2VyIiwiaGFuZGxlciIsImRpc3Bvc2VkIiwiZGVsaXZlciIsIm1zZyIsInF1ZXVlTWljcm90YXNrIiwicG9zdCIsInR5cGUiLCJkZXNjcmlwdG9yIiwiYnVpbGQiLCJzb3VyY2VzIiwiZSIsIm1lc3NhZ2UiLCJ0b2tlbiIsInN1aXRlcyIsInJ1blN1aXRlcyIsImlkIiwiUHJvbWlzZSIsInJlc29sdmUiLCJ0aGVuIiwiZXZhbCIsImlucHV0cyIsInZhbHVlIiwiY2F0Y2giLCJvbk1lc3NhZ2UiLCJoIiwicmVzdGFydCIsImRpc3Bvc2UiLCJ3b3JrZXJUcmFuc3BvcnQiLCJjcmVhdGVXb3JrZXIiLCJ3aXJlIiwib25tZXNzYWdlIiwiZGF0YSIsInBvc3RNZXNzYWdlIiwidGVybWluYXRlIl0sInNvdXJjZXMiOlsid29ya2VyVHJhbnNwb3J0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBob3N0J3MgY2hhbm5lbCB0byBhIHJlc3RhcnRhYmxlLCB0ZXJtaW5hYmxlIHdvcmtlciAoQVJDSElURUNUVVJFX1BMQU4gwqc0LjEpLiBUaGUgYXN5bmNcbi8vIGVuZ2luZSBkcml2ZXMgZXZhbHVhdGlvbiB0aHJvdWdoIHRoaXMgcG9ydDsga2VlcGluZyBpdCBhbiBpbmplY3RlZCBpbnRlcmZhY2UgaXMgd2hhdCBsZXRzIHRoZVxuLy8gZW5naW5lIGJlIHRlc3RlZCB3aXRoIGFuIGluLXByb2Nlc3Mgd29ya2VyIChubyByZWFsIHRocmVhZHMpIGFuZCBsZXRzIGByZXN0YXJ0KClgIG1vZGVsIHRoZVxuLy8gdGVybWluYXRlLWFuZC1yZWJ1aWxkIHRoZSBoYXJkLXJ1bmF3YXkgd2F0Y2hkb2cgcmVsaWVzIG9uLlxuXG5pbXBvcnQgeyBjcmVhdGVFbmdpbmVXb3JrZXIgfSBmcm9tICcuL3dvcmtlci9lbmdpbmVXb3JrZXIudHMnO1xuaW1wb3J0IHR5cGUgeyBXb3JrZXJSZXF1ZXN0LCBXb3JrZXJSZXNwb25zZSB9IGZyb20gJy4vd29ya2VyL3Byb3RvY29sLnRzJztcblxuZXhwb3J0IGludGVyZmFjZSBXb3JrZXJUcmFuc3BvcnQge1xuICBwb3N0KG1zZzogV29ya2VyUmVxdWVzdCk6IHZvaWQ7XG4gIG9uTWVzc2FnZShoYW5kbGVyOiAobXNnOiBXb3JrZXJSZXNwb25zZSkgPT4gdm9pZCk6IHZvaWQ7XG4gIC8qKiBUZXJtaW5hdGUgdGhlIGN1cnJlbnQgd29ya2VyIChhYmFuZG9uaW5nIGFueSBpbi1mbGlnaHQgZXZhbCkgYW5kIHN0YXJ0IGEgZnJlc2ggb25lLiAqL1xuICByZXN0YXJ0KCk6IHZvaWQ7XG4gIC8qKlxuICAgKiBUZXJtaW5hdGUgd2l0aG91dCByZXNwYXduIChXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQyDCpzIuMiwgRy1XSUYtNyk6IGEgZGlzY2FyZGVkXG4gICAqIHNoYWRvdyBjb250ZXh0IG11c3QgYmUgYWJsZSB0byAqc3RvcCouIEEgZGlzcG9zZWQgdHJhbnNwb3J0IGRlbGl2ZXJzIG5vIGZ1cnRoZXJcbiAgICogbWVzc2FnZXMgYW5kIGRyb3BzIHN1YnNlcXVlbnQgcG9zdHMuXG4gICAqL1xuICBkaXNwb3NlKCk6IHZvaWQ7XG59XG5cbi8qKlxuICogUnVucyB0aGUgd29ya2VyIGJvZHkgaW4tcHJvY2Vzcy4gVXNlZCBpbiB0ZXN0cyBhbmQgYXMgYSBtYWluLXRocmVhZCBmYWxsYmFjayB3aGVyZSBhIHJlYWxcbiAqIFdvcmtlci9TRVMtbG9ja2Rvd24gY29udGV4dCBpcyB1bmF2YWlsYWJsZS4gUmVzcG9uc2VzIGFyZSBkZWxpdmVyZWQgb24gYSBtaWNyb3Rhc2sgc28gY2FsbGVyc1xuICogc2VlIGFzeW5jIHNlbWFudGljcy4gTk9URTogaXQgY2Fubm90IGludGVycnVwdCBhIHN5bmNocm9ub3VzIGRpdmVyZ2VuY2UgKHNhbWUgdGhyZWFkKSDigJQgdGhlXG4gKiBoYXJkLXJ1bmF3YXkgd2F0Y2hkb2cgcGF0aCBpcyBleGVyY2lzZWQgaW4gdGVzdHMgd2l0aCBhIHRyYW5zcG9ydCBkb3VibGUgdGhhdCBzaW1wbHkgd2l0aGhvbGRzXG4gKiBhIHJlc3BvbnNlLCB3aGljaCBpcyB3aGF0IGEgd2VkZ2VkIHdvcmtlciBsb29rcyBsaWtlIGZyb20gdGhlIGhvc3QncyBzaWRlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaW5NZW1vcnlUcmFuc3BvcnQoKTogV29ya2VyVHJhbnNwb3J0IHtcbiAgbGV0IHdvcmtlciA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuICBsZXQgaGFuZGxlcjogKG1zZzogV29ya2VyUmVzcG9uc2UpID0+IHZvaWQgPSAoKSA9PiB7fTtcbiAgbGV0IGRpc3Bvc2VkID0gZmFsc2U7XG4gIGNvbnN0IGRlbGl2ZXIgPSAobXNnOiBXb3JrZXJSZXNwb25zZSk6IHZvaWQgPT4ge1xuICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgIGlmICghZGlzcG9zZWQpIGhhbmRsZXIobXNnKTtcbiAgICB9KTtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBwb3N0KG1zZykge1xuICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICBpZiAobXNnLnR5cGUgPT09ICdidWlsZCcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBkZWxpdmVyKHsgdHlwZTogJ2J1aWx0JywgZGVzY3JpcHRvcjogd29ya2VyLmJ1aWxkKG1zZy5zb3VyY2VzKSB9KTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGRlbGl2ZXIoeyB0eXBlOiAnYnVpbGQtZXJyb3InLCBtZXNzYWdlOiAoZSBhcyBFcnJvcikubWVzc2FnZSB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAobXNnLnR5cGUgPT09ICdydW4tdGVzdHMnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZGVsaXZlcih7IHR5cGU6ICd0ZXN0LXJlc3VsdHMnLCB0b2tlbjogbXNnLnRva2VuLCBzdWl0ZXM6IHdvcmtlci5ydW5TdWl0ZXMobXNnLnN1aXRlcykgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBkZWxpdmVyKHsgdHlwZTogJ2V2YWwtZXJyb3InLCB0b2tlbjogbXNnLnRva2VuLCBpZDogJyhydW4tdGVzdHMpJywgbWVzc2FnZTogKGUgYXMgRXJyb3IpLm1lc3NhZ2UgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gQSBmb3JtdWxhIG1heSBiZSBhc3luYyDigJQgYXdhaXQgaXQgYmVmb3JlIGRlbGl2ZXJpbmcgKMKnNC4xKS5cbiAgICAgIFByb21pc2UucmVzb2x2ZSgpXG4gICAgICAgIC50aGVuKCgpID0+IHdvcmtlci5ldmFsKG1zZy5pZCwgbXNnLmlucHV0cykpXG4gICAgICAgIC50aGVuKCh2YWx1ZSkgPT4gZGVsaXZlcih7IHR5cGU6ICdyZXN1bHQnLCB0b2tlbjogbXNnLnRva2VuLCBpZDogbXNnLmlkLCB2YWx1ZSB9KSlcbiAgICAgICAgLmNhdGNoKChlKSA9PiBkZWxpdmVyKHsgdHlwZTogJ2V2YWwtZXJyb3InLCB0b2tlbjogbXNnLnRva2VuLCBpZDogbXNnLmlkLCBtZXNzYWdlOiAoZSBhcyBFcnJvcikubWVzc2FnZSB9KSk7XG4gICAgfSxcbiAgICBvbk1lc3NhZ2UoaCkge1xuICAgICAgaGFuZGxlciA9IGg7XG4gICAgfSxcbiAgICByZXN0YXJ0KCkge1xuICAgICAgd29ya2VyID0gY3JlYXRlRW5naW5lV29ya2VyKCk7XG4gICAgfSxcbiAgICBkaXNwb3NlKCkge1xuICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgaGFuZGxlciA9ICgpID0+IHt9O1xuICAgIH0sXG4gIH07XG59XG5cbi8qKlxuICogQSByZWFsIFdlYiBXb3JrZXIgdHJhbnNwb3J0LiBgY3JlYXRlV29ya2VyYCBpcyBpbmplY3RlZCBzbyB0aGUgKGJ1bmRsZXItL3N0YW5kYXJkLXNwZWNpZmljKVxuICogYG5ldyBXb3JrZXIobmV3IFVSTCgnLi9lbnRyeS9lbmdpbmUudHMnLCBpbXBvcnQubWV0YS51cmwpLCB7IHR5cGU6ICdtb2R1bGUnIH0pYCBjYWxsIGxpdmVzIGF0XG4gKiB0aGUgY2FsbCBzaXRlLCBub3QgaW4gdGhpcyBsaWJyYXJ5LiBgcmVzdGFydCgpYCBpcyB0aGUgd2F0Y2hkb2cncyBraWxsIHN3aXRjaDogYHRlcm1pbmF0ZSgpYFxuICogZHJvcHMgYSB3ZWRnZWQgd29ya2VyIChhbmQgYW55IGluLWZsaWdodCBldmFsKSBhbmQgYSBmcmVzaCBvbmUgaXMgc3Bhd25lZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdvcmtlclRyYW5zcG9ydChjcmVhdGVXb3JrZXI6ICgpID0+IFdvcmtlcik6IFdvcmtlclRyYW5zcG9ydCB7XG4gIGxldCB3b3JrZXIgPSBjcmVhdGVXb3JrZXIoKTtcbiAgbGV0IGhhbmRsZXI6IChtc2c6IFdvcmtlclJlc3BvbnNlKSA9PiB2b2lkID0gKCkgPT4ge307XG4gIGxldCBkaXNwb3NlZCA9IGZhbHNlO1xuICBjb25zdCB3aXJlID0gKCk6IHZvaWQgPT4ge1xuICAgIHdvcmtlci5vbm1lc3NhZ2UgPSAoZTogTWVzc2FnZUV2ZW50PFdvcmtlclJlc3BvbnNlPikgPT4gaGFuZGxlcihlLmRhdGEpO1xuICB9O1xuICB3aXJlKCk7XG4gIHJldHVybiB7XG4gICAgcG9zdChtc2cpIHtcbiAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgd29ya2VyLnBvc3RNZXNzYWdlKG1zZyk7XG4gICAgfSxcbiAgICBvbk1lc3NhZ2UoaCkge1xuICAgICAgaGFuZGxlciA9IGg7XG4gICAgfSxcbiAgICByZXN0YXJ0KCkge1xuICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICB3b3JrZXIudGVybWluYXRlKCk7XG4gICAgICB3b3JrZXIgPSBjcmVhdGVXb3JrZXIoKTtcbiAgICAgIHdpcmUoKTtcbiAgICB9LFxuICAgIGRpc3Bvc2UoKSB7XG4gICAgICBkaXNwb3NlZCA9IHRydWU7XG4gICAgICBoYW5kbGVyID0gKCkgPT4ge307XG4gICAgICB3b3JrZXIudGVybWluYXRlKCk7XG4gICAgfSxcbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUtBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUxBO0FBQ0E7QUFDQTtBQUNBOztBQWtCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGlCQUFpQkEsQ0FBQSxFQUFvQjtFQUNuRCxJQUFJQyxNQUFNLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztFQUNqQyxJQUFJQyxPQUFzQyxHQUFHQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0VBQ3JELElBQUlDLFFBQVEsR0FBRyxLQUFLO0VBQ3BCLE1BQU1DLE9BQU8sR0FBSUMsR0FBbUIsSUFBVztJQUM3Q0MsY0FBYyxDQUFDLE1BQU07TUFDbkIsSUFBSSxDQUFDSCxRQUFRLEVBQUVELE9BQU8sQ0FBQ0csR0FBRyxDQUFDO0lBQzdCLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDRCxPQUFPO0lBQ0xFLElBQUlBLENBQUNGLEdBQUcsRUFBRTtNQUNSLElBQUlGLFFBQVEsRUFBRTtNQUNkLElBQUlFLEdBQUcsQ0FBQ0csSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUN4QixJQUFJO1VBQ0ZKLE9BQU8sQ0FBQztZQUFFSSxJQUFJLEVBQUUsT0FBTztZQUFFQyxVQUFVLEVBQUVULE1BQU0sQ0FBQ1UsS0FBSyxDQUFDTCxHQUFHLENBQUNNLE9BQU87VUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQyxDQUFDLE9BQU9DLENBQUMsRUFBRTtVQUNWUixPQUFPLENBQUM7WUFBRUksSUFBSSxFQUFFLGFBQWE7WUFBRUssT0FBTyxFQUFHRCxDQUFDLENBQVdDO1VBQVEsQ0FBQyxDQUFDO1FBQ2pFO1FBQ0E7TUFDRjtNQUNBLElBQUlSLEdBQUcsQ0FBQ0csSUFBSSxLQUFLLFdBQVcsRUFBRTtRQUM1QixJQUFJO1VBQ0ZKLE9BQU8sQ0FBQztZQUFFSSxJQUFJLEVBQUUsY0FBYztZQUFFTSxLQUFLLEVBQUVULEdBQUcsQ0FBQ1MsS0FBSztZQUFFQyxNQUFNLEVBQUVmLE1BQU0sQ0FBQ2dCLFNBQVMsQ0FBQ1gsR0FBRyxDQUFDVSxNQUFNO1VBQUUsQ0FBQyxDQUFDO1FBQzNGLENBQUMsQ0FBQyxPQUFPSCxDQUFDLEVBQUU7VUFDVlIsT0FBTyxDQUFDO1lBQUVJLElBQUksRUFBRSxZQUFZO1lBQUVNLEtBQUssRUFBRVQsR0FBRyxDQUFDUyxLQUFLO1lBQUVHLEVBQUUsRUFBRSxhQUFhO1lBQUVKLE9BQU8sRUFBR0QsQ0FBQyxDQUFXQztVQUFRLENBQUMsQ0FBQztRQUNyRztRQUNBO01BQ0Y7TUFDQTtNQUNBSyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQ2RDLElBQUksQ0FBQyxNQUFNcEIsTUFBTSxDQUFDcUIsSUFBSSxDQUFDaEIsR0FBRyxDQUFDWSxFQUFFLEVBQUVaLEdBQUcsQ0FBQ2lCLE1BQU0sQ0FBQyxDQUFDLENBQzNDRixJQUFJLENBQUVHLEtBQUssSUFBS25CLE9BQU8sQ0FBQztRQUFFSSxJQUFJLEVBQUUsUUFBUTtRQUFFTSxLQUFLLEVBQUVULEdBQUcsQ0FBQ1MsS0FBSztRQUFFRyxFQUFFLEVBQUVaLEdBQUcsQ0FBQ1ksRUFBRTtRQUFFTTtNQUFNLENBQUMsQ0FBQyxDQUFDLENBQ2pGQyxLQUFLLENBQUVaLENBQUMsSUFBS1IsT0FBTyxDQUFDO1FBQUVJLElBQUksRUFBRSxZQUFZO1FBQUVNLEtBQUssRUFBRVQsR0FBRyxDQUFDUyxLQUFLO1FBQUVHLEVBQUUsRUFBRVosR0FBRyxDQUFDWSxFQUFFO1FBQUVKLE9BQU8sRUFBR0QsQ0FBQyxDQUFXQztNQUFRLENBQUMsQ0FBQyxDQUFDO0lBQy9HLENBQUM7SUFDRFksU0FBU0EsQ0FBQ0MsQ0FBQyxFQUFFO01BQ1h4QixPQUFPLEdBQUd3QixDQUFDO0lBQ2IsQ0FBQztJQUNEQyxPQUFPQSxDQUFBLEVBQUc7TUFDUjNCLE1BQU0sR0FBRyxJQUFBQyxnQ0FBa0IsRUFBQyxDQUFDO0lBQy9CLENBQUM7SUFDRDJCLE9BQU9BLENBQUEsRUFBRztNQUNSekIsUUFBUSxHQUFHLElBQUk7TUFDZkQsT0FBTyxHQUFHQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0lBQ3BCO0VBQ0YsQ0FBQztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMyQixlQUFlQSxDQUFDQyxZQUEwQixFQUFtQjtFQUMzRSxJQUFJOUIsTUFBTSxHQUFHOEIsWUFBWSxDQUFDLENBQUM7RUFDM0IsSUFBSTVCLE9BQXNDLEdBQUdBLENBQUEsS0FBTSxDQUFDLENBQUM7RUFDckQsSUFBSUMsUUFBUSxHQUFHLEtBQUs7RUFDcEIsTUFBTTRCLElBQUksR0FBR0EsQ0FBQSxLQUFZO0lBQ3ZCL0IsTUFBTSxDQUFDZ0MsU0FBUyxHQUFJcEIsQ0FBK0IsSUFBS1YsT0FBTyxDQUFDVSxDQUFDLENBQUNxQixJQUFJLENBQUM7RUFDekUsQ0FBQztFQUNERixJQUFJLENBQUMsQ0FBQztFQUNOLE9BQU87SUFDTHhCLElBQUlBLENBQUNGLEdBQUcsRUFBRTtNQUNSLElBQUlGLFFBQVEsRUFBRTtNQUNkSCxNQUFNLENBQUNrQyxXQUFXLENBQUM3QixHQUFHLENBQUM7SUFDekIsQ0FBQztJQUNEb0IsU0FBU0EsQ0FBQ0MsQ0FBQyxFQUFFO01BQ1h4QixPQUFPLEdBQUd3QixDQUFDO0lBQ2IsQ0FBQztJQUNEQyxPQUFPQSxDQUFBLEVBQUc7TUFDUixJQUFJeEIsUUFBUSxFQUFFO01BQ2RILE1BQU0sQ0FBQ21DLFNBQVMsQ0FBQyxDQUFDO01BQ2xCbkMsTUFBTSxHQUFHOEIsWUFBWSxDQUFDLENBQUM7TUFDdkJDLElBQUksQ0FBQyxDQUFDO0lBQ1IsQ0FBQztJQUNESCxPQUFPQSxDQUFBLEVBQUc7TUFDUnpCLFFBQVEsR0FBRyxJQUFJO01BQ2ZELE9BQU8sR0FBR0EsQ0FBQSxLQUFNLENBQUMsQ0FBQztNQUNsQkYsTUFBTSxDQUFDbUMsU0FBUyxDQUFDLENBQUM7SUFDcEI7RUFDRixDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=