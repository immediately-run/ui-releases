var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Callout;
var _attrs = require("../attrs.ts");
var _renderContext = require("../renderContext.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Callout — an emphasized prose block with a `tone` (info/success/warning/danger). Container:
// renders its children (usually markdown) through the shared dispatcher.
const TONES = new Set(['info', 'success', 'warning', 'danger']);
function Callout({
  node
}) {
  _s();
  const toneAttr = (0, _attrs.attrString)(node, 'tone');
  const tone = TONES.has(toneAttr ?? '') ? toneAttr : 'info';
  const renderNodes = (0, _renderContext.useRenderNodes)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-callout",
    "data-tone": tone,
    role: "note",
    children: renderNodes(node.children)
  });
}
_s(Callout, "ITAsjexFDox20GXuav5598+1Xb8=", false, function () {
  return [_renderContext.useRenderNodes];
});
_c = Callout;
var _c;
$RefreshReg$(_c, "Callout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlbmRlckNvbnRleHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiVE9ORVMiLCJTZXQiLCJDYWxsb3V0Iiwibm9kZSIsInRvbmVBdHRyIiwiYXR0clN0cmluZyIsInRvbmUiLCJoYXMiLCJyZW5kZXJOb2RlcyIsInVzZVJlbmRlck5vZGVzIiwianN4IiwiY2xhc3NOYW1lIiwicm9sZSIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYWxsb3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDYWxsb3V0IOKAlCBhbiBlbXBoYXNpemVkIHByb3NlIGJsb2NrIHdpdGggYSBgdG9uZWAgKGluZm8vc3VjY2Vzcy93YXJuaW5nL2RhbmdlcikuIENvbnRhaW5lcjpcbi8vIHJlbmRlcnMgaXRzIGNoaWxkcmVuICh1c3VhbGx5IG1hcmtkb3duKSB0aHJvdWdoIHRoZSBzaGFyZWQgZGlzcGF0Y2hlci5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyB1c2VSZW5kZXJOb2RlcyB9IGZyb20gJy4uL3JlbmRlckNvbnRleHQudHMnO1xuXG5jb25zdCBUT05FUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydpbmZvJywgJ3N1Y2Nlc3MnLCAnd2FybmluZycsICdkYW5nZXInXSk7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhbGxvdXQoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHRvbmVBdHRyID0gYXR0clN0cmluZyhub2RlLCAndG9uZScpO1xuICBjb25zdCB0b25lID0gVE9ORVMuaGFzKHRvbmVBdHRyID8/ICcnKSA/IHRvbmVBdHRyIDogJ2luZm8nO1xuICBjb25zdCByZW5kZXJOb2RlcyA9IHVzZVJlbmRlck5vZGVzKCk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1jYWxsb3V0XCIgZGF0YS10b25lPXt0b25lfSByb2xlPVwibm90ZVwiPlxuICAgICAge3JlbmRlck5vZGVzKG5vZGUuY2hpbGRyZW4pfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxjQUFBLEdBQUFELE9BQUE7QUFBcUQsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBSnJEO0FBQ0E7QUFLQSxNQUFNQyxLQUEwQixHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBRXJFLFNBQVNDLE9BQU9BLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFMLEVBQUE7RUFDakUsTUFBTU0sUUFBUSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxNQUFNLENBQUM7RUFDekMsTUFBTUcsSUFBSSxHQUFHTixLQUFLLENBQUNPLEdBQUcsQ0FBQ0gsUUFBUSxJQUFJLEVBQUUsQ0FBQyxHQUFHQSxRQUFRLEdBQUcsTUFBTTtFQUMxRCxNQUFNSSxXQUFXLEdBQUcsSUFBQUMsNkJBQWMsRUFBQyxDQUFDO0VBQ3BDLG9CQUNFLElBQUFaLFdBQUEsQ0FBQWEsR0FBQTtJQUFLQyxTQUFTLEVBQUMsWUFBWTtJQUFDLGFBQVdMLElBQUs7SUFBQ00sSUFBSSxFQUFDLE1BQU07SUFBQUMsUUFBQSxFQUNyREwsV0FBVyxDQUFDTCxJQUFJLENBQUNVLFFBQVE7RUFBQyxDQUN4QixDQUFDO0FBRVY7QUFBQ2YsRUFBQSxDQVR1QkksT0FBTztFQUFBLFFBR1RPLDZCQUFjO0FBQUE7QUFBQUssRUFBQSxHQUhaWixPQUFPO0FBQUEsSUFBQVksRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}