"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.compareVersions = compareVersions;
exports.parseVersion = parseVersion;
exports.satisfies = satisfies;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
// A deliberately minimal semver matcher for the compatibility envelope
// (DOCUMENT_VERSIONING_SPEC §1/§2). It supports exactly what `compat` ranges use — a
// conjunction of comparators (`>=1.4 <2`) over `major.minor.patch` — not the full semver
// grammar (no `^`/`~`/`||`/pre-release tags). Keeping it small and pure avoids pulling a
// semver runtime into the sandbox bundle; the envelope's ranges are simple by design.

/** Parse "1", "1.4", or "1.4.2" into a {@link SemVer}. Throws on anything malformed. */
function parseVersion(v) {
  const m = /^(\d+)(?:\.(\d+))?(?:\.(\d+))?$/.exec(v.trim());
  if (!m) throw new Error(`Invalid version: ${JSON.stringify(v)}`);
  return {
    major: Number(m[1]),
    minor: m[2] !== undefined ? Number(m[2]) : 0,
    patch: m[3] !== undefined ? Number(m[3]) : 0
  };
}

/** Order two versions: negative if a < b, 0 if equal, positive if a > b. */
function compareVersions(a, b) {
  const pa = typeof a === 'string' ? parseVersion(a) : a;
  const pb = typeof b === 'string' ? parseVersion(b) : b;
  return pa.major - pb.major || pa.minor - pb.minor || pa.patch - pb.patch;
}
const OPS = ['>=', '<=', '>', '<', '='];
function comparator(token) {
  let op = '=';
  let rest = token;
  for (const o of OPS) {
    if (token.startsWith(o)) {
      op = o;
      rest = token.slice(o.length);
      break;
    }
  }
  const bound = parseVersion(rest);
  return v => {
    const c = compareVersions(v, bound);
    switch (op) {
      case '>=':
        return c >= 0;
      case '<=':
        return c <= 0;
      case '>':
        return c > 0;
      case '<':
        return c < 0;
      case '=':
        return c === 0;
    }
  };
}

/**
 * True when `version` satisfies every space-separated comparator in `range`
 * (e.g. `">=1.4 <2"`). An empty range is satisfied by anything.
 */
function satisfies(version, range) {
  const v = typeof version === 'string' ? parseVersion(version) : version;
  const tokens = range.trim().split(/\s+/).filter(t => t.length > 0);
  return tokens.every(t => comparator(t)(v));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwYXJzZVZlcnNpb24iLCJ2IiwibSIsImV4ZWMiLCJ0cmltIiwiRXJyb3IiLCJKU09OIiwic3RyaW5naWZ5IiwibWFqb3IiLCJOdW1iZXIiLCJtaW5vciIsInVuZGVmaW5lZCIsInBhdGNoIiwiY29tcGFyZVZlcnNpb25zIiwiYSIsImIiLCJwYSIsInBiIiwiT1BTIiwiY29tcGFyYXRvciIsInRva2VuIiwib3AiLCJyZXN0IiwibyIsInN0YXJ0c1dpdGgiLCJzbGljZSIsImxlbmd0aCIsImJvdW5kIiwiYyIsInNhdGlzZmllcyIsInZlcnNpb24iLCJyYW5nZSIsInRva2VucyIsInNwbGl0IiwiZmlsdGVyIiwidCIsImV2ZXJ5Il0sInNvdXJjZXMiOlsic2VtdmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEEgZGVsaWJlcmF0ZWx5IG1pbmltYWwgc2VtdmVyIG1hdGNoZXIgZm9yIHRoZSBjb21wYXRpYmlsaXR5IGVudmVsb3BlXG4vLyAoRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDIMKnMS/CpzIpLiBJdCBzdXBwb3J0cyBleGFjdGx5IHdoYXQgYGNvbXBhdGAgcmFuZ2VzIHVzZSDigJQgYVxuLy8gY29uanVuY3Rpb24gb2YgY29tcGFyYXRvcnMgKGA+PTEuNCA8MmApIG92ZXIgYG1ham9yLm1pbm9yLnBhdGNoYCDigJQgbm90IHRoZSBmdWxsIHNlbXZlclxuLy8gZ3JhbW1hciAobm8gYF5gL2B+YC9gfHxgL3ByZS1yZWxlYXNlIHRhZ3MpLiBLZWVwaW5nIGl0IHNtYWxsIGFuZCBwdXJlIGF2b2lkcyBwdWxsaW5nIGFcbi8vIHNlbXZlciBydW50aW1lIGludG8gdGhlIHNhbmRib3ggYnVuZGxlOyB0aGUgZW52ZWxvcGUncyByYW5nZXMgYXJlIHNpbXBsZSBieSBkZXNpZ24uXG5cbmV4cG9ydCBpbnRlcmZhY2UgU2VtVmVyIHtcbiAgbWFqb3I6IG51bWJlcjtcbiAgbWlub3I6IG51bWJlcjtcbiAgcGF0Y2g6IG51bWJlcjtcbn1cblxuLyoqIFBhcnNlIFwiMVwiLCBcIjEuNFwiLCBvciBcIjEuNC4yXCIgaW50byBhIHtAbGluayBTZW1WZXJ9LiBUaHJvd3Mgb24gYW55dGhpbmcgbWFsZm9ybWVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlVmVyc2lvbih2OiBzdHJpbmcpOiBTZW1WZXIge1xuICBjb25zdCBtID0gL14oXFxkKykoPzpcXC4oXFxkKykpPyg/OlxcLihcXGQrKSk/JC8uZXhlYyh2LnRyaW0oKSk7XG4gIGlmICghbSkgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIHZlcnNpb246ICR7SlNPTi5zdHJpbmdpZnkodil9YCk7XG4gIHJldHVybiB7XG4gICAgbWFqb3I6IE51bWJlcihtWzFdKSxcbiAgICBtaW5vcjogbVsyXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKG1bMl0pIDogMCxcbiAgICBwYXRjaDogbVszXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKG1bM10pIDogMCxcbiAgfTtcbn1cblxuLyoqIE9yZGVyIHR3byB2ZXJzaW9uczogbmVnYXRpdmUgaWYgYSA8IGIsIDAgaWYgZXF1YWwsIHBvc2l0aXZlIGlmIGEgPiBiLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbXBhcmVWZXJzaW9ucyhhOiBzdHJpbmcgfCBTZW1WZXIsIGI6IHN0cmluZyB8IFNlbVZlcik6IG51bWJlciB7XG4gIGNvbnN0IHBhID0gdHlwZW9mIGEgPT09ICdzdHJpbmcnID8gcGFyc2VWZXJzaW9uKGEpIDogYTtcbiAgY29uc3QgcGIgPSB0eXBlb2YgYiA9PT0gJ3N0cmluZycgPyBwYXJzZVZlcnNpb24oYikgOiBiO1xuICByZXR1cm4gcGEubWFqb3IgLSBwYi5tYWpvciB8fCBwYS5taW5vciAtIHBiLm1pbm9yIHx8IHBhLnBhdGNoIC0gcGIucGF0Y2g7XG59XG5cbnR5cGUgT3AgPSAnPj0nIHwgJzw9JyB8ICc+JyB8ICc8JyB8ICc9JztcblxuY29uc3QgT1BTOiBPcFtdID0gWyc+PScsICc8PScsICc+JywgJzwnLCAnPSddO1xuXG5mdW5jdGlvbiBjb21wYXJhdG9yKHRva2VuOiBzdHJpbmcpOiAodjogU2VtVmVyKSA9PiBib29sZWFuIHtcbiAgbGV0IG9wOiBPcCA9ICc9JztcbiAgbGV0IHJlc3QgPSB0b2tlbjtcbiAgZm9yIChjb25zdCBvIG9mIE9QUykge1xuICAgIGlmICh0b2tlbi5zdGFydHNXaXRoKG8pKSB7XG4gICAgICBvcCA9IG87XG4gICAgICByZXN0ID0gdG9rZW4uc2xpY2Uoby5sZW5ndGgpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIGNvbnN0IGJvdW5kID0gcGFyc2VWZXJzaW9uKHJlc3QpO1xuICByZXR1cm4gKHY6IFNlbVZlcikgPT4ge1xuICAgIGNvbnN0IGMgPSBjb21wYXJlVmVyc2lvbnModiwgYm91bmQpO1xuICAgIHN3aXRjaCAob3ApIHtcbiAgICAgIGNhc2UgJz49JzpcbiAgICAgICAgcmV0dXJuIGMgPj0gMDtcbiAgICAgIGNhc2UgJzw9JzpcbiAgICAgICAgcmV0dXJuIGMgPD0gMDtcbiAgICAgIGNhc2UgJz4nOlxuICAgICAgICByZXR1cm4gYyA+IDA7XG4gICAgICBjYXNlICc8JzpcbiAgICAgICAgcmV0dXJuIGMgPCAwO1xuICAgICAgY2FzZSAnPSc6XG4gICAgICAgIHJldHVybiBjID09PSAwO1xuICAgIH1cbiAgfTtcbn1cblxuLyoqXG4gKiBUcnVlIHdoZW4gYHZlcnNpb25gIHNhdGlzZmllcyBldmVyeSBzcGFjZS1zZXBhcmF0ZWQgY29tcGFyYXRvciBpbiBgcmFuZ2VgXG4gKiAoZS5nLiBgXCI+PTEuNCA8MlwiYCkuIEFuIGVtcHR5IHJhbmdlIGlzIHNhdGlzZmllZCBieSBhbnl0aGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNhdGlzZmllcyh2ZXJzaW9uOiBzdHJpbmcgfCBTZW1WZXIsIHJhbmdlOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgdiA9IHR5cGVvZiB2ZXJzaW9uID09PSAnc3RyaW5nJyA/IHBhcnNlVmVyc2lvbih2ZXJzaW9uKSA6IHZlcnNpb247XG4gIGNvbnN0IHRva2VucyA9IHJhbmdlLnRyaW0oKS5zcGxpdCgvXFxzKy8pLmZpbHRlcigodCkgPT4gdC5sZW5ndGggPiAwKTtcbiAgcmV0dXJuIHRva2Vucy5ldmVyeSgodCkgPT4gY29tcGFyYXRvcih0KSh2KSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFRQTtBQUNPLFNBQVNBLFlBQVlBLENBQUNDLENBQVMsRUFBVTtFQUM5QyxNQUFNQyxDQUFDLEdBQUcsaUNBQWlDLENBQUNDLElBQUksQ0FBQ0YsQ0FBQyxDQUFDRyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzFELElBQUksQ0FBQ0YsQ0FBQyxFQUFFLE1BQU0sSUFBSUcsS0FBSyxDQUFDLG9CQUFvQkMsSUFBSSxDQUFDQyxTQUFTLENBQUNOLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFDaEUsT0FBTztJQUNMTyxLQUFLLEVBQUVDLE1BQU0sQ0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25CUSxLQUFLLEVBQUVSLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBS1MsU0FBUyxHQUFHRixNQUFNLENBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7SUFDNUNVLEtBQUssRUFBRVYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLUyxTQUFTLEdBQUdGLE1BQU0sQ0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7RUFDN0MsQ0FBQztBQUNIOztBQUVBO0FBQ08sU0FBU1csZUFBZUEsQ0FBQ0MsQ0FBa0IsRUFBRUMsQ0FBa0IsRUFBVTtFQUM5RSxNQUFNQyxFQUFFLEdBQUcsT0FBT0YsQ0FBQyxLQUFLLFFBQVEsR0FBR2QsWUFBWSxDQUFDYyxDQUFDLENBQUMsR0FBR0EsQ0FBQztFQUN0RCxNQUFNRyxFQUFFLEdBQUcsT0FBT0YsQ0FBQyxLQUFLLFFBQVEsR0FBR2YsWUFBWSxDQUFDZSxDQUFDLENBQUMsR0FBR0EsQ0FBQztFQUN0RCxPQUFPQyxFQUFFLENBQUNSLEtBQUssR0FBR1MsRUFBRSxDQUFDVCxLQUFLLElBQUlRLEVBQUUsQ0FBQ04sS0FBSyxHQUFHTyxFQUFFLENBQUNQLEtBQUssSUFBSU0sRUFBRSxDQUFDSixLQUFLLEdBQUdLLEVBQUUsQ0FBQ0wsS0FBSztBQUMxRTtBQUlBLE1BQU1NLEdBQVMsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7QUFFN0MsU0FBU0MsVUFBVUEsQ0FBQ0MsS0FBYSxFQUEwQjtFQUN6RCxJQUFJQyxFQUFNLEdBQUcsR0FBRztFQUNoQixJQUFJQyxJQUFJLEdBQUdGLEtBQUs7RUFDaEIsS0FBSyxNQUFNRyxDQUFDLElBQUlMLEdBQUcsRUFBRTtJQUNuQixJQUFJRSxLQUFLLENBQUNJLFVBQVUsQ0FBQ0QsQ0FBQyxDQUFDLEVBQUU7TUFDdkJGLEVBQUUsR0FBR0UsQ0FBQztNQUNORCxJQUFJLEdBQUdGLEtBQUssQ0FBQ0ssS0FBSyxDQUFDRixDQUFDLENBQUNHLE1BQU0sQ0FBQztNQUM1QjtJQUNGO0VBQ0Y7RUFDQSxNQUFNQyxLQUFLLEdBQUczQixZQUFZLENBQUNzQixJQUFJLENBQUM7RUFDaEMsT0FBUXJCLENBQVMsSUFBSztJQUNwQixNQUFNMkIsQ0FBQyxHQUFHZixlQUFlLENBQUNaLENBQUMsRUFBRTBCLEtBQUssQ0FBQztJQUNuQyxRQUFRTixFQUFFO01BQ1IsS0FBSyxJQUFJO1FBQ1AsT0FBT08sQ0FBQyxJQUFJLENBQUM7TUFDZixLQUFLLElBQUk7UUFDUCxPQUFPQSxDQUFDLElBQUksQ0FBQztNQUNmLEtBQUssR0FBRztRQUNOLE9BQU9BLENBQUMsR0FBRyxDQUFDO01BQ2QsS0FBSyxHQUFHO1FBQ04sT0FBT0EsQ0FBQyxHQUFHLENBQUM7TUFDZCxLQUFLLEdBQUc7UUFDTixPQUFPQSxDQUFDLEtBQUssQ0FBQztJQUNsQjtFQUNGLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLFNBQVNBLENBQUNDLE9BQXdCLEVBQUVDLEtBQWEsRUFBVztFQUMxRSxNQUFNOUIsQ0FBQyxHQUFHLE9BQU82QixPQUFPLEtBQUssUUFBUSxHQUFHOUIsWUFBWSxDQUFDOEIsT0FBTyxDQUFDLEdBQUdBLE9BQU87RUFDdkUsTUFBTUUsTUFBTSxHQUFHRCxLQUFLLENBQUMzQixJQUFJLENBQUMsQ0FBQyxDQUFDNkIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDQyxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDVCxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ3BFLE9BQU9NLE1BQU0sQ0FBQ0ksS0FBSyxDQUFFRCxDQUFDLElBQUtoQixVQUFVLENBQUNnQixDQUFDLENBQUMsQ0FBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQzlDIiwiaWdub3JlTGlzdCI6W119