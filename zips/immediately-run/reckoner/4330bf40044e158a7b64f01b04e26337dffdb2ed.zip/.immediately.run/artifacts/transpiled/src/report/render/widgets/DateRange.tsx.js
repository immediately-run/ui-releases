var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DateRange;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _attrs = require("../attrs.ts");
var _useParam = require("./useParam.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // DateRange widget — writes a string `params.<name>` naming a relative range preset (§3.3).
// v1 offers a closed preset list resolvable by the stdlib's `resolveRange(preset, now)`; a
// custom calendar picker is a deferred enrichment. The declared preset set is the validation.
const PRESETS = ['last-30d', 'last-90d', 'last-12m', 'ytd', 'all'];
function DateRange({
  node
}) {
  _s();
  const name = (0, _attrs.attrString)(node, 'name') ?? '';
  const def = (0, _attrs.attrString)(node, 'default') ?? 'last-90d';
  const options = PRESETS.includes(def) ? PRESETS : [def, ...PRESETS];
  const {
    value,
    set
  } = (0, _useParam.useParam)(name, def);
  const current = typeof value === 'string' ? value : def;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
    className: "rk-widget rk-widget-daterange",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rk-widget-label",
      children: name
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("select", {
      value: current,
      onChange: e => set(e.target.value),
      children: options.map(o => /*#__PURE__*/(0, _jsxRuntime.jsx)("option", {
        value: o,
        children: o
      }, o))
    })]
  });
}
_s(DateRange, "P5g961Dx7UfkNf2t68spDCPaBwI=", false, function () {
  return [_useParam.useParam];
});
_c = DateRange;
var _c;
$RefreshReg$(_c, "DateRange");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3VzZVBhcmFtIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlBSRVNFVFMiLCJEYXRlUmFuZ2UiLCJub2RlIiwibmFtZSIsImF0dHJTdHJpbmciLCJkZWYiLCJvcHRpb25zIiwiaW5jbHVkZXMiLCJ2YWx1ZSIsInNldCIsInVzZVBhcmFtIiwiY3VycmVudCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsIm1hcCIsIm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhdGVSYW5nZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRGF0ZVJhbmdlIHdpZGdldCDigJQgd3JpdGVzIGEgc3RyaW5nIGBwYXJhbXMuPG5hbWU+YCBuYW1pbmcgYSByZWxhdGl2ZSByYW5nZSBwcmVzZXQgKMKnMy4zKS5cbi8vIHYxIG9mZmVycyBhIGNsb3NlZCBwcmVzZXQgbGlzdCByZXNvbHZhYmxlIGJ5IHRoZSBzdGRsaWIncyBgcmVzb2x2ZVJhbmdlKHByZXNldCwgbm93KWA7IGFcbi8vIGN1c3RvbSBjYWxlbmRhciBwaWNrZXIgaXMgYSBkZWZlcnJlZCBlbnJpY2htZW50LiBUaGUgZGVjbGFyZWQgcHJlc2V0IHNldCBpcyB0aGUgdmFsaWRhdGlvbi5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyB1c2VQYXJhbSB9IGZyb20gJy4vdXNlUGFyYW0udHMnO1xuXG5jb25zdCBQUkVTRVRTID0gWydsYXN0LTMwZCcsICdsYXN0LTkwZCcsICdsYXN0LTEybScsICd5dGQnLCAnYWxsJ107XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhdGVSYW5nZSh7IG5vZGUgfTogeyBub2RlOiBDb21wb25lbnROb2RlIH0pIHtcbiAgY29uc3QgbmFtZSA9IGF0dHJTdHJpbmcobm9kZSwgJ25hbWUnKSA/PyAnJztcbiAgY29uc3QgZGVmID0gYXR0clN0cmluZyhub2RlLCAnZGVmYXVsdCcpID8/ICdsYXN0LTkwZCc7XG4gIGNvbnN0IG9wdGlvbnMgPSBQUkVTRVRTLmluY2x1ZGVzKGRlZikgPyBQUkVTRVRTIDogW2RlZiwgLi4uUFJFU0VUU107XG4gIGNvbnN0IHsgdmFsdWUsIHNldCB9ID0gdXNlUGFyYW0obmFtZSwgZGVmKTtcbiAgY29uc3QgY3VycmVudCA9IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyB2YWx1ZSA6IGRlZjtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwicmstd2lkZ2V0IHJrLXdpZGdldC1kYXRlcmFuZ2VcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdpZGdldC1sYWJlbFwiPntuYW1lfTwvc3Bhbj5cbiAgICAgIDxzZWxlY3QgdmFsdWU9e2N1cnJlbnR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0KGUudGFyZ2V0LnZhbHVlKX0+XG4gICAgICAgIHtvcHRpb25zLm1hcCgobykgPT4gKFxuICAgICAgICAgIDxvcHRpb24ga2V5PXtvfSB2YWx1ZT17b30+XG4gICAgICAgICAgICB7b31cbiAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L3NlbGVjdD5cbiAgICA8L2xhYmVsPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUlBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQUF5QyxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFBQSxJQUFBRyxFQUFBLEdBQUFDLFlBQUEsSUFMekM7QUFDQTtBQUNBO0FBS0EsTUFBTUMsT0FBTyxHQUFHLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztBQUVuRCxTQUFTQyxTQUFTQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBSixFQUFBO0VBQ25FLE1BQU1LLElBQUksR0FBRyxJQUFBQyxpQkFBVSxFQUFDRixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRTtFQUMzQyxNQUFNRyxHQUFHLEdBQUcsSUFBQUQsaUJBQVUsRUFBQ0YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJLFVBQVU7RUFDckQsTUFBTUksT0FBTyxHQUFHTixPQUFPLENBQUNPLFFBQVEsQ0FBQ0YsR0FBRyxDQUFDLEdBQUdMLE9BQU8sR0FBRyxDQUFDSyxHQUFHLEVBQUUsR0FBR0wsT0FBTyxDQUFDO0VBQ25FLE1BQU07SUFBRVEsS0FBSztJQUFFQztFQUFJLENBQUMsR0FBRyxJQUFBQyxrQkFBUSxFQUFDUCxJQUFJLEVBQUVFLEdBQUcsQ0FBQztFQUMxQyxNQUFNTSxPQUFPLEdBQUcsT0FBT0gsS0FBSyxLQUFLLFFBQVEsR0FBR0EsS0FBSyxHQUFHSCxHQUFHO0VBQ3ZELG9CQUNFLElBQUFSLFdBQUEsQ0FBQWUsSUFBQTtJQUFPQyxTQUFTLEVBQUMsK0JBQStCO0lBQUFDLFFBQUEsZ0JBQzlDLElBQUFqQixXQUFBLENBQUFrQixHQUFBO01BQU1GLFNBQVMsRUFBQyxpQkFBaUI7TUFBQUMsUUFBQSxFQUFFWDtJQUFJLENBQU8sQ0FBQyxlQUMvQyxJQUFBTixXQUFBLENBQUFrQixHQUFBO01BQVFQLEtBQUssRUFBRUcsT0FBUTtNQUFDSyxRQUFRLEVBQUdDLENBQUMsSUFBS1IsR0FBRyxDQUFDUSxDQUFDLENBQUNDLE1BQU0sQ0FBQ1YsS0FBSyxDQUFFO01BQUFNLFFBQUEsRUFDMURSLE9BQU8sQ0FBQ2EsR0FBRyxDQUFFQyxDQUFDLGlCQUNiLElBQUF2QixXQUFBLENBQUFrQixHQUFBO1FBQWdCUCxLQUFLLEVBQUVZLENBQUU7UUFBQU4sUUFBQSxFQUN0Qk07TUFBQyxHQURTQSxDQUVMLENBQ1Q7SUFBQyxDQUNJLENBQUM7RUFBQSxDQUNKLENBQUM7QUFFWjtBQUFDdEIsRUFBQSxDQWxCdUJHLFNBQVM7RUFBQSxRQUlSUyxrQkFBUTtBQUFBO0FBQUFXLEVBQUEsR0FKVHBCLFNBQVM7QUFBQSxJQUFBb0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}