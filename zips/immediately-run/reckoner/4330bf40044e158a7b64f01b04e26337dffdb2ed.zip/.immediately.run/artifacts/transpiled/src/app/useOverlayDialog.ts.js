"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useOverlayDialog = useOverlayDialog;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
var _react = require("react");
// The dialog-behaviour half of R-IX-1 for reckoner's two overlays (R3-610): a `role=dialog`
// surface must move focus in on open, trap Tab within, answer Escape, and return focus to
// the control that opened it — the decision set R3-592 generalized for the host's own
// chrome, written here locally because a region app cannot import the host's hooks. One
// hook, two callers (the inspector dock, the workbook panel); the SDK dialog primitive
// (R3-613) is the future swap target, and its parity test is what will make the swap safe.

/** Options: `enabled` gates the whole contract (attach, focus-in, restore) on one flag. */

/**
 * The modal-dialog contract for one overlay element: attach the returned `ref` to the
 * element that carries `role="dialog"` / `aria-modal`. While enabled, focus moves to the
 * first focusable inside the element on open (the element itself, made minimally
 * focusable, when it has none), Tab and Shift-Tab wrap within it — the focusable list is
 * re-read at keydown, so a panel that mounts later (WhatIfPanel) joins the trap without a
 * re-render — Escape calls `onClose`, and disable/unmount restores the invoker captured at
 * open, guarded for an invoker that has itself unmounted.
 */
function useOverlayDialog(onClose, {
  enabled = true
} = {}) {
  const ref = (0, _react.useRef)(null);
  // Latest-ref so a parent's re-render with a new closure never re-runs the effect (which
  // would re-capture the invoker mid-dialog); the handler reads it at event time.
  const onCloseRef = (0, _react.useRef)(onClose);
  (0, _react.useEffect)(() => {
    onCloseRef.current = onClose;
  });
  (0, _react.useEffect)(() => {
    if (!enabled) return;
    const root = ref.current;
    if (!root) return;
    const invoker = document.activeElement instanceof HTMLElement ? document.activeElement : null;

    // Anything the keyboard can stop on, disabled controls excluded, read fresh every time.
    // `summary` is implicitly tabbable (the vocabulary section's entry toggles), and a
    // closed `<details>` hides its content — everything but its own summary — so those
    // matches are dropped: a hidden Copy button is not in the tab order, and counting it
    // as the tail would let Tab escape the trap at the last visible focusable (R3-610 r2).
    const SELECTOR = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), summary:not([tabindex="-1"]), [tabindex]:not([tabindex="-1"])';
    const rendered = el => {
      for (let n = el.parentElement; n !== null && n !== root; n = n.parentElement) {
        if (n instanceof HTMLDetailsElement && !n.open && !(el.tagName === 'SUMMARY' && el.parentElement === n)) {
          return false;
        }
      }
      return true;
    };
    const focusables = () => Array.from(root.querySelectorAll(SELECTOR)).filter(el => rendered(el));
    const first = focusables()[0] ?? null;
    if (first) first.focus();else {
      // No focusable child: the root itself becomes the focus stop so Escape/Tab still land.
      root.tabIndex = -1;
      root.focus();
    }
    const onKeyDown = e => {
      if (e.key === 'Escape') {
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab') return;
      const list = focusables();
      if (list.length === 0) {
        e.preventDefault();
        return;
      }
      const head = list[0];
      const tail = list[list.length - 1];
      const active = document.activeElement;
      if (e.shiftKey) {
        if (active === head || active === root) {
          e.preventDefault();
          tail.focus();
        }
      } else if (active === tail || active === root) {
        e.preventDefault();
        head.focus();
      }
    };
    root.addEventListener('keydown', onKeyDown);
    return () => {
      root.removeEventListener('keydown', onKeyDown);
      if (invoker !== null && invoker.isConnected) invoker.focus();
    };
  }, [enabled]);
  return ref;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwidXNlT3ZlcmxheURpYWxvZyIsIm9uQ2xvc2UiLCJlbmFibGVkIiwicmVmIiwidXNlUmVmIiwib25DbG9zZVJlZiIsInVzZUVmZmVjdCIsImN1cnJlbnQiLCJyb290IiwiaW52b2tlciIsImRvY3VtZW50IiwiYWN0aXZlRWxlbWVudCIsIkhUTUxFbGVtZW50IiwiU0VMRUNUT1IiLCJyZW5kZXJlZCIsImVsIiwibiIsInBhcmVudEVsZW1lbnQiLCJIVE1MRGV0YWlsc0VsZW1lbnQiLCJvcGVuIiwidGFnTmFtZSIsImZvY3VzYWJsZXMiLCJBcnJheSIsImZyb20iLCJxdWVyeVNlbGVjdG9yQWxsIiwiZmlsdGVyIiwiZmlyc3QiLCJmb2N1cyIsInRhYkluZGV4Iiwib25LZXlEb3duIiwiZSIsImtleSIsImxpc3QiLCJsZW5ndGgiLCJwcmV2ZW50RGVmYXVsdCIsImhlYWQiLCJ0YWlsIiwiYWN0aXZlIiwic2hpZnRLZXkiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImlzQ29ubmVjdGVkIl0sInNvdXJjZXMiOlsidXNlT3ZlcmxheURpYWxvZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgZGlhbG9nLWJlaGF2aW91ciBoYWxmIG9mIFItSVgtMSBmb3IgcmVja29uZXIncyB0d28gb3ZlcmxheXMgKFIzLTYxMCk6IGEgYHJvbGU9ZGlhbG9nYFxuLy8gc3VyZmFjZSBtdXN0IG1vdmUgZm9jdXMgaW4gb24gb3BlbiwgdHJhcCBUYWIgd2l0aGluLCBhbnN3ZXIgRXNjYXBlLCBhbmQgcmV0dXJuIGZvY3VzIHRvXG4vLyB0aGUgY29udHJvbCB0aGF0IG9wZW5lZCBpdCDigJQgdGhlIGRlY2lzaW9uIHNldCBSMy01OTIgZ2VuZXJhbGl6ZWQgZm9yIHRoZSBob3N0J3Mgb3duXG4vLyBjaHJvbWUsIHdyaXR0ZW4gaGVyZSBsb2NhbGx5IGJlY2F1c2UgYSByZWdpb24gYXBwIGNhbm5vdCBpbXBvcnQgdGhlIGhvc3QncyBob29rcy4gT25lXG4vLyBob29rLCB0d28gY2FsbGVycyAodGhlIGluc3BlY3RvciBkb2NrLCB0aGUgd29ya2Jvb2sgcGFuZWwpOyB0aGUgU0RLIGRpYWxvZyBwcmltaXRpdmVcbi8vIChSMy02MTMpIGlzIHRoZSBmdXR1cmUgc3dhcCB0YXJnZXQsIGFuZCBpdHMgcGFyaXR5IHRlc3QgaXMgd2hhdCB3aWxsIG1ha2UgdGhlIHN3YXAgc2FmZS5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB0eXBlIFJlZk9iamVjdCB9IGZyb20gJ3JlYWN0JztcblxuLyoqIE9wdGlvbnM6IGBlbmFibGVkYCBnYXRlcyB0aGUgd2hvbGUgY29udHJhY3QgKGF0dGFjaCwgZm9jdXMtaW4sIHJlc3RvcmUpIG9uIG9uZSBmbGFnLiAqL1xuZXhwb3J0IGludGVyZmFjZSBPdmVybGF5RGlhbG9nT3B0aW9ucyB7XG4gIGVuYWJsZWQ/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIFRoZSBtb2RhbC1kaWFsb2cgY29udHJhY3QgZm9yIG9uZSBvdmVybGF5IGVsZW1lbnQ6IGF0dGFjaCB0aGUgcmV0dXJuZWQgYHJlZmAgdG8gdGhlXG4gKiBlbGVtZW50IHRoYXQgY2FycmllcyBgcm9sZT1cImRpYWxvZ1wiYCAvIGBhcmlhLW1vZGFsYC4gV2hpbGUgZW5hYmxlZCwgZm9jdXMgbW92ZXMgdG8gdGhlXG4gKiBmaXJzdCBmb2N1c2FibGUgaW5zaWRlIHRoZSBlbGVtZW50IG9uIG9wZW4gKHRoZSBlbGVtZW50IGl0c2VsZiwgbWFkZSBtaW5pbWFsbHlcbiAqIGZvY3VzYWJsZSwgd2hlbiBpdCBoYXMgbm9uZSksIFRhYiBhbmQgU2hpZnQtVGFiIHdyYXAgd2l0aGluIGl0IOKAlCB0aGUgZm9jdXNhYmxlIGxpc3QgaXNcbiAqIHJlLXJlYWQgYXQga2V5ZG93biwgc28gYSBwYW5lbCB0aGF0IG1vdW50cyBsYXRlciAoV2hhdElmUGFuZWwpIGpvaW5zIHRoZSB0cmFwIHdpdGhvdXQgYVxuICogcmUtcmVuZGVyIOKAlCBFc2NhcGUgY2FsbHMgYG9uQ2xvc2VgLCBhbmQgZGlzYWJsZS91bm1vdW50IHJlc3RvcmVzIHRoZSBpbnZva2VyIGNhcHR1cmVkIGF0XG4gKiBvcGVuLCBndWFyZGVkIGZvciBhbiBpbnZva2VyIHRoYXQgaGFzIGl0c2VsZiB1bm1vdW50ZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPdmVybGF5RGlhbG9nPFQgZXh0ZW5kcyBIVE1MRWxlbWVudD4oXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQsXG4gIHsgZW5hYmxlZCA9IHRydWUgfTogT3ZlcmxheURpYWxvZ09wdGlvbnMgPSB7fSxcbik6IFJlZk9iamVjdDxUIHwgbnVsbD4ge1xuICBjb25zdCByZWYgPSB1c2VSZWY8VCB8IG51bGw+KG51bGwpO1xuICAvLyBMYXRlc3QtcmVmIHNvIGEgcGFyZW50J3MgcmUtcmVuZGVyIHdpdGggYSBuZXcgY2xvc3VyZSBuZXZlciByZS1ydW5zIHRoZSBlZmZlY3QgKHdoaWNoXG4gIC8vIHdvdWxkIHJlLWNhcHR1cmUgdGhlIGludm9rZXIgbWlkLWRpYWxvZyk7IHRoZSBoYW5kbGVyIHJlYWRzIGl0IGF0IGV2ZW50IHRpbWUuXG4gIGNvbnN0IG9uQ2xvc2VSZWYgPSB1c2VSZWYob25DbG9zZSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb25DbG9zZVJlZi5jdXJyZW50ID0gb25DbG9zZTtcbiAgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHJldHVybjtcbiAgICBjb25zdCByb290ID0gcmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFyb290KSByZXR1cm47XG4gICAgY29uc3QgaW52b2tlciA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCA/IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgOiBudWxsO1xuXG4gICAgLy8gQW55dGhpbmcgdGhlIGtleWJvYXJkIGNhbiBzdG9wIG9uLCBkaXNhYmxlZCBjb250cm9scyBleGNsdWRlZCwgcmVhZCBmcmVzaCBldmVyeSB0aW1lLlxuICAgIC8vIGBzdW1tYXJ5YCBpcyBpbXBsaWNpdGx5IHRhYmJhYmxlICh0aGUgdm9jYWJ1bGFyeSBzZWN0aW9uJ3MgZW50cnkgdG9nZ2xlcyksIGFuZCBhXG4gICAgLy8gY2xvc2VkIGA8ZGV0YWlscz5gIGhpZGVzIGl0cyBjb250ZW50IOKAlCBldmVyeXRoaW5nIGJ1dCBpdHMgb3duIHN1bW1hcnkg4oCUIHNvIHRob3NlXG4gICAgLy8gbWF0Y2hlcyBhcmUgZHJvcHBlZDogYSBoaWRkZW4gQ29weSBidXR0b24gaXMgbm90IGluIHRoZSB0YWIgb3JkZXIsIGFuZCBjb3VudGluZyBpdFxuICAgIC8vIGFzIHRoZSB0YWlsIHdvdWxkIGxldCBUYWIgZXNjYXBlIHRoZSB0cmFwIGF0IHRoZSBsYXN0IHZpc2libGUgZm9jdXNhYmxlIChSMy02MTAgcjIpLlxuICAgIGNvbnN0IFNFTEVDVE9SID1cbiAgICAgICdhW2hyZWZdLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCBpbnB1dDpub3QoW2Rpc2FibGVkXSksIHNlbGVjdDpub3QoW2Rpc2FibGVkXSksIHRleHRhcmVhOm5vdChbZGlzYWJsZWRdKSwgc3VtbWFyeTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCBbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9XCItMVwiXSknO1xuICAgIGNvbnN0IHJlbmRlcmVkID0gKGVsOiBIVE1MRWxlbWVudCk6IGJvb2xlYW4gPT4ge1xuICAgICAgZm9yIChsZXQgbjogTm9kZSB8IG51bGwgPSBlbC5wYXJlbnRFbGVtZW50OyBuICE9PSBudWxsICYmIG4gIT09IHJvb3Q7IG4gPSBuLnBhcmVudEVsZW1lbnQpIHtcbiAgICAgICAgaWYgKG4gaW5zdGFuY2VvZiBIVE1MRGV0YWlsc0VsZW1lbnQgJiYgIW4ub3BlbiAmJiAhKGVsLnRhZ05hbWUgPT09ICdTVU1NQVJZJyAmJiBlbC5wYXJlbnRFbGVtZW50ID09PSBuKSkge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfTtcbiAgICBjb25zdCBmb2N1c2FibGVzID0gKCkgPT5cbiAgICAgIEFycmF5LmZyb20ocm9vdC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihTRUxFQ1RPUikpLmZpbHRlcigoZWwpID0+IHJlbmRlcmVkKGVsKSk7XG5cbiAgICBjb25zdCBmaXJzdCA9IGZvY3VzYWJsZXMoKVswXSA/PyBudWxsO1xuICAgIGlmIChmaXJzdCkgZmlyc3QuZm9jdXMoKTtcbiAgICBlbHNlIHtcbiAgICAgIC8vIE5vIGZvY3VzYWJsZSBjaGlsZDogdGhlIHJvb3QgaXRzZWxmIGJlY29tZXMgdGhlIGZvY3VzIHN0b3Agc28gRXNjYXBlL1RhYiBzdGlsbCBsYW5kLlxuICAgICAgcm9vdC50YWJJbmRleCA9IC0xO1xuICAgICAgcm9vdC5mb2N1cygpO1xuICAgIH1cblxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgIG9uQ2xvc2VSZWYuY3VycmVudCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZS5rZXkgIT09ICdUYWInKSByZXR1cm47XG4gICAgICBjb25zdCBsaXN0ID0gZm9jdXNhYmxlcygpO1xuICAgICAgaWYgKGxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgaGVhZCA9IGxpc3RbMF07XG4gICAgICBjb25zdCB0YWlsID0gbGlzdFtsaXN0Lmxlbmd0aCAtIDFdO1xuICAgICAgY29uc3QgYWN0aXZlID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgIGlmIChlLnNoaWZ0S2V5KSB7XG4gICAgICAgIGlmIChhY3RpdmUgPT09IGhlYWQgfHwgYWN0aXZlID09PSByb290KSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIHRhaWwuZm9jdXMoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChhY3RpdmUgPT09IHRhaWwgfHwgYWN0aXZlID09PSByb290KSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaGVhZC5mb2N1cygpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICByb290LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICByb290LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24pO1xuICAgICAgaWYgKGludm9rZXIgIT09IG51bGwgJiYgaW52b2tlci5pc0Nvbm5lY3RlZCkgaW52b2tlci5mb2N1cygpO1xuICAgIH07XG4gIH0sIFtlbmFibGVkXSk7XG5cbiAgcmV0dXJuIHJlZjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFNQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7O0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsZ0JBQWdCQSxDQUM5QkMsT0FBbUIsRUFDbkI7RUFBRUMsT0FBTyxHQUFHO0FBQTJCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDeEI7RUFDckIsTUFBTUMsR0FBRyxHQUFHLElBQUFDLGFBQU0sRUFBVyxJQUFJLENBQUM7RUFDbEM7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBRyxJQUFBRCxhQUFNLEVBQUNILE9BQU8sQ0FBQztFQUNsQyxJQUFBSyxnQkFBUyxFQUFDLE1BQU07SUFDZEQsVUFBVSxDQUFDRSxPQUFPLEdBQUdOLE9BQU87RUFDOUIsQ0FBQyxDQUFDO0VBRUYsSUFBQUssZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDSixPQUFPLEVBQUU7SUFDZCxNQUFNTSxJQUFJLEdBQUdMLEdBQUcsQ0FBQ0ksT0FBTztJQUN4QixJQUFJLENBQUNDLElBQUksRUFBRTtJQUNYLE1BQU1DLE9BQU8sR0FBR0MsUUFBUSxDQUFDQyxhQUFhLFlBQVlDLFdBQVcsR0FBR0YsUUFBUSxDQUFDQyxhQUFhLEdBQUcsSUFBSTs7SUFFN0Y7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1FLFFBQVEsR0FDWix5S0FBeUs7SUFDM0ssTUFBTUMsUUFBUSxHQUFJQyxFQUFlLElBQWM7TUFDN0MsS0FBSyxJQUFJQyxDQUFjLEdBQUdELEVBQUUsQ0FBQ0UsYUFBYSxFQUFFRCxDQUFDLEtBQUssSUFBSSxJQUFJQSxDQUFDLEtBQUtSLElBQUksRUFBRVEsQ0FBQyxHQUFHQSxDQUFDLENBQUNDLGFBQWEsRUFBRTtRQUN6RixJQUFJRCxDQUFDLFlBQVlFLGtCQUFrQixJQUFJLENBQUNGLENBQUMsQ0FBQ0csSUFBSSxJQUFJLEVBQUVKLEVBQUUsQ0FBQ0ssT0FBTyxLQUFLLFNBQVMsSUFBSUwsRUFBRSxDQUFDRSxhQUFhLEtBQUtELENBQUMsQ0FBQyxFQUFFO1VBQ3ZHLE9BQU8sS0FBSztRQUNkO01BQ0Y7TUFDQSxPQUFPLElBQUk7SUFDYixDQUFDO0lBQ0QsTUFBTUssVUFBVSxHQUFHQSxDQUFBLEtBQ2pCQyxLQUFLLENBQUNDLElBQUksQ0FBQ2YsSUFBSSxDQUFDZ0IsZ0JBQWdCLENBQWNYLFFBQVEsQ0FBQyxDQUFDLENBQUNZLE1BQU0sQ0FBRVYsRUFBRSxJQUFLRCxRQUFRLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBRXZGLE1BQU1XLEtBQUssR0FBR0wsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJO0lBQ3JDLElBQUlLLEtBQUssRUFBRUEsS0FBSyxDQUFDQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQ3BCO01BQ0g7TUFDQW5CLElBQUksQ0FBQ29CLFFBQVEsR0FBRyxDQUFDLENBQUM7TUFDbEJwQixJQUFJLENBQUNtQixLQUFLLENBQUMsQ0FBQztJQUNkO0lBRUEsTUFBTUUsU0FBUyxHQUFJQyxDQUFnQixJQUFLO01BQ3RDLElBQUlBLENBQUMsQ0FBQ0MsR0FBRyxLQUFLLFFBQVEsRUFBRTtRQUN0QjFCLFVBQVUsQ0FBQ0UsT0FBTyxDQUFDLENBQUM7UUFDcEI7TUFDRjtNQUNBLElBQUl1QixDQUFDLENBQUNDLEdBQUcsS0FBSyxLQUFLLEVBQUU7TUFDckIsTUFBTUMsSUFBSSxHQUFHWCxVQUFVLENBQUMsQ0FBQztNQUN6QixJQUFJVyxJQUFJLENBQUNDLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDckJILENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEI7TUFDRjtNQUNBLE1BQU1DLElBQUksR0FBR0gsSUFBSSxDQUFDLENBQUMsQ0FBQztNQUNwQixNQUFNSSxJQUFJLEdBQUdKLElBQUksQ0FBQ0EsSUFBSSxDQUFDQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQ2xDLE1BQU1JLE1BQU0sR0FBRzNCLFFBQVEsQ0FBQ0MsYUFBYTtNQUNyQyxJQUFJbUIsQ0FBQyxDQUFDUSxRQUFRLEVBQUU7UUFDZCxJQUFJRCxNQUFNLEtBQUtGLElBQUksSUFBSUUsTUFBTSxLQUFLN0IsSUFBSSxFQUFFO1VBQ3RDc0IsQ0FBQyxDQUFDSSxjQUFjLENBQUMsQ0FBQztVQUNsQkUsSUFBSSxDQUFDVCxLQUFLLENBQUMsQ0FBQztRQUNkO01BQ0YsQ0FBQyxNQUFNLElBQUlVLE1BQU0sS0FBS0QsSUFBSSxJQUFJQyxNQUFNLEtBQUs3QixJQUFJLEVBQUU7UUFDN0NzQixDQUFDLENBQUNJLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCQyxJQUFJLENBQUNSLEtBQUssQ0FBQyxDQUFDO01BQ2Q7SUFDRixDQUFDO0lBRURuQixJQUFJLENBQUMrQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUVWLFNBQVMsQ0FBQztJQUMzQyxPQUFPLE1BQU07TUFDWHJCLElBQUksQ0FBQ2dDLG1CQUFtQixDQUFDLFNBQVMsRUFBRVgsU0FBUyxDQUFDO01BQzlDLElBQUlwQixPQUFPLEtBQUssSUFBSSxJQUFJQSxPQUFPLENBQUNnQyxXQUFXLEVBQUVoQyxPQUFPLENBQUNrQixLQUFLLENBQUMsQ0FBQztJQUM5RCxDQUFDO0VBQ0gsQ0FBQyxFQUFFLENBQUN6QixPQUFPLENBQUMsQ0FBQztFQUViLE9BQU9DLEdBQUc7QUFDWiIsImlnbm9yZUxpc3QiOltdfQ==