"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.contentKey = contentKey;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
// Content keys for early cutoff (ARCHITECTURE_PLAN §4.2). The scheduler skips propagating
// a recomputed cell whose result is unchanged; "unchanged" is decided by a **content key**,
// not reference identity alone. To keep cutoff sound (a stale value slipping through is a
// correctness hole, and — via the tier pair rule — a tier-laundering hole), the key is a
// *canonical serialization*, not a lossy digest: distinct values never share a key.
// Reference equality is the cheap fast path the scheduler checks first; this is the fallback.

/**
 * A canonical, collision-free string key for a plain value: object keys sorted, arrays in
 * order, scalars tagged by JSON so `1` (number) and `"1"` (string) never collide.
 */
function contentKey(v) {
  return encode(v);
}
function encode(v) {
  if (v === null) return 'null';
  if (typeof v === 'number') return `n:${v}`;
  if (typeof v === 'boolean') return `b:${v}`;
  if (typeof v === 'string') return `s:${JSON.stringify(v)}`;
  if (Array.isArray(v)) return `[${v.map(encode).join(',')}]`;
  const keys = Object.keys(v).sort();
  return `{${keys.map(k => `${JSON.stringify(k)}:${encode(v[k])}`).join(',')}}`;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjb250ZW50S2V5IiwidiIsImVuY29kZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJBcnJheSIsImlzQXJyYXkiLCJtYXAiLCJqb2luIiwia2V5cyIsIk9iamVjdCIsInNvcnQiLCJrIl0sInNvdXJjZXMiOlsiaGFzaC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb250ZW50IGtleXMgZm9yIGVhcmx5IGN1dG9mZiAoQVJDSElURUNUVVJFX1BMQU4gwqc0LjIpLiBUaGUgc2NoZWR1bGVyIHNraXBzIHByb3BhZ2F0aW5nXG4vLyBhIHJlY29tcHV0ZWQgY2VsbCB3aG9zZSByZXN1bHQgaXMgdW5jaGFuZ2VkOyBcInVuY2hhbmdlZFwiIGlzIGRlY2lkZWQgYnkgYSAqKmNvbnRlbnQga2V5KiosXG4vLyBub3QgcmVmZXJlbmNlIGlkZW50aXR5IGFsb25lLiBUbyBrZWVwIGN1dG9mZiBzb3VuZCAoYSBzdGFsZSB2YWx1ZSBzbGlwcGluZyB0aHJvdWdoIGlzIGFcbi8vIGNvcnJlY3RuZXNzIGhvbGUsIGFuZCDigJQgdmlhIHRoZSB0aWVyIHBhaXIgcnVsZSDigJQgYSB0aWVyLWxhdW5kZXJpbmcgaG9sZSksIHRoZSBrZXkgaXMgYVxuLy8gKmNhbm9uaWNhbCBzZXJpYWxpemF0aW9uKiwgbm90IGEgbG9zc3kgZGlnZXN0OiBkaXN0aW5jdCB2YWx1ZXMgbmV2ZXIgc2hhcmUgYSBrZXkuXG4vLyBSZWZlcmVuY2UgZXF1YWxpdHkgaXMgdGhlIGNoZWFwIGZhc3QgcGF0aCB0aGUgc2NoZWR1bGVyIGNoZWNrcyBmaXJzdDsgdGhpcyBpcyB0aGUgZmFsbGJhY2suXG5cbmltcG9ydCB0eXBlIHsgVmFsdWUgfSBmcm9tICcuLi9zdGRsaWIvdHlwZXMudHMnO1xuXG4vKipcbiAqIEEgY2Fub25pY2FsLCBjb2xsaXNpb24tZnJlZSBzdHJpbmcga2V5IGZvciBhIHBsYWluIHZhbHVlOiBvYmplY3Qga2V5cyBzb3J0ZWQsIGFycmF5cyBpblxuICogb3JkZXIsIHNjYWxhcnMgdGFnZ2VkIGJ5IEpTT04gc28gYDFgIChudW1iZXIpIGFuZCBgXCIxXCJgIChzdHJpbmcpIG5ldmVyIGNvbGxpZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb250ZW50S2V5KHY6IFZhbHVlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGVuY29kZSh2KTtcbn1cblxuZnVuY3Rpb24gZW5jb2RlKHY6IFZhbHVlKTogc3RyaW5nIHtcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiAnbnVsbCc7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicpIHJldHVybiBgbjoke3Z9YDtcbiAgaWYgKHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHJldHVybiBgYjoke3Z9YDtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIGBzOiR7SlNPTi5zdHJpbmdpZnkodil9YDtcbiAgaWYgKEFycmF5LmlzQXJyYXkodikpIHJldHVybiBgWyR7di5tYXAoZW5jb2RlKS5qb2luKCcsJyl9XWA7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh2KS5zb3J0KCk7XG4gIHJldHVybiBgeyR7a2V5cy5tYXAoKGspID0+IGAke0pTT04uc3RyaW5naWZ5KGspfToke2VuY29kZSh2W2tdKX1gKS5qb2luKCcsJyl9fWA7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0EsVUFBVUEsQ0FBQ0MsQ0FBUSxFQUFVO0VBQzNDLE9BQU9DLE1BQU0sQ0FBQ0QsQ0FBQyxDQUFDO0FBQ2xCO0FBRUEsU0FBU0MsTUFBTUEsQ0FBQ0QsQ0FBUSxFQUFVO0VBQ2hDLElBQUlBLENBQUMsS0FBSyxJQUFJLEVBQUUsT0FBTyxNQUFNO0VBQzdCLElBQUksT0FBT0EsQ0FBQyxLQUFLLFFBQVEsRUFBRSxPQUFPLEtBQUtBLENBQUMsRUFBRTtFQUMxQyxJQUFJLE9BQU9BLENBQUMsS0FBSyxTQUFTLEVBQUUsT0FBTyxLQUFLQSxDQUFDLEVBQUU7RUFDM0MsSUFBSSxPQUFPQSxDQUFDLEtBQUssUUFBUSxFQUFFLE9BQU8sS0FBS0UsSUFBSSxDQUFDQyxTQUFTLENBQUNILENBQUMsQ0FBQyxFQUFFO0VBQzFELElBQUlJLEtBQUssQ0FBQ0MsT0FBTyxDQUFDTCxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUlBLENBQUMsQ0FBQ00sR0FBRyxDQUFDTCxNQUFNLENBQUMsQ0FBQ00sSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO0VBQzNELE1BQU1DLElBQUksR0FBR0MsTUFBTSxDQUFDRCxJQUFJLENBQUNSLENBQUMsQ0FBQyxDQUFDVSxJQUFJLENBQUMsQ0FBQztFQUNsQyxPQUFPLElBQUlGLElBQUksQ0FBQ0YsR0FBRyxDQUFFSyxDQUFDLElBQUssR0FBR1QsSUFBSSxDQUFDQyxTQUFTLENBQUNRLENBQUMsQ0FBQyxJQUFJVixNQUFNLENBQUNELENBQUMsQ0FBQ1csQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUNKLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztBQUNqRiIsImlnbm9yZUxpc3QiOltdfQ==