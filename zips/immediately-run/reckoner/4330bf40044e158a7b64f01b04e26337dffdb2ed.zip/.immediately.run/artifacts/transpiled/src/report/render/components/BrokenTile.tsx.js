var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = BrokenTile;
var _jsxRuntime = require("react/jsx-runtime");
// The component-owned degraded state (§3.3 point 4, RQ-C2): a bound cell threw, was never
// published, or resolved to the wrong shape. View mode shows a marked broken tile with no
// internals; the reason is a muted caption (useful in edit mode, harmless in view). Never a
// blank, never a crash, never silent wrong data. An unconsented-feed variant reads as a
// "needs access" affordance rather than an error.
function BrokenTile({
  component,
  reason,
  variant = 'error'
}) {
  const title = variant === 'needs-access' ? 'Needs data access' : 'Unavailable';
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-broken",
    "data-variant": variant,
    role: "note",
    "aria-label": `${component}: ${title}`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rk-broken-title",
      children: title
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rk-broken-reason",
      children: reason
    })]
  });
}
_c = BrokenTile;
var _c;
$RefreshReg$(_c, "BrokenTile");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJCcm9rZW5UaWxlIiwiY29tcG9uZW50IiwicmVhc29uIiwidmFyaWFudCIsInRpdGxlIiwiX2pzeFJ1bnRpbWUiLCJqc3hzIiwiY2xhc3NOYW1lIiwicm9sZSIsImNoaWxkcmVuIiwianN4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCcm9rZW5UaWxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgY29tcG9uZW50LW93bmVkIGRlZ3JhZGVkIHN0YXRlICjCpzMuMyBwb2ludCA0LCBSUS1DMik6IGEgYm91bmQgY2VsbCB0aHJldywgd2FzIG5ldmVyXG4vLyBwdWJsaXNoZWQsIG9yIHJlc29sdmVkIHRvIHRoZSB3cm9uZyBzaGFwZS4gVmlldyBtb2RlIHNob3dzIGEgbWFya2VkIGJyb2tlbiB0aWxlIHdpdGggbm9cbi8vIGludGVybmFsczsgdGhlIHJlYXNvbiBpcyBhIG11dGVkIGNhcHRpb24gKHVzZWZ1bCBpbiBlZGl0IG1vZGUsIGhhcm1sZXNzIGluIHZpZXcpLiBOZXZlciBhXG4vLyBibGFuaywgbmV2ZXIgYSBjcmFzaCwgbmV2ZXIgc2lsZW50IHdyb25nIGRhdGEuIEFuIHVuY29uc2VudGVkLWZlZWQgdmFyaWFudCByZWFkcyBhcyBhXG4vLyBcIm5lZWRzIGFjY2Vzc1wiIGFmZm9yZGFuY2UgcmF0aGVyIHRoYW4gYW4gZXJyb3IuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCcm9rZW5UaWxlKHtcbiAgY29tcG9uZW50LFxuICByZWFzb24sXG4gIHZhcmlhbnQgPSAnZXJyb3InLFxufToge1xuICBjb21wb25lbnQ6IHN0cmluZztcbiAgcmVhc29uOiBzdHJpbmc7XG4gIHZhcmlhbnQ/OiAnZXJyb3InIHwgJ25lZWRzLWFjY2Vzcyc7XG59KSB7XG4gIGNvbnN0IHRpdGxlID0gdmFyaWFudCA9PT0gJ25lZWRzLWFjY2VzcycgPyAnTmVlZHMgZGF0YSBhY2Nlc3MnIDogJ1VuYXZhaWxhYmxlJztcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWJyb2tlblwiIGRhdGEtdmFyaWFudD17dmFyaWFudH0gcm9sZT1cIm5vdGVcIiBhcmlhLWxhYmVsPXtgJHtjb21wb25lbnR9OiAke3RpdGxlfWB9PlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstYnJva2VuLXRpdGxlXCI+e3RpdGxlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWJyb2tlbi1yZWFzb25cIj57cmVhc29ufTwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQSxVQUFVQSxDQUFDO0VBQ2pDQyxTQUFTO0VBQ1RDLE1BQU07RUFDTkMsT0FBTyxHQUFHO0FBS1osQ0FBQyxFQUFFO0VBQ0QsTUFBTUMsS0FBSyxHQUFHRCxPQUFPLEtBQUssY0FBYyxHQUFHLG1CQUFtQixHQUFHLGFBQWE7RUFDOUUsb0JBQ0UsSUFBQUUsV0FBQSxDQUFBQyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxXQUFXO0lBQUMsZ0JBQWNKLE9BQVE7SUFBQ0ssSUFBSSxFQUFDLE1BQU07SUFBQyxjQUFZLEdBQUdQLFNBQVMsS0FBS0csS0FBSyxFQUFHO0lBQUFLLFFBQUEsZ0JBQ2pHLElBQUFKLFdBQUEsQ0FBQUssR0FBQTtNQUFNSCxTQUFTLEVBQUMsaUJBQWlCO01BQUFFLFFBQUEsRUFBRUw7SUFBSyxDQUFPLENBQUMsZUFDaEQsSUFBQUMsV0FBQSxDQUFBSyxHQUFBO01BQU1ILFNBQVMsRUFBQyxrQkFBa0I7TUFBQUUsUUFBQSxFQUFFUDtJQUFNLENBQU8sQ0FBQztFQUFBLENBQy9DLENBQUM7QUFFVjtBQUFDUyxFQUFBLEdBaEJ1QlgsVUFBVTtBQUFBLElBQUFXLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}