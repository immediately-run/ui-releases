"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.precedentTree = precedentTree;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
// The precedent neighborhood (review-1 UX-4). Walking a 4-deep precedent chain one panel at
// a time is a regression against Excel's spatial Trace-Precedents, so the inspector offers
// the whole subgraph at once alongside the hop-by-hop chips. Pure: it folds the workbook's
// cell descriptors into a tree — the DAG unrolled as a tree (a diamond's shared node simply
// appears in both arms; cycles cannot occur, the engine rejects them at build), externals
// (`feeds.*`/`fixtures.*`/`params.*`/`static.*`) as the leaves the walk terminates at.
//
// Bounded by construction: a wide DAG unrolls toward exponential node counts, so the builder
// stops at `maxNodes` and reports `truncated` — the view says so rather than silently
// clipping (ways_of_working: no silent caps).

/** One node of the precedent tree: a cell (navigable) or an external leaf. */

const DEFAULT_MAX_NODES = 200;

/**
 * Build the precedent tree for a cell: every cell input, transitively, with externals as
 * leaves. Wildcards expand to their worksheet's cells (the conservative dependency set the
 * engine itself computes).
 */
function precedentTree(rootId, cells, maxNodes = DEFAULT_MAX_NODES) {
  const byId = new Map(cells.map(c => [c.id, c]));
  const root = byId.get(rootId);
  if (root === undefined) {
    return {
      root: {
        id: rootId,
        kind: 'cell',
        via: '',
        children: []
      },
      nodeCount: 0,
      truncated: false,
      depth: 0
    };
  }
  let budget = maxNodes;
  let truncated = false;
  const build = cell => {
    const out = [];
    for (const r of cell.resolvers) {
      if (budget <= 0) {
        truncated = true;
        break;
      }
      if (r.kind === 'cell') {
        const target = byId.get(r.nodeId);
        budget -= 1;
        out.push({
          id: r.nodeId,
          kind: 'cell',
          via: r.name,
          children: target === undefined ? [] : build(target)
        });
      } else if (r.kind === 'wildcard') {
        const members = cells.filter(c => c.worksheet === r.worksheet);
        for (const m of members) {
          if (budget <= 0) {
            truncated = true;
            break;
          }
          budget -= 1;
          out.push({
            id: m.id,
            kind: 'cell',
            via: r.name,
            detail: `${r.worksheet}.*`,
            children: build(m)
          });
        }
      } else if (r.kind === 'windowed-feed') {
        out.push({
          id: `feeds.${r.feed}`,
          kind: 'external',
          via: r.name,
          detail: r.window,
          children: []
        });
      } else {
        out.push({
          id: r.key,
          kind: 'external',
          via: r.name,
          children: []
        });
      }
    }
    return out;
  };
  const children = build(root);
  const tree = {
    root: {
      id: rootId,
      kind: 'cell',
      via: '',
      children
    },
    nodeCount: 1 + (maxNodes - budget),
    truncated,
    depth: 0
  };
  tree.depth = depthOf(tree.root);
  return tree;
}
function depthOf(node) {
  if (node.children.length === 0) return 0;
  return 1 + Math.max(...node.children.map(depthOf));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJERUZBVUxUX01BWF9OT0RFUyIsInByZWNlZGVudFRyZWUiLCJyb290SWQiLCJjZWxscyIsIm1heE5vZGVzIiwiYnlJZCIsIk1hcCIsIm1hcCIsImMiLCJpZCIsInJvb3QiLCJnZXQiLCJ1bmRlZmluZWQiLCJraW5kIiwidmlhIiwiY2hpbGRyZW4iLCJub2RlQ291bnQiLCJ0cnVuY2F0ZWQiLCJkZXB0aCIsImJ1ZGdldCIsImJ1aWxkIiwiY2VsbCIsIm91dCIsInIiLCJyZXNvbHZlcnMiLCJ0YXJnZXQiLCJub2RlSWQiLCJwdXNoIiwibmFtZSIsIm1lbWJlcnMiLCJmaWx0ZXIiLCJ3b3Jrc2hlZXQiLCJtIiwiZGV0YWlsIiwiZmVlZCIsIndpbmRvdyIsImtleSIsInRyZWUiLCJkZXB0aE9mIiwibm9kZSIsImxlbmd0aCIsIk1hdGgiLCJtYXgiXSwic291cmNlcyI6WyJwcmVjZWRlbnRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBwcmVjZWRlbnQgbmVpZ2hib3Job29kIChyZXZpZXctMSBVWC00KS4gV2Fsa2luZyBhIDQtZGVlcCBwcmVjZWRlbnQgY2hhaW4gb25lIHBhbmVsIGF0XG4vLyBhIHRpbWUgaXMgYSByZWdyZXNzaW9uIGFnYWluc3QgRXhjZWwncyBzcGF0aWFsIFRyYWNlLVByZWNlZGVudHMsIHNvIHRoZSBpbnNwZWN0b3Igb2ZmZXJzXG4vLyB0aGUgd2hvbGUgc3ViZ3JhcGggYXQgb25jZSBhbG9uZ3NpZGUgdGhlIGhvcC1ieS1ob3AgY2hpcHMuIFB1cmU6IGl0IGZvbGRzIHRoZSB3b3JrYm9vaydzXG4vLyBjZWxsIGRlc2NyaXB0b3JzIGludG8gYSB0cmVlIOKAlCB0aGUgREFHIHVucm9sbGVkIGFzIGEgdHJlZSAoYSBkaWFtb25kJ3Mgc2hhcmVkIG5vZGUgc2ltcGx5XG4vLyBhcHBlYXJzIGluIGJvdGggYXJtczsgY3ljbGVzIGNhbm5vdCBvY2N1ciwgdGhlIGVuZ2luZSByZWplY3RzIHRoZW0gYXQgYnVpbGQpLCBleHRlcm5hbHNcbi8vIChgZmVlZHMuKmAvYGZpeHR1cmVzLipgL2BwYXJhbXMuKmAvYHN0YXRpYy4qYCkgYXMgdGhlIGxlYXZlcyB0aGUgd2FsayB0ZXJtaW5hdGVzIGF0LlxuLy9cbi8vIEJvdW5kZWQgYnkgY29uc3RydWN0aW9uOiBhIHdpZGUgREFHIHVucm9sbHMgdG93YXJkIGV4cG9uZW50aWFsIG5vZGUgY291bnRzLCBzbyB0aGUgYnVpbGRlclxuLy8gc3RvcHMgYXQgYG1heE5vZGVzYCBhbmQgcmVwb3J0cyBgdHJ1bmNhdGVkYCDigJQgdGhlIHZpZXcgc2F5cyBzbyByYXRoZXIgdGhhbiBzaWxlbnRseVxuLy8gY2xpcHBpbmcgKHdheXNfb2Zfd29ya2luZzogbm8gc2lsZW50IGNhcHMpLlxuXG5pbXBvcnQgdHlwZSB7IENlbGxEZXNjcmlwdG9yIH0gZnJvbSAnLi93b3JrZXIvcHJvdG9jb2wudHMnO1xuXG4vKiogT25lIG5vZGUgb2YgdGhlIHByZWNlZGVudCB0cmVlOiBhIGNlbGwgKG5hdmlnYWJsZSkgb3IgYW4gZXh0ZXJuYWwgbGVhZi4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJlY2VkZW50Tm9kZSB7XG4gIC8qKiBDZWxsIGlkIChgcmV2ZW51ZS50b3RhbGApIG9yIGV4dGVybmFsIGtleSAoYGZlZWRzLm9yZGVyc2ApLiAqL1xuICBpZDogc3RyaW5nO1xuICBraW5kOiAnY2VsbCcgfCAnZXh0ZXJuYWwnO1xuICAvKiogVGhlIGRlY2xhcmVkIGlucHV0J3MgbG9jYWwgbmFtZSBhdCB0aGlzIGVkZ2UgKHdoeSB0aGlzIG5vZGUgaXMgaGVyZSkuICovXG4gIHZpYTogc3RyaW5nO1xuICAvKiogRXh0cmEgY29udGV4dCBmb3IgdGhlIGxhYmVsOiBhIHdpbmRvd2VkIGZlZWQncyB3aW5kb3csIGEgd2lsZGNhcmQncyB3b3Jrc2hlZXQuICovXG4gIGRldGFpbD86IHN0cmluZztcbiAgY2hpbGRyZW46IFByZWNlZGVudE5vZGVbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcmVjZWRlbnRUcmVlIHtcbiAgcm9vdDogUHJlY2VkZW50Tm9kZTtcbiAgLyoqIE5vZGVzIGFjdHVhbGx5IG1hdGVyaWFsaXplZCAodGhlIGhvbmVzdCBjb3VudCwgcG9zdC1jYXApLiAqL1xuICBub2RlQ291bnQ6IG51bWJlcjtcbiAgLyoqIFRydWUgd2hlbiB0aGUgYG1heE5vZGVzYCBjYXAgc3RvcHBlZCB0aGUgdW5yb2xsIOKAlCB0aGUgdmlldyBtdXN0IHNheSBzby4gKi9cbiAgdHJ1bmNhdGVkOiBib29sZWFuO1xuICAvKiogVGhlIGRlZXBlc3QgcGF0aCBsZW5ndGggKGVkZ2VzKSwgZm9yIGEgb25lLWdsYW5jZSBcImhvdyBkZWVwIGlzIHRoaXNcIi4gKi9cbiAgZGVwdGg6IG51bWJlcjtcbn1cblxuY29uc3QgREVGQVVMVF9NQVhfTk9ERVMgPSAyMDA7XG5cbi8qKlxuICogQnVpbGQgdGhlIHByZWNlZGVudCB0cmVlIGZvciBhIGNlbGw6IGV2ZXJ5IGNlbGwgaW5wdXQsIHRyYW5zaXRpdmVseSwgd2l0aCBleHRlcm5hbHMgYXNcbiAqIGxlYXZlcy4gV2lsZGNhcmRzIGV4cGFuZCB0byB0aGVpciB3b3Jrc2hlZXQncyBjZWxscyAodGhlIGNvbnNlcnZhdGl2ZSBkZXBlbmRlbmN5IHNldCB0aGVcbiAqIGVuZ2luZSBpdHNlbGYgY29tcHV0ZXMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcHJlY2VkZW50VHJlZShcbiAgcm9vdElkOiBzdHJpbmcsXG4gIGNlbGxzOiByZWFkb25seSBDZWxsRGVzY3JpcHRvcltdLFxuICBtYXhOb2RlczogbnVtYmVyID0gREVGQVVMVF9NQVhfTk9ERVMsXG4pOiBQcmVjZWRlbnRUcmVlIHtcbiAgY29uc3QgYnlJZCA9IG5ldyBNYXAoY2VsbHMubWFwKChjKSA9PiBbYy5pZCwgY10pKTtcbiAgY29uc3Qgcm9vdCA9IGJ5SWQuZ2V0KHJvb3RJZCk7XG4gIGlmIChyb290ID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4geyByb290OiB7IGlkOiByb290SWQsIGtpbmQ6ICdjZWxsJywgdmlhOiAnJywgY2hpbGRyZW46IFtdIH0sIG5vZGVDb3VudDogMCwgdHJ1bmNhdGVkOiBmYWxzZSwgZGVwdGg6IDAgfTtcbiAgfVxuXG4gIGxldCBidWRnZXQgPSBtYXhOb2RlcztcbiAgbGV0IHRydW5jYXRlZCA9IGZhbHNlO1xuXG4gIGNvbnN0IGJ1aWxkID0gKGNlbGw6IENlbGxEZXNjcmlwdG9yKTogUHJlY2VkZW50Tm9kZVtdID0+IHtcbiAgICBjb25zdCBvdXQ6IFByZWNlZGVudE5vZGVbXSA9IFtdO1xuICAgIGZvciAoY29uc3QgciBvZiBjZWxsLnJlc29sdmVycykge1xuICAgICAgaWYgKGJ1ZGdldCA8PSAwKSB7XG4gICAgICAgIHRydW5jYXRlZCA9IHRydWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgaWYgKHIua2luZCA9PT0gJ2NlbGwnKSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGJ5SWQuZ2V0KHIubm9kZUlkKTtcbiAgICAgICAgYnVkZ2V0IC09IDE7XG4gICAgICAgIG91dC5wdXNoKHtcbiAgICAgICAgICBpZDogci5ub2RlSWQsXG4gICAgICAgICAga2luZDogJ2NlbGwnLFxuICAgICAgICAgIHZpYTogci5uYW1lLFxuICAgICAgICAgIGNoaWxkcmVuOiB0YXJnZXQgPT09IHVuZGVmaW5lZCA/IFtdIDogYnVpbGQodGFyZ2V0KSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKHIua2luZCA9PT0gJ3dpbGRjYXJkJykge1xuICAgICAgICBjb25zdCBtZW1iZXJzID0gY2VsbHMuZmlsdGVyKChjKSA9PiBjLndvcmtzaGVldCA9PT0gci53b3Jrc2hlZXQpO1xuICAgICAgICBmb3IgKGNvbnN0IG0gb2YgbWVtYmVycykge1xuICAgICAgICAgIGlmIChidWRnZXQgPD0gMCkge1xuICAgICAgICAgICAgdHJ1bmNhdGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgICBidWRnZXQgLT0gMTtcbiAgICAgICAgICBvdXQucHVzaCh7XG4gICAgICAgICAgICBpZDogbS5pZCxcbiAgICAgICAgICAgIGtpbmQ6ICdjZWxsJyxcbiAgICAgICAgICAgIHZpYTogci5uYW1lLFxuICAgICAgICAgICAgZGV0YWlsOiBgJHtyLndvcmtzaGVldH0uKmAsXG4gICAgICAgICAgICBjaGlsZHJlbjogYnVpbGQobSksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoci5raW5kID09PSAnd2luZG93ZWQtZmVlZCcpIHtcbiAgICAgICAgb3V0LnB1c2goeyBpZDogYGZlZWRzLiR7ci5mZWVkfWAsIGtpbmQ6ICdleHRlcm5hbCcsIHZpYTogci5uYW1lLCBkZXRhaWw6IHIud2luZG93LCBjaGlsZHJlbjogW10gfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXQucHVzaCh7IGlkOiByLmtleSwga2luZDogJ2V4dGVybmFsJywgdmlhOiByLm5hbWUsIGNoaWxkcmVuOiBbXSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbiAgfTtcblxuICBjb25zdCBjaGlsZHJlbiA9IGJ1aWxkKHJvb3QpO1xuICBjb25zdCB0cmVlOiBQcmVjZWRlbnRUcmVlID0ge1xuICAgIHJvb3Q6IHsgaWQ6IHJvb3RJZCwga2luZDogJ2NlbGwnLCB2aWE6ICcnLCBjaGlsZHJlbiB9LFxuICAgIG5vZGVDb3VudDogMSArIChtYXhOb2RlcyAtIGJ1ZGdldCksXG4gICAgdHJ1bmNhdGVkLFxuICAgIGRlcHRoOiAwLFxuICB9O1xuICB0cmVlLmRlcHRoID0gZGVwdGhPZih0cmVlLnJvb3QpO1xuICByZXR1cm4gdHJlZTtcbn1cblxuZnVuY3Rpb24gZGVwdGhPZihub2RlOiBQcmVjZWRlbnROb2RlKTogbnVtYmVyIHtcbiAgaWYgKG5vZGUuY2hpbGRyZW4ubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgcmV0dXJuIDEgKyBNYXRoLm1heCguLi5ub2RlLmNoaWxkcmVuLm1hcChkZXB0aE9mKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBOztBQXNCQSxNQUFNQSxpQkFBaUIsR0FBRyxHQUFHOztBQUU3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsYUFBYUEsQ0FDM0JDLE1BQWMsRUFDZEMsS0FBZ0MsRUFDaENDLFFBQWdCLEdBQUdKLGlCQUFpQixFQUNyQjtFQUNmLE1BQU1LLElBQUksR0FBRyxJQUFJQyxHQUFHLENBQUNILEtBQUssQ0FBQ0ksR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxFQUFFLEVBQUVELENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDakQsTUFBTUUsSUFBSSxHQUFHTCxJQUFJLENBQUNNLEdBQUcsQ0FBQ1QsTUFBTSxDQUFDO0VBQzdCLElBQUlRLElBQUksS0FBS0UsU0FBUyxFQUFFO0lBQ3RCLE9BQU87TUFBRUYsSUFBSSxFQUFFO1FBQUVELEVBQUUsRUFBRVAsTUFBTTtRQUFFVyxJQUFJLEVBQUUsTUFBTTtRQUFFQyxHQUFHLEVBQUUsRUFBRTtRQUFFQyxRQUFRLEVBQUU7TUFBRyxDQUFDO01BQUVDLFNBQVMsRUFBRSxDQUFDO01BQUVDLFNBQVMsRUFBRSxLQUFLO01BQUVDLEtBQUssRUFBRTtJQUFFLENBQUM7RUFDaEg7RUFFQSxJQUFJQyxNQUFNLEdBQUdmLFFBQVE7RUFDckIsSUFBSWEsU0FBUyxHQUFHLEtBQUs7RUFFckIsTUFBTUcsS0FBSyxHQUFJQyxJQUFvQixJQUFzQjtJQUN2RCxNQUFNQyxHQUFvQixHQUFHLEVBQUU7SUFDL0IsS0FBSyxNQUFNQyxDQUFDLElBQUlGLElBQUksQ0FBQ0csU0FBUyxFQUFFO01BQzlCLElBQUlMLE1BQU0sSUFBSSxDQUFDLEVBQUU7UUFDZkYsU0FBUyxHQUFHLElBQUk7UUFDaEI7TUFDRjtNQUNBLElBQUlNLENBQUMsQ0FBQ1YsSUFBSSxLQUFLLE1BQU0sRUFBRTtRQUNyQixNQUFNWSxNQUFNLEdBQUdwQixJQUFJLENBQUNNLEdBQUcsQ0FBQ1ksQ0FBQyxDQUFDRyxNQUFNLENBQUM7UUFDakNQLE1BQU0sSUFBSSxDQUFDO1FBQ1hHLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDO1VBQ1BsQixFQUFFLEVBQUVjLENBQUMsQ0FBQ0csTUFBTTtVQUNaYixJQUFJLEVBQUUsTUFBTTtVQUNaQyxHQUFHLEVBQUVTLENBQUMsQ0FBQ0ssSUFBSTtVQUNYYixRQUFRLEVBQUVVLE1BQU0sS0FBS2IsU0FBUyxHQUFHLEVBQUUsR0FBR1EsS0FBSyxDQUFDSyxNQUFNO1FBQ3BELENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTSxJQUFJRixDQUFDLENBQUNWLElBQUksS0FBSyxVQUFVLEVBQUU7UUFDaEMsTUFBTWdCLE9BQU8sR0FBRzFCLEtBQUssQ0FBQzJCLE1BQU0sQ0FBRXRCLENBQUMsSUFBS0EsQ0FBQyxDQUFDdUIsU0FBUyxLQUFLUixDQUFDLENBQUNRLFNBQVMsQ0FBQztRQUNoRSxLQUFLLE1BQU1DLENBQUMsSUFBSUgsT0FBTyxFQUFFO1VBQ3ZCLElBQUlWLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDZkYsU0FBUyxHQUFHLElBQUk7WUFDaEI7VUFDRjtVQUNBRSxNQUFNLElBQUksQ0FBQztVQUNYRyxHQUFHLENBQUNLLElBQUksQ0FBQztZQUNQbEIsRUFBRSxFQUFFdUIsQ0FBQyxDQUFDdkIsRUFBRTtZQUNSSSxJQUFJLEVBQUUsTUFBTTtZQUNaQyxHQUFHLEVBQUVTLENBQUMsQ0FBQ0ssSUFBSTtZQUNYSyxNQUFNLEVBQUUsR0FBR1YsQ0FBQyxDQUFDUSxTQUFTLElBQUk7WUFDMUJoQixRQUFRLEVBQUVLLEtBQUssQ0FBQ1ksQ0FBQztVQUNuQixDQUFDLENBQUM7UUFDSjtNQUNGLENBQUMsTUFBTSxJQUFJVCxDQUFDLENBQUNWLElBQUksS0FBSyxlQUFlLEVBQUU7UUFDckNTLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDO1VBQUVsQixFQUFFLEVBQUUsU0FBU2MsQ0FBQyxDQUFDVyxJQUFJLEVBQUU7VUFBRXJCLElBQUksRUFBRSxVQUFVO1VBQUVDLEdBQUcsRUFBRVMsQ0FBQyxDQUFDSyxJQUFJO1VBQUVLLE1BQU0sRUFBRVYsQ0FBQyxDQUFDWSxNQUFNO1VBQUVwQixRQUFRLEVBQUU7UUFBRyxDQUFDLENBQUM7TUFDcEcsQ0FBQyxNQUFNO1FBQ0xPLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDO1VBQUVsQixFQUFFLEVBQUVjLENBQUMsQ0FBQ2EsR0FBRztVQUFFdkIsSUFBSSxFQUFFLFVBQVU7VUFBRUMsR0FBRyxFQUFFUyxDQUFDLENBQUNLLElBQUk7VUFBRWIsUUFBUSxFQUFFO1FBQUcsQ0FBQyxDQUFDO01BQ3RFO0lBQ0Y7SUFDQSxPQUFPTyxHQUFHO0VBQ1osQ0FBQztFQUVELE1BQU1QLFFBQVEsR0FBR0ssS0FBSyxDQUFDVixJQUFJLENBQUM7RUFDNUIsTUFBTTJCLElBQW1CLEdBQUc7SUFDMUIzQixJQUFJLEVBQUU7TUFBRUQsRUFBRSxFQUFFUCxNQUFNO01BQUVXLElBQUksRUFBRSxNQUFNO01BQUVDLEdBQUcsRUFBRSxFQUFFO01BQUVDO0lBQVMsQ0FBQztJQUNyREMsU0FBUyxFQUFFLENBQUMsSUFBSVosUUFBUSxHQUFHZSxNQUFNLENBQUM7SUFDbENGLFNBQVM7SUFDVEMsS0FBSyxFQUFFO0VBQ1QsQ0FBQztFQUNEbUIsSUFBSSxDQUFDbkIsS0FBSyxHQUFHb0IsT0FBTyxDQUFDRCxJQUFJLENBQUMzQixJQUFJLENBQUM7RUFDL0IsT0FBTzJCLElBQUk7QUFDYjtBQUVBLFNBQVNDLE9BQU9BLENBQUNDLElBQW1CLEVBQVU7RUFDNUMsSUFBSUEsSUFBSSxDQUFDeEIsUUFBUSxDQUFDeUIsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLENBQUM7RUFDeEMsT0FBTyxDQUFDLEdBQUdDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLEdBQUdILElBQUksQ0FBQ3hCLFFBQVEsQ0FBQ1IsR0FBRyxDQUFDK0IsT0FBTyxDQUFDLENBQUM7QUFDcEQiLCJpZ25vcmVMaXN0IjpbXX0=