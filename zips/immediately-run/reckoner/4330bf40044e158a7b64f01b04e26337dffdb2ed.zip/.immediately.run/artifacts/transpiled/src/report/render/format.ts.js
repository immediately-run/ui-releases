"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.formatDelta = formatDelta;
exports.formatNumber = formatNumber;
exports.formatScalar = formatScalar;
// Value formatting for the report components (§3.3). The catalog's `format` enum
// (`number` | `currency` | `percent` | `multiple`) selects a presentation; everything else
// falls back to a compact, locale-default rendering. An optional `unit` suffix (R3-382 —
// "EUR m", "x", "bps") is display-only and rides after the number. Currency uses the
// **accounting** negative convention (parentheses) — the finance-reader default. Pure —
// no DOM, no engine — so it is unit-testable and shared by Kpi / Gauge / Value / Table cells.

const NF = new Intl.NumberFormat(undefined, {
  maximumFractionDigits: 2
});
const CF = new Intl.NumberFormat(undefined, {
  style: 'currency',
  currency: 'EUR',
  currencySign: 'accounting',
  maximumFractionDigits: 0
});
const PF = new Intl.NumberFormat(undefined, {
  style: 'percent',
  maximumFractionDigits: 1
});

/** Format a number by the catalog `format` enum; `percent` treats the value as a ratio, `multiple` renders "2.75x". */
function formatNumber(n, format = 'number', unit) {
  if (!Number.isFinite(n)) return '—';
  let base;
  switch (format) {
    case 'currency':
      base = CF.format(n);
      break;
    case 'percent':
      base = PF.format(n);
      break;
    case 'multiple':
      base = `${NF.format(n)}x`;
      break;
    case 'number':
      base = NF.format(n);
      break;
  }
  return unit === undefined || unit === '' ? base : `${base} ${unit}`;
}

/**
 * Format an arbitrary published cell value for inline / cell display. Scalars render
 * directly; `null` is the empty marker (`—`); a non-scalar (a row set bound where a scalar
 * was expected) is a shape mismatch surfaced by the caller, not stringified here.
 */
function formatScalar(v, format, unit) {
  if (v === null) return '—';
  if (typeof v === 'number') return formatNumber(v, format, unit);
  if (typeof v === 'boolean') return v ? 'yes' : 'no';
  if (typeof v === 'string') return v;
  return String(v);
}

/** A signed delta label for a KPI compare (`+12.3%` / `−4`). */
function formatDelta(current, previous, format = 'number') {
  if (!Number.isFinite(current) || !Number.isFinite(previous)) return {
    label: '—',
    direction: 'flat'
  };
  const diff = current - previous;
  const direction = diff > 0 ? 'up' : diff < 0 ? 'down' : 'flat';
  if (format === 'percent') {
    const label = `${diff >= 0 ? '+' : '−'}${formatNumber(Math.abs(diff), 'percent')}`;
    return {
      label,
      direction
    };
  }
  // Relative change is the useful KPI delta for number/currency.
  if (previous === 0) return {
    label: diff === 0 ? '0%' : '—',
    direction
  };
  const rel = diff / Math.abs(previous);
  return {
    label: `${diff >= 0 ? '+' : '−'}${formatNumber(Math.abs(rel), 'percent')}`,
    direction
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJORiIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJ1bmRlZmluZWQiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJDRiIsInN0eWxlIiwiY3VycmVuY3kiLCJjdXJyZW5jeVNpZ24iLCJQRiIsImZvcm1hdE51bWJlciIsIm4iLCJmb3JtYXQiLCJ1bml0IiwiTnVtYmVyIiwiaXNGaW5pdGUiLCJiYXNlIiwiZm9ybWF0U2NhbGFyIiwidiIsIlN0cmluZyIsImZvcm1hdERlbHRhIiwiY3VycmVudCIsInByZXZpb3VzIiwibGFiZWwiLCJkaXJlY3Rpb24iLCJkaWZmIiwiTWF0aCIsImFicyIsInJlbCJdLCJzb3VyY2VzIjpbImZvcm1hdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBWYWx1ZSBmb3JtYXR0aW5nIGZvciB0aGUgcmVwb3J0IGNvbXBvbmVudHMgKMKnMy4zKS4gVGhlIGNhdGFsb2cncyBgZm9ybWF0YCBlbnVtXG4vLyAoYG51bWJlcmAgfCBgY3VycmVuY3lgIHwgYHBlcmNlbnRgIHwgYG11bHRpcGxlYCkgc2VsZWN0cyBhIHByZXNlbnRhdGlvbjsgZXZlcnl0aGluZyBlbHNlXG4vLyBmYWxscyBiYWNrIHRvIGEgY29tcGFjdCwgbG9jYWxlLWRlZmF1bHQgcmVuZGVyaW5nLiBBbiBvcHRpb25hbCBgdW5pdGAgc3VmZml4IChSMy0zODIg4oCUXG4vLyBcIkVVUiBtXCIsIFwieFwiLCBcImJwc1wiKSBpcyBkaXNwbGF5LW9ubHkgYW5kIHJpZGVzIGFmdGVyIHRoZSBudW1iZXIuIEN1cnJlbmN5IHVzZXMgdGhlXG4vLyAqKmFjY291bnRpbmcqKiBuZWdhdGl2ZSBjb252ZW50aW9uIChwYXJlbnRoZXNlcykg4oCUIHRoZSBmaW5hbmNlLXJlYWRlciBkZWZhdWx0LiBQdXJlIOKAlFxuLy8gbm8gRE9NLCBubyBlbmdpbmUg4oCUIHNvIGl0IGlzIHVuaXQtdGVzdGFibGUgYW5kIHNoYXJlZCBieSBLcGkgLyBHYXVnZSAvIFZhbHVlIC8gVGFibGUgY2VsbHMuXG5cbmltcG9ydCB0eXBlIHsgVmFsdWUgfSBmcm9tICcuLi8uLi9zdGRsaWIvdHlwZXMudHMnO1xuXG5leHBvcnQgdHlwZSBOdW1iZXJGb3JtYXQgPSAnbnVtYmVyJyB8ICdjdXJyZW5jeScgfCAncGVyY2VudCcgfCAnbXVsdGlwbGUnO1xuXG5jb25zdCBORiA9IG5ldyBJbnRsLk51bWJlckZvcm1hdCh1bmRlZmluZWQsIHsgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pO1xuY29uc3QgQ0YgPSBuZXcgSW50bC5OdW1iZXJGb3JtYXQodW5kZWZpbmVkLCB7XG4gIHN0eWxlOiAnY3VycmVuY3knLCBjdXJyZW5jeTogJ0VVUicsIGN1cnJlbmN5U2lnbjogJ2FjY291bnRpbmcnLCBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDAsXG59KTtcbmNvbnN0IFBGID0gbmV3IEludGwuTnVtYmVyRm9ybWF0KHVuZGVmaW5lZCwgeyBzdHlsZTogJ3BlcmNlbnQnLCBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDEgfSk7XG5cbi8qKiBGb3JtYXQgYSBudW1iZXIgYnkgdGhlIGNhdGFsb2cgYGZvcm1hdGAgZW51bTsgYHBlcmNlbnRgIHRyZWF0cyB0aGUgdmFsdWUgYXMgYSByYXRpbywgYG11bHRpcGxlYCByZW5kZXJzIFwiMi43NXhcIi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXROdW1iZXIobjogbnVtYmVyLCBmb3JtYXQ6IE51bWJlckZvcm1hdCA9ICdudW1iZXInLCB1bml0Pzogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiAn4oCUJztcbiAgbGV0IGJhc2U6IHN0cmluZztcbiAgc3dpdGNoIChmb3JtYXQpIHtcbiAgICBjYXNlICdjdXJyZW5jeSc6XG4gICAgICBiYXNlID0gQ0YuZm9ybWF0KG4pO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncGVyY2VudCc6XG4gICAgICBiYXNlID0gUEYuZm9ybWF0KG4pO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbXVsdGlwbGUnOlxuICAgICAgYmFzZSA9IGAke05GLmZvcm1hdChuKX14YDtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ251bWJlcic6XG4gICAgICBiYXNlID0gTkYuZm9ybWF0KG4pO1xuICAgICAgYnJlYWs7XG4gIH1cbiAgcmV0dXJuIHVuaXQgPT09IHVuZGVmaW5lZCB8fCB1bml0ID09PSAnJyA/IGJhc2UgOiBgJHtiYXNlfSAke3VuaXR9YDtcbn1cblxuLyoqXG4gKiBGb3JtYXQgYW4gYXJiaXRyYXJ5IHB1Ymxpc2hlZCBjZWxsIHZhbHVlIGZvciBpbmxpbmUgLyBjZWxsIGRpc3BsYXkuIFNjYWxhcnMgcmVuZGVyXG4gKiBkaXJlY3RseTsgYG51bGxgIGlzIHRoZSBlbXB0eSBtYXJrZXIgKGDigJRgKTsgYSBub24tc2NhbGFyIChhIHJvdyBzZXQgYm91bmQgd2hlcmUgYSBzY2FsYXJcbiAqIHdhcyBleHBlY3RlZCkgaXMgYSBzaGFwZSBtaXNtYXRjaCBzdXJmYWNlZCBieSB0aGUgY2FsbGVyLCBub3Qgc3RyaW5naWZpZWQgaGVyZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFNjYWxhcih2OiBWYWx1ZSwgZm9ybWF0PzogTnVtYmVyRm9ybWF0LCB1bml0Pzogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiAn4oCUJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJykgcmV0dXJuIGZvcm1hdE51bWJlcih2LCBmb3JtYXQsIHVuaXQpO1xuICBpZiAodHlwZW9mIHYgPT09ICdib29sZWFuJykgcmV0dXJuIHYgPyAneWVzJyA6ICdubyc7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB2O1xuICByZXR1cm4gU3RyaW5nKHYpO1xufVxuXG4vKiogQSBzaWduZWQgZGVsdGEgbGFiZWwgZm9yIGEgS1BJIGNvbXBhcmUgKGArMTIuMyVgIC8gYOKIkjRgKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREZWx0YShjdXJyZW50OiBudW1iZXIsIHByZXZpb3VzOiBudW1iZXIsIGZvcm1hdDogTnVtYmVyRm9ybWF0ID0gJ251bWJlcicpOiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGRpcmVjdGlvbjogJ3VwJyB8ICdkb3duJyB8ICdmbGF0Jztcbn0ge1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShjdXJyZW50KSB8fCAhTnVtYmVyLmlzRmluaXRlKHByZXZpb3VzKSkgcmV0dXJuIHsgbGFiZWw6ICfigJQnLCBkaXJlY3Rpb246ICdmbGF0JyB9O1xuICBjb25zdCBkaWZmID0gY3VycmVudCAtIHByZXZpb3VzO1xuICBjb25zdCBkaXJlY3Rpb24gPSBkaWZmID4gMCA/ICd1cCcgOiBkaWZmIDwgMCA/ICdkb3duJyA6ICdmbGF0JztcbiAgaWYgKGZvcm1hdCA9PT0gJ3BlcmNlbnQnKSB7XG4gICAgY29uc3QgbGFiZWwgPSBgJHtkaWZmID49IDAgPyAnKycgOiAn4oiSJ30ke2Zvcm1hdE51bWJlcihNYXRoLmFicyhkaWZmKSwgJ3BlcmNlbnQnKX1gO1xuICAgIHJldHVybiB7IGxhYmVsLCBkaXJlY3Rpb24gfTtcbiAgfVxuICAvLyBSZWxhdGl2ZSBjaGFuZ2UgaXMgdGhlIHVzZWZ1bCBLUEkgZGVsdGEgZm9yIG51bWJlci9jdXJyZW5jeS5cbiAgaWYgKHByZXZpb3VzID09PSAwKSByZXR1cm4geyBsYWJlbDogZGlmZiA9PT0gMCA/ICcwJScgOiAn4oCUJywgZGlyZWN0aW9uIH07XG4gIGNvbnN0IHJlbCA9IGRpZmYgLyBNYXRoLmFicyhwcmV2aW91cyk7XG4gIHJldHVybiB7IGxhYmVsOiBgJHtkaWZmID49IDAgPyAnKycgOiAn4oiSJ30ke2Zvcm1hdE51bWJlcihNYXRoLmFicyhyZWwpLCAncGVyY2VudCcpfWAsIGRpcmVjdGlvbiB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFNQSxNQUFNQSxFQUFFLEdBQUcsSUFBSUMsSUFBSSxDQUFDQyxZQUFZLENBQUNDLFNBQVMsRUFBRTtFQUFFQyxxQkFBcUIsRUFBRTtBQUFFLENBQUMsQ0FBQztBQUN6RSxNQUFNQyxFQUFFLEdBQUcsSUFBSUosSUFBSSxDQUFDQyxZQUFZLENBQUNDLFNBQVMsRUFBRTtFQUMxQ0csS0FBSyxFQUFFLFVBQVU7RUFBRUMsUUFBUSxFQUFFLEtBQUs7RUFBRUMsWUFBWSxFQUFFLFlBQVk7RUFBRUoscUJBQXFCLEVBQUU7QUFDekYsQ0FBQyxDQUFDO0FBQ0YsTUFBTUssRUFBRSxHQUFHLElBQUlSLElBQUksQ0FBQ0MsWUFBWSxDQUFDQyxTQUFTLEVBQUU7RUFBRUcsS0FBSyxFQUFFLFNBQVM7RUFBRUYscUJBQXFCLEVBQUU7QUFBRSxDQUFDLENBQUM7O0FBRTNGO0FBQ08sU0FBU00sWUFBWUEsQ0FBQ0MsQ0FBUyxFQUFFQyxNQUFvQixHQUFHLFFBQVEsRUFBRUMsSUFBYSxFQUFVO0VBQzlGLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxRQUFRLENBQUNKLENBQUMsQ0FBQyxFQUFFLE9BQU8sR0FBRztFQUNuQyxJQUFJSyxJQUFZO0VBQ2hCLFFBQVFKLE1BQU07SUFDWixLQUFLLFVBQVU7TUFDYkksSUFBSSxHQUFHWCxFQUFFLENBQUNPLE1BQU0sQ0FBQ0QsQ0FBQyxDQUFDO01BQ25CO0lBQ0YsS0FBSyxTQUFTO01BQ1pLLElBQUksR0FBR1AsRUFBRSxDQUFDRyxNQUFNLENBQUNELENBQUMsQ0FBQztNQUNuQjtJQUNGLEtBQUssVUFBVTtNQUNiSyxJQUFJLEdBQUcsR0FBR2hCLEVBQUUsQ0FBQ1ksTUFBTSxDQUFDRCxDQUFDLENBQUMsR0FBRztNQUN6QjtJQUNGLEtBQUssUUFBUTtNQUNYSyxJQUFJLEdBQUdoQixFQUFFLENBQUNZLE1BQU0sQ0FBQ0QsQ0FBQyxDQUFDO01BQ25CO0VBQ0o7RUFDQSxPQUFPRSxJQUFJLEtBQUtWLFNBQVMsSUFBSVUsSUFBSSxLQUFLLEVBQUUsR0FBR0csSUFBSSxHQUFHLEdBQUdBLElBQUksSUFBSUgsSUFBSSxFQUFFO0FBQ3JFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTSSxZQUFZQSxDQUFDQyxDQUFRLEVBQUVOLE1BQXFCLEVBQUVDLElBQWEsRUFBVTtFQUNuRixJQUFJSyxDQUFDLEtBQUssSUFBSSxFQUFFLE9BQU8sR0FBRztFQUMxQixJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBT1IsWUFBWSxDQUFDUSxDQUFDLEVBQUVOLE1BQU0sRUFBRUMsSUFBSSxDQUFDO0VBQy9ELElBQUksT0FBT0ssQ0FBQyxLQUFLLFNBQVMsRUFBRSxPQUFPQSxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQUk7RUFDbkQsSUFBSSxPQUFPQSxDQUFDLEtBQUssUUFBUSxFQUFFLE9BQU9BLENBQUM7RUFDbkMsT0FBT0MsTUFBTSxDQUFDRCxDQUFDLENBQUM7QUFDbEI7O0FBRUE7QUFDTyxTQUFTRSxXQUFXQSxDQUFDQyxPQUFlLEVBQUVDLFFBQWdCLEVBQUVWLE1BQW9CLEdBQUcsUUFBUSxFQUc1RjtFQUNBLElBQUksQ0FBQ0UsTUFBTSxDQUFDQyxRQUFRLENBQUNNLE9BQU8sQ0FBQyxJQUFJLENBQUNQLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDTyxRQUFRLENBQUMsRUFBRSxPQUFPO0lBQUVDLEtBQUssRUFBRSxHQUFHO0lBQUVDLFNBQVMsRUFBRTtFQUFPLENBQUM7RUFDckcsTUFBTUMsSUFBSSxHQUFHSixPQUFPLEdBQUdDLFFBQVE7RUFDL0IsTUFBTUUsU0FBUyxHQUFHQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBR0EsSUFBSSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsTUFBTTtFQUM5RCxJQUFJYixNQUFNLEtBQUssU0FBUyxFQUFFO0lBQ3hCLE1BQU1XLEtBQUssR0FBRyxHQUFHRSxJQUFJLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUdmLFlBQVksQ0FBQ2dCLElBQUksQ0FBQ0MsR0FBRyxDQUFDRixJQUFJLENBQUMsRUFBRSxTQUFTLENBQUMsRUFBRTtJQUNsRixPQUFPO01BQUVGLEtBQUs7TUFBRUM7SUFBVSxDQUFDO0VBQzdCO0VBQ0E7RUFDQSxJQUFJRixRQUFRLEtBQUssQ0FBQyxFQUFFLE9BQU87SUFBRUMsS0FBSyxFQUFFRSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksR0FBRyxHQUFHO0lBQUVEO0VBQVUsQ0FBQztFQUN4RSxNQUFNSSxHQUFHLEdBQUdILElBQUksR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUNMLFFBQVEsQ0FBQztFQUNyQyxPQUFPO0lBQUVDLEtBQUssRUFBRSxHQUFHRSxJQUFJLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUdmLFlBQVksQ0FBQ2dCLElBQUksQ0FBQ0MsR0FBRyxDQUFDQyxHQUFHLENBQUMsRUFBRSxTQUFTLENBQUMsRUFBRTtJQUFFSjtFQUFVLENBQUM7QUFDbEciLCJpZ25vcmVMaXN0IjpbXX0=