var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _shadow = require("../engine/shadow.ts");
var _useShadowRunner = require("../hooks/useShadowRunner.ts");
var _WorkbookPanelBody = _interopRequireDefault(require("./WorkbookPanelBody.tsx"));
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The scratch pad (WHATIF_SHADOW_EVALUATION_SPEC §1.2) — the R-6 ephemeral scratch
// surface: one unsaved worksheet buffer with the full worksheet grammar, run through the
// shadow session and rendered as ordinary workbook cards, visibly marked unsaved. Text
// safety per §1.4: the buffer is session-scoped app state (survives panel close), Clear
// is an arm-then-confirm (the in-repo confirm idiom — no native dialogs), and Copy offers
// the text to the clipboard with a guarded fallback (a plain textarea always allows
// manual select-copy). Refusals (scratch collision G-WIF-8, durable-subject tests
// G-WIF-6a), build errors, and cross-reference diagnostics (G-WIF-10) render as visible
// messages, never silent.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function ScratchPad({
  session,
  baseVerdicts,
  text,
  onTextChange
}) {
  _s();
  const {
    outcome,
    running,
    run,
    reset
  } = (0, _useShadowRunner.useShadowRunner)(session);
  const [armedClear, setArmedClear] = (0, _react.useState)(false);
  const [copied, setCopied] = (0, _react.useState)(false);
  const [copyFailed, setCopyFailed] = (0, _react.useState)(false);

  // G-WIF-8: a document that declares its own `scratch` worksheet disables the pad.
  if (_shadow.SCRATCH_WORKSHEET in session.sources) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "rk-wb-sheet rk-scratch",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
        children: "scratch"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-wb-note",
        children: ["this document already has a worksheet named \u201C", _shadow.SCRATCH_WORKSHEET, "\u201D, so the scratch pad is unavailable here."]
      })]
    });
  }

  // A refused clipboard write must not be silent (WCAG 3.3.1 / R-IX-3's named-failure
  // face): the rejection renders a visible line naming the manual fallback — the
  // textarea below still allows select-and-copy either way.
  const copy = () => {
    setCopyFailed(false);
    try {
      void navigator.clipboard?.writeText(text).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }).catch(() => {
        setCopyFailed(true);
      });
    } catch {
      /* clipboard can be absent in the sandboxed iframe — name it, don't swallow it */
      setCopyFailed(true);
    }
  };
  const scratchCells = outcome?.ok === true ? outcome.cells.filter(c => c.worksheet === _shadow.SCRATCH_WORKSHEET) : [];
  const scratchTests = outcome?.ok === true ? outcome.tests.filter(t => t.worksheet === _shadow.SCRATCH_WORKSHEET) : [];
  const scratchErrors = outcome?.ok === true ? scratchCells.map(c => ({
    id: c.id,
    error: outcome.errorOf(c.id)
  })).filter(e => e.error !== undefined) : [];
  const errorDiags = outcome?.ok === true ? outcome.diagnostics.filter(d => d.severity === 'error') : [];
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "rk-wb-sheet rk-scratch",
    "aria-label": "Scratch pad",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("h3", {
      children: ["scratch ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-scratch-tag",
        children: "unsaved"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wb-note",
      children: "an ephemeral worksheet: cells, tests, cross-references \u2014 evaluated on demand, never saved to the document."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("textarea", {
      className: "rk-wi-editor rk-scratch-editor",
      value: text,
      rows: Math.min(14, Math.max(5, text.split('\n').length)),
      spellCheck: false,
      "aria-label": "Scratch worksheet source",
      placeholder: `import { cell } from "@reckoner/stdlib";\n\nexport const probe = cell({\n  doc: "try something",\n  inputs: { },\n  formula: () => 1,\n});`,
      onChange: e => {
        setArmedClear(false);
        onTextChange(e.target.value);
      }
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wi-actions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-run",
        onClick: () => run({
          scratch: text
        }, baseVerdicts),
        disabled: running || text.trim() === '',
        children: running ? 'Running…' : 'Run'
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-close",
        onClick: copy,
        disabled: text === '',
        children: copied ? 'Copied' : 'Copy'
      }), copyFailed && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-copy-failed",
        role: "status",
        children: "Copy failed \u2014 select the text and copy manually"
      }), !armedClear ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-close",
        onClick: () => setArmedClear(true),
        disabled: running || text === '',
        children: "Clear"
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-close rk-scratch-clear-armed",
        onClick: () => {
          setArmedClear(false);
          onTextChange('');
          reset();
        },
        children: "Really clear?"
      })]
    }), outcome !== null && !outcome.ok && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wb-error",
      role: "status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-wb-kind",
        children: outcome.refusal.code
      }), " ", outcome.refusal.message]
    }), errorDiags.map((d, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wb-error",
      children: d.message
    }, i)), scratchErrors.map(e => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-wb-error",
      children: [e.id, ": ", e.error]
    }, e.id)), outcome?.ok === true && scratchCells.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WorkbookPanelBody.default, {
      cells: scratchCells,
      tests: scratchTests,
      results: outcome.verdicts,
      valueOf: outcome.valueOf
    })]
  });
}
_s(ScratchPad, "CwGod77V0ODJiCtQpSYKyqR0CQ0=", false, function () {
  return [_useShadowRunner.useShadowRunner];
});
_c = ScratchPad;
var _default = exports.default = ScratchPad;
var _c;
$RefreshReg$(_c, "ScratchPad");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NoYWRvdyIsIl91c2VTaGFkb3dSdW5uZXIiLCJfV29ya2Jvb2tQYW5lbEJvZHkiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlNjcmF0Y2hQYWQiLCJzZXNzaW9uIiwiYmFzZVZlcmRpY3RzIiwidGV4dCIsIm9uVGV4dENoYW5nZSIsIm91dGNvbWUiLCJydW5uaW5nIiwicnVuIiwicmVzZXQiLCJ1c2VTaGFkb3dSdW5uZXIiLCJhcm1lZENsZWFyIiwic2V0QXJtZWRDbGVhciIsInVzZVN0YXRlIiwiY29waWVkIiwic2V0Q29waWVkIiwiY29weUZhaWxlZCIsInNldENvcHlGYWlsZWQiLCJTQ1JBVENIX1dPUktTSEVFVCIsInNvdXJjZXMiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJjb3B5IiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwidGhlbiIsInNldFRpbWVvdXQiLCJjYXRjaCIsInNjcmF0Y2hDZWxscyIsIm9rIiwiY2VsbHMiLCJmaWx0ZXIiLCJjIiwid29ya3NoZWV0Iiwic2NyYXRjaFRlc3RzIiwidGVzdHMiLCJ0Iiwic2NyYXRjaEVycm9ycyIsIm1hcCIsImlkIiwiZXJyb3IiLCJlcnJvck9mIiwidW5kZWZpbmVkIiwiZXJyb3JEaWFncyIsImRpYWdub3N0aWNzIiwiZCIsInNldmVyaXR5IiwidmFsdWUiLCJyb3dzIiwiTWF0aCIsIm1pbiIsIm1heCIsInNwbGl0IiwibGVuZ3RoIiwic3BlbGxDaGVjayIsInBsYWNlaG9sZGVyIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJ0eXBlIiwib25DbGljayIsInNjcmF0Y2giLCJkaXNhYmxlZCIsInRyaW0iLCJyb2xlIiwicmVmdXNhbCIsImNvZGUiLCJtZXNzYWdlIiwiaSIsInJlc3VsdHMiLCJ2ZXJkaWN0cyIsInZhbHVlT2YiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNjcmF0Y2hQYWQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBzY3JhdGNoIHBhZCAoV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMgwqcxLjIpIOKAlCB0aGUgUi02IGVwaGVtZXJhbCBzY3JhdGNoXG4vLyBzdXJmYWNlOiBvbmUgdW5zYXZlZCB3b3Jrc2hlZXQgYnVmZmVyIHdpdGggdGhlIGZ1bGwgd29ya3NoZWV0IGdyYW1tYXIsIHJ1biB0aHJvdWdoIHRoZVxuLy8gc2hhZG93IHNlc3Npb24gYW5kIHJlbmRlcmVkIGFzIG9yZGluYXJ5IHdvcmtib29rIGNhcmRzLCB2aXNpYmx5IG1hcmtlZCB1bnNhdmVkLiBUZXh0XG4vLyBzYWZldHkgcGVyIMKnMS40OiB0aGUgYnVmZmVyIGlzIHNlc3Npb24tc2NvcGVkIGFwcCBzdGF0ZSAoc3Vydml2ZXMgcGFuZWwgY2xvc2UpLCBDbGVhclxuLy8gaXMgYW4gYXJtLXRoZW4tY29uZmlybSAodGhlIGluLXJlcG8gY29uZmlybSBpZGlvbSDigJQgbm8gbmF0aXZlIGRpYWxvZ3MpLCBhbmQgQ29weSBvZmZlcnNcbi8vIHRoZSB0ZXh0IHRvIHRoZSBjbGlwYm9hcmQgd2l0aCBhIGd1YXJkZWQgZmFsbGJhY2sgKGEgcGxhaW4gdGV4dGFyZWEgYWx3YXlzIGFsbG93c1xuLy8gbWFudWFsIHNlbGVjdC1jb3B5KS4gUmVmdXNhbHMgKHNjcmF0Y2ggY29sbGlzaW9uIEctV0lGLTgsIGR1cmFibGUtc3ViamVjdCB0ZXN0c1xuLy8gRy1XSUYtNmEpLCBidWlsZCBlcnJvcnMsIGFuZCBjcm9zcy1yZWZlcmVuY2UgZGlhZ25vc3RpY3MgKEctV0lGLTEwKSByZW5kZXIgYXMgdmlzaWJsZVxuLy8gbWVzc2FnZXMsIG5ldmVyIHNpbGVudC5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBTdWJqZWN0UmVzdWx0IH0gZnJvbSAnLi4vZW5naW5lL3dvcmtlci9wcm90b2NvbC50cyc7XG5pbXBvcnQgeyBTQ1JBVENIX1dPUktTSEVFVCB9IGZyb20gJy4uL2VuZ2luZS9zaGFkb3cudHMnO1xuaW1wb3J0IHsgdXNlU2hhZG93UnVubmVyIH0gZnJvbSAnLi4vaG9va3MvdXNlU2hhZG93UnVubmVyLnRzJztcbmltcG9ydCB0eXBlIHsgUmVwb3J0U2Vzc2lvbiB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgV29ya2Jvb2tQYW5lbEJvZHkgZnJvbSAnLi9Xb3JrYm9va1BhbmVsQm9keS50c3gnO1xuaW1wb3J0ICcuL3dvcmtib29rLXBhbmVsLmNzcyc7XG5cbmludGVyZmFjZSBTY3JhdGNoUGFkUHJvcHMge1xuICBzZXNzaW9uOiBSZXBvcnRTZXNzaW9uO1xuICAvKiogVGhlIHBhbmVsJ3MgY3VycmVudCBzdWl0ZSByZXN1bHRzICh2ZXJkaWN0IGZsaXBzIGZvciBzY3JhdGNoIHN1YmplY3RzIGRpZmYgYWdhaW5zdCB0aGVzZSkuICovXG4gIGJhc2VWZXJkaWN0czogUmVhZG9ubHlNYXA8c3RyaW5nLCBTdWJqZWN0UmVzdWx0PiB8IG51bGw7XG4gIC8qKiBUaGUgc2Vzc2lvbi1zY29wZWQgYnVmZmVyIHRleHQgKEFwcCBvd25zIGl0OyDCpzEuNCkuICovXG4gIHRleHQ6IHN0cmluZztcbiAgb25UZXh0Q2hhbmdlOiAodGV4dDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBTY3JhdGNoUGFkKHsgc2Vzc2lvbiwgYmFzZVZlcmRpY3RzLCB0ZXh0LCBvblRleHRDaGFuZ2UgfTogU2NyYXRjaFBhZFByb3BzKSB7XG4gIGNvbnN0IHsgb3V0Y29tZSwgcnVubmluZywgcnVuLCByZXNldCB9ID0gdXNlU2hhZG93UnVubmVyKHNlc3Npb24pO1xuICBjb25zdCBbYXJtZWRDbGVhciwgc2V0QXJtZWRDbGVhcl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjb3B5RmFpbGVkLCBzZXRDb3B5RmFpbGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBHLVdJRi04OiBhIGRvY3VtZW50IHRoYXQgZGVjbGFyZXMgaXRzIG93biBgc2NyYXRjaGAgd29ya3NoZWV0IGRpc2FibGVzIHRoZSBwYWQuXG4gIGlmIChTQ1JBVENIX1dPUktTSEVFVCBpbiBzZXNzaW9uLnNvdXJjZXMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicmstd2Itc2hlZXQgcmstc2NyYXRjaFwiPlxuICAgICAgICA8aDM+c2NyYXRjaDwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2Itbm90ZVwiPlxuICAgICAgICAgIHRoaXMgZG9jdW1lbnQgYWxyZWFkeSBoYXMgYSB3b3Jrc2hlZXQgbmFtZWQg4oCce1NDUkFUQ0hfV09SS1NIRUVUfeKAnSwgc28gdGhlIHNjcmF0Y2ggcGFkIGlzIHVuYXZhaWxhYmxlIGhlcmUuXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH1cblxuICAvLyBBIHJlZnVzZWQgY2xpcGJvYXJkIHdyaXRlIG11c3Qgbm90IGJlIHNpbGVudCAoV0NBRyAzLjMuMSAvIFItSVgtMydzIG5hbWVkLWZhaWx1cmVcbiAgLy8gZmFjZSk6IHRoZSByZWplY3Rpb24gcmVuZGVycyBhIHZpc2libGUgbGluZSBuYW1pbmcgdGhlIG1hbnVhbCBmYWxsYmFjayDigJQgdGhlXG4gIC8vIHRleHRhcmVhIGJlbG93IHN0aWxsIGFsbG93cyBzZWxlY3QtYW5kLWNvcHkgZWl0aGVyIHdheS5cbiAgY29uc3QgY29weSA9ICgpOiB2b2lkID0+IHtcbiAgICBzZXRDb3B5RmFpbGVkKGZhbHNlKTtcbiAgICB0cnkge1xuICAgICAgdm9pZCBuYXZpZ2F0b3IuY2xpcGJvYXJkXG4gICAgICAgID8ud3JpdGVUZXh0KHRleHQpXG4gICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICBzZXRDb3BpZWQodHJ1ZSk7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCAxNTAwKTtcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICBzZXRDb3B5RmFpbGVkKHRydWUpO1xuICAgICAgICB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIGNsaXBib2FyZCBjYW4gYmUgYWJzZW50IGluIHRoZSBzYW5kYm94ZWQgaWZyYW1lIOKAlCBuYW1lIGl0LCBkb24ndCBzd2FsbG93IGl0ICovXG4gICAgICBzZXRDb3B5RmFpbGVkKHRydWUpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBzY3JhdGNoQ2VsbHMgPSBvdXRjb21lPy5vayA9PT0gdHJ1ZSA/IG91dGNvbWUuY2VsbHMuZmlsdGVyKChjKSA9PiBjLndvcmtzaGVldCA9PT0gU0NSQVRDSF9XT1JLU0hFRVQpIDogW107XG4gIGNvbnN0IHNjcmF0Y2hUZXN0cyA9IG91dGNvbWU/Lm9rID09PSB0cnVlID8gb3V0Y29tZS50ZXN0cy5maWx0ZXIoKHQpID0+IHQud29ya3NoZWV0ID09PSBTQ1JBVENIX1dPUktTSEVFVCkgOiBbXTtcbiAgY29uc3Qgc2NyYXRjaEVycm9ycyA9XG4gICAgb3V0Y29tZT8ub2sgPT09IHRydWVcbiAgICAgID8gc2NyYXRjaENlbGxzLm1hcCgoYykgPT4gKHsgaWQ6IGMuaWQsIGVycm9yOiBvdXRjb21lLmVycm9yT2YoYy5pZCkgfSkpLmZpbHRlcigoZSkgPT4gZS5lcnJvciAhPT0gdW5kZWZpbmVkKVxuICAgICAgOiBbXTtcbiAgY29uc3QgZXJyb3JEaWFncyA9IG91dGNvbWU/Lm9rID09PSB0cnVlID8gb3V0Y29tZS5kaWFnbm9zdGljcy5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgPT09ICdlcnJvcicpIDogW107XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyay13Yi1zaGVldCByay1zY3JhdGNoXCIgYXJpYS1sYWJlbD1cIlNjcmF0Y2ggcGFkXCI+XG4gICAgICA8aDM+XG4gICAgICAgIHNjcmF0Y2ggPHNwYW4gY2xhc3NOYW1lPVwicmstc2NyYXRjaC10YWdcIj51bnNhdmVkPC9zcGFuPlxuICAgICAgPC9oMz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2Itbm90ZVwiPlxuICAgICAgICBhbiBlcGhlbWVyYWwgd29ya3NoZWV0OiBjZWxscywgdGVzdHMsIGNyb3NzLXJlZmVyZW5jZXMg4oCUIGV2YWx1YXRlZCBvbiBkZW1hbmQsIG5ldmVyIHNhdmVkIHRvIHRoZSBkb2N1bWVudC5cbiAgICAgIDwvZGl2PlxuICAgICAgPHRleHRhcmVhXG4gICAgICAgIGNsYXNzTmFtZT1cInJrLXdpLWVkaXRvciByay1zY3JhdGNoLWVkaXRvclwiXG4gICAgICAgIHZhbHVlPXt0ZXh0fVxuICAgICAgICByb3dzPXtNYXRoLm1pbigxNCwgTWF0aC5tYXgoNSwgdGV4dC5zcGxpdCgnXFxuJykubGVuZ3RoKSl9XG4gICAgICAgIHNwZWxsQ2hlY2s9e2ZhbHNlfVxuICAgICAgICBhcmlhLWxhYmVsPVwiU2NyYXRjaCB3b3Jrc2hlZXQgc291cmNlXCJcbiAgICAgICAgcGxhY2Vob2xkZXI9e2BpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcXG5cXG5leHBvcnQgY29uc3QgcHJvYmUgPSBjZWxsKHtcXG4gIGRvYzogXCJ0cnkgc29tZXRoaW5nXCIsXFxuICBpbnB1dHM6IHsgfSxcXG4gIGZvcm11bGE6ICgpID0+IDEsXFxufSk7YH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgc2V0QXJtZWRDbGVhcihmYWxzZSk7XG4gICAgICAgICAgb25UZXh0Q2hhbmdlKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdpLWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInJrLXdiLXJ1blwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gcnVuKHsgc2NyYXRjaDogdGV4dCB9LCBiYXNlVmVyZGljdHMpfVxuICAgICAgICAgIGRpc2FibGVkPXtydW5uaW5nIHx8IHRleHQudHJpbSgpID09PSAnJ31cbiAgICAgICAgPlxuICAgICAgICAgIHtydW5uaW5nID8gJ1J1bm5pbmfigKYnIDogJ1J1bid9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyay13Yi1jbG9zZVwiIG9uQ2xpY2s9e2NvcHl9IGRpc2FibGVkPXt0ZXh0ID09PSAnJ30+XG4gICAgICAgICAge2NvcGllZCA/ICdDb3BpZWQnIDogJ0NvcHknfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAge2NvcHlGYWlsZWQgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWNvcHktZmFpbGVkXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgQ29weSBmYWlsZWQg4oCUIHNlbGVjdCB0aGUgdGV4dCBhbmQgY29weSBtYW51YWxseVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgICAgeyFhcm1lZENsZWFyID8gKFxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlXCIgb25DbGljaz17KCkgPT4gc2V0QXJtZWRDbGVhcih0cnVlKX0gZGlzYWJsZWQ9e3J1bm5pbmcgfHwgdGV4dCA9PT0gJyd9PlxuICAgICAgICAgICAgQ2xlYXJcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlIHJrLXNjcmF0Y2gtY2xlYXItYXJtZWRcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICBzZXRBcm1lZENsZWFyKGZhbHNlKTtcbiAgICAgICAgICAgICAgb25UZXh0Q2hhbmdlKCcnKTtcbiAgICAgICAgICAgICAgcmVzZXQoKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgUmVhbGx5IGNsZWFyP1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtvdXRjb21lICE9PSBudWxsICYmICFvdXRjb21lLm9rICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13Yi1lcnJvclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay13Yi1raW5kXCI+e291dGNvbWUucmVmdXNhbC5jb2RlfTwvc3Bhbj4ge291dGNvbWUucmVmdXNhbC5tZXNzYWdlfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7ZXJyb3JEaWFncy5tYXAoKGQsIGkpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInJrLXdiLWVycm9yXCI+XG4gICAgICAgICAge2QubWVzc2FnZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICAgIHtzY3JhdGNoRXJyb3JzLm1hcCgoZSkgPT4gKFxuICAgICAgICA8ZGl2IGtleT17ZS5pZH0gY2xhc3NOYW1lPVwicmstd2ItZXJyb3JcIj5cbiAgICAgICAgICB7ZS5pZH06IHtlLmVycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkpfVxuXG4gICAgICB7b3V0Y29tZT8ub2sgPT09IHRydWUgJiYgc2NyYXRjaENlbGxzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8V29ya2Jvb2tQYW5lbEJvZHlcbiAgICAgICAgICBjZWxscz17c2NyYXRjaENlbGxzfVxuICAgICAgICAgIHRlc3RzPXtzY3JhdGNoVGVzdHN9XG4gICAgICAgICAgcmVzdWx0cz17b3V0Y29tZS52ZXJkaWN0c31cbiAgICAgICAgICB2YWx1ZU9mPXtvdXRjb21lLnZhbHVlT2Z9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2NyYXRjaFBhZDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBU0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsZ0JBQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLGtCQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQUEsT0FBQTtBQUE4QixJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxJQUFBTSxFQUFBLEdBQUFDLFlBQUEsSUFmOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUgsdUJBQUFJLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFrQkEsU0FBU0csVUFBVUEsQ0FBQztFQUFFQyxPQUFPO0VBQUVDLFlBQVk7RUFBRUMsSUFBSTtFQUFFQztBQUE4QixDQUFDLEVBQUU7RUFBQVQsRUFBQTtFQUNsRixNQUFNO0lBQUVVLE9BQU87SUFBRUMsT0FBTztJQUFFQyxHQUFHO0lBQUVDO0VBQU0sQ0FBQyxHQUFHLElBQUFDLGdDQUFlLEVBQUNSLE9BQU8sQ0FBQztFQUNqRSxNQUFNLENBQUNTLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUNuRCxNQUFNLENBQUNDLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUMzQyxNQUFNLENBQUNHLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQUosZUFBUSxFQUFDLEtBQUssQ0FBQzs7RUFFbkQ7RUFDQSxJQUFJSyx5QkFBaUIsSUFBSWhCLE9BQU8sQ0FBQ2lCLE9BQU8sRUFBRTtJQUN4QyxvQkFDRSxJQUFBeEIsV0FBQSxDQUFBeUIsSUFBQTtNQUFTQyxTQUFTLEVBQUMsd0JBQXdCO01BQUFDLFFBQUEsZ0JBQ3pDLElBQUEzQixXQUFBLENBQUE0QixHQUFBO1FBQUFELFFBQUEsRUFBSTtNQUFPLENBQUksQ0FBQyxlQUNoQixJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLEdBQUMsb0RBQ21CLEVBQUNKLHlCQUFpQixFQUFDLGlEQUNsRTtNQUFBLENBQUssQ0FBQztJQUFBLENBQ0MsQ0FBQztFQUVkOztFQUVBO0VBQ0E7RUFDQTtFQUNBLE1BQU1NLElBQUksR0FBR0EsQ0FBQSxLQUFZO0lBQ3ZCUCxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ3BCLElBQUk7TUFDRixLQUFLUSxTQUFTLENBQUNDLFNBQVMsRUFDcEJDLFNBQVMsQ0FBQ3ZCLElBQUksQ0FBQyxDQUNoQndCLElBQUksQ0FBQyxNQUFNO1FBQ1ZiLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDZmMsVUFBVSxDQUFDLE1BQU1kLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUFJLENBQUM7TUFDMUMsQ0FBQyxDQUFDLENBQ0RlLEtBQUssQ0FBQyxNQUFNO1FBQ1hiLGFBQWEsQ0FBQyxJQUFJLENBQUM7TUFDckIsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDLE1BQU07TUFDTjtNQUNBQSxhQUFhLENBQUMsSUFBSSxDQUFDO0lBQ3JCO0VBQ0YsQ0FBQztFQUVELE1BQU1jLFlBQVksR0FBR3pCLE9BQU8sRUFBRTBCLEVBQUUsS0FBSyxJQUFJLEdBQUcxQixPQUFPLENBQUMyQixLQUFLLENBQUNDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFNBQVMsS0FBS2xCLHlCQUFpQixDQUFDLEdBQUcsRUFBRTtFQUMvRyxNQUFNbUIsWUFBWSxHQUFHL0IsT0FBTyxFQUFFMEIsRUFBRSxLQUFLLElBQUksR0FBRzFCLE9BQU8sQ0FBQ2dDLEtBQUssQ0FBQ0osTUFBTSxDQUFFSyxDQUFDLElBQUtBLENBQUMsQ0FBQ0gsU0FBUyxLQUFLbEIseUJBQWlCLENBQUMsR0FBRyxFQUFFO0VBQy9HLE1BQU1zQixhQUFhLEdBQ2pCbEMsT0FBTyxFQUFFMEIsRUFBRSxLQUFLLElBQUksR0FDaEJELFlBQVksQ0FBQ1UsR0FBRyxDQUFFTixDQUFDLEtBQU07SUFBRU8sRUFBRSxFQUFFUCxDQUFDLENBQUNPLEVBQUU7SUFBRUMsS0FBSyxFQUFFckMsT0FBTyxDQUFDc0MsT0FBTyxDQUFDVCxDQUFDLENBQUNPLEVBQUU7RUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDUixNQUFNLENBQUVwQyxDQUFDLElBQUtBLENBQUMsQ0FBQzZDLEtBQUssS0FBS0UsU0FBUyxDQUFDLEdBQzFHLEVBQUU7RUFDUixNQUFNQyxVQUFVLEdBQUd4QyxPQUFPLEVBQUUwQixFQUFFLEtBQUssSUFBSSxHQUFHMUIsT0FBTyxDQUFDeUMsV0FBVyxDQUFDYixNQUFNLENBQUVjLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxRQUFRLEtBQUssT0FBTyxDQUFDLEdBQUcsRUFBRTtFQUV4RyxvQkFDRSxJQUFBdEQsV0FBQSxDQUFBeUIsSUFBQTtJQUFTQyxTQUFTLEVBQUMsd0JBQXdCO0lBQUMsY0FBVyxhQUFhO0lBQUFDLFFBQUEsZ0JBQ2xFLElBQUEzQixXQUFBLENBQUF5QixJQUFBO01BQUFFLFFBQUEsR0FBSSxVQUNNLG1CQUFBM0IsV0FBQSxDQUFBNEIsR0FBQTtRQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFDLFFBQUEsRUFBQztNQUFPLENBQU0sQ0FBQztJQUFBLENBQ3JELENBQUMsZUFDTCxJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQTtNQUFLRixTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLEVBQUM7SUFFNUIsQ0FBSyxDQUFDLGVBQ04sSUFBQTNCLFdBQUEsQ0FBQTRCLEdBQUE7TUFDRUYsU0FBUyxFQUFDLGdDQUFnQztNQUMxQzZCLEtBQUssRUFBRTlDLElBQUs7TUFDWitDLElBQUksRUFBRUMsSUFBSSxDQUFDQyxHQUFHLENBQUMsRUFBRSxFQUFFRCxJQUFJLENBQUNFLEdBQUcsQ0FBQyxDQUFDLEVBQUVsRCxJQUFJLENBQUNtRCxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUNDLE1BQU0sQ0FBQyxDQUFFO01BQ3pEQyxVQUFVLEVBQUUsS0FBTTtNQUNsQixjQUFXLDBCQUEwQjtNQUNyQ0MsV0FBVyxFQUFFLDRJQUE2STtNQUMxSkMsUUFBUSxFQUFHN0QsQ0FBQyxJQUFLO1FBQ2ZjLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDcEJQLFlBQVksQ0FBQ1AsQ0FBQyxDQUFDOEQsTUFBTSxDQUFDVixLQUFLLENBQUM7TUFDOUI7SUFBRSxDQUNILENBQUMsZUFDRixJQUFBdkQsV0FBQSxDQUFBeUIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsZUFBZTtNQUFBQyxRQUFBLGdCQUM1QixJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQTtRQUNFc0MsSUFBSSxFQUFDLFFBQVE7UUFDYnhDLFNBQVMsRUFBQyxXQUFXO1FBQ3JCeUMsT0FBTyxFQUFFQSxDQUFBLEtBQU10RCxHQUFHLENBQUM7VUFBRXVELE9BQU8sRUFBRTNEO1FBQUssQ0FBQyxFQUFFRCxZQUFZLENBQUU7UUFDcEQ2RCxRQUFRLEVBQUV6RCxPQUFPLElBQUlILElBQUksQ0FBQzZELElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRztRQUFBM0MsUUFBQSxFQUV2Q2YsT0FBTyxHQUFHLFVBQVUsR0FBRztNQUFLLENBQ3ZCLENBQUMsZUFDVCxJQUFBWixXQUFBLENBQUE0QixHQUFBO1FBQVFzQyxJQUFJLEVBQUMsUUFBUTtRQUFDeEMsU0FBUyxFQUFDLGFBQWE7UUFBQ3lDLE9BQU8sRUFBRXRDLElBQUs7UUFBQ3dDLFFBQVEsRUFBRTVELElBQUksS0FBSyxFQUFHO1FBQUFrQixRQUFBLEVBQ2hGUixNQUFNLEdBQUcsUUFBUSxHQUFHO01BQU0sQ0FDckIsQ0FBQyxFQUNSRSxVQUFVLGlCQUNULElBQUFyQixXQUFBLENBQUE0QixHQUFBO1FBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQzZDLElBQUksRUFBQyxRQUFRO1FBQUE1QyxRQUFBLEVBQUM7TUFFL0MsQ0FBTSxDQUNQLEVBQ0EsQ0FBQ1gsVUFBVSxnQkFDVixJQUFBaEIsV0FBQSxDQUFBNEIsR0FBQTtRQUFRc0MsSUFBSSxFQUFDLFFBQVE7UUFBQ3hDLFNBQVMsRUFBQyxhQUFhO1FBQUN5QyxPQUFPLEVBQUVBLENBQUEsS0FBTWxELGFBQWEsQ0FBQyxJQUFJLENBQUU7UUFBQ29ELFFBQVEsRUFBRXpELE9BQU8sSUFBSUgsSUFBSSxLQUFLLEVBQUc7UUFBQWtCLFFBQUEsRUFBQztNQUVwSCxDQUFRLENBQUMsZ0JBRVQsSUFBQTNCLFdBQUEsQ0FBQTRCLEdBQUE7UUFDRXNDLElBQUksRUFBQyxRQUFRO1FBQ2J4QyxTQUFTLEVBQUMsb0NBQW9DO1FBQzlDeUMsT0FBTyxFQUFFQSxDQUFBLEtBQU07VUFDYmxELGFBQWEsQ0FBQyxLQUFLLENBQUM7VUFDcEJQLFlBQVksQ0FBQyxFQUFFLENBQUM7VUFDaEJJLEtBQUssQ0FBQyxDQUFDO1FBQ1QsQ0FBRTtRQUFBYSxRQUFBLEVBQ0g7TUFFRCxDQUFRLENBQ1Q7SUFBQSxDQUNFLENBQUMsRUFFTGhCLE9BQU8sS0FBSyxJQUFJLElBQUksQ0FBQ0EsT0FBTyxDQUFDMEIsRUFBRSxpQkFDOUIsSUFBQXJDLFdBQUEsQ0FBQXlCLElBQUE7TUFBS0MsU0FBUyxFQUFDLGFBQWE7TUFBQzZDLElBQUksRUFBQyxRQUFRO01BQUE1QyxRQUFBLGdCQUN4QyxJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQTtRQUFNRixTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLEVBQUVoQixPQUFPLENBQUM2RCxPQUFPLENBQUNDO01BQUksQ0FBTyxDQUFDLEtBQUMsRUFBQzlELE9BQU8sQ0FBQzZELE9BQU8sQ0FBQ0UsT0FBTztJQUFBLENBQ2hGLENBQ04sRUFDQXZCLFVBQVUsQ0FBQ0wsR0FBRyxDQUFDLENBQUNPLENBQUMsRUFBRXNCLENBQUMsa0JBQ25CLElBQUEzRSxXQUFBLENBQUE0QixHQUFBO01BQWFGLFNBQVMsRUFBQyxhQUFhO01BQUFDLFFBQUEsRUFDakMwQixDQUFDLENBQUNxQjtJQUFPLEdBREZDLENBRUwsQ0FDTixDQUFDLEVBQ0Q5QixhQUFhLENBQUNDLEdBQUcsQ0FBRTNDLENBQUMsaUJBQ25CLElBQUFILFdBQUEsQ0FBQXlCLElBQUE7TUFBZ0JDLFNBQVMsRUFBQyxhQUFhO01BQUFDLFFBQUEsR0FDcEN4QixDQUFDLENBQUM0QyxFQUFFLEVBQUMsSUFBRSxFQUFDNUMsQ0FBQyxDQUFDNkMsS0FBSztJQUFBLEdBRFI3QyxDQUFDLENBQUM0QyxFQUVQLENBQ04sQ0FBQyxFQUVEcEMsT0FBTyxFQUFFMEIsRUFBRSxLQUFLLElBQUksSUFBSUQsWUFBWSxDQUFDeUIsTUFBTSxHQUFHLENBQUMsaUJBQzlDLElBQUE3RCxXQUFBLENBQUE0QixHQUFBLEVBQUM5QixrQkFBQSxDQUFBTyxPQUFpQjtNQUNoQmlDLEtBQUssRUFBRUYsWUFBYTtNQUNwQk8sS0FBSyxFQUFFRCxZQUFhO01BQ3BCa0MsT0FBTyxFQUFFakUsT0FBTyxDQUFDa0UsUUFBUztNQUMxQkMsT0FBTyxFQUFFbkUsT0FBTyxDQUFDbUU7SUFBUSxDQUMxQixDQUNGO0VBQUEsQ0FDTSxDQUFDO0FBRWQ7QUFBQzdFLEVBQUEsQ0FqSVFLLFVBQVU7RUFBQSxRQUN3QlMsZ0NBQWU7QUFBQTtBQUFBZ0UsRUFBQSxHQURqRHpFLFVBQVU7QUFBQSxJQUFBMEUsUUFBQSxHQUFBQyxPQUFBLENBQUE1RSxPQUFBLEdBbUlKQyxVQUFVO0FBQUEsSUFBQXlFLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}