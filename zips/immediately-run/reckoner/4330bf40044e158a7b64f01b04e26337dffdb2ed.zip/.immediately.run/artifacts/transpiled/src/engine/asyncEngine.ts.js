"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TimeoutError = exports.AsyncEngine = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/web.dom-exception.stack.js");
require("core-js/modules/web.structured-clone.js");
var _tier = require("./tier.ts");
var _hash = require("./hash.ts");
var _resolve = require("./resolve.ts");
var _graph = require("./graph.ts");
var _circuitBreaker = require("./circuitBreaker.ts");
// The worker-backed async engine (ARCHITECTURE_PLAN §4.1/§4.2) — the host half of the executor
// realm. It owns all scheduling + epoch/breaker state (§4.1: "memo/epoch state lives outside
// the worker"); the worker only executes formulas. Over a `WorkerTransport` it:
//
//   - builds the graph structure from the worker's descriptor and schedules in topo order,
//     resolving inputs through the *shared* `resolveInputs` (one path with the sync Scheduler);
//   - folds tiers (`meetTiers`) and publishes `(value, tier)` per cell with content-key cutoff;
//   - runs a **watchdog** per eval: exceeding the wall-clock budget is a hard runaway — the
//     worker is `terminate()`d + rebuilt and the `CircuitBreaker` counts it; after enough, the
//     cell quarantines and its dependents resolve to the propagated **lattice error** (SES does
//     not protect availability — the breaker + error-as-value are how the engine survives it);
//   - applies **single-slot run-to-completion supersession**: overlapping `update()`s never
//     cancel an in-flight pass; they coalesce into one follow-up with the latest externals, so
//     progress holds even when eval time exceeds the input change rate (no cancel-restart livelock).
//
// GLITCH-FREEDOM (§4.2 C-R-B) is satisfied here **by construction**, not by an explicit
// common-epoch barrier. A pass evaluates cells **sequentially in topo order over one externals
// snapshot**, and passes are **strictly serialized** (single-slot supersession) — so within a
// pass every cell reads inputs derived from a single epoch, and no new epoch starts mid-pass.
// Even on an asymmetric diamond under a continuous feed (a slow arm B, a fast arm C, both under a
// shared ancestor), C cannot race ahead to a newer epoch while B lags: C only runs *after* B in
// the same pass. The freshness cost of that choice is exactly §4.2's stated trade — a cell's
// freshness equals its slowest transitive path. This invariant is proven by the glitch-freedom
// property test (asyncEngine.glitch.test.ts, spec §11 E-2), which watches every settled pass via
// `onPass`. The **per-cell epoch-gate barrier becomes necessary only if concurrent arm evaluation
// is introduced** (the deferred worker-pool partitioning, §4.1) — the single-context serial engine
// does not need it. (An explicit epoch stamp would only add value under that future concurrency.)

class TimeoutError extends Error {
  constructor(id) {
    super(`evaluation of "${id}" exceeded the budget`);
    this.name = 'TimeoutError';
  }
}

/** The settled state after a pass. */
exports.TimeoutError = TimeoutError;
const defaultTimer = (fn, ms) => {
  const h = setTimeout(fn, ms);
  return () => clearTimeout(h);
};
class AsyncEngine {
  #transport;
  #budget;
  #breaker;
  #now;
  #setTimer;
  #onPass;
  #sources = {};
  #order = [];
  #cycles = [];
  #nodesById = new Map();
  #worksheets = new Map();
  #results = new Map();
  #errors = new Map();
  #externals = new Map();
  #tests = [];
  #pending = new Map();
  #token = 0;
  #buildResolve = null;
  #buildReject = null;
  #testsPending = new Map();

  // supersession
  #running = false;
  #runningPromise = Promise.resolve(this.#emptyPass());
  #pendingExternals = null;
  constructor(opts) {
    this.#transport = opts.transport;
    this.#budget = opts.evalBudgetMs ?? 2000;
    this.#breaker = new _circuitBreaker.CircuitBreaker(opts.breaker ?? _circuitBreaker.DEFAULT_BREAKER);
    this.#now = opts.now ?? (() => Date.now());
    this.#setTimer = opts.setTimer ?? defaultTimer;
    this.#onPass = opts.onPass ?? (() => {});
    this.#transport.onMessage(msg => this.#onMessage(msg));
  }

  /** Build a fresh engine from worksheet sources over an injected transport. */
  static async fromSources(sources, opts) {
    const engine = new AsyncEngine(opts);
    await engine.build(sources);
    return engine;
  }

  /** Send the sources to the worker and adopt the returned graph structure. */
  async build(sources) {
    this.#sources = sources;
    this.#applyDescriptor(await this.#sendBuild(sources));
  }

  /** Cold run over the given externals. */
  run(externals) {
    this.#pendingExternals = toMap(externals);
    return this.#drive();
  }

  /** Merge an external delta and recompute (single-slot supersession). */
  update(delta) {
    const base = this.#pendingExternals ?? this.#externals;
    const merged = new Map(base);
    for (const [k, v] of Object.entries(delta)) merged.set(k, {
      value: v.value,
      tier: v.tier
    });
    this.#pendingExternals = merged;
    return this.#drive();
  }

  /** The published result for a cell, if any. */
  result(id) {
    return this.#results.get(id);
  }

  /** The lattice-error message for a cell, if it errored/quarantined. */
  error(id) {
    return this.#errors.get(id);
  }
  value(id) {
    return this.#results.get(id)?.value;
  }

  /**
   * Every external key the workbook reads, with the declaring cell — the input to
   * load-time cross-reference validation (`validateExternalReferences`), so a typo'd
   * feed/fixture name is a diagnostic instead of a silent null.
   */
  externalReferences() {
    const out = [];
    for (const node of this.#nodesById.values()) {
      for (const key of node.externals) out.push({
        key,
        site: node.id
      });
    }
    return out;
  }

  /** Author re-arm of a quarantined cell (§4.1). */
  rearm(id) {
    this.#breaker.rearm(id);
  }

  /** The workbook's cells (id, worksheet, cell, doc) — the review surface's card data. */
  cells() {
    return [...this.#nodesById.values()];
  }

  /** The workbook's test cells (kind + subject), sans closures — `runTests` executes them. */
  tests() {
    return this.#tests;
  }

  /**
   * Run every test suite against the current published state, worker-side (that is where the
   * `expect`/`relation` closures live), and return the review-surface verdict per subject.
   * Subjects without tests are absent from the map (their cells render `untested`).
   *
   * A divergent test wedges the worker the same way a divergent formula does, so this rides
   * a wall-clock budget like `eval`: on timeout the worker is restarted (abandoning the
   * pending suites) and the call rejects — the render pipeline's own watchdog recovery
   * pattern, applied to the review path. The per-cell circuit breaker does not yet count
   * test-run terminations (a booked residual; tests are author code with the same runaway
   * risk, but the failure is contained to the panel).
   */
  runTests() {
    const subjects = [...new Set(this.#tests.map(t => t.subject))];
    const suites = subjects.map(subject => ({
      subject,
      subjectValue: this.#results.get(subject)?.value ?? null,
      inputs: this.#inputsFor(subject),
      // R3-373: each test's declared inputs, resolved host-side against the same
      // published state a cell's inputs resolve against. Name-matched entries become
      // substitutions; name-unmatched ones are auxiliary context (oracle fixtures).
      tests: this.#tests.filter(t => t.subject === subject).map(t => this.#resolveTestInputs(t))
    }));
    const token = ++this.#token;
    return new Promise((resolve, reject) => {
      const cancel = this.#setTimer(() => {
        this.#testsPending.delete(token);
        this.#transport.restart();
        void this.#sendBuild(this.#sources).catch(() => {
          /* rebuild failure surfaces on the next pass */
        });
        reject(new Error('test run timed out (worker restarted)'));
      }, this.#budget * Math.max(1, suites.length));
      this.#testsPending.set(token, {
        resolve: r => {
          cancel();
          resolve(new Map(r.map(s => [s.subject, s])));
        },
        reject: e => {
          cancel();
          reject(e);
        }
      });
      this.#transport.post({
        type: 'run-tests',
        token,
        suites
      });
    });
  }

  /** Resolve one cell's inputs from current published state (the run-tests context). */
  #inputsFor(id) {
    const node = this.#nodesById.get(id);
    if (node === undefined) return {};
    return (0, _resolve.resolveInputs)(node.resolvers, {
      results: this.#results,
      externals: this.#externals,
      worksheets: this.#worksheets
    }).values;
  }

  /**
   * Resolve one test's declared inputs against published state (R3-373). An unresolvable
   * reference — unknown cell/worksheet (from `resolversFor`), or an external the document
   * has not supplied (absent fixture/feed/param) — is a failing test entry with a message,
   * never a silent `null` substitution.
   */
  #resolveTestInputs(test) {
    const {
      resolvers,
      diagnostics
    } = (0, _graph.resolversFor)(test.inputs, {
      nodes: this.#nodesById,
      worksheets: this.#worksheets
    });
    if (diagnostics.length > 0) {
      return {
        id: test.id,
        error: diagnostics[0]
      };
    }
    for (const r of resolvers) {
      if (r.kind === 'external' && !this.#externals.has(r.key)) {
        return {
          id: test.id,
          error: `test "${test.id}" input "${r.name}" references absent external "${r.key}".`
        };
      }
      if (r.kind === 'windowed-feed' && !this.#externals.has(`${_resolve.FEED_BUFFER_PREFIX}${r.feed}`)) {
        return {
          id: test.id,
          error: `test "${test.id}" windowed input "${r.name}" references feed "${r.feed}", which has no retained buffer.`
        };
      }
    }
    const {
      values
    } = (0, _resolve.resolveInputs)(resolvers, {
      results: this.#results,
      externals: this.#externals,
      worksheets: this.#worksheets
    });
    return {
      id: test.id,
      inputs: values
    };
  }
  snapshot() {
    return {
      results: new Map(this.#results),
      errors: new Map(this.#errors),
      quarantined: this.#breaker.quarantined()
    };
  }

  /**
   * A coherent settled baseline for shadow evaluation (WHATIF_SHADOW_EVALUATION_SPEC §2.1,
   * G-WIF-3): awaits quiescence (no pass in flight, nothing pending — bounded by single-slot
   * supersession), then returns the settled pass **and** the externals that produced it as
   * one pair. The externals are **deep copies** (structured clone; every external crossed the
   * worker boundary, so clonability holds by construction) — a correctness requirement on the
   * in-process transport, where handing out live references would let a shadow formula mutate
   * the base session's inputs.
   */
  async settledSnapshot() {
    while (this.#running || this.#pendingExternals !== null) {
      if (!this.#running) {
        // Pending-but-idle is unreachable via run()/update() (both drive synchronously),
        // but a caller racing the microtask gap lands here — drive rather than spin.
        await this.#drive();
      } else {
        await this.#runningPromise;
      }
    }
    const externals = {};
    for (const [k, v] of this.#externals) {
      externals[k] = structuredClone({
        value: v.value,
        tier: v.tier
      });
    }
    return {
      pass: this.snapshot(),
      externals
    };
  }

  // --- internals -----------------------------------------------------------------

  #emptyPass() {
    return {
      results: new Map(),
      errors: new Map(),
      quarantined: []
    };
  }
  #applyDescriptor(d) {
    this.#order = d.order;
    this.#cycles = d.cycles;
    this.#nodesById = new Map(d.cells.map(c => [c.id, c]));
    this.#worksheets = new Map(d.worksheets);
    this.#tests = d.tests;
  }
  #onMessage(msg) {
    if (msg.type === 'built') {
      this.#buildResolve?.(msg.descriptor);
      this.#buildResolve = this.#buildReject = null;
    } else if (msg.type === 'build-error') {
      this.#buildReject?.(new Error(msg.message));
      this.#buildResolve = this.#buildReject = null;
    } else if (msg.type === 'test-results') {
      const p = this.#testsPending.get(msg.token);
      if (p === undefined) return;
      this.#testsPending.delete(msg.token);
      p.resolve(msg.suites);
    } else if (msg.type === 'eval-error') {
      // An eval-error can carry a run-tests token (suite machinery threw worker-side).
      const t = this.#testsPending.get(msg.token);
      if (t !== undefined) {
        this.#testsPending.delete(msg.token);
        t.reject(new Error(msg.message));
        return;
      }
      const p = this.#pending.get(msg.token);
      if (p !== undefined) p.reject(new Error(msg.message));
    } else {
      const p = this.#pending.get(msg.token);
      if (p === undefined) return; // superseded / abandoned after a restart
      p.resolve(msg.value);
    }
  }
  #sendBuild(sources) {
    return new Promise((resolve, reject) => {
      this.#buildResolve = resolve;
      this.#buildReject = reject;
      this.#transport.post({
        type: 'build',
        sources
      });
    });
  }
  #drive() {
    if (!this.#running) {
      this.#running = true;
      this.#runningPromise = this.#loop().finally(() => {
        this.#running = false;
      });
    }
    return this.#runningPromise;
  }
  async #loop() {
    let last = this.#emptyPass();
    while (this.#pendingExternals !== null) {
      const externals = this.#pendingExternals;
      this.#pendingExternals = null;
      last = await this.#pass(externals);
    }
    return last;
  }
  async #pass(externals) {
    this.#externals = externals;
    this.#results = new Map();
    this.#errors = new Map();
    if (this.#cycles.length > 0) {
      // A cyclic workbook is unrunnable — and cyclic nodes are excluded from the topo `order`,
      // so error *every* cell, not just the orderable ones.
      const path = this.#cycles.map(c => c.join(' → ')).join('; ');
      for (const id of this.#nodesById.keys()) this.#errors.set(id, `dependency cycle: ${path}`);
      return this.#settle();
    }
    for (const id of this.#order) {
      const node = this.#nodesById.get(id);
      if (node === undefined) continue;
      if (this.#breaker.isBlocked(id, this.#now())) {
        this.#errors.set(id, 'quarantined (circuit breaker)');
        continue;
      }
      const erroredDep = node.deps.find(d => this.#errors.has(d));
      if (erroredDep !== undefined) {
        this.#errors.set(id, `input "${erroredDep}" errored`);
        continue;
      }
      const {
        values,
        tiers
      } = (0, _resolve.resolveInputs)(node.resolvers, {
        results: this.#results,
        externals: this.#externals,
        worksheets: this.#worksheets
      });
      try {
        const value = await this.#evalWithWatchdog(id, values);
        this.#publish(id, value, (0, _tier.meetTiers)(tiers));
      } catch (e) {
        if (e instanceof TimeoutError) {
          // Hard runaway: kill the wedged worker, rebuild it, and count toward the breaker.
          this.#transport.restart();
          this.#breaker.hardTermination(id, this.#now());
          try {
            await this.#sendBuild(this.#sources);
          } catch {
            /* rebuild failure surfaces on the next pass; this cell is already errored */
          }
          this.#errors.set(id, 'evaluation timed out (terminated)');
        } else {
          // Formula threw — a deterministic lattice error, not a runaway (worker is fine).
          this.#errors.set(id, e.message);
        }
      }
    }
    return this.#settle();
  }

  /** Snapshot the settled pass and notify the observer (every pass, not just the coalesced last). */
  #settle() {
    const pass = this.snapshot();
    this.#onPass(pass);
    return pass;
  }
  #evalWithWatchdog(id, inputs) {
    const token = ++this.#token;
    return new Promise((resolve, reject) => {
      let cancel = () => {};
      const settle = fn => arg => {
        cancel();
        this.#pending.delete(token);
        fn(arg);
      };
      this.#pending.set(token, {
        resolve: settle(resolve),
        reject: settle(reject)
      });
      cancel = this.#setTimer(() => {
        this.#pending.delete(token);
        reject(new TimeoutError(id));
      }, this.#budget);
      this.#transport.post({
        type: 'eval',
        id,
        token,
        inputs
      });
    });
  }
  #publish(id, value, tier) {
    this.#results.set(id, {
      id,
      value,
      tier,
      key: (0, _hash.contentKey)(value)
    });
  }
}
exports.AsyncEngine = AsyncEngine;
function toMap(externals) {
  return new Map(Object.entries(externals).map(([k, v]) => [k, {
    value: v.value,
    tier: v.tier
  }]));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdGllciIsInJlcXVpcmUiLCJfaGFzaCIsIl9yZXNvbHZlIiwiX2dyYXBoIiwiX2NpcmN1aXRCcmVha2VyIiwiVGltZW91dEVycm9yIiwiRXJyb3IiLCJjb25zdHJ1Y3RvciIsImlkIiwibmFtZSIsImV4cG9ydHMiLCJkZWZhdWx0VGltZXIiLCJmbiIsIm1zIiwiaCIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJBc3luY0VuZ2luZSIsInRyYW5zcG9ydCIsImJ1ZGdldCIsImJyZWFrZXIiLCJub3ciLCJzZXRUaW1lciIsIm9uUGFzcyIsInNvdXJjZXMiLCJvcmRlciIsImN5Y2xlcyIsIm5vZGVzQnlJZCIsIk1hcCIsIndvcmtzaGVldHMiLCJyZXN1bHRzIiwiZXJyb3JzIiwiZXh0ZXJuYWxzIiwidGVzdHMiLCJwZW5kaW5nIiwidG9rZW4iLCJidWlsZFJlc29sdmUiLCJidWlsZFJlamVjdCIsInRlc3RzUGVuZGluZyIsInJ1bm5pbmciLCJydW5uaW5nUHJvbWlzZSIsIlByb21pc2UiLCJyZXNvbHZlIiwiZW1wdHlQYXNzIiwicGVuZGluZ0V4dGVybmFscyIsIm9wdHMiLCJldmFsQnVkZ2V0TXMiLCJDaXJjdWl0QnJlYWtlciIsIkRFRkFVTFRfQlJFQUtFUiIsIkRhdGUiLCJvbk1lc3NhZ2UiLCJtc2ciLCJmcm9tU291cmNlcyIsImVuZ2luZSIsImJ1aWxkIiwiYXBwbHlEZXNjcmlwdG9yIiwic2VuZEJ1aWxkIiwicnVuIiwidG9NYXAiLCJkcml2ZSIsInVwZGF0ZSIsImRlbHRhIiwiYmFzZSIsIm1lcmdlZCIsImsiLCJ2IiwiT2JqZWN0IiwiZW50cmllcyIsInNldCIsInZhbHVlIiwidGllciIsInJlc3VsdCIsImdldCIsImVycm9yIiwiZXh0ZXJuYWxSZWZlcmVuY2VzIiwib3V0Iiwibm9kZSIsInZhbHVlcyIsImtleSIsInB1c2giLCJzaXRlIiwicmVhcm0iLCJjZWxscyIsInJ1blRlc3RzIiwic3ViamVjdHMiLCJTZXQiLCJtYXAiLCJ0Iiwic3ViamVjdCIsInN1aXRlcyIsInN1YmplY3RWYWx1ZSIsImlucHV0cyIsImlucHV0c0ZvciIsImZpbHRlciIsInJlc29sdmVUZXN0SW5wdXRzIiwicmVqZWN0IiwiY2FuY2VsIiwiZGVsZXRlIiwicmVzdGFydCIsImNhdGNoIiwiTWF0aCIsIm1heCIsImxlbmd0aCIsInIiLCJzIiwiZSIsInBvc3QiLCJ0eXBlIiwiI2lucHV0c0ZvciIsInVuZGVmaW5lZCIsInJlc29sdmVJbnB1dHMiLCJyZXNvbHZlcnMiLCIjcmVzb2x2ZVRlc3RJbnB1dHMiLCJ0ZXN0IiwiZGlhZ25vc3RpY3MiLCJyZXNvbHZlcnNGb3IiLCJub2RlcyIsImtpbmQiLCJoYXMiLCJGRUVEX0JVRkZFUl9QUkVGSVgiLCJmZWVkIiwic25hcHNob3QiLCJxdWFyYW50aW5lZCIsInNldHRsZWRTbmFwc2hvdCIsInN0cnVjdHVyZWRDbG9uZSIsInBhc3MiLCIjZW1wdHlQYXNzIiwiI2FwcGx5RGVzY3JpcHRvciIsImQiLCJjIiwiI29uTWVzc2FnZSIsImRlc2NyaXB0b3IiLCJtZXNzYWdlIiwicCIsIiNzZW5kQnVpbGQiLCIjZHJpdmUiLCJsb29wIiwiZmluYWxseSIsIiNsb29wIiwibGFzdCIsIiNwYXNzIiwicGF0aCIsImpvaW4iLCJrZXlzIiwic2V0dGxlIiwiaXNCbG9ja2VkIiwiZXJyb3JlZERlcCIsImRlcHMiLCJmaW5kIiwidGllcnMiLCJldmFsV2l0aFdhdGNoZG9nIiwicHVibGlzaCIsIm1lZXRUaWVycyIsImhhcmRUZXJtaW5hdGlvbiIsIiNzZXR0bGUiLCIjZXZhbFdpdGhXYXRjaGRvZyIsImFyZyIsIiNwdWJsaXNoIiwiY29udGVudEtleSJdLCJzb3VyY2VzIjpbImFzeW5jRW5naW5lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSB3b3JrZXItYmFja2VkIGFzeW5jIGVuZ2luZSAoQVJDSElURUNUVVJFX1BMQU4gwqc0LjEvwqc0LjIpIOKAlCB0aGUgaG9zdCBoYWxmIG9mIHRoZSBleGVjdXRvclxuLy8gcmVhbG0uIEl0IG93bnMgYWxsIHNjaGVkdWxpbmcgKyBlcG9jaC9icmVha2VyIHN0YXRlICjCpzQuMTogXCJtZW1vL2Vwb2NoIHN0YXRlIGxpdmVzIG91dHNpZGVcbi8vIHRoZSB3b3JrZXJcIik7IHRoZSB3b3JrZXIgb25seSBleGVjdXRlcyBmb3JtdWxhcy4gT3ZlciBhIGBXb3JrZXJUcmFuc3BvcnRgIGl0OlxuLy9cbi8vICAgLSBidWlsZHMgdGhlIGdyYXBoIHN0cnVjdHVyZSBmcm9tIHRoZSB3b3JrZXIncyBkZXNjcmlwdG9yIGFuZCBzY2hlZHVsZXMgaW4gdG9wbyBvcmRlcixcbi8vICAgICByZXNvbHZpbmcgaW5wdXRzIHRocm91Z2ggdGhlICpzaGFyZWQqIGByZXNvbHZlSW5wdXRzYCAob25lIHBhdGggd2l0aCB0aGUgc3luYyBTY2hlZHVsZXIpO1xuLy8gICAtIGZvbGRzIHRpZXJzIChgbWVldFRpZXJzYCkgYW5kIHB1Ymxpc2hlcyBgKHZhbHVlLCB0aWVyKWAgcGVyIGNlbGwgd2l0aCBjb250ZW50LWtleSBjdXRvZmY7XG4vLyAgIC0gcnVucyBhICoqd2F0Y2hkb2cqKiBwZXIgZXZhbDogZXhjZWVkaW5nIHRoZSB3YWxsLWNsb2NrIGJ1ZGdldCBpcyBhIGhhcmQgcnVuYXdheSDigJQgdGhlXG4vLyAgICAgd29ya2VyIGlzIGB0ZXJtaW5hdGUoKWBkICsgcmVidWlsdCBhbmQgdGhlIGBDaXJjdWl0QnJlYWtlcmAgY291bnRzIGl0OyBhZnRlciBlbm91Z2gsIHRoZVxuLy8gICAgIGNlbGwgcXVhcmFudGluZXMgYW5kIGl0cyBkZXBlbmRlbnRzIHJlc29sdmUgdG8gdGhlIHByb3BhZ2F0ZWQgKipsYXR0aWNlIGVycm9yKiogKFNFUyBkb2VzXG4vLyAgICAgbm90IHByb3RlY3QgYXZhaWxhYmlsaXR5IOKAlCB0aGUgYnJlYWtlciArIGVycm9yLWFzLXZhbHVlIGFyZSBob3cgdGhlIGVuZ2luZSBzdXJ2aXZlcyBpdCk7XG4vLyAgIC0gYXBwbGllcyAqKnNpbmdsZS1zbG90IHJ1bi10by1jb21wbGV0aW9uIHN1cGVyc2Vzc2lvbioqOiBvdmVybGFwcGluZyBgdXBkYXRlKClgcyBuZXZlclxuLy8gICAgIGNhbmNlbCBhbiBpbi1mbGlnaHQgcGFzczsgdGhleSBjb2FsZXNjZSBpbnRvIG9uZSBmb2xsb3ctdXAgd2l0aCB0aGUgbGF0ZXN0IGV4dGVybmFscywgc29cbi8vICAgICBwcm9ncmVzcyBob2xkcyBldmVuIHdoZW4gZXZhbCB0aW1lIGV4Y2VlZHMgdGhlIGlucHV0IGNoYW5nZSByYXRlIChubyBjYW5jZWwtcmVzdGFydCBsaXZlbG9jaykuXG4vL1xuLy8gR0xJVENILUZSRUVET00gKMKnNC4yIEMtUi1CKSBpcyBzYXRpc2ZpZWQgaGVyZSAqKmJ5IGNvbnN0cnVjdGlvbioqLCBub3QgYnkgYW4gZXhwbGljaXRcbi8vIGNvbW1vbi1lcG9jaCBiYXJyaWVyLiBBIHBhc3MgZXZhbHVhdGVzIGNlbGxzICoqc2VxdWVudGlhbGx5IGluIHRvcG8gb3JkZXIgb3ZlciBvbmUgZXh0ZXJuYWxzXG4vLyBzbmFwc2hvdCoqLCBhbmQgcGFzc2VzIGFyZSAqKnN0cmljdGx5IHNlcmlhbGl6ZWQqKiAoc2luZ2xlLXNsb3Qgc3VwZXJzZXNzaW9uKSDigJQgc28gd2l0aGluIGFcbi8vIHBhc3MgZXZlcnkgY2VsbCByZWFkcyBpbnB1dHMgZGVyaXZlZCBmcm9tIGEgc2luZ2xlIGVwb2NoLCBhbmQgbm8gbmV3IGVwb2NoIHN0YXJ0cyBtaWQtcGFzcy5cbi8vIEV2ZW4gb24gYW4gYXN5bW1ldHJpYyBkaWFtb25kIHVuZGVyIGEgY29udGludW91cyBmZWVkIChhIHNsb3cgYXJtIEIsIGEgZmFzdCBhcm0gQywgYm90aCB1bmRlciBhXG4vLyBzaGFyZWQgYW5jZXN0b3IpLCBDIGNhbm5vdCByYWNlIGFoZWFkIHRvIGEgbmV3ZXIgZXBvY2ggd2hpbGUgQiBsYWdzOiBDIG9ubHkgcnVucyAqYWZ0ZXIqIEIgaW5cbi8vIHRoZSBzYW1lIHBhc3MuIFRoZSBmcmVzaG5lc3MgY29zdCBvZiB0aGF0IGNob2ljZSBpcyBleGFjdGx5IMKnNC4yJ3Mgc3RhdGVkIHRyYWRlIOKAlCBhIGNlbGwnc1xuLy8gZnJlc2huZXNzIGVxdWFscyBpdHMgc2xvd2VzdCB0cmFuc2l0aXZlIHBhdGguIFRoaXMgaW52YXJpYW50IGlzIHByb3ZlbiBieSB0aGUgZ2xpdGNoLWZyZWVkb21cbi8vIHByb3BlcnR5IHRlc3QgKGFzeW5jRW5naW5lLmdsaXRjaC50ZXN0LnRzLCBzcGVjIMKnMTEgRS0yKSwgd2hpY2ggd2F0Y2hlcyBldmVyeSBzZXR0bGVkIHBhc3MgdmlhXG4vLyBgb25QYXNzYC4gVGhlICoqcGVyLWNlbGwgZXBvY2gtZ2F0ZSBiYXJyaWVyIGJlY29tZXMgbmVjZXNzYXJ5IG9ubHkgaWYgY29uY3VycmVudCBhcm0gZXZhbHVhdGlvblxuLy8gaXMgaW50cm9kdWNlZCoqICh0aGUgZGVmZXJyZWQgd29ya2VyLXBvb2wgcGFydGl0aW9uaW5nLCDCpzQuMSkg4oCUIHRoZSBzaW5nbGUtY29udGV4dCBzZXJpYWwgZW5naW5lXG4vLyBkb2VzIG5vdCBuZWVkIGl0LiAoQW4gZXhwbGljaXQgZXBvY2ggc3RhbXAgd291bGQgb25seSBhZGQgdmFsdWUgdW5kZXIgdGhhdCBmdXR1cmUgY29uY3VycmVuY3kuKVxuXG5pbXBvcnQgdHlwZSB7IFZhbHVlIH0gZnJvbSAnLi4vc3RkbGliL3R5cGVzLnRzJztcbmltcG9ydCB0eXBlIHsgRXh0ZXJuYWxWYWx1ZSwgUHVibGlzaGVkUmVzdWx0IH0gZnJvbSAnLi90eXBlcy50cyc7XG5pbXBvcnQgeyBtZWV0VGllcnMgfSBmcm9tICcuL3RpZXIudHMnO1xuaW1wb3J0IHsgY29udGVudEtleSB9IGZyb20gJy4vaGFzaC50cyc7XG5pbXBvcnQgeyByZXNvbHZlSW5wdXRzLCBGRUVEX0JVRkZFUl9QUkVGSVggfSBmcm9tICcuL3Jlc29sdmUudHMnO1xuaW1wb3J0IHsgcmVzb2x2ZXJzRm9yIH0gZnJvbSAnLi9ncmFwaC50cyc7XG5pbXBvcnQgeyBDaXJjdWl0QnJlYWtlciwgREVGQVVMVF9CUkVBS0VSIH0gZnJvbSAnLi9jaXJjdWl0QnJlYWtlci50cyc7XG5pbXBvcnQgdHlwZSB7IEJyZWFrZXJDb25maWcgfSBmcm9tICcuL2NpcmN1aXRCcmVha2VyLnRzJztcbmltcG9ydCB0eXBlIHsgV29ya2VyVHJhbnNwb3J0IH0gZnJvbSAnLi93b3JrZXJUcmFuc3BvcnQudHMnO1xuaW1wb3J0IHR5cGUge1xuICBDZWxsRGVzY3JpcHRvcixcbiAgU3ViamVjdFJlc3VsdCxcbiAgU3VpdGVDb250ZXh0LFxuICBUZXN0SW5wdXRDb250ZXh0LFxuICBUZXN0RGVzY3JpcHRvcixcbiAgV29ya2Jvb2tEZXNjcmlwdG9yLFxuICBXb3JrZXJSZXNwb25zZSxcbn0gZnJvbSAnLi93b3JrZXIvcHJvdG9jb2wudHMnO1xuXG5leHBvcnQgY2xhc3MgVGltZW91dEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihpZDogc3RyaW5nKSB7XG4gICAgc3VwZXIoYGV2YWx1YXRpb24gb2YgXCIke2lkfVwiIGV4Y2VlZGVkIHRoZSBidWRnZXRgKTtcbiAgICB0aGlzLm5hbWUgPSAnVGltZW91dEVycm9yJztcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEFzeW5jRW5naW5lT3B0aW9ucyB7XG4gIHRyYW5zcG9ydDogV29ya2VyVHJhbnNwb3J0O1xuICAvKiogUGVyLWV2YWwgd2FsbC1jbG9jayBidWRnZXQgKG1zKTsgZXhjZWVkaW5nIGl0IGlzIGEgaGFyZCBydW5hd2F5LiBEZWZhdWx0IDIwMDAuICovXG4gIGV2YWxCdWRnZXRNcz86IG51bWJlcjtcbiAgYnJlYWtlcj86IEJyZWFrZXJDb25maWc7XG4gIC8qKiBJbmplY3RlZCBjbG9jayDigJQga2VwdCBvdXQgb2YgYW1iaWVudCBzbyBwYXNzZXMgYXJlIGRldGVybWluaXN0aWMgaW4gdGVzdHMuICovXG4gIG5vdz86ICgpID0+IG51bWJlcjtcbiAgLyoqIEluamVjdGVkIHRpbWVyOyByZXR1cm5zIGEgY2FuY2VsbGVyLiBEZWZhdWx0IGBzZXRUaW1lb3V0YC9gY2xlYXJUaW1lb3V0YC4gKi9cbiAgc2V0VGltZXI/OiAoZm46ICgpID0+IHZvaWQsIG1zOiBudW1iZXIpID0+ICgpID0+IHZvaWQ7XG4gIC8qKlxuICAgKiBPYnNlcnZlIGV2ZXJ5IHNldHRsZWQgcGFzcyAobm90IGp1c3QgdGhlIGNvYWxlc2NlZCBmaW5hbCBvbmUpIOKAlCB0aGUgaG9vayB0aGVcbiAgICogZ2xpdGNoLWZyZWVkb20gcHJvcGVydHkgdGVzdCB3YXRjaGVzLiBBIHBhc3MgaXMgaW50ZXJuYWxseSBzaW5nbGUtZXBvY2ggYnkgY29uc3RydWN0aW9uXG4gICAqIChzZXJpYWwgZXZhbHVhdGlvbiBvdmVyIG9uZSBleHRlcm5hbHMgc25hcHNob3QpLCBzbyB0aGlzIGV4cG9zZXMgdGhhdCBpbnZhcmlhbnQgdG8gYSBjaGVja2VyLlxuICAgKi9cbiAgb25QYXNzPzogKHBhc3M6IEFzeW5jUGFzcykgPT4gdm9pZDtcbn1cblxuLyoqIFRoZSBzZXR0bGVkIHN0YXRlIGFmdGVyIGEgcGFzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXN5bmNQYXNzIHtcbiAgcmVzdWx0czogTWFwPHN0cmluZywgUHVibGlzaGVkUmVzdWx0PjtcbiAgZXJyb3JzOiBNYXA8c3RyaW5nLCBzdHJpbmc+O1xuICBxdWFyYW50aW5lZDogc3RyaW5nW107XG59XG5cbmludGVyZmFjZSBQZW5kaW5nRXZhbCB7XG4gIHJlc29sdmU6ICh2OiBWYWx1ZSkgPT4gdm9pZDtcbiAgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7XG59XG5cbmNvbnN0IGRlZmF1bHRUaW1lciA9IChmbjogKCkgPT4gdm9pZCwgbXM6IG51bWJlcik6ICgoKSA9PiB2b2lkKSA9PiB7XG4gIGNvbnN0IGggPSBzZXRUaW1lb3V0KGZuLCBtcyk7XG4gIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQoaCk7XG59O1xuXG5leHBvcnQgY2xhc3MgQXN5bmNFbmdpbmUge1xuICByZWFkb25seSAjdHJhbnNwb3J0OiBXb3JrZXJUcmFuc3BvcnQ7XG4gIHJlYWRvbmx5ICNidWRnZXQ6IG51bWJlcjtcbiAgcmVhZG9ubHkgI2JyZWFrZXI6IENpcmN1aXRCcmVha2VyO1xuICByZWFkb25seSAjbm93OiAoKSA9PiBudW1iZXI7XG4gIHJlYWRvbmx5ICNzZXRUaW1lcjogKGZuOiAoKSA9PiB2b2lkLCBtczogbnVtYmVyKSA9PiAoKSA9PiB2b2lkO1xuICByZWFkb25seSAjb25QYXNzOiAocGFzczogQXN5bmNQYXNzKSA9PiB2b2lkO1xuXG4gICNzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gICNvcmRlcjogc3RyaW5nW10gPSBbXTtcbiAgI2N5Y2xlczogc3RyaW5nW11bXSA9IFtdO1xuICAjbm9kZXNCeUlkID0gbmV3IE1hcDxzdHJpbmcsIENlbGxEZXNjcmlwdG9yPigpO1xuICAjd29ya3NoZWV0cyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmdbXT4oKTtcblxuICAjcmVzdWx0cyA9IG5ldyBNYXA8c3RyaW5nLCBQdWJsaXNoZWRSZXN1bHQ+KCk7XG4gICNlcnJvcnMgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xuICAjZXh0ZXJuYWxzID0gbmV3IE1hcDxzdHJpbmcsIHsgdmFsdWU6IFZhbHVlOyB0aWVyOiBFeHRlcm5hbFZhbHVlWyd0aWVyJ10gfT4oKTtcbiAgI3Rlc3RzOiBXb3JrYm9va0Rlc2NyaXB0b3JbJ3Rlc3RzJ10gPSBbXTtcblxuICAjcGVuZGluZyA9IG5ldyBNYXA8bnVtYmVyLCBQZW5kaW5nRXZhbD4oKTtcbiAgI3Rva2VuID0gMDtcbiAgI2J1aWxkUmVzb2x2ZTogKChkOiBXb3JrYm9va0Rlc2NyaXB0b3IpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG4gICNidWlsZFJlamVjdDogKChlOiBFcnJvcikgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcbiAgI3Rlc3RzUGVuZGluZyA9IG5ldyBNYXA8bnVtYmVyLCB7IHJlc29sdmU6IChyOiBTdWJqZWN0UmVzdWx0W10pID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkIH0+KCk7XG5cbiAgLy8gc3VwZXJzZXNzaW9uXG4gICNydW5uaW5nID0gZmFsc2U7XG4gICNydW5uaW5nUHJvbWlzZTogUHJvbWlzZTxBc3luY1Bhc3M+ID0gUHJvbWlzZS5yZXNvbHZlKHRoaXMuI2VtcHR5UGFzcygpKTtcbiAgI3BlbmRpbmdFeHRlcm5hbHM6IE1hcDxzdHJpbmcsIHsgdmFsdWU6IFZhbHVlOyB0aWVyOiBFeHRlcm5hbFZhbHVlWyd0aWVyJ10gfT4gfCBudWxsID0gbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiBBc3luY0VuZ2luZU9wdGlvbnMpIHtcbiAgICB0aGlzLiN0cmFuc3BvcnQgPSBvcHRzLnRyYW5zcG9ydDtcbiAgICB0aGlzLiNidWRnZXQgPSBvcHRzLmV2YWxCdWRnZXRNcyA/PyAyMDAwO1xuICAgIHRoaXMuI2JyZWFrZXIgPSBuZXcgQ2lyY3VpdEJyZWFrZXIob3B0cy5icmVha2VyID8/IERFRkFVTFRfQlJFQUtFUik7XG4gICAgdGhpcy4jbm93ID0gb3B0cy5ub3cgPz8gKCgpID0+IERhdGUubm93KCkpO1xuICAgIHRoaXMuI3NldFRpbWVyID0gb3B0cy5zZXRUaW1lciA/PyBkZWZhdWx0VGltZXI7XG4gICAgdGhpcy4jb25QYXNzID0gb3B0cy5vblBhc3MgPz8gKCgpID0+IHt9KTtcbiAgICB0aGlzLiN0cmFuc3BvcnQub25NZXNzYWdlKChtc2cpID0+IHRoaXMuI29uTWVzc2FnZShtc2cpKTtcbiAgfVxuXG4gIC8qKiBCdWlsZCBhIGZyZXNoIGVuZ2luZSBmcm9tIHdvcmtzaGVldCBzb3VyY2VzIG92ZXIgYW4gaW5qZWN0ZWQgdHJhbnNwb3J0LiAqL1xuICBzdGF0aWMgYXN5bmMgZnJvbVNvdXJjZXMoc291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiwgb3B0czogT21pdDxBc3luY0VuZ2luZU9wdGlvbnMsIG5ldmVyPik6IFByb21pc2U8QXN5bmNFbmdpbmU+IHtcbiAgICBjb25zdCBlbmdpbmUgPSBuZXcgQXN5bmNFbmdpbmUob3B0cyk7XG4gICAgYXdhaXQgZW5naW5lLmJ1aWxkKHNvdXJjZXMpO1xuICAgIHJldHVybiBlbmdpbmU7XG4gIH1cblxuICAvKiogU2VuZCB0aGUgc291cmNlcyB0byB0aGUgd29ya2VyIGFuZCBhZG9wdCB0aGUgcmV0dXJuZWQgZ3JhcGggc3RydWN0dXJlLiAqL1xuICBhc3luYyBidWlsZChzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy4jc291cmNlcyA9IHNvdXJjZXM7XG4gICAgdGhpcy4jYXBwbHlEZXNjcmlwdG9yKGF3YWl0IHRoaXMuI3NlbmRCdWlsZChzb3VyY2VzKSk7XG4gIH1cblxuICAvKiogQ29sZCBydW4gb3ZlciB0aGUgZ2l2ZW4gZXh0ZXJuYWxzLiAqL1xuICBydW4oZXh0ZXJuYWxzOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPik6IFByb21pc2U8QXN5bmNQYXNzPiB7XG4gICAgdGhpcy4jcGVuZGluZ0V4dGVybmFscyA9IHRvTWFwKGV4dGVybmFscyk7XG4gICAgcmV0dXJuIHRoaXMuI2RyaXZlKCk7XG4gIH1cblxuICAvKiogTWVyZ2UgYW4gZXh0ZXJuYWwgZGVsdGEgYW5kIHJlY29tcHV0ZSAoc2luZ2xlLXNsb3Qgc3VwZXJzZXNzaW9uKS4gKi9cbiAgdXBkYXRlKGRlbHRhOiBSZWNvcmQ8c3RyaW5nLCBFeHRlcm5hbFZhbHVlPik6IFByb21pc2U8QXN5bmNQYXNzPiB7XG4gICAgY29uc3QgYmFzZSA9IHRoaXMuI3BlbmRpbmdFeHRlcm5hbHMgPz8gdGhpcy4jZXh0ZXJuYWxzO1xuICAgIGNvbnN0IG1lcmdlZCA9IG5ldyBNYXAoYmFzZSk7XG4gICAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMoZGVsdGEpKSBtZXJnZWQuc2V0KGssIHsgdmFsdWU6IHYudmFsdWUsIHRpZXI6IHYudGllciB9KTtcbiAgICB0aGlzLiNwZW5kaW5nRXh0ZXJuYWxzID0gbWVyZ2VkO1xuICAgIHJldHVybiB0aGlzLiNkcml2ZSgpO1xuICB9XG5cbiAgLyoqIFRoZSBwdWJsaXNoZWQgcmVzdWx0IGZvciBhIGNlbGwsIGlmIGFueS4gKi9cbiAgcmVzdWx0KGlkOiBzdHJpbmcpOiBQdWJsaXNoZWRSZXN1bHQgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiNyZXN1bHRzLmdldChpZCk7XG4gIH1cblxuICAvKiogVGhlIGxhdHRpY2UtZXJyb3IgbWVzc2FnZSBmb3IgYSBjZWxsLCBpZiBpdCBlcnJvcmVkL3F1YXJhbnRpbmVkLiAqL1xuICBlcnJvcihpZDogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy4jZXJyb3JzLmdldChpZCk7XG4gIH1cblxuICB2YWx1ZShpZDogc3RyaW5nKTogVmFsdWUgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiNyZXN1bHRzLmdldChpZCk/LnZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqIEV2ZXJ5IGV4dGVybmFsIGtleSB0aGUgd29ya2Jvb2sgcmVhZHMsIHdpdGggdGhlIGRlY2xhcmluZyBjZWxsIOKAlCB0aGUgaW5wdXQgdG9cbiAgICogbG9hZC10aW1lIGNyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uIChgdmFsaWRhdGVFeHRlcm5hbFJlZmVyZW5jZXNgKSwgc28gYSB0eXBvJ2RcbiAgICogZmVlZC9maXh0dXJlIG5hbWUgaXMgYSBkaWFnbm9zdGljIGluc3RlYWQgb2YgYSBzaWxlbnQgbnVsbC5cbiAgICovXG4gIGV4dGVybmFsUmVmZXJlbmNlcygpOiB7IGtleTogc3RyaW5nOyBzaXRlOiBzdHJpbmcgfVtdIHtcbiAgICBjb25zdCBvdXQ6IHsga2V5OiBzdHJpbmc7IHNpdGU6IHN0cmluZyB9W10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IG5vZGUgb2YgdGhpcy4jbm9kZXNCeUlkLnZhbHVlcygpKSB7XG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiBub2RlLmV4dGVybmFscykgb3V0LnB1c2goeyBrZXksIHNpdGU6IG5vZGUuaWQgfSk7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG4gIH1cblxuICAvKiogQXV0aG9yIHJlLWFybSBvZiBhIHF1YXJhbnRpbmVkIGNlbGwgKMKnNC4xKS4gKi9cbiAgcmVhcm0oaWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIHRoaXMuI2JyZWFrZXIucmVhcm0oaWQpO1xuICB9XG5cbiAgLyoqIFRoZSB3b3JrYm9vaydzIGNlbGxzIChpZCwgd29ya3NoZWV0LCBjZWxsLCBkb2MpIOKAlCB0aGUgcmV2aWV3IHN1cmZhY2UncyBjYXJkIGRhdGEuICovXG4gIGNlbGxzKCk6IHJlYWRvbmx5IENlbGxEZXNjcmlwdG9yW10ge1xuICAgIHJldHVybiBbLi4udGhpcy4jbm9kZXNCeUlkLnZhbHVlcygpXTtcbiAgfVxuXG4gIC8qKiBUaGUgd29ya2Jvb2sncyB0ZXN0IGNlbGxzIChraW5kICsgc3ViamVjdCksIHNhbnMgY2xvc3VyZXMg4oCUIGBydW5UZXN0c2AgZXhlY3V0ZXMgdGhlbS4gKi9cbiAgdGVzdHMoKTogcmVhZG9ubHkgVGVzdERlc2NyaXB0b3JbXSB7XG4gICAgcmV0dXJuIHRoaXMuI3Rlc3RzO1xuICB9XG5cbiAgLyoqXG4gICAqIFJ1biBldmVyeSB0ZXN0IHN1aXRlIGFnYWluc3QgdGhlIGN1cnJlbnQgcHVibGlzaGVkIHN0YXRlLCB3b3JrZXItc2lkZSAodGhhdCBpcyB3aGVyZSB0aGVcbiAgICogYGV4cGVjdGAvYHJlbGF0aW9uYCBjbG9zdXJlcyBsaXZlKSwgYW5kIHJldHVybiB0aGUgcmV2aWV3LXN1cmZhY2UgdmVyZGljdCBwZXIgc3ViamVjdC5cbiAgICogU3ViamVjdHMgd2l0aG91dCB0ZXN0cyBhcmUgYWJzZW50IGZyb20gdGhlIG1hcCAodGhlaXIgY2VsbHMgcmVuZGVyIGB1bnRlc3RlZGApLlxuICAgKlxuICAgKiBBIGRpdmVyZ2VudCB0ZXN0IHdlZGdlcyB0aGUgd29ya2VyIHRoZSBzYW1lIHdheSBhIGRpdmVyZ2VudCBmb3JtdWxhIGRvZXMsIHNvIHRoaXMgcmlkZXNcbiAgICogYSB3YWxsLWNsb2NrIGJ1ZGdldCBsaWtlIGBldmFsYDogb24gdGltZW91dCB0aGUgd29ya2VyIGlzIHJlc3RhcnRlZCAoYWJhbmRvbmluZyB0aGVcbiAgICogcGVuZGluZyBzdWl0ZXMpIGFuZCB0aGUgY2FsbCByZWplY3RzIOKAlCB0aGUgcmVuZGVyIHBpcGVsaW5lJ3Mgb3duIHdhdGNoZG9nIHJlY292ZXJ5XG4gICAqIHBhdHRlcm4sIGFwcGxpZWQgdG8gdGhlIHJldmlldyBwYXRoLiBUaGUgcGVyLWNlbGwgY2lyY3VpdCBicmVha2VyIGRvZXMgbm90IHlldCBjb3VudFxuICAgKiB0ZXN0LXJ1biB0ZXJtaW5hdGlvbnMgKGEgYm9va2VkIHJlc2lkdWFsOyB0ZXN0cyBhcmUgYXV0aG9yIGNvZGUgd2l0aCB0aGUgc2FtZSBydW5hd2F5XG4gICAqIHJpc2ssIGJ1dCB0aGUgZmFpbHVyZSBpcyBjb250YWluZWQgdG8gdGhlIHBhbmVsKS5cbiAgICovXG4gIHJ1blRlc3RzKCk6IFByb21pc2U8TWFwPHN0cmluZywgU3ViamVjdFJlc3VsdD4+IHtcbiAgICBjb25zdCBzdWJqZWN0cyA9IFsuLi5uZXcgU2V0KHRoaXMuI3Rlc3RzLm1hcCgodCkgPT4gdC5zdWJqZWN0KSldO1xuICAgIGNvbnN0IHN1aXRlczogU3VpdGVDb250ZXh0W10gPSBzdWJqZWN0cy5tYXAoKHN1YmplY3QpID0+ICh7XG4gICAgICBzdWJqZWN0LFxuICAgICAgc3ViamVjdFZhbHVlOiB0aGlzLiNyZXN1bHRzLmdldChzdWJqZWN0KT8udmFsdWUgPz8gbnVsbCxcbiAgICAgIGlucHV0czogdGhpcy4jaW5wdXRzRm9yKHN1YmplY3QpLFxuICAgICAgLy8gUjMtMzczOiBlYWNoIHRlc3QncyBkZWNsYXJlZCBpbnB1dHMsIHJlc29sdmVkIGhvc3Qtc2lkZSBhZ2FpbnN0IHRoZSBzYW1lXG4gICAgICAvLyBwdWJsaXNoZWQgc3RhdGUgYSBjZWxsJ3MgaW5wdXRzIHJlc29sdmUgYWdhaW5zdC4gTmFtZS1tYXRjaGVkIGVudHJpZXMgYmVjb21lXG4gICAgICAvLyBzdWJzdGl0dXRpb25zOyBuYW1lLXVubWF0Y2hlZCBvbmVzIGFyZSBhdXhpbGlhcnkgY29udGV4dCAob3JhY2xlIGZpeHR1cmVzKS5cbiAgICAgIHRlc3RzOiB0aGlzLiN0ZXN0cy5maWx0ZXIoKHQpID0+IHQuc3ViamVjdCA9PT0gc3ViamVjdCkubWFwKCh0KSA9PiB0aGlzLiNyZXNvbHZlVGVzdElucHV0cyh0KSksXG4gICAgfSkpO1xuICAgIGNvbnN0IHRva2VuID0gKyt0aGlzLiN0b2tlbjtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8TWFwPHN0cmluZywgU3ViamVjdFJlc3VsdD4+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IGNhbmNlbCA9IHRoaXMuI3NldFRpbWVyKCgpID0+IHtcbiAgICAgICAgdGhpcy4jdGVzdHNQZW5kaW5nLmRlbGV0ZSh0b2tlbik7XG4gICAgICAgIHRoaXMuI3RyYW5zcG9ydC5yZXN0YXJ0KCk7XG4gICAgICAgIHZvaWQgdGhpcy4jc2VuZEJ1aWxkKHRoaXMuI3NvdXJjZXMpLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAvKiByZWJ1aWxkIGZhaWx1cmUgc3VyZmFjZXMgb24gdGhlIG5leHQgcGFzcyAqL1xuICAgICAgICB9KTtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcigndGVzdCBydW4gdGltZWQgb3V0ICh3b3JrZXIgcmVzdGFydGVkKScpKTtcbiAgICAgIH0sIHRoaXMuI2J1ZGdldCAqIE1hdGgubWF4KDEsIHN1aXRlcy5sZW5ndGgpKTtcbiAgICAgIHRoaXMuI3Rlc3RzUGVuZGluZy5zZXQodG9rZW4sIHtcbiAgICAgICAgcmVzb2x2ZTogKHIpID0+IHtcbiAgICAgICAgICBjYW5jZWwoKTtcbiAgICAgICAgICByZXNvbHZlKG5ldyBNYXAoci5tYXAoKHMpID0+IFtzLnN1YmplY3QsIHNdKSkpO1xuICAgICAgICB9LFxuICAgICAgICByZWplY3Q6IChlKSA9PiB7XG4gICAgICAgICAgY2FuY2VsKCk7XG4gICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICB0aGlzLiN0cmFuc3BvcnQucG9zdCh7IHR5cGU6ICdydW4tdGVzdHMnLCB0b2tlbiwgc3VpdGVzIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqIFJlc29sdmUgb25lIGNlbGwncyBpbnB1dHMgZnJvbSBjdXJyZW50IHB1Ymxpc2hlZCBzdGF0ZSAodGhlIHJ1bi10ZXN0cyBjb250ZXh0KS4gKi9cbiAgI2lucHV0c0ZvcihpZDogc3RyaW5nKTogUmVjb3JkPHN0cmluZywgVmFsdWU+IHtcbiAgICBjb25zdCBub2RlID0gdGhpcy4jbm9kZXNCeUlkLmdldChpZCk7XG4gICAgaWYgKG5vZGUgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHt9O1xuICAgIHJldHVybiByZXNvbHZlSW5wdXRzKG5vZGUucmVzb2x2ZXJzLCB7XG4gICAgICByZXN1bHRzOiB0aGlzLiNyZXN1bHRzLFxuICAgICAgZXh0ZXJuYWxzOiB0aGlzLiNleHRlcm5hbHMsXG4gICAgICB3b3Jrc2hlZXRzOiB0aGlzLiN3b3Jrc2hlZXRzLFxuICAgIH0pLnZhbHVlcztcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXNvbHZlIG9uZSB0ZXN0J3MgZGVjbGFyZWQgaW5wdXRzIGFnYWluc3QgcHVibGlzaGVkIHN0YXRlIChSMy0zNzMpLiBBbiB1bnJlc29sdmFibGVcbiAgICogcmVmZXJlbmNlIOKAlCB1bmtub3duIGNlbGwvd29ya3NoZWV0IChmcm9tIGByZXNvbHZlcnNGb3JgKSwgb3IgYW4gZXh0ZXJuYWwgdGhlIGRvY3VtZW50XG4gICAqIGhhcyBub3Qgc3VwcGxpZWQgKGFic2VudCBmaXh0dXJlL2ZlZWQvcGFyYW0pIOKAlCBpcyBhIGZhaWxpbmcgdGVzdCBlbnRyeSB3aXRoIGEgbWVzc2FnZSxcbiAgICogbmV2ZXIgYSBzaWxlbnQgYG51bGxgIHN1YnN0aXR1dGlvbi5cbiAgICovXG4gICNyZXNvbHZlVGVzdElucHV0cyh0ZXN0OiBXb3JrYm9va0Rlc2NyaXB0b3JbJ3Rlc3RzJ11bbnVtYmVyXSk6IFRlc3RJbnB1dENvbnRleHQge1xuICAgIGNvbnN0IHsgcmVzb2x2ZXJzLCBkaWFnbm9zdGljcyB9ID0gcmVzb2x2ZXJzRm9yKHRlc3QuaW5wdXRzLCB7XG4gICAgICBub2RlczogdGhpcy4jbm9kZXNCeUlkLFxuICAgICAgd29ya3NoZWV0czogdGhpcy4jd29ya3NoZWV0cyxcbiAgICB9KTtcbiAgICBpZiAoZGlhZ25vc3RpY3MubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIHsgaWQ6IHRlc3QuaWQsIGVycm9yOiBkaWFnbm9zdGljc1swXSB9O1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IHIgb2YgcmVzb2x2ZXJzKSB7XG4gICAgICBpZiAoci5raW5kID09PSAnZXh0ZXJuYWwnICYmICF0aGlzLiNleHRlcm5hbHMuaGFzKHIua2V5KSkge1xuICAgICAgICByZXR1cm4geyBpZDogdGVzdC5pZCwgZXJyb3I6IGB0ZXN0IFwiJHt0ZXN0LmlkfVwiIGlucHV0IFwiJHtyLm5hbWV9XCIgcmVmZXJlbmNlcyBhYnNlbnQgZXh0ZXJuYWwgXCIke3Iua2V5fVwiLmAgfTtcbiAgICAgIH1cbiAgICAgIGlmIChyLmtpbmQgPT09ICd3aW5kb3dlZC1mZWVkJyAmJiAhdGhpcy4jZXh0ZXJuYWxzLmhhcyhgJHtGRUVEX0JVRkZFUl9QUkVGSVh9JHtyLmZlZWR9YCkpIHtcbiAgICAgICAgcmV0dXJuIHsgaWQ6IHRlc3QuaWQsIGVycm9yOiBgdGVzdCBcIiR7dGVzdC5pZH1cIiB3aW5kb3dlZCBpbnB1dCBcIiR7ci5uYW1lfVwiIHJlZmVyZW5jZXMgZmVlZCBcIiR7ci5mZWVkfVwiLCB3aGljaCBoYXMgbm8gcmV0YWluZWQgYnVmZmVyLmAgfTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgeyB2YWx1ZXMgfSA9IHJlc29sdmVJbnB1dHMocmVzb2x2ZXJzLCB7XG4gICAgICByZXN1bHRzOiB0aGlzLiNyZXN1bHRzLFxuICAgICAgZXh0ZXJuYWxzOiB0aGlzLiNleHRlcm5hbHMsXG4gICAgICB3b3Jrc2hlZXRzOiB0aGlzLiN3b3Jrc2hlZXRzLFxuICAgIH0pO1xuICAgIHJldHVybiB7IGlkOiB0ZXN0LmlkLCBpbnB1dHM6IHZhbHVlcyB9O1xuICB9XG5cbiAgc25hcHNob3QoKTogQXN5bmNQYXNzIHtcbiAgICByZXR1cm4geyByZXN1bHRzOiBuZXcgTWFwKHRoaXMuI3Jlc3VsdHMpLCBlcnJvcnM6IG5ldyBNYXAodGhpcy4jZXJyb3JzKSwgcXVhcmFudGluZWQ6IHRoaXMuI2JyZWFrZXIucXVhcmFudGluZWQoKSB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEEgY29oZXJlbnQgc2V0dGxlZCBiYXNlbGluZSBmb3Igc2hhZG93IGV2YWx1YXRpb24gKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMi4xLFxuICAgKiBHLVdJRi0zKTogYXdhaXRzIHF1aWVzY2VuY2UgKG5vIHBhc3MgaW4gZmxpZ2h0LCBub3RoaW5nIHBlbmRpbmcg4oCUIGJvdW5kZWQgYnkgc2luZ2xlLXNsb3RcbiAgICogc3VwZXJzZXNzaW9uKSwgdGhlbiByZXR1cm5zIHRoZSBzZXR0bGVkIHBhc3MgKiphbmQqKiB0aGUgZXh0ZXJuYWxzIHRoYXQgcHJvZHVjZWQgaXQgYXNcbiAgICogb25lIHBhaXIuIFRoZSBleHRlcm5hbHMgYXJlICoqZGVlcCBjb3BpZXMqKiAoc3RydWN0dXJlZCBjbG9uZTsgZXZlcnkgZXh0ZXJuYWwgY3Jvc3NlZCB0aGVcbiAgICogd29ya2VyIGJvdW5kYXJ5LCBzbyBjbG9uYWJpbGl0eSBob2xkcyBieSBjb25zdHJ1Y3Rpb24pIOKAlCBhIGNvcnJlY3RuZXNzIHJlcXVpcmVtZW50IG9uIHRoZVxuICAgKiBpbi1wcm9jZXNzIHRyYW5zcG9ydCwgd2hlcmUgaGFuZGluZyBvdXQgbGl2ZSByZWZlcmVuY2VzIHdvdWxkIGxldCBhIHNoYWRvdyBmb3JtdWxhIG11dGF0ZVxuICAgKiB0aGUgYmFzZSBzZXNzaW9uJ3MgaW5wdXRzLlxuICAgKi9cbiAgYXN5bmMgc2V0dGxlZFNuYXBzaG90KCk6IFByb21pc2U8eyBwYXNzOiBBc3luY1Bhc3M7IGV4dGVybmFsczogUmVjb3JkPHN0cmluZywgRXh0ZXJuYWxWYWx1ZT4gfT4ge1xuICAgIHdoaWxlICh0aGlzLiNydW5uaW5nIHx8IHRoaXMuI3BlbmRpbmdFeHRlcm5hbHMgIT09IG51bGwpIHtcbiAgICAgIGlmICghdGhpcy4jcnVubmluZykge1xuICAgICAgICAvLyBQZW5kaW5nLWJ1dC1pZGxlIGlzIHVucmVhY2hhYmxlIHZpYSBydW4oKS91cGRhdGUoKSAoYm90aCBkcml2ZSBzeW5jaHJvbm91c2x5KSxcbiAgICAgICAgLy8gYnV0IGEgY2FsbGVyIHJhY2luZyB0aGUgbWljcm90YXNrIGdhcCBsYW5kcyBoZXJlIOKAlCBkcml2ZSByYXRoZXIgdGhhbiBzcGluLlxuICAgICAgICBhd2FpdCB0aGlzLiNkcml2ZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgdGhpcy4jcnVubmluZ1Byb21pc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGV4dGVybmFsczogUmVjb3JkPHN0cmluZywgRXh0ZXJuYWxWYWx1ZT4gPSB7fTtcbiAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiB0aGlzLiNleHRlcm5hbHMpIHtcbiAgICAgIGV4dGVybmFsc1trXSA9IHN0cnVjdHVyZWRDbG9uZSh7IHZhbHVlOiB2LnZhbHVlLCB0aWVyOiB2LnRpZXIgfSk7XG4gICAgfVxuICAgIHJldHVybiB7IHBhc3M6IHRoaXMuc25hcHNob3QoKSwgZXh0ZXJuYWxzIH07XG4gIH1cblxuICAvLyAtLS0gaW50ZXJuYWxzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgI2VtcHR5UGFzcygpOiBBc3luY1Bhc3Mge1xuICAgIHJldHVybiB7IHJlc3VsdHM6IG5ldyBNYXAoKSwgZXJyb3JzOiBuZXcgTWFwKCksIHF1YXJhbnRpbmVkOiBbXSB9O1xuICB9XG5cbiAgI2FwcGx5RGVzY3JpcHRvcihkOiBXb3JrYm9va0Rlc2NyaXB0b3IpOiB2b2lkIHtcbiAgICB0aGlzLiNvcmRlciA9IGQub3JkZXI7XG4gICAgdGhpcy4jY3ljbGVzID0gZC5jeWNsZXM7XG4gICAgdGhpcy4jbm9kZXNCeUlkID0gbmV3IE1hcChkLmNlbGxzLm1hcCgoYykgPT4gW2MuaWQsIGNdKSk7XG4gICAgdGhpcy4jd29ya3NoZWV0cyA9IG5ldyBNYXAoZC53b3Jrc2hlZXRzKTtcbiAgICB0aGlzLiN0ZXN0cyA9IGQudGVzdHM7XG4gIH1cblxuICAjb25NZXNzYWdlKG1zZzogV29ya2VyUmVzcG9uc2UpOiB2b2lkIHtcbiAgICBpZiAobXNnLnR5cGUgPT09ICdidWlsdCcpIHtcbiAgICAgIHRoaXMuI2J1aWxkUmVzb2x2ZT8uKG1zZy5kZXNjcmlwdG9yKTtcbiAgICAgIHRoaXMuI2J1aWxkUmVzb2x2ZSA9IHRoaXMuI2J1aWxkUmVqZWN0ID0gbnVsbDtcbiAgICB9IGVsc2UgaWYgKG1zZy50eXBlID09PSAnYnVpbGQtZXJyb3InKSB7XG4gICAgICB0aGlzLiNidWlsZFJlamVjdD8uKG5ldyBFcnJvcihtc2cubWVzc2FnZSkpO1xuICAgICAgdGhpcy4jYnVpbGRSZXNvbHZlID0gdGhpcy4jYnVpbGRSZWplY3QgPSBudWxsO1xuICAgIH0gZWxzZSBpZiAobXNnLnR5cGUgPT09ICd0ZXN0LXJlc3VsdHMnKSB7XG4gICAgICBjb25zdCBwID0gdGhpcy4jdGVzdHNQZW5kaW5nLmdldChtc2cudG9rZW4pO1xuICAgICAgaWYgKHAgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICAgICAgdGhpcy4jdGVzdHNQZW5kaW5nLmRlbGV0ZShtc2cudG9rZW4pO1xuICAgICAgcC5yZXNvbHZlKG1zZy5zdWl0ZXMpO1xuICAgIH0gZWxzZSBpZiAobXNnLnR5cGUgPT09ICdldmFsLWVycm9yJykge1xuICAgICAgLy8gQW4gZXZhbC1lcnJvciBjYW4gY2FycnkgYSBydW4tdGVzdHMgdG9rZW4gKHN1aXRlIG1hY2hpbmVyeSB0aHJldyB3b3JrZXItc2lkZSkuXG4gICAgICBjb25zdCB0ID0gdGhpcy4jdGVzdHNQZW5kaW5nLmdldChtc2cudG9rZW4pO1xuICAgICAgaWYgKHQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLiN0ZXN0c1BlbmRpbmcuZGVsZXRlKG1zZy50b2tlbik7XG4gICAgICAgIHQucmVqZWN0KG5ldyBFcnJvcihtc2cubWVzc2FnZSkpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBwID0gdGhpcy4jcGVuZGluZy5nZXQobXNnLnRva2VuKTtcbiAgICAgIGlmIChwICE9PSB1bmRlZmluZWQpIHAucmVqZWN0KG5ldyBFcnJvcihtc2cubWVzc2FnZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBwID0gdGhpcy4jcGVuZGluZy5nZXQobXNnLnRva2VuKTtcbiAgICAgIGlmIChwID09PSB1bmRlZmluZWQpIHJldHVybjsgLy8gc3VwZXJzZWRlZCAvIGFiYW5kb25lZCBhZnRlciBhIHJlc3RhcnRcbiAgICAgIHAucmVzb2x2ZShtc2cudmFsdWUpO1xuICAgIH1cbiAgfVxuXG4gICNzZW5kQnVpbGQoc291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IFByb21pc2U8V29ya2Jvb2tEZXNjcmlwdG9yPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFdvcmtib29rRGVzY3JpcHRvcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy4jYnVpbGRSZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgIHRoaXMuI2J1aWxkUmVqZWN0ID0gcmVqZWN0O1xuICAgICAgdGhpcy4jdHJhbnNwb3J0LnBvc3QoeyB0eXBlOiAnYnVpbGQnLCBzb3VyY2VzIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgI2RyaXZlKCk6IFByb21pc2U8QXN5bmNQYXNzPiB7XG4gICAgaWYgKCF0aGlzLiNydW5uaW5nKSB7XG4gICAgICB0aGlzLiNydW5uaW5nID0gdHJ1ZTtcbiAgICAgIHRoaXMuI3J1bm5pbmdQcm9taXNlID0gdGhpcy4jbG9vcCgpLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICB0aGlzLiNydW5uaW5nID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3J1bm5pbmdQcm9taXNlO1xuICB9XG5cbiAgYXN5bmMgI2xvb3AoKTogUHJvbWlzZTxBc3luY1Bhc3M+IHtcbiAgICBsZXQgbGFzdCA9IHRoaXMuI2VtcHR5UGFzcygpO1xuICAgIHdoaWxlICh0aGlzLiNwZW5kaW5nRXh0ZXJuYWxzICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBleHRlcm5hbHMgPSB0aGlzLiNwZW5kaW5nRXh0ZXJuYWxzO1xuICAgICAgdGhpcy4jcGVuZGluZ0V4dGVybmFscyA9IG51bGw7XG4gICAgICBsYXN0ID0gYXdhaXQgdGhpcy4jcGFzcyhleHRlcm5hbHMpO1xuICAgIH1cbiAgICByZXR1cm4gbGFzdDtcbiAgfVxuXG4gIGFzeW5jICNwYXNzKGV4dGVybmFsczogTWFwPHN0cmluZywgeyB2YWx1ZTogVmFsdWU7IHRpZXI6IEV4dGVybmFsVmFsdWVbJ3RpZXInXSB9Pik6IFByb21pc2U8QXN5bmNQYXNzPiB7XG4gICAgdGhpcy4jZXh0ZXJuYWxzID0gZXh0ZXJuYWxzO1xuICAgIHRoaXMuI3Jlc3VsdHMgPSBuZXcgTWFwKCk7XG4gICAgdGhpcy4jZXJyb3JzID0gbmV3IE1hcCgpO1xuXG4gICAgaWYgKHRoaXMuI2N5Y2xlcy5sZW5ndGggPiAwKSB7XG4gICAgICAvLyBBIGN5Y2xpYyB3b3JrYm9vayBpcyB1bnJ1bm5hYmxlIOKAlCBhbmQgY3ljbGljIG5vZGVzIGFyZSBleGNsdWRlZCBmcm9tIHRoZSB0b3BvIGBvcmRlcmAsXG4gICAgICAvLyBzbyBlcnJvciAqZXZlcnkqIGNlbGwsIG5vdCBqdXN0IHRoZSBvcmRlcmFibGUgb25lcy5cbiAgICAgIGNvbnN0IHBhdGggPSB0aGlzLiNjeWNsZXMubWFwKChjKSA9PiBjLmpvaW4oJyDihpIgJykpLmpvaW4oJzsgJyk7XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIHRoaXMuI25vZGVzQnlJZC5rZXlzKCkpIHRoaXMuI2Vycm9ycy5zZXQoaWQsIGBkZXBlbmRlbmN5IGN5Y2xlOiAke3BhdGh9YCk7XG4gICAgICByZXR1cm4gdGhpcy4jc2V0dGxlKCk7XG4gICAgfVxuXG4gICAgZm9yIChjb25zdCBpZCBvZiB0aGlzLiNvcmRlcikge1xuICAgICAgY29uc3Qgbm9kZSA9IHRoaXMuI25vZGVzQnlJZC5nZXQoaWQpO1xuICAgICAgaWYgKG5vZGUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG5cbiAgICAgIGlmICh0aGlzLiNicmVha2VyLmlzQmxvY2tlZChpZCwgdGhpcy4jbm93KCkpKSB7XG4gICAgICAgIHRoaXMuI2Vycm9ycy5zZXQoaWQsICdxdWFyYW50aW5lZCAoY2lyY3VpdCBicmVha2VyKScpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGVycm9yZWREZXAgPSBub2RlLmRlcHMuZmluZCgoZCkgPT4gdGhpcy4jZXJyb3JzLmhhcyhkKSk7XG4gICAgICBpZiAoZXJyb3JlZERlcCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuI2Vycm9ycy5zZXQoaWQsIGBpbnB1dCBcIiR7ZXJyb3JlZERlcH1cIiBlcnJvcmVkYCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB7IHZhbHVlcywgdGllcnMgfSA9IHJlc29sdmVJbnB1dHMobm9kZS5yZXNvbHZlcnMsIHtcbiAgICAgICAgcmVzdWx0czogdGhpcy4jcmVzdWx0cyxcbiAgICAgICAgZXh0ZXJuYWxzOiB0aGlzLiNleHRlcm5hbHMsXG4gICAgICAgIHdvcmtzaGVldHM6IHRoaXMuI3dvcmtzaGVldHMsXG4gICAgICB9KTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCB0aGlzLiNldmFsV2l0aFdhdGNoZG9nKGlkLCB2YWx1ZXMpO1xuICAgICAgICB0aGlzLiNwdWJsaXNoKGlkLCB2YWx1ZSwgbWVldFRpZXJzKHRpZXJzKSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgVGltZW91dEVycm9yKSB7XG4gICAgICAgICAgLy8gSGFyZCBydW5hd2F5OiBraWxsIHRoZSB3ZWRnZWQgd29ya2VyLCByZWJ1aWxkIGl0LCBhbmQgY291bnQgdG93YXJkIHRoZSBicmVha2VyLlxuICAgICAgICAgIHRoaXMuI3RyYW5zcG9ydC5yZXN0YXJ0KCk7XG4gICAgICAgICAgdGhpcy4jYnJlYWtlci5oYXJkVGVybWluYXRpb24oaWQsIHRoaXMuI25vdygpKTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy4jc2VuZEJ1aWxkKHRoaXMuI3NvdXJjZXMpO1xuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLyogcmVidWlsZCBmYWlsdXJlIHN1cmZhY2VzIG9uIHRoZSBuZXh0IHBhc3M7IHRoaXMgY2VsbCBpcyBhbHJlYWR5IGVycm9yZWQgKi9cbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy4jZXJyb3JzLnNldChpZCwgJ2V2YWx1YXRpb24gdGltZWQgb3V0ICh0ZXJtaW5hdGVkKScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIEZvcm11bGEgdGhyZXcg4oCUIGEgZGV0ZXJtaW5pc3RpYyBsYXR0aWNlIGVycm9yLCBub3QgYSBydW5hd2F5ICh3b3JrZXIgaXMgZmluZSkuXG4gICAgICAgICAgdGhpcy4jZXJyb3JzLnNldChpZCwgKGUgYXMgRXJyb3IpLm1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLiNzZXR0bGUoKTtcbiAgfVxuXG4gIC8qKiBTbmFwc2hvdCB0aGUgc2V0dGxlZCBwYXNzIGFuZCBub3RpZnkgdGhlIG9ic2VydmVyIChldmVyeSBwYXNzLCBub3QganVzdCB0aGUgY29hbGVzY2VkIGxhc3QpLiAqL1xuICAjc2V0dGxlKCk6IEFzeW5jUGFzcyB7XG4gICAgY29uc3QgcGFzcyA9IHRoaXMuc25hcHNob3QoKTtcbiAgICB0aGlzLiNvblBhc3MocGFzcyk7XG4gICAgcmV0dXJuIHBhc3M7XG4gIH1cblxuICAjZXZhbFdpdGhXYXRjaGRvZyhpZDogc3RyaW5nLCBpbnB1dHM6IFJlY29yZDxzdHJpbmcsIFZhbHVlPik6IFByb21pc2U8VmFsdWU+IHtcbiAgICBjb25zdCB0b2tlbiA9ICsrdGhpcy4jdG9rZW47XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFZhbHVlPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBsZXQgY2FuY2VsID0gKCk6IHZvaWQgPT4ge307XG4gICAgICBjb25zdCBzZXR0bGUgPSA8VD4oZm46IChhcmc6IFQpID0+IHZvaWQpID0+IChhcmc6IFQpOiB2b2lkID0+IHtcbiAgICAgICAgY2FuY2VsKCk7XG4gICAgICAgIHRoaXMuI3BlbmRpbmcuZGVsZXRlKHRva2VuKTtcbiAgICAgICAgZm4oYXJnKTtcbiAgICAgIH07XG4gICAgICB0aGlzLiNwZW5kaW5nLnNldCh0b2tlbiwgeyByZXNvbHZlOiBzZXR0bGUocmVzb2x2ZSksIHJlamVjdDogc2V0dGxlKHJlamVjdCkgfSk7XG4gICAgICBjYW5jZWwgPSB0aGlzLiNzZXRUaW1lcigoKSA9PiB7XG4gICAgICAgIHRoaXMuI3BlbmRpbmcuZGVsZXRlKHRva2VuKTtcbiAgICAgICAgcmVqZWN0KG5ldyBUaW1lb3V0RXJyb3IoaWQpKTtcbiAgICAgIH0sIHRoaXMuI2J1ZGdldCk7XG4gICAgICB0aGlzLiN0cmFuc3BvcnQucG9zdCh7IHR5cGU6ICdldmFsJywgaWQsIHRva2VuLCBpbnB1dHMgfSk7XG4gICAgfSk7XG4gIH1cblxuICAjcHVibGlzaChpZDogc3RyaW5nLCB2YWx1ZTogVmFsdWUsIHRpZXI6IEV4dGVybmFsVmFsdWVbJ3RpZXInXSk6IHZvaWQge1xuICAgIHRoaXMuI3Jlc3VsdHMuc2V0KGlkLCB7IGlkLCB2YWx1ZSwgdGllciwga2V5OiBjb250ZW50S2V5KHZhbHVlKSB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiB0b01hcChleHRlcm5hbHM6IFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+KTogTWFwPHN0cmluZywgeyB2YWx1ZTogVmFsdWU7IHRpZXI6IEV4dGVybmFsVmFsdWVbJ3RpZXInXSB9PiB7XG4gIHJldHVybiBuZXcgTWFwKE9iamVjdC5lbnRyaWVzKGV4dGVybmFscykubWFwKChbaywgdl0pID0+IFtrLCB7IHZhbHVlOiB2LnZhbHVlLCB0aWVyOiB2LnRpZXIgfV0pKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBOEJBLElBQUFBLEtBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEtBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE1BQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGVBQUEsR0FBQUosT0FBQTtBQWxDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBcUJPLE1BQU1LLFlBQVksU0FBU0MsS0FBSyxDQUFDO0VBQ3RDQyxXQUFXQSxDQUFDQyxFQUFVLEVBQUU7SUFDdEIsS0FBSyxDQUFDLGtCQUFrQkEsRUFBRSx1QkFBdUIsQ0FBQztJQUNsRCxJQUFJLENBQUNDLElBQUksR0FBRyxjQUFjO0VBQzVCO0FBQ0Y7O0FBbUJBO0FBQUFDLE9BQUEsQ0FBQUwsWUFBQSxHQUFBQSxZQUFBO0FBWUEsTUFBTU0sWUFBWSxHQUFHQSxDQUFDQyxFQUFjLEVBQUVDLEVBQVUsS0FBbUI7RUFDakUsTUFBTUMsQ0FBQyxHQUFHQyxVQUFVLENBQUNILEVBQUUsRUFBRUMsRUFBRSxDQUFDO0VBQzVCLE9BQU8sTUFBTUcsWUFBWSxDQUFDRixDQUFDLENBQUM7QUFDOUIsQ0FBQztBQUVNLE1BQU1HLFdBQVcsQ0FBQztFQUNkLENBQUNDLFNBQVM7RUFDVixDQUFDQyxNQUFNO0VBQ1AsQ0FBQ0MsT0FBTztFQUNSLENBQUNDLEdBQUc7RUFDSixDQUFDQyxRQUFRO0VBQ1QsQ0FBQ0MsTUFBTTtFQUVoQixDQUFDQyxPQUFPLEdBQTJCLENBQUMsQ0FBQztFQUNyQyxDQUFDQyxLQUFLLEdBQWEsRUFBRTtFQUNyQixDQUFDQyxNQUFNLEdBQWUsRUFBRTtFQUN4QixDQUFDQyxTQUFTLEdBQUcsSUFBSUMsR0FBRyxDQUF5QixDQUFDO0VBQzlDLENBQUNDLFVBQVUsR0FBRyxJQUFJRCxHQUFHLENBQW1CLENBQUM7RUFFekMsQ0FBQ0UsT0FBTyxHQUFHLElBQUlGLEdBQUcsQ0FBMEIsQ0FBQztFQUM3QyxDQUFDRyxNQUFNLEdBQUcsSUFBSUgsR0FBRyxDQUFpQixDQUFDO0VBQ25DLENBQUNJLFNBQVMsR0FBRyxJQUFJSixHQUFHLENBQXdELENBQUM7RUFDN0UsQ0FBQ0ssS0FBSyxHQUFnQyxFQUFFO0VBRXhDLENBQUNDLE9BQU8sR0FBRyxJQUFJTixHQUFHLENBQXNCLENBQUM7RUFDekMsQ0FBQ08sS0FBSyxHQUFHLENBQUM7RUFDVixDQUFDQyxZQUFZLEdBQTZDLElBQUk7RUFDOUQsQ0FBQ0MsV0FBVyxHQUFnQyxJQUFJO0VBQ2hELENBQUNDLFlBQVksR0FBRyxJQUFJVixHQUFHLENBQWdGLENBQUM7O0VBRXhHO0VBQ0EsQ0FBQ1csT0FBTyxHQUFHLEtBQUs7RUFDaEIsQ0FBQ0MsY0FBYyxHQUF1QkMsT0FBTyxDQUFDQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUNDLFNBQVMsQ0FBQyxDQUFDLENBQUM7RUFDeEUsQ0FBQ0MsZ0JBQWdCLEdBQXNFLElBQUk7RUFFM0ZyQyxXQUFXQSxDQUFDc0MsSUFBd0IsRUFBRTtJQUNwQyxJQUFJLENBQUMsQ0FBQzNCLFNBQVMsR0FBRzJCLElBQUksQ0FBQzNCLFNBQVM7SUFDaEMsSUFBSSxDQUFDLENBQUNDLE1BQU0sR0FBRzBCLElBQUksQ0FBQ0MsWUFBWSxJQUFJLElBQUk7SUFDeEMsSUFBSSxDQUFDLENBQUMxQixPQUFPLEdBQUcsSUFBSTJCLDhCQUFjLENBQUNGLElBQUksQ0FBQ3pCLE9BQU8sSUFBSTRCLCtCQUFlLENBQUM7SUFDbkUsSUFBSSxDQUFDLENBQUMzQixHQUFHLEdBQUd3QixJQUFJLENBQUN4QixHQUFHLEtBQUssTUFBTTRCLElBQUksQ0FBQzVCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDMUMsSUFBSSxDQUFDLENBQUNDLFFBQVEsR0FBR3VCLElBQUksQ0FBQ3ZCLFFBQVEsSUFBSVgsWUFBWTtJQUM5QyxJQUFJLENBQUMsQ0FBQ1ksTUFBTSxHQUFHc0IsSUFBSSxDQUFDdEIsTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDeEMsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQ2dDLFNBQVMsQ0FBRUMsR0FBRyxJQUFLLElBQUksQ0FBQyxDQUFDRCxTQUFTLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0VBQzFEOztFQUVBO0VBQ0EsYUFBYUMsV0FBV0EsQ0FBQzVCLE9BQStCLEVBQUVxQixJQUFxQyxFQUF3QjtJQUNySCxNQUFNUSxNQUFNLEdBQUcsSUFBSXBDLFdBQVcsQ0FBQzRCLElBQUksQ0FBQztJQUNwQyxNQUFNUSxNQUFNLENBQUNDLEtBQUssQ0FBQzlCLE9BQU8sQ0FBQztJQUMzQixPQUFPNkIsTUFBTTtFQUNmOztFQUVBO0VBQ0EsTUFBTUMsS0FBS0EsQ0FBQzlCLE9BQStCLEVBQWlCO0lBQzFELElBQUksQ0FBQyxDQUFDQSxPQUFPLEdBQUdBLE9BQU87SUFDdkIsSUFBSSxDQUFDLENBQUMrQixlQUFlLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQ0MsU0FBUyxDQUFDaEMsT0FBTyxDQUFDLENBQUM7RUFDdkQ7O0VBRUE7RUFDQWlDLEdBQUdBLENBQUN6QixTQUF3QyxFQUFzQjtJQUNoRSxJQUFJLENBQUMsQ0FBQ1ksZ0JBQWdCLEdBQUdjLEtBQUssQ0FBQzFCLFNBQVMsQ0FBQztJQUN6QyxPQUFPLElBQUksQ0FBQyxDQUFDMkIsS0FBSyxDQUFDLENBQUM7RUFDdEI7O0VBRUE7RUFDQUMsTUFBTUEsQ0FBQ0MsS0FBb0MsRUFBc0I7SUFDL0QsTUFBTUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDbEIsZ0JBQWdCLElBQUksSUFBSSxDQUFDLENBQUNaLFNBQVM7SUFDdEQsTUFBTStCLE1BQU0sR0FBRyxJQUFJbkMsR0FBRyxDQUFDa0MsSUFBSSxDQUFDO0lBQzVCLEtBQUssTUFBTSxDQUFDRSxDQUFDLEVBQUVDLENBQUMsQ0FBQyxJQUFJQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ04sS0FBSyxDQUFDLEVBQUVFLE1BQU0sQ0FBQ0ssR0FBRyxDQUFDSixDQUFDLEVBQUU7TUFBRUssS0FBSyxFQUFFSixDQUFDLENBQUNJLEtBQUs7TUFBRUMsSUFBSSxFQUFFTCxDQUFDLENBQUNLO0lBQUssQ0FBQyxDQUFDO0lBQzNGLElBQUksQ0FBQyxDQUFDMUIsZ0JBQWdCLEdBQUdtQixNQUFNO0lBQy9CLE9BQU8sSUFBSSxDQUFDLENBQUNKLEtBQUssQ0FBQyxDQUFDO0VBQ3RCOztFQUVBO0VBQ0FZLE1BQU1BLENBQUMvRCxFQUFVLEVBQStCO0lBQzlDLE9BQU8sSUFBSSxDQUFDLENBQUNzQixPQUFPLENBQUMwQyxHQUFHLENBQUNoRSxFQUFFLENBQUM7RUFDOUI7O0VBRUE7RUFDQWlFLEtBQUtBLENBQUNqRSxFQUFVLEVBQXNCO0lBQ3BDLE9BQU8sSUFBSSxDQUFDLENBQUN1QixNQUFNLENBQUN5QyxHQUFHLENBQUNoRSxFQUFFLENBQUM7RUFDN0I7RUFFQTZELEtBQUtBLENBQUM3RCxFQUFVLEVBQXFCO0lBQ25DLE9BQU8sSUFBSSxDQUFDLENBQUNzQixPQUFPLENBQUMwQyxHQUFHLENBQUNoRSxFQUFFLENBQUMsRUFBRTZELEtBQUs7RUFDckM7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFSyxrQkFBa0JBLENBQUEsRUFBb0M7SUFDcEQsTUFBTUMsR0FBb0MsR0FBRyxFQUFFO0lBQy9DLEtBQUssTUFBTUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDakQsU0FBUyxDQUFDa0QsTUFBTSxDQUFDLENBQUMsRUFBRTtNQUMzQyxLQUFLLE1BQU1DLEdBQUcsSUFBSUYsSUFBSSxDQUFDNUMsU0FBUyxFQUFFMkMsR0FBRyxDQUFDSSxJQUFJLENBQUM7UUFBRUQsR0FBRztRQUFFRSxJQUFJLEVBQUVKLElBQUksQ0FBQ3BFO01BQUcsQ0FBQyxDQUFDO0lBQ3BFO0lBQ0EsT0FBT21FLEdBQUc7RUFDWjs7RUFFQTtFQUNBTSxLQUFLQSxDQUFDekUsRUFBVSxFQUFRO0lBQ3RCLElBQUksQ0FBQyxDQUFDWSxPQUFPLENBQUM2RCxLQUFLLENBQUN6RSxFQUFFLENBQUM7RUFDekI7O0VBRUE7RUFDQTBFLEtBQUtBLENBQUEsRUFBOEI7SUFDakMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUN2RCxTQUFTLENBQUNrRCxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3RDOztFQUVBO0VBQ0E1QyxLQUFLQSxDQUFBLEVBQThCO0lBQ2pDLE9BQU8sSUFBSSxDQUFDLENBQUNBLEtBQUs7RUFDcEI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VrRCxRQUFRQSxDQUFBLEVBQXdDO0lBQzlDLE1BQU1DLFFBQVEsR0FBRyxDQUFDLEdBQUcsSUFBSUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDcEQsS0FBSyxDQUFDcUQsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNoRSxNQUFNQyxNQUFzQixHQUFHTCxRQUFRLENBQUNFLEdBQUcsQ0FBRUUsT0FBTyxLQUFNO01BQ3hEQSxPQUFPO01BQ1BFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzVELE9BQU8sQ0FBQzBDLEdBQUcsQ0FBQ2dCLE9BQU8sQ0FBQyxFQUFFbkIsS0FBSyxJQUFJLElBQUk7TUFDdkRzQixNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUNDLFNBQVMsQ0FBQ0osT0FBTyxDQUFDO01BQ2hDO01BQ0E7TUFDQTtNQUNBdkQsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDQSxLQUFLLENBQUM0RCxNQUFNLENBQUVOLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxPQUFPLEtBQUtBLE9BQU8sQ0FBQyxDQUFDRixHQUFHLENBQUVDLENBQUMsSUFBSyxJQUFJLENBQUMsQ0FBQ08saUJBQWlCLENBQUNQLENBQUMsQ0FBQztJQUMvRixDQUFDLENBQUMsQ0FBQztJQUNILE1BQU1wRCxLQUFLLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQ0EsS0FBSztJQUMzQixPQUFPLElBQUlNLE9BQU8sQ0FBNkIsQ0FBQ0MsT0FBTyxFQUFFcUQsTUFBTSxLQUFLO01BQ2xFLE1BQU1DLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQzFFLFFBQVEsQ0FBQyxNQUFNO1FBQ2xDLElBQUksQ0FBQyxDQUFDZ0IsWUFBWSxDQUFDMkQsTUFBTSxDQUFDOUQsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxDQUFDakIsU0FBUyxDQUFDZ0YsT0FBTyxDQUFDLENBQUM7UUFDekIsS0FBSyxJQUFJLENBQUMsQ0FBQzFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQ2hDLE9BQU8sQ0FBQyxDQUFDMkUsS0FBSyxDQUFDLE1BQU07VUFDOUM7UUFBQSxDQUNELENBQUM7UUFDRkosTUFBTSxDQUFDLElBQUl6RixLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQztNQUM1RCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUNhLE1BQU0sR0FBR2lGLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRVosTUFBTSxDQUFDYSxNQUFNLENBQUMsQ0FBQztNQUM3QyxJQUFJLENBQUMsQ0FBQ2hFLFlBQVksQ0FBQzhCLEdBQUcsQ0FBQ2pDLEtBQUssRUFBRTtRQUM1Qk8sT0FBTyxFQUFHNkQsQ0FBQyxJQUFLO1VBQ2RQLE1BQU0sQ0FBQyxDQUFDO1VBQ1J0RCxPQUFPLENBQUMsSUFBSWQsR0FBRyxDQUFDMkUsQ0FBQyxDQUFDakIsR0FBRyxDQUFFa0IsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ2hCLE9BQU8sRUFBRWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBQ0RULE1BQU0sRUFBR1UsQ0FBQyxJQUFLO1VBQ2JULE1BQU0sQ0FBQyxDQUFDO1VBQ1JELE1BQU0sQ0FBQ1UsQ0FBQyxDQUFDO1FBQ1g7TUFDRixDQUFDLENBQUM7TUFDRixJQUFJLENBQUMsQ0FBQ3ZGLFNBQVMsQ0FBQ3dGLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUUsV0FBVztRQUFFeEUsS0FBSztRQUFFc0Q7TUFBTyxDQUFDLENBQUM7SUFDNUQsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQSxDQUFDRyxTQUFTZ0IsQ0FBQ3BHLEVBQVUsRUFBeUI7SUFDNUMsTUFBTW9FLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQ2pELFNBQVMsQ0FBQzZDLEdBQUcsQ0FBQ2hFLEVBQUUsQ0FBQztJQUNwQyxJQUFJb0UsSUFBSSxLQUFLaUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2pDLE9BQU8sSUFBQUMsc0JBQWEsRUFBQ2xDLElBQUksQ0FBQ21DLFNBQVMsRUFBRTtNQUNuQ2pGLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQ0EsT0FBTztNQUN0QkUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDQSxTQUFTO01BQzFCSCxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUNBO0lBQ3BCLENBQUMsQ0FBQyxDQUFDZ0QsTUFBTTtFQUNYOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLENBQUNpQixpQkFBaUJrQixDQUFDQyxJQUF5QyxFQUFvQjtJQUM5RSxNQUFNO01BQUVGLFNBQVM7TUFBRUc7SUFBWSxDQUFDLEdBQUcsSUFBQUMsbUJBQVksRUFBQ0YsSUFBSSxDQUFDdEIsTUFBTSxFQUFFO01BQzNEeUIsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDekYsU0FBUztNQUN0QkUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDQTtJQUNwQixDQUFDLENBQUM7SUFDRixJQUFJcUYsV0FBVyxDQUFDWixNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQzFCLE9BQU87UUFBRTlGLEVBQUUsRUFBRXlHLElBQUksQ0FBQ3pHLEVBQUU7UUFBRWlFLEtBQUssRUFBRXlDLFdBQVcsQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUMvQztJQUNBLEtBQUssTUFBTVgsQ0FBQyxJQUFJUSxTQUFTLEVBQUU7TUFDekIsSUFBSVIsQ0FBQyxDQUFDYyxJQUFJLEtBQUssVUFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUNyRixTQUFTLENBQUNzRixHQUFHLENBQUNmLENBQUMsQ0FBQ3pCLEdBQUcsQ0FBQyxFQUFFO1FBQ3hELE9BQU87VUFBRXRFLEVBQUUsRUFBRXlHLElBQUksQ0FBQ3pHLEVBQUU7VUFBRWlFLEtBQUssRUFBRSxTQUFTd0MsSUFBSSxDQUFDekcsRUFBRSxZQUFZK0YsQ0FBQyxDQUFDOUYsSUFBSSxpQ0FBaUM4RixDQUFDLENBQUN6QixHQUFHO1FBQUssQ0FBQztNQUM3RztNQUNBLElBQUl5QixDQUFDLENBQUNjLElBQUksS0FBSyxlQUFlLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQ3JGLFNBQVMsQ0FBQ3NGLEdBQUcsQ0FBQyxHQUFHQywyQkFBa0IsR0FBR2hCLENBQUMsQ0FBQ2lCLElBQUksRUFBRSxDQUFDLEVBQUU7UUFDeEYsT0FBTztVQUFFaEgsRUFBRSxFQUFFeUcsSUFBSSxDQUFDekcsRUFBRTtVQUFFaUUsS0FBSyxFQUFFLFNBQVN3QyxJQUFJLENBQUN6RyxFQUFFLHFCQUFxQitGLENBQUMsQ0FBQzlGLElBQUksc0JBQXNCOEYsQ0FBQyxDQUFDaUIsSUFBSTtRQUFtQyxDQUFDO01BQzFJO0lBQ0Y7SUFDQSxNQUFNO01BQUUzQztJQUFPLENBQUMsR0FBRyxJQUFBaUMsc0JBQWEsRUFBQ0MsU0FBUyxFQUFFO01BQzFDakYsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDQSxPQUFPO01BQ3RCRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUNBLFNBQVM7TUFDMUJILFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQ0E7SUFDcEIsQ0FBQyxDQUFDO0lBQ0YsT0FBTztNQUFFckIsRUFBRSxFQUFFeUcsSUFBSSxDQUFDekcsRUFBRTtNQUFFbUYsTUFBTSxFQUFFZDtJQUFPLENBQUM7RUFDeEM7RUFFQTRDLFFBQVFBLENBQUEsRUFBYztJQUNwQixPQUFPO01BQUUzRixPQUFPLEVBQUUsSUFBSUYsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDRSxPQUFPLENBQUM7TUFBRUMsTUFBTSxFQUFFLElBQUlILEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQ0csTUFBTSxDQUFDO01BQUUyRixXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUN0RyxPQUFPLENBQUNzRyxXQUFXLENBQUM7SUFBRSxDQUFDO0VBQ3JIOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1DLGVBQWVBLENBQUEsRUFBMkU7SUFDOUYsT0FBTyxJQUFJLENBQUMsQ0FBQ3BGLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQ0ssZ0JBQWdCLEtBQUssSUFBSSxFQUFFO01BQ3ZELElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQ0wsT0FBTyxFQUFFO1FBQ2xCO1FBQ0E7UUFDQSxNQUFNLElBQUksQ0FBQyxDQUFDb0IsS0FBSyxDQUFDLENBQUM7TUFDckIsQ0FBQyxNQUFNO1FBQ0wsTUFBTSxJQUFJLENBQUMsQ0FBQ25CLGNBQWM7TUFDNUI7SUFDRjtJQUNBLE1BQU1SLFNBQXdDLEdBQUcsQ0FBQyxDQUFDO0lBQ25ELEtBQUssTUFBTSxDQUFDZ0MsQ0FBQyxFQUFFQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQ2pDLFNBQVMsRUFBRTtNQUNwQ0EsU0FBUyxDQUFDZ0MsQ0FBQyxDQUFDLEdBQUc0RCxlQUFlLENBQUM7UUFBRXZELEtBQUssRUFBRUosQ0FBQyxDQUFDSSxLQUFLO1FBQUVDLElBQUksRUFBRUwsQ0FBQyxDQUFDSztNQUFLLENBQUMsQ0FBQztJQUNsRTtJQUNBLE9BQU87TUFBRXVELElBQUksRUFBRSxJQUFJLENBQUNKLFFBQVEsQ0FBQyxDQUFDO01BQUV6RjtJQUFVLENBQUM7RUFDN0M7O0VBRUE7O0VBRUEsQ0FBQ1csU0FBU21GLENBQUEsRUFBYztJQUN0QixPQUFPO01BQUVoRyxPQUFPLEVBQUUsSUFBSUYsR0FBRyxDQUFDLENBQUM7TUFBRUcsTUFBTSxFQUFFLElBQUlILEdBQUcsQ0FBQyxDQUFDO01BQUU4RixXQUFXLEVBQUU7SUFBRyxDQUFDO0VBQ25FO0VBRUEsQ0FBQ25FLGVBQWV3RSxDQUFDQyxDQUFxQixFQUFRO0lBQzVDLElBQUksQ0FBQyxDQUFDdkcsS0FBSyxHQUFHdUcsQ0FBQyxDQUFDdkcsS0FBSztJQUNyQixJQUFJLENBQUMsQ0FBQ0MsTUFBTSxHQUFHc0csQ0FBQyxDQUFDdEcsTUFBTTtJQUN2QixJQUFJLENBQUMsQ0FBQ0MsU0FBUyxHQUFHLElBQUlDLEdBQUcsQ0FBQ29HLENBQUMsQ0FBQzlDLEtBQUssQ0FBQ0ksR0FBRyxDQUFFMkMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ3pILEVBQUUsRUFBRXlILENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEQsSUFBSSxDQUFDLENBQUNwRyxVQUFVLEdBQUcsSUFBSUQsR0FBRyxDQUFDb0csQ0FBQyxDQUFDbkcsVUFBVSxDQUFDO0lBQ3hDLElBQUksQ0FBQyxDQUFDSSxLQUFLLEdBQUcrRixDQUFDLENBQUMvRixLQUFLO0VBQ3ZCO0VBRUEsQ0FBQ2lCLFNBQVNnRixDQUFDL0UsR0FBbUIsRUFBUTtJQUNwQyxJQUFJQSxHQUFHLENBQUN3RCxJQUFJLEtBQUssT0FBTyxFQUFFO01BQ3hCLElBQUksQ0FBQyxDQUFDdkUsWUFBWSxHQUFHZSxHQUFHLENBQUNnRixVQUFVLENBQUM7TUFDcEMsSUFBSSxDQUFDLENBQUMvRixZQUFZLEdBQUcsSUFBSSxDQUFDLENBQUNDLFdBQVcsR0FBRyxJQUFJO0lBQy9DLENBQUMsTUFBTSxJQUFJYyxHQUFHLENBQUN3RCxJQUFJLEtBQUssYUFBYSxFQUFFO01BQ3JDLElBQUksQ0FBQyxDQUFDdEUsV0FBVyxHQUFHLElBQUkvQixLQUFLLENBQUM2QyxHQUFHLENBQUNpRixPQUFPLENBQUMsQ0FBQztNQUMzQyxJQUFJLENBQUMsQ0FBQ2hHLFlBQVksR0FBRyxJQUFJLENBQUMsQ0FBQ0MsV0FBVyxHQUFHLElBQUk7SUFDL0MsQ0FBQyxNQUFNLElBQUljLEdBQUcsQ0FBQ3dELElBQUksS0FBSyxjQUFjLEVBQUU7TUFDdEMsTUFBTTBCLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQy9GLFlBQVksQ0FBQ2tDLEdBQUcsQ0FBQ3JCLEdBQUcsQ0FBQ2hCLEtBQUssQ0FBQztNQUMzQyxJQUFJa0csQ0FBQyxLQUFLeEIsU0FBUyxFQUFFO01BQ3JCLElBQUksQ0FBQyxDQUFDdkUsWUFBWSxDQUFDMkQsTUFBTSxDQUFDOUMsR0FBRyxDQUFDaEIsS0FBSyxDQUFDO01BQ3BDa0csQ0FBQyxDQUFDM0YsT0FBTyxDQUFDUyxHQUFHLENBQUNzQyxNQUFNLENBQUM7SUFDdkIsQ0FBQyxNQUFNLElBQUl0QyxHQUFHLENBQUN3RCxJQUFJLEtBQUssWUFBWSxFQUFFO01BQ3BDO01BQ0EsTUFBTXBCLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQ2pELFlBQVksQ0FBQ2tDLEdBQUcsQ0FBQ3JCLEdBQUcsQ0FBQ2hCLEtBQUssQ0FBQztNQUMzQyxJQUFJb0QsQ0FBQyxLQUFLc0IsU0FBUyxFQUFFO1FBQ25CLElBQUksQ0FBQyxDQUFDdkUsWUFBWSxDQUFDMkQsTUFBTSxDQUFDOUMsR0FBRyxDQUFDaEIsS0FBSyxDQUFDO1FBQ3BDb0QsQ0FBQyxDQUFDUSxNQUFNLENBQUMsSUFBSXpGLEtBQUssQ0FBQzZDLEdBQUcsQ0FBQ2lGLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDO01BQ0Y7TUFDQSxNQUFNQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUNuRyxPQUFPLENBQUNzQyxHQUFHLENBQUNyQixHQUFHLENBQUNoQixLQUFLLENBQUM7TUFDdEMsSUFBSWtHLENBQUMsS0FBS3hCLFNBQVMsRUFBRXdCLENBQUMsQ0FBQ3RDLE1BQU0sQ0FBQyxJQUFJekYsS0FBSyxDQUFDNkMsR0FBRyxDQUFDaUYsT0FBTyxDQUFDLENBQUM7SUFDdkQsQ0FBQyxNQUFNO01BQ0wsTUFBTUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDbkcsT0FBTyxDQUFDc0MsR0FBRyxDQUFDckIsR0FBRyxDQUFDaEIsS0FBSyxDQUFDO01BQ3RDLElBQUlrRyxDQUFDLEtBQUt4QixTQUFTLEVBQUUsT0FBTyxDQUFDO01BQzdCd0IsQ0FBQyxDQUFDM0YsT0FBTyxDQUFDUyxHQUFHLENBQUNrQixLQUFLLENBQUM7SUFDdEI7RUFDRjtFQUVBLENBQUNiLFNBQVM4RSxDQUFDOUcsT0FBK0IsRUFBK0I7SUFDdkUsT0FBTyxJQUFJaUIsT0FBTyxDQUFxQixDQUFDQyxPQUFPLEVBQUVxRCxNQUFNLEtBQUs7TUFDMUQsSUFBSSxDQUFDLENBQUMzRCxZQUFZLEdBQUdNLE9BQU87TUFDNUIsSUFBSSxDQUFDLENBQUNMLFdBQVcsR0FBRzBELE1BQU07TUFDMUIsSUFBSSxDQUFDLENBQUM3RSxTQUFTLENBQUN3RixJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFLE9BQU87UUFBRW5GO01BQVEsQ0FBQyxDQUFDO0lBQ2xELENBQUMsQ0FBQztFQUNKO0VBRUEsQ0FBQ21DLEtBQUs0RSxDQUFBLEVBQXVCO0lBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQ2hHLE9BQU8sRUFBRTtNQUNsQixJQUFJLENBQUMsQ0FBQ0EsT0FBTyxHQUFHLElBQUk7TUFDcEIsSUFBSSxDQUFDLENBQUNDLGNBQWMsR0FBRyxJQUFJLENBQUMsQ0FBQ2dHLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxNQUFNO1FBQ2hELElBQUksQ0FBQyxDQUFDbEcsT0FBTyxHQUFHLEtBQUs7TUFDdkIsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxPQUFPLElBQUksQ0FBQyxDQUFDQyxjQUFjO0VBQzdCO0VBRUEsTUFBTSxDQUFDZ0csSUFBSUUsQ0FBQSxFQUF1QjtJQUNoQyxJQUFJQyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUNoRyxTQUFTLENBQUMsQ0FBQztJQUM1QixPQUFPLElBQUksQ0FBQyxDQUFDQyxnQkFBZ0IsS0FBSyxJQUFJLEVBQUU7TUFDdEMsTUFBTVosU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDWSxnQkFBZ0I7TUFDeEMsSUFBSSxDQUFDLENBQUNBLGdCQUFnQixHQUFHLElBQUk7TUFDN0IrRixJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQ2QsSUFBSSxDQUFDN0YsU0FBUyxDQUFDO0lBQ3BDO0lBQ0EsT0FBTzJHLElBQUk7RUFDYjtFQUVBLE1BQU0sQ0FBQ2QsSUFBSWUsQ0FBQzVHLFNBQXFFLEVBQXNCO0lBQ3JHLElBQUksQ0FBQyxDQUFDQSxTQUFTLEdBQUdBLFNBQVM7SUFDM0IsSUFBSSxDQUFDLENBQUNGLE9BQU8sR0FBRyxJQUFJRixHQUFHLENBQUMsQ0FBQztJQUN6QixJQUFJLENBQUMsQ0FBQ0csTUFBTSxHQUFHLElBQUlILEdBQUcsQ0FBQyxDQUFDO0lBRXhCLElBQUksSUFBSSxDQUFDLENBQUNGLE1BQU0sQ0FBQzRFLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDM0I7TUFDQTtNQUNBLE1BQU11QyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUNuSCxNQUFNLENBQUM0RCxHQUFHLENBQUUyQyxDQUFDLElBQUtBLENBQUMsQ0FBQ2EsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUNBLElBQUksQ0FBQyxJQUFJLENBQUM7TUFDOUQsS0FBSyxNQUFNdEksRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDbUIsU0FBUyxDQUFDb0gsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQ2hILE1BQU0sQ0FBQ3FDLEdBQUcsQ0FBQzVELEVBQUUsRUFBRSxxQkFBcUJxSSxJQUFJLEVBQUUsQ0FBQztNQUMxRixPQUFPLElBQUksQ0FBQyxDQUFDRyxNQUFNLENBQUMsQ0FBQztJQUN2QjtJQUVBLEtBQUssTUFBTXhJLEVBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQ2lCLEtBQUssRUFBRTtNQUM1QixNQUFNbUQsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDakQsU0FBUyxDQUFDNkMsR0FBRyxDQUFDaEUsRUFBRSxDQUFDO01BQ3BDLElBQUlvRSxJQUFJLEtBQUtpQyxTQUFTLEVBQUU7TUFFeEIsSUFBSSxJQUFJLENBQUMsQ0FBQ3pGLE9BQU8sQ0FBQzZILFNBQVMsQ0FBQ3pJLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQ2EsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQzVDLElBQUksQ0FBQyxDQUFDVSxNQUFNLENBQUNxQyxHQUFHLENBQUM1RCxFQUFFLEVBQUUsK0JBQStCLENBQUM7UUFDckQ7TUFDRjtNQUNBLE1BQU0wSSxVQUFVLEdBQUd0RSxJQUFJLENBQUN1RSxJQUFJLENBQUNDLElBQUksQ0FBRXBCLENBQUMsSUFBSyxJQUFJLENBQUMsQ0FBQ2pHLE1BQU0sQ0FBQ3VGLEdBQUcsQ0FBQ1UsQ0FBQyxDQUFDLENBQUM7TUFDN0QsSUFBSWtCLFVBQVUsS0FBS3JDLFNBQVMsRUFBRTtRQUM1QixJQUFJLENBQUMsQ0FBQzlFLE1BQU0sQ0FBQ3FDLEdBQUcsQ0FBQzVELEVBQUUsRUFBRSxVQUFVMEksVUFBVSxXQUFXLENBQUM7UUFDckQ7TUFDRjtNQUVBLE1BQU07UUFBRXJFLE1BQU07UUFBRXdFO01BQU0sQ0FBQyxHQUFHLElBQUF2QyxzQkFBYSxFQUFDbEMsSUFBSSxDQUFDbUMsU0FBUyxFQUFFO1FBQ3REakYsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDQSxPQUFPO1FBQ3RCRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUNBLFNBQVM7UUFDMUJILFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQ0E7TUFDcEIsQ0FBQyxDQUFDO01BRUYsSUFBSTtRQUNGLE1BQU13QyxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQ2lGLGdCQUFnQixDQUFDOUksRUFBRSxFQUFFcUUsTUFBTSxDQUFDO1FBQ3RELElBQUksQ0FBQyxDQUFDMEUsT0FBTyxDQUFDL0ksRUFBRSxFQUFFNkQsS0FBSyxFQUFFLElBQUFtRixlQUFTLEVBQUNILEtBQUssQ0FBQyxDQUFDO01BQzVDLENBQUMsQ0FBQyxPQUFPNUMsQ0FBQyxFQUFFO1FBQ1YsSUFBSUEsQ0FBQyxZQUFZcEcsWUFBWSxFQUFFO1VBQzdCO1VBQ0EsSUFBSSxDQUFDLENBQUNhLFNBQVMsQ0FBQ2dGLE9BQU8sQ0FBQyxDQUFDO1VBQ3pCLElBQUksQ0FBQyxDQUFDOUUsT0FBTyxDQUFDcUksZUFBZSxDQUFDakosRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDYSxHQUFHLENBQUMsQ0FBQyxDQUFDO1VBQzlDLElBQUk7WUFDRixNQUFNLElBQUksQ0FBQyxDQUFDbUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDaEMsT0FBTyxDQUFDO1VBQ3RDLENBQUMsQ0FBQyxNQUFNO1lBQ047VUFBQTtVQUVGLElBQUksQ0FBQyxDQUFDTyxNQUFNLENBQUNxQyxHQUFHLENBQUM1RCxFQUFFLEVBQUUsbUNBQW1DLENBQUM7UUFDM0QsQ0FBQyxNQUFNO1VBQ0w7VUFDQSxJQUFJLENBQUMsQ0FBQ3VCLE1BQU0sQ0FBQ3FDLEdBQUcsQ0FBQzVELEVBQUUsRUFBR2lHLENBQUMsQ0FBVzJCLE9BQU8sQ0FBQztRQUM1QztNQUNGO0lBQ0Y7SUFDQSxPQUFPLElBQUksQ0FBQyxDQUFDWSxNQUFNLENBQUMsQ0FBQztFQUN2Qjs7RUFFQTtFQUNBLENBQUNBLE1BQU1VLENBQUEsRUFBYztJQUNuQixNQUFNN0IsSUFBSSxHQUFHLElBQUksQ0FBQ0osUUFBUSxDQUFDLENBQUM7SUFDNUIsSUFBSSxDQUFDLENBQUNsRyxNQUFNLENBQUNzRyxJQUFJLENBQUM7SUFDbEIsT0FBT0EsSUFBSTtFQUNiO0VBRUEsQ0FBQ3lCLGdCQUFnQkssQ0FBQ25KLEVBQVUsRUFBRW1GLE1BQTZCLEVBQWtCO0lBQzNFLE1BQU14RCxLQUFLLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQ0EsS0FBSztJQUMzQixPQUFPLElBQUlNLE9BQU8sQ0FBUSxDQUFDQyxPQUFPLEVBQUVxRCxNQUFNLEtBQUs7TUFDN0MsSUFBSUMsTUFBTSxHQUFHQSxDQUFBLEtBQVksQ0FBQyxDQUFDO01BQzNCLE1BQU1nRCxNQUFNLEdBQU9wSSxFQUFvQixJQUFNZ0osR0FBTSxJQUFXO1FBQzVENUQsTUFBTSxDQUFDLENBQUM7UUFDUixJQUFJLENBQUMsQ0FBQzlELE9BQU8sQ0FBQytELE1BQU0sQ0FBQzlELEtBQUssQ0FBQztRQUMzQnZCLEVBQUUsQ0FBQ2dKLEdBQUcsQ0FBQztNQUNULENBQUM7TUFDRCxJQUFJLENBQUMsQ0FBQzFILE9BQU8sQ0FBQ2tDLEdBQUcsQ0FBQ2pDLEtBQUssRUFBRTtRQUFFTyxPQUFPLEVBQUVzRyxNQUFNLENBQUN0RyxPQUFPLENBQUM7UUFBRXFELE1BQU0sRUFBRWlELE1BQU0sQ0FBQ2pELE1BQU07TUFBRSxDQUFDLENBQUM7TUFDOUVDLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQzFFLFFBQVEsQ0FBQyxNQUFNO1FBQzVCLElBQUksQ0FBQyxDQUFDWSxPQUFPLENBQUMrRCxNQUFNLENBQUM5RCxLQUFLLENBQUM7UUFDM0I0RCxNQUFNLENBQUMsSUFBSTFGLFlBQVksQ0FBQ0csRUFBRSxDQUFDLENBQUM7TUFDOUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDVyxNQUFNLENBQUM7TUFDaEIsSUFBSSxDQUFDLENBQUNELFNBQVMsQ0FBQ3dGLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUUsTUFBTTtRQUFFbkcsRUFBRTtRQUFFMkIsS0FBSztRQUFFd0Q7TUFBTyxDQUFDLENBQUM7SUFDM0QsQ0FBQyxDQUFDO0VBQ0o7RUFFQSxDQUFDNEQsT0FBT00sQ0FBQ3JKLEVBQVUsRUFBRTZELEtBQVksRUFBRUMsSUFBMkIsRUFBUTtJQUNwRSxJQUFJLENBQUMsQ0FBQ3hDLE9BQU8sQ0FBQ3NDLEdBQUcsQ0FBQzVELEVBQUUsRUFBRTtNQUFFQSxFQUFFO01BQUU2RCxLQUFLO01BQUVDLElBQUk7TUFBRVEsR0FBRyxFQUFFLElBQUFnRixnQkFBVSxFQUFDekYsS0FBSztJQUFFLENBQUMsQ0FBQztFQUNwRTtBQUNGO0FBQUMzRCxPQUFBLENBQUFPLFdBQUEsR0FBQUEsV0FBQTtBQUVELFNBQVN5QyxLQUFLQSxDQUFDMUIsU0FBd0MsRUFBOEQ7RUFDbkgsT0FBTyxJQUFJSixHQUFHLENBQUNzQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ25DLFNBQVMsQ0FBQyxDQUFDc0QsR0FBRyxDQUFDLENBQUMsQ0FBQ3RCLENBQUMsRUFBRUMsQ0FBQyxDQUFDLEtBQUssQ0FBQ0QsQ0FBQyxFQUFFO0lBQUVLLEtBQUssRUFBRUosQ0FBQyxDQUFDSSxLQUFLO0lBQUVDLElBQUksRUFBRUwsQ0FBQyxDQUFDSztFQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEciLCJpZ25vcmVMaXN0IjpbXX0=