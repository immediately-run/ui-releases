var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TierSlot;
var _jsxRuntime = require("react/jsx-runtime");
// The reserved tier/trust badge slot (§3.3 point 3, review-1 H2). The badge is **host-drawn
// chrome, not Reckoner's** — a trust signal drawn by app code is forgeable by a malicious
// fork (receive `tier=live`, render a `static` badge). So we render an empty, host-fillable
// slot that only *carries* the tier as a data attribute; the host paints the actual badge
// into it. Standalone (no host), the slot is invisible. Never render badge text here.

function TierSlot({
  tier
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: "rk-tier-slot",
    "data-tier": tier,
    "data-host-badge": true,
    "aria-hidden": "true"
  });
}
_c = TierSlot;
var _c;
$RefreshReg$(_c, "TierSlot");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJUaWVyU2xvdCIsInRpZXIiLCJfanN4UnVudGltZSIsImpzeCIsImNsYXNzTmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGllclNsb3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSByZXNlcnZlZCB0aWVyL3RydXN0IGJhZGdlIHNsb3QgKMKnMy4zIHBvaW50IDMsIHJldmlldy0xIEgyKS4gVGhlIGJhZGdlIGlzICoqaG9zdC1kcmF3blxuLy8gY2hyb21lLCBub3QgUmVja29uZXIncyoqIOKAlCBhIHRydXN0IHNpZ25hbCBkcmF3biBieSBhcHAgY29kZSBpcyBmb3JnZWFibGUgYnkgYSBtYWxpY2lvdXNcbi8vIGZvcmsgKHJlY2VpdmUgYHRpZXI9bGl2ZWAsIHJlbmRlciBhIGBzdGF0aWNgIGJhZGdlKS4gU28gd2UgcmVuZGVyIGFuIGVtcHR5LCBob3N0LWZpbGxhYmxlXG4vLyBzbG90IHRoYXQgb25seSAqY2FycmllcyogdGhlIHRpZXIgYXMgYSBkYXRhIGF0dHJpYnV0ZTsgdGhlIGhvc3QgcGFpbnRzIHRoZSBhY3R1YWwgYmFkZ2Vcbi8vIGludG8gaXQuIFN0YW5kYWxvbmUgKG5vIGhvc3QpLCB0aGUgc2xvdCBpcyBpbnZpc2libGUuIE5ldmVyIHJlbmRlciBiYWRnZSB0ZXh0IGhlcmUuXG5pbXBvcnQgdHlwZSB7IFRpZXIgfSBmcm9tICcuLi8uLi8uLi9lbmdpbmUvdGllci50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRpZXJTbG90KHsgdGllciB9OiB7IHRpZXI6IFRpZXIgfSkge1xuICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwicmstdGllci1zbG90XCIgZGF0YS10aWVyPXt0aWVyfSBkYXRhLWhvc3QtYmFkZ2UgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz47XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdlLFNBQVNBLFFBQVFBLENBQUM7RUFBRUM7QUFBcUIsQ0FBQyxFQUFFO0VBQ3pELG9CQUFPLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFNQyxTQUFTLEVBQUMsY0FBYztJQUFDLGFBQVdILElBQUs7SUFBQyx1QkFBZTtJQUFDLGVBQVk7RUFBTSxDQUFFLENBQUM7QUFDOUY7QUFBQ0ksRUFBQSxHQUZ1QkwsUUFBUTtBQUFBLElBQUFLLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}