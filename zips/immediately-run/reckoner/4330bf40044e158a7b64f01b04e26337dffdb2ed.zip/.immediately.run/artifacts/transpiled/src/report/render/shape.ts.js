"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.asBoolean = asBoolean;
exports.asNumber = asNumber;
exports.asRows = asRows;
exports.asScalar = asScalar;
exports.labelField = labelField;
exports.numericField = numericField;
// Shape contracts (§3.3 point 4): "a Kpi wants a scalar, a Chart wants rows." A binding that
// resolves to the wrong shape is a **marked broken tile** in view mode (and an authoring
// diagnostic upstream) — never a blank or a crash. These guards turn a resolved value into a
// typed success or a reason string the component renders as a broken tile. Pure.

/** Require a scalar (Kpi / Value / Gauge). Rows or objects are a shape mismatch. */
function asScalar(v) {
  if (v === null || typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean') {
    return {
      ok: true,
      data: v
    };
  }
  return {
    ok: false,
    reason: Array.isArray(v) ? 'expected a single value, got a table' : 'expected a single value, got an object'
  };
}

/** Require a numeric scalar (Gauge). */
function asNumber(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return {
    ok: true,
    data: v
  };
  if (v === null) return {
    ok: false,
    reason: 'no value'
  };
  return {
    ok: false,
    reason: 'expected a number'
  };
}

/** Require a boolean scalar (ShowWhen). Truthiness is refused: a cell that starts returning a count would silently flip the render. */
function asBoolean(v) {
  if (v === true || v === false) return {
    ok: true,
    data: v
  };
  if (v === null) return {
    ok: false,
    reason: 'expected true or false, got no value'
  };
  if (typeof v === 'number') return {
    ok: false,
    reason: 'expected true or false, got a number'
  };
  if (typeof v === 'string') return {
    ok: false,
    reason: 'expected true or false, got text'
  };
  return {
    ok: false,
    reason: Array.isArray(v) ? 'expected true or false, got a table' : 'expected true or false, got an object'
  };
}

/** Require a table (an array of plain-object rows) for Chart / Table / Facets / Map. */
function asRows(v) {
  if (!Array.isArray(v)) return {
    ok: false,
    reason: 'expected a table of rows'
  };
  for (const r of v) {
    if (r === null || typeof r !== 'object' || Array.isArray(r)) {
      return {
        ok: false,
        reason: 'table rows must be objects'
      };
    }
  }
  return {
    ok: true,
    data: v
  };
}

/** Read a numeric column, coercing null/absent to `null` (never NaN). */
function numericField(row, field) {
  const v = row[field];
  return typeof v === 'number' && Number.isFinite(v) ? v : null;
}

/** Read any column as a display label. */
function labelField(row, field) {
  const v = row[field];
  if (v === null || v === undefined) return '—';
  if (typeof v === 'object') return '';
  return String(v);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJhc1NjYWxhciIsInYiLCJvayIsImRhdGEiLCJyZWFzb24iLCJBcnJheSIsImlzQXJyYXkiLCJhc051bWJlciIsIk51bWJlciIsImlzRmluaXRlIiwiYXNCb29sZWFuIiwiYXNSb3dzIiwiciIsIm51bWVyaWNGaWVsZCIsInJvdyIsImZpZWxkIiwibGFiZWxGaWVsZCIsInVuZGVmaW5lZCIsIlN0cmluZyJdLCJzb3VyY2VzIjpbInNoYXBlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFNoYXBlIGNvbnRyYWN0cyAowqczLjMgcG9pbnQgNCk6IFwiYSBLcGkgd2FudHMgYSBzY2FsYXIsIGEgQ2hhcnQgd2FudHMgcm93cy5cIiBBIGJpbmRpbmcgdGhhdFxuLy8gcmVzb2x2ZXMgdG8gdGhlIHdyb25nIHNoYXBlIGlzIGEgKiptYXJrZWQgYnJva2VuIHRpbGUqKiBpbiB2aWV3IG1vZGUgKGFuZCBhbiBhdXRob3Jpbmdcbi8vIGRpYWdub3N0aWMgdXBzdHJlYW0pIOKAlCBuZXZlciBhIGJsYW5rIG9yIGEgY3Jhc2guIFRoZXNlIGd1YXJkcyB0dXJuIGEgcmVzb2x2ZWQgdmFsdWUgaW50byBhXG4vLyB0eXBlZCBzdWNjZXNzIG9yIGEgcmVhc29uIHN0cmluZyB0aGUgY29tcG9uZW50IHJlbmRlcnMgYXMgYSBicm9rZW4gdGlsZS4gUHVyZS5cblxuaW1wb3J0IHR5cGUgeyBSb3csIFNjYWxhciwgVmFsdWUgfSBmcm9tICcuLi8uLi9zdGRsaWIvdHlwZXMudHMnO1xuXG5leHBvcnQgdHlwZSBTaGFwZVJlc3VsdDxUPiA9IHsgb2s6IHRydWU7IGRhdGE6IFQgfSB8IHsgb2s6IGZhbHNlOyByZWFzb246IHN0cmluZyB9O1xuXG4vKiogUmVxdWlyZSBhIHNjYWxhciAoS3BpIC8gVmFsdWUgLyBHYXVnZSkuIFJvd3Mgb3Igb2JqZWN0cyBhcmUgYSBzaGFwZSBtaXNtYXRjaC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc1NjYWxhcih2OiBWYWx1ZSk6IFNoYXBlUmVzdWx0PFNjYWxhcj4ge1xuICBpZiAodiA9PT0gbnVsbCB8fCB0eXBlb2YgdiA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHYgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgZGF0YTogdiB9O1xuICB9XG4gIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiBBcnJheS5pc0FycmF5KHYpID8gJ2V4cGVjdGVkIGEgc2luZ2xlIHZhbHVlLCBnb3QgYSB0YWJsZScgOiAnZXhwZWN0ZWQgYSBzaW5nbGUgdmFsdWUsIGdvdCBhbiBvYmplY3QnIH07XG59XG5cbi8qKiBSZXF1aXJlIGEgbnVtZXJpYyBzY2FsYXIgKEdhdWdlKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc051bWJlcih2OiBWYWx1ZSk6IFNoYXBlUmVzdWx0PG51bWJlcj4ge1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHYgfTtcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiAnbm8gdmFsdWUnIH07XG4gIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiAnZXhwZWN0ZWQgYSBudW1iZXInIH07XG59XG5cbi8qKiBSZXF1aXJlIGEgYm9vbGVhbiBzY2FsYXIgKFNob3dXaGVuKS4gVHJ1dGhpbmVzcyBpcyByZWZ1c2VkOiBhIGNlbGwgdGhhdCBzdGFydHMgcmV0dXJuaW5nIGEgY291bnQgd291bGQgc2lsZW50bHkgZmxpcCB0aGUgcmVuZGVyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFzQm9vbGVhbih2OiBWYWx1ZSk6IFNoYXBlUmVzdWx0PGJvb2xlYW4+IHtcbiAgaWYgKHYgPT09IHRydWUgfHwgdiA9PT0gZmFsc2UpIHJldHVybiB7IG9rOiB0cnVlLCBkYXRhOiB2IH07XG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogJ2V4cGVjdGVkIHRydWUgb3IgZmFsc2UsIGdvdCBubyB2YWx1ZScgfTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJykgcmV0dXJuIHsgb2s6IGZhbHNlLCByZWFzb246ICdleHBlY3RlZCB0cnVlIG9yIGZhbHNlLCBnb3QgYSBudW1iZXInIH07XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiAnZXhwZWN0ZWQgdHJ1ZSBvciBmYWxzZSwgZ290IHRleHQnIH07XG4gIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiBBcnJheS5pc0FycmF5KHYpID8gJ2V4cGVjdGVkIHRydWUgb3IgZmFsc2UsIGdvdCBhIHRhYmxlJyA6ICdleHBlY3RlZCB0cnVlIG9yIGZhbHNlLCBnb3QgYW4gb2JqZWN0JyB9O1xufVxuXG4vKiogUmVxdWlyZSBhIHRhYmxlIChhbiBhcnJheSBvZiBwbGFpbi1vYmplY3Qgcm93cykgZm9yIENoYXJ0IC8gVGFibGUgLyBGYWNldHMgLyBNYXAuICovXG5leHBvcnQgZnVuY3Rpb24gYXNSb3dzKHY6IFZhbHVlKTogU2hhcGVSZXN1bHQ8Um93W10+IHtcbiAgaWYgKCFBcnJheS5pc0FycmF5KHYpKSByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogJ2V4cGVjdGVkIGEgdGFibGUgb2Ygcm93cycgfTtcbiAgZm9yIChjb25zdCByIG9mIHYpIHtcbiAgICBpZiAociA9PT0gbnVsbCB8fCB0eXBlb2YgciAhPT0gJ29iamVjdCcgfHwgQXJyYXkuaXNBcnJheShyKSkge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCByZWFzb246ICd0YWJsZSByb3dzIG11c3QgYmUgb2JqZWN0cycgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHYgYXMgUm93W10gfTtcbn1cblxuLyoqIFJlYWQgYSBudW1lcmljIGNvbHVtbiwgY29lcmNpbmcgbnVsbC9hYnNlbnQgdG8gYG51bGxgIChuZXZlciBOYU4pLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG51bWVyaWNGaWVsZChyb3c6IFJvdywgZmllbGQ6IHN0cmluZyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCB2ID0gcm93W2ZpZWxkXTtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikgPyB2IDogbnVsbDtcbn1cblxuLyoqIFJlYWQgYW55IGNvbHVtbiBhcyBhIGRpc3BsYXkgbGFiZWwuICovXG5leHBvcnQgZnVuY3Rpb24gbGFiZWxGaWVsZChyb3c6IFJvdywgZmllbGQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHYgPSByb3dbZmllbGRdO1xuICBpZiAodiA9PT0gbnVsbCB8fCB2ID09PSB1bmRlZmluZWQpIHJldHVybiAn4oCUJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnb2JqZWN0JykgcmV0dXJuICcnO1xuICByZXR1cm4gU3RyaW5nKHYpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQU1BO0FBQ08sU0FBU0EsUUFBUUEsQ0FBQ0MsQ0FBUSxFQUF1QjtFQUN0RCxJQUFJQSxDQUFDLEtBQUssSUFBSSxJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLElBQUksT0FBT0EsQ0FBQyxLQUFLLFFBQVEsSUFBSSxPQUFPQSxDQUFDLEtBQUssU0FBUyxFQUFFO0lBQzFGLE9BQU87TUFBRUMsRUFBRSxFQUFFLElBQUk7TUFBRUMsSUFBSSxFQUFFRjtJQUFFLENBQUM7RUFDOUI7RUFDQSxPQUFPO0lBQUVDLEVBQUUsRUFBRSxLQUFLO0lBQUVFLE1BQU0sRUFBRUMsS0FBSyxDQUFDQyxPQUFPLENBQUNMLENBQUMsQ0FBQyxHQUFHLHNDQUFzQyxHQUFHO0VBQXlDLENBQUM7QUFDcEk7O0FBRUE7QUFDTyxTQUFTTSxRQUFRQSxDQUFDTixDQUFRLEVBQXVCO0VBQ3RELElBQUksT0FBT0EsQ0FBQyxLQUFLLFFBQVEsSUFBSU8sTUFBTSxDQUFDQyxRQUFRLENBQUNSLENBQUMsQ0FBQyxFQUFFLE9BQU87SUFBRUMsRUFBRSxFQUFFLElBQUk7SUFBRUMsSUFBSSxFQUFFRjtFQUFFLENBQUM7RUFDN0UsSUFBSUEsQ0FBQyxLQUFLLElBQUksRUFBRSxPQUFPO0lBQUVDLEVBQUUsRUFBRSxLQUFLO0lBQUVFLE1BQU0sRUFBRTtFQUFXLENBQUM7RUFDeEQsT0FBTztJQUFFRixFQUFFLEVBQUUsS0FBSztJQUFFRSxNQUFNLEVBQUU7RUFBb0IsQ0FBQztBQUNuRDs7QUFFQTtBQUNPLFNBQVNNLFNBQVNBLENBQUNULENBQVEsRUFBd0I7RUFDeEQsSUFBSUEsQ0FBQyxLQUFLLElBQUksSUFBSUEsQ0FBQyxLQUFLLEtBQUssRUFBRSxPQUFPO0lBQUVDLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRUY7RUFBRSxDQUFDO0VBQzNELElBQUlBLENBQUMsS0FBSyxJQUFJLEVBQUUsT0FBTztJQUFFQyxFQUFFLEVBQUUsS0FBSztJQUFFRSxNQUFNLEVBQUU7RUFBdUMsQ0FBQztFQUNwRixJQUFJLE9BQU9ILENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBTztJQUFFQyxFQUFFLEVBQUUsS0FBSztJQUFFRSxNQUFNLEVBQUU7RUFBdUMsQ0FBQztFQUMvRixJQUFJLE9BQU9ILENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBTztJQUFFQyxFQUFFLEVBQUUsS0FBSztJQUFFRSxNQUFNLEVBQUU7RUFBbUMsQ0FBQztFQUMzRixPQUFPO0lBQUVGLEVBQUUsRUFBRSxLQUFLO0lBQUVFLE1BQU0sRUFBRUMsS0FBSyxDQUFDQyxPQUFPLENBQUNMLENBQUMsQ0FBQyxHQUFHLHFDQUFxQyxHQUFHO0VBQXdDLENBQUM7QUFDbEk7O0FBRUE7QUFDTyxTQUFTVSxNQUFNQSxDQUFDVixDQUFRLEVBQXNCO0VBQ25ELElBQUksQ0FBQ0ksS0FBSyxDQUFDQyxPQUFPLENBQUNMLENBQUMsQ0FBQyxFQUFFLE9BQU87SUFBRUMsRUFBRSxFQUFFLEtBQUs7SUFBRUUsTUFBTSxFQUFFO0VBQTJCLENBQUM7RUFDL0UsS0FBSyxNQUFNUSxDQUFDLElBQUlYLENBQUMsRUFBRTtJQUNqQixJQUFJVyxDQUFDLEtBQUssSUFBSSxJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLElBQUlQLEtBQUssQ0FBQ0MsT0FBTyxDQUFDTSxDQUFDLENBQUMsRUFBRTtNQUMzRCxPQUFPO1FBQUVWLEVBQUUsRUFBRSxLQUFLO1FBQUVFLE1BQU0sRUFBRTtNQUE2QixDQUFDO0lBQzVEO0VBQ0Y7RUFDQSxPQUFPO0lBQUVGLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRUY7RUFBVyxDQUFDO0FBQ3ZDOztBQUVBO0FBQ08sU0FBU1ksWUFBWUEsQ0FBQ0MsR0FBUSxFQUFFQyxLQUFhLEVBQWlCO0VBQ25FLE1BQU1kLENBQUMsR0FBR2EsR0FBRyxDQUFDQyxLQUFLLENBQUM7RUFDcEIsT0FBTyxPQUFPZCxDQUFDLEtBQUssUUFBUSxJQUFJTyxNQUFNLENBQUNDLFFBQVEsQ0FBQ1IsQ0FBQyxDQUFDLEdBQUdBLENBQUMsR0FBRyxJQUFJO0FBQy9EOztBQUVBO0FBQ08sU0FBU2UsVUFBVUEsQ0FBQ0YsR0FBUSxFQUFFQyxLQUFhLEVBQVU7RUFDMUQsTUFBTWQsQ0FBQyxHQUFHYSxHQUFHLENBQUNDLEtBQUssQ0FBQztFQUNwQixJQUFJZCxDQUFDLEtBQUssSUFBSSxJQUFJQSxDQUFDLEtBQUtnQixTQUFTLEVBQUUsT0FBTyxHQUFHO0VBQzdDLElBQUksT0FBT2hCLENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBTyxFQUFFO0VBQ3BDLE9BQU9pQixNQUFNLENBQUNqQixDQUFDLENBQUM7QUFDbEIiLCJpZ25vcmVMaXN0IjpbXX0=