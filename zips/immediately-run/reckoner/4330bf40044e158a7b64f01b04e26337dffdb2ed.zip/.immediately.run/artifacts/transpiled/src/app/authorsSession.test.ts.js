"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.some.js");
var _vitest = require("vitest");
var _workerTransport = require("../engine/workerTransport.ts");
var _reportSession = require("./reportSession.ts");
// The author's view through the real session pipeline (AUTHORS_VIEW_SPEC §3.5/§4,
// gates G-AV-1..4 session halves + the §6 consumer-template diagnostic): in-memory
// documents through `buildReportSession` over the in-process transport.

const SHEET = `import { cell } from "@reckoner/stdlib";

export const total = cell({
  doc: "the number",
  inputs: {},
  formula: () => 41,
});
`;
function seed(over) {
  const files = {
    '/doc/reckoner.json': JSON.stringify({
      format: 1,
      compat: {
        stdlib: '>=0.1.0',
        catalog: '>=0.1.0'
      },
      worksheets: ['model.sheet.js'],
      params: {},
      title: 'Authors harness',
      ...(over.manifest ?? {})
    }),
    '/doc/worksheets/model.sheet.js': SHEET
  };
  for (const [name, source] of Object.entries(over.templates ?? {})) {
    files[`/doc/templates/${name}.mdx`] = source;
  }
  return {
    root: '/doc',
    files
  };
}
(0, _vitest.describe)('author’s-view session wiring', () => {
  (0, _vitest.it)('G-AV-1: a document without an author’s view gets the built-in scaffold', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      templates: {
        weekly: '# Report.\n'
      }
    }));
    (0, _vitest.expect)(session.authorsFromDocument).toBe(false);
    (0, _vitest.expect)(session.authorsNodes.some(n => n.type === 'component' && n.name === 'FormulaIndex')).toBe(true);
    (0, _vitest.expect)(session.nodes.length).toBeGreaterThan(0); // the consumer report is weekly
  });
  (0, _vitest.it)('G-AV-2: the document’s own authors_view.mdx replaces the default entirely', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      templates: {
        weekly: '# Report.\n',
        authors_view: '# Mine.\n\n<SuiteSummary />\n'
      }
    }));
    (0, _vitest.expect)(session.authorsFromDocument).toBe(true);
    (0, _vitest.expect)(session.authorsNodes.some(n => n.type === 'component' && n.name === 'FormulaIndex')).toBe(false);
    (0, _vitest.expect)(session.authorsNodes.some(n => n.type === 'component' && n.name === 'SuiteSummary')).toBe(true);
  });
  (0, _vitest.it)('G-AV-3: the author’s view never serves as the consumer report', async () => {
    // Template list [authors_view, deal] — the report must be deal, not the workings.
    const withOther = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      templates: {
        authors_view: '<FormulaIndex />\n',
        deal: '# Deal.\n'
      }
    }));
    (0, _vitest.expect)(withOther.nodes.some(n => n.type === 'markdown' && n.text.includes('Deal'))).toBe(true);

    // A document with ONLY an author's view renders the report empty-state.
    const only = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      templates: {
        authors_view: '<FormulaIndex />\n'
      }
    }));
    (0, _vitest.expect)(only.nodes).toEqual([]);
    (0, _vitest.expect)(only.authorsFromDocument).toBe(true);
  });
  (0, _vitest.it)('G-AV-4: the manifest’s authorsView key selects a differently-named template', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      manifest: {
        authorsView: 'workings'
      },
      templates: {
        workings: '# Workings.\n\n<TestIndex />\n',
        weekly: '# Report.\n'
      }
    }));
    (0, _vitest.expect)(session.authorsFromDocument).toBe(true);
    (0, _vitest.expect)(session.authorsNodes.some(n => n.type === 'component' && n.name === 'TestIndex')).toBe(true);
    (0, _vitest.expect)(session.nodes.some(n => n.type === 'markdown' && n.text.includes('Report'))).toBe(true);
  });
  (0, _vitest.it)('§6: a reflection component in a consumer template raises a load-time warning', async () => {
    const session = await (0, _reportSession.buildReportSession)((0, _workerTransport.inMemoryTransport)(), seed({
      templates: {
        weekly: '# Report.\n\n<FormulaIndex />\n'
      }
    }));
    const warning = session.diagnostics.find(d => d.message.includes('FormulaIndex'));
    (0, _vitest.expect)(warning).toBeDefined();
    (0, _vitest.expect)(warning?.severity).toBe('warning');
    // …and the author's-view scaffold itself never triggers it.
    (0, _vitest.expect)(session.diagnostics.filter(d => d.message.includes("author's-view component")).length).toBe(1);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl93b3JrZXJUcmFuc3BvcnQiLCJfcmVwb3J0U2Vzc2lvbiIsIlNIRUVUIiwic2VlZCIsIm92ZXIiLCJmaWxlcyIsIkpTT04iLCJzdHJpbmdpZnkiLCJmb3JtYXQiLCJjb21wYXQiLCJzdGRsaWIiLCJjYXRhbG9nIiwid29ya3NoZWV0cyIsInBhcmFtcyIsInRpdGxlIiwibWFuaWZlc3QiLCJuYW1lIiwic291cmNlIiwiT2JqZWN0IiwiZW50cmllcyIsInRlbXBsYXRlcyIsInJvb3QiLCJkZXNjcmliZSIsIml0Iiwic2Vzc2lvbiIsImJ1aWxkUmVwb3J0U2Vzc2lvbiIsImluTWVtb3J5VHJhbnNwb3J0Iiwid2Vla2x5IiwiZXhwZWN0IiwiYXV0aG9yc0Zyb21Eb2N1bWVudCIsInRvQmUiLCJhdXRob3JzTm9kZXMiLCJzb21lIiwibiIsInR5cGUiLCJub2RlcyIsImxlbmd0aCIsInRvQmVHcmVhdGVyVGhhbiIsImF1dGhvcnNfdmlldyIsIndpdGhPdGhlciIsImRlYWwiLCJ0ZXh0IiwiaW5jbHVkZXMiLCJvbmx5IiwidG9FcXVhbCIsImF1dGhvcnNWaWV3Iiwid29ya2luZ3MiLCJ3YXJuaW5nIiwiZGlhZ25vc3RpY3MiLCJmaW5kIiwiZCIsIm1lc3NhZ2UiLCJ0b0JlRGVmaW5lZCIsInNldmVyaXR5IiwiZmlsdGVyIl0sInNvdXJjZXMiOlsiYXV0aG9yc1Nlc3Npb24udGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgYXV0aG9yJ3MgdmlldyB0aHJvdWdoIHRoZSByZWFsIHNlc3Npb24gcGlwZWxpbmUgKEFVVEhPUlNfVklFV19TUEVDIMKnMy41L8KnNCxcbi8vIGdhdGVzIEctQVYtMS4uNCBzZXNzaW9uIGhhbHZlcyArIHRoZSDCpzYgY29uc3VtZXItdGVtcGxhdGUgZGlhZ25vc3RpYyk6IGluLW1lbW9yeVxuLy8gZG9jdW1lbnRzIHRocm91Z2ggYGJ1aWxkUmVwb3J0U2Vzc2lvbmAgb3ZlciB0aGUgaW4tcHJvY2VzcyB0cmFuc3BvcnQuXG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBpbk1lbW9yeVRyYW5zcG9ydCB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXJUcmFuc3BvcnQudHMnO1xuaW1wb3J0IHR5cGUgeyBTZWVkRG9jdW1lbnQgfSBmcm9tICcuLi9zZWVkL3NlZWRzLnRzJztcbmltcG9ydCB7IGJ1aWxkUmVwb3J0U2Vzc2lvbiB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5cbmNvbnN0IFNIRUVUID0gYGltcG9ydCB7IGNlbGwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG5leHBvcnQgY29uc3QgdG90YWwgPSBjZWxsKHtcbiAgZG9jOiBcInRoZSBudW1iZXJcIixcbiAgaW5wdXRzOiB7fSxcbiAgZm9ybXVsYTogKCkgPT4gNDEsXG59KTtcbmA7XG5cbmZ1bmN0aW9uIHNlZWQob3Zlcjoge1xuICBtYW5pZmVzdD86IFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICB0ZW1wbGF0ZXM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xufSk6IFNlZWREb2N1bWVudCB7XG4gIGNvbnN0IGZpbGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICcvZG9jL3JlY2tvbmVyLmpzb24nOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICBmb3JtYXQ6IDEsXG4gICAgICBjb21wYXQ6IHsgc3RkbGliOiAnPj0wLjEuMCcsIGNhdGFsb2c6ICc+PTAuMS4wJyB9LFxuICAgICAgd29ya3NoZWV0czogWydtb2RlbC5zaGVldC5qcyddLFxuICAgICAgcGFyYW1zOiB7fSxcbiAgICAgIHRpdGxlOiAnQXV0aG9ycyBoYXJuZXNzJyxcbiAgICAgIC4uLihvdmVyLm1hbmlmZXN0ID8/IHt9KSxcbiAgICB9KSxcbiAgICAnL2RvYy93b3Jrc2hlZXRzL21vZGVsLnNoZWV0LmpzJzogU0hFRVQsXG4gIH07XG4gIGZvciAoY29uc3QgW25hbWUsIHNvdXJjZV0gb2YgT2JqZWN0LmVudHJpZXMob3Zlci50ZW1wbGF0ZXMgPz8ge30pKSB7XG4gICAgZmlsZXNbYC9kb2MvdGVtcGxhdGVzLyR7bmFtZX0ubWR4YF0gPSBzb3VyY2U7XG4gIH1cbiAgcmV0dXJuIHsgcm9vdDogJy9kb2MnLCBmaWxlcyB9O1xufVxuXG5kZXNjcmliZSgnYXV0aG9y4oCZcy12aWV3IHNlc3Npb24gd2lyaW5nJywgKCkgPT4ge1xuICBpdCgnRy1BVi0xOiBhIGRvY3VtZW50IHdpdGhvdXQgYW4gYXV0aG9y4oCZcyB2aWV3IGdldHMgdGhlIGJ1aWx0LWluIHNjYWZmb2xkJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oaW5NZW1vcnlUcmFuc3BvcnQoKSwgc2VlZCh7IHRlbXBsYXRlczogeyB3ZWVrbHk6ICcjIFJlcG9ydC5cXG4nIH0gfSkpO1xuICAgIGV4cGVjdChzZXNzaW9uLmF1dGhvcnNGcm9tRG9jdW1lbnQpLnRvQmUoZmFsc2UpO1xuICAgIGV4cGVjdChzZXNzaW9uLmF1dGhvcnNOb2Rlcy5zb21lKChuKSA9PiBuLnR5cGUgPT09ICdjb21wb25lbnQnICYmIG4ubmFtZSA9PT0gJ0Zvcm11bGFJbmRleCcpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChzZXNzaW9uLm5vZGVzLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDApOyAvLyB0aGUgY29uc3VtZXIgcmVwb3J0IGlzIHdlZWtseVxuICB9KTtcblxuICBpdCgnRy1BVi0yOiB0aGUgZG9jdW1lbnTigJlzIG93biBhdXRob3JzX3ZpZXcubWR4IHJlcGxhY2VzIHRoZSBkZWZhdWx0IGVudGlyZWx5JywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oXG4gICAgICBpbk1lbW9yeVRyYW5zcG9ydCgpLFxuICAgICAgc2VlZCh7IHRlbXBsYXRlczogeyB3ZWVrbHk6ICcjIFJlcG9ydC5cXG4nLCBhdXRob3JzX3ZpZXc6ICcjIE1pbmUuXFxuXFxuPFN1aXRlU3VtbWFyeSAvPlxcbicgfSB9KSxcbiAgICApO1xuICAgIGV4cGVjdChzZXNzaW9uLmF1dGhvcnNGcm9tRG9jdW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHNlc3Npb24uYXV0aG9yc05vZGVzLnNvbWUoKG4pID0+IG4udHlwZSA9PT0gJ2NvbXBvbmVudCcgJiYgbi5uYW1lID09PSAnRm9ybXVsYUluZGV4JykpLnRvQmUoZmFsc2UpO1xuICAgIGV4cGVjdChzZXNzaW9uLmF1dGhvcnNOb2Rlcy5zb21lKChuKSA9PiBuLnR5cGUgPT09ICdjb21wb25lbnQnICYmIG4ubmFtZSA9PT0gJ1N1aXRlU3VtbWFyeScpKS50b0JlKHRydWUpO1xuICB9KTtcblxuICBpdCgnRy1BVi0zOiB0aGUgYXV0aG9y4oCZcyB2aWV3IG5ldmVyIHNlcnZlcyBhcyB0aGUgY29uc3VtZXIgcmVwb3J0JywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRlbXBsYXRlIGxpc3QgW2F1dGhvcnNfdmlldywgZGVhbF0g4oCUIHRoZSByZXBvcnQgbXVzdCBiZSBkZWFsLCBub3QgdGhlIHdvcmtpbmdzLlxuICAgIGNvbnN0IHdpdGhPdGhlciA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihcbiAgICAgIGluTWVtb3J5VHJhbnNwb3J0KCksXG4gICAgICBzZWVkKHsgdGVtcGxhdGVzOiB7IGF1dGhvcnNfdmlldzogJzxGb3JtdWxhSW5kZXggLz5cXG4nLCBkZWFsOiAnIyBEZWFsLlxcbicgfSB9KSxcbiAgICApO1xuICAgIGV4cGVjdCh3aXRoT3RoZXIubm9kZXMuc29tZSgobikgPT4gbi50eXBlID09PSAnbWFya2Rvd24nICYmIG4udGV4dC5pbmNsdWRlcygnRGVhbCcpKSkudG9CZSh0cnVlKTtcblxuICAgIC8vIEEgZG9jdW1lbnQgd2l0aCBPTkxZIGFuIGF1dGhvcidzIHZpZXcgcmVuZGVycyB0aGUgcmVwb3J0IGVtcHR5LXN0YXRlLlxuICAgIGNvbnN0IG9ubHkgPSBhd2FpdCBidWlsZFJlcG9ydFNlc3Npb24oXG4gICAgICBpbk1lbW9yeVRyYW5zcG9ydCgpLFxuICAgICAgc2VlZCh7IHRlbXBsYXRlczogeyBhdXRob3JzX3ZpZXc6ICc8Rm9ybXVsYUluZGV4IC8+XFxuJyB9IH0pLFxuICAgICk7XG4gICAgZXhwZWN0KG9ubHkubm9kZXMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChvbmx5LmF1dGhvcnNGcm9tRG9jdW1lbnQpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCdHLUFWLTQ6IHRoZSBtYW5pZmVzdOKAmXMgYXV0aG9yc1ZpZXcga2V5IHNlbGVjdHMgYSBkaWZmZXJlbnRseS1uYW1lZCB0ZW1wbGF0ZScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYnVpbGRSZXBvcnRTZXNzaW9uKFxuICAgICAgaW5NZW1vcnlUcmFuc3BvcnQoKSxcbiAgICAgIHNlZWQoe1xuICAgICAgICBtYW5pZmVzdDogeyBhdXRob3JzVmlldzogJ3dvcmtpbmdzJyB9LFxuICAgICAgICB0ZW1wbGF0ZXM6IHsgd29ya2luZ3M6ICcjIFdvcmtpbmdzLlxcblxcbjxUZXN0SW5kZXggLz5cXG4nLCB3ZWVrbHk6ICcjIFJlcG9ydC5cXG4nIH0sXG4gICAgICB9KSxcbiAgICApO1xuICAgIGV4cGVjdChzZXNzaW9uLmF1dGhvcnNGcm9tRG9jdW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHNlc3Npb24uYXV0aG9yc05vZGVzLnNvbWUoKG4pID0+IG4udHlwZSA9PT0gJ2NvbXBvbmVudCcgJiYgbi5uYW1lID09PSAnVGVzdEluZGV4JykpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHNlc3Npb24ubm9kZXMuc29tZSgobikgPT4gbi50eXBlID09PSAnbWFya2Rvd24nICYmIG4udGV4dC5pbmNsdWRlcygnUmVwb3J0JykpKS50b0JlKHRydWUpO1xuICB9KTtcblxuICBpdCgnwqc2OiBhIHJlZmxlY3Rpb24gY29tcG9uZW50IGluIGEgY29uc3VtZXIgdGVtcGxhdGUgcmFpc2VzIGEgbG9hZC10aW1lIHdhcm5pbmcnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGJ1aWxkUmVwb3J0U2Vzc2lvbihcbiAgICAgIGluTWVtb3J5VHJhbnNwb3J0KCksXG4gICAgICBzZWVkKHsgdGVtcGxhdGVzOiB7IHdlZWtseTogJyMgUmVwb3J0LlxcblxcbjxGb3JtdWxhSW5kZXggLz5cXG4nIH0gfSksXG4gICAgKTtcbiAgICBjb25zdCB3YXJuaW5nID0gc2Vzc2lvbi5kaWFnbm9zdGljcy5maW5kKChkKSA9PiBkLm1lc3NhZ2UuaW5jbHVkZXMoJ0Zvcm11bGFJbmRleCcpKTtcbiAgICBleHBlY3Qod2FybmluZykudG9CZURlZmluZWQoKTtcbiAgICBleHBlY3Qod2FybmluZz8uc2V2ZXJpdHkpLnRvQmUoJ3dhcm5pbmcnKTtcbiAgICAvLyDigKZhbmQgdGhlIGF1dGhvcidzLXZpZXcgc2NhZmZvbGQgaXRzZWxmIG5ldmVyIHRyaWdnZXJzIGl0LlxuICAgIGV4cGVjdChzZXNzaW9uLmRpYWdub3N0aWNzLmZpbHRlcigoZCkgPT4gZC5tZXNzYWdlLmluY2x1ZGVzKFwiYXV0aG9yJ3MtdmlldyBjb21wb25lbnRcIikpLmxlbmd0aCkudG9CZSgxKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBR0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsZ0JBQUEsR0FBQUQsT0FBQTtBQUVBLElBQUFFLGNBQUEsR0FBQUYsT0FBQTtBQU5BO0FBQ0E7QUFDQTs7QUFNQSxNQUFNRyxLQUFLLEdBQUc7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBRUQsU0FBU0MsSUFBSUEsQ0FBQ0MsSUFHYixFQUFnQjtFQUNmLE1BQU1DLEtBQTZCLEdBQUc7SUFDcEMsb0JBQW9CLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ25DQyxNQUFNLEVBQUUsQ0FBQztNQUNUQyxNQUFNLEVBQUU7UUFBRUMsTUFBTSxFQUFFLFNBQVM7UUFBRUMsT0FBTyxFQUFFO01BQVUsQ0FBQztNQUNqREMsVUFBVSxFQUFFLENBQUMsZ0JBQWdCLENBQUM7TUFDOUJDLE1BQU0sRUFBRSxDQUFDLENBQUM7TUFDVkMsS0FBSyxFQUFFLGlCQUFpQjtNQUN4QixJQUFJVixJQUFJLENBQUNXLFFBQVEsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQyxDQUFDO0lBQ0YsZ0NBQWdDLEVBQUViO0VBQ3BDLENBQUM7RUFDRCxLQUFLLE1BQU0sQ0FBQ2MsSUFBSSxFQUFFQyxNQUFNLENBQUMsSUFBSUMsTUFBTSxDQUFDQyxPQUFPLENBQUNmLElBQUksQ0FBQ2dCLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQ2pFZixLQUFLLENBQUMsa0JBQWtCVyxJQUFJLE1BQU0sQ0FBQyxHQUFHQyxNQUFNO0VBQzlDO0VBQ0EsT0FBTztJQUFFSSxJQUFJLEVBQUUsTUFBTTtJQUFFaEI7RUFBTSxDQUFDO0FBQ2hDO0FBRUEsSUFBQWlCLGdCQUFRLEVBQUMsOEJBQThCLEVBQUUsTUFBTTtFQUM3QyxJQUFBQyxVQUFFLEVBQUMsd0VBQXdFLEVBQUUsWUFBWTtJQUN2RixNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFBQyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLEVBQUV2QixJQUFJLENBQUM7TUFBRWlCLFNBQVMsRUFBRTtRQUFFTyxNQUFNLEVBQUU7TUFBYztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzdHLElBQUFDLGNBQU0sRUFBQ0osT0FBTyxDQUFDSyxtQkFBbUIsQ0FBQyxDQUFDQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQy9DLElBQUFGLGNBQU0sRUFBQ0osT0FBTyxDQUFDTyxZQUFZLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxXQUFXLElBQUlELENBQUMsQ0FBQ2pCLElBQUksS0FBSyxjQUFjLENBQUMsQ0FBQyxDQUFDYyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3hHLElBQUFGLGNBQU0sRUFBQ0osT0FBTyxDQUFDVyxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRCxDQUFDLENBQUM7RUFFRixJQUFBZCxVQUFFLEVBQUMsMkVBQTJFLEVBQUUsWUFBWTtJQUMxRixNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFDdEMsSUFBQUMsa0NBQWlCLEVBQUMsQ0FBQyxFQUNuQnZCLElBQUksQ0FBQztNQUFFaUIsU0FBUyxFQUFFO1FBQUVPLE1BQU0sRUFBRSxhQUFhO1FBQUVXLFlBQVksRUFBRTtNQUFnQztJQUFFLENBQUMsQ0FDOUYsQ0FBQztJQUNELElBQUFWLGNBQU0sRUFBQ0osT0FBTyxDQUFDSyxtQkFBbUIsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzlDLElBQUFGLGNBQU0sRUFBQ0osT0FBTyxDQUFDTyxZQUFZLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxXQUFXLElBQUlELENBQUMsQ0FBQ2pCLElBQUksS0FBSyxjQUFjLENBQUMsQ0FBQyxDQUFDYyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ3pHLElBQUFGLGNBQU0sRUFBQ0osT0FBTyxDQUFDTyxZQUFZLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxXQUFXLElBQUlELENBQUMsQ0FBQ2pCLElBQUksS0FBSyxjQUFjLENBQUMsQ0FBQyxDQUFDYyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzFHLENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQywrREFBK0QsRUFBRSxZQUFZO0lBQzlFO0lBQ0EsTUFBTWdCLFNBQVMsR0FBRyxNQUFNLElBQUFkLGlDQUFrQixFQUN4QyxJQUFBQyxrQ0FBaUIsRUFBQyxDQUFDLEVBQ25CdkIsSUFBSSxDQUFDO01BQUVpQixTQUFTLEVBQUU7UUFBRWtCLFlBQVksRUFBRSxvQkFBb0I7UUFBRUUsSUFBSSxFQUFFO01BQVk7SUFBRSxDQUFDLENBQy9FLENBQUM7SUFDRCxJQUFBWixjQUFNLEVBQUNXLFNBQVMsQ0FBQ0osS0FBSyxDQUFDSCxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUssVUFBVSxJQUFJRCxDQUFDLENBQUNRLElBQUksQ0FBQ0MsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQzs7SUFFaEc7SUFDQSxNQUFNYSxJQUFJLEdBQUcsTUFBTSxJQUFBbEIsaUNBQWtCLEVBQ25DLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFDbkJ2QixJQUFJLENBQUM7TUFBRWlCLFNBQVMsRUFBRTtRQUFFa0IsWUFBWSxFQUFFO01BQXFCO0lBQUUsQ0FBQyxDQUM1RCxDQUFDO0lBQ0QsSUFBQVYsY0FBTSxFQUFDZSxJQUFJLENBQUNSLEtBQUssQ0FBQyxDQUFDUyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzlCLElBQUFoQixjQUFNLEVBQUNlLElBQUksQ0FBQ2QsbUJBQW1CLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztFQUM3QyxDQUFDLENBQUM7RUFFRixJQUFBUCxVQUFFLEVBQUMsNkVBQTZFLEVBQUUsWUFBWTtJQUM1RixNQUFNQyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBa0IsRUFDdEMsSUFBQUMsa0NBQWlCLEVBQUMsQ0FBQyxFQUNuQnZCLElBQUksQ0FBQztNQUNIWSxRQUFRLEVBQUU7UUFBRThCLFdBQVcsRUFBRTtNQUFXLENBQUM7TUFDckN6QixTQUFTLEVBQUU7UUFBRTBCLFFBQVEsRUFBRSxnQ0FBZ0M7UUFBRW5CLE1BQU0sRUFBRTtNQUFjO0lBQ2pGLENBQUMsQ0FDSCxDQUFDO0lBQ0QsSUFBQUMsY0FBTSxFQUFDSixPQUFPLENBQUNLLG1CQUFtQixDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDOUMsSUFBQUYsY0FBTSxFQUFDSixPQUFPLENBQUNPLFlBQVksQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLFdBQVcsSUFBSUQsQ0FBQyxDQUFDakIsSUFBSSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUNjLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDckcsSUFBQUYsY0FBTSxFQUFDSixPQUFPLENBQUNXLEtBQUssQ0FBQ0gsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLFVBQVUsSUFBSUQsQ0FBQyxDQUFDUSxJQUFJLENBQUNDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUNaLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbEcsQ0FBQyxDQUFDO0VBRUYsSUFBQVAsVUFBRSxFQUFDLDhFQUE4RSxFQUFFLFlBQVk7SUFDN0YsTUFBTUMsT0FBTyxHQUFHLE1BQU0sSUFBQUMsaUNBQWtCLEVBQ3RDLElBQUFDLGtDQUFpQixFQUFDLENBQUMsRUFDbkJ2QixJQUFJLENBQUM7TUFBRWlCLFNBQVMsRUFBRTtRQUFFTyxNQUFNLEVBQUU7TUFBa0M7SUFBRSxDQUFDLENBQ25FLENBQUM7SUFDRCxNQUFNb0IsT0FBTyxHQUFHdkIsT0FBTyxDQUFDd0IsV0FBVyxDQUFDQyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxPQUFPLENBQUNULFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNuRixJQUFBZCxjQUFNLEVBQUNtQixPQUFPLENBQUMsQ0FBQ0ssV0FBVyxDQUFDLENBQUM7SUFDN0IsSUFBQXhCLGNBQU0sRUFBQ21CLE9BQU8sRUFBRU0sUUFBUSxDQUFDLENBQUN2QixJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3pDO0lBQ0EsSUFBQUYsY0FBTSxFQUFDSixPQUFPLENBQUN3QixXQUFXLENBQUNNLE1BQU0sQ0FBRUosQ0FBQyxJQUFLQSxDQUFDLENBQUNDLE9BQU8sQ0FBQ1QsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQ04sTUFBTSxDQUFDLENBQUNOLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDekcsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119