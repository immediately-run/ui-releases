"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Conflator", {
  enumerable: true,
  get: function () {
    return _conflation.Conflator;
  }
});
Object.defineProperty(exports, "FeedRuntime", {
  enumerable: true,
  get: function () {
    return _runtime.FeedRuntime;
  }
});
Object.defineProperty(exports, "RetentionBuffer", {
  enumerable: true,
  get: function () {
    return _buffer.RetentionBuffer;
  }
});
Object.defineProperty(exports, "checkBufferCoversWindows", {
  enumerable: true,
  get: function () {
    return _constraints.checkBufferCoversWindows;
  }
});
Object.defineProperty(exports, "frame", {
  enumerable: true,
  get: function () {
    return _frame.frame;
  }
});
Object.defineProperty(exports, "gapFrame", {
  enumerable: true,
  get: function () {
    return _frame.gapFrame;
  }
});
Object.defineProperty(exports, "manualConnector", {
  enumerable: true,
  get: function () {
    return _connector.manualConnector;
  }
});
Object.defineProperty(exports, "pollingConnector", {
  enumerable: true,
  get: function () {
    return _connector.pollingConnector;
  }
});
var _frame = require("./frame.ts");
var _buffer = require("./buffer.ts");
var _conflation = require("./conflation.ts");
var _constraints = require("./constraints.ts");
var _connector = require("./connector.ts");
var _runtime = require("./runtime.ts");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZnJhbWUiLCJyZXF1aXJlIiwiX2J1ZmZlciIsIl9jb25mbGF0aW9uIiwiX2NvbnN0cmFpbnRzIiwiX2Nvbm5lY3RvciIsIl9ydW50aW1lIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGZlZWQgZGF0YS1wbGFuZSBjb3JlIChBUkNISVRFQ1RVUkVfUExBTiDCpzUpIOKAlCB0aGUgcHVyZSwgb2ZmbGluZS10ZXN0YWJsZSBoYWxmIG9mIHRoZSBsaXZlXG4vLyBwbGFuZTogY29udGVudC1hZGRyZXNzZWQgZnJhbWVzLCB0aGUgY29ubmVjdG9yJ3MgcmV0ZW50aW9uIGJ1ZmZlciAoYGtlZXBMYXN0YC9ga2VlcEZvcmAgKyBnYXBcbi8vIG1hcmtlcnMpLCBrZWVwLWxhdGVzdCBjb25mbGF0aW9uIChzaGFyZWQgYnkgZmVlZHMgYW5kIHBhcmFtIGRyYWdzLCDCpzUuMyBGOCksIGFuZCB0aGUgc3RhdGljXG4vLyBidWZmZXLiiaV3aW5kb3cgY292ZXJhZ2UgY2hlY2suIFRoZSBgRmVlZFJ1bnRpbWVgIHB1Ymxpc2hlcyBlYWNoIGZlZWQgdHdpY2UgaW50byB0aGUgZW5naW5lOlxuLy8gdGhlIHNuYXBzaG90IChgZmVlZHMuPG5hbWU+YCwgdGhlIG5ld2VzdCBmcmFtZSdzIHJvd3MpIGFuZCB0aGUgcmV0YWluZWQgcm93c1xuLy8gKGBmZWVkQnVmZmVycy48bmFtZT5gKSwgd2hpY2ggdGhlIGVuZ2luZSdzIGlucHV0IHJlc29sdmVyIHNsaWNlcyBmb3IgYHsgZmVlZCwgd2luZG93IH1gXG4vLyBpbnB1dHMgKHNlZSBgc3JjL2VuZ2luZS9yZXNvbHZlLnRzYCkuIFRoZSBlZmZlY3RmdWwgaGFsZiDigJQgdGhlIHJlYWwgY29ubmVjdG9yIHJlYWxtXG4vLyAoc2NoZWR1bGVkL3N1YnNjcmlwdGlvbiBmZXRjaCB2aWEgdGhlIGhvc3QgU1NSRiBwcm94eSkgYW5kIHRoZSBPUEZTIG1hdGVyaWFsaXplLXRvLW1vdW50XG4vLyB0cmFuc3BvcnQg4oCUIHBsdWdzIGludG8gdGhlc2UgYXMgaW5qZWN0ZWQgcG9ydHMgaW4gYSBsYXRlciBpbmNyZW1lbnQgKHBsYXRmb3JtLWJsb2NrZWQpLlxuXG5leHBvcnQgeyBmcmFtZSwgZ2FwRnJhbWUgfSBmcm9tICcuL2ZyYW1lLnRzJztcbmV4cG9ydCB0eXBlIHsgRnJhbWUgfSBmcm9tICcuL2ZyYW1lLnRzJztcbmV4cG9ydCB7IFJldGVudGlvbkJ1ZmZlciB9IGZyb20gJy4vYnVmZmVyLnRzJztcbmV4cG9ydCB0eXBlIHsgUmV0ZW50aW9uUG9saWN5IH0gZnJvbSAnLi9idWZmZXIudHMnO1xuZXhwb3J0IHsgQ29uZmxhdG9yIH0gZnJvbSAnLi9jb25mbGF0aW9uLnRzJztcbmV4cG9ydCB7IGNoZWNrQnVmZmVyQ292ZXJzV2luZG93cyB9IGZyb20gJy4vY29uc3RyYWludHMudHMnO1xuZXhwb3J0IHR5cGUgeyBDb3ZlcmFnZVZpb2xhdGlvbiwgV2luZG93RGVjbCB9IGZyb20gJy4vY29uc3RyYWludHMudHMnO1xuZXhwb3J0IHsgbWFudWFsQ29ubmVjdG9yLCBwb2xsaW5nQ29ubmVjdG9yIH0gZnJvbSAnLi9jb25uZWN0b3IudHMnO1xuZXhwb3J0IHR5cGUgeyBDb25uZWN0b3IsIENvbm5lY3RvclNpbmssIFBvbGxpbmdPcHRpb25zIH0gZnJvbSAnLi9jb25uZWN0b3IudHMnO1xuZXhwb3J0IHsgRmVlZFJ1bnRpbWUgfSBmcm9tICcuL3J1bnRpbWUudHMnO1xuZXhwb3J0IHR5cGUgeyBGZWVkU3BlYywgRmVlZEVuZ2luZSwgRmVlZFJ1bnRpbWVEZXBzIH0gZnJvbSAnLi9ydW50aW1lLnRzJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFVQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFFQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxZQUFBLEdBQUFILE9BQUE7QUFFQSxJQUFBSSxVQUFBLEdBQUFKLE9BQUE7QUFFQSxJQUFBSyxRQUFBLEdBQUFMLE9BQUEiLCJpZ25vcmVMaXN0IjpbXX0=