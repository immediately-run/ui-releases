"use strict";

var _vitest = require("vitest");
var _suiteReport = require("./suiteReport.ts");
var _testrunner = require("./testrunner.ts");
// S4a — the in-platform document-test gate (`AXIS2_SELF_HOSTING_WORKITEMS` S4;
// roadmap R3-231).
//
// The item's acceptance is one sentence: "an author runs the workbook suite from the
// editor and sees the SAME verdicts the review surface shows — no terminal." So the
// load-bearing test is not that the counts add up; it is that the summary is a function
// of the very map `WorkbookPanelBody` renders from, and therefore cannot disagree with it.

const cell = id => ({
  id,
  worksheet: id.split('.')[0],
  cell: id.split('.')[1],
  doc: '',
  formulaSource: '() => 1',
  deps: [],
  externals: [],
  resolvers: []
});
const result = (subject, verdict) => [subject, {
  subject,
  verdict,
  outcomes: []
}];
(0, _vitest.describe)('summarizeSuite — the workbook-level answer', () => {
  (0, _vitest.it)('counts every verdict, and the counts sum to the cell count', () => {
    const cells = ['rev.a', 'rev.b', 'rev.c', 'rev.d'].map(cell);
    const results = new Map([result('rev.a', 'validated'), result('rev.b', 'pinned'), result('rev.c', 'failing')]);
    const r = (0, _suiteReport.summarizeSuite)(cells, results);
    (0, _vitest.expect)(r).toMatchObject({
      total: 4,
      validated: 1,
      pinned: 1,
      failing: 1,
      untested: 1,
      ok: false
    });
    (0, _vitest.expect)(r.validated + r.pinned + r.failing + r.untested).toBe(r.total);
    (0, _vitest.expect)(r.failingSubjects).toEqual(['rev.c']);
  });
  (0, _vitest.it)('a cell absent from the results is `untested` — the same thing the cards render', () => {
    // `WorkbookPanelBody` does `results?.get(cell.id)?.verdict ?? 'untested'`. If this
    // module chose a different default the summary and the cards would disagree about a
    // workbook that has never been run, which is the most common state of all.
    const r = (0, _suiteReport.summarizeSuite)([cell('rev.a')], new Map());
    (0, _vitest.expect)(r.untested).toBe(1);
    (0, _vitest.expect)((0, _suiteReport.summarizeSuite)([cell('rev.a')], null).untested).toBe(1);
  });
  (0, _vitest.it)('the summary uses the SAME verdicts the review surface shows — not a second classification', () => {
    // Drive it end-to-end from `classifyCell`, the §6 owner of the rule: whatever it says
    // about these outcomes is what the summary must count. If a second copy of the rule
    // ever appeared in `suiteReport`, this is the test that would catch the divergence.
    const outcomes = [{
      subject: 'rev.a',
      kinds: [{
        kind: 'metamorphic',
        pass: true
      }]
    }, {
      subject: 'rev.b',
      kinds: [{
        kind: 'specification',
        pass: true
      }]
    }, {
      subject: 'rev.c',
      kinds: [{
        kind: 'property',
        pass: false
      }]
    }];
    const results = new Map(outcomes.map(o => result(o.subject, (0, _testrunner.classifyCell)(o.kinds))));
    const r = (0, _suiteReport.summarizeSuite)(outcomes.map(o => cell(o.subject)), results);
    (0, _vitest.expect)(r.validated).toBe(1); // metamorphic
    (0, _vitest.expect)(r.pinned).toBe(1); // specification only — regression evidence, not validation
    (0, _vitest.expect)(r.failing).toBe(1);
  });
  (0, _vitest.it)('`ok` means nothing FAILED — it does not mean the workbook is covered', () => {
    // A workbook of entirely untested cells is green by this measure. That is honest
    // (nothing is broken) and it is why coverage is reported next to it rather than
    // folded into one number that would read as a pass.
    const r = (0, _suiteReport.summarizeSuite)(['rev.a', 'rev.b'].map(cell), new Map());
    (0, _vitest.expect)(r.ok).toBe(true);
    (0, _vitest.expect)(r.untested).toBe(2);
    (0, _vitest.expect)(r.line).toContain('2 untested');
  });
});
(0, _vitest.describe)('summaryLine — what the author actually reads', () => {
  const base = {
    total: 10,
    validated: 4,
    pinned: 3,
    untested: 3,
    failing: 0
  };
  (0, _vitest.it)('leads with the failure count when there is one', () => {
    const line = (0, _suiteReport.summaryLine)({
      ...base,
      failing: 2,
      untested: 1
    });
    (0, _vitest.expect)(line.startsWith('Suite failed — 2 failing')).toBe(true);
  });
  (0, _vitest.it)('keeps validated and pinned as separate words — never added together', () => {
    // §6's whole point: an inferred formula reproduces its own fitting data by
    // construction, so "7 tested" would be the theater the verdict rule prevents.
    const line = (0, _suiteReport.summaryLine)(base);
    (0, _vitest.expect)(line).toContain('4 validated');
    (0, _vitest.expect)(line).toContain('3 pinned');
    (0, _vitest.expect)(line).not.toContain('7 ');
  });
  (0, _vitest.it)('reports a mutation score only when one was measured', () => {
    (0, _vitest.expect)((0, _suiteReport.summaryLine)(base)).not.toContain('mutation');
    (0, _vitest.expect)((0, _suiteReport.summaryLine)({
      ...base,
      mutationScore: 0.62
    })).toContain('mutation 62%');
    // An absent score is absent, never a zero that would read as a measured 0%.
    (0, _vitest.expect)((0, _suiteReport.summaryLine)({
      ...base,
      mutationScore: 0
    })).toContain('mutation 0%');
  });
  (0, _vitest.it)('says something sensible for an empty workbook and for a single cell', () => {
    (0, _vitest.expect)((0, _suiteReport.summaryLine)({
      total: 0,
      validated: 0,
      pinned: 0,
      untested: 0,
      failing: 0
    })).toBe('No cells to test.');
    (0, _vitest.expect)((0, _suiteReport.summaryLine)({
      total: 1,
      validated: 1,
      pinned: 0,
      untested: 0,
      failing: 0
    })).toContain('of 1 cell.');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9zdWl0ZVJlcG9ydCIsIl90ZXN0cnVubmVyIiwiY2VsbCIsImlkIiwid29ya3NoZWV0Iiwic3BsaXQiLCJkb2MiLCJmb3JtdWxhU291cmNlIiwiZGVwcyIsImV4dGVybmFscyIsInJlc29sdmVycyIsInJlc3VsdCIsInN1YmplY3QiLCJ2ZXJkaWN0Iiwib3V0Y29tZXMiLCJkZXNjcmliZSIsIml0IiwiY2VsbHMiLCJtYXAiLCJyZXN1bHRzIiwiTWFwIiwiciIsInN1bW1hcml6ZVN1aXRlIiwiZXhwZWN0IiwidG9NYXRjaE9iamVjdCIsInRvdGFsIiwidmFsaWRhdGVkIiwicGlubmVkIiwiZmFpbGluZyIsInVudGVzdGVkIiwib2siLCJ0b0JlIiwiZmFpbGluZ1N1YmplY3RzIiwidG9FcXVhbCIsImtpbmRzIiwia2luZCIsInBhc3MiLCJvIiwiY2xhc3NpZnlDZWxsIiwibGluZSIsInRvQ29udGFpbiIsImJhc2UiLCJzdW1tYXJ5TGluZSIsInN0YXJ0c1dpdGgiLCJub3QiLCJtdXRhdGlvblNjb3JlIl0sInNvdXJjZXMiOlsic3VpdGVSZXBvcnQudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBTNGEg4oCUIHRoZSBpbi1wbGF0Zm9ybSBkb2N1bWVudC10ZXN0IGdhdGUgKGBBWElTMl9TRUxGX0hPU1RJTkdfV09SS0lURU1TYCBTNDtcbi8vIHJvYWRtYXAgUjMtMjMxKS5cbi8vXG4vLyBUaGUgaXRlbSdzIGFjY2VwdGFuY2UgaXMgb25lIHNlbnRlbmNlOiBcImFuIGF1dGhvciBydW5zIHRoZSB3b3JrYm9vayBzdWl0ZSBmcm9tIHRoZVxuLy8gZWRpdG9yIGFuZCBzZWVzIHRoZSBTQU1FIHZlcmRpY3RzIHRoZSByZXZpZXcgc3VyZmFjZSBzaG93cyDigJQgbm8gdGVybWluYWwuXCIgU28gdGhlXG4vLyBsb2FkLWJlYXJpbmcgdGVzdCBpcyBub3QgdGhhdCB0aGUgY291bnRzIGFkZCB1cDsgaXQgaXMgdGhhdCB0aGUgc3VtbWFyeSBpcyBhIGZ1bmN0aW9uXG4vLyBvZiB0aGUgdmVyeSBtYXAgYFdvcmtib29rUGFuZWxCb2R5YCByZW5kZXJzIGZyb20sIGFuZCB0aGVyZWZvcmUgY2Fubm90IGRpc2FncmVlIHdpdGggaXQuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBzdW1tYXJpemVTdWl0ZSwgc3VtbWFyeUxpbmUgfSBmcm9tICcuL3N1aXRlUmVwb3J0LnRzJztcbmltcG9ydCB7IGNsYXNzaWZ5Q2VsbCB9IGZyb20gJy4vdGVzdHJ1bm5lci50cyc7XG5pbXBvcnQgdHlwZSB7IENlbGxEZXNjcmlwdG9yLCBTdWJqZWN0UmVzdWx0IH0gZnJvbSAnLi93b3JrZXIvcHJvdG9jb2wudHMnO1xuXG5jb25zdCBjZWxsID0gKGlkOiBzdHJpbmcpOiBDZWxsRGVzY3JpcHRvciA9PiAoe1xuICBpZCxcbiAgd29ya3NoZWV0OiBpZC5zcGxpdCgnLicpWzBdLFxuICBjZWxsOiBpZC5zcGxpdCgnLicpWzFdLFxuICBkb2M6ICcnLFxuICBmb3JtdWxhU291cmNlOiAnKCkgPT4gMScsXG4gIGRlcHM6IFtdLFxuICBleHRlcm5hbHM6IFtdLFxuICByZXNvbHZlcnM6IFtdLFxufSk7XG5cbmNvbnN0IHJlc3VsdCA9IChzdWJqZWN0OiBzdHJpbmcsIHZlcmRpY3Q6IFN1YmplY3RSZXN1bHRbJ3ZlcmRpY3QnXSk6IFtzdHJpbmcsIFN1YmplY3RSZXN1bHRdID0+IFtcbiAgc3ViamVjdCxcbiAgeyBzdWJqZWN0LCB2ZXJkaWN0LCBvdXRjb21lczogW10gfSxcbl07XG5cbmRlc2NyaWJlKCdzdW1tYXJpemVTdWl0ZSDigJQgdGhlIHdvcmtib29rLWxldmVsIGFuc3dlcicsICgpID0+IHtcbiAgaXQoJ2NvdW50cyBldmVyeSB2ZXJkaWN0LCBhbmQgdGhlIGNvdW50cyBzdW0gdG8gdGhlIGNlbGwgY291bnQnLCAoKSA9PiB7XG4gICAgY29uc3QgY2VsbHMgPSBbJ3Jldi5hJywgJ3Jldi5iJywgJ3Jldi5jJywgJ3Jldi5kJ10ubWFwKGNlbGwpO1xuICAgIGNvbnN0IHJlc3VsdHMgPSBuZXcgTWFwKFtyZXN1bHQoJ3Jldi5hJywgJ3ZhbGlkYXRlZCcpLCByZXN1bHQoJ3Jldi5iJywgJ3Bpbm5lZCcpLCByZXN1bHQoJ3Jldi5jJywgJ2ZhaWxpbmcnKV0pO1xuICAgIGNvbnN0IHIgPSBzdW1tYXJpemVTdWl0ZShjZWxscywgcmVzdWx0cyk7XG4gICAgZXhwZWN0KHIpLnRvTWF0Y2hPYmplY3QoeyB0b3RhbDogNCwgdmFsaWRhdGVkOiAxLCBwaW5uZWQ6IDEsIGZhaWxpbmc6IDEsIHVudGVzdGVkOiAxLCBvazogZmFsc2UgfSk7XG4gICAgZXhwZWN0KHIudmFsaWRhdGVkICsgci5waW5uZWQgKyByLmZhaWxpbmcgKyByLnVudGVzdGVkKS50b0JlKHIudG90YWwpO1xuICAgIGV4cGVjdChyLmZhaWxpbmdTdWJqZWN0cykudG9FcXVhbChbJ3Jldi5jJ10pO1xuICB9KTtcblxuICBpdCgnYSBjZWxsIGFic2VudCBmcm9tIHRoZSByZXN1bHRzIGlzIGB1bnRlc3RlZGAg4oCUIHRoZSBzYW1lIHRoaW5nIHRoZSBjYXJkcyByZW5kZXInLCAoKSA9PiB7XG4gICAgLy8gYFdvcmtib29rUGFuZWxCb2R5YCBkb2VzIGByZXN1bHRzPy5nZXQoY2VsbC5pZCk/LnZlcmRpY3QgPz8gJ3VudGVzdGVkJ2AuIElmIHRoaXNcbiAgICAvLyBtb2R1bGUgY2hvc2UgYSBkaWZmZXJlbnQgZGVmYXVsdCB0aGUgc3VtbWFyeSBhbmQgdGhlIGNhcmRzIHdvdWxkIGRpc2FncmVlIGFib3V0IGFcbiAgICAvLyB3b3JrYm9vayB0aGF0IGhhcyBuZXZlciBiZWVuIHJ1biwgd2hpY2ggaXMgdGhlIG1vc3QgY29tbW9uIHN0YXRlIG9mIGFsbC5cbiAgICBjb25zdCByID0gc3VtbWFyaXplU3VpdGUoW2NlbGwoJ3Jldi5hJyldLCBuZXcgTWFwKCkpO1xuICAgIGV4cGVjdChyLnVudGVzdGVkKS50b0JlKDEpO1xuICAgIGV4cGVjdChzdW1tYXJpemVTdWl0ZShbY2VsbCgncmV2LmEnKV0sIG51bGwpLnVudGVzdGVkKS50b0JlKDEpO1xuICB9KTtcblxuICBpdCgndGhlIHN1bW1hcnkgdXNlcyB0aGUgU0FNRSB2ZXJkaWN0cyB0aGUgcmV2aWV3IHN1cmZhY2Ugc2hvd3Mg4oCUIG5vdCBhIHNlY29uZCBjbGFzc2lmaWNhdGlvbicsICgpID0+IHtcbiAgICAvLyBEcml2ZSBpdCBlbmQtdG8tZW5kIGZyb20gYGNsYXNzaWZ5Q2VsbGAsIHRoZSDCpzYgb3duZXIgb2YgdGhlIHJ1bGU6IHdoYXRldmVyIGl0IHNheXNcbiAgICAvLyBhYm91dCB0aGVzZSBvdXRjb21lcyBpcyB3aGF0IHRoZSBzdW1tYXJ5IG11c3QgY291bnQuIElmIGEgc2Vjb25kIGNvcHkgb2YgdGhlIHJ1bGVcbiAgICAvLyBldmVyIGFwcGVhcmVkIGluIGBzdWl0ZVJlcG9ydGAsIHRoaXMgaXMgdGhlIHRlc3QgdGhhdCB3b3VsZCBjYXRjaCB0aGUgZGl2ZXJnZW5jZS5cbiAgICBjb25zdCBvdXRjb21lcyA9IFtcbiAgICAgIHsgc3ViamVjdDogJ3Jldi5hJywga2luZHM6IFt7IGtpbmQ6ICdtZXRhbW9ycGhpYycgYXMgY29uc3QsIHBhc3M6IHRydWUgfV0gfSxcbiAgICAgIHsgc3ViamVjdDogJ3Jldi5iJywga2luZHM6IFt7IGtpbmQ6ICdzcGVjaWZpY2F0aW9uJyBhcyBjb25zdCwgcGFzczogdHJ1ZSB9XSB9LFxuICAgICAgeyBzdWJqZWN0OiAncmV2LmMnLCBraW5kczogW3sga2luZDogJ3Byb3BlcnR5JyBhcyBjb25zdCwgcGFzczogZmFsc2UgfV0gfSxcbiAgICBdO1xuICAgIGNvbnN0IHJlc3VsdHMgPSBuZXcgTWFwKG91dGNvbWVzLm1hcCgobykgPT4gcmVzdWx0KG8uc3ViamVjdCwgY2xhc3NpZnlDZWxsKG8ua2luZHMpKSkpO1xuICAgIGNvbnN0IHIgPSBzdW1tYXJpemVTdWl0ZShvdXRjb21lcy5tYXAoKG8pID0+IGNlbGwoby5zdWJqZWN0KSksIHJlc3VsdHMpO1xuICAgIGV4cGVjdChyLnZhbGlkYXRlZCkudG9CZSgxKTsgLy8gbWV0YW1vcnBoaWNcbiAgICBleHBlY3Qoci5waW5uZWQpLnRvQmUoMSk7IC8vIHNwZWNpZmljYXRpb24gb25seSDigJQgcmVncmVzc2lvbiBldmlkZW5jZSwgbm90IHZhbGlkYXRpb25cbiAgICBleHBlY3Qoci5mYWlsaW5nKS50b0JlKDEpO1xuICB9KTtcblxuICBpdCgnYG9rYCBtZWFucyBub3RoaW5nIEZBSUxFRCDigJQgaXQgZG9lcyBub3QgbWVhbiB0aGUgd29ya2Jvb2sgaXMgY292ZXJlZCcsICgpID0+IHtcbiAgICAvLyBBIHdvcmtib29rIG9mIGVudGlyZWx5IHVudGVzdGVkIGNlbGxzIGlzIGdyZWVuIGJ5IHRoaXMgbWVhc3VyZS4gVGhhdCBpcyBob25lc3RcbiAgICAvLyAobm90aGluZyBpcyBicm9rZW4pIGFuZCBpdCBpcyB3aHkgY292ZXJhZ2UgaXMgcmVwb3J0ZWQgbmV4dCB0byBpdCByYXRoZXIgdGhhblxuICAgIC8vIGZvbGRlZCBpbnRvIG9uZSBudW1iZXIgdGhhdCB3b3VsZCByZWFkIGFzIGEgcGFzcy5cbiAgICBjb25zdCByID0gc3VtbWFyaXplU3VpdGUoWydyZXYuYScsICdyZXYuYiddLm1hcChjZWxsKSwgbmV3IE1hcCgpKTtcbiAgICBleHBlY3Qoci5vaykudG9CZSh0cnVlKTtcbiAgICBleHBlY3Qoci51bnRlc3RlZCkudG9CZSgyKTtcbiAgICBleHBlY3Qoci5saW5lKS50b0NvbnRhaW4oJzIgdW50ZXN0ZWQnKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ3N1bW1hcnlMaW5lIOKAlCB3aGF0IHRoZSBhdXRob3IgYWN0dWFsbHkgcmVhZHMnLCAoKSA9PiB7XG4gIGNvbnN0IGJhc2UgPSB7IHRvdGFsOiAxMCwgdmFsaWRhdGVkOiA0LCBwaW5uZWQ6IDMsIHVudGVzdGVkOiAzLCBmYWlsaW5nOiAwIH07XG5cbiAgaXQoJ2xlYWRzIHdpdGggdGhlIGZhaWx1cmUgY291bnQgd2hlbiB0aGVyZSBpcyBvbmUnLCAoKSA9PiB7XG4gICAgY29uc3QgbGluZSA9IHN1bW1hcnlMaW5lKHsgLi4uYmFzZSwgZmFpbGluZzogMiwgdW50ZXN0ZWQ6IDEgfSk7XG4gICAgZXhwZWN0KGxpbmUuc3RhcnRzV2l0aCgnU3VpdGUgZmFpbGVkIOKAlCAyIGZhaWxpbmcnKSkudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoJ2tlZXBzIHZhbGlkYXRlZCBhbmQgcGlubmVkIGFzIHNlcGFyYXRlIHdvcmRzIOKAlCBuZXZlciBhZGRlZCB0b2dldGhlcicsICgpID0+IHtcbiAgICAvLyDCpzYncyB3aG9sZSBwb2ludDogYW4gaW5mZXJyZWQgZm9ybXVsYSByZXByb2R1Y2VzIGl0cyBvd24gZml0dGluZyBkYXRhIGJ5XG4gICAgLy8gY29uc3RydWN0aW9uLCBzbyBcIjcgdGVzdGVkXCIgd291bGQgYmUgdGhlIHRoZWF0ZXIgdGhlIHZlcmRpY3QgcnVsZSBwcmV2ZW50cy5cbiAgICBjb25zdCBsaW5lID0gc3VtbWFyeUxpbmUoYmFzZSk7XG4gICAgZXhwZWN0KGxpbmUpLnRvQ29udGFpbignNCB2YWxpZGF0ZWQnKTtcbiAgICBleHBlY3QobGluZSkudG9Db250YWluKCczIHBpbm5lZCcpO1xuICAgIGV4cGVjdChsaW5lKS5ub3QudG9Db250YWluKCc3ICcpO1xuICB9KTtcblxuICBpdCgncmVwb3J0cyBhIG11dGF0aW9uIHNjb3JlIG9ubHkgd2hlbiBvbmUgd2FzIG1lYXN1cmVkJywgKCkgPT4ge1xuICAgIGV4cGVjdChzdW1tYXJ5TGluZShiYXNlKSkubm90LnRvQ29udGFpbignbXV0YXRpb24nKTtcbiAgICBleHBlY3Qoc3VtbWFyeUxpbmUoeyAuLi5iYXNlLCBtdXRhdGlvblNjb3JlOiAwLjYyIH0pKS50b0NvbnRhaW4oJ211dGF0aW9uIDYyJScpO1xuICAgIC8vIEFuIGFic2VudCBzY29yZSBpcyBhYnNlbnQsIG5ldmVyIGEgemVybyB0aGF0IHdvdWxkIHJlYWQgYXMgYSBtZWFzdXJlZCAwJS5cbiAgICBleHBlY3Qoc3VtbWFyeUxpbmUoeyAuLi5iYXNlLCBtdXRhdGlvblNjb3JlOiAwIH0pKS50b0NvbnRhaW4oJ211dGF0aW9uIDAlJyk7XG4gIH0pO1xuXG4gIGl0KCdzYXlzIHNvbWV0aGluZyBzZW5zaWJsZSBmb3IgYW4gZW1wdHkgd29ya2Jvb2sgYW5kIGZvciBhIHNpbmdsZSBjZWxsJywgKCkgPT4ge1xuICAgIGV4cGVjdChzdW1tYXJ5TGluZSh7IHRvdGFsOiAwLCB2YWxpZGF0ZWQ6IDAsIHBpbm5lZDogMCwgdW50ZXN0ZWQ6IDAsIGZhaWxpbmc6IDAgfSkpLnRvQmUoJ05vIGNlbGxzIHRvIHRlc3QuJyk7XG4gICAgZXhwZWN0KHN1bW1hcnlMaW5lKHsgdG90YWw6IDEsIHZhbGlkYXRlZDogMSwgcGlubmVkOiAwLCB1bnRlc3RlZDogMCwgZmFpbGluZzogMCB9KSkudG9Db250YWluKCdvZiAxIGNlbGwuJyk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBT0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBTUEsTUFBTUcsSUFBSSxHQUFJQyxFQUFVLEtBQXNCO0VBQzVDQSxFQUFFO0VBQ0ZDLFNBQVMsRUFBRUQsRUFBRSxDQUFDRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzNCSCxJQUFJLEVBQUVDLEVBQUUsQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN0QkMsR0FBRyxFQUFFLEVBQUU7RUFDUEMsYUFBYSxFQUFFLFNBQVM7RUFDeEJDLElBQUksRUFBRSxFQUFFO0VBQ1JDLFNBQVMsRUFBRSxFQUFFO0VBQ2JDLFNBQVMsRUFBRTtBQUNiLENBQUMsQ0FBQztBQUVGLE1BQU1DLE1BQU0sR0FBR0EsQ0FBQ0MsT0FBZSxFQUFFQyxPQUFpQyxLQUE4QixDQUM5RkQsT0FBTyxFQUNQO0VBQUVBLE9BQU87RUFBRUMsT0FBTztFQUFFQyxRQUFRLEVBQUU7QUFBRyxDQUFDLENBQ25DO0FBRUQsSUFBQUMsZ0JBQVEsRUFBQyw0Q0FBNEMsRUFBRSxNQUFNO0VBQzNELElBQUFDLFVBQUUsRUFBQyw0REFBNEQsRUFBRSxNQUFNO0lBQ3JFLE1BQU1DLEtBQUssR0FBRyxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDQyxHQUFHLENBQUNoQixJQUFJLENBQUM7SUFDNUQsTUFBTWlCLE9BQU8sR0FBRyxJQUFJQyxHQUFHLENBQUMsQ0FBQ1QsTUFBTSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsRUFBRUEsTUFBTSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBRUEsTUFBTSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQzlHLE1BQU1VLENBQUMsR0FBRyxJQUFBQywyQkFBYyxFQUFDTCxLQUFLLEVBQUVFLE9BQU8sQ0FBQztJQUN4QyxJQUFBSSxjQUFNLEVBQUNGLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUM7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsU0FBUyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsT0FBTyxFQUFFLENBQUM7TUFBRUMsUUFBUSxFQUFFLENBQUM7TUFBRUMsRUFBRSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQ2xHLElBQUFQLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDSyxTQUFTLEdBQUdMLENBQUMsQ0FBQ00sTUFBTSxHQUFHTixDQUFDLENBQUNPLE9BQU8sR0FBR1AsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ0UsSUFBSSxDQUFDVixDQUFDLENBQUNJLEtBQUssQ0FBQztJQUNyRSxJQUFBRixjQUFNLEVBQUNGLENBQUMsQ0FBQ1csZUFBZSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0VBQzlDLENBQUMsQ0FBQztFQUVGLElBQUFqQixVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsTUFBTTtJQUN6RjtJQUNBO0lBQ0E7SUFDQSxNQUFNSyxDQUFDLEdBQUcsSUFBQUMsMkJBQWMsRUFBQyxDQUFDcEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsSUFBSWtCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDcEQsSUFBQUcsY0FBTSxFQUFDRixDQUFDLENBQUNRLFFBQVEsQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzFCLElBQUFSLGNBQU0sRUFBQyxJQUFBRCwyQkFBYyxFQUFDLENBQUNwQixJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzJCLFFBQVEsQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2hFLENBQUMsQ0FBQztFQUVGLElBQUFmLFVBQUUsRUFBQywyRkFBMkYsRUFBRSxNQUFNO0lBQ3BHO0lBQ0E7SUFDQTtJQUNBLE1BQU1GLFFBQVEsR0FBRyxDQUNmO01BQUVGLE9BQU8sRUFBRSxPQUFPO01BQUVzQixLQUFLLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUUsYUFBc0I7UUFBRUMsSUFBSSxFQUFFO01BQUssQ0FBQztJQUFFLENBQUMsRUFDM0U7TUFBRXhCLE9BQU8sRUFBRSxPQUFPO01BQUVzQixLQUFLLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUUsZUFBd0I7UUFBRUMsSUFBSSxFQUFFO01BQUssQ0FBQztJQUFFLENBQUMsRUFDN0U7TUFBRXhCLE9BQU8sRUFBRSxPQUFPO01BQUVzQixLQUFLLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUUsVUFBbUI7UUFBRUMsSUFBSSxFQUFFO01BQU0sQ0FBQztJQUFFLENBQUMsQ0FDMUU7SUFDRCxNQUFNakIsT0FBTyxHQUFHLElBQUlDLEdBQUcsQ0FBQ04sUUFBUSxDQUFDSSxHQUFHLENBQUVtQixDQUFDLElBQUsxQixNQUFNLENBQUMwQixDQUFDLENBQUN6QixPQUFPLEVBQUUsSUFBQTBCLHdCQUFZLEVBQUNELENBQUMsQ0FBQ0gsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RGLE1BQU1iLENBQUMsR0FBRyxJQUFBQywyQkFBYyxFQUFDUixRQUFRLENBQUNJLEdBQUcsQ0FBRW1CLENBQUMsSUFBS25DLElBQUksQ0FBQ21DLENBQUMsQ0FBQ3pCLE9BQU8sQ0FBQyxDQUFDLEVBQUVPLE9BQU8sQ0FBQztJQUN2RSxJQUFBSSxjQUFNLEVBQUNGLENBQUMsQ0FBQ0ssU0FBUyxDQUFDLENBQUNLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzdCLElBQUFSLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDTSxNQUFNLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUIsSUFBQVIsY0FBTSxFQUFDRixDQUFDLENBQUNPLE9BQU8sQ0FBQyxDQUFDRyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzNCLENBQUMsQ0FBQztFQUVGLElBQUFmLFVBQUUsRUFBQyxzRUFBc0UsRUFBRSxNQUFNO0lBQy9FO0lBQ0E7SUFDQTtJQUNBLE1BQU1LLENBQUMsR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDSixHQUFHLENBQUNoQixJQUFJLENBQUMsRUFBRSxJQUFJa0IsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUNqRSxJQUFBRyxjQUFNLEVBQUNGLENBQUMsQ0FBQ1MsRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDdkIsSUFBQVIsY0FBTSxFQUFDRixDQUFDLENBQUNRLFFBQVEsQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzFCLElBQUFSLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDa0IsSUFBSSxDQUFDLENBQUNDLFNBQVMsQ0FBQyxZQUFZLENBQUM7RUFDeEMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQXpCLGdCQUFRLEVBQUMsOENBQThDLEVBQUUsTUFBTTtFQUM3RCxNQUFNMEIsSUFBSSxHQUFHO0lBQUVoQixLQUFLLEVBQUUsRUFBRTtJQUFFQyxTQUFTLEVBQUUsQ0FBQztJQUFFQyxNQUFNLEVBQUUsQ0FBQztJQUFFRSxRQUFRLEVBQUUsQ0FBQztJQUFFRCxPQUFPLEVBQUU7RUFBRSxDQUFDO0VBRTVFLElBQUFaLFVBQUUsRUFBQyxnREFBZ0QsRUFBRSxNQUFNO0lBQ3pELE1BQU11QixJQUFJLEdBQUcsSUFBQUcsd0JBQVcsRUFBQztNQUFFLEdBQUdELElBQUk7TUFBRWIsT0FBTyxFQUFFLENBQUM7TUFBRUMsUUFBUSxFQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQzlELElBQUFOLGNBQU0sRUFBQ2dCLElBQUksQ0FBQ0ksVUFBVSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRSxDQUFDLENBQUM7RUFFRixJQUFBZixVQUFFLEVBQUMscUVBQXFFLEVBQUUsTUFBTTtJQUM5RTtJQUNBO0lBQ0EsTUFBTXVCLElBQUksR0FBRyxJQUFBRyx3QkFBVyxFQUFDRCxJQUFJLENBQUM7SUFDOUIsSUFBQWxCLGNBQU0sRUFBQ2dCLElBQUksQ0FBQyxDQUFDQyxTQUFTLENBQUMsYUFBYSxDQUFDO0lBQ3JDLElBQUFqQixjQUFNLEVBQUNnQixJQUFJLENBQUMsQ0FBQ0MsU0FBUyxDQUFDLFVBQVUsQ0FBQztJQUNsQyxJQUFBakIsY0FBTSxFQUFDZ0IsSUFBSSxDQUFDLENBQUNLLEdBQUcsQ0FBQ0osU0FBUyxDQUFDLElBQUksQ0FBQztFQUNsQyxDQUFDLENBQUM7RUFFRixJQUFBeEIsVUFBRSxFQUFDLHFEQUFxRCxFQUFFLE1BQU07SUFDOUQsSUFBQU8sY0FBTSxFQUFDLElBQUFtQix3QkFBVyxFQUFDRCxJQUFJLENBQUMsQ0FBQyxDQUFDRyxHQUFHLENBQUNKLFNBQVMsQ0FBQyxVQUFVLENBQUM7SUFDbkQsSUFBQWpCLGNBQU0sRUFBQyxJQUFBbUIsd0JBQVcsRUFBQztNQUFFLEdBQUdELElBQUk7TUFBRUksYUFBYSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUMvRTtJQUNBLElBQUFqQixjQUFNLEVBQUMsSUFBQW1CLHdCQUFXLEVBQUM7TUFBRSxHQUFHRCxJQUFJO01BQUVJLGFBQWEsRUFBRTtJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNMLFNBQVMsQ0FBQyxhQUFhLENBQUM7RUFDN0UsQ0FBQyxDQUFDO0VBRUYsSUFBQXhCLFVBQUUsRUFBQyxxRUFBcUUsRUFBRSxNQUFNO0lBQzlFLElBQUFPLGNBQU0sRUFBQyxJQUFBbUIsd0JBQVcsRUFBQztNQUFFakIsS0FBSyxFQUFFLENBQUM7TUFBRUMsU0FBUyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUUsUUFBUSxFQUFFLENBQUM7TUFBRUQsT0FBTyxFQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0csSUFBSSxDQUFDLG1CQUFtQixDQUFDO0lBQzdHLElBQUFSLGNBQU0sRUFBQyxJQUFBbUIsd0JBQVcsRUFBQztNQUFFakIsS0FBSyxFQUFFLENBQUM7TUFBRUMsU0FBUyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUUsUUFBUSxFQUFFLENBQUM7TUFBRUQsT0FBTyxFQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ1ksU0FBUyxDQUFDLFlBQVksQ0FBQztFQUM3RyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=