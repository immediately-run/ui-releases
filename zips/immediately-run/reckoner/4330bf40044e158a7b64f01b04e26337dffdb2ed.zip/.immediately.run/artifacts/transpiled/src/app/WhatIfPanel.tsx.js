var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _useShadowRunner = require("../hooks/useShadowRunner.ts");
var _WhatIfResult = _interopRequireDefault(require("./WhatIfResult.tsx"));
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The inspector's "What if" section (WHATIF_SHADOW_EVALUATION_SPEC §1.1) — the effectful
// shell: an editable formula variant (session-scoped text, owned by App per §1.4 so
// closing the inspector never destroys an edit), an explicit Run through the shadow
// runner, the WhatIfResult readout, and Discard. Ephemeral by construction: no apply, no
// write path (§7 — the document here is read-only, and the spec says the affordance must
// explain itself rather than dangle a dead button).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function WhatIfPanel({
  session,
  cell,
  baseVerdicts,
  text,
  onTextChange
}) {
  _s();
  const {
    outcome,
    running,
    run,
    reset
  } = (0, _useShadowRunner.useShadowRunner)(session);

  // A different inspected cell means a different counterfactual: drop the stale readout
  // (the variant text itself is per-cell app state and survives).
  (0, _react.useEffect)(() => {
    reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cell.id]);
  const edited = text !== cell.formulaSource;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-wi",
    "aria-label": `What if for ${cell.id}`,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-ins-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "rk-ins-label",
        children: "what if"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("textarea", {
        className: "rk-wi-editor",
        value: text,
        rows: Math.min(10, Math.max(3, text.split('\n').length)),
        spellCheck: false,
        "aria-label": `Formula variant for ${cell.id}`,
        onChange: e => onTextChange(cell.id, e.target.value)
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-wi-actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-wb-run",
          onClick: () => run({
            variants: {
              [cell.id]: text
            }
          }, baseVerdicts),
          disabled: running,
          children: running ? 'Running…' : 'Run'
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-wb-close",
          onClick: () => {
            reset();
            onTextChange(cell.id, cell.formulaSource);
          },
          disabled: running || !edited && outcome === null,
          children: "Discard"
        })]
      }), outcome !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WhatIfResult.default, {
        outcome: outcome,
        cellId: cell.id
      }), outcome === null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-wi-note",
        children: "edit the formula and run to see the counterfactual \u2014 results are never saved to the document."
      })]
    })
  });
}
_s(WhatIfPanel, "S0LVgOnRN0pjaI1QmEGeX+7pHkc=", false, function () {
  return [_useShadowRunner.useShadowRunner];
});
_c = WhatIfPanel;
var _default = exports.default = WhatIfPanel;
var _c;
$RefreshReg$(_c, "WhatIfPanel");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZVNoYWRvd1J1bm5lciIsIl9XaGF0SWZSZXN1bHQiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIldoYXRJZlBhbmVsIiwic2Vzc2lvbiIsImNlbGwiLCJiYXNlVmVyZGljdHMiLCJ0ZXh0Iiwib25UZXh0Q2hhbmdlIiwib3V0Y29tZSIsInJ1bm5pbmciLCJydW4iLCJyZXNldCIsInVzZVNoYWRvd1J1bm5lciIsInVzZUVmZmVjdCIsImlkIiwiZWRpdGVkIiwiZm9ybXVsYVNvdXJjZSIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4cyIsInZhbHVlIiwicm93cyIsIk1hdGgiLCJtaW4iLCJtYXgiLCJzcGxpdCIsImxlbmd0aCIsInNwZWxsQ2hlY2siLCJvbkNoYW5nZSIsInRhcmdldCIsInR5cGUiLCJvbkNsaWNrIiwidmFyaWFudHMiLCJkaXNhYmxlZCIsImNlbGxJZCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV2hhdElmUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBpbnNwZWN0b3IncyBcIldoYXQgaWZcIiBzZWN0aW9uIChXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQyDCpzEuMSkg4oCUIHRoZSBlZmZlY3RmdWxcbi8vIHNoZWxsOiBhbiBlZGl0YWJsZSBmb3JtdWxhIHZhcmlhbnQgKHNlc3Npb24tc2NvcGVkIHRleHQsIG93bmVkIGJ5IEFwcCBwZXIgwqcxLjQgc29cbi8vIGNsb3NpbmcgdGhlIGluc3BlY3RvciBuZXZlciBkZXN0cm95cyBhbiBlZGl0KSwgYW4gZXhwbGljaXQgUnVuIHRocm91Z2ggdGhlIHNoYWRvd1xuLy8gcnVubmVyLCB0aGUgV2hhdElmUmVzdWx0IHJlYWRvdXQsIGFuZCBEaXNjYXJkLiBFcGhlbWVyYWwgYnkgY29uc3RydWN0aW9uOiBubyBhcHBseSwgbm9cbi8vIHdyaXRlIHBhdGggKMKnNyDigJQgdGhlIGRvY3VtZW50IGhlcmUgaXMgcmVhZC1vbmx5LCBhbmQgdGhlIHNwZWMgc2F5cyB0aGUgYWZmb3JkYW5jZSBtdXN0XG4vLyBleHBsYWluIGl0c2VsZiByYXRoZXIgdGhhbiBkYW5nbGUgYSBkZWFkIGJ1dHRvbikuXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdHlwZSB7IENlbGxEZXNjcmlwdG9yLCBTdWJqZWN0UmVzdWx0IH0gZnJvbSAnLi4vZW5naW5lL3dvcmtlci9wcm90b2NvbC50cyc7XG5pbXBvcnQgeyB1c2VTaGFkb3dSdW5uZXIgfSBmcm9tICcuLi9ob29rcy91c2VTaGFkb3dSdW5uZXIudHMnO1xuaW1wb3J0IHR5cGUgeyBSZXBvcnRTZXNzaW9uIH0gZnJvbSAnLi9yZXBvcnRTZXNzaW9uLnRzJztcbmltcG9ydCBXaGF0SWZSZXN1bHQgZnJvbSAnLi9XaGF0SWZSZXN1bHQudHN4JztcbmltcG9ydCAnLi93b3JrYm9vay1wYW5lbC5jc3MnO1xuXG5pbnRlcmZhY2UgV2hhdElmUGFuZWxQcm9wcyB7XG4gIHNlc3Npb246IFJlcG9ydFNlc3Npb247XG4gIGNlbGw6IENlbGxEZXNjcmlwdG9yO1xuICAvKiogVGhlIHJldmlldyBzdXJmYWNlJ3MgY3VycmVudCBzdWl0ZSByZXN1bHRzIOKAlCB2ZXJkaWN0IGZsaXBzIGRpZmYgYWdhaW5zdCB0aGVzZS4gKi9cbiAgYmFzZVZlcmRpY3RzOiBSZWFkb25seU1hcDxzdHJpbmcsIFN1YmplY3RSZXN1bHQ+IHwgbnVsbDtcbiAgLyoqIFRoZSBzZXNzaW9uLXNjb3BlZCB2YXJpYW50IHRleHQgZm9yIHRoaXMgY2VsbCAoQXBwIG93bnMgaXQ7IMKnMS40KS4gKi9cbiAgdGV4dDogc3RyaW5nO1xuICBvblRleHRDaGFuZ2U6IChjZWxsSWQ6IHN0cmluZywgdGV4dDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBXaGF0SWZQYW5lbCh7IHNlc3Npb24sIGNlbGwsIGJhc2VWZXJkaWN0cywgdGV4dCwgb25UZXh0Q2hhbmdlIH06IFdoYXRJZlBhbmVsUHJvcHMpIHtcbiAgY29uc3QgeyBvdXRjb21lLCBydW5uaW5nLCBydW4sIHJlc2V0IH0gPSB1c2VTaGFkb3dSdW5uZXIoc2Vzc2lvbik7XG5cbiAgLy8gQSBkaWZmZXJlbnQgaW5zcGVjdGVkIGNlbGwgbWVhbnMgYSBkaWZmZXJlbnQgY291bnRlcmZhY3R1YWw6IGRyb3AgdGhlIHN0YWxlIHJlYWRvdXRcbiAgLy8gKHRoZSB2YXJpYW50IHRleHQgaXRzZWxmIGlzIHBlci1jZWxsIGFwcCBzdGF0ZSBhbmQgc3Vydml2ZXMpLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlc2V0KCk7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbY2VsbC5pZF0pO1xuXG4gIGNvbnN0IGVkaXRlZCA9IHRleHQgIT09IGNlbGwuZm9ybXVsYVNvdXJjZTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2lcIiBhcmlhLWxhYmVsPXtgV2hhdCBpZiBmb3IgJHtjZWxsLmlkfWB9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1pbnMtcm93XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWlucy1sYWJlbFwiPndoYXQgaWY8L3NwYW4+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIGNsYXNzTmFtZT1cInJrLXdpLWVkaXRvclwiXG4gICAgICAgICAgdmFsdWU9e3RleHR9XG4gICAgICAgICAgcm93cz17TWF0aC5taW4oMTAsIE1hdGgubWF4KDMsIHRleHQuc3BsaXQoJ1xcbicpLmxlbmd0aCkpfVxuICAgICAgICAgIHNwZWxsQ2hlY2s9e2ZhbHNlfVxuICAgICAgICAgIGFyaWEtbGFiZWw9e2BGb3JtdWxhIHZhcmlhbnQgZm9yICR7Y2VsbC5pZH1gfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25UZXh0Q2hhbmdlKGNlbGwuaWQsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1hY3Rpb25zXCI+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmstd2ItcnVuXCIgb25DbGljaz17KCkgPT4gcnVuKHsgdmFyaWFudHM6IHsgW2NlbGwuaWRdOiB0ZXh0IH0gfSwgYmFzZVZlcmRpY3RzKX0gZGlzYWJsZWQ9e3J1bm5pbmd9PlxuICAgICAgICAgICAge3J1bm5pbmcgPyAnUnVubmluZ+KApicgOiAnUnVuJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgcmVzZXQoKTtcbiAgICAgICAgICAgICAgb25UZXh0Q2hhbmdlKGNlbGwuaWQsIGNlbGwuZm9ybXVsYVNvdXJjZSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgZGlzYWJsZWQ9e3J1bm5pbmcgfHwgKCFlZGl0ZWQgJiYgb3V0Y29tZSA9PT0gbnVsbCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgRGlzY2FyZFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge291dGNvbWUgIT09IG51bGwgJiYgPFdoYXRJZlJlc3VsdCBvdXRjb21lPXtvdXRjb21lfSBjZWxsSWQ9e2NlbGwuaWR9IC8+fVxuICAgICAgICB7b3V0Y29tZSA9PT0gbnVsbCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1ub3RlXCI+XG4gICAgICAgICAgICBlZGl0IHRoZSBmb3JtdWxhIGFuZCBydW4gdG8gc2VlIHRoZSBjb3VudGVyZmFjdHVhbCDigJQgcmVzdWx0cyBhcmUgbmV2ZXIgc2F2ZWQgdG8gdGhlIGRvY3VtZW50LlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFdoYXRJZlBhbmVsO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFFQSxJQUFBQyxnQkFBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsYUFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0FBLE9BQUE7QUFBOEIsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsSUFBQUssRUFBQSxHQUFBQyxZQUFBLElBWDlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBa0JBLFNBQVNHLFdBQVdBLENBQUM7RUFBRUMsT0FBTztFQUFFQyxJQUFJO0VBQUVDLFlBQVk7RUFBRUMsSUFBSTtFQUFFQztBQUErQixDQUFDLEVBQUU7RUFBQVYsRUFBQTtFQUMxRixNQUFNO0lBQUVXLE9BQU87SUFBRUMsT0FBTztJQUFFQyxHQUFHO0lBQUVDO0VBQU0sQ0FBQyxHQUFHLElBQUFDLGdDQUFlLEVBQUNULE9BQU8sQ0FBQzs7RUFFakU7RUFDQTtFQUNBLElBQUFVLGdCQUFTLEVBQUMsTUFBTTtJQUNkRixLQUFLLENBQUMsQ0FBQztJQUNQO0VBQ0YsQ0FBQyxFQUFFLENBQUNQLElBQUksQ0FBQ1UsRUFBRSxDQUFDLENBQUM7RUFFYixNQUFNQyxNQUFNLEdBQUdULElBQUksS0FBS0YsSUFBSSxDQUFDWSxhQUFhO0VBRTFDLG9CQUNFLElBQUFwQixXQUFBLENBQUFxQixHQUFBO0lBQUtDLFNBQVMsRUFBQyxPQUFPO0lBQUMsY0FBWSxlQUFlZCxJQUFJLENBQUNVLEVBQUUsRUFBRztJQUFBSyxRQUFBLGVBQzFELElBQUF2QixXQUFBLENBQUF3QixJQUFBO01BQUtGLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUF2QixXQUFBLENBQUFxQixHQUFBO1FBQU1DLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFBQztNQUFPLENBQU0sQ0FBQyxlQUM3QyxJQUFBdkIsV0FBQSxDQUFBcUIsR0FBQTtRQUNFQyxTQUFTLEVBQUMsY0FBYztRQUN4QkcsS0FBSyxFQUFFZixJQUFLO1FBQ1pnQixJQUFJLEVBQUVDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLEVBQUUsRUFBRUQsSUFBSSxDQUFDRSxHQUFHLENBQUMsQ0FBQyxFQUFFbkIsSUFBSSxDQUFDb0IsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBRTtRQUN6REMsVUFBVSxFQUFFLEtBQU07UUFDbEIsY0FBWSx1QkFBdUJ4QixJQUFJLENBQUNVLEVBQUUsRUFBRztRQUM3Q2UsUUFBUSxFQUFHOUIsQ0FBQyxJQUFLUSxZQUFZLENBQUNILElBQUksQ0FBQ1UsRUFBRSxFQUFFZixDQUFDLENBQUMrQixNQUFNLENBQUNULEtBQUs7TUFBRSxDQUN4RCxDQUFDLGVBQ0YsSUFBQXpCLFdBQUEsQ0FBQXdCLElBQUE7UUFBS0YsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxnQkFDNUIsSUFBQXZCLFdBQUEsQ0FBQXFCLEdBQUE7VUFBUWMsSUFBSSxFQUFDLFFBQVE7VUFBQ2IsU0FBUyxFQUFDLFdBQVc7VUFBQ2MsT0FBTyxFQUFFQSxDQUFBLEtBQU10QixHQUFHLENBQUM7WUFBRXVCLFFBQVEsRUFBRTtjQUFFLENBQUM3QixJQUFJLENBQUNVLEVBQUUsR0FBR1I7WUFBSztVQUFFLENBQUMsRUFBRUQsWUFBWSxDQUFFO1VBQUM2QixRQUFRLEVBQUV6QixPQUFRO1VBQUFVLFFBQUEsRUFDaElWLE9BQU8sR0FBRyxVQUFVLEdBQUc7UUFBSyxDQUN2QixDQUFDLGVBQ1QsSUFBQWIsV0FBQSxDQUFBcUIsR0FBQTtVQUNFYyxJQUFJLEVBQUMsUUFBUTtVQUNiYixTQUFTLEVBQUMsYUFBYTtVQUN2QmMsT0FBTyxFQUFFQSxDQUFBLEtBQU07WUFDYnJCLEtBQUssQ0FBQyxDQUFDO1lBQ1BKLFlBQVksQ0FBQ0gsSUFBSSxDQUFDVSxFQUFFLEVBQUVWLElBQUksQ0FBQ1ksYUFBYSxDQUFDO1VBQzNDLENBQUU7VUFDRmtCLFFBQVEsRUFBRXpCLE9BQU8sSUFBSyxDQUFDTSxNQUFNLElBQUlQLE9BQU8sS0FBSyxJQUFNO1VBQUFXLFFBQUEsRUFDcEQ7UUFFRCxDQUFRLENBQUM7TUFBQSxDQUNOLENBQUMsRUFDTFgsT0FBTyxLQUFLLElBQUksaUJBQUksSUFBQVosV0FBQSxDQUFBcUIsR0FBQSxFQUFDdkIsYUFBQSxDQUFBTyxPQUFZO1FBQUNPLE9BQU8sRUFBRUEsT0FBUTtRQUFDMkIsTUFBTSxFQUFFL0IsSUFBSSxDQUFDVTtNQUFHLENBQUUsQ0FBQyxFQUN2RU4sT0FBTyxLQUFLLElBQUksaUJBQ2YsSUFBQVosV0FBQSxDQUFBcUIsR0FBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLEVBQUM7TUFFNUIsQ0FBSyxDQUNOO0lBQUEsQ0FDRTtFQUFDLENBQ0gsQ0FBQztBQUVWO0FBQUN0QixFQUFBLENBakRRSyxXQUFXO0VBQUEsUUFDdUJVLGdDQUFlO0FBQUE7QUFBQXdCLEVBQUEsR0FEakRsQyxXQUFXO0FBQUEsSUFBQW1DLFFBQUEsR0FBQUMsT0FBQSxDQUFBckMsT0FBQSxHQW1ETEMsV0FBVztBQUFBLElBQUFrQyxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}