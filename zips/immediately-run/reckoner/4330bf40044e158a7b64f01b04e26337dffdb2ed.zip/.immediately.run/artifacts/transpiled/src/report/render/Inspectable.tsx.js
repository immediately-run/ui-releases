var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _inspectionContext = require("./inspectionContext.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The on-pixel inspection affordance (V3): "a quiet affordance on every bound element —
// hover-reveal desktop, long-press touch — faint enough not to tax run mode." This wrapper
// renders its children bare unless the inspection port is provided; with it, a small overlay
// button appears on hover / keyboard focus (desktop) and a ~450ms press opens it directly
// (touch, where there is no hover). One component per file, default export (repo rule).
function Inspectable({
  source,
  children
}) {
  _s();
  const port = (0, _react.useContext)(_inspectionContext.InspectionContext);
  const timer = (0, _react.useRef)(null);
  if (port === null || !port.canInspect(source)) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_jsxRuntime.Fragment, {
    children: children
  });
  const cancelPress = () => {
    if (timer.current !== null) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-inspectable",
    "data-source": source,
    onPointerDown: e => {
      // Touch long-press opens directly — there is no hover to reveal into.
      if (e.pointerType === 'touch') {
        cancelPress();
        timer.current = setTimeout(() => port.onInspect(source), 450);
      }
    },
    onPointerUp: cancelPress,
    onPointerCancel: cancelPress,
    onPointerLeave: cancelPress,
    children: [children, /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "rk-inspect-btn",
      "aria-label": `Inspect ${source}`,
      onClick: () => port.onInspect(source),
      children: "\u2315"
    })]
  });
}
_s(Inspectable, "gx3xEbXDJKUgUdSv++BW9rJ54oc=");
_c = Inspectable;
var _default = exports.default = Inspectable;
var _c;
$RefreshReg$(_c, "Inspectable");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2luc3BlY3Rpb25Db250ZXh0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkluc3BlY3RhYmxlIiwic291cmNlIiwiY2hpbGRyZW4iLCJwb3J0IiwidXNlQ29udGV4dCIsIkluc3BlY3Rpb25Db250ZXh0IiwidGltZXIiLCJ1c2VSZWYiLCJjYW5JbnNwZWN0IiwianN4IiwiRnJhZ21lbnQiLCJjYW5jZWxQcmVzcyIsImN1cnJlbnQiLCJjbGVhclRpbWVvdXQiLCJqc3hzIiwiY2xhc3NOYW1lIiwib25Qb2ludGVyRG93biIsImUiLCJwb2ludGVyVHlwZSIsInNldFRpbWVvdXQiLCJvbkluc3BlY3QiLCJvblBvaW50ZXJVcCIsIm9uUG9pbnRlckNhbmNlbCIsIm9uUG9pbnRlckxlYXZlIiwidHlwZSIsIm9uQ2xpY2siLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbnNwZWN0YWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIG9uLXBpeGVsIGluc3BlY3Rpb24gYWZmb3JkYW5jZSAoVjMpOiBcImEgcXVpZXQgYWZmb3JkYW5jZSBvbiBldmVyeSBib3VuZCBlbGVtZW50IOKAlFxuLy8gaG92ZXItcmV2ZWFsIGRlc2t0b3AsIGxvbmctcHJlc3MgdG91Y2gg4oCUIGZhaW50IGVub3VnaCBub3QgdG8gdGF4IHJ1biBtb2RlLlwiIFRoaXMgd3JhcHBlclxuLy8gcmVuZGVycyBpdHMgY2hpbGRyZW4gYmFyZSB1bmxlc3MgdGhlIGluc3BlY3Rpb24gcG9ydCBpcyBwcm92aWRlZDsgd2l0aCBpdCwgYSBzbWFsbCBvdmVybGF5XG4vLyBidXR0b24gYXBwZWFycyBvbiBob3ZlciAvIGtleWJvYXJkIGZvY3VzIChkZXNrdG9wKSBhbmQgYSB+NDUwbXMgcHJlc3Mgb3BlbnMgaXQgZGlyZWN0bHlcbi8vICh0b3VjaCwgd2hlcmUgdGhlcmUgaXMgbm8gaG92ZXIpLiBPbmUgY29tcG9uZW50IHBlciBmaWxlLCBkZWZhdWx0IGV4cG9ydCAocmVwbyBydWxlKS5cbmltcG9ydCB7IHVzZUNvbnRleHQsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgSW5zcGVjdGlvbkNvbnRleHQgfSBmcm9tICcuL2luc3BlY3Rpb25Db250ZXh0LnRzJztcblxuaW50ZXJmYWNlIEluc3BlY3RhYmxlUHJvcHMge1xuICAvKiogVGhlIGJvdW5kIHNvdXJjZSAoYSBjZWxsIGlkKSB0aGUgd3JhcHBlZCBlbGVtZW50IGRpc3BsYXlzLiAqL1xuICBzb3VyY2U6IHN0cmluZztcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbn1cblxuZnVuY3Rpb24gSW5zcGVjdGFibGUoeyBzb3VyY2UsIGNoaWxkcmVuIH06IEluc3BlY3RhYmxlUHJvcHMpIHtcbiAgY29uc3QgcG9ydCA9IHVzZUNvbnRleHQoSW5zcGVjdGlvbkNvbnRleHQpO1xuICBjb25zdCB0aW1lciA9IHVzZVJlZjxSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGw+KG51bGwpO1xuXG4gIGlmIChwb3J0ID09PSBudWxsIHx8ICFwb3J0LmNhbkluc3BlY3Qoc291cmNlKSkgcmV0dXJuIDw+e2NoaWxkcmVufTwvPjtcblxuICBjb25zdCBjYW5jZWxQcmVzcyA9ICgpOiB2b2lkID0+IHtcbiAgICBpZiAodGltZXIuY3VycmVudCAhPT0gbnVsbCkge1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyLmN1cnJlbnQpO1xuICAgICAgdGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwicmstaW5zcGVjdGFibGVcIlxuICAgICAgZGF0YS1zb3VyY2U9e3NvdXJjZX1cbiAgICAgIG9uUG9pbnRlckRvd249eyhlKSA9PiB7XG4gICAgICAgIC8vIFRvdWNoIGxvbmctcHJlc3Mgb3BlbnMgZGlyZWN0bHkg4oCUIHRoZXJlIGlzIG5vIGhvdmVyIHRvIHJldmVhbCBpbnRvLlxuICAgICAgICBpZiAoZS5wb2ludGVyVHlwZSA9PT0gJ3RvdWNoJykge1xuICAgICAgICAgIGNhbmNlbFByZXNzKCk7XG4gICAgICAgICAgdGltZXIuY3VycmVudCA9IHNldFRpbWVvdXQoKCkgPT4gcG9ydC5vbkluc3BlY3Qoc291cmNlKSwgNDUwKTtcbiAgICAgICAgfVxuICAgICAgfX1cbiAgICAgIG9uUG9pbnRlclVwPXtjYW5jZWxQcmVzc31cbiAgICAgIG9uUG9pbnRlckNhbmNlbD17Y2FuY2VsUHJlc3N9XG4gICAgICBvblBvaW50ZXJMZWF2ZT17Y2FuY2VsUHJlc3N9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgY2xhc3NOYW1lPVwicmstaW5zcGVjdC1idG5cIlxuICAgICAgICBhcmlhLWxhYmVsPXtgSW5zcGVjdCAke3NvdXJjZX1gfVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBwb3J0Lm9uSW5zcGVjdChzb3VyY2UpfVxuICAgICAgPlxuICAgICAgICDijJVcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBJbnNwZWN0YWJsZTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsa0JBQUEsR0FBQUQsT0FBQTtBQUEyRCxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFBQSxJQUFBRyxFQUFBLEdBQUFDLFlBQUEsSUFQM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdBLFNBQVNDLFdBQVdBLENBQUM7RUFBRUMsTUFBTTtFQUFFQztBQUEyQixDQUFDLEVBQUU7RUFBQUosRUFBQTtFQUMzRCxNQUFNSyxJQUFJLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0Msb0NBQWlCLENBQUM7RUFDMUMsTUFBTUMsS0FBSyxHQUFHLElBQUFDLGFBQU0sRUFBdUMsSUFBSSxDQUFDO0VBRWhFLElBQUlKLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQ0EsSUFBSSxDQUFDSyxVQUFVLENBQUNQLE1BQU0sQ0FBQyxFQUFFLG9CQUFPLElBQUFKLFdBQUEsQ0FBQVksR0FBQSxFQUFBWixXQUFBLENBQUFhLFFBQUE7SUFBQVIsUUFBQSxFQUFHQTtFQUFRLENBQUcsQ0FBQztFQUVyRSxNQUFNUyxXQUFXLEdBQUdBLENBQUEsS0FBWTtJQUM5QixJQUFJTCxLQUFLLENBQUNNLE9BQU8sS0FBSyxJQUFJLEVBQUU7TUFDMUJDLFlBQVksQ0FBQ1AsS0FBSyxDQUFDTSxPQUFPLENBQUM7TUFDM0JOLEtBQUssQ0FBQ00sT0FBTyxHQUFHLElBQUk7SUFDdEI7RUFDRixDQUFDO0VBRUQsb0JBQ0UsSUFBQWYsV0FBQSxDQUFBaUIsSUFBQTtJQUNFQyxTQUFTLEVBQUMsZ0JBQWdCO0lBQzFCLGVBQWFkLE1BQU87SUFDcEJlLGFBQWEsRUFBR0MsQ0FBQyxJQUFLO01BQ3BCO01BQ0EsSUFBSUEsQ0FBQyxDQUFDQyxXQUFXLEtBQUssT0FBTyxFQUFFO1FBQzdCUCxXQUFXLENBQUMsQ0FBQztRQUNiTCxLQUFLLENBQUNNLE9BQU8sR0FBR08sVUFBVSxDQUFDLE1BQU1oQixJQUFJLENBQUNpQixTQUFTLENBQUNuQixNQUFNLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDL0Q7SUFDRixDQUFFO0lBQ0ZvQixXQUFXLEVBQUVWLFdBQVk7SUFDekJXLGVBQWUsRUFBRVgsV0FBWTtJQUM3QlksY0FBYyxFQUFFWixXQUFZO0lBQUFULFFBQUEsR0FFM0JBLFFBQVEsZUFDVCxJQUFBTCxXQUFBLENBQUFZLEdBQUE7TUFDRWUsSUFBSSxFQUFDLFFBQVE7TUFDYlQsU0FBUyxFQUFDLGdCQUFnQjtNQUMxQixjQUFZLFdBQVdkLE1BQU0sRUFBRztNQUNoQ3dCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdEIsSUFBSSxDQUFDaUIsU0FBUyxDQUFDbkIsTUFBTSxDQUFFO01BQUFDLFFBQUEsRUFDdkM7SUFFRCxDQUFRLENBQUM7RUFBQSxDQUNOLENBQUM7QUFFVjtBQUFDSixFQUFBLENBdkNRRSxXQUFXO0FBQUEwQixFQUFBLEdBQVgxQixXQUFXO0FBQUEsSUFBQTJCLFFBQUEsR0FBQUMsT0FBQSxDQUFBQyxPQUFBLEdBeUNMN0IsV0FBVztBQUFBLElBQUEwQixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}