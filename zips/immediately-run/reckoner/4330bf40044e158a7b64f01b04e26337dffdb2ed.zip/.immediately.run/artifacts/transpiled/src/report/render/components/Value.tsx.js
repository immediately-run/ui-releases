var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Value;
var _bindingsContext = require("../bindingsContext.ts");
var _shape = require("../shape.ts");
var _attrs = require("../attrs.ts");
var _format = require("../format.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Value — an inline bound scalar in prose (§3.3: "echo a viewer selection with
// `<Value source="params.region" />`"). Renders the resolved scalar inline; a non-scalar or
// non-ok binding renders a muted inline marker rather than breaking the sentence.
function Value({
  node
}) {
  _s();
  const bound = (0, _bindingsContext.useSource)((0, _attrs.attrString)(node, 'source'));
  if (bound.status !== 'ok') return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: "rk-value rk-value-missing",
    children: "\u2014"
  });
  const scalar = (0, _shape.asScalar)(bound.value);
  if (!scalar.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: "rk-value rk-value-missing",
    children: "\u2014"
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: "rk-value",
    "data-tier": bound.tier,
    children: (0, _format.formatScalar)(scalar.data)
  });
}
_s(Value, "5joLNnTxqRabjF7FIIG70b60L3g=", false, function () {
  return [_bindingsContext.useSource];
});
_c = Value;
var _c;
$RefreshReg$(_c, "Value");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9zaGFwZSIsIl9hdHRycyIsIl9mb3JtYXQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiVmFsdWUiLCJub2RlIiwiYm91bmQiLCJ1c2VTb3VyY2UiLCJhdHRyU3RyaW5nIiwic3RhdHVzIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJzY2FsYXIiLCJhc1NjYWxhciIsInZhbHVlIiwib2siLCJ0aWVyIiwiZm9ybWF0U2NhbGFyIiwiZGF0YSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVmFsdWUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFZhbHVlIOKAlCBhbiBpbmxpbmUgYm91bmQgc2NhbGFyIGluIHByb3NlICjCpzMuMzogXCJlY2hvIGEgdmlld2VyIHNlbGVjdGlvbiB3aXRoXG4vLyBgPFZhbHVlIHNvdXJjZT1cInBhcmFtcy5yZWdpb25cIiAvPmBcIikuIFJlbmRlcnMgdGhlIHJlc29sdmVkIHNjYWxhciBpbmxpbmU7IGEgbm9uLXNjYWxhciBvclxuLy8gbm9uLW9rIGJpbmRpbmcgcmVuZGVycyBhIG11dGVkIGlubGluZSBtYXJrZXIgcmF0aGVyIHRoYW4gYnJlYWtpbmcgdGhlIHNlbnRlbmNlLlxuaW1wb3J0IHR5cGUgeyBDb21wb25lbnROb2RlIH0gZnJvbSAnLi4vLi4vbm9kZXMudHMnO1xuaW1wb3J0IHsgdXNlU291cmNlIH0gZnJvbSAnLi4vYmluZGluZ3NDb250ZXh0LnRzJztcbmltcG9ydCB7IGFzU2NhbGFyIH0gZnJvbSAnLi4vc2hhcGUudHMnO1xuaW1wb3J0IHsgYXR0clN0cmluZyB9IGZyb20gJy4uL2F0dHJzLnRzJztcbmltcG9ydCB7IGZvcm1hdFNjYWxhciB9IGZyb20gJy4uL2Zvcm1hdC50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFZhbHVlKHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCBib3VuZCA9IHVzZVNvdXJjZShhdHRyU3RyaW5nKG5vZGUsICdzb3VyY2UnKSk7XG4gIGlmIChib3VuZC5zdGF0dXMgIT09ICdvaycpIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJyay12YWx1ZSByay12YWx1ZS1taXNzaW5nXCI+4oCUPC9zcGFuPjtcbiAgY29uc3Qgc2NhbGFyID0gYXNTY2FsYXIoYm91bmQudmFsdWUpO1xuICBpZiAoIXNjYWxhci5vaykgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInJrLXZhbHVlIHJrLXZhbHVlLW1pc3NpbmdcIj7igJQ8L3NwYW4+O1xuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXZhbHVlXCIgZGF0YS10aWVyPXtib3VuZC50aWVyfT5cbiAgICAgIHtmb3JtYXRTY2FsYXIoc2NhbGFyLmRhdGEpfVxuICAgIDwvc3Bhbj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBSUEsSUFBQUEsZ0JBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUgsT0FBQTtBQUE0QyxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUEsSUFQNUM7QUFDQTtBQUNBO0FBT2UsU0FBU0MsS0FBS0EsQ0FBQztFQUFFQztBQUE4QixDQUFDLEVBQUU7RUFBQUgsRUFBQTtFQUMvRCxNQUFNSSxLQUFLLEdBQUcsSUFBQUMsMEJBQVMsRUFBQyxJQUFBQyxpQkFBVSxFQUFDSCxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7RUFDbkQsSUFBSUMsS0FBSyxDQUFDRyxNQUFNLEtBQUssSUFBSSxFQUFFLG9CQUFPLElBQUFSLFdBQUEsQ0FBQVMsR0FBQTtJQUFNQyxTQUFTLEVBQUMsMkJBQTJCO0lBQUFDLFFBQUEsRUFBQztFQUFDLENBQU0sQ0FBQztFQUN0RixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsZUFBUSxFQUFDUixLQUFLLENBQUNTLEtBQUssQ0FBQztFQUNwQyxJQUFJLENBQUNGLE1BQU0sQ0FBQ0csRUFBRSxFQUFFLG9CQUFPLElBQUFmLFdBQUEsQ0FBQVMsR0FBQTtJQUFNQyxTQUFTLEVBQUMsMkJBQTJCO0lBQUFDLFFBQUEsRUFBQztFQUFDLENBQU0sQ0FBQztFQUMzRSxvQkFDRSxJQUFBWCxXQUFBLENBQUFTLEdBQUE7SUFBTUMsU0FBUyxFQUFDLFVBQVU7SUFBQyxhQUFXTCxLQUFLLENBQUNXLElBQUs7SUFBQUwsUUFBQSxFQUM5QyxJQUFBTSxvQkFBWSxFQUFDTCxNQUFNLENBQUNNLElBQUk7RUFBQyxDQUN0QixDQUFDO0FBRVg7QUFBQ2pCLEVBQUEsQ0FWdUJFLEtBQUs7RUFBQSxRQUNiRywwQkFBUztBQUFBO0FBQUFhLEVBQUEsR0FERGhCLEtBQUs7QUFBQSxJQUFBZ0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}