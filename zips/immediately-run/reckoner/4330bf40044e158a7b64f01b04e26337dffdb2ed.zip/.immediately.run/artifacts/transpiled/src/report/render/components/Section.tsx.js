var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Section;
var _renderContext = require("../renderContext.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Section — a vertical layout grouping (§3.3 layout primitives). Container; renders children
// stacked. Responsive spacing lives in CSS, not the template.
function Section({
  node
}) {
  _s();
  const renderNodes = (0, _renderContext.useRenderNodes)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("section", {
    className: "rk-section",
    children: renderNodes(node.children)
  });
}
_s(Section, "ITAsjexFDox20GXuav5598+1Xb8=", false, function () {
  return [_renderContext.useRenderNodes];
});
_c = Section;
var _c;
$RefreshReg$(_c, "Section");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVuZGVyQ29udGV4dCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiU2VjdGlvbiIsIm5vZGUiLCJyZW5kZXJOb2RlcyIsInVzZVJlbmRlck5vZGVzIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNlY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFNlY3Rpb24g4oCUIGEgdmVydGljYWwgbGF5b3V0IGdyb3VwaW5nICjCpzMuMyBsYXlvdXQgcHJpbWl0aXZlcykuIENvbnRhaW5lcjsgcmVuZGVycyBjaGlsZHJlblxuLy8gc3RhY2tlZC4gUmVzcG9uc2l2ZSBzcGFjaW5nIGxpdmVzIGluIENTUywgbm90IHRoZSB0ZW1wbGF0ZS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IHVzZVJlbmRlck5vZGVzIH0gZnJvbSAnLi4vcmVuZGVyQ29udGV4dC50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNlY3Rpb24oeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHJlbmRlck5vZGVzID0gdXNlUmVuZGVyTm9kZXMoKTtcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJrLXNlY3Rpb25cIj57cmVuZGVyTm9kZXMobm9kZS5jaGlsZHJlbil9PC9zZWN0aW9uPjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBR0EsSUFBQUEsY0FBQSxHQUFBQyxPQUFBO0FBQXFELElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLElBQUFFLEVBQUEsR0FBQUMsWUFBQSxJQUhyRDtBQUNBO0FBSWUsU0FBU0MsT0FBT0EsQ0FBQztFQUFFQztBQUE4QixDQUFDLEVBQUU7RUFBQUgsRUFBQTtFQUNqRSxNQUFNSSxXQUFXLEdBQUcsSUFBQUMsNkJBQWMsRUFBQyxDQUFDO0VBQ3BDLG9CQUFPLElBQUFOLFdBQUEsQ0FBQU8sR0FBQTtJQUFTQyxTQUFTLEVBQUMsWUFBWTtJQUFBQyxRQUFBLEVBQUVKLFdBQVcsQ0FBQ0QsSUFBSSxDQUFDSyxRQUFRO0VBQUMsQ0FBVSxDQUFDO0FBQy9FO0FBQUNSLEVBQUEsQ0FIdUJFLE9BQU87RUFBQSxRQUNURyw2QkFBYztBQUFBO0FBQUFJLEVBQUEsR0FEWlAsT0FBTztBQUFBLElBQUFPLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}