var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Params;
var _renderContext = require("../renderContext.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Params — a block of input widgets (§3.3 "widgets write to input cells"). Container; renders
// its widget children (Select/Toggle/Range/DateRange) through the shared dispatcher. A widget's
// `name` designates a `params.*` input cell: a viewer pick writes the param, the host
// recomputes every formula that declared it, and every bound component re-renders. Interaction
// is pure data flow the dependency graph already understands — no event handlers in templates.
function Params({
  node
}) {
  _s();
  const renderNodes = (0, _renderContext.useRenderNodes)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("form", {
    className: "rk-params",
    role: "group",
    "aria-label": "report parameters",
    onSubmit: e => e.preventDefault(),
    children: renderNodes(node.children)
  });
}
_s(Params, "ITAsjexFDox20GXuav5598+1Xb8=", false, function () {
  return [_renderContext.useRenderNodes];
});
_c = Params;
var _c;
$RefreshReg$(_c, "Params");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVuZGVyQ29udGV4dCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiUGFyYW1zIiwibm9kZSIsInJlbmRlck5vZGVzIiwidXNlUmVuZGVyTm9kZXMiLCJqc3giLCJjbGFzc05hbWUiLCJyb2xlIiwib25TdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGFyYW1zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQYXJhbXMg4oCUIGEgYmxvY2sgb2YgaW5wdXQgd2lkZ2V0cyAowqczLjMgXCJ3aWRnZXRzIHdyaXRlIHRvIGlucHV0IGNlbGxzXCIpLiBDb250YWluZXI7IHJlbmRlcnNcbi8vIGl0cyB3aWRnZXQgY2hpbGRyZW4gKFNlbGVjdC9Ub2dnbGUvUmFuZ2UvRGF0ZVJhbmdlKSB0aHJvdWdoIHRoZSBzaGFyZWQgZGlzcGF0Y2hlci4gQSB3aWRnZXQnc1xuLy8gYG5hbWVgIGRlc2lnbmF0ZXMgYSBgcGFyYW1zLipgIGlucHV0IGNlbGw6IGEgdmlld2VyIHBpY2sgd3JpdGVzIHRoZSBwYXJhbSwgdGhlIGhvc3Rcbi8vIHJlY29tcHV0ZXMgZXZlcnkgZm9ybXVsYSB0aGF0IGRlY2xhcmVkIGl0LCBhbmQgZXZlcnkgYm91bmQgY29tcG9uZW50IHJlLXJlbmRlcnMuIEludGVyYWN0aW9uXG4vLyBpcyBwdXJlIGRhdGEgZmxvdyB0aGUgZGVwZW5kZW5jeSBncmFwaCBhbHJlYWR5IHVuZGVyc3RhbmRzIOKAlCBubyBldmVudCBoYW5kbGVycyBpbiB0ZW1wbGF0ZXMuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyB1c2VSZW5kZXJOb2RlcyB9IGZyb20gJy4uL3JlbmRlckNvbnRleHQudHMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYXJhbXMoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHJlbmRlck5vZGVzID0gdXNlUmVuZGVyTm9kZXMoKTtcbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBjbGFzc05hbWU9XCJyay1wYXJhbXNcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwicmVwb3J0IHBhcmFtZXRlcnNcIiBvblN1Ym1pdD17KGUpID0+IGUucHJldmVudERlZmF1bHQoKX0+XG4gICAgICB7cmVuZGVyTm9kZXMobm9kZS5jaGlsZHJlbil9XG4gICAgPC9mb3JtPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxjQUFBLEdBQUFDLE9BQUE7QUFBcUQsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsSUFBQUUsRUFBQSxHQUFBQyxZQUFBLElBTnJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJZSxTQUFTQyxNQUFNQSxDQUFDO0VBQUVDO0FBQThCLENBQUMsRUFBRTtFQUFBSCxFQUFBO0VBQ2hFLE1BQU1JLFdBQVcsR0FBRyxJQUFBQyw2QkFBYyxFQUFDLENBQUM7RUFDcEMsb0JBQ0UsSUFBQU4sV0FBQSxDQUFBTyxHQUFBO0lBQU1DLFNBQVMsRUFBQyxXQUFXO0lBQUNDLElBQUksRUFBQyxPQUFPO0lBQUMsY0FBVyxtQkFBbUI7SUFBQ0MsUUFBUSxFQUFHQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsY0FBYyxDQUFDLENBQUU7SUFBQUMsUUFBQSxFQUN6R1IsV0FBVyxDQUFDRCxJQUFJLENBQUNTLFFBQVE7RUFBQyxDQUN2QixDQUFDO0FBRVg7QUFBQ1osRUFBQSxDQVB1QkUsTUFBTTtFQUFBLFFBQ1JHLDZCQUFjO0FBQUE7QUFBQVEsRUFBQSxHQURaWCxNQUFNO0FBQUEsSUFBQVcsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}