var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _server = require("react-dom/server");
var _ValueInspector = _interopRequireDefault(require("./ValueInspector.tsx"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// @vitest-environment happy-dom
// The value inspector (review surface slice 2). Two halves:
//  · the pre-existing suite — pure props → static render: name, doc, value + tier
//    (plain data — the tier badge is host chrome, review-1 H2), read-only formula
//    source, navigable input chips (the V3 hop-by-hop walk), the coverage state,
//    the precedent neighborhood, the what-if door and the R3-427 anchors;
//  · the edit door (R3-447, DOCUMENT_NAVIGATOR_SPEC §3/§4) — present beside the
//    anchors only where the row’s path passes the gate, absent (never disabled)
//    otherwise, with the RCD §5.1 disclosure — static render covers presence and
//    the no-host-boot property; the DOM half drives the click.

// react-dom/client requires the act environment flag to flush effects deterministically.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const resolvers = [{
  name: 'rows',
  kind: 'external',
  key: 'feeds.orders'
}, {
  name: 'raw',
  kind: 'cell',
  nodeId: 'revenue.raw'
}, {
  name: 'tail',
  kind: 'windowed-feed',
  feed: 'orders',
  window: '1h',
  by: 'ts'
}, {
  name: 'all',
  kind: 'wildcard',
  worksheet: 'revenue'
}];
const cell = {
  id: 'revenue.total',
  worksheet: 'revenue',
  cell: 'total',
  doc: 'total revenue, EUR-normalized',
  formulaSource: '({ rows, raw }) => rows.reduce((a, r) => a + r.eur, 0) + raw',
  deps: ['revenue.raw'],
  externals: ['feeds.orders'],
  resolvers
};
const tests = [{
  id: 'revenue.total_check',
  worksheet: 'revenue',
  name: 'total_check',
  kind: 'specification',
  subject: 'revenue.total',
  inputs: {}
}];
const outcome = {
  subject: 'revenue.total',
  verdict: 'pinned',
  outcomes: [{
    id: 'revenue.total_check',
    kind: 'specification',
    pass: true,
    message: ''
  }]
};
function render(over = {}) {
  const props = {
    cell,
    cells: [cell, ...extraCells],
    tests,
    verdicts: new Map([[outcome.subject, outcome]]),
    result: {
      id: 'revenue.total',
      value: 48_120,
      tier: 'live',
      key: 'k'
    },
    onNavigate: () => {},
    onClose: () => {},
    ...over
  };
  return (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_ValueInspector.default, props));
}

/** Upstream cells the precedent neighborhood can walk into. */
const extraCells = [{
  id: 'revenue.raw',
  worksheet: 'revenue',
  cell: 'raw',
  doc: 'raw rows',
  formulaSource: '({ rows }) => rows',
  deps: [],
  externals: ['feeds.orders'],
  resolvers: [{
    name: 'rows',
    kind: 'external',
    key: 'feeds.orders'
  }]
}, {
  id: 'revenue.base',
  worksheet: 'revenue',
  cell: 'base',
  doc: 'base',
  formulaSource: '({ r }) => r.length',
  deps: ['revenue.raw'],
  externals: [],
  resolvers: [{
    name: 'r',
    kind: 'cell',
    nodeId: 'revenue.raw'
  }]
}];
(0, _vitest.describe)('ValueInspector', () => {
  const html = render();
  (0, _vitest.it)('renders the binding name, doc, value, tier (as data — never a badge), and verdict', () => {
    (0, _vitest.expect)(html).toContain('revenue.total');
    (0, _vitest.expect)(html).toContain('total revenue, EUR-normalized');
    (0, _vitest.expect)(html).toContain('48120');
    (0, _vitest.expect)(html).toContain('tier live');
    (0, _vitest.expect)(html).toContain('rk-verdict--pinned');
    // the tier badge is host-drawn chrome; the app never renders one (review-1 H2)
    (0, _vitest.expect)(html).not.toMatch(/badge/i);
  });
  (0, _vitest.it)('renders the formula source read-only', () => {
    (0, _vitest.expect)(html).toContain('rows.reduce((a, r) =&gt; a + r.eur, 0)');
    (0, _vitest.expect)(html).toContain('<pre');
  });
  (0, _vitest.it)('declared inputs render as chips — cell refs navigable, externals and windows inert', () => {
    (0, _vitest.expect)(html).toContain('rows ← feeds.orders');
    (0, _vitest.expect)(html).toContain('raw ← revenue.raw');
    (0, _vitest.expect)(html).toContain('tail ← feed orders · 1h');
    (0, _vitest.expect)(html).toContain('all ← revenue.*');
    // the cell-ref chip is the only navigable one
    const chips = html.match(/rk-chip[^"]*/g) ?? [];
    (0, _vitest.expect)(chips.filter(c => c.includes('rk-chip--nav'))).toHaveLength(1);
  });
  (0, _vitest.it)('this cell’s tests render with kind and outcome', () => {
    (0, _vitest.expect)(html).toContain('>specification<');
    (0, _vitest.expect)(html).toContain('total_check');
    (0, _vitest.expect)(html).toContain('>pass<');
  });
  (0, _vitest.it)('an absent outcome renders untested; a failing test shows its message', () => {
    const untested = render({
      verdicts: new Map()
    });
    (0, _vitest.expect)(untested).toContain('rk-verdict--untested');
    const failing = render({
      verdicts: new Map([['revenue.total', {
        subject: 'revenue.total',
        verdict: 'failing',
        outcomes: [{
          id: 'revenue.total_check',
          kind: 'specification',
          pass: false,
          message: 'expected 30, got 29'
        }]
      }]])
    });
    (0, _vitest.expect)(failing).toContain('rk-verdict--failing');
    (0, _vitest.expect)(failing).toContain('expected 30, got 29');
  });
  (0, _vitest.it)('null results (suites still computing) render the distinct pending chip, never untested', () => {
    const pending = render({
      verdicts: null
    });
    (0, _vitest.expect)(pending).toContain('rk-verdict--pending');
    (0, _vitest.expect)(pending).toContain('>pending<');
    (0, _vitest.expect)(pending).not.toContain('rk-verdict--untested');
  });
});
(0, _vitest.describe)('ValueInspector — the precedent neighborhood (UX-4)', () => {
  (0, _vitest.it)('renders the whole subgraph beneath the cell inputs, nested', () => {
    const html = render();
    // total → raw → feeds.orders: the two-level walk is visible at once
    (0, _vitest.expect)(html).toContain('rk-prec');
    (0, _vitest.expect)(html).toContain('raw:');
    (0, _vitest.expect)(html).toContain('revenue.raw');
    (0, _vitest.expect)(html).toContain('feeds.orders');
    // the meta line states the shape
    (0, _vitest.expect)(html).toMatch(/nodes · depth 1/);
  });
  (0, _vitest.it)('a cell with only external inputs shows no neighborhood (nothing to walk)', () => {
    const onlyExternal = {
      ...cell,
      resolvers: [{
        name: 'rows',
        kind: 'external',
        key: 'feeds.orders'
      }]
    };
    const html = render({
      cell: onlyExternal
    });
    (0, _vitest.expect)(html).not.toContain('rk-prec');
  });
});
(0, _vitest.describe)('the what-if door (spec §1.1, amended 2026-08-28)', () => {
  (0, _vitest.it)('renders the formula row affordance when a handler is provided, and none otherwise', () => {
    (0, _vitest.expect)(render({
      onWhatIf: () => {}
    })).toContain('what if →');
    (0, _vitest.expect)(render()).not.toContain('what if →');
  });
});
(0, _vitest.describe)('file:line anchors from spans (R3-427)', () => {
  (0, _vitest.it)('the formula row and test rows name their exact location when spans + paths exist', () => {
    const withSpan = {
      ...cell,
      span: {
        start: 0,
        end: 10,
        line: 12
      }
    };
    const testsWithSpan = tests.map(t => ({
      ...t,
      span: {
        start: 0,
        end: 5,
        line: 31
      }
    }));
    const html = render({
      cell: withSpan,
      tests: testsWithSpan,
      worksheetPaths: {
        revenue: 'worksheets/revenue.sheet.js'
      }
    });
    (0, _vitest.expect)(html).toContain('worksheets/revenue.sheet.js:12');
    (0, _vitest.expect)(html).toContain('worksheets/revenue.sheet.js:31');
  });
  (0, _vitest.it)('renders no anchor without spans or paths — never a wrong location', () => {
    (0, _vitest.expect)(render()).not.toContain('.sheet.js:');
    (0, _vitest.expect)(render({
      worksheetPaths: {
        revenue: 'worksheets/revenue.sheet.js'
      }
    })).not.toContain('.sheet.js:');
  });
});
(0, _vitest.describe)('the edit door (R3-447, DOCUMENT_NAVIGATOR_SPEC §3/§4)', () => {
  const spanned = {
    ...cell,
    span: {
      start: 0,
      end: 10,
      line: 12
    }
  };
  const spannedTests = tests.map(t => ({
    ...t,
    span: {
      start: 0,
      end: 5,
      line: 31
    },
    worksheet: 'checks'
  }));
  const paths = {
    revenue: 'worksheets/revenue.sheet.js',
    checks: 'worksheets/checks.sheet.js'
  };
  const DISCLOSURE = 'Edits save to the mounted content. Proposing a change back to its repository is not wired yet.';
  (0, _vitest.it)('no door at all when the port is not wired (the seed, non-dispatched flow)', () => {
    const html = render({
      cell: spanned,
      tests: spannedTests,
      worksheetPaths: paths
    });
    (0, _vitest.expect)(html).toContain('worksheets/revenue.sheet.js:12'); // the anchors are still data
    (0, _vitest.expect)(html).not.toContain('>edit<');
    (0, _vitest.expect)(html).not.toContain(DISCLOSURE);
  });
  (0, _vitest.it)('a row whose own path fails the gate has no door — the clean row keeps its own', () => {
    const html = render({
      cell: spanned,
      tests: spannedTests,
      worksheetPaths: {
        revenue: 'worksheets/../../evil.sheet.js',
        checks: 'worksheets/checks.sheet.js'
      },
      canEditPath: rel => rel === 'worksheets/checks.sheet.js',
      onEdit: () => {}
    });
    (0, _vitest.expect)((html.match(/>edit</g) ?? []).length).toBe(1); // only the test row’s door
  });
  (0, _vitest.it)('the door renders beside BOTH anchors with the disclosure at the button', () => {
    const html = render({
      cell: spanned,
      tests: spannedTests,
      worksheetPaths: paths,
      canEditPath: () => true,
      onEdit: () => {}
    });
    (0, _vitest.expect)((html.match(/>edit</g) ?? []).length).toBe(2);
    (0, _vitest.expect)(html).toContain('rk-ins-edit-note'); // the visible disclosure line, not just the tooltip
    (0, _vitest.expect)(html).toContain(DISCLOSURE);
    (0, _vitest.expect)(html).toContain(`title="${DISCLOSURE}"`);
  });
  (0, _vitest.it)('the disclosure note renders when ONLY a test row carries a door (pinned on the note element, not the tooltip string)', () => {
    const html = render({
      cell: spanned,
      tests: spannedTests,
      worksheetPaths: paths,
      canEditPath: rel => rel === 'worksheets/checks.sheet.js',
      onEdit: () => {}
    });
    (0, _vitest.expect)((html.match(/>edit</g) ?? []).length).toBe(1);
    // the note ELEMENT is the assertion: the tooltip carries the same string, so a
    // bare toContain(DISCLOSURE) would pass even with the note gated on the formula
    // row's door alone (round 1's bug) — this is the line that fails without anyDoor
    (0, _vitest.expect)(html).toContain('rk-ins-edit-note');
    (0, _vitest.expect)(html).toContain(DISCLOSURE);
  });
  (0, _vitest.it)('a click hands the row’s own document-relative path to the door', () => {
    const onEdit = _vitest.vi.fn();
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    (0, _react.act)(() => {
      root.render(/*#__PURE__*/(0, _react.createElement)(_ValueInspector.default, {
        cell: spanned,
        cells: [spanned],
        tests: spannedTests,
        verdicts: new Map([[outcome.subject, outcome]]),
        result: undefined,
        onNavigate: () => {},
        onClose: () => {},
        worksheetPaths: paths,
        canEditPath: () => true,
        onEdit
      }));
    });
    const buttons = [...container.querySelectorAll('button')].filter(b => b.textContent === 'edit');
    (0, _vitest.expect)(buttons.length).toBe(2);
    (0, _react.act)(() => {
      buttons[0].dispatchEvent(new MouseEvent('click', {
        bubbles: true
      }));
      buttons[1].dispatchEvent(new MouseEvent('click', {
        bubbles: true
      }));
    });
    (0, _vitest.expect)(onEdit).toHaveBeenCalledWith('worksheets/revenue.sheet.js');
    (0, _vitest.expect)(onEdit).toHaveBeenCalledWith('worksheets/checks.sheet.js');
    (0, _react.act)(() => root.unmount());
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfc2VydmVyIiwiX1ZhbHVlSW5zcGVjdG9yIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImdsb2JhbFRoaXMiLCJJU19SRUFDVF9BQ1RfRU5WSVJPTk1FTlQiLCJyZXNvbHZlcnMiLCJuYW1lIiwia2luZCIsImtleSIsIm5vZGVJZCIsImZlZWQiLCJ3aW5kb3ciLCJieSIsIndvcmtzaGVldCIsImNlbGwiLCJpZCIsImRvYyIsImZvcm11bGFTb3VyY2UiLCJkZXBzIiwiZXh0ZXJuYWxzIiwidGVzdHMiLCJzdWJqZWN0IiwiaW5wdXRzIiwib3V0Y29tZSIsInZlcmRpY3QiLCJvdXRjb21lcyIsInBhc3MiLCJtZXNzYWdlIiwicmVuZGVyIiwib3ZlciIsInByb3BzIiwiY2VsbHMiLCJleHRyYUNlbGxzIiwidmVyZGljdHMiLCJNYXAiLCJyZXN1bHQiLCJ2YWx1ZSIsInRpZXIiLCJvbk5hdmlnYXRlIiwib25DbG9zZSIsInJlbmRlclRvU3RhdGljTWFya3VwIiwiY3JlYXRlRWxlbWVudCIsIlZhbHVlSW5zcGVjdG9yIiwiZGVzY3JpYmUiLCJodG1sIiwiaXQiLCJleHBlY3QiLCJ0b0NvbnRhaW4iLCJub3QiLCJ0b01hdGNoIiwiY2hpcHMiLCJtYXRjaCIsImZpbHRlciIsImMiLCJpbmNsdWRlcyIsInRvSGF2ZUxlbmd0aCIsInVudGVzdGVkIiwiZmFpbGluZyIsInBlbmRpbmciLCJvbmx5RXh0ZXJuYWwiLCJvbldoYXRJZiIsIndpdGhTcGFuIiwic3BhbiIsInN0YXJ0IiwiZW5kIiwibGluZSIsInRlc3RzV2l0aFNwYW4iLCJtYXAiLCJ0Iiwid29ya3NoZWV0UGF0aHMiLCJyZXZlbnVlIiwic3Bhbm5lZCIsInNwYW5uZWRUZXN0cyIsInBhdGhzIiwiY2hlY2tzIiwiRElTQ0xPU1VSRSIsImNhbkVkaXRQYXRoIiwicmVsIiwib25FZGl0IiwibGVuZ3RoIiwidG9CZSIsInZpIiwiZm4iLCJjb250YWluZXIiLCJkb2N1bWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwidW5kZWZpbmVkIiwiYnV0dG9ucyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJiIiwidGV4dENvbnRlbnQiLCJkaXNwYXRjaEV2ZW50IiwiTW91c2VFdmVudCIsImJ1YmJsZXMiLCJ0b0hhdmVCZWVuQ2FsbGVkV2l0aCIsInVubW91bnQiXSwic291cmNlcyI6WyJWYWx1ZUluc3BlY3Rvci50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGhhcHB5LWRvbVxuLy8gVGhlIHZhbHVlIGluc3BlY3RvciAocmV2aWV3IHN1cmZhY2Ugc2xpY2UgMikuIFR3byBoYWx2ZXM6XG4vLyAgwrcgdGhlIHByZS1leGlzdGluZyBzdWl0ZSDigJQgcHVyZSBwcm9wcyDihpIgc3RhdGljIHJlbmRlcjogbmFtZSwgZG9jLCB2YWx1ZSArIHRpZXJcbi8vICAgIChwbGFpbiBkYXRhIOKAlCB0aGUgdGllciBiYWRnZSBpcyBob3N0IGNocm9tZSwgcmV2aWV3LTEgSDIpLCByZWFkLW9ubHkgZm9ybXVsYVxuLy8gICAgc291cmNlLCBuYXZpZ2FibGUgaW5wdXQgY2hpcHMgKHRoZSBWMyBob3AtYnktaG9wIHdhbGspLCB0aGUgY292ZXJhZ2Ugc3RhdGUsXG4vLyAgICB0aGUgcHJlY2VkZW50IG5laWdoYm9yaG9vZCwgdGhlIHdoYXQtaWYgZG9vciBhbmQgdGhlIFIzLTQyNyBhbmNob3JzO1xuLy8gIMK3IHRoZSBlZGl0IGRvb3IgKFIzLTQ0NywgRE9DVU1FTlRfTkFWSUdBVE9SX1NQRUMgwqczL8KnNCkg4oCUIHByZXNlbnQgYmVzaWRlIHRoZVxuLy8gICAgYW5jaG9ycyBvbmx5IHdoZXJlIHRoZSByb3figJlzIHBhdGggcGFzc2VzIHRoZSBnYXRlLCBhYnNlbnQgKG5ldmVyIGRpc2FibGVkKVxuLy8gICAgb3RoZXJ3aXNlLCB3aXRoIHRoZSBSQ0Qgwqc1LjEgZGlzY2xvc3VyZSDigJQgc3RhdGljIHJlbmRlciBjb3ZlcnMgcHJlc2VuY2UgYW5kXG4vLyAgICB0aGUgbm8taG9zdC1ib290IHByb3BlcnR5OyB0aGUgRE9NIGhhbGYgZHJpdmVzIHRoZSBjbGljay5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBhY3QsIGNyZWF0ZUVsZW1lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290LCB0eXBlIFJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCB7IHJlbmRlclRvU3RhdGljTWFya3VwIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG5pbXBvcnQgVmFsdWVJbnNwZWN0b3IgZnJvbSAnLi9WYWx1ZUluc3BlY3Rvci50c3gnO1xuaW1wb3J0IHR5cGUgeyBDZWxsRGVzY3JpcHRvciwgU3ViamVjdFJlc3VsdCwgVGVzdERlc2NyaXB0b3IgfSBmcm9tICcuLi9lbmdpbmUvd29ya2VyL3Byb3RvY29sLnRzJztcbmltcG9ydCB0eXBlIHsgSW5wdXRSZXNvbHZlciB9IGZyb20gJy4uL2VuZ2luZS90eXBlcy50cyc7XG5cbi8vIHJlYWN0LWRvbS9jbGllbnQgcmVxdWlyZXMgdGhlIGFjdCBlbnZpcm9ubWVudCBmbGFnIHRvIGZsdXNoIGVmZmVjdHMgZGV0ZXJtaW5pc3RpY2FsbHkuXG4oZ2xvYmFsVGhpcyBhcyB1bmtub3duIGFzIHsgSVNfUkVBQ1RfQUNUX0VOVklST05NRU5UOiBib29sZWFuIH0pLklTX1JFQUNUX0FDVF9FTlZJUk9OTUVOVCA9IHRydWU7XG5cbmNvbnN0IHJlc29sdmVyczogSW5wdXRSZXNvbHZlcltdID0gW1xuICB7IG5hbWU6ICdyb3dzJywga2luZDogJ2V4dGVybmFsJywga2V5OiAnZmVlZHMub3JkZXJzJyB9LFxuICB7IG5hbWU6ICdyYXcnLCBraW5kOiAnY2VsbCcsIG5vZGVJZDogJ3JldmVudWUucmF3JyB9LFxuICB7IG5hbWU6ICd0YWlsJywga2luZDogJ3dpbmRvd2VkLWZlZWQnLCBmZWVkOiAnb3JkZXJzJywgd2luZG93OiAnMWgnLCBieTogJ3RzJyB9LFxuICB7IG5hbWU6ICdhbGwnLCBraW5kOiAnd2lsZGNhcmQnLCB3b3Jrc2hlZXQ6ICdyZXZlbnVlJyB9LFxuXTtcblxuY29uc3QgY2VsbDogQ2VsbERlc2NyaXB0b3IgPSB7XG4gIGlkOiAncmV2ZW51ZS50b3RhbCcsXG4gIHdvcmtzaGVldDogJ3JldmVudWUnLFxuICBjZWxsOiAndG90YWwnLFxuICBkb2M6ICd0b3RhbCByZXZlbnVlLCBFVVItbm9ybWFsaXplZCcsXG4gIGZvcm11bGFTb3VyY2U6ICcoeyByb3dzLCByYXcgfSkgPT4gcm93cy5yZWR1Y2UoKGEsIHIpID0+IGEgKyByLmV1ciwgMCkgKyByYXcnLFxuICBkZXBzOiBbJ3JldmVudWUucmF3J10sXG4gIGV4dGVybmFsczogWydmZWVkcy5vcmRlcnMnXSxcbiAgcmVzb2x2ZXJzLFxufTtcblxuY29uc3QgdGVzdHM6IFRlc3REZXNjcmlwdG9yW10gPSBbXG4gIHsgaWQ6ICdyZXZlbnVlLnRvdGFsX2NoZWNrJywgd29ya3NoZWV0OiAncmV2ZW51ZScsIG5hbWU6ICd0b3RhbF9jaGVjaycsIGtpbmQ6ICdzcGVjaWZpY2F0aW9uJywgc3ViamVjdDogJ3JldmVudWUudG90YWwnLCBpbnB1dHM6IHt9IH0sXG5dO1xuXG5jb25zdCBvdXRjb21lOiBTdWJqZWN0UmVzdWx0ID0ge1xuICBzdWJqZWN0OiAncmV2ZW51ZS50b3RhbCcsXG4gIHZlcmRpY3Q6ICdwaW5uZWQnLFxuICBvdXRjb21lczogW3sgaWQ6ICdyZXZlbnVlLnRvdGFsX2NoZWNrJywga2luZDogJ3NwZWNpZmljYXRpb24nLCBwYXNzOiB0cnVlLCBtZXNzYWdlOiAnJyB9XSxcbn07XG5cbmZ1bmN0aW9uIHJlbmRlcihvdmVyOiBQYXJ0aWFsPFBhcmFtZXRlcnM8dHlwZW9mIFZhbHVlSW5zcGVjdG9yPlswXT4gPSB7fSk6IHN0cmluZyB7XG4gIGNvbnN0IHByb3BzID0ge1xuICAgIGNlbGwsXG4gICAgY2VsbHM6IFtjZWxsLCAuLi5leHRyYUNlbGxzXSxcbiAgICB0ZXN0cyxcbiAgICB2ZXJkaWN0czogbmV3IE1hcChbW291dGNvbWUuc3ViamVjdCwgb3V0Y29tZV1dKSxcbiAgICByZXN1bHQ6IHsgaWQ6ICdyZXZlbnVlLnRvdGFsJywgdmFsdWU6IDQ4XzEyMCwgdGllcjogJ2xpdmUnIGFzIGNvbnN0LCBrZXk6ICdrJyB9LFxuICAgIG9uTmF2aWdhdGU6ICgpID0+IHt9LFxuICAgIG9uQ2xvc2U6ICgpID0+IHt9LFxuICAgIC4uLm92ZXIsXG4gIH07XG4gIHJldHVybiByZW5kZXJUb1N0YXRpY01hcmt1cChjcmVhdGVFbGVtZW50KFZhbHVlSW5zcGVjdG9yLCBwcm9wcykpO1xufVxuXG4vKiogVXBzdHJlYW0gY2VsbHMgdGhlIHByZWNlZGVudCBuZWlnaGJvcmhvb2QgY2FuIHdhbGsgaW50by4gKi9cbmNvbnN0IGV4dHJhQ2VsbHMgPSBbXG4gIHtcbiAgICBpZDogJ3JldmVudWUucmF3JyxcbiAgICB3b3Jrc2hlZXQ6ICdyZXZlbnVlJyxcbiAgICBjZWxsOiAncmF3JyxcbiAgICBkb2M6ICdyYXcgcm93cycsXG4gICAgZm9ybXVsYVNvdXJjZTogJyh7IHJvd3MgfSkgPT4gcm93cycsXG4gICAgZGVwczogW10sXG4gICAgZXh0ZXJuYWxzOiBbJ2ZlZWRzLm9yZGVycyddLFxuICAgIHJlc29sdmVyczogW3sgbmFtZTogJ3Jvd3MnLCBraW5kOiAnZXh0ZXJuYWwnLCBrZXk6ICdmZWVkcy5vcmRlcnMnIH1dIGFzIG5ldmVyLFxuICB9LFxuICB7XG4gICAgaWQ6ICdyZXZlbnVlLmJhc2UnLFxuICAgIHdvcmtzaGVldDogJ3JldmVudWUnLFxuICAgIGNlbGw6ICdiYXNlJyxcbiAgICBkb2M6ICdiYXNlJyxcbiAgICBmb3JtdWxhU291cmNlOiAnKHsgciB9KSA9PiByLmxlbmd0aCcsXG4gICAgZGVwczogWydyZXZlbnVlLnJhdyddLFxuICAgIGV4dGVybmFsczogW10sXG4gICAgcmVzb2x2ZXJzOiBbeyBuYW1lOiAncicsIGtpbmQ6ICdjZWxsJywgbm9kZUlkOiAncmV2ZW51ZS5yYXcnIH1dIGFzIG5ldmVyLFxuICB9LFxuXTtcblxuZGVzY3JpYmUoJ1ZhbHVlSW5zcGVjdG9yJywgKCkgPT4ge1xuICBjb25zdCBodG1sID0gcmVuZGVyKCk7XG5cbiAgaXQoJ3JlbmRlcnMgdGhlIGJpbmRpbmcgbmFtZSwgZG9jLCB2YWx1ZSwgdGllciAoYXMgZGF0YSDigJQgbmV2ZXIgYSBiYWRnZSksIGFuZCB2ZXJkaWN0JywgKCkgPT4ge1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JldmVudWUudG90YWwnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCd0b3RhbCByZXZlbnVlLCBFVVItbm9ybWFsaXplZCcpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJzQ4MTIwJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigndGllciBsaXZlJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmstdmVyZGljdC0tcGlubmVkJyk7XG4gICAgLy8gdGhlIHRpZXIgYmFkZ2UgaXMgaG9zdC1kcmF3biBjaHJvbWU7IHRoZSBhcHAgbmV2ZXIgcmVuZGVycyBvbmUgKHJldmlldy0xIEgyKVxuICAgIGV4cGVjdChodG1sKS5ub3QudG9NYXRjaCgvYmFkZ2UvaSk7XG4gIH0pO1xuXG4gIGl0KCdyZW5kZXJzIHRoZSBmb3JtdWxhIHNvdXJjZSByZWFkLW9ubHknLCAoKSA9PiB7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncm93cy5yZWR1Y2UoKGEsIHIpID0mZ3Q7IGEgKyByLmV1ciwgMCknKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCc8cHJlJyk7XG4gIH0pO1xuXG4gIGl0KCdkZWNsYXJlZCBpbnB1dHMgcmVuZGVyIGFzIGNoaXBzIOKAlCBjZWxsIHJlZnMgbmF2aWdhYmxlLCBleHRlcm5hbHMgYW5kIHdpbmRvd3MgaW5lcnQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncm93cyDihpAgZmVlZHMub3JkZXJzJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmF3IOKGkCByZXZlbnVlLnJhdycpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3RhaWwg4oaQIGZlZWQgb3JkZXJzIMK3IDFoJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignYWxsIOKGkCByZXZlbnVlLionKTtcbiAgICAvLyB0aGUgY2VsbC1yZWYgY2hpcCBpcyB0aGUgb25seSBuYXZpZ2FibGUgb25lXG4gICAgY29uc3QgY2hpcHMgPSBodG1sLm1hdGNoKC9yay1jaGlwW15cIl0qL2cpID8/IFtdO1xuICAgIGV4cGVjdChjaGlwcy5maWx0ZXIoKGMpID0+IGMuaW5jbHVkZXMoJ3JrLWNoaXAtLW5hdicpKSkudG9IYXZlTGVuZ3RoKDEpO1xuICB9KTtcblxuICBpdCgndGhpcyBjZWxs4oCZcyB0ZXN0cyByZW5kZXIgd2l0aCBraW5kIGFuZCBvdXRjb21lJywgKCkgPT4ge1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJz5zcGVjaWZpY2F0aW9uPCcpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3RvdGFsX2NoZWNrJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignPnBhc3M8Jyk7XG4gIH0pO1xuXG4gIGl0KCdhbiBhYnNlbnQgb3V0Y29tZSByZW5kZXJzIHVudGVzdGVkOyBhIGZhaWxpbmcgdGVzdCBzaG93cyBpdHMgbWVzc2FnZScsICgpID0+IHtcbiAgICBjb25zdCB1bnRlc3RlZCA9IHJlbmRlcih7IHZlcmRpY3RzOiBuZXcgTWFwKCkgfSk7XG4gICAgZXhwZWN0KHVudGVzdGVkKS50b0NvbnRhaW4oJ3JrLXZlcmRpY3QtLXVudGVzdGVkJyk7XG5cbiAgICBjb25zdCBmYWlsaW5nID0gcmVuZGVyKHtcbiAgICAgIHZlcmRpY3RzOiBuZXcgTWFwKFtcbiAgICAgICAgW1xuICAgICAgICAgICdyZXZlbnVlLnRvdGFsJyxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBzdWJqZWN0OiAncmV2ZW51ZS50b3RhbCcsXG4gICAgICAgICAgICB2ZXJkaWN0OiAnZmFpbGluZycsXG4gICAgICAgICAgICBvdXRjb21lczogW3sgaWQ6ICdyZXZlbnVlLnRvdGFsX2NoZWNrJywga2luZDogJ3NwZWNpZmljYXRpb24nLCBwYXNzOiBmYWxzZSwgbWVzc2FnZTogJ2V4cGVjdGVkIDMwLCBnb3QgMjknIH1dLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICBdKSxcbiAgICB9KTtcbiAgICBleHBlY3QoZmFpbGluZykudG9Db250YWluKCdyay12ZXJkaWN0LS1mYWlsaW5nJyk7XG4gICAgZXhwZWN0KGZhaWxpbmcpLnRvQ29udGFpbignZXhwZWN0ZWQgMzAsIGdvdCAyOScpO1xuICB9KTtcblxuICBpdCgnbnVsbCByZXN1bHRzIChzdWl0ZXMgc3RpbGwgY29tcHV0aW5nKSByZW5kZXIgdGhlIGRpc3RpbmN0IHBlbmRpbmcgY2hpcCwgbmV2ZXIgdW50ZXN0ZWQnLCAoKSA9PiB7XG4gICAgY29uc3QgcGVuZGluZyA9IHJlbmRlcih7IHZlcmRpY3RzOiBudWxsIH0pO1xuICAgIGV4cGVjdChwZW5kaW5nKS50b0NvbnRhaW4oJ3JrLXZlcmRpY3QtLXBlbmRpbmcnKTtcbiAgICBleHBlY3QocGVuZGluZykudG9Db250YWluKCc+cGVuZGluZzwnKTtcbiAgICBleHBlY3QocGVuZGluZykubm90LnRvQ29udGFpbigncmstdmVyZGljdC0tdW50ZXN0ZWQnKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ1ZhbHVlSW5zcGVjdG9yIOKAlCB0aGUgcHJlY2VkZW50IG5laWdoYm9yaG9vZCAoVVgtNCknLCAoKSA9PiB7XG4gIGl0KCdyZW5kZXJzIHRoZSB3aG9sZSBzdWJncmFwaCBiZW5lYXRoIHRoZSBjZWxsIGlucHV0cywgbmVzdGVkJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoKTtcbiAgICAvLyB0b3RhbCDihpIgcmF3IOKGkiBmZWVkcy5vcmRlcnM6IHRoZSB0d28tbGV2ZWwgd2FsayBpcyB2aXNpYmxlIGF0IG9uY2VcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1wcmVjJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbigncmF3OicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JldmVudWUucmF3Jyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignZmVlZHMub3JkZXJzJyk7XG4gICAgLy8gdGhlIG1ldGEgbGluZSBzdGF0ZXMgdGhlIHNoYXBlXG4gICAgZXhwZWN0KGh0bWwpLnRvTWF0Y2goL25vZGVzIMK3IGRlcHRoIDEvKTtcbiAgfSk7XG5cbiAgaXQoJ2EgY2VsbCB3aXRoIG9ubHkgZXh0ZXJuYWwgaW5wdXRzIHNob3dzIG5vIG5laWdoYm9yaG9vZCAobm90aGluZyB0byB3YWxrKScsICgpID0+IHtcbiAgICBjb25zdCBvbmx5RXh0ZXJuYWwgPSB7XG4gICAgICAuLi5jZWxsLFxuICAgICAgcmVzb2x2ZXJzOiBbeyBuYW1lOiAncm93cycsIGtpbmQ6ICdleHRlcm5hbCcsIGtleTogJ2ZlZWRzLm9yZGVycycgfV0gYXMgbmV2ZXIsXG4gICAgfTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKHsgY2VsbDogb25seUV4dGVybmFsIH0pO1xuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCdyay1wcmVjJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd0aGUgd2hhdC1pZiBkb29yIChzcGVjIMKnMS4xLCBhbWVuZGVkIDIwMjYtMDgtMjgpJywgKCkgPT4ge1xuICBpdCgncmVuZGVycyB0aGUgZm9ybXVsYSByb3cgYWZmb3JkYW5jZSB3aGVuIGEgaGFuZGxlciBpcyBwcm92aWRlZCwgYW5kIG5vbmUgb3RoZXJ3aXNlJywgKCkgPT4ge1xuICAgIGV4cGVjdChyZW5kZXIoeyBvbldoYXRJZjogKCkgPT4ge30gfSkpLnRvQ29udGFpbignd2hhdCBpZiDihpInKTtcbiAgICBleHBlY3QocmVuZGVyKCkpLm5vdC50b0NvbnRhaW4oJ3doYXQgaWYg4oaSJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdmaWxlOmxpbmUgYW5jaG9ycyBmcm9tIHNwYW5zIChSMy00MjcpJywgKCkgPT4ge1xuICBpdCgndGhlIGZvcm11bGEgcm93IGFuZCB0ZXN0IHJvd3MgbmFtZSB0aGVpciBleGFjdCBsb2NhdGlvbiB3aGVuIHNwYW5zICsgcGF0aHMgZXhpc3QnLCAoKSA9PiB7XG4gICAgY29uc3Qgd2l0aFNwYW4gPSB7IC4uLmNlbGwsIHNwYW46IHsgc3RhcnQ6IDAsIGVuZDogMTAsIGxpbmU6IDEyIH0gfTtcbiAgICBjb25zdCB0ZXN0c1dpdGhTcGFuID0gdGVzdHMubWFwKCh0KSA9PiAoeyAuLi50LCBzcGFuOiB7IHN0YXJ0OiAwLCBlbmQ6IDUsIGxpbmU6IDMxIH0gfSkpO1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoe1xuICAgICAgY2VsbDogd2l0aFNwYW4sXG4gICAgICB0ZXN0czogdGVzdHNXaXRoU3BhbixcbiAgICAgIHdvcmtzaGVldFBhdGhzOiB7IHJldmVudWU6ICd3b3Jrc2hlZXRzL3JldmVudWUuc2hlZXQuanMnIH0sXG4gICAgfSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignd29ya3NoZWV0cy9yZXZlbnVlLnNoZWV0LmpzOjEyJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignd29ya3NoZWV0cy9yZXZlbnVlLnNoZWV0LmpzOjMxJyk7XG4gIH0pO1xuXG4gIGl0KCdyZW5kZXJzIG5vIGFuY2hvciB3aXRob3V0IHNwYW5zIG9yIHBhdGhzIOKAlCBuZXZlciBhIHdyb25nIGxvY2F0aW9uJywgKCkgPT4ge1xuICAgIGV4cGVjdChyZW5kZXIoKSkubm90LnRvQ29udGFpbignLnNoZWV0LmpzOicpO1xuICAgIGV4cGVjdChyZW5kZXIoeyB3b3Jrc2hlZXRQYXRoczogeyByZXZlbnVlOiAnd29ya3NoZWV0cy9yZXZlbnVlLnNoZWV0LmpzJyB9IH0pKS5ub3QudG9Db250YWluKCcuc2hlZXQuanM6Jyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd0aGUgZWRpdCBkb29yIChSMy00NDcsIERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIMKnMy/CpzQpJywgKCkgPT4ge1xuICBjb25zdCBzcGFubmVkID0geyAuLi5jZWxsLCBzcGFuOiB7IHN0YXJ0OiAwLCBlbmQ6IDEwLCBsaW5lOiAxMiB9IH07XG4gIGNvbnN0IHNwYW5uZWRUZXN0cyA9IHRlc3RzLm1hcCgodCkgPT4gKHsgLi4udCwgc3BhbjogeyBzdGFydDogMCwgZW5kOiA1LCBsaW5lOiAzMSB9LCB3b3Jrc2hlZXQ6ICdjaGVja3MnIH0pKTtcbiAgY29uc3QgcGF0aHMgPSB7IHJldmVudWU6ICd3b3Jrc2hlZXRzL3JldmVudWUuc2hlZXQuanMnLCBjaGVja3M6ICd3b3Jrc2hlZXRzL2NoZWNrcy5zaGVldC5qcycgfTtcbiAgY29uc3QgRElTQ0xPU1VSRSA9ICdFZGl0cyBzYXZlIHRvIHRoZSBtb3VudGVkIGNvbnRlbnQuIFByb3Bvc2luZyBhIGNoYW5nZSBiYWNrIHRvIGl0cyByZXBvc2l0b3J5IGlzIG5vdCB3aXJlZCB5ZXQuJztcblxuICBpdCgnbm8gZG9vciBhdCBhbGwgd2hlbiB0aGUgcG9ydCBpcyBub3Qgd2lyZWQgKHRoZSBzZWVkLCBub24tZGlzcGF0Y2hlZCBmbG93KScsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKHsgY2VsbDogc3Bhbm5lZCwgdGVzdHM6IHNwYW5uZWRUZXN0cywgd29ya3NoZWV0UGF0aHM6IHBhdGhzIH0pO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3dvcmtzaGVldHMvcmV2ZW51ZS5zaGVldC5qczoxMicpOyAvLyB0aGUgYW5jaG9ycyBhcmUgc3RpbGwgZGF0YVxuICAgIGV4cGVjdChodG1sKS5ub3QudG9Db250YWluKCc+ZWRpdDwnKTtcbiAgICBleHBlY3QoaHRtbCkubm90LnRvQ29udGFpbihESVNDTE9TVVJFKTtcbiAgfSk7XG5cbiAgaXQoJ2Egcm93IHdob3NlIG93biBwYXRoIGZhaWxzIHRoZSBnYXRlIGhhcyBubyBkb29yIOKAlCB0aGUgY2xlYW4gcm93IGtlZXBzIGl0cyBvd24nLCAoKSA9PiB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlcih7XG4gICAgICBjZWxsOiBzcGFubmVkLFxuICAgICAgdGVzdHM6IHNwYW5uZWRUZXN0cyxcbiAgICAgIHdvcmtzaGVldFBhdGhzOiB7IHJldmVudWU6ICd3b3Jrc2hlZXRzLy4uLy4uL2V2aWwuc2hlZXQuanMnLCBjaGVja3M6ICd3b3Jrc2hlZXRzL2NoZWNrcy5zaGVldC5qcycgfSxcbiAgICAgIGNhbkVkaXRQYXRoOiAocmVsKSA9PiByZWwgPT09ICd3b3Jrc2hlZXRzL2NoZWNrcy5zaGVldC5qcycsXG4gICAgICBvbkVkaXQ6ICgpID0+IHt9LFxuICAgIH0pO1xuICAgIGV4cGVjdCgoaHRtbC5tYXRjaCgvPmVkaXQ8L2cpID8/IFtdKS5sZW5ndGgpLnRvQmUoMSk7IC8vIG9ubHkgdGhlIHRlc3Qgcm934oCZcyBkb29yXG4gIH0pO1xuXG4gIGl0KCd0aGUgZG9vciByZW5kZXJzIGJlc2lkZSBCT1RIIGFuY2hvcnMgd2l0aCB0aGUgZGlzY2xvc3VyZSBhdCB0aGUgYnV0dG9uJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXIoe1xuICAgICAgY2VsbDogc3Bhbm5lZCxcbiAgICAgIHRlc3RzOiBzcGFubmVkVGVzdHMsXG4gICAgICB3b3Jrc2hlZXRQYXRoczogcGF0aHMsXG4gICAgICBjYW5FZGl0UGF0aDogKCkgPT4gdHJ1ZSxcbiAgICAgIG9uRWRpdDogKCkgPT4ge30sXG4gICAgfSk7XG4gICAgZXhwZWN0KChodG1sLm1hdGNoKC8+ZWRpdDwvZykgPz8gW10pLmxlbmd0aCkudG9CZSgyKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyay1pbnMtZWRpdC1ub3RlJyk7IC8vIHRoZSB2aXNpYmxlIGRpc2Nsb3N1cmUgbGluZSwgbm90IGp1c3QgdGhlIHRvb2x0aXBcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKERJU0NMT1NVUkUpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oYHRpdGxlPVwiJHtESVNDTE9TVVJFfVwiYCk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgZGlzY2xvc3VyZSBub3RlIHJlbmRlcnMgd2hlbiBPTkxZIGEgdGVzdCByb3cgY2FycmllcyBhIGRvb3IgKHBpbm5lZCBvbiB0aGUgbm90ZSBlbGVtZW50LCBub3QgdGhlIHRvb2x0aXAgc3RyaW5nKScsICgpID0+IHtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyKHtcbiAgICAgIGNlbGw6IHNwYW5uZWQsXG4gICAgICB0ZXN0czogc3Bhbm5lZFRlc3RzLFxuICAgICAgd29ya3NoZWV0UGF0aHM6IHBhdGhzLFxuICAgICAgY2FuRWRpdFBhdGg6IChyZWwpID0+IHJlbCA9PT0gJ3dvcmtzaGVldHMvY2hlY2tzLnNoZWV0LmpzJyxcbiAgICAgIG9uRWRpdDogKCkgPT4ge30sXG4gICAgfSk7XG4gICAgZXhwZWN0KChodG1sLm1hdGNoKC8+ZWRpdDwvZykgPz8gW10pLmxlbmd0aCkudG9CZSgxKTtcbiAgICAvLyB0aGUgbm90ZSBFTEVNRU5UIGlzIHRoZSBhc3NlcnRpb246IHRoZSB0b29sdGlwIGNhcnJpZXMgdGhlIHNhbWUgc3RyaW5nLCBzbyBhXG4gICAgLy8gYmFyZSB0b0NvbnRhaW4oRElTQ0xPU1VSRSkgd291bGQgcGFzcyBldmVuIHdpdGggdGhlIG5vdGUgZ2F0ZWQgb24gdGhlIGZvcm11bGFcbiAgICAvLyByb3cncyBkb29yIGFsb25lIChyb3VuZCAxJ3MgYnVnKSDigJQgdGhpcyBpcyB0aGUgbGluZSB0aGF0IGZhaWxzIHdpdGhvdXQgYW55RG9vclxuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3JrLWlucy1lZGl0LW5vdGUnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKERJU0NMT1NVUkUpO1xuICB9KTtcblxuICBpdCgnYSBjbGljayBoYW5kcyB0aGUgcm934oCZcyBvd24gZG9jdW1lbnQtcmVsYXRpdmUgcGF0aCB0byB0aGUgZG9vcicsICgpID0+IHtcbiAgICBjb25zdCBvbkVkaXQgPSB2aS5mbigpO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgICBjb25zdCByb290OiBSb290ID0gY3JlYXRlUm9vdChjb250YWluZXIpO1xuICAgIGFjdCgoKSA9PiB7XG4gICAgICByb290LnJlbmRlcihcbiAgICAgICAgY3JlYXRlRWxlbWVudChWYWx1ZUluc3BlY3Rvciwge1xuICAgICAgICAgIGNlbGw6IHNwYW5uZWQsXG4gICAgICAgICAgY2VsbHM6IFtzcGFubmVkXSxcbiAgICAgICAgICB0ZXN0czogc3Bhbm5lZFRlc3RzLFxuICAgICAgICAgIHZlcmRpY3RzOiBuZXcgTWFwKFtbb3V0Y29tZS5zdWJqZWN0LCBvdXRjb21lXV0pLFxuICAgICAgICAgIHJlc3VsdDogdW5kZWZpbmVkLFxuICAgICAgICAgIG9uTmF2aWdhdGU6ICgpID0+IHt9LFxuICAgICAgICAgIG9uQ2xvc2U6ICgpID0+IHt9LFxuICAgICAgICAgIHdvcmtzaGVldFBhdGhzOiBwYXRocyxcbiAgICAgICAgICBjYW5FZGl0UGF0aDogKCkgPT4gdHJ1ZSxcbiAgICAgICAgICBvbkVkaXQsXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9KTtcbiAgICBjb25zdCBidXR0b25zID0gWy4uLmNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdidXR0b24nKV0uZmlsdGVyKChiKSA9PiBiLnRleHRDb250ZW50ID09PSAnZWRpdCcpO1xuICAgIGV4cGVjdChidXR0b25zLmxlbmd0aCkudG9CZSgyKTtcbiAgICBhY3QoKCkgPT4ge1xuICAgICAgYnV0dG9uc1swXS5kaXNwYXRjaEV2ZW50KG5ldyBNb3VzZUV2ZW50KCdjbGljaycsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG4gICAgICBidXR0b25zWzFdLmRpc3BhdGNoRXZlbnQobmV3IE1vdXNlRXZlbnQoJ2NsaWNrJywgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgICB9KTtcbiAgICBleHBlY3Qob25FZGl0KS50b0hhdmVCZWVuQ2FsbGVkV2l0aCgnd29ya3NoZWV0cy9yZXZlbnVlLnNoZWV0LmpzJyk7XG4gICAgZXhwZWN0KG9uRWRpdCkudG9IYXZlQmVlbkNhbGxlZFdpdGgoJ3dvcmtzaGVldHMvY2hlY2tzLnNoZWV0LmpzJyk7XG4gICAgYWN0KCgpID0+IHJvb3QudW5tb3VudCgpKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQVVBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGVBQUEsR0FBQUMsc0JBQUEsQ0FBQUwsT0FBQTtBQUFrRCxTQUFBSyx1QkFBQUMsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWRsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFTQTtBQUNDRyxVQUFVLENBQXNEQyx3QkFBd0IsR0FBRyxJQUFJO0FBRWhHLE1BQU1DLFNBQTBCLEdBQUcsQ0FDakM7RUFBRUMsSUFBSSxFQUFFLE1BQU07RUFBRUMsSUFBSSxFQUFFLFVBQVU7RUFBRUMsR0FBRyxFQUFFO0FBQWUsQ0FBQyxFQUN2RDtFQUFFRixJQUFJLEVBQUUsS0FBSztFQUFFQyxJQUFJLEVBQUUsTUFBTTtFQUFFRSxNQUFNLEVBQUU7QUFBYyxDQUFDLEVBQ3BEO0VBQUVILElBQUksRUFBRSxNQUFNO0VBQUVDLElBQUksRUFBRSxlQUFlO0VBQUVHLElBQUksRUFBRSxRQUFRO0VBQUVDLE1BQU0sRUFBRSxJQUFJO0VBQUVDLEVBQUUsRUFBRTtBQUFLLENBQUMsRUFDL0U7RUFBRU4sSUFBSSxFQUFFLEtBQUs7RUFBRUMsSUFBSSxFQUFFLFVBQVU7RUFBRU0sU0FBUyxFQUFFO0FBQVUsQ0FBQyxDQUN4RDtBQUVELE1BQU1DLElBQW9CLEdBQUc7RUFDM0JDLEVBQUUsRUFBRSxlQUFlO0VBQ25CRixTQUFTLEVBQUUsU0FBUztFQUNwQkMsSUFBSSxFQUFFLE9BQU87RUFDYkUsR0FBRyxFQUFFLCtCQUErQjtFQUNwQ0MsYUFBYSxFQUFFLDhEQUE4RDtFQUM3RUMsSUFBSSxFQUFFLENBQUMsYUFBYSxDQUFDO0VBQ3JCQyxTQUFTLEVBQUUsQ0FBQyxjQUFjLENBQUM7RUFDM0JkO0FBQ0YsQ0FBQztBQUVELE1BQU1lLEtBQXVCLEdBQUcsQ0FDOUI7RUFBRUwsRUFBRSxFQUFFLHFCQUFxQjtFQUFFRixTQUFTLEVBQUUsU0FBUztFQUFFUCxJQUFJLEVBQUUsYUFBYTtFQUFFQyxJQUFJLEVBQUUsZUFBZTtFQUFFYyxPQUFPLEVBQUUsZUFBZTtFQUFFQyxNQUFNLEVBQUUsQ0FBQztBQUFFLENBQUMsQ0FDdEk7QUFFRCxNQUFNQyxPQUFzQixHQUFHO0VBQzdCRixPQUFPLEVBQUUsZUFBZTtFQUN4QkcsT0FBTyxFQUFFLFFBQVE7RUFDakJDLFFBQVEsRUFBRSxDQUFDO0lBQUVWLEVBQUUsRUFBRSxxQkFBcUI7SUFBRVIsSUFBSSxFQUFFLGVBQWU7SUFBRW1CLElBQUksRUFBRSxJQUFJO0lBQUVDLE9BQU8sRUFBRTtFQUFHLENBQUM7QUFDMUYsQ0FBQztBQUVELFNBQVNDLE1BQU1BLENBQUNDLElBQW1ELEdBQUcsQ0FBQyxDQUFDLEVBQVU7RUFDaEYsTUFBTUMsS0FBSyxHQUFHO0lBQ1poQixJQUFJO0lBQ0ppQixLQUFLLEVBQUUsQ0FBQ2pCLElBQUksRUFBRSxHQUFHa0IsVUFBVSxDQUFDO0lBQzVCWixLQUFLO0lBQ0xhLFFBQVEsRUFBRSxJQUFJQyxHQUFHLENBQUMsQ0FBQyxDQUFDWCxPQUFPLENBQUNGLE9BQU8sRUFBRUUsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQ1ksTUFBTSxFQUFFO01BQUVwQixFQUFFLEVBQUUsZUFBZTtNQUFFcUIsS0FBSyxFQUFFLE1BQU07TUFBRUMsSUFBSSxFQUFFLE1BQWU7TUFBRTdCLEdBQUcsRUFBRTtJQUFJLENBQUM7SUFDL0U4QixVQUFVLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7SUFDcEJDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBQztJQUNqQixHQUFHVjtFQUNMLENBQUM7RUFDRCxPQUFPLElBQUFXLDRCQUFvQixlQUFDLElBQUFDLG9CQUFhLEVBQUNDLHVCQUFjLEVBQUVaLEtBQUssQ0FBQyxDQUFDO0FBQ25FOztBQUVBO0FBQ0EsTUFBTUUsVUFBVSxHQUFHLENBQ2pCO0VBQ0VqQixFQUFFLEVBQUUsYUFBYTtFQUNqQkYsU0FBUyxFQUFFLFNBQVM7RUFDcEJDLElBQUksRUFBRSxLQUFLO0VBQ1hFLEdBQUcsRUFBRSxVQUFVO0VBQ2ZDLGFBQWEsRUFBRSxvQkFBb0I7RUFDbkNDLElBQUksRUFBRSxFQUFFO0VBQ1JDLFNBQVMsRUFBRSxDQUFDLGNBQWMsQ0FBQztFQUMzQmQsU0FBUyxFQUFFLENBQUM7SUFBRUMsSUFBSSxFQUFFLE1BQU07SUFBRUMsSUFBSSxFQUFFLFVBQVU7SUFBRUMsR0FBRyxFQUFFO0VBQWUsQ0FBQztBQUNyRSxDQUFDLEVBQ0Q7RUFDRU8sRUFBRSxFQUFFLGNBQWM7RUFDbEJGLFNBQVMsRUFBRSxTQUFTO0VBQ3BCQyxJQUFJLEVBQUUsTUFBTTtFQUNaRSxHQUFHLEVBQUUsTUFBTTtFQUNYQyxhQUFhLEVBQUUscUJBQXFCO0VBQ3BDQyxJQUFJLEVBQUUsQ0FBQyxhQUFhLENBQUM7RUFDckJDLFNBQVMsRUFBRSxFQUFFO0VBQ2JkLFNBQVMsRUFBRSxDQUFDO0lBQUVDLElBQUksRUFBRSxHQUFHO0lBQUVDLElBQUksRUFBRSxNQUFNO0lBQUVFLE1BQU0sRUFBRTtFQUFjLENBQUM7QUFDaEUsQ0FBQyxDQUNGO0FBRUQsSUFBQWtDLGdCQUFRLEVBQUMsZ0JBQWdCLEVBQUUsTUFBTTtFQUMvQixNQUFNQyxJQUFJLEdBQUdoQixNQUFNLENBQUMsQ0FBQztFQUVyQixJQUFBaUIsVUFBRSxFQUFDLG1GQUFtRixFQUFFLE1BQU07SUFDNUYsSUFBQUMsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGVBQWUsQ0FBQztJQUN2QyxJQUFBRCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsK0JBQStCLENBQUM7SUFDdkQsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLE9BQU8sQ0FBQztJQUMvQixJQUFBRCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ25DLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQztJQUM1QztJQUNBLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNJLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLFFBQVEsQ0FBQztFQUNwQyxDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsc0NBQXNDLEVBQUUsTUFBTTtJQUMvQyxJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsd0NBQXdDLENBQUM7SUFDaEUsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUNoQyxDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMsb0ZBQW9GLEVBQUUsTUFBTTtJQUM3RixJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDN0MsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLG1CQUFtQixDQUFDO0lBQzNDLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQztJQUNqRCxJQUFBRCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsaUJBQWlCLENBQUM7SUFDekM7SUFDQSxNQUFNRyxLQUFLLEdBQUdOLElBQUksQ0FBQ08sS0FBSyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUU7SUFDL0MsSUFBQUwsY0FBTSxFQUFDSSxLQUFLLENBQUNFLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDekUsQ0FBQyxDQUFDO0VBRUYsSUFBQVYsVUFBRSxFQUFDLGdEQUFnRCxFQUFFLE1BQU07SUFDekQsSUFBQUMsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGlCQUFpQixDQUFDO0lBQ3pDLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxhQUFhLENBQUM7SUFDckMsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLFFBQVEsQ0FBQztFQUNsQyxDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMsc0VBQXNFLEVBQUUsTUFBTTtJQUMvRSxNQUFNVyxRQUFRLEdBQUc1QixNQUFNLENBQUM7TUFBRUssUUFBUSxFQUFFLElBQUlDLEdBQUcsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUNoRCxJQUFBWSxjQUFNLEVBQUNVLFFBQVEsQ0FBQyxDQUFDVCxTQUFTLENBQUMsc0JBQXNCLENBQUM7SUFFbEQsTUFBTVUsT0FBTyxHQUFHN0IsTUFBTSxDQUFDO01BQ3JCSyxRQUFRLEVBQUUsSUFBSUMsR0FBRyxDQUFDLENBQ2hCLENBQ0UsZUFBZSxFQUNmO1FBQ0ViLE9BQU8sRUFBRSxlQUFlO1FBQ3hCRyxPQUFPLEVBQUUsU0FBUztRQUNsQkMsUUFBUSxFQUFFLENBQUM7VUFBRVYsRUFBRSxFQUFFLHFCQUFxQjtVQUFFUixJQUFJLEVBQUUsZUFBZTtVQUFFbUIsSUFBSSxFQUFFLEtBQUs7VUFBRUMsT0FBTyxFQUFFO1FBQXNCLENBQUM7TUFDOUcsQ0FBQyxDQUNGLENBQ0Y7SUFDSCxDQUFDLENBQUM7SUFDRixJQUFBbUIsY0FBTSxFQUFDVyxPQUFPLENBQUMsQ0FBQ1YsU0FBUyxDQUFDLHFCQUFxQixDQUFDO0lBQ2hELElBQUFELGNBQU0sRUFBQ1csT0FBTyxDQUFDLENBQUNWLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQztFQUNsRCxDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMsd0ZBQXdGLEVBQUUsTUFBTTtJQUNqRyxNQUFNYSxPQUFPLEdBQUc5QixNQUFNLENBQUM7TUFBRUssUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzFDLElBQUFhLGNBQU0sRUFBQ1ksT0FBTyxDQUFDLENBQUNYLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQztJQUNoRCxJQUFBRCxjQUFNLEVBQUNZLE9BQU8sQ0FBQyxDQUFDWCxTQUFTLENBQUMsV0FBVyxDQUFDO0lBQ3RDLElBQUFELGNBQU0sRUFBQ1ksT0FBTyxDQUFDLENBQUNWLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLHNCQUFzQixDQUFDO0VBQ3ZELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFKLGdCQUFRLEVBQUMsb0RBQW9ELEVBQUUsTUFBTTtFQUNuRSxJQUFBRSxVQUFFLEVBQUMsNERBQTRELEVBQUUsTUFBTTtJQUNyRSxNQUFNRCxJQUFJLEdBQUdoQixNQUFNLENBQUMsQ0FBQztJQUNyQjtJQUNBLElBQUFrQixjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsU0FBUyxDQUFDO0lBQ2pDLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxNQUFNLENBQUM7SUFDOUIsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGFBQWEsQ0FBQztJQUNyQyxJQUFBRCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsY0FBYyxDQUFDO0lBQ3RDO0lBQ0EsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLGlCQUFpQixDQUFDO0VBQ3pDLENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0lBQ25GLE1BQU1jLFlBQVksR0FBRztNQUNuQixHQUFHN0MsSUFBSTtNQUNQVCxTQUFTLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUUsTUFBTTtRQUFFQyxJQUFJLEVBQUUsVUFBVTtRQUFFQyxHQUFHLEVBQUU7TUFBZSxDQUFDO0lBQ3JFLENBQUM7SUFDRCxNQUFNb0MsSUFBSSxHQUFHaEIsTUFBTSxDQUFDO01BQUVkLElBQUksRUFBRTZDO0lBQWEsQ0FBQyxDQUFDO0lBQzNDLElBQUFiLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNJLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLFNBQVMsQ0FBQztFQUN2QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLGtEQUFrRCxFQUFFLE1BQU07RUFDakUsSUFBQUUsVUFBRSxFQUFDLG1GQUFtRixFQUFFLE1BQU07SUFDNUYsSUFBQUMsY0FBTSxFQUFDbEIsTUFBTSxDQUFDO01BQUVnQyxRQUFRLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ2IsU0FBUyxDQUFDLFdBQVcsQ0FBQztJQUM3RCxJQUFBRCxjQUFNLEVBQUNsQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNvQixHQUFHLENBQUNELFNBQVMsQ0FBQyxXQUFXLENBQUM7RUFDN0MsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQUosZ0JBQVEsRUFBQyx1Q0FBdUMsRUFBRSxNQUFNO0VBQ3RELElBQUFFLFVBQUUsRUFBQyxrRkFBa0YsRUFBRSxNQUFNO0lBQzNGLE1BQU1nQixRQUFRLEdBQUc7TUFBRSxHQUFHL0MsSUFBSTtNQUFFZ0QsSUFBSSxFQUFFO1FBQUVDLEtBQUssRUFBRSxDQUFDO1FBQUVDLEdBQUcsRUFBRSxFQUFFO1FBQUVDLElBQUksRUFBRTtNQUFHO0lBQUUsQ0FBQztJQUNuRSxNQUFNQyxhQUFhLEdBQUc5QyxLQUFLLENBQUMrQyxHQUFHLENBQUVDLENBQUMsS0FBTTtNQUFFLEdBQUdBLENBQUM7TUFBRU4sSUFBSSxFQUFFO1FBQUVDLEtBQUssRUFBRSxDQUFDO1FBQUVDLEdBQUcsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRTtNQUFHO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDeEYsTUFBTXJCLElBQUksR0FBR2hCLE1BQU0sQ0FBQztNQUNsQmQsSUFBSSxFQUFFK0MsUUFBUTtNQUNkekMsS0FBSyxFQUFFOEMsYUFBYTtNQUNwQkcsY0FBYyxFQUFFO1FBQUVDLE9BQU8sRUFBRTtNQUE4QjtJQUMzRCxDQUFDLENBQUM7SUFDRixJQUFBeEIsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGdDQUFnQyxDQUFDO0lBQ3hELElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxnQ0FBZ0MsQ0FBQztFQUMxRCxDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMsbUVBQW1FLEVBQUUsTUFBTTtJQUM1RSxJQUFBQyxjQUFNLEVBQUNsQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNvQixHQUFHLENBQUNELFNBQVMsQ0FBQyxZQUFZLENBQUM7SUFDNUMsSUFBQUQsY0FBTSxFQUFDbEIsTUFBTSxDQUFDO01BQUV5QyxjQUFjLEVBQUU7UUFBRUMsT0FBTyxFQUFFO01BQThCO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3RCLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLFlBQVksQ0FBQztFQUM1RyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBSixnQkFBUSxFQUFDLHVEQUF1RCxFQUFFLE1BQU07RUFDdEUsTUFBTTRCLE9BQU8sR0FBRztJQUFFLEdBQUd6RCxJQUFJO0lBQUVnRCxJQUFJLEVBQUU7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsR0FBRyxFQUFFLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQUc7RUFBRSxDQUFDO0VBQ2xFLE1BQU1PLFlBQVksR0FBR3BELEtBQUssQ0FBQytDLEdBQUcsQ0FBRUMsQ0FBQyxLQUFNO0lBQUUsR0FBR0EsQ0FBQztJQUFFTixJQUFJLEVBQUU7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsR0FBRyxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFO0lBQUcsQ0FBQztJQUFFcEQsU0FBUyxFQUFFO0VBQVMsQ0FBQyxDQUFDLENBQUM7RUFDNUcsTUFBTTRELEtBQUssR0FBRztJQUFFSCxPQUFPLEVBQUUsNkJBQTZCO0lBQUVJLE1BQU0sRUFBRTtFQUE2QixDQUFDO0VBQzlGLE1BQU1DLFVBQVUsR0FBRyxnR0FBZ0c7RUFFbkgsSUFBQTlCLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxNQUFNO0lBQ3BGLE1BQU1ELElBQUksR0FBR2hCLE1BQU0sQ0FBQztNQUFFZCxJQUFJLEVBQUV5RCxPQUFPO01BQUVuRCxLQUFLLEVBQUVvRCxZQUFZO01BQUVILGNBQWMsRUFBRUk7SUFBTSxDQUFDLENBQUM7SUFDbEYsSUFBQTNCLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUM7SUFDMUQsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0ksR0FBRyxDQUFDRCxTQUFTLENBQUMsUUFBUSxDQUFDO0lBQ3BDLElBQUFELGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNJLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDNEIsVUFBVSxDQUFDO0VBQ3hDLENBQUMsQ0FBQztFQUVGLElBQUE5QixVQUFFLEVBQUMsK0VBQStFLEVBQUUsTUFBTTtJQUN4RixNQUFNRCxJQUFJLEdBQUdoQixNQUFNLENBQUM7TUFDbEJkLElBQUksRUFBRXlELE9BQU87TUFDYm5ELEtBQUssRUFBRW9ELFlBQVk7TUFDbkJILGNBQWMsRUFBRTtRQUFFQyxPQUFPLEVBQUUsZ0NBQWdDO1FBQUVJLE1BQU0sRUFBRTtNQUE2QixDQUFDO01BQ25HRSxXQUFXLEVBQUdDLEdBQUcsSUFBS0EsR0FBRyxLQUFLLDRCQUE0QjtNQUMxREMsTUFBTSxFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUNqQixDQUFDLENBQUM7SUFDRixJQUFBaEMsY0FBTSxFQUFDLENBQUNGLElBQUksQ0FBQ08sS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFBRTRCLE1BQU0sQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN4RCxDQUFDLENBQUM7RUFFRixJQUFBbkMsVUFBRSxFQUFDLHdFQUF3RSxFQUFFLE1BQU07SUFDakYsTUFBTUQsSUFBSSxHQUFHaEIsTUFBTSxDQUFDO01BQ2xCZCxJQUFJLEVBQUV5RCxPQUFPO01BQ2JuRCxLQUFLLEVBQUVvRCxZQUFZO01BQ25CSCxjQUFjLEVBQUVJLEtBQUs7TUFDckJHLFdBQVcsRUFBRUEsQ0FBQSxLQUFNLElBQUk7TUFDdkJFLE1BQU0sRUFBRUEsQ0FBQSxLQUFNLENBQUM7SUFDakIsQ0FBQyxDQUFDO0lBQ0YsSUFBQWhDLGNBQU0sRUFBQyxDQUFDRixJQUFJLENBQUNPLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUU0QixNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNwRCxJQUFBbEMsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztJQUM1QyxJQUFBRCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUM0QixVQUFVLENBQUM7SUFDbEMsSUFBQTdCLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxVQUFVNEIsVUFBVSxHQUFHLENBQUM7RUFDakQsQ0FBQyxDQUFDO0VBRUYsSUFBQTlCLFVBQUUsRUFBQyxzSEFBc0gsRUFBRSxNQUFNO0lBQy9ILE1BQU1ELElBQUksR0FBR2hCLE1BQU0sQ0FBQztNQUNsQmQsSUFBSSxFQUFFeUQsT0FBTztNQUNibkQsS0FBSyxFQUFFb0QsWUFBWTtNQUNuQkgsY0FBYyxFQUFFSSxLQUFLO01BQ3JCRyxXQUFXLEVBQUdDLEdBQUcsSUFBS0EsR0FBRyxLQUFLLDRCQUE0QjtNQUMxREMsTUFBTSxFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUNqQixDQUFDLENBQUM7SUFDRixJQUFBaEMsY0FBTSxFQUFDLENBQUNGLElBQUksQ0FBQ08sS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFBRTRCLE1BQU0sQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3BEO0lBQ0E7SUFDQTtJQUNBLElBQUFsQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsa0JBQWtCLENBQUM7SUFDMUMsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csU0FBUyxDQUFDNEIsVUFBVSxDQUFDO0VBQ3BDLENBQUMsQ0FBQztFQUVGLElBQUE5QixVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsTUFBTTtJQUN6RSxNQUFNaUMsTUFBTSxHQUFHRyxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3RCLE1BQU1DLFNBQVMsR0FBR0MsUUFBUSxDQUFDM0MsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMvQzJDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxXQUFXLENBQUNILFNBQVMsQ0FBQztJQUNwQyxNQUFNSSxJQUFVLEdBQUcsSUFBQUMsa0JBQVUsRUFBQ0wsU0FBUyxDQUFDO0lBQ3hDLElBQUFNLFVBQUcsRUFBQyxNQUFNO01BQ1JGLElBQUksQ0FBQzNELE1BQU0sY0FDVCxJQUFBYSxvQkFBYSxFQUFDQyx1QkFBYyxFQUFFO1FBQzVCNUIsSUFBSSxFQUFFeUQsT0FBTztRQUNieEMsS0FBSyxFQUFFLENBQUN3QyxPQUFPLENBQUM7UUFDaEJuRCxLQUFLLEVBQUVvRCxZQUFZO1FBQ25CdkMsUUFBUSxFQUFFLElBQUlDLEdBQUcsQ0FBQyxDQUFDLENBQUNYLE9BQU8sQ0FBQ0YsT0FBTyxFQUFFRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQy9DWSxNQUFNLEVBQUV1RCxTQUFTO1FBQ2pCcEQsVUFBVSxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO1FBQ3BCQyxPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7UUFDakI4QixjQUFjLEVBQUVJLEtBQUs7UUFDckJHLFdBQVcsRUFBRUEsQ0FBQSxLQUFNLElBQUk7UUFDdkJFO01BQ0YsQ0FBQyxDQUNILENBQUM7SUFDSCxDQUFDLENBQUM7SUFDRixNQUFNYSxPQUFPLEdBQUcsQ0FBQyxHQUFHUixTQUFTLENBQUNTLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUN4QyxNQUFNLENBQUV5QyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsV0FBVyxLQUFLLE1BQU0sQ0FBQztJQUNqRyxJQUFBaEQsY0FBTSxFQUFDNkMsT0FBTyxDQUFDWixNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5QixJQUFBUyxVQUFHLEVBQUMsTUFBTTtNQUNSRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNJLGFBQWEsQ0FBQyxJQUFJQyxVQUFVLENBQUMsT0FBTyxFQUFFO1FBQUVDLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQyxDQUFDO01BQ3BFTixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNJLGFBQWEsQ0FBQyxJQUFJQyxVQUFVLENBQUMsT0FBTyxFQUFFO1FBQUVDLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLENBQUMsQ0FBQztJQUNGLElBQUFuRCxjQUFNLEVBQUNnQyxNQUFNLENBQUMsQ0FBQ29CLG9CQUFvQixDQUFDLDZCQUE2QixDQUFDO0lBQ2xFLElBQUFwRCxjQUFNLEVBQUNnQyxNQUFNLENBQUMsQ0FBQ29CLG9CQUFvQixDQUFDLDRCQUE0QixDQUFDO0lBQ2pFLElBQUFULFVBQUcsRUFBQyxNQUFNRixJQUFJLENBQUNZLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDM0IsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}