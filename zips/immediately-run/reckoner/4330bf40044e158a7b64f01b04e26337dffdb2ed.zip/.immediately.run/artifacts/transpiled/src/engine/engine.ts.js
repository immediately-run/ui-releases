"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Engine = void 0;
var _graph = require("./graph.ts");
var _resolve = require("./resolve.ts");
var _scheduler = require("./scheduler.ts");
var _testrunner = require("./testrunner.ts");
var _compartment = require("./compartment.ts");
// The engine orchestrator (ARCHITECTURE_PLAN §4) — ties the pure spine into one runnable
// pipeline: worksheet sources → SES-confined evaluation → dependency graph → recalc
// scheduler → published results, plus the tests-as-cells run and the review-surface
// verdict. The confined-formula execution is the one effectful step; everything else is the
// pure machinery from ./scheduler, ./graph, ./testrunner and ../stdlib.

class Engine {
  /** Test cells, keyed by the subject cell id they validate. */

  #cellDef = new Map();
  constructor(workbook) {
    // Cells drive the value graph; tests are run as a pass over the settled results.
    const cellWorkbook = {};
    this.testsBySubject = new Map();
    for (const [worksheet, cells] of Object.entries(workbook)) {
      const cellSheet = {};
      for (const [name, def] of Object.entries(cells)) {
        if (def.kind === 'cell') {
          cellSheet[name] = def;
          this.#cellDef.set(`${worksheet}.${name}`, def);
        } else {
          const list = this.testsBySubject.get(def.subject) ?? [];
          list.push(def);
          this.testsBySubject.set(def.subject, list);
        }
      }
      cellWorkbook[worksheet] = cellSheet;
    }
    this.graph = (0, _graph.buildGraph)(cellWorkbook);
    this.scheduler = new _scheduler.Scheduler(this.graph);
  }

  /** Build an engine from worksheet sources, evaluating each inside a SES Compartment. */
  static fromSources(sources, stdlib) {
    const workbook = {};
    for (const [worksheet, source] of Object.entries(sources)) {
      workbook[worksheet] = (0, _compartment.evaluateWorksheet)(source, stdlib);
    }
    return new Engine(workbook);
  }

  /** Cold recompute of every cell over the given external inputs. */
  run(externals) {
    return this.scheduler.initial(externals, (node, inputs) => node.def.formula(inputs));
  }

  /** Incremental recompute after external changes (feed/param), with cutoff. */
  update(externals) {
    return this.scheduler.apply(externals, (node, inputs) => node.def.formula(inputs));
  }

  /** The published value for a cell. */
  value(id) {
    return this.scheduler.result(id)?.value;
  }

  /**
   * Run every test against its subject, returning the suite result + review-surface verdict
   * per subject cell. A test's declared inputs resolve against the same published state a
   * cell's do (§6, R3-373) and split two ways:
   *
   * - **name-matched → substitution** — they override the subject's live inputs by local
   *   name, the subject formula **re-runs** over the merged set, and `expect`/`relation`
   *   assert against that substituted run (the holdout shape: swap the data input for its
   *   fixture, keep params/static live);
   * - **name-unmatched → auxiliary** — they are context for `expect`/`relation` only (an
   *   oracle fixture) and never feed the formula.
   *
   * Metamorphic invariance relations re-run the subject formula over a transformed input
   * via the injected `reevaluate` port (the transformed re-run rides the same merged base).
   */
  runTests() {
    const out = new Map();
    for (const [subject, tests] of this.testsBySubject) {
      const subjectDef = this.#cellDef.get(subject);
      const liveInputs = this.scheduler.inputsFor(subject);
      const liveSubject = () => this.scheduler.result(subject)?.value ?? null;
      const suite = (0, _testrunner.runSuite)(tests, test => {
        const reevaluate = subjectDef === undefined ? undefined : inputs => subjectDef.formula(inputs);
        if (subjectDef === undefined) {
          return {
            subject: liveSubject(),
            inputs: liveInputs
          };
        }
        if (Object.keys(test.inputs).length === 0) {
          return {
            subject: liveSubject(),
            inputs: liveInputs,
            reevaluate
          };
        }
        const {
          resolvers,
          diagnostics
        } = (0, _graph.resolversFor)(test.inputs, this.graph);
        if (diagnostics.length > 0) {
          return {
            subject: null,
            inputs: {},
            error: diagnostics[0]
          };
        }
        for (const r of resolvers) {
          if (r.kind === 'external' && !this.scheduler.hasExternal(r.key)) {
            return {
              subject: null,
              inputs: {},
              error: `test "${subject}" input "${r.name}" references absent external "${r.key}".`
            };
          }
          if (r.kind === 'windowed-feed' && !this.scheduler.hasExternal(`${_resolve.FEED_BUFFER_PREFIX}${r.feed}`)) {
            return {
              subject: null,
              inputs: {},
              error: `test "${subject}" windowed input "${r.name}" references feed "${r.feed}", which has no retained buffer.`
            };
          }
        }
        const declared = this.scheduler.resolve(resolvers).values;
        const substituted = {};
        const auxiliary = {};
        for (const [name, value] of Object.entries(declared)) {
          if (name in liveInputs) substituted[name] = value;else auxiliary[name] = value;
        }
        if (Object.keys(substituted).length === 0) {
          return {
            subject: liveSubject(),
            inputs: {
              ...liveInputs,
              ...auxiliary
            },
            reevaluate
          };
        }
        const merged = {
          ...liveInputs,
          ...substituted
        };
        try {
          return {
            subject: subjectDef.formula(merged),
            inputs: {
              ...merged,
              ...auxiliary
            },
            reevaluate
          };
        } catch (e) {
          // The subject errored over the substituted inputs — a data-shape mismatch between
          // the fixture and the formula, which is exactly what the test should report.
          return {
            subject: null,
            inputs: {
              ...merged,
              ...auxiliary
            },
            error: `subject errored over substituted inputs: ${e.message}`
          };
        }
      });
      out.set(subject, suite);
    }
    return out;
  }
}
exports.Engine = Engine;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZ3JhcGgiLCJyZXF1aXJlIiwiX3Jlc29sdmUiLCJfc2NoZWR1bGVyIiwiX3Rlc3RydW5uZXIiLCJfY29tcGFydG1lbnQiLCJFbmdpbmUiLCJjZWxsRGVmIiwiTWFwIiwiY29uc3RydWN0b3IiLCJ3b3JrYm9vayIsImNlbGxXb3JrYm9vayIsInRlc3RzQnlTdWJqZWN0Iiwid29ya3NoZWV0IiwiY2VsbHMiLCJPYmplY3QiLCJlbnRyaWVzIiwiY2VsbFNoZWV0IiwibmFtZSIsImRlZiIsImtpbmQiLCJzZXQiLCJsaXN0IiwiZ2V0Iiwic3ViamVjdCIsInB1c2giLCJncmFwaCIsImJ1aWxkR3JhcGgiLCJzY2hlZHVsZXIiLCJTY2hlZHVsZXIiLCJmcm9tU291cmNlcyIsInNvdXJjZXMiLCJzdGRsaWIiLCJzb3VyY2UiLCJldmFsdWF0ZVdvcmtzaGVldCIsInJ1biIsImV4dGVybmFscyIsImluaXRpYWwiLCJub2RlIiwiaW5wdXRzIiwiZm9ybXVsYSIsInVwZGF0ZSIsImFwcGx5IiwidmFsdWUiLCJpZCIsInJlc3VsdCIsInJ1blRlc3RzIiwib3V0IiwidGVzdHMiLCJzdWJqZWN0RGVmIiwibGl2ZUlucHV0cyIsImlucHV0c0ZvciIsImxpdmVTdWJqZWN0Iiwic3VpdGUiLCJydW5TdWl0ZSIsInRlc3QiLCJyZWV2YWx1YXRlIiwidW5kZWZpbmVkIiwia2V5cyIsImxlbmd0aCIsInJlc29sdmVycyIsImRpYWdub3N0aWNzIiwicmVzb2x2ZXJzRm9yIiwiZXJyb3IiLCJyIiwiaGFzRXh0ZXJuYWwiLCJrZXkiLCJGRUVEX0JVRkZFUl9QUkVGSVgiLCJmZWVkIiwiZGVjbGFyZWQiLCJyZXNvbHZlIiwidmFsdWVzIiwic3Vic3RpdHV0ZWQiLCJhdXhpbGlhcnkiLCJtZXJnZWQiLCJlIiwibWVzc2FnZSIsImV4cG9ydHMiXSwic291cmNlcyI6WyJlbmdpbmUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGVuZ2luZSBvcmNoZXN0cmF0b3IgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnNCkg4oCUIHRpZXMgdGhlIHB1cmUgc3BpbmUgaW50byBvbmUgcnVubmFibGVcbi8vIHBpcGVsaW5lOiB3b3Jrc2hlZXQgc291cmNlcyDihpIgU0VTLWNvbmZpbmVkIGV2YWx1YXRpb24g4oaSIGRlcGVuZGVuY3kgZ3JhcGgg4oaSIHJlY2FsY1xuLy8gc2NoZWR1bGVyIOKGkiBwdWJsaXNoZWQgcmVzdWx0cywgcGx1cyB0aGUgdGVzdHMtYXMtY2VsbHMgcnVuIGFuZCB0aGUgcmV2aWV3LXN1cmZhY2Vcbi8vIHZlcmRpY3QuIFRoZSBjb25maW5lZC1mb3JtdWxhIGV4ZWN1dGlvbiBpcyB0aGUgb25lIGVmZmVjdGZ1bCBzdGVwOyBldmVyeXRoaW5nIGVsc2UgaXMgdGhlXG4vLyBwdXJlIG1hY2hpbmVyeSBmcm9tIC4vc2NoZWR1bGVyLCAuL2dyYXBoLCAuL3Rlc3RydW5uZXIgYW5kIC4uL3N0ZGxpYi5cblxuaW1wb3J0IHR5cGUgeyBWYWx1ZSB9IGZyb20gJy4uL3N0ZGxpYi90eXBlcy50cyc7XG5pbXBvcnQgdHlwZSB7IENlbGxEZWYsIFRlc3RDZWxsRGVmIH0gZnJvbSAnLi4vc3RkbGliL2NlbGwudHMnO1xuaW1wb3J0IHR5cGUgeyBEZXBlbmRlbmN5R3JhcGgsIEV4dGVybmFsVmFsdWUsIFBhc3NSZXN1bHQsIFdvcmtib29rIH0gZnJvbSAnLi90eXBlcy50cyc7XG5pbXBvcnQgeyBidWlsZEdyYXBoIH0gZnJvbSAnLi9ncmFwaC50cyc7XG5pbXBvcnQgeyByZXNvbHZlcnNGb3IgfSBmcm9tICcuL2dyYXBoLnRzJztcbmltcG9ydCB7IEZFRURfQlVGRkVSX1BSRUZJWCB9IGZyb20gJy4vcmVzb2x2ZS50cyc7XG5pbXBvcnQgeyBTY2hlZHVsZXIgfSBmcm9tICcuL3NjaGVkdWxlci50cyc7XG5pbXBvcnQgeyBydW5TdWl0ZSB9IGZyb20gJy4vdGVzdHJ1bm5lci50cyc7XG5pbXBvcnQgdHlwZSB7IFN1aXRlUmVzdWx0IH0gZnJvbSAnLi90ZXN0cnVubmVyLnRzJztcbmltcG9ydCB7IGV2YWx1YXRlV29ya3NoZWV0IH0gZnJvbSAnLi9jb21wYXJ0bWVudC50cyc7XG5cbmV4cG9ydCBjbGFzcyBFbmdpbmUge1xuICByZWFkb25seSBncmFwaDogRGVwZW5kZW5jeUdyYXBoO1xuICByZWFkb25seSBzY2hlZHVsZXI6IFNjaGVkdWxlcjtcbiAgLyoqIFRlc3QgY2VsbHMsIGtleWVkIGJ5IHRoZSBzdWJqZWN0IGNlbGwgaWQgdGhleSB2YWxpZGF0ZS4gKi9cbiAgcmVhZG9ubHkgdGVzdHNCeVN1YmplY3Q6IE1hcDxzdHJpbmcsIFRlc3RDZWxsRGVmW10+O1xuXG4gICNjZWxsRGVmID0gbmV3IE1hcDxzdHJpbmcsIENlbGxEZWY+KCk7XG5cbiAgY29uc3RydWN0b3Iod29ya2Jvb2s6IFdvcmtib29rKSB7XG4gICAgLy8gQ2VsbHMgZHJpdmUgdGhlIHZhbHVlIGdyYXBoOyB0ZXN0cyBhcmUgcnVuIGFzIGEgcGFzcyBvdmVyIHRoZSBzZXR0bGVkIHJlc3VsdHMuXG4gICAgY29uc3QgY2VsbFdvcmtib29rOiBXb3JrYm9vayA9IHt9O1xuICAgIHRoaXMudGVzdHNCeVN1YmplY3QgPSBuZXcgTWFwKCk7XG4gICAgZm9yIChjb25zdCBbd29ya3NoZWV0LCBjZWxsc10gb2YgT2JqZWN0LmVudHJpZXMod29ya2Jvb2spKSB7XG4gICAgICBjb25zdCBjZWxsU2hlZXQ6IFJlY29yZDxzdHJpbmcsIENlbGxEZWY+ID0ge307XG4gICAgICBmb3IgKGNvbnN0IFtuYW1lLCBkZWZdIG9mIE9iamVjdC5lbnRyaWVzKGNlbGxzKSkge1xuICAgICAgICBpZiAoZGVmLmtpbmQgPT09ICdjZWxsJykge1xuICAgICAgICAgIGNlbGxTaGVldFtuYW1lXSA9IGRlZjtcbiAgICAgICAgICB0aGlzLiNjZWxsRGVmLnNldChgJHt3b3Jrc2hlZXR9LiR7bmFtZX1gLCBkZWYpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGxpc3QgPSB0aGlzLnRlc3RzQnlTdWJqZWN0LmdldChkZWYuc3ViamVjdCkgPz8gW107XG4gICAgICAgICAgbGlzdC5wdXNoKGRlZik7XG4gICAgICAgICAgdGhpcy50ZXN0c0J5U3ViamVjdC5zZXQoZGVmLnN1YmplY3QsIGxpc3QpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjZWxsV29ya2Jvb2tbd29ya3NoZWV0XSA9IGNlbGxTaGVldDtcbiAgICB9XG4gICAgdGhpcy5ncmFwaCA9IGJ1aWxkR3JhcGgoY2VsbFdvcmtib29rKTtcbiAgICB0aGlzLnNjaGVkdWxlciA9IG5ldyBTY2hlZHVsZXIodGhpcy5ncmFwaCk7XG4gIH1cblxuICAvKiogQnVpbGQgYW4gZW5naW5lIGZyb20gd29ya3NoZWV0IHNvdXJjZXMsIGV2YWx1YXRpbmcgZWFjaCBpbnNpZGUgYSBTRVMgQ29tcGFydG1lbnQuICovXG4gIHN0YXRpYyBmcm9tU291cmNlcyhcbiAgICBzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LFxuICAgIHN0ZGxpYjogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gICk6IEVuZ2luZSB7XG4gICAgY29uc3Qgd29ya2Jvb2s6IFdvcmtib29rID0ge307XG4gICAgZm9yIChjb25zdCBbd29ya3NoZWV0LCBzb3VyY2VdIG9mIE9iamVjdC5lbnRyaWVzKHNvdXJjZXMpKSB7XG4gICAgICB3b3JrYm9va1t3b3Jrc2hlZXRdID0gZXZhbHVhdGVXb3Jrc2hlZXQoc291cmNlLCBzdGRsaWIpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEVuZ2luZSh3b3JrYm9vayk7XG4gIH1cblxuICAvKiogQ29sZCByZWNvbXB1dGUgb2YgZXZlcnkgY2VsbCBvdmVyIHRoZSBnaXZlbiBleHRlcm5hbCBpbnB1dHMuICovXG4gIHJ1bihleHRlcm5hbHM6IFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+KTogUGFzc1Jlc3VsdCB7XG4gICAgcmV0dXJuIHRoaXMuc2NoZWR1bGVyLmluaXRpYWwoZXh0ZXJuYWxzLCAobm9kZSwgaW5wdXRzKSA9PlxuICAgICAgKG5vZGUuZGVmIGFzIENlbGxEZWYpLmZvcm11bGEoaW5wdXRzKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEluY3JlbWVudGFsIHJlY29tcHV0ZSBhZnRlciBleHRlcm5hbCBjaGFuZ2VzIChmZWVkL3BhcmFtKSwgd2l0aCBjdXRvZmYuICovXG4gIHVwZGF0ZShleHRlcm5hbHM6IFJlY29yZDxzdHJpbmcsIEV4dGVybmFsVmFsdWU+KTogUGFzc1Jlc3VsdCB7XG4gICAgcmV0dXJuIHRoaXMuc2NoZWR1bGVyLmFwcGx5KGV4dGVybmFscywgKG5vZGUsIGlucHV0cykgPT5cbiAgICAgIChub2RlLmRlZiBhcyBDZWxsRGVmKS5mb3JtdWxhKGlucHV0cyksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBUaGUgcHVibGlzaGVkIHZhbHVlIGZvciBhIGNlbGwuICovXG4gIHZhbHVlKGlkOiBzdHJpbmcpOiBWYWx1ZSB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMuc2NoZWR1bGVyLnJlc3VsdChpZCk/LnZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqIFJ1biBldmVyeSB0ZXN0IGFnYWluc3QgaXRzIHN1YmplY3QsIHJldHVybmluZyB0aGUgc3VpdGUgcmVzdWx0ICsgcmV2aWV3LXN1cmZhY2UgdmVyZGljdFxuICAgKiBwZXIgc3ViamVjdCBjZWxsLiBBIHRlc3QncyBkZWNsYXJlZCBpbnB1dHMgcmVzb2x2ZSBhZ2FpbnN0IHRoZSBzYW1lIHB1Ymxpc2hlZCBzdGF0ZSBhXG4gICAqIGNlbGwncyBkbyAowqc2LCBSMy0zNzMpIGFuZCBzcGxpdCB0d28gd2F5czpcbiAgICpcbiAgICogLSAqKm5hbWUtbWF0Y2hlZCDihpIgc3Vic3RpdHV0aW9uKiog4oCUIHRoZXkgb3ZlcnJpZGUgdGhlIHN1YmplY3QncyBsaXZlIGlucHV0cyBieSBsb2NhbFxuICAgKiAgIG5hbWUsIHRoZSBzdWJqZWN0IGZvcm11bGEgKipyZS1ydW5zKiogb3ZlciB0aGUgbWVyZ2VkIHNldCwgYW5kIGBleHBlY3RgL2ByZWxhdGlvbmBcbiAgICogICBhc3NlcnQgYWdhaW5zdCB0aGF0IHN1YnN0aXR1dGVkIHJ1biAodGhlIGhvbGRvdXQgc2hhcGU6IHN3YXAgdGhlIGRhdGEgaW5wdXQgZm9yIGl0c1xuICAgKiAgIGZpeHR1cmUsIGtlZXAgcGFyYW1zL3N0YXRpYyBsaXZlKTtcbiAgICogLSAqKm5hbWUtdW5tYXRjaGVkIOKGkiBhdXhpbGlhcnkqKiDigJQgdGhleSBhcmUgY29udGV4dCBmb3IgYGV4cGVjdGAvYHJlbGF0aW9uYCBvbmx5IChhblxuICAgKiAgIG9yYWNsZSBmaXh0dXJlKSBhbmQgbmV2ZXIgZmVlZCB0aGUgZm9ybXVsYS5cbiAgICpcbiAgICogTWV0YW1vcnBoaWMgaW52YXJpYW5jZSByZWxhdGlvbnMgcmUtcnVuIHRoZSBzdWJqZWN0IGZvcm11bGEgb3ZlciBhIHRyYW5zZm9ybWVkIGlucHV0XG4gICAqIHZpYSB0aGUgaW5qZWN0ZWQgYHJlZXZhbHVhdGVgIHBvcnQgKHRoZSB0cmFuc2Zvcm1lZCByZS1ydW4gcmlkZXMgdGhlIHNhbWUgbWVyZ2VkIGJhc2UpLlxuICAgKi9cbiAgcnVuVGVzdHMoKTogTWFwPHN0cmluZywgU3VpdGVSZXN1bHQ+IHtcbiAgICBjb25zdCBvdXQgPSBuZXcgTWFwPHN0cmluZywgU3VpdGVSZXN1bHQ+KCk7XG4gICAgZm9yIChjb25zdCBbc3ViamVjdCwgdGVzdHNdIG9mIHRoaXMudGVzdHNCeVN1YmplY3QpIHtcbiAgICAgIGNvbnN0IHN1YmplY3REZWYgPSB0aGlzLiNjZWxsRGVmLmdldChzdWJqZWN0KTtcbiAgICAgIGNvbnN0IGxpdmVJbnB1dHMgPSB0aGlzLnNjaGVkdWxlci5pbnB1dHNGb3Ioc3ViamVjdCk7XG4gICAgICBjb25zdCBsaXZlU3ViamVjdCA9ICgpOiBWYWx1ZSA9PiB0aGlzLnNjaGVkdWxlci5yZXN1bHQoc3ViamVjdCk/LnZhbHVlID8/IG51bGw7XG4gICAgICBjb25zdCBzdWl0ZSA9IHJ1blN1aXRlKHRlc3RzLCAodGVzdCkgPT4ge1xuICAgICAgICBjb25zdCByZWV2YWx1YXRlID1cbiAgICAgICAgICBzdWJqZWN0RGVmID09PSB1bmRlZmluZWRcbiAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICA6IChpbnB1dHM6IFJlY29yZDxzdHJpbmcsIFZhbHVlPikgPT4gc3ViamVjdERlZi5mb3JtdWxhKGlucHV0cyk7XG4gICAgICAgIGlmIChzdWJqZWN0RGVmID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICByZXR1cm4geyBzdWJqZWN0OiBsaXZlU3ViamVjdCgpLCBpbnB1dHM6IGxpdmVJbnB1dHMgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoT2JqZWN0LmtleXModGVzdC5pbnB1dHMpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgIHJldHVybiB7IHN1YmplY3Q6IGxpdmVTdWJqZWN0KCksIGlucHV0czogbGl2ZUlucHV0cywgcmVldmFsdWF0ZSB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgeyByZXNvbHZlcnMsIGRpYWdub3N0aWNzIH0gPSByZXNvbHZlcnNGb3IodGVzdC5pbnB1dHMsIHRoaXMuZ3JhcGgpO1xuICAgICAgICBpZiAoZGlhZ25vc3RpY3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiB7IHN1YmplY3Q6IG51bGwsIGlucHV0czoge30sIGVycm9yOiBkaWFnbm9zdGljc1swXSB9O1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgciBvZiByZXNvbHZlcnMpIHtcbiAgICAgICAgICBpZiAoci5raW5kID09PSAnZXh0ZXJuYWwnICYmICF0aGlzLnNjaGVkdWxlci5oYXNFeHRlcm5hbChyLmtleSkpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHN1YmplY3Q6IG51bGwsIGlucHV0czoge30sIGVycm9yOiBgdGVzdCBcIiR7c3ViamVjdH1cIiBpbnB1dCBcIiR7ci5uYW1lfVwiIHJlZmVyZW5jZXMgYWJzZW50IGV4dGVybmFsIFwiJHtyLmtleX1cIi5gIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChyLmtpbmQgPT09ICd3aW5kb3dlZC1mZWVkJyAmJiAhdGhpcy5zY2hlZHVsZXIuaGFzRXh0ZXJuYWwoYCR7RkVFRF9CVUZGRVJfUFJFRklYfSR7ci5mZWVkfWApKSB7XG4gICAgICAgICAgICByZXR1cm4geyBzdWJqZWN0OiBudWxsLCBpbnB1dHM6IHt9LCBlcnJvcjogYHRlc3QgXCIke3N1YmplY3R9XCIgd2luZG93ZWQgaW5wdXQgXCIke3IubmFtZX1cIiByZWZlcmVuY2VzIGZlZWQgXCIke3IuZmVlZH1cIiwgd2hpY2ggaGFzIG5vIHJldGFpbmVkIGJ1ZmZlci5gIH07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRlY2xhcmVkID0gdGhpcy5zY2hlZHVsZXIucmVzb2x2ZShyZXNvbHZlcnMpLnZhbHVlcztcbiAgICAgICAgY29uc3Qgc3Vic3RpdHV0ZWQ6IFJlY29yZDxzdHJpbmcsIFZhbHVlPiA9IHt9O1xuICAgICAgICBjb25zdCBhdXhpbGlhcnk6IFJlY29yZDxzdHJpbmcsIFZhbHVlPiA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZGVjbGFyZWQpKSB7XG4gICAgICAgICAgaWYgKG5hbWUgaW4gbGl2ZUlucHV0cykgc3Vic3RpdHV0ZWRbbmFtZV0gPSB2YWx1ZTtcbiAgICAgICAgICBlbHNlIGF1eGlsaWFyeVtuYW1lXSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhzdWJzdGl0dXRlZCkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3ViamVjdDogbGl2ZVN1YmplY3QoKSwgaW5wdXRzOiB7IC4uLmxpdmVJbnB1dHMsIC4uLmF1eGlsaWFyeSB9LCByZWV2YWx1YXRlIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWVyZ2VkID0geyAuLi5saXZlSW5wdXRzLCAuLi5zdWJzdGl0dXRlZCB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiB7IHN1YmplY3Q6IHN1YmplY3REZWYuZm9ybXVsYShtZXJnZWQpLCBpbnB1dHM6IHsgLi4ubWVyZ2VkLCAuLi5hdXhpbGlhcnkgfSwgcmVldmFsdWF0ZSB9O1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gVGhlIHN1YmplY3QgZXJyb3JlZCBvdmVyIHRoZSBzdWJzdGl0dXRlZCBpbnB1dHMg4oCUIGEgZGF0YS1zaGFwZSBtaXNtYXRjaCBiZXR3ZWVuXG4gICAgICAgICAgLy8gdGhlIGZpeHR1cmUgYW5kIHRoZSBmb3JtdWxhLCB3aGljaCBpcyBleGFjdGx5IHdoYXQgdGhlIHRlc3Qgc2hvdWxkIHJlcG9ydC5cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3ViamVjdDogbnVsbCxcbiAgICAgICAgICAgIGlucHV0czogeyAuLi5tZXJnZWQsIC4uLmF1eGlsaWFyeSB9LFxuICAgICAgICAgICAgZXJyb3I6IGBzdWJqZWN0IGVycm9yZWQgb3ZlciBzdWJzdGl0dXRlZCBpbnB1dHM6ICR7KGUgYXMgRXJyb3IpLm1lc3NhZ2V9YCxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIG91dC5zZXQoc3ViamVjdCwgc3VpdGUpO1xuICAgIH1cbiAgICByZXR1cm4gb3V0O1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLFFBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUVBLElBQUFJLFlBQUEsR0FBQUosT0FBQTtBQWZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBYU8sTUFBTUssTUFBTSxDQUFDO0VBR2xCOztFQUdBLENBQUNDLE9BQU8sR0FBRyxJQUFJQyxHQUFHLENBQWtCLENBQUM7RUFFckNDLFdBQVdBLENBQUNDLFFBQWtCLEVBQUU7SUFDOUI7SUFDQSxNQUFNQyxZQUFzQixHQUFHLENBQUMsQ0FBQztJQUNqQyxJQUFJLENBQUNDLGNBQWMsR0FBRyxJQUFJSixHQUFHLENBQUMsQ0FBQztJQUMvQixLQUFLLE1BQU0sQ0FBQ0ssU0FBUyxFQUFFQyxLQUFLLENBQUMsSUFBSUMsTUFBTSxDQUFDQyxPQUFPLENBQUNOLFFBQVEsQ0FBQyxFQUFFO01BQ3pELE1BQU1PLFNBQWtDLEdBQUcsQ0FBQyxDQUFDO01BQzdDLEtBQUssTUFBTSxDQUFDQyxJQUFJLEVBQUVDLEdBQUcsQ0FBQyxJQUFJSixNQUFNLENBQUNDLE9BQU8sQ0FBQ0YsS0FBSyxDQUFDLEVBQUU7UUFDL0MsSUFBSUssR0FBRyxDQUFDQyxJQUFJLEtBQUssTUFBTSxFQUFFO1VBQ3ZCSCxTQUFTLENBQUNDLElBQUksQ0FBQyxHQUFHQyxHQUFHO1VBQ3JCLElBQUksQ0FBQyxDQUFDWixPQUFPLENBQUNjLEdBQUcsQ0FBQyxHQUFHUixTQUFTLElBQUlLLElBQUksRUFBRSxFQUFFQyxHQUFHLENBQUM7UUFDaEQsQ0FBQyxNQUFNO1VBQ0wsTUFBTUcsSUFBSSxHQUFHLElBQUksQ0FBQ1YsY0FBYyxDQUFDVyxHQUFHLENBQUNKLEdBQUcsQ0FBQ0ssT0FBTyxDQUFDLElBQUksRUFBRTtVQUN2REYsSUFBSSxDQUFDRyxJQUFJLENBQUNOLEdBQUcsQ0FBQztVQUNkLElBQUksQ0FBQ1AsY0FBYyxDQUFDUyxHQUFHLENBQUNGLEdBQUcsQ0FBQ0ssT0FBTyxFQUFFRixJQUFJLENBQUM7UUFDNUM7TUFDRjtNQUNBWCxZQUFZLENBQUNFLFNBQVMsQ0FBQyxHQUFHSSxTQUFTO0lBQ3JDO0lBQ0EsSUFBSSxDQUFDUyxLQUFLLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ2hCLFlBQVksQ0FBQztJQUNyQyxJQUFJLENBQUNpQixTQUFTLEdBQUcsSUFBSUMsb0JBQVMsQ0FBQyxJQUFJLENBQUNILEtBQUssQ0FBQztFQUM1Qzs7RUFFQTtFQUNBLE9BQU9JLFdBQVdBLENBQ2hCQyxPQUErQixFQUMvQkMsTUFBK0IsRUFDdkI7SUFDUixNQUFNdEIsUUFBa0IsR0FBRyxDQUFDLENBQUM7SUFDN0IsS0FBSyxNQUFNLENBQUNHLFNBQVMsRUFBRW9CLE1BQU0sQ0FBQyxJQUFJbEIsTUFBTSxDQUFDQyxPQUFPLENBQUNlLE9BQU8sQ0FBQyxFQUFFO01BQ3pEckIsUUFBUSxDQUFDRyxTQUFTLENBQUMsR0FBRyxJQUFBcUIsOEJBQWlCLEVBQUNELE1BQU0sRUFBRUQsTUFBTSxDQUFDO0lBQ3pEO0lBQ0EsT0FBTyxJQUFJMUIsTUFBTSxDQUFDSSxRQUFRLENBQUM7RUFDN0I7O0VBRUE7RUFDQXlCLEdBQUdBLENBQUNDLFNBQXdDLEVBQWM7SUFDeEQsT0FBTyxJQUFJLENBQUNSLFNBQVMsQ0FBQ1MsT0FBTyxDQUFDRCxTQUFTLEVBQUUsQ0FBQ0UsSUFBSSxFQUFFQyxNQUFNLEtBQ25ERCxJQUFJLENBQUNuQixHQUFHLENBQWFxQixPQUFPLENBQUNELE1BQU0sQ0FDdEMsQ0FBQztFQUNIOztFQUVBO0VBQ0FFLE1BQU1BLENBQUNMLFNBQXdDLEVBQWM7SUFDM0QsT0FBTyxJQUFJLENBQUNSLFNBQVMsQ0FBQ2MsS0FBSyxDQUFDTixTQUFTLEVBQUUsQ0FBQ0UsSUFBSSxFQUFFQyxNQUFNLEtBQ2pERCxJQUFJLENBQUNuQixHQUFHLENBQWFxQixPQUFPLENBQUNELE1BQU0sQ0FDdEMsQ0FBQztFQUNIOztFQUVBO0VBQ0FJLEtBQUtBLENBQUNDLEVBQVUsRUFBcUI7SUFDbkMsT0FBTyxJQUFJLENBQUNoQixTQUFTLENBQUNpQixNQUFNLENBQUNELEVBQUUsQ0FBQyxFQUFFRCxLQUFLO0VBQ3pDOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFRyxRQUFRQSxDQUFBLEVBQTZCO0lBQ25DLE1BQU1DLEdBQUcsR0FBRyxJQUFJdkMsR0FBRyxDQUFzQixDQUFDO0lBQzFDLEtBQUssTUFBTSxDQUFDZ0IsT0FBTyxFQUFFd0IsS0FBSyxDQUFDLElBQUksSUFBSSxDQUFDcEMsY0FBYyxFQUFFO01BQ2xELE1BQU1xQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUMxQyxPQUFPLENBQUNnQixHQUFHLENBQUNDLE9BQU8sQ0FBQztNQUM3QyxNQUFNMEIsVUFBVSxHQUFHLElBQUksQ0FBQ3RCLFNBQVMsQ0FBQ3VCLFNBQVMsQ0FBQzNCLE9BQU8sQ0FBQztNQUNwRCxNQUFNNEIsV0FBVyxHQUFHQSxDQUFBLEtBQWEsSUFBSSxDQUFDeEIsU0FBUyxDQUFDaUIsTUFBTSxDQUFDckIsT0FBTyxDQUFDLEVBQUVtQixLQUFLLElBQUksSUFBSTtNQUM5RSxNQUFNVSxLQUFLLEdBQUcsSUFBQUMsb0JBQVEsRUFBQ04sS0FBSyxFQUFHTyxJQUFJLElBQUs7UUFDdEMsTUFBTUMsVUFBVSxHQUNkUCxVQUFVLEtBQUtRLFNBQVMsR0FDcEJBLFNBQVMsR0FDUmxCLE1BQTZCLElBQUtVLFVBQVUsQ0FBQ1QsT0FBTyxDQUFDRCxNQUFNLENBQUM7UUFDbkUsSUFBSVUsVUFBVSxLQUFLUSxTQUFTLEVBQUU7VUFDNUIsT0FBTztZQUFFakMsT0FBTyxFQUFFNEIsV0FBVyxDQUFDLENBQUM7WUFBRWIsTUFBTSxFQUFFVztVQUFXLENBQUM7UUFDdkQ7UUFDQSxJQUFJbkMsTUFBTSxDQUFDMkMsSUFBSSxDQUFDSCxJQUFJLENBQUNoQixNQUFNLENBQUMsQ0FBQ29CLE1BQU0sS0FBSyxDQUFDLEVBQUU7VUFDekMsT0FBTztZQUFFbkMsT0FBTyxFQUFFNEIsV0FBVyxDQUFDLENBQUM7WUFBRWIsTUFBTSxFQUFFVyxVQUFVO1lBQUVNO1VBQVcsQ0FBQztRQUNuRTtRQUVBLE1BQU07VUFBRUksU0FBUztVQUFFQztRQUFZLENBQUMsR0FBRyxJQUFBQyxtQkFBWSxFQUFDUCxJQUFJLENBQUNoQixNQUFNLEVBQUUsSUFBSSxDQUFDYixLQUFLLENBQUM7UUFDeEUsSUFBSW1DLFdBQVcsQ0FBQ0YsTUFBTSxHQUFHLENBQUMsRUFBRTtVQUMxQixPQUFPO1lBQUVuQyxPQUFPLEVBQUUsSUFBSTtZQUFFZSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUV3QixLQUFLLEVBQUVGLFdBQVcsQ0FBQyxDQUFDO1VBQUUsQ0FBQztRQUM3RDtRQUNBLEtBQUssTUFBTUcsQ0FBQyxJQUFJSixTQUFTLEVBQUU7VUFDekIsSUFBSUksQ0FBQyxDQUFDNUMsSUFBSSxLQUFLLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQ1EsU0FBUyxDQUFDcUMsV0FBVyxDQUFDRCxDQUFDLENBQUNFLEdBQUcsQ0FBQyxFQUFFO1lBQy9ELE9BQU87Y0FBRTFDLE9BQU8sRUFBRSxJQUFJO2NBQUVlLE1BQU0sRUFBRSxDQUFDLENBQUM7Y0FBRXdCLEtBQUssRUFBRSxTQUFTdkMsT0FBTyxZQUFZd0MsQ0FBQyxDQUFDOUMsSUFBSSxpQ0FBaUM4QyxDQUFDLENBQUNFLEdBQUc7WUFBSyxDQUFDO1VBQzNIO1VBQ0EsSUFBSUYsQ0FBQyxDQUFDNUMsSUFBSSxLQUFLLGVBQWUsSUFBSSxDQUFDLElBQUksQ0FBQ1EsU0FBUyxDQUFDcUMsV0FBVyxDQUFDLEdBQUdFLDJCQUFrQixHQUFHSCxDQUFDLENBQUNJLElBQUksRUFBRSxDQUFDLEVBQUU7WUFDL0YsT0FBTztjQUFFNUMsT0FBTyxFQUFFLElBQUk7Y0FBRWUsTUFBTSxFQUFFLENBQUMsQ0FBQztjQUFFd0IsS0FBSyxFQUFFLFNBQVN2QyxPQUFPLHFCQUFxQndDLENBQUMsQ0FBQzlDLElBQUksc0JBQXNCOEMsQ0FBQyxDQUFDSSxJQUFJO1lBQW1DLENBQUM7VUFDeEo7UUFDRjtRQUNBLE1BQU1DLFFBQVEsR0FBRyxJQUFJLENBQUN6QyxTQUFTLENBQUMwQyxPQUFPLENBQUNWLFNBQVMsQ0FBQyxDQUFDVyxNQUFNO1FBQ3pELE1BQU1DLFdBQWtDLEdBQUcsQ0FBQyxDQUFDO1FBQzdDLE1BQU1DLFNBQWdDLEdBQUcsQ0FBQyxDQUFDO1FBQzNDLEtBQUssTUFBTSxDQUFDdkQsSUFBSSxFQUFFeUIsS0FBSyxDQUFDLElBQUk1QixNQUFNLENBQUNDLE9BQU8sQ0FBQ3FELFFBQVEsQ0FBQyxFQUFFO1VBQ3BELElBQUluRCxJQUFJLElBQUlnQyxVQUFVLEVBQUVzQixXQUFXLENBQUN0RCxJQUFJLENBQUMsR0FBR3lCLEtBQUssQ0FBQyxLQUM3QzhCLFNBQVMsQ0FBQ3ZELElBQUksQ0FBQyxHQUFHeUIsS0FBSztRQUM5QjtRQUNBLElBQUk1QixNQUFNLENBQUMyQyxJQUFJLENBQUNjLFdBQVcsQ0FBQyxDQUFDYixNQUFNLEtBQUssQ0FBQyxFQUFFO1VBQ3pDLE9BQU87WUFBRW5DLE9BQU8sRUFBRTRCLFdBQVcsQ0FBQyxDQUFDO1lBQUViLE1BQU0sRUFBRTtjQUFFLEdBQUdXLFVBQVU7Y0FBRSxHQUFHdUI7WUFBVSxDQUFDO1lBQUVqQjtVQUFXLENBQUM7UUFDeEY7UUFDQSxNQUFNa0IsTUFBTSxHQUFHO1VBQUUsR0FBR3hCLFVBQVU7VUFBRSxHQUFHc0I7UUFBWSxDQUFDO1FBQ2hELElBQUk7VUFDRixPQUFPO1lBQUVoRCxPQUFPLEVBQUV5QixVQUFVLENBQUNULE9BQU8sQ0FBQ2tDLE1BQU0sQ0FBQztZQUFFbkMsTUFBTSxFQUFFO2NBQUUsR0FBR21DLE1BQU07Y0FBRSxHQUFHRDtZQUFVLENBQUM7WUFBRWpCO1VBQVcsQ0FBQztRQUNqRyxDQUFDLENBQUMsT0FBT21CLENBQUMsRUFBRTtVQUNWO1VBQ0E7VUFDQSxPQUFPO1lBQ0xuRCxPQUFPLEVBQUUsSUFBSTtZQUNiZSxNQUFNLEVBQUU7Y0FBRSxHQUFHbUMsTUFBTTtjQUFFLEdBQUdEO1lBQVUsQ0FBQztZQUNuQ1YsS0FBSyxFQUFFLDRDQUE2Q1ksQ0FBQyxDQUFXQyxPQUFPO1VBQ3pFLENBQUM7UUFDSDtNQUNGLENBQUMsQ0FBQztNQUNGN0IsR0FBRyxDQUFDMUIsR0FBRyxDQUFDRyxPQUFPLEVBQUU2QixLQUFLLENBQUM7SUFDekI7SUFDQSxPQUFPTixHQUFHO0VBQ1o7QUFDRjtBQUFDOEIsT0FBQSxDQUFBdkUsTUFBQSxHQUFBQSxNQUFBIiwiaWdub3JlTGlzdCI6W119