var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Row;
var _renderContext = require("../renderContext.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Row — a horizontal layout grouping (§3.3 layout primitives) that reflows to a fluid grid so
// tiles add/drop columns continuously with space (§3.3.1 intrinsic layout). Container; the
// responsiveness is entirely in CSS — the template carries no breakpoints.
function Row({
  node
}) {
  _s();
  const renderNodes = (0, _renderContext.useRenderNodes)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-row",
    children: renderNodes(node.children)
  });
}
_s(Row, "ITAsjexFDox20GXuav5598+1Xb8=", false, function () {
  return [_renderContext.useRenderNodes];
});
_c = Row;
var _c;
$RefreshReg$(_c, "Row");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVuZGVyQ29udGV4dCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiUm93Iiwibm9kZSIsInJlbmRlck5vZGVzIiwidXNlUmVuZGVyTm9kZXMiLCJqc3giLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUm93LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb3cg4oCUIGEgaG9yaXpvbnRhbCBsYXlvdXQgZ3JvdXBpbmcgKMKnMy4zIGxheW91dCBwcmltaXRpdmVzKSB0aGF0IHJlZmxvd3MgdG8gYSBmbHVpZCBncmlkIHNvXG4vLyB0aWxlcyBhZGQvZHJvcCBjb2x1bW5zIGNvbnRpbnVvdXNseSB3aXRoIHNwYWNlICjCpzMuMy4xIGludHJpbnNpYyBsYXlvdXQpLiBDb250YWluZXI7IHRoZVxuLy8gcmVzcG9uc2l2ZW5lc3MgaXMgZW50aXJlbHkgaW4gQ1NTIOKAlCB0aGUgdGVtcGxhdGUgY2FycmllcyBubyBicmVha3BvaW50cy5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IHVzZVJlbmRlck5vZGVzIH0gZnJvbSAnLi4vcmVuZGVyQ29udGV4dC50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJvdyh7IG5vZGUgfTogeyBub2RlOiBDb21wb25lbnROb2RlIH0pIHtcbiAgY29uc3QgcmVuZGVyTm9kZXMgPSB1c2VSZW5kZXJOb2RlcygpO1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJyay1yb3dcIj57cmVuZGVyTm9kZXMobm9kZS5jaGlsZHJlbil9PC9kaXY+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFJQSxJQUFBQSxjQUFBLEdBQUFDLE9BQUE7QUFBcUQsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsSUFBQUUsRUFBQSxHQUFBQyxZQUFBLElBSnJEO0FBQ0E7QUFDQTtBQUllLFNBQVNDLEdBQUdBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFILEVBQUE7RUFDN0QsTUFBTUksV0FBVyxHQUFHLElBQUFDLDZCQUFjLEVBQUMsQ0FBQztFQUNwQyxvQkFBTyxJQUFBTixXQUFBLENBQUFPLEdBQUE7SUFBS0MsU0FBUyxFQUFDLFFBQVE7SUFBQUMsUUFBQSxFQUFFSixXQUFXLENBQUNELElBQUksQ0FBQ0ssUUFBUTtFQUFDLENBQU0sQ0FBQztBQUNuRTtBQUFDUixFQUFBLENBSHVCRSxHQUFHO0VBQUEsUUFDTEcsNkJBQWM7QUFBQTtBQUFBSSxFQUFBLEdBRFpQLEdBQUc7QUFBQSxJQUFBTyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}