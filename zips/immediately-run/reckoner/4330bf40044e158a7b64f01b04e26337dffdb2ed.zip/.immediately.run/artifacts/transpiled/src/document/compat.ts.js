"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.resolveCompat = resolveCompat;
var _semver = require("./semver.ts");
// The compatibility resolution rule (DOCUMENT_VERSIONING_SPEC §2/§3). On open, the app
// compares its own versions to the document's `compat`. The additive-only stdlib/catalog
// contract does the heavy lifting — forward compatibility within a major is free — so this
// rule's job is to make the cross-major and old-app-new-document cases *legible*, never to
// produce a plausible-but-wrong render:
//
//   - unknown `format` major        → refuse (never a partial parse)
//   - app newer, same major         → run   (additive-only: the callables still exist)
//   - app older than the doc needs  → degrade (specific cells/components become "needs ≥ x"
//                                     placeholders; the rest runs)

/** Resolve whether `app` can open a document with the given `manifest`. */
function resolveCompat(app, manifest) {
  if (!app.formats.includes(manifest.format)) {
    return {
      status: 'refuse',
      reason: `this report needs Reckoner document format ${manifest.format}; this app understands ${app.formats.join(', ')}.`
    };
  }
  const reasons = [];
  const {
    stdlib,
    catalog
  } = manifest.compat;
  if (stdlib !== undefined && !(0, _semver.satisfies)(app.stdlib, stdlib)) {
    reasons.push(`needs stdlib ${stdlib} (app has ${app.stdlib})`);
  }
  if (catalog !== undefined && !(0, _semver.satisfies)(app.catalog, catalog)) {
    reasons.push(`needs component catalog ${catalog} (app has ${app.catalog})`);
  }

  // A newer in-file tierTag encoding is not a refusal or a whole-document degrade: an
  // unknown tag is treated as the host-authoritative mount tier and the in-file tag is
  // ignored (§3/OQ-2), so it never up-labels. It is surfaced as an informational reason
  // only when the rest already degrades, and never gates on its own.
  if (reasons.length === 0) return {
    status: 'run'
  };
  return {
    status: 'degrade',
    reasons
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2VtdmVyIiwicmVxdWlyZSIsInJlc29sdmVDb21wYXQiLCJhcHAiLCJtYW5pZmVzdCIsImZvcm1hdHMiLCJpbmNsdWRlcyIsImZvcm1hdCIsInN0YXR1cyIsInJlYXNvbiIsImpvaW4iLCJyZWFzb25zIiwic3RkbGliIiwiY2F0YWxvZyIsImNvbXBhdCIsInVuZGVmaW5lZCIsInNhdGlzZmllcyIsInB1c2giLCJsZW5ndGgiXSwic291cmNlcyI6WyJjb21wYXQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGNvbXBhdGliaWxpdHkgcmVzb2x1dGlvbiBydWxlIChET0NVTUVOVF9WRVJTSU9OSU5HX1NQRUMgwqcyL8KnMykuIE9uIG9wZW4sIHRoZSBhcHBcbi8vIGNvbXBhcmVzIGl0cyBvd24gdmVyc2lvbnMgdG8gdGhlIGRvY3VtZW50J3MgYGNvbXBhdGAuIFRoZSBhZGRpdGl2ZS1vbmx5IHN0ZGxpYi9jYXRhbG9nXG4vLyBjb250cmFjdCBkb2VzIHRoZSBoZWF2eSBsaWZ0aW5nIOKAlCBmb3J3YXJkIGNvbXBhdGliaWxpdHkgd2l0aGluIGEgbWFqb3IgaXMgZnJlZSDigJQgc28gdGhpc1xuLy8gcnVsZSdzIGpvYiBpcyB0byBtYWtlIHRoZSBjcm9zcy1tYWpvciBhbmQgb2xkLWFwcC1uZXctZG9jdW1lbnQgY2FzZXMgKmxlZ2libGUqLCBuZXZlciB0b1xuLy8gcHJvZHVjZSBhIHBsYXVzaWJsZS1idXQtd3JvbmcgcmVuZGVyOlxuLy9cbi8vICAgLSB1bmtub3duIGBmb3JtYXRgIG1ham9yICAgICAgICDihpIgcmVmdXNlIChuZXZlciBhIHBhcnRpYWwgcGFyc2UpXG4vLyAgIC0gYXBwIG5ld2VyLCBzYW1lIG1ham9yICAgICAgICAg4oaSIHJ1biAgIChhZGRpdGl2ZS1vbmx5OiB0aGUgY2FsbGFibGVzIHN0aWxsIGV4aXN0KVxuLy8gICAtIGFwcCBvbGRlciB0aGFuIHRoZSBkb2MgbmVlZHMgIOKGkiBkZWdyYWRlIChzcGVjaWZpYyBjZWxscy9jb21wb25lbnRzIGJlY29tZSBcIm5lZWRzIOKJpSB4XCJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyczsgdGhlIHJlc3QgcnVucylcblxuaW1wb3J0IHR5cGUgeyBSZWNrb25lck1hbmlmZXN0IH0gZnJvbSAnLi90eXBlcy50cyc7XG5pbXBvcnQgeyBzYXRpc2ZpZXMgfSBmcm9tICcuL3NlbXZlci50cyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQXBwVmVyc2lvbnMge1xuICAvKiogVGhlIGRvY3VtZW50LXNjaGVtYSBtYWpvcnMgdGhpcyBhcHAgdW5kZXJzdGFuZHMuICovXG4gIGZvcm1hdHM6IG51bWJlcltdO1xuICBzdGRsaWI6IHN0cmluZztcbiAgY2F0YWxvZzogc3RyaW5nO1xuICB0aWVyVGFnOiBudW1iZXI7XG59XG5cbmV4cG9ydCB0eXBlIENvbXBhdFZlcmRpY3QgPVxuICB8IHsgc3RhdHVzOiAncnVuJyB9XG4gIHwgeyBzdGF0dXM6ICdkZWdyYWRlJzsgcmVhc29uczogc3RyaW5nW10gfVxuICB8IHsgc3RhdHVzOiAncmVmdXNlJzsgcmVhc29uOiBzdHJpbmcgfTtcblxuLyoqIFJlc29sdmUgd2hldGhlciBgYXBwYCBjYW4gb3BlbiBhIGRvY3VtZW50IHdpdGggdGhlIGdpdmVuIGBtYW5pZmVzdGAuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUNvbXBhdChhcHA6IEFwcFZlcnNpb25zLCBtYW5pZmVzdDogUmVja29uZXJNYW5pZmVzdCk6IENvbXBhdFZlcmRpY3Qge1xuICBpZiAoIWFwcC5mb3JtYXRzLmluY2x1ZGVzKG1hbmlmZXN0LmZvcm1hdCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzOiAncmVmdXNlJyxcbiAgICAgIHJlYXNvbjogYHRoaXMgcmVwb3J0IG5lZWRzIFJlY2tvbmVyIGRvY3VtZW50IGZvcm1hdCAke21hbmlmZXN0LmZvcm1hdH07IHRoaXMgYXBwIHVuZGVyc3RhbmRzICR7YXBwLmZvcm1hdHMuam9pbignLCAnKX0uYCxcbiAgICB9O1xuICB9XG5cbiAgY29uc3QgcmVhc29uczogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgeyBzdGRsaWIsIGNhdGFsb2cgfSA9IG1hbmlmZXN0LmNvbXBhdDtcblxuICBpZiAoc3RkbGliICE9PSB1bmRlZmluZWQgJiYgIXNhdGlzZmllcyhhcHAuc3RkbGliLCBzdGRsaWIpKSB7XG4gICAgcmVhc29ucy5wdXNoKGBuZWVkcyBzdGRsaWIgJHtzdGRsaWJ9IChhcHAgaGFzICR7YXBwLnN0ZGxpYn0pYCk7XG4gIH1cbiAgaWYgKGNhdGFsb2cgIT09IHVuZGVmaW5lZCAmJiAhc2F0aXNmaWVzKGFwcC5jYXRhbG9nLCBjYXRhbG9nKSkge1xuICAgIHJlYXNvbnMucHVzaChgbmVlZHMgY29tcG9uZW50IGNhdGFsb2cgJHtjYXRhbG9nfSAoYXBwIGhhcyAke2FwcC5jYXRhbG9nfSlgKTtcbiAgfVxuXG4gIC8vIEEgbmV3ZXIgaW4tZmlsZSB0aWVyVGFnIGVuY29kaW5nIGlzIG5vdCBhIHJlZnVzYWwgb3IgYSB3aG9sZS1kb2N1bWVudCBkZWdyYWRlOiBhblxuICAvLyB1bmtub3duIHRhZyBpcyB0cmVhdGVkIGFzIHRoZSBob3N0LWF1dGhvcml0YXRpdmUgbW91bnQgdGllciBhbmQgdGhlIGluLWZpbGUgdGFnIGlzXG4gIC8vIGlnbm9yZWQgKMKnMy9PUS0yKSwgc28gaXQgbmV2ZXIgdXAtbGFiZWxzLiBJdCBpcyBzdXJmYWNlZCBhcyBhbiBpbmZvcm1hdGlvbmFsIHJlYXNvblxuICAvLyBvbmx5IHdoZW4gdGhlIHJlc3QgYWxyZWFkeSBkZWdyYWRlcywgYW5kIG5ldmVyIGdhdGVzIG9uIGl0cyBvd24uXG4gIGlmIChyZWFzb25zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHsgc3RhdHVzOiAncnVuJyB9O1xuICByZXR1cm4geyBzdGF0dXM6ICdkZWdyYWRlJywgcmVhc29ucyB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFZQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFrQkE7QUFDTyxTQUFTQyxhQUFhQSxDQUFDQyxHQUFnQixFQUFFQyxRQUEwQixFQUFpQjtFQUN6RixJQUFJLENBQUNELEdBQUcsQ0FBQ0UsT0FBTyxDQUFDQyxRQUFRLENBQUNGLFFBQVEsQ0FBQ0csTUFBTSxDQUFDLEVBQUU7SUFDMUMsT0FBTztNQUNMQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsTUFBTSxFQUFFLDhDQUE4Q0wsUUFBUSxDQUFDRyxNQUFNLDBCQUEwQkosR0FBRyxDQUFDRSxPQUFPLENBQUNLLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDdkgsQ0FBQztFQUNIO0VBRUEsTUFBTUMsT0FBaUIsR0FBRyxFQUFFO0VBQzVCLE1BQU07SUFBRUMsTUFBTTtJQUFFQztFQUFRLENBQUMsR0FBR1QsUUFBUSxDQUFDVSxNQUFNO0VBRTNDLElBQUlGLE1BQU0sS0FBS0csU0FBUyxJQUFJLENBQUMsSUFBQUMsaUJBQVMsRUFBQ2IsR0FBRyxDQUFDUyxNQUFNLEVBQUVBLE1BQU0sQ0FBQyxFQUFFO0lBQzFERCxPQUFPLENBQUNNLElBQUksQ0FBQyxnQkFBZ0JMLE1BQU0sYUFBYVQsR0FBRyxDQUFDUyxNQUFNLEdBQUcsQ0FBQztFQUNoRTtFQUNBLElBQUlDLE9BQU8sS0FBS0UsU0FBUyxJQUFJLENBQUMsSUFBQUMsaUJBQVMsRUFBQ2IsR0FBRyxDQUFDVSxPQUFPLEVBQUVBLE9BQU8sQ0FBQyxFQUFFO0lBQzdERixPQUFPLENBQUNNLElBQUksQ0FBQywyQkFBMkJKLE9BQU8sYUFBYVYsR0FBRyxDQUFDVSxPQUFPLEdBQUcsQ0FBQztFQUM3RTs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlGLE9BQU8sQ0FBQ08sTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUVWLE1BQU0sRUFBRTtFQUFNLENBQUM7RUFDbEQsT0FBTztJQUFFQSxNQUFNLEVBQUUsU0FBUztJQUFFRztFQUFRLENBQUM7QUFDdkMiLCJpZ25vcmVMaXN0IjpbXX0=