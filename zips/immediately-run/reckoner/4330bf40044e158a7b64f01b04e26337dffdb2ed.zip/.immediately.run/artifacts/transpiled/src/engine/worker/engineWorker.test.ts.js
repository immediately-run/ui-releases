"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/web.dom-exception.stack.js");
require("core-js/modules/web.structured-clone.js");
var _vitest = require("vitest");
var _engineWorker = require("./engineWorker.ts");
const SOURCES = {
  sheet: `import { cell } from "@reckoner/stdlib";
export const base = cell({ doc: "base", inputs: { x: "params.x" }, formula: ({ x }) => x + 1 });
export const dbl = cell({ doc: "double base", inputs: { b: "sheet.base" }, formula: ({ b }) => b * 2 });
`
};
(0, _vitest.describe)('createEngineWorker', () => {
  (0, _vitest.it)('builds a serializable descriptor with topo order + externals (no formulas cross the wire)', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    const d = w.build(SOURCES);
    (0, _vitest.expect)(d.order).toEqual(['sheet.base', 'sheet.dbl']);
    (0, _vitest.expect)(d.externalInputs).toEqual(['params.x']);
    (0, _vitest.expect)(d.cycles).toEqual([]);
    (0, _vitest.expect)(d.cells.map(c => c.id).sort()).toEqual(['sheet.base', 'sheet.dbl']);
    // The descriptor is structured-clone safe — no function anywhere in it.
    (0, _vitest.expect)(() => structuredClone(d)).not.toThrow();
  });
  (0, _vitest.it)('evaluates a cell formula against host-resolved inputs', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    w.build(SOURCES);
    (0, _vitest.expect)(w.eval('sheet.base', {
      x: 5
    })).toBe(6);
    (0, _vitest.expect)(w.eval('sheet.dbl', {
      b: 6
    })).toBe(12);
  });
  (0, _vitest.it)('throws on an unknown cell', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    w.build(SOURCES);
    (0, _vitest.expect)(() => w.eval('sheet.nope', {})).toThrow(/unknown cell/);
  });
  (0, _vitest.it)('reports a dependency cycle in the descriptor', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    const d = w.build({
      s: `import { cell } from "@reckoner/stdlib";
export const a = cell({ doc: "a", inputs: { b: "s.b" }, formula: ({ b }) => b });
export const b = cell({ doc: "b", inputs: { a: "s.a" }, formula: ({ a }) => a });
`
    });
    (0, _vitest.expect)(d.cycles.length).toBeGreaterThan(0);
  });
});
(0, _vitest.describe)('createEngineWorker — tests + the review surface', () => {
  const SOURCES_WITH_TESTS = {
    sheet: `import { cell, testCell, expectEqual, property } from "@reckoner/stdlib";
export const base = cell({ doc: "base cell", inputs: { x: "params.x" }, formula: ({ x }) => x + 1 });
export const base_check = testCell({
  kind: "specification",
  subject: "sheet.base",
  expect: ({ result }) => expectEqual(result, 3),
});
export const base_sane = testCell({
  kind: "property",
  subject: "sheet.base",
  relation: property("positive", (r) => r > 0),
});
export const other = cell({ doc: "untested", inputs: { b: "sheet.base" }, formula: ({ b }) => b * 2 });
`
  };
  (0, _vitest.it)('the descriptor carries cell docs and the test cards (kinds + subjects), clone-safe', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    const d = w.build(SOURCES_WITH_TESTS);
    (0, _vitest.expect)(d.cells.find(c => c.id === 'sheet.base')?.doc).toBe('base cell');
    // Project explicitly rather than destructuring `span` away: an unused binding is a
    // lint error, and `_`-prefixing is not exempt under this repo's config.
    const cards = d.tests.map(t => ({
      id: t.id,
      worksheet: t.worksheet,
      name: t.name,
      kind: t.kind,
      subject: t.subject,
      inputs: t.inputs
    }));
    (0, _vitest.expect)(cards).toEqual([{
      id: 'sheet.base_check',
      worksheet: 'sheet',
      name: 'base_check',
      kind: 'specification',
      subject: 'sheet.base',
      inputs: {}
    }, {
      id: 'sheet.base_sane',
      worksheet: 'sheet',
      name: 'base_sane',
      kind: 'property',
      subject: 'sheet.base',
      inputs: {}
    }]);
    // R3-427: every test carries its declaration span, computed on the raw source.
    for (const t of d.tests) (0, _vitest.expect)(t.span?.line).toBeGreaterThan(0);
    (0, _vitest.expect)(() => structuredClone(d)).not.toThrow();
    (0, _vitest.expect)(d.order).not.toContain('sheet.base_check'); // tests never enter the value graph
  });
  (0, _vitest.it)('runSuites executes the closures worker-side and returns serializable verdicts', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    w.build(SOURCES_WITH_TESTS);
    const out = w.runSuites([{
      subject: 'sheet.base',
      subjectValue: 3,
      inputs: {
        x: 2
      }
    }]);
    (0, _vitest.expect)(out).toHaveLength(1);
    // specification passes (3 === 3) + property passes → validated (the §6 rule)
    (0, _vitest.expect)(out[0].verdict).toBe('validated');
    (0, _vitest.expect)(out[0].outcomes.map(o => [o.id, o.pass])).toEqual([['sheet.base_check', true], ['sheet.base_sane', true]]);
    (0, _vitest.expect)(() => structuredClone(out)).not.toThrow();
  });
  (0, _vitest.it)('a failing example test pins the cell as failing (any failure → failing)', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    w.build(SOURCES_WITH_TESTS);
    const out = w.runSuites([{
      subject: 'sheet.base',
      subjectValue: 99,
      inputs: {
        x: 2
      }
    }]);
    (0, _vitest.expect)(out[0].verdict).toBe('failing');
    (0, _vitest.expect)(out[0].outcomes.find(o => o.id === 'sheet.base_check')?.pass).toBe(false);
  });
  (0, _vitest.it)('a suite whose machinery crashes settles failing with the error recorded', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    w.build(SOURCES_WITH_TESTS);
    // expectEqual receives a non-number → its own guard fails it (not a crash); force a
    // crash by giving the subject a context whose inputs make the property throw.
    const out = w.runSuites([{
      subject: 'sheet.base',
      subjectValue: null,
      inputs: {
        x: null
      }
    }]);
    (0, _vitest.expect)(out[0].verdict).toBe('failing');
    (0, _vitest.expect)(out[0].outcomes.every(o => !o.pass)).toBe(true);
  });
});
(0, _vitest.describe)('createEngineWorker — formula source crosses the wire for the value inspector', () => {
  (0, _vitest.it)('the descriptor carries each formula\'s source text, clone-safe', () => {
    const w = (0, _engineWorker.createEngineWorker)();
    const d = w.build(SOURCES);
    const base = d.cells.find(c => c.id === 'sheet.base');
    (0, _vitest.expect)(base.formulaSource).toContain('x + 1');
    (0, _vitest.expect)(() => structuredClone(d)).not.toThrow();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9lbmdpbmVXb3JrZXIiLCJTT1VSQ0VTIiwic2hlZXQiLCJkZXNjcmliZSIsIml0IiwidyIsImNyZWF0ZUVuZ2luZVdvcmtlciIsImQiLCJidWlsZCIsImV4cGVjdCIsIm9yZGVyIiwidG9FcXVhbCIsImV4dGVybmFsSW5wdXRzIiwiY3ljbGVzIiwiY2VsbHMiLCJtYXAiLCJjIiwiaWQiLCJzb3J0Iiwic3RydWN0dXJlZENsb25lIiwibm90IiwidG9UaHJvdyIsImV2YWwiLCJ4IiwidG9CZSIsImIiLCJzIiwibGVuZ3RoIiwidG9CZUdyZWF0ZXJUaGFuIiwiU09VUkNFU19XSVRIX1RFU1RTIiwiZmluZCIsImRvYyIsImNhcmRzIiwidGVzdHMiLCJ0Iiwid29ya3NoZWV0IiwibmFtZSIsImtpbmQiLCJzdWJqZWN0IiwiaW5wdXRzIiwic3BhbiIsImxpbmUiLCJ0b0NvbnRhaW4iLCJvdXQiLCJydW5TdWl0ZXMiLCJzdWJqZWN0VmFsdWUiLCJ0b0hhdmVMZW5ndGgiLCJ2ZXJkaWN0Iiwib3V0Y29tZXMiLCJvIiwicGFzcyIsImV2ZXJ5IiwiYmFzZSIsImZvcm11bGFTb3VyY2UiXSwic291cmNlcyI6WyJlbmdpbmVXb3JrZXIudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBjcmVhdGVFbmdpbmVXb3JrZXIgfSBmcm9tICcuL2VuZ2luZVdvcmtlci50cyc7XG5cbmNvbnN0IFNPVVJDRVMgPSB7XG4gIHNoZWV0OiBgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5leHBvcnQgY29uc3QgYmFzZSA9IGNlbGwoeyBkb2M6IFwiYmFzZVwiLCBpbnB1dHM6IHsgeDogXCJwYXJhbXMueFwiIH0sIGZvcm11bGE6ICh7IHggfSkgPT4geCArIDEgfSk7XG5leHBvcnQgY29uc3QgZGJsID0gY2VsbCh7IGRvYzogXCJkb3VibGUgYmFzZVwiLCBpbnB1dHM6IHsgYjogXCJzaGVldC5iYXNlXCIgfSwgZm9ybXVsYTogKHsgYiB9KSA9PiBiICogMiB9KTtcbmAsXG59O1xuXG5kZXNjcmliZSgnY3JlYXRlRW5naW5lV29ya2VyJywgKCkgPT4ge1xuICBpdCgnYnVpbGRzIGEgc2VyaWFsaXphYmxlIGRlc2NyaXB0b3Igd2l0aCB0b3BvIG9yZGVyICsgZXh0ZXJuYWxzIChubyBmb3JtdWxhcyBjcm9zcyB0aGUgd2lyZSknLCAoKSA9PiB7XG4gICAgY29uc3QgdyA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuICAgIGNvbnN0IGQgPSB3LmJ1aWxkKFNPVVJDRVMpO1xuICAgIGV4cGVjdChkLm9yZGVyKS50b0VxdWFsKFsnc2hlZXQuYmFzZScsICdzaGVldC5kYmwnXSk7XG4gICAgZXhwZWN0KGQuZXh0ZXJuYWxJbnB1dHMpLnRvRXF1YWwoWydwYXJhbXMueCddKTtcbiAgICBleHBlY3QoZC5jeWNsZXMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChkLmNlbGxzLm1hcCgoYykgPT4gYy5pZCkuc29ydCgpKS50b0VxdWFsKFsnc2hlZXQuYmFzZScsICdzaGVldC5kYmwnXSk7XG4gICAgLy8gVGhlIGRlc2NyaXB0b3IgaXMgc3RydWN0dXJlZC1jbG9uZSBzYWZlIOKAlCBubyBmdW5jdGlvbiBhbnl3aGVyZSBpbiBpdC5cbiAgICBleHBlY3QoKCkgPT4gc3RydWN0dXJlZENsb25lKGQpKS5ub3QudG9UaHJvdygpO1xuICB9KTtcblxuICBpdCgnZXZhbHVhdGVzIGEgY2VsbCBmb3JtdWxhIGFnYWluc3QgaG9zdC1yZXNvbHZlZCBpbnB1dHMnLCAoKSA9PiB7XG4gICAgY29uc3QgdyA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuICAgIHcuYnVpbGQoU09VUkNFUyk7XG4gICAgZXhwZWN0KHcuZXZhbCgnc2hlZXQuYmFzZScsIHsgeDogNSB9KSkudG9CZSg2KTtcbiAgICBleHBlY3Qody5ldmFsKCdzaGVldC5kYmwnLCB7IGI6IDYgfSkpLnRvQmUoMTIpO1xuICB9KTtcblxuICBpdCgndGhyb3dzIG9uIGFuIHVua25vd24gY2VsbCcsICgpID0+IHtcbiAgICBjb25zdCB3ID0gY3JlYXRlRW5naW5lV29ya2VyKCk7XG4gICAgdy5idWlsZChTT1VSQ0VTKTtcbiAgICBleHBlY3QoKCkgPT4gdy5ldmFsKCdzaGVldC5ub3BlJywge30pKS50b1Rocm93KC91bmtub3duIGNlbGwvKTtcbiAgfSk7XG5cbiAgaXQoJ3JlcG9ydHMgYSBkZXBlbmRlbmN5IGN5Y2xlIGluIHRoZSBkZXNjcmlwdG9yJywgKCkgPT4ge1xuICAgIGNvbnN0IHcgPSBjcmVhdGVFbmdpbmVXb3JrZXIoKTtcbiAgICBjb25zdCBkID0gdy5idWlsZCh7XG4gICAgICBzOiBgaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5leHBvcnQgY29uc3QgYSA9IGNlbGwoeyBkb2M6IFwiYVwiLCBpbnB1dHM6IHsgYjogXCJzLmJcIiB9LCBmb3JtdWxhOiAoeyBiIH0pID0+IGIgfSk7XG5leHBvcnQgY29uc3QgYiA9IGNlbGwoeyBkb2M6IFwiYlwiLCBpbnB1dHM6IHsgYTogXCJzLmFcIiB9LCBmb3JtdWxhOiAoeyBhIH0pID0+IGEgfSk7XG5gLFxuICAgIH0pO1xuICAgIGV4cGVjdChkLmN5Y2xlcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ2NyZWF0ZUVuZ2luZVdvcmtlciDigJQgdGVzdHMgKyB0aGUgcmV2aWV3IHN1cmZhY2UnLCAoKSA9PiB7XG4gIGNvbnN0IFNPVVJDRVNfV0lUSF9URVNUUyA9IHtcbiAgICBzaGVldDogYGltcG9ydCB7IGNlbGwsIHRlc3RDZWxsLCBleHBlY3RFcXVhbCwgcHJvcGVydHkgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuZXhwb3J0IGNvbnN0IGJhc2UgPSBjZWxsKHsgZG9jOiBcImJhc2UgY2VsbFwiLCBpbnB1dHM6IHsgeDogXCJwYXJhbXMueFwiIH0sIGZvcm11bGE6ICh7IHggfSkgPT4geCArIDEgfSk7XG5leHBvcnQgY29uc3QgYmFzZV9jaGVjayA9IHRlc3RDZWxsKHtcbiAga2luZDogXCJzcGVjaWZpY2F0aW9uXCIsXG4gIHN1YmplY3Q6IFwic2hlZXQuYmFzZVwiLFxuICBleHBlY3Q6ICh7IHJlc3VsdCB9KSA9PiBleHBlY3RFcXVhbChyZXN1bHQsIDMpLFxufSk7XG5leHBvcnQgY29uc3QgYmFzZV9zYW5lID0gdGVzdENlbGwoe1xuICBraW5kOiBcInByb3BlcnR5XCIsXG4gIHN1YmplY3Q6IFwic2hlZXQuYmFzZVwiLFxuICByZWxhdGlvbjogcHJvcGVydHkoXCJwb3NpdGl2ZVwiLCAocikgPT4gciA+IDApLFxufSk7XG5leHBvcnQgY29uc3Qgb3RoZXIgPSBjZWxsKHsgZG9jOiBcInVudGVzdGVkXCIsIGlucHV0czogeyBiOiBcInNoZWV0LmJhc2VcIiB9LCBmb3JtdWxhOiAoeyBiIH0pID0+IGIgKiAyIH0pO1xuYCxcbiAgfTtcblxuICBpdCgndGhlIGRlc2NyaXB0b3IgY2FycmllcyBjZWxsIGRvY3MgYW5kIHRoZSB0ZXN0IGNhcmRzIChraW5kcyArIHN1YmplY3RzKSwgY2xvbmUtc2FmZScsICgpID0+IHtcbiAgICBjb25zdCB3ID0gY3JlYXRlRW5naW5lV29ya2VyKCk7XG4gICAgY29uc3QgZCA9IHcuYnVpbGQoU09VUkNFU19XSVRIX1RFU1RTKTtcbiAgICBleHBlY3QoZC5jZWxscy5maW5kKChjKSA9PiBjLmlkID09PSAnc2hlZXQuYmFzZScpPy5kb2MpLnRvQmUoJ2Jhc2UgY2VsbCcpO1xuICAgIC8vIFByb2plY3QgZXhwbGljaXRseSByYXRoZXIgdGhhbiBkZXN0cnVjdHVyaW5nIGBzcGFuYCBhd2F5OiBhbiB1bnVzZWQgYmluZGluZyBpcyBhXG4gICAgLy8gbGludCBlcnJvciwgYW5kIGBfYC1wcmVmaXhpbmcgaXMgbm90IGV4ZW1wdCB1bmRlciB0aGlzIHJlcG8ncyBjb25maWcuXG4gICAgY29uc3QgY2FyZHMgPSBkLnRlc3RzLm1hcCgodCkgPT4gKHtcbiAgICAgIGlkOiB0LmlkLCB3b3Jrc2hlZXQ6IHQud29ya3NoZWV0LCBuYW1lOiB0Lm5hbWUsIGtpbmQ6IHQua2luZCwgc3ViamVjdDogdC5zdWJqZWN0LCBpbnB1dHM6IHQuaW5wdXRzLFxuICAgIH0pKTtcbiAgICBleHBlY3QoY2FyZHMpLnRvRXF1YWwoW1xuICAgICAgeyBpZDogJ3NoZWV0LmJhc2VfY2hlY2snLCB3b3Jrc2hlZXQ6ICdzaGVldCcsIG5hbWU6ICdiYXNlX2NoZWNrJywga2luZDogJ3NwZWNpZmljYXRpb24nLCBzdWJqZWN0OiAnc2hlZXQuYmFzZScsIGlucHV0czoge30gfSxcbiAgICAgIHsgaWQ6ICdzaGVldC5iYXNlX3NhbmUnLCB3b3Jrc2hlZXQ6ICdzaGVldCcsIG5hbWU6ICdiYXNlX3NhbmUnLCBraW5kOiAncHJvcGVydHknLCBzdWJqZWN0OiAnc2hlZXQuYmFzZScsIGlucHV0czoge30gfSxcbiAgICBdKTtcbiAgICAvLyBSMy00Mjc6IGV2ZXJ5IHRlc3QgY2FycmllcyBpdHMgZGVjbGFyYXRpb24gc3BhbiwgY29tcHV0ZWQgb24gdGhlIHJhdyBzb3VyY2UuXG4gICAgZm9yIChjb25zdCB0IG9mIGQudGVzdHMpIGV4cGVjdCh0LnNwYW4/LmxpbmUpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgICBleHBlY3QoKCkgPT4gc3RydWN0dXJlZENsb25lKGQpKS5ub3QudG9UaHJvdygpO1xuICAgIGV4cGVjdChkLm9yZGVyKS5ub3QudG9Db250YWluKCdzaGVldC5iYXNlX2NoZWNrJyk7IC8vIHRlc3RzIG5ldmVyIGVudGVyIHRoZSB2YWx1ZSBncmFwaFxuICB9KTtcblxuICBpdCgncnVuU3VpdGVzIGV4ZWN1dGVzIHRoZSBjbG9zdXJlcyB3b3JrZXItc2lkZSBhbmQgcmV0dXJucyBzZXJpYWxpemFibGUgdmVyZGljdHMnLCAoKSA9PiB7XG4gICAgY29uc3QgdyA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuICAgIHcuYnVpbGQoU09VUkNFU19XSVRIX1RFU1RTKTtcbiAgICBjb25zdCBvdXQgPSB3LnJ1blN1aXRlcyhbeyBzdWJqZWN0OiAnc2hlZXQuYmFzZScsIHN1YmplY3RWYWx1ZTogMywgaW5wdXRzOiB7IHg6IDIgfSB9XSk7XG4gICAgZXhwZWN0KG91dCkudG9IYXZlTGVuZ3RoKDEpO1xuICAgIC8vIHNwZWNpZmljYXRpb24gcGFzc2VzICgzID09PSAzKSArIHByb3BlcnR5IHBhc3NlcyDihpIgdmFsaWRhdGVkICh0aGUgwqc2IHJ1bGUpXG4gICAgZXhwZWN0KG91dFswXS52ZXJkaWN0KS50b0JlKCd2YWxpZGF0ZWQnKTtcbiAgICBleHBlY3Qob3V0WzBdLm91dGNvbWVzLm1hcCgobykgPT4gW28uaWQsIG8ucGFzc10pKS50b0VxdWFsKFtcbiAgICAgIFsnc2hlZXQuYmFzZV9jaGVjaycsIHRydWVdLFxuICAgICAgWydzaGVldC5iYXNlX3NhbmUnLCB0cnVlXSxcbiAgICBdKTtcbiAgICBleHBlY3QoKCkgPT4gc3RydWN0dXJlZENsb25lKG91dCkpLm5vdC50b1Rocm93KCk7XG4gIH0pO1xuXG4gIGl0KCdhIGZhaWxpbmcgZXhhbXBsZSB0ZXN0IHBpbnMgdGhlIGNlbGwgYXMgZmFpbGluZyAoYW55IGZhaWx1cmUg4oaSIGZhaWxpbmcpJywgKCkgPT4ge1xuICAgIGNvbnN0IHcgPSBjcmVhdGVFbmdpbmVXb3JrZXIoKTtcbiAgICB3LmJ1aWxkKFNPVVJDRVNfV0lUSF9URVNUUyk7XG4gICAgY29uc3Qgb3V0ID0gdy5ydW5TdWl0ZXMoW3sgc3ViamVjdDogJ3NoZWV0LmJhc2UnLCBzdWJqZWN0VmFsdWU6IDk5LCBpbnB1dHM6IHsgeDogMiB9IH1dKTtcbiAgICBleHBlY3Qob3V0WzBdLnZlcmRpY3QpLnRvQmUoJ2ZhaWxpbmcnKTtcbiAgICBleHBlY3Qob3V0WzBdLm91dGNvbWVzLmZpbmQoKG8pID0+IG8uaWQgPT09ICdzaGVldC5iYXNlX2NoZWNrJyk/LnBhc3MpLnRvQmUoZmFsc2UpO1xuICB9KTtcblxuICBpdCgnYSBzdWl0ZSB3aG9zZSBtYWNoaW5lcnkgY3Jhc2hlcyBzZXR0bGVzIGZhaWxpbmcgd2l0aCB0aGUgZXJyb3IgcmVjb3JkZWQnLCAoKSA9PiB7XG4gICAgY29uc3QgdyA9IGNyZWF0ZUVuZ2luZVdvcmtlcigpO1xuICAgIHcuYnVpbGQoU09VUkNFU19XSVRIX1RFU1RTKTtcbiAgICAvLyBleHBlY3RFcXVhbCByZWNlaXZlcyBhIG5vbi1udW1iZXIg4oaSIGl0cyBvd24gZ3VhcmQgZmFpbHMgaXQgKG5vdCBhIGNyYXNoKTsgZm9yY2UgYVxuICAgIC8vIGNyYXNoIGJ5IGdpdmluZyB0aGUgc3ViamVjdCBhIGNvbnRleHQgd2hvc2UgaW5wdXRzIG1ha2UgdGhlIHByb3BlcnR5IHRocm93LlxuICAgIGNvbnN0IG91dCA9IHcucnVuU3VpdGVzKFt7IHN1YmplY3Q6ICdzaGVldC5iYXNlJywgc3ViamVjdFZhbHVlOiBudWxsLCBpbnB1dHM6IHsgeDogbnVsbCB9IH1dKTtcbiAgICBleHBlY3Qob3V0WzBdLnZlcmRpY3QpLnRvQmUoJ2ZhaWxpbmcnKTtcbiAgICBleHBlY3Qob3V0WzBdLm91dGNvbWVzLmV2ZXJ5KChvKSA9PiAhby5wYXNzKSkudG9CZSh0cnVlKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ2NyZWF0ZUVuZ2luZVdvcmtlciDigJQgZm9ybXVsYSBzb3VyY2UgY3Jvc3NlcyB0aGUgd2lyZSBmb3IgdGhlIHZhbHVlIGluc3BlY3RvcicsICgpID0+IHtcbiAgaXQoJ3RoZSBkZXNjcmlwdG9yIGNhcnJpZXMgZWFjaCBmb3JtdWxhXFwncyBzb3VyY2UgdGV4dCwgY2xvbmUtc2FmZScsICgpID0+IHtcbiAgICBjb25zdCB3ID0gY3JlYXRlRW5naW5lV29ya2VyKCk7XG4gICAgY29uc3QgZCA9IHcuYnVpbGQoU09VUkNFUyk7XG4gICAgY29uc3QgYmFzZSA9IGQuY2VsbHMuZmluZCgoYykgPT4gYy5pZCA9PT0gJ3NoZWV0LmJhc2UnKSE7XG4gICAgZXhwZWN0KGJhc2UuZm9ybXVsYVNvdXJjZSkudG9Db250YWluKCd4ICsgMScpO1xuICAgIGV4cGVjdCgoKSA9PiBzdHJ1Y3R1cmVkQ2xvbmUoZCkpLm5vdC50b1Rocm93KCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBRUEsTUFBTUUsT0FBTyxHQUFHO0VBQ2RDLEtBQUssRUFBRTtBQUNUO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFFRCxJQUFBQyxnQkFBUSxFQUFDLG9CQUFvQixFQUFFLE1BQU07RUFDbkMsSUFBQUMsVUFBRSxFQUFDLDJGQUEyRixFQUFFLE1BQU07SUFDcEcsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLGdDQUFrQixFQUFDLENBQUM7SUFDOUIsTUFBTUMsQ0FBQyxHQUFHRixDQUFDLENBQUNHLEtBQUssQ0FBQ1AsT0FBTyxDQUFDO0lBQzFCLElBQUFRLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDRyxLQUFLLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3BELElBQUFGLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDSyxjQUFjLENBQUMsQ0FBQ0QsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDOUMsSUFBQUYsY0FBTSxFQUFDRixDQUFDLENBQUNNLE1BQU0sQ0FBQyxDQUFDRixPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzVCLElBQUFGLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDTyxLQUFLLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNQLE9BQU8sQ0FBQyxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM1RTtJQUNBLElBQUFGLGNBQU0sRUFBQyxNQUFNVSxlQUFlLENBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUNhLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDaEQsQ0FBQyxDQUFDO0VBRUYsSUFBQWpCLFVBQUUsRUFBQyx1REFBdUQsRUFBRSxNQUFNO0lBQ2hFLE1BQU1DLENBQUMsR0FBRyxJQUFBQyxnQ0FBa0IsRUFBQyxDQUFDO0lBQzlCRCxDQUFDLENBQUNHLEtBQUssQ0FBQ1AsT0FBTyxDQUFDO0lBQ2hCLElBQUFRLGNBQU0sRUFBQ0osQ0FBQyxDQUFDaUIsSUFBSSxDQUFDLFlBQVksRUFBRTtNQUFFQyxDQUFDLEVBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlDLElBQUFmLGNBQU0sRUFBQ0osQ0FBQyxDQUFDaUIsSUFBSSxDQUFDLFdBQVcsRUFBRTtNQUFFRyxDQUFDLEVBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDO0VBQ2hELENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMsMkJBQTJCLEVBQUUsTUFBTTtJQUNwQyxNQUFNQyxDQUFDLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztJQUM5QkQsQ0FBQyxDQUFDRyxLQUFLLENBQUNQLE9BQU8sQ0FBQztJQUNoQixJQUFBUSxjQUFNLEVBQUMsTUFBTUosQ0FBQyxDQUFDaUIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNELE9BQU8sQ0FBQyxjQUFjLENBQUM7RUFDaEUsQ0FBQyxDQUFDO0VBRUYsSUFBQWpCLFVBQUUsRUFBQyw4Q0FBOEMsRUFBRSxNQUFNO0lBQ3ZELE1BQU1DLENBQUMsR0FBRyxJQUFBQyxnQ0FBa0IsRUFBQyxDQUFDO0lBQzlCLE1BQU1DLENBQUMsR0FBR0YsQ0FBQyxDQUFDRyxLQUFLLENBQUM7TUFDaEJrQixDQUFDLEVBQUU7QUFDVDtBQUNBO0FBQ0E7SUFDSSxDQUFDLENBQUM7SUFDRixJQUFBakIsY0FBTSxFQUFDRixDQUFDLENBQUNNLE1BQU0sQ0FBQ2MsTUFBTSxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFDNUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQXpCLGdCQUFRLEVBQUMsaURBQWlELEVBQUUsTUFBTTtFQUNoRSxNQUFNMEIsa0JBQWtCLEdBQUc7SUFDekIzQixLQUFLLEVBQUU7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLENBQUM7RUFFRCxJQUFBRSxVQUFFLEVBQUMsb0ZBQW9GLEVBQUUsTUFBTTtJQUM3RixNQUFNQyxDQUFDLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztJQUM5QixNQUFNQyxDQUFDLEdBQUdGLENBQUMsQ0FBQ0csS0FBSyxDQUFDcUIsa0JBQWtCLENBQUM7SUFDckMsSUFBQXBCLGNBQU0sRUFBQ0YsQ0FBQyxDQUFDTyxLQUFLLENBQUNnQixJQUFJLENBQUVkLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUssWUFBWSxDQUFDLEVBQUVjLEdBQUcsQ0FBQyxDQUFDUCxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ3pFO0lBQ0E7SUFDQSxNQUFNUSxLQUFLLEdBQUd6QixDQUFDLENBQUMwQixLQUFLLENBQUNsQixHQUFHLENBQUVtQixDQUFDLEtBQU07TUFDaENqQixFQUFFLEVBQUVpQixDQUFDLENBQUNqQixFQUFFO01BQUVrQixTQUFTLEVBQUVELENBQUMsQ0FBQ0MsU0FBUztNQUFFQyxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSTtNQUFFQyxJQUFJLEVBQUVILENBQUMsQ0FBQ0csSUFBSTtNQUFFQyxPQUFPLEVBQUVKLENBQUMsQ0FBQ0ksT0FBTztNQUFFQyxNQUFNLEVBQUVMLENBQUMsQ0FBQ0s7SUFDOUYsQ0FBQyxDQUFDLENBQUM7SUFDSCxJQUFBOUIsY0FBTSxFQUFDdUIsS0FBSyxDQUFDLENBQUNyQixPQUFPLENBQUMsQ0FDcEI7TUFBRU0sRUFBRSxFQUFFLGtCQUFrQjtNQUFFa0IsU0FBUyxFQUFFLE9BQU87TUFBRUMsSUFBSSxFQUFFLFlBQVk7TUFBRUMsSUFBSSxFQUFFLGVBQWU7TUFBRUMsT0FBTyxFQUFFLFlBQVk7TUFBRUMsTUFBTSxFQUFFLENBQUM7SUFBRSxDQUFDLEVBQzVIO01BQUV0QixFQUFFLEVBQUUsaUJBQWlCO01BQUVrQixTQUFTLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUUsV0FBVztNQUFFQyxJQUFJLEVBQUUsVUFBVTtNQUFFQyxPQUFPLEVBQUUsWUFBWTtNQUFFQyxNQUFNLEVBQUUsQ0FBQztJQUFFLENBQUMsQ0FDdEgsQ0FBQztJQUNGO0lBQ0EsS0FBSyxNQUFNTCxDQUFDLElBQUkzQixDQUFDLENBQUMwQixLQUFLLEVBQUUsSUFBQXhCLGNBQU0sRUFBQ3lCLENBQUMsQ0FBQ00sSUFBSSxFQUFFQyxJQUFJLENBQUMsQ0FBQ2IsZUFBZSxDQUFDLENBQUMsQ0FBQztJQUNoRSxJQUFBbkIsY0FBTSxFQUFDLE1BQU1VLGVBQWUsQ0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQ2EsR0FBRyxDQUFDQyxPQUFPLENBQUMsQ0FBQztJQUM5QyxJQUFBWixjQUFNLEVBQUNGLENBQUMsQ0FBQ0csS0FBSyxDQUFDLENBQUNVLEdBQUcsQ0FBQ3NCLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7RUFDckQsQ0FBQyxDQUFDO0VBRUYsSUFBQXRDLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxNQUFNO0lBQ3hGLE1BQU1DLENBQUMsR0FBRyxJQUFBQyxnQ0FBa0IsRUFBQyxDQUFDO0lBQzlCRCxDQUFDLENBQUNHLEtBQUssQ0FBQ3FCLGtCQUFrQixDQUFDO0lBQzNCLE1BQU1jLEdBQUcsR0FBR3RDLENBQUMsQ0FBQ3VDLFNBQVMsQ0FBQyxDQUFDO01BQUVOLE9BQU8sRUFBRSxZQUFZO01BQUVPLFlBQVksRUFBRSxDQUFDO01BQUVOLE1BQU0sRUFBRTtRQUFFaEIsQ0FBQyxFQUFFO01BQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUN2RixJQUFBZCxjQUFNLEVBQUNrQyxHQUFHLENBQUMsQ0FBQ0csWUFBWSxDQUFDLENBQUMsQ0FBQztJQUMzQjtJQUNBLElBQUFyQyxjQUFNLEVBQUNrQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNJLE9BQU8sQ0FBQyxDQUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUN4QyxJQUFBZixjQUFNLEVBQUNrQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNLLFFBQVEsQ0FBQ2pDLEdBQUcsQ0FBRWtDLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNoQyxFQUFFLEVBQUVnQyxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZDLE9BQU8sQ0FBQyxDQUN6RCxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxFQUMxQixDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUMxQixDQUFDO0lBQ0YsSUFBQUYsY0FBTSxFQUFDLE1BQU1VLGVBQWUsQ0FBQ3dCLEdBQUcsQ0FBQyxDQUFDLENBQUN2QixHQUFHLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0VBQ2xELENBQUMsQ0FBQztFQUVGLElBQUFqQixVQUFFLEVBQUMseUVBQXlFLEVBQUUsTUFBTTtJQUNsRixNQUFNQyxDQUFDLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztJQUM5QkQsQ0FBQyxDQUFDRyxLQUFLLENBQUNxQixrQkFBa0IsQ0FBQztJQUMzQixNQUFNYyxHQUFHLEdBQUd0QyxDQUFDLENBQUN1QyxTQUFTLENBQUMsQ0FBQztNQUFFTixPQUFPLEVBQUUsWUFBWTtNQUFFTyxZQUFZLEVBQUUsRUFBRTtNQUFFTixNQUFNLEVBQUU7UUFBRWhCLENBQUMsRUFBRTtNQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDeEYsSUFBQWQsY0FBTSxFQUFDa0MsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxPQUFPLENBQUMsQ0FBQ3ZCLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDdEMsSUFBQWYsY0FBTSxFQUFDa0MsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDSyxRQUFRLENBQUNsQixJQUFJLENBQUVtQixDQUFDLElBQUtBLENBQUMsQ0FBQ2hDLEVBQUUsS0FBSyxrQkFBa0IsQ0FBQyxFQUFFaUMsSUFBSSxDQUFDLENBQUMxQixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQ3BGLENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMseUVBQXlFLEVBQUUsTUFBTTtJQUNsRixNQUFNQyxDQUFDLEdBQUcsSUFBQUMsZ0NBQWtCLEVBQUMsQ0FBQztJQUM5QkQsQ0FBQyxDQUFDRyxLQUFLLENBQUNxQixrQkFBa0IsQ0FBQztJQUMzQjtJQUNBO0lBQ0EsTUFBTWMsR0FBRyxHQUFHdEMsQ0FBQyxDQUFDdUMsU0FBUyxDQUFDLENBQUM7TUFBRU4sT0FBTyxFQUFFLFlBQVk7TUFBRU8sWUFBWSxFQUFFLElBQUk7TUFBRU4sTUFBTSxFQUFFO1FBQUVoQixDQUFDLEVBQUU7TUFBSztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzdGLElBQUFkLGNBQU0sRUFBQ2tDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksT0FBTyxDQUFDLENBQUN2QixJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3RDLElBQUFmLGNBQU0sRUFBQ2tDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ssUUFBUSxDQUFDRyxLQUFLLENBQUVGLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzFELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFyQixnQkFBUSxFQUFDLDhFQUE4RSxFQUFFLE1BQU07RUFDN0YsSUFBQUMsVUFBRSxFQUFDLGdFQUFnRSxFQUFFLE1BQU07SUFDekUsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLGdDQUFrQixFQUFDLENBQUM7SUFDOUIsTUFBTUMsQ0FBQyxHQUFHRixDQUFDLENBQUNHLEtBQUssQ0FBQ1AsT0FBTyxDQUFDO0lBQzFCLE1BQU1tRCxJQUFJLEdBQUc3QyxDQUFDLENBQUNPLEtBQUssQ0FBQ2dCLElBQUksQ0FBRWQsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBSyxZQUFZLENBQUU7SUFDeEQsSUFBQVIsY0FBTSxFQUFDMkMsSUFBSSxDQUFDQyxhQUFhLENBQUMsQ0FBQ1gsU0FBUyxDQUFDLE9BQU8sQ0FBQztJQUM3QyxJQUFBakMsY0FBTSxFQUFDLE1BQU1VLGVBQWUsQ0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQ2EsR0FBRyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUNoRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=