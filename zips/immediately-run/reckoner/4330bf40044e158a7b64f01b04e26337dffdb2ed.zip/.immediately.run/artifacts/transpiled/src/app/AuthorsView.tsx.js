var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _index = require("../report/index.ts");
var _authorsView = require("./authorsView.ts");
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The author's view (AUTHORS_VIEW_SPEC §1) — the document describing itself, rendered
// in place of the report under a small header with an explicit way back (§1.2: the view
// is component state, not a route; browser back exits the app, as it does for every
// panel today). The node tree is the document's own author's-view template or the
// built-in scaffold (session-selected, §4); the reflection port is provided HERE and
// only here (§6 — the restriction is structural).
function AuthorsView({
  session,
  bindings,
  verdicts,
  onClose
}) {
  _s();
  const reflection = (0, _react.useMemo)(() => (0, _authorsView.buildReflectionPort)(session.engine, session.loaded, verdicts), [session, verdicts]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "rk-authors",
    "aria-label": "Author's view",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "rk-authors-head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "rk-authors-title",
        children: [session.title, " \u2014 author's view", !session.authorsFromDocument && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-scratch-tag",
          children: "default"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rk-wb-close",
        onClick: onClose,
        children: "Back to report"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_index.ReportView, {
      nodes: session.authorsNodes,
      bindings: bindings,
      reflection: reflection
    })]
  });
}
_s(AuthorsView, "f3QH84B9aiQa6ioj6jEd0s8TI1U=");
_c = AuthorsView;
var _default = exports.default = AuthorsView;
var _c;
$RefreshReg$(_c, "AuthorsView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2luZGV4IiwiX2F1dGhvcnNWaWV3IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkF1dGhvcnNWaWV3Iiwic2Vzc2lvbiIsImJpbmRpbmdzIiwidmVyZGljdHMiLCJvbkNsb3NlIiwicmVmbGVjdGlvbiIsInVzZU1lbW8iLCJidWlsZFJlZmxlY3Rpb25Qb3J0IiwiZW5naW5lIiwibG9hZGVkIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwidGl0bGUiLCJhdXRob3JzRnJvbURvY3VtZW50IiwianN4IiwidHlwZSIsIm9uQ2xpY2siLCJSZXBvcnRWaWV3Iiwibm9kZXMiLCJhdXRob3JzTm9kZXMiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdXRob3JzVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGF1dGhvcidzIHZpZXcgKEFVVEhPUlNfVklFV19TUEVDIMKnMSkg4oCUIHRoZSBkb2N1bWVudCBkZXNjcmliaW5nIGl0c2VsZiwgcmVuZGVyZWRcbi8vIGluIHBsYWNlIG9mIHRoZSByZXBvcnQgdW5kZXIgYSBzbWFsbCBoZWFkZXIgd2l0aCBhbiBleHBsaWNpdCB3YXkgYmFjayAowqcxLjI6IHRoZSB2aWV3XG4vLyBpcyBjb21wb25lbnQgc3RhdGUsIG5vdCBhIHJvdXRlOyBicm93c2VyIGJhY2sgZXhpdHMgdGhlIGFwcCwgYXMgaXQgZG9lcyBmb3IgZXZlcnlcbi8vIHBhbmVsIHRvZGF5KS4gVGhlIG5vZGUgdHJlZSBpcyB0aGUgZG9jdW1lbnQncyBvd24gYXV0aG9yJ3MtdmlldyB0ZW1wbGF0ZSBvciB0aGVcbi8vIGJ1aWx0LWluIHNjYWZmb2xkIChzZXNzaW9uLXNlbGVjdGVkLCDCpzQpOyB0aGUgcmVmbGVjdGlvbiBwb3J0IGlzIHByb3ZpZGVkIEhFUkUgYW5kXG4vLyBvbmx5IGhlcmUgKMKnNiDigJQgdGhlIHJlc3RyaWN0aW9uIGlzIHN0cnVjdHVyYWwpLlxuaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgU3ViamVjdFJlc3VsdCB9IGZyb20gJy4uL2VuZ2luZS93b3JrZXIvcHJvdG9jb2wudHMnO1xuaW1wb3J0IHsgUmVwb3J0VmlldyB9IGZyb20gJy4uL3JlcG9ydC9pbmRleC50cyc7XG5pbXBvcnQgdHlwZSB7IEJpbmRpbmdzIH0gZnJvbSAnLi4vcmVwb3J0L2luZGV4LnRzJztcbmltcG9ydCB7IGJ1aWxkUmVmbGVjdGlvblBvcnQgfSBmcm9tICcuL2F1dGhvcnNWaWV3LnRzJztcbmltcG9ydCB0eXBlIHsgUmVwb3J0U2Vzc2lvbiB9IGZyb20gJy4vcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgJy4vd29ya2Jvb2stcGFuZWwuY3NzJztcblxuaW50ZXJmYWNlIEF1dGhvcnNWaWV3UHJvcHMge1xuICBzZXNzaW9uOiBSZXBvcnRTZXNzaW9uO1xuICBiaW5kaW5nczogQmluZGluZ3M7XG4gIC8qKiBUaGUgYXBwLWxldmVsIHN1aXRlIHJlc3VsdHMg4oCUIHRoZSBTQU1FIG9iamVjdCBldmVyeSByZXZpZXcgc3VyZmFjZSByZW5kZXJzIChHLUFWLTEwKS4gKi9cbiAgdmVyZGljdHM6IFJlYWRvbmx5TWFwPHN0cmluZywgU3ViamVjdFJlc3VsdD4gfCBudWxsO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBBdXRob3JzVmlldyh7IHNlc3Npb24sIGJpbmRpbmdzLCB2ZXJkaWN0cywgb25DbG9zZSB9OiBBdXRob3JzVmlld1Byb3BzKSB7XG4gIGNvbnN0IHJlZmxlY3Rpb24gPSB1c2VNZW1vKFxuICAgICgpID0+IGJ1aWxkUmVmbGVjdGlvblBvcnQoc2Vzc2lvbi5lbmdpbmUsIHNlc3Npb24ubG9hZGVkLCB2ZXJkaWN0cyksXG4gICAgW3Nlc3Npb24sIHZlcmRpY3RzXSxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJrLWF1dGhvcnNcIiBhcmlhLWxhYmVsPVwiQXV0aG9yJ3Mgdmlld1wiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJyay1hdXRob3JzLWhlYWRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstYXV0aG9ycy10aXRsZVwiPlxuICAgICAgICAgIHtzZXNzaW9uLnRpdGxlfSDigJQgYXV0aG9yJ3Mgdmlld1xuICAgICAgICAgIHshc2Vzc2lvbi5hdXRob3JzRnJvbURvY3VtZW50ICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLXNjcmF0Y2gtdGFnXCI+ZGVmYXVsdDwvc3Bhbj59XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmstd2ItY2xvc2VcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgICAgICBCYWNrIHRvIHJlcG9ydFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgPFJlcG9ydFZpZXcgbm9kZXM9e3Nlc3Npb24uYXV0aG9yc05vZGVzfSBiaW5kaW5ncz17YmluZGluZ3N9IHJlZmxlY3Rpb249e3JlZmxlY3Rpb259IC8+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBdXRob3JzVmlldztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsWUFBQSxHQUFBRixPQUFBO0FBRUFBLE9BQUE7QUFBOEIsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBWjlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWlCQSxTQUFTQyxXQUFXQSxDQUFDO0VBQUVDLE9BQU87RUFBRUMsUUFBUTtFQUFFQyxRQUFRO0VBQUVDO0FBQTBCLENBQUMsRUFBRTtFQUFBTixFQUFBO0VBQy9FLE1BQU1PLFVBQVUsR0FBRyxJQUFBQyxjQUFPLEVBQ3hCLE1BQU0sSUFBQUMsZ0NBQW1CLEVBQUNOLE9BQU8sQ0FBQ08sTUFBTSxFQUFFUCxPQUFPLENBQUNRLE1BQU0sRUFBRU4sUUFBUSxDQUFDLEVBQ25FLENBQUNGLE9BQU8sRUFBRUUsUUFBUSxDQUNwQixDQUFDO0VBRUQsb0JBQ0UsSUFBQU4sV0FBQSxDQUFBYSxJQUFBO0lBQVNDLFNBQVMsRUFBQyxZQUFZO0lBQUMsY0FBVyxlQUFlO0lBQUFDLFFBQUEsZ0JBQ3hELElBQUFmLFdBQUEsQ0FBQWEsSUFBQTtNQUFRQyxTQUFTLEVBQUMsaUJBQWlCO01BQUFDLFFBQUEsZ0JBQ2pDLElBQUFmLFdBQUEsQ0FBQWEsSUFBQTtRQUFNQyxTQUFTLEVBQUMsa0JBQWtCO1FBQUFDLFFBQUEsR0FDL0JYLE9BQU8sQ0FBQ1ksS0FBSyxFQUFDLHVCQUNmLEVBQUMsQ0FBQ1osT0FBTyxDQUFDYSxtQkFBbUIsaUJBQUksSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUE7VUFBTUosU0FBUyxFQUFDLGdCQUFnQjtVQUFBQyxRQUFBLEVBQUM7UUFBTyxDQUFNLENBQUM7TUFBQSxDQUM1RSxDQUFDLGVBQ1AsSUFBQWYsV0FBQSxDQUFBa0IsR0FBQTtRQUFRQyxJQUFJLEVBQUMsUUFBUTtRQUFDTCxTQUFTLEVBQUMsYUFBYTtRQUFDTSxPQUFPLEVBQUViLE9BQVE7UUFBQVEsUUFBQSxFQUFDO01BRWhFLENBQVEsQ0FBQztJQUFBLENBQ0gsQ0FBQyxlQUNULElBQUFmLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ3BCLE1BQUEsQ0FBQXVCLFVBQVU7TUFBQ0MsS0FBSyxFQUFFbEIsT0FBTyxDQUFDbUIsWUFBYTtNQUFDbEIsUUFBUSxFQUFFQSxRQUFTO01BQUNHLFVBQVUsRUFBRUE7SUFBVyxDQUFFLENBQUM7RUFBQSxDQUNoRixDQUFDO0FBRWQ7QUFBQ1AsRUFBQSxDQXBCUUUsV0FBVztBQUFBcUIsRUFBQSxHQUFYckIsV0FBVztBQUFBLElBQUFzQixRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQXNCTHhCLFdBQVc7QUFBQSxJQUFBcUIsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}