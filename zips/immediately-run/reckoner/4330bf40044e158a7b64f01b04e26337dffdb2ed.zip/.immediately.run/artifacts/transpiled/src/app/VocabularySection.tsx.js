var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _vocabulary = require("./vocabulary.ts");
require("./workbook-panel.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The vocabulary section (DOCUMENT_NAVIGATOR_SPEC Part A §1) — panel chrome answering
// "what components exist, and what can I use as an input knob?". Everything rendered is
// derived from the closed catalog by `vocabulary()`; this file is presentation plus a
// filter and a copy affordance. Each entry collapses (the large-catalog + mobile
// pattern the author's-view indexes use) and carries a snippet the suite has already
// proven parses and validates (G-DN-A3), so the copy button hands over something usable
// rather than an example that errors on paste.
const FILTERS = [{
  value: undefined,
  label: 'all'
}, {
  value: 'widgets',
  label: 'input knobs'
}, {
  value: 'components',
  label: 'display'
}];
function attrLine(a) {
  const req = a.required ? ' · required' : '';
  const values = a.values !== undefined && a.values.length > 0 ? ` · ${a.values.join(' | ')}` : '';
  const variant = a.variant !== undefined ? ` · when kind="${a.variant}"` : '';
  return `${a.name} · ${a.type}${req}${values}${variant}`;
}
function VocabularySection() {
  _s();
  const [filter, setFilter] = (0, _react.useState)(undefined);
  const [copied, setCopied] = (0, _react.useState)(null);
  const [copyFailed, setCopyFailed] = (0, _react.useState)(null);
  const entries = (0, _vocabulary.vocabulary)(filter);

  // A refused clipboard write must not be silent (WCAG 3.3.1 / R-IX-3's named-failure
  // face): the rejection renders a visible line by the entry's control naming the
  // manual fallback — the snippet stays selectable text either way. Keyed by entry so
  // the line lands next to the control that failed, nowhere else.
  const copy = (name, snippet) => {
    setCopyFailed(null);
    try {
      void navigator.clipboard?.writeText(snippet).then(() => {
        setCopied(name);
        setTimeout(() => setCopied(null), 1500);
      }).catch(() => {
        setCopyFailed(name);
      });
    } catch {
      /* clipboard can be absent in the sandboxed iframe — name it, don't swallow it */
      setCopyFailed(name);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "rk-wb-sheet rk-vocab",
    "aria-label": "Vocabulary",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
      children: "vocabulary"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wb-note",
      children: "the components a template can use \u2014 copy a snippet, paste it into the template file."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-wi-actions",
      role: "group",
      "aria-label": "Vocabulary filter",
      children: FILTERS.map(f => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: `rk-wb-close ${filter === f.value ? 'rk-vocab-filter--on' : ''}`,
        onClick: () => setFilter(f.value),
        children: f.label
      }, f.label))
    }), entries.map(entry => /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
      className: "rk-refl-sheet rk-vocab-entry",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("summary", {
        className: "rk-refl-sheet-name",
        children: [entry.name, entry.isWidget && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-scratch-tag",
          children: "input knob"
        }), entry.isContainer && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-scratch-tag",
          children: "container"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-vocab-attrs",
        children: [entry.attributes.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-plain",
          children: "no attributes"
        }), entry.attributes.map(a => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "rk-refl-plain",
          children: attrLine(a)
        }, `${a.variant ?? ''}${a.name}`))]
      }), entry.snippet !== null ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
          className: "rk-refl-formula",
          children: entry.snippet
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "rk-wi-actions",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "rk-wb-close",
            onClick: () => copy(entry.name, entry.snippet),
            children: copied === entry.name ? 'Copied' : 'Copy'
          }), copyFailed === entry.name && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rk-copy-failed",
            role: "status",
            children: "Copy failed \u2014 select the text and copy manually"
          })]
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-wb-note",
        children: entry.snippetNote ?? 'no snippet available.'
      })]
    }, entry.name))]
  });
}
_s(VocabularySection, "8H6MHWeeZB0diEfGbbdLZfMNQhM=");
_c = VocabularySection;
var _default = exports.default = VocabularySection;
var _c;
$RefreshReg$(_c, "VocabularySection");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZvY2FidWxhcnkiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiRklMVEVSUyIsInZhbHVlIiwidW5kZWZpbmVkIiwibGFiZWwiLCJhdHRyTGluZSIsImEiLCJyZXEiLCJyZXF1aXJlZCIsInZhbHVlcyIsImxlbmd0aCIsImpvaW4iLCJ2YXJpYW50IiwibmFtZSIsInR5cGUiLCJWb2NhYnVsYXJ5U2VjdGlvbiIsImZpbHRlciIsInNldEZpbHRlciIsInVzZVN0YXRlIiwiY29waWVkIiwic2V0Q29waWVkIiwiY29weUZhaWxlZCIsInNldENvcHlGYWlsZWQiLCJlbnRyaWVzIiwidm9jYWJ1bGFyeSIsImNvcHkiLCJzbmlwcGV0IiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwidGhlbiIsInNldFRpbWVvdXQiLCJjYXRjaCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInJvbGUiLCJtYXAiLCJmIiwib25DbGljayIsImVudHJ5IiwiaXNXaWRnZXQiLCJpc0NvbnRhaW5lciIsImF0dHJpYnV0ZXMiLCJGcmFnbWVudCIsInNuaXBwZXROb3RlIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVm9jYWJ1bGFyeVNlY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSB2b2NhYnVsYXJ5IHNlY3Rpb24gKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIFBhcnQgQSDCpzEpIOKAlCBwYW5lbCBjaHJvbWUgYW5zd2VyaW5nXG4vLyBcIndoYXQgY29tcG9uZW50cyBleGlzdCwgYW5kIHdoYXQgY2FuIEkgdXNlIGFzIGFuIGlucHV0IGtub2I/XCIuIEV2ZXJ5dGhpbmcgcmVuZGVyZWQgaXNcbi8vIGRlcml2ZWQgZnJvbSB0aGUgY2xvc2VkIGNhdGFsb2cgYnkgYHZvY2FidWxhcnkoKWA7IHRoaXMgZmlsZSBpcyBwcmVzZW50YXRpb24gcGx1cyBhXG4vLyBmaWx0ZXIgYW5kIGEgY29weSBhZmZvcmRhbmNlLiBFYWNoIGVudHJ5IGNvbGxhcHNlcyAodGhlIGxhcmdlLWNhdGFsb2cgKyBtb2JpbGVcbi8vIHBhdHRlcm4gdGhlIGF1dGhvcidzLXZpZXcgaW5kZXhlcyB1c2UpIGFuZCBjYXJyaWVzIGEgc25pcHBldCB0aGUgc3VpdGUgaGFzIGFscmVhZHlcbi8vIHByb3ZlbiBwYXJzZXMgYW5kIHZhbGlkYXRlcyAoRy1ETi1BMyksIHNvIHRoZSBjb3B5IGJ1dHRvbiBoYW5kcyBvdmVyIHNvbWV0aGluZyB1c2FibGVcbi8vIHJhdGhlciB0aGFuIGFuIGV4YW1wbGUgdGhhdCBlcnJvcnMgb24gcGFzdGUuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHZvY2FidWxhcnkgfSBmcm9tICcuL3ZvY2FidWxhcnkudHMnO1xuaW1wb3J0IHR5cGUgeyBWb2NhYkF0dHJpYnV0ZSwgVm9jYWJGaWx0ZXIgfSBmcm9tICcuL3ZvY2FidWxhcnkudHMnO1xuaW1wb3J0ICcuL3dvcmtib29rLXBhbmVsLmNzcyc7XG5cbmNvbnN0IEZJTFRFUlM6IHsgdmFsdWU6IFZvY2FiRmlsdGVyOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcbiAgeyB2YWx1ZTogdW5kZWZpbmVkLCBsYWJlbDogJ2FsbCcgfSxcbiAgeyB2YWx1ZTogJ3dpZGdldHMnLCBsYWJlbDogJ2lucHV0IGtub2JzJyB9LFxuICB7IHZhbHVlOiAnY29tcG9uZW50cycsIGxhYmVsOiAnZGlzcGxheScgfSxcbl07XG5cbmZ1bmN0aW9uIGF0dHJMaW5lKGE6IFZvY2FiQXR0cmlidXRlKTogc3RyaW5nIHtcbiAgY29uc3QgcmVxID0gYS5yZXF1aXJlZCA/ICcgwrcgcmVxdWlyZWQnIDogJyc7XG4gIGNvbnN0IHZhbHVlcyA9IGEudmFsdWVzICE9PSB1bmRlZmluZWQgJiYgYS52YWx1ZXMubGVuZ3RoID4gMCA/IGAgwrcgJHthLnZhbHVlcy5qb2luKCcgfCAnKX1gIDogJyc7XG4gIGNvbnN0IHZhcmlhbnQgPSBhLnZhcmlhbnQgIT09IHVuZGVmaW5lZCA/IGAgwrcgd2hlbiBraW5kPVwiJHthLnZhcmlhbnR9XCJgIDogJyc7XG4gIHJldHVybiBgJHthLm5hbWV9IMK3ICR7YS50eXBlfSR7cmVxfSR7dmFsdWVzfSR7dmFyaWFudH1gO1xufVxuXG5mdW5jdGlvbiBWb2NhYnVsYXJ5U2VjdGlvbigpIHtcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPFZvY2FiRmlsdGVyPih1bmRlZmluZWQpO1xuICBjb25zdCBbY29waWVkLCBzZXRDb3BpZWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjb3B5RmFpbGVkLCBzZXRDb3B5RmFpbGVkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBlbnRyaWVzID0gdm9jYWJ1bGFyeShmaWx0ZXIpO1xuXG4gIC8vIEEgcmVmdXNlZCBjbGlwYm9hcmQgd3JpdGUgbXVzdCBub3QgYmUgc2lsZW50IChXQ0FHIDMuMy4xIC8gUi1JWC0zJ3MgbmFtZWQtZmFpbHVyZVxuICAvLyBmYWNlKTogdGhlIHJlamVjdGlvbiByZW5kZXJzIGEgdmlzaWJsZSBsaW5lIGJ5IHRoZSBlbnRyeSdzIGNvbnRyb2wgbmFtaW5nIHRoZVxuICAvLyBtYW51YWwgZmFsbGJhY2sg4oCUIHRoZSBzbmlwcGV0IHN0YXlzIHNlbGVjdGFibGUgdGV4dCBlaXRoZXIgd2F5LiBLZXllZCBieSBlbnRyeSBzb1xuICAvLyB0aGUgbGluZSBsYW5kcyBuZXh0IHRvIHRoZSBjb250cm9sIHRoYXQgZmFpbGVkLCBub3doZXJlIGVsc2UuXG4gIGNvbnN0IGNvcHkgPSAobmFtZTogc3RyaW5nLCBzbmlwcGV0OiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICBzZXRDb3B5RmFpbGVkKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICB2b2lkIG5hdmlnYXRvci5jbGlwYm9hcmRcbiAgICAgICAgPy53cml0ZVRleHQoc25pcHBldClcbiAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIHNldENvcGllZChuYW1lKTtcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZChudWxsKSwgMTUwMCk7XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgc2V0Q29weUZhaWxlZChuYW1lKTtcbiAgICAgICAgfSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiBjbGlwYm9hcmQgY2FuIGJlIGFic2VudCBpbiB0aGUgc2FuZGJveGVkIGlmcmFtZSDigJQgbmFtZSBpdCwgZG9uJ3Qgc3dhbGxvdyBpdCAqL1xuICAgICAgc2V0Q29weUZhaWxlZChuYW1lKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyay13Yi1zaGVldCByay12b2NhYlwiIGFyaWEtbGFiZWw9XCJWb2NhYnVsYXJ5XCI+XG4gICAgICA8aDM+dm9jYWJ1bGFyeTwvaDM+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXdiLW5vdGVcIj5cbiAgICAgICAgdGhlIGNvbXBvbmVudHMgYSB0ZW1wbGF0ZSBjYW4gdXNlIOKAlCBjb3B5IGEgc25pcHBldCwgcGFzdGUgaXQgaW50byB0aGUgdGVtcGxhdGUgZmlsZS5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13aS1hY3Rpb25zXCIgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlZvY2FidWxhcnkgZmlsdGVyXCI+XG4gICAgICAgIHtGSUxURVJTLm1hcCgoZikgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17Zi5sYWJlbH1cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmstd2ItY2xvc2UgJHtmaWx0ZXIgPT09IGYudmFsdWUgPyAncmstdm9jYWItZmlsdGVyLS1vbicgOiAnJ31gfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKGYudmFsdWUpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtmLmxhYmVsfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZW50cmllcy5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgIDxkZXRhaWxzIGtleT17ZW50cnkubmFtZX0gY2xhc3NOYW1lPVwicmstcmVmbC1zaGVldCByay12b2NhYi1lbnRyeVwiPlxuICAgICAgICAgIDxzdW1tYXJ5IGNsYXNzTmFtZT1cInJrLXJlZmwtc2hlZXQtbmFtZVwiPlxuICAgICAgICAgICAge2VudHJ5Lm5hbWV9XG4gICAgICAgICAgICB7ZW50cnkuaXNXaWRnZXQgJiYgPHNwYW4gY2xhc3NOYW1lPVwicmstc2NyYXRjaC10YWdcIj5pbnB1dCBrbm9iPC9zcGFuPn1cbiAgICAgICAgICAgIHtlbnRyeS5pc0NvbnRhaW5lciAmJiA8c3BhbiBjbGFzc05hbWU9XCJyay1zY3JhdGNoLXRhZ1wiPmNvbnRhaW5lcjwvc3Bhbj59XG4gICAgICAgICAgPC9zdW1tYXJ5PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay12b2NhYi1hdHRyc1wiPlxuICAgICAgICAgICAge2VudHJ5LmF0dHJpYnV0ZXMubGVuZ3RoID09PSAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwtcGxhaW5cIj5ubyBhdHRyaWJ1dGVzPC9zcGFuPn1cbiAgICAgICAgICAgIHtlbnRyeS5hdHRyaWJ1dGVzLm1hcCgoYSkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17YCR7YS52YXJpYW50ID8/ICcnfSR7YS5uYW1lfWB9IGNsYXNzTmFtZT1cInJrLXJlZmwtcGxhaW5cIj5cbiAgICAgICAgICAgICAgICB7YXR0ckxpbmUoYSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7ZW50cnkuc25pcHBldCAhPT0gbnVsbCA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwicmstcmVmbC1mb3JtdWxhXCI+e2VudHJ5LnNuaXBwZXR9PC9wcmU+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstd2ktYWN0aW9uc1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJrLXdiLWNsb3NlXCIgb25DbGljaz17KCkgPT4gY29weShlbnRyeS5uYW1lLCBlbnRyeS5zbmlwcGV0ISl9PlxuICAgICAgICAgICAgICAgICAge2NvcGllZCA9PT0gZW50cnkubmFtZSA/ICdDb3BpZWQnIDogJ0NvcHknfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIHtjb3B5RmFpbGVkID09PSBlbnRyeS5uYW1lICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLWNvcHktZmFpbGVkXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICBDb3B5IGZhaWxlZCDigJQgc2VsZWN0IHRoZSB0ZXh0IGFuZCBjb3B5IG1hbnVhbGx5XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay13Yi1ub3RlXCI+e2VudHJ5LnNuaXBwZXROb3RlID8/ICdubyBzbmlwcGV0IGF2YWlsYWJsZS4nfTwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGV0YWlscz5cbiAgICAgICkpfVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgVm9jYWJ1bGFyeVNlY3Rpb247XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBT0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRUFBLE9BQUE7QUFBOEIsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBVjlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUEsTUFBTUMsT0FBZ0QsR0FBRyxDQUN2RDtFQUFFQyxLQUFLLEVBQUVDLFNBQVM7RUFBRUMsS0FBSyxFQUFFO0FBQU0sQ0FBQyxFQUNsQztFQUFFRixLQUFLLEVBQUUsU0FBUztFQUFFRSxLQUFLLEVBQUU7QUFBYyxDQUFDLEVBQzFDO0VBQUVGLEtBQUssRUFBRSxZQUFZO0VBQUVFLEtBQUssRUFBRTtBQUFVLENBQUMsQ0FDMUM7QUFFRCxTQUFTQyxRQUFRQSxDQUFDQyxDQUFpQixFQUFVO0VBQzNDLE1BQU1DLEdBQUcsR0FBR0QsQ0FBQyxDQUFDRSxRQUFRLEdBQUcsYUFBYSxHQUFHLEVBQUU7RUFDM0MsTUFBTUMsTUFBTSxHQUFHSCxDQUFDLENBQUNHLE1BQU0sS0FBS04sU0FBUyxJQUFJRyxDQUFDLENBQUNHLE1BQU0sQ0FBQ0MsTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNSixDQUFDLENBQUNHLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEdBQUcsRUFBRTtFQUNoRyxNQUFNQyxPQUFPLEdBQUdOLENBQUMsQ0FBQ00sT0FBTyxLQUFLVCxTQUFTLEdBQUcsaUJBQWlCRyxDQUFDLENBQUNNLE9BQU8sR0FBRyxHQUFHLEVBQUU7RUFDNUUsT0FBTyxHQUFHTixDQUFDLENBQUNPLElBQUksTUFBTVAsQ0FBQyxDQUFDUSxJQUFJLEdBQUdQLEdBQUcsR0FBR0UsTUFBTSxHQUFHRyxPQUFPLEVBQUU7QUFDekQ7QUFFQSxTQUFTRyxpQkFBaUJBLENBQUEsRUFBRztFQUFBaEIsRUFBQTtFQUMzQixNQUFNLENBQUNpQixNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBY2YsU0FBUyxDQUFDO0VBQzVELE1BQU0sQ0FBQ2dCLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDekQsTUFBTSxDQUFDRyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ2pFLE1BQU1LLE9BQU8sR0FBRyxJQUFBQyxzQkFBVSxFQUFDUixNQUFNLENBQUM7O0VBRWxDO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTVMsSUFBSSxHQUFHQSxDQUFDWixJQUFZLEVBQUVhLE9BQWUsS0FBVztJQUNwREosYUFBYSxDQUFDLElBQUksQ0FBQztJQUNuQixJQUFJO01BQ0YsS0FBS0ssU0FBUyxDQUFDQyxTQUFTLEVBQ3BCQyxTQUFTLENBQUNILE9BQU8sQ0FBQyxDQUNuQkksSUFBSSxDQUFDLE1BQU07UUFDVlYsU0FBUyxDQUFDUCxJQUFJLENBQUM7UUFDZmtCLFVBQVUsQ0FBQyxNQUFNWCxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDO01BQ3pDLENBQUMsQ0FBQyxDQUNEWSxLQUFLLENBQUMsTUFBTTtRQUNYVixhQUFhLENBQUNULElBQUksQ0FBQztNQUNyQixDQUFDLENBQUM7SUFDTixDQUFDLENBQUMsTUFBTTtNQUNOO01BQ0FTLGFBQWEsQ0FBQ1QsSUFBSSxDQUFDO0lBQ3JCO0VBQ0YsQ0FBQztFQUVELG9CQUNFLElBQUFmLFdBQUEsQ0FBQW1DLElBQUE7SUFBU0MsU0FBUyxFQUFDLHNCQUFzQjtJQUFDLGNBQVcsWUFBWTtJQUFBQyxRQUFBLGdCQUMvRCxJQUFBckMsV0FBQSxDQUFBc0MsR0FBQTtNQUFBRCxRQUFBLEVBQUk7SUFBVSxDQUFJLENBQUMsZUFDbkIsSUFBQXJDLFdBQUEsQ0FBQXNDLEdBQUE7TUFBS0YsU0FBUyxFQUFDLFlBQVk7TUFBQUMsUUFBQSxFQUFDO0lBRTVCLENBQUssQ0FBQyxlQUNOLElBQUFyQyxXQUFBLENBQUFzQyxHQUFBO01BQUtGLFNBQVMsRUFBQyxlQUFlO01BQUNHLElBQUksRUFBQyxPQUFPO01BQUMsY0FBVyxtQkFBbUI7TUFBQUYsUUFBQSxFQUN2RWxDLE9BQU8sQ0FBQ3FDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDYixJQUFBekMsV0FBQSxDQUFBc0MsR0FBQTtRQUVFdEIsSUFBSSxFQUFDLFFBQVE7UUFDYm9CLFNBQVMsRUFBRSxlQUFlbEIsTUFBTSxLQUFLdUIsQ0FBQyxDQUFDckMsS0FBSyxHQUFHLHFCQUFxQixHQUFHLEVBQUUsRUFBRztRQUM1RXNDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdkIsU0FBUyxDQUFDc0IsQ0FBQyxDQUFDckMsS0FBSyxDQUFFO1FBQUFpQyxRQUFBLEVBRWpDSSxDQUFDLENBQUNuQztNQUFLLEdBTEhtQyxDQUFDLENBQUNuQyxLQU1ELENBQ1Q7SUFBQyxDQUNDLENBQUMsRUFFTG1CLE9BQU8sQ0FBQ2UsR0FBRyxDQUFFRyxLQUFLLGlCQUNqQixJQUFBM0MsV0FBQSxDQUFBbUMsSUFBQTtNQUEwQkMsU0FBUyxFQUFDLDhCQUE4QjtNQUFBQyxRQUFBLGdCQUNoRSxJQUFBckMsV0FBQSxDQUFBbUMsSUFBQTtRQUFTQyxTQUFTLEVBQUMsb0JBQW9CO1FBQUFDLFFBQUEsR0FDcENNLEtBQUssQ0FBQzVCLElBQUksRUFDVjRCLEtBQUssQ0FBQ0MsUUFBUSxpQkFBSSxJQUFBNUMsV0FBQSxDQUFBc0MsR0FBQTtVQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1VBQUFDLFFBQUEsRUFBQztRQUFVLENBQU0sQ0FBQyxFQUNwRU0sS0FBSyxDQUFDRSxXQUFXLGlCQUFJLElBQUE3QyxXQUFBLENBQUFzQyxHQUFBO1VBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUMsUUFBQSxFQUFDO1FBQVMsQ0FBTSxDQUFDO01BQUEsQ0FDaEUsQ0FBQyxlQUVWLElBQUFyQyxXQUFBLENBQUFtQyxJQUFBO1FBQUtDLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUMsUUFBQSxHQUM1Qk0sS0FBSyxDQUFDRyxVQUFVLENBQUNsQyxNQUFNLEtBQUssQ0FBQyxpQkFBSSxJQUFBWixXQUFBLENBQUFzQyxHQUFBO1VBQU1GLFNBQVMsRUFBQyxlQUFlO1VBQUFDLFFBQUEsRUFBQztRQUFhLENBQU0sQ0FBQyxFQUNyRk0sS0FBSyxDQUFDRyxVQUFVLENBQUNOLEdBQUcsQ0FBRWhDLENBQUMsaUJBQ3RCLElBQUFSLFdBQUEsQ0FBQXNDLEdBQUE7VUFBeUNGLFNBQVMsRUFBQyxlQUFlO1VBQUFDLFFBQUEsRUFDL0Q5QixRQUFRLENBQUNDLENBQUM7UUFBQyxHQURKLEdBQUdBLENBQUMsQ0FBQ00sT0FBTyxJQUFJLEVBQUUsR0FBR04sQ0FBQyxDQUFDTyxJQUFJLEVBRWhDLENBQ04sQ0FBQztNQUFBLENBQ0MsQ0FBQyxFQUVMNEIsS0FBSyxDQUFDZixPQUFPLEtBQUssSUFBSSxnQkFDckIsSUFBQTVCLFdBQUEsQ0FBQW1DLElBQUEsRUFBQW5DLFdBQUEsQ0FBQStDLFFBQUE7UUFBQVYsUUFBQSxnQkFDRSxJQUFBckMsV0FBQSxDQUFBc0MsR0FBQTtVQUFLRixTQUFTLEVBQUMsaUJBQWlCO1VBQUFDLFFBQUEsRUFBRU0sS0FBSyxDQUFDZjtRQUFPLENBQU0sQ0FBQyxlQUN0RCxJQUFBNUIsV0FBQSxDQUFBbUMsSUFBQTtVQUFLQyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLGdCQUM1QixJQUFBckMsV0FBQSxDQUFBc0MsR0FBQTtZQUFRdEIsSUFBSSxFQUFDLFFBQVE7WUFBQ29CLFNBQVMsRUFBQyxhQUFhO1lBQUNNLE9BQU8sRUFBRUEsQ0FBQSxLQUFNZixJQUFJLENBQUNnQixLQUFLLENBQUM1QixJQUFJLEVBQUU0QixLQUFLLENBQUNmLE9BQVEsQ0FBRTtZQUFBUyxRQUFBLEVBQzNGaEIsTUFBTSxLQUFLc0IsS0FBSyxDQUFDNUIsSUFBSSxHQUFHLFFBQVEsR0FBRztVQUFNLENBQ3BDLENBQUMsRUFDUlEsVUFBVSxLQUFLb0IsS0FBSyxDQUFDNUIsSUFBSSxpQkFDeEIsSUFBQWYsV0FBQSxDQUFBc0MsR0FBQTtZQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1lBQUNHLElBQUksRUFBQyxRQUFRO1lBQUFGLFFBQUEsRUFBQztVQUUvQyxDQUFNLENBQ1A7UUFBQSxDQUNFLENBQUM7TUFBQSxDQUNOLENBQUMsZ0JBRUgsSUFBQXJDLFdBQUEsQ0FBQXNDLEdBQUE7UUFBS0YsU0FBUyxFQUFDLFlBQVk7UUFBQUMsUUFBQSxFQUFFTSxLQUFLLENBQUNLLFdBQVcsSUFBSTtNQUF1QixDQUFNLENBQ2hGO0lBQUEsR0FoQ1dMLEtBQUssQ0FBQzVCLElBaUNYLENBQ1YsQ0FBQztFQUFBLENBQ0ssQ0FBQztBQUVkO0FBQUNkLEVBQUEsQ0FyRlFnQixpQkFBaUI7QUFBQWdDLEVBQUEsR0FBakJoQyxpQkFBaUI7QUFBQSxJQUFBaUMsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0F1RlhuQyxpQkFBaUI7QUFBQSxJQUFBZ0MsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}