"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SUBJECT_INPUT = void 0;
exports.buildGraph = buildGraph;
exports.declaredWindows = declaredWindows;
exports.resolversFor = resolversFor;
var _resolve = require("./resolve.ts");
// Build the dependency graph from a workbook of registered cells (ARCHITECTURE_PLAN §4.2,
// F1/C-4). Each cell/test becomes a node; its declared inputs become internal edges (to
// other cells) or external inputs (feeds/fixtures/static/params). A `<worksheet>.*`
// wildcard is expanded to every cell of that worksheet at build time, so the conservative
// dependency set is **statically enumerable** — the invariant the SCC cycle check and the
// deadlock-freedom argument rest on.
//
// Two enumerability invariants are enforced fail-closed (C-4): (a) a worksheet may not be
// named a reserved namespace (`params`/`feeds`/…) — that would let a cell masquerade as a
// leaf input and hide a producer edge from the static SCC; (b) namespace tokens come from
// `parseInput` and are already compile-time literals, so nothing here resolves a wildcard
// from a runtime value.

const RESERVED = new Set(['feeds', 'fixtures', 'static', 'params']);

/** The reserved local-input name under which a test node receives its subject's value. */
const SUBJECT_INPUT = exports.SUBJECT_INPUT = '$subject';
function buildGraph(workbook) {
  const diagnostics = [];
  const worksheets = new Map();
  const defsById = new Map();

  // Pass 1 — enumerate nodes and per-worksheet cell lists.
  for (const [worksheet, cells] of Object.entries(workbook)) {
    if (RESERVED.has(worksheet)) {
      diagnostics.push({
        severity: 'error',
        id: worksheet,
        message: `worksheet "${worksheet}" collides with a reserved namespace; rename it.`
      });
    }
    const names = [];
    for (const [cell, def] of Object.entries(cells)) {
      const id = `${worksheet}.${cell}`;
      names.push(id);
      defsById.set(id, {
        worksheet,
        cell,
        def
      });
    }
    worksheets.set(worksheet, names);
  }
  const has = id => defsById.has(id);
  const nodes = new Map();
  const externalInputs = new Set();

  // Pass 2 — classify each node's inputs into internal edges + external inputs.
  for (const [id, {
    worksheet,
    cell,
    def
  }] of defsById) {
    const deps = new Set();
    const externals = new Set();
    const resolvers = [];
    for (const [name, spec] of Object.entries(def.inputs)) {
      classifyInput(name, spec, {
        id,
        deps,
        externals,
        resolvers,
        worksheets,
        has,
        diagnostics
      });
    }

    // A test also depends on its subject cell (so it re-runs when the subject changes).
    if (def.kind === 'test') {
      const subject = def.subject;
      if (has(subject)) {
        deps.add(subject);
        resolvers.push({
          name: SUBJECT_INPUT,
          kind: 'cell',
          nodeId: subject
        });
      } else {
        diagnostics.push({
          severity: 'error',
          id,
          message: `test subject "${subject}" does not exist.`
        });
      }
    }
    for (const key of externals) externalInputs.add(key);
    nodes.set(id, {
      id,
      worksheet,
      cell,
      kind: def.kind,
      def,
      deps: [...deps],
      externals: [...externals],
      resolvers
    });
  }
  return {
    nodes,
    worksheets,
    externalInputs,
    diagnostics
  };
}

/**
 * Every windowed input declared in the workbook (`{ feed, window }` sites), for the
 * edit-time buffer-coverage diagnostic (`checkBufferCoversWindows`). Structurally the
 * feed layer's `WindowDecl` — declared here so the engine never imports the feed layer.
 */
function declaredWindows(graph) {
  const out = [];
  for (const node of graph.nodes.values()) {
    for (const r of node.resolvers) {
      if (r.kind === 'windowed-feed') out.push({
        feed: r.feed,
        window: r.window,
        site: node.id
      });
    }
  }
  return out;
}
function classifyInput(name, spec, ctx) {
  if (spec.feed !== undefined) {
    // The windowed-feed object form: the cell reads the feed's *retained rows* (not the
    // snapshot), so its external key is the buffer external the feed runtime publishes
    // alongside `feeds.<name>` — that key changing is what dirties the cell. The resolver
    // also reads the clock (`params.now`, falling back to the newest retained event time),
    // so a windowed input structurally depends on `params.now` too: a clock-only update must
    // advance the window. (Unconditional — whether the app supplies `params.now` is a
    // runtime fact the graph cannot know; an external that never changes never dirties.)
    ctx.externals.add(`${_resolve.FEED_BUFFER_PREFIX}${spec.feed}`);
    ctx.externals.add('params.now');
    ctx.resolvers.push({
      name,
      kind: 'windowed-feed',
      feed: spec.feed,
      window: spec.window,
      by: spec.by
    });
    return;
  }
  if (spec.namespace !== 'worksheet') {
    ctx.externals.add(spec.dependency);
    ctx.resolvers.push({
      name,
      kind: 'external',
      key: spec.dependency
    });
    return;
  }
  const worksheet = spec.worksheet;
  if (spec.wildcard) {
    const cells = ctx.worksheets.get(worksheet);
    if (cells === undefined) {
      ctx.diagnostics.push({
        severity: 'error',
        id: ctx.id,
        message: `input "${name}" references unknown worksheet "${worksheet}".`
      });
      ctx.resolvers.push({
        name,
        kind: 'wildcard',
        worksheet
      });
      return;
    }
    for (const dep of cells) if (dep !== ctx.id) ctx.deps.add(dep);
    ctx.resolvers.push({
      name,
      kind: 'wildcard',
      worksheet
    });
    return;
  }
  const nodeId = `${worksheet}.${spec.cell}`;
  if (!ctx.has(nodeId)) {
    ctx.diagnostics.push({
      severity: 'error',
      id: ctx.id,
      message: `input "${name}" references unknown cell "${nodeId}".`
    });
  } else {
    ctx.deps.add(nodeId);
  }
  ctx.resolvers.push({
    name,
    kind: 'cell',
    nodeId
  });
}

/**
 * Resolvers for a declared-inputs map held by a *non-graph* consumer — the test runner's
 * fixture substitution (a test's declared inputs resolve against the same published state
 * a cell's do). Unresolvable references come back as diagnostics for the caller to surface;
 * they are the same errors `buildGraph` would emit for a cell. `graph` is the structural
 * minimum the classifier needs (an id→node map for cell-existence checks + the worksheet
 * lists), so the async engine can pass its descriptor maps directly.
 */
function resolversFor(inputs, graph) {
  const diagnostics = [];
  const resolvers = [];
  for (const [name, spec] of Object.entries(inputs)) {
    classifyInput(name, spec, {
      id: '(test inputs)',
      deps: new Set(),
      externals: new Set(),
      resolvers,
      worksheets: graph.worksheets,
      has: id => graph.nodes.has(id),
      diagnostics
    });
  }
  return {
    resolvers,
    diagnostics: diagnostics.map(d => d.message)
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVzb2x2ZSIsInJlcXVpcmUiLCJSRVNFUlZFRCIsIlNldCIsIlNVQkpFQ1RfSU5QVVQiLCJleHBvcnRzIiwiYnVpbGRHcmFwaCIsIndvcmtib29rIiwiZGlhZ25vc3RpY3MiLCJ3b3Jrc2hlZXRzIiwiTWFwIiwiZGVmc0J5SWQiLCJ3b3Jrc2hlZXQiLCJjZWxscyIsIk9iamVjdCIsImVudHJpZXMiLCJoYXMiLCJwdXNoIiwic2V2ZXJpdHkiLCJpZCIsIm1lc3NhZ2UiLCJuYW1lcyIsImNlbGwiLCJkZWYiLCJzZXQiLCJub2RlcyIsImV4dGVybmFsSW5wdXRzIiwiZGVwcyIsImV4dGVybmFscyIsInJlc29sdmVycyIsIm5hbWUiLCJzcGVjIiwiaW5wdXRzIiwiY2xhc3NpZnlJbnB1dCIsImtpbmQiLCJzdWJqZWN0IiwiYWRkIiwibm9kZUlkIiwia2V5IiwiZGVjbGFyZWRXaW5kb3dzIiwiZ3JhcGgiLCJvdXQiLCJub2RlIiwidmFsdWVzIiwiciIsImZlZWQiLCJ3aW5kb3ciLCJzaXRlIiwiY3R4IiwidW5kZWZpbmVkIiwiRkVFRF9CVUZGRVJfUFJFRklYIiwiYnkiLCJuYW1lc3BhY2UiLCJkZXBlbmRlbmN5Iiwid2lsZGNhcmQiLCJnZXQiLCJkZXAiLCJyZXNvbHZlcnNGb3IiLCJtYXAiLCJkIl0sInNvdXJjZXMiOlsiZ3JhcGgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQnVpbGQgdGhlIGRlcGVuZGVuY3kgZ3JhcGggZnJvbSBhIHdvcmtib29rIG9mIHJlZ2lzdGVyZWQgY2VsbHMgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnNC4yLFxuLy8gRjEvQy00KS4gRWFjaCBjZWxsL3Rlc3QgYmVjb21lcyBhIG5vZGU7IGl0cyBkZWNsYXJlZCBpbnB1dHMgYmVjb21lIGludGVybmFsIGVkZ2VzICh0b1xuLy8gb3RoZXIgY2VsbHMpIG9yIGV4dGVybmFsIGlucHV0cyAoZmVlZHMvZml4dHVyZXMvc3RhdGljL3BhcmFtcykuIEEgYDx3b3Jrc2hlZXQ+LipgXG4vLyB3aWxkY2FyZCBpcyBleHBhbmRlZCB0byBldmVyeSBjZWxsIG9mIHRoYXQgd29ya3NoZWV0IGF0IGJ1aWxkIHRpbWUsIHNvIHRoZSBjb25zZXJ2YXRpdmVcbi8vIGRlcGVuZGVuY3kgc2V0IGlzICoqc3RhdGljYWxseSBlbnVtZXJhYmxlKiog4oCUIHRoZSBpbnZhcmlhbnQgdGhlIFNDQyBjeWNsZSBjaGVjayBhbmQgdGhlXG4vLyBkZWFkbG9jay1mcmVlZG9tIGFyZ3VtZW50IHJlc3Qgb24uXG4vL1xuLy8gVHdvIGVudW1lcmFiaWxpdHkgaW52YXJpYW50cyBhcmUgZW5mb3JjZWQgZmFpbC1jbG9zZWQgKEMtNCk6IChhKSBhIHdvcmtzaGVldCBtYXkgbm90IGJlXG4vLyBuYW1lZCBhIHJlc2VydmVkIG5hbWVzcGFjZSAoYHBhcmFtc2AvYGZlZWRzYC/igKYpIOKAlCB0aGF0IHdvdWxkIGxldCBhIGNlbGwgbWFzcXVlcmFkZSBhcyBhXG4vLyBsZWFmIGlucHV0IGFuZCBoaWRlIGEgcHJvZHVjZXIgZWRnZSBmcm9tIHRoZSBzdGF0aWMgU0NDOyAoYikgbmFtZXNwYWNlIHRva2VucyBjb21lIGZyb21cbi8vIGBwYXJzZUlucHV0YCBhbmQgYXJlIGFscmVhZHkgY29tcGlsZS10aW1lIGxpdGVyYWxzLCBzbyBub3RoaW5nIGhlcmUgcmVzb2x2ZXMgYSB3aWxkY2FyZFxuLy8gZnJvbSBhIHJ1bnRpbWUgdmFsdWUuXG5cbmltcG9ydCB0eXBlIHtcbiAgRGVwZW5kZW5jeUdyYXBoLFxuICBHcmFwaERpYWdub3N0aWMsXG4gIEdyYXBoTm9kZSxcbiAgSW5wdXRSZXNvbHZlcixcbiAgTm9kZURlZixcbiAgV29ya2Jvb2ssXG59IGZyb20gJy4vdHlwZXMudHMnO1xuaW1wb3J0IHR5cGUgeyBJbnB1dFNwZWMgfSBmcm9tICcuLi9zdGRsaWIvaW5wdXRzLnRzJztcbmltcG9ydCB7IEZFRURfQlVGRkVSX1BSRUZJWCB9IGZyb20gJy4vcmVzb2x2ZS50cyc7XG5cbmNvbnN0IFJFU0VSVkVEID0gbmV3IFNldChbJ2ZlZWRzJywgJ2ZpeHR1cmVzJywgJ3N0YXRpYycsICdwYXJhbXMnXSk7XG5cbi8qKiBUaGUgcmVzZXJ2ZWQgbG9jYWwtaW5wdXQgbmFtZSB1bmRlciB3aGljaCBhIHRlc3Qgbm9kZSByZWNlaXZlcyBpdHMgc3ViamVjdCdzIHZhbHVlLiAqL1xuZXhwb3J0IGNvbnN0IFNVQkpFQ1RfSU5QVVQgPSAnJHN1YmplY3QnO1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRHcmFwaCh3b3JrYm9vazogV29ya2Jvb2spOiBEZXBlbmRlbmN5R3JhcGgge1xuICBjb25zdCBkaWFnbm9zdGljczogR3JhcGhEaWFnbm9zdGljW10gPSBbXTtcbiAgY29uc3Qgd29ya3NoZWV0cyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmdbXT4oKTtcbiAgY29uc3QgZGVmc0J5SWQgPSBuZXcgTWFwPHN0cmluZywgeyB3b3Jrc2hlZXQ6IHN0cmluZzsgY2VsbDogc3RyaW5nOyBkZWY6IE5vZGVEZWYgfT4oKTtcblxuICAvLyBQYXNzIDEg4oCUIGVudW1lcmF0ZSBub2RlcyBhbmQgcGVyLXdvcmtzaGVldCBjZWxsIGxpc3RzLlxuICBmb3IgKGNvbnN0IFt3b3Jrc2hlZXQsIGNlbGxzXSBvZiBPYmplY3QuZW50cmllcyh3b3JrYm9vaykpIHtcbiAgICBpZiAoUkVTRVJWRUQuaGFzKHdvcmtzaGVldCkpIHtcbiAgICAgIGRpYWdub3N0aWNzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogJ2Vycm9yJyxcbiAgICAgICAgaWQ6IHdvcmtzaGVldCxcbiAgICAgICAgbWVzc2FnZTogYHdvcmtzaGVldCBcIiR7d29ya3NoZWV0fVwiIGNvbGxpZGVzIHdpdGggYSByZXNlcnZlZCBuYW1lc3BhY2U7IHJlbmFtZSBpdC5gLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IG5hbWVzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGZvciAoY29uc3QgW2NlbGwsIGRlZl0gb2YgT2JqZWN0LmVudHJpZXMoY2VsbHMpKSB7XG4gICAgICBjb25zdCBpZCA9IGAke3dvcmtzaGVldH0uJHtjZWxsfWA7XG4gICAgICBuYW1lcy5wdXNoKGlkKTtcbiAgICAgIGRlZnNCeUlkLnNldChpZCwgeyB3b3Jrc2hlZXQsIGNlbGwsIGRlZiB9KTtcbiAgICB9XG4gICAgd29ya3NoZWV0cy5zZXQod29ya3NoZWV0LCBuYW1lcyk7XG4gIH1cblxuICBjb25zdCBoYXMgPSAoaWQ6IHN0cmluZyk6IGJvb2xlYW4gPT4gZGVmc0J5SWQuaGFzKGlkKTtcbiAgY29uc3Qgbm9kZXMgPSBuZXcgTWFwPHN0cmluZywgR3JhcGhOb2RlPigpO1xuICBjb25zdCBleHRlcm5hbElucHV0cyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuXG4gIC8vIFBhc3MgMiDigJQgY2xhc3NpZnkgZWFjaCBub2RlJ3MgaW5wdXRzIGludG8gaW50ZXJuYWwgZWRnZXMgKyBleHRlcm5hbCBpbnB1dHMuXG4gIGZvciAoY29uc3QgW2lkLCB7IHdvcmtzaGVldCwgY2VsbCwgZGVmIH1dIG9mIGRlZnNCeUlkKSB7XG4gICAgY29uc3QgZGVwcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgIGNvbnN0IGV4dGVybmFscyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgIGNvbnN0IHJlc29sdmVyczogSW5wdXRSZXNvbHZlcltdID0gW107XG5cbiAgICBmb3IgKGNvbnN0IFtuYW1lLCBzcGVjXSBvZiBPYmplY3QuZW50cmllcyhkZWYuaW5wdXRzKSBhcyBbc3RyaW5nLCBJbnB1dFNwZWNdW10pIHtcbiAgICAgIGNsYXNzaWZ5SW5wdXQobmFtZSwgc3BlYywgeyBpZCwgZGVwcywgZXh0ZXJuYWxzLCByZXNvbHZlcnMsIHdvcmtzaGVldHMsIGhhcywgZGlhZ25vc3RpY3MgfSk7XG4gICAgfVxuXG4gICAgLy8gQSB0ZXN0IGFsc28gZGVwZW5kcyBvbiBpdHMgc3ViamVjdCBjZWxsIChzbyBpdCByZS1ydW5zIHdoZW4gdGhlIHN1YmplY3QgY2hhbmdlcykuXG4gICAgaWYgKGRlZi5raW5kID09PSAndGVzdCcpIHtcbiAgICAgIGNvbnN0IHN1YmplY3QgPSBkZWYuc3ViamVjdDtcbiAgICAgIGlmIChoYXMoc3ViamVjdCkpIHtcbiAgICAgICAgZGVwcy5hZGQoc3ViamVjdCk7XG4gICAgICAgIHJlc29sdmVycy5wdXNoKHsgbmFtZTogU1VCSkVDVF9JTlBVVCwga2luZDogJ2NlbGwnLCBub2RlSWQ6IHN1YmplY3QgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkaWFnbm9zdGljcy5wdXNoKHsgc2V2ZXJpdHk6ICdlcnJvcicsIGlkLCBtZXNzYWdlOiBgdGVzdCBzdWJqZWN0IFwiJHtzdWJqZWN0fVwiIGRvZXMgbm90IGV4aXN0LmAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgZm9yIChjb25zdCBrZXkgb2YgZXh0ZXJuYWxzKSBleHRlcm5hbElucHV0cy5hZGQoa2V5KTtcbiAgICBub2Rlcy5zZXQoaWQsIHtcbiAgICAgIGlkLFxuICAgICAgd29ya3NoZWV0LFxuICAgICAgY2VsbCxcbiAgICAgIGtpbmQ6IGRlZi5raW5kLFxuICAgICAgZGVmLFxuICAgICAgZGVwczogWy4uLmRlcHNdLFxuICAgICAgZXh0ZXJuYWxzOiBbLi4uZXh0ZXJuYWxzXSxcbiAgICAgIHJlc29sdmVycyxcbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiB7IG5vZGVzLCB3b3Jrc2hlZXRzLCBleHRlcm5hbElucHV0cywgZGlhZ25vc3RpY3MgfTtcbn1cblxuLyoqXG4gKiBFdmVyeSB3aW5kb3dlZCBpbnB1dCBkZWNsYXJlZCBpbiB0aGUgd29ya2Jvb2sgKGB7IGZlZWQsIHdpbmRvdyB9YCBzaXRlcyksIGZvciB0aGVcbiAqIGVkaXQtdGltZSBidWZmZXItY292ZXJhZ2UgZGlhZ25vc3RpYyAoYGNoZWNrQnVmZmVyQ292ZXJzV2luZG93c2ApLiBTdHJ1Y3R1cmFsbHkgdGhlXG4gKiBmZWVkIGxheWVyJ3MgYFdpbmRvd0RlY2xgIOKAlCBkZWNsYXJlZCBoZXJlIHNvIHRoZSBlbmdpbmUgbmV2ZXIgaW1wb3J0cyB0aGUgZmVlZCBsYXllci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY2xhcmVkV2luZG93cyhncmFwaDogRGVwZW5kZW5jeUdyYXBoKTogeyBmZWVkOiBzdHJpbmc7IHdpbmRvdzogc3RyaW5nOyBzaXRlOiBzdHJpbmcgfVtdIHtcbiAgY29uc3Qgb3V0OiB7IGZlZWQ6IHN0cmluZzsgd2luZG93OiBzdHJpbmc7IHNpdGU6IHN0cmluZyB9W10gPSBbXTtcbiAgZm9yIChjb25zdCBub2RlIG9mIGdyYXBoLm5vZGVzLnZhbHVlcygpKSB7XG4gICAgZm9yIChjb25zdCByIG9mIG5vZGUucmVzb2x2ZXJzKSB7XG4gICAgICBpZiAoci5raW5kID09PSAnd2luZG93ZWQtZmVlZCcpIG91dC5wdXNoKHsgZmVlZDogci5mZWVkLCB3aW5kb3c6IHIud2luZG93LCBzaXRlOiBub2RlLmlkIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5pbnRlcmZhY2UgQ2xhc3NpZnlDdHgge1xuICBpZDogc3RyaW5nO1xuICBkZXBzOiBTZXQ8c3RyaW5nPjtcbiAgZXh0ZXJuYWxzOiBTZXQ8c3RyaW5nPjtcbiAgcmVzb2x2ZXJzOiBJbnB1dFJlc29sdmVyW107XG4gIHdvcmtzaGVldHM6IE1hcDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgaGFzOiAoaWQ6IHN0cmluZykgPT4gYm9vbGVhbjtcbiAgZGlhZ25vc3RpY3M6IEdyYXBoRGlhZ25vc3RpY1tdO1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeUlucHV0KG5hbWU6IHN0cmluZywgc3BlYzogSW5wdXRTcGVjLCBjdHg6IENsYXNzaWZ5Q3R4KTogdm9pZCB7XG4gIGlmIChzcGVjLmZlZWQgIT09IHVuZGVmaW5lZCkge1xuICAgIC8vIFRoZSB3aW5kb3dlZC1mZWVkIG9iamVjdCBmb3JtOiB0aGUgY2VsbCByZWFkcyB0aGUgZmVlZCdzICpyZXRhaW5lZCByb3dzKiAobm90IHRoZVxuICAgIC8vIHNuYXBzaG90KSwgc28gaXRzIGV4dGVybmFsIGtleSBpcyB0aGUgYnVmZmVyIGV4dGVybmFsIHRoZSBmZWVkIHJ1bnRpbWUgcHVibGlzaGVzXG4gICAgLy8gYWxvbmdzaWRlIGBmZWVkcy48bmFtZT5gIOKAlCB0aGF0IGtleSBjaGFuZ2luZyBpcyB3aGF0IGRpcnRpZXMgdGhlIGNlbGwuIFRoZSByZXNvbHZlclxuICAgIC8vIGFsc28gcmVhZHMgdGhlIGNsb2NrIChgcGFyYW1zLm5vd2AsIGZhbGxpbmcgYmFjayB0byB0aGUgbmV3ZXN0IHJldGFpbmVkIGV2ZW50IHRpbWUpLFxuICAgIC8vIHNvIGEgd2luZG93ZWQgaW5wdXQgc3RydWN0dXJhbGx5IGRlcGVuZHMgb24gYHBhcmFtcy5ub3dgIHRvbzogYSBjbG9jay1vbmx5IHVwZGF0ZSBtdXN0XG4gICAgLy8gYWR2YW5jZSB0aGUgd2luZG93LiAoVW5jb25kaXRpb25hbCDigJQgd2hldGhlciB0aGUgYXBwIHN1cHBsaWVzIGBwYXJhbXMubm93YCBpcyBhXG4gICAgLy8gcnVudGltZSBmYWN0IHRoZSBncmFwaCBjYW5ub3Qga25vdzsgYW4gZXh0ZXJuYWwgdGhhdCBuZXZlciBjaGFuZ2VzIG5ldmVyIGRpcnRpZXMuKVxuICAgIGN0eC5leHRlcm5hbHMuYWRkKGAke0ZFRURfQlVGRkVSX1BSRUZJWH0ke3NwZWMuZmVlZH1gKTtcbiAgICBjdHguZXh0ZXJuYWxzLmFkZCgncGFyYW1zLm5vdycpO1xuICAgIGN0eC5yZXNvbHZlcnMucHVzaCh7IG5hbWUsIGtpbmQ6ICd3aW5kb3dlZC1mZWVkJywgZmVlZDogc3BlYy5mZWVkLCB3aW5kb3c6IHNwZWMud2luZG93ISwgYnk6IHNwZWMuYnkhIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc3BlYy5uYW1lc3BhY2UgIT09ICd3b3Jrc2hlZXQnKSB7XG4gICAgY3R4LmV4dGVybmFscy5hZGQoc3BlYy5kZXBlbmRlbmN5KTtcbiAgICBjdHgucmVzb2x2ZXJzLnB1c2goeyBuYW1lLCBraW5kOiAnZXh0ZXJuYWwnLCBrZXk6IHNwZWMuZGVwZW5kZW5jeSB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCB3b3Jrc2hlZXQgPSBzcGVjLndvcmtzaGVldCE7XG4gIGlmIChzcGVjLndpbGRjYXJkKSB7XG4gICAgY29uc3QgY2VsbHMgPSBjdHgud29ya3NoZWV0cy5nZXQod29ya3NoZWV0KTtcbiAgICBpZiAoY2VsbHMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgY3R4LmRpYWdub3N0aWNzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogJ2Vycm9yJyxcbiAgICAgICAgaWQ6IGN0eC5pZCxcbiAgICAgICAgbWVzc2FnZTogYGlucHV0IFwiJHtuYW1lfVwiIHJlZmVyZW5jZXMgdW5rbm93biB3b3Jrc2hlZXQgXCIke3dvcmtzaGVldH1cIi5gLFxuICAgICAgfSk7XG4gICAgICBjdHgucmVzb2x2ZXJzLnB1c2goeyBuYW1lLCBraW5kOiAnd2lsZGNhcmQnLCB3b3Jrc2hlZXQgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGZvciAoY29uc3QgZGVwIG9mIGNlbGxzKSBpZiAoZGVwICE9PSBjdHguaWQpIGN0eC5kZXBzLmFkZChkZXApO1xuICAgIGN0eC5yZXNvbHZlcnMucHVzaCh7IG5hbWUsIGtpbmQ6ICd3aWxkY2FyZCcsIHdvcmtzaGVldCB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBub2RlSWQgPSBgJHt3b3Jrc2hlZXR9LiR7c3BlYy5jZWxsfWA7XG4gIGlmICghY3R4Lmhhcyhub2RlSWQpKSB7XG4gICAgY3R4LmRpYWdub3N0aWNzLnB1c2goe1xuICAgICAgc2V2ZXJpdHk6ICdlcnJvcicsXG4gICAgICBpZDogY3R4LmlkLFxuICAgICAgbWVzc2FnZTogYGlucHV0IFwiJHtuYW1lfVwiIHJlZmVyZW5jZXMgdW5rbm93biBjZWxsIFwiJHtub2RlSWR9XCIuYCxcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBjdHguZGVwcy5hZGQobm9kZUlkKTtcbiAgfVxuICBjdHgucmVzb2x2ZXJzLnB1c2goeyBuYW1lLCBraW5kOiAnY2VsbCcsIG5vZGVJZCB9KTtcbn1cblxuLyoqXG4gKiBSZXNvbHZlcnMgZm9yIGEgZGVjbGFyZWQtaW5wdXRzIG1hcCBoZWxkIGJ5IGEgKm5vbi1ncmFwaCogY29uc3VtZXIg4oCUIHRoZSB0ZXN0IHJ1bm5lcidzXG4gKiBmaXh0dXJlIHN1YnN0aXR1dGlvbiAoYSB0ZXN0J3MgZGVjbGFyZWQgaW5wdXRzIHJlc29sdmUgYWdhaW5zdCB0aGUgc2FtZSBwdWJsaXNoZWQgc3RhdGVcbiAqIGEgY2VsbCdzIGRvKS4gVW5yZXNvbHZhYmxlIHJlZmVyZW5jZXMgY29tZSBiYWNrIGFzIGRpYWdub3N0aWNzIGZvciB0aGUgY2FsbGVyIHRvIHN1cmZhY2U7XG4gKiB0aGV5IGFyZSB0aGUgc2FtZSBlcnJvcnMgYGJ1aWxkR3JhcGhgIHdvdWxkIGVtaXQgZm9yIGEgY2VsbC4gYGdyYXBoYCBpcyB0aGUgc3RydWN0dXJhbFxuICogbWluaW11bSB0aGUgY2xhc3NpZmllciBuZWVkcyAoYW4gaWTihpJub2RlIG1hcCBmb3IgY2VsbC1leGlzdGVuY2UgY2hlY2tzICsgdGhlIHdvcmtzaGVldFxuICogbGlzdHMpLCBzbyB0aGUgYXN5bmMgZW5naW5lIGNhbiBwYXNzIGl0cyBkZXNjcmlwdG9yIG1hcHMgZGlyZWN0bHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlcnNGb3IoXG4gIGlucHV0czogUmVjb3JkPHN0cmluZywgSW5wdXRTcGVjPixcbiAgZ3JhcGg6IHsgbm9kZXM6IE1hcDxzdHJpbmcsIHVua25vd24+OyB3b3Jrc2hlZXRzOiBNYXA8c3RyaW5nLCBzdHJpbmdbXT4gfSxcbik6IHsgcmVzb2x2ZXJzOiBJbnB1dFJlc29sdmVyW107IGRpYWdub3N0aWNzOiBzdHJpbmdbXSB9IHtcbiAgY29uc3QgZGlhZ25vc3RpY3M6IEdyYXBoRGlhZ25vc3RpY1tdID0gW107XG4gIGNvbnN0IHJlc29sdmVyczogSW5wdXRSZXNvbHZlcltdID0gW107XG4gIGZvciAoY29uc3QgW25hbWUsIHNwZWNdIG9mIE9iamVjdC5lbnRyaWVzKGlucHV0cykpIHtcbiAgICBjbGFzc2lmeUlucHV0KG5hbWUsIHNwZWMsIHtcbiAgICAgIGlkOiAnKHRlc3QgaW5wdXRzKScsXG4gICAgICBkZXBzOiBuZXcgU2V0KCksXG4gICAgICBleHRlcm5hbHM6IG5ldyBTZXQoKSxcbiAgICAgIHJlc29sdmVycyxcbiAgICAgIHdvcmtzaGVldHM6IGdyYXBoLndvcmtzaGVldHMsXG4gICAgICBoYXM6IChpZCkgPT4gZ3JhcGgubm9kZXMuaGFzKGlkKSxcbiAgICAgIGRpYWdub3N0aWNzLFxuICAgIH0pO1xuICB9XG4gIHJldHVybiB7IHJlc29sdmVycywgZGlhZ25vc3RpY3M6IGRpYWdub3N0aWNzLm1hcCgoZCkgPT4gZC5tZXNzYWdlKSB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFzQkEsSUFBQUEsUUFBQSxHQUFBQyxPQUFBO0FBdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFhQSxNQUFNQyxRQUFRLEdBQUcsSUFBSUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7O0FBRW5FO0FBQ08sTUFBTUMsYUFBYSxHQUFBQyxPQUFBLENBQUFELGFBQUEsR0FBRyxVQUFVO0FBRWhDLFNBQVNFLFVBQVVBLENBQUNDLFFBQWtCLEVBQW1CO0VBQzlELE1BQU1DLFdBQThCLEdBQUcsRUFBRTtFQUN6QyxNQUFNQyxVQUFVLEdBQUcsSUFBSUMsR0FBRyxDQUFtQixDQUFDO0VBQzlDLE1BQU1DLFFBQVEsR0FBRyxJQUFJRCxHQUFHLENBQTRELENBQUM7O0VBRXJGO0VBQ0EsS0FBSyxNQUFNLENBQUNFLFNBQVMsRUFBRUMsS0FBSyxDQUFDLElBQUlDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUixRQUFRLENBQUMsRUFBRTtJQUN6RCxJQUFJTCxRQUFRLENBQUNjLEdBQUcsQ0FBQ0osU0FBUyxDQUFDLEVBQUU7TUFDM0JKLFdBQVcsQ0FBQ1MsSUFBSSxDQUFDO1FBQ2ZDLFFBQVEsRUFBRSxPQUFPO1FBQ2pCQyxFQUFFLEVBQUVQLFNBQVM7UUFDYlEsT0FBTyxFQUFFLGNBQWNSLFNBQVM7TUFDbEMsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNUyxLQUFlLEdBQUcsRUFBRTtJQUMxQixLQUFLLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFQyxHQUFHLENBQUMsSUFBSVQsTUFBTSxDQUFDQyxPQUFPLENBQUNGLEtBQUssQ0FBQyxFQUFFO01BQy9DLE1BQU1NLEVBQUUsR0FBRyxHQUFHUCxTQUFTLElBQUlVLElBQUksRUFBRTtNQUNqQ0QsS0FBSyxDQUFDSixJQUFJLENBQUNFLEVBQUUsQ0FBQztNQUNkUixRQUFRLENBQUNhLEdBQUcsQ0FBQ0wsRUFBRSxFQUFFO1FBQUVQLFNBQVM7UUFBRVUsSUFBSTtRQUFFQztNQUFJLENBQUMsQ0FBQztJQUM1QztJQUNBZCxVQUFVLENBQUNlLEdBQUcsQ0FBQ1osU0FBUyxFQUFFUyxLQUFLLENBQUM7RUFDbEM7RUFFQSxNQUFNTCxHQUFHLEdBQUlHLEVBQVUsSUFBY1IsUUFBUSxDQUFDSyxHQUFHLENBQUNHLEVBQUUsQ0FBQztFQUNyRCxNQUFNTSxLQUFLLEdBQUcsSUFBSWYsR0FBRyxDQUFvQixDQUFDO0VBQzFDLE1BQU1nQixjQUFjLEdBQUcsSUFBSXZCLEdBQUcsQ0FBUyxDQUFDOztFQUV4QztFQUNBLEtBQUssTUFBTSxDQUFDZ0IsRUFBRSxFQUFFO0lBQUVQLFNBQVM7SUFBRVUsSUFBSTtJQUFFQztFQUFJLENBQUMsQ0FBQyxJQUFJWixRQUFRLEVBQUU7SUFDckQsTUFBTWdCLElBQUksR0FBRyxJQUFJeEIsR0FBRyxDQUFTLENBQUM7SUFDOUIsTUFBTXlCLFNBQVMsR0FBRyxJQUFJekIsR0FBRyxDQUFTLENBQUM7SUFDbkMsTUFBTTBCLFNBQTBCLEdBQUcsRUFBRTtJQUVyQyxLQUFLLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFQyxJQUFJLENBQUMsSUFBSWpCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUSxHQUFHLENBQUNTLE1BQU0sQ0FBQyxFQUEyQjtNQUM5RUMsYUFBYSxDQUFDSCxJQUFJLEVBQUVDLElBQUksRUFBRTtRQUFFWixFQUFFO1FBQUVRLElBQUk7UUFBRUMsU0FBUztRQUFFQyxTQUFTO1FBQUVwQixVQUFVO1FBQUVPLEdBQUc7UUFBRVI7TUFBWSxDQUFDLENBQUM7SUFDN0Y7O0lBRUE7SUFDQSxJQUFJZSxHQUFHLENBQUNXLElBQUksS0FBSyxNQUFNLEVBQUU7TUFDdkIsTUFBTUMsT0FBTyxHQUFHWixHQUFHLENBQUNZLE9BQU87TUFDM0IsSUFBSW5CLEdBQUcsQ0FBQ21CLE9BQU8sQ0FBQyxFQUFFO1FBQ2hCUixJQUFJLENBQUNTLEdBQUcsQ0FBQ0QsT0FBTyxDQUFDO1FBQ2pCTixTQUFTLENBQUNaLElBQUksQ0FBQztVQUFFYSxJQUFJLEVBQUUxQixhQUFhO1VBQUU4QixJQUFJLEVBQUUsTUFBTTtVQUFFRyxNQUFNLEVBQUVGO1FBQVEsQ0FBQyxDQUFDO01BQ3hFLENBQUMsTUFBTTtRQUNMM0IsV0FBVyxDQUFDUyxJQUFJLENBQUM7VUFBRUMsUUFBUSxFQUFFLE9BQU87VUFBRUMsRUFBRTtVQUFFQyxPQUFPLEVBQUUsaUJBQWlCZSxPQUFPO1FBQW9CLENBQUMsQ0FBQztNQUNuRztJQUNGO0lBRUEsS0FBSyxNQUFNRyxHQUFHLElBQUlWLFNBQVMsRUFBRUYsY0FBYyxDQUFDVSxHQUFHLENBQUNFLEdBQUcsQ0FBQztJQUNwRGIsS0FBSyxDQUFDRCxHQUFHLENBQUNMLEVBQUUsRUFBRTtNQUNaQSxFQUFFO01BQ0ZQLFNBQVM7TUFDVFUsSUFBSTtNQUNKWSxJQUFJLEVBQUVYLEdBQUcsQ0FBQ1csSUFBSTtNQUNkWCxHQUFHO01BQ0hJLElBQUksRUFBRSxDQUFDLEdBQUdBLElBQUksQ0FBQztNQUNmQyxTQUFTLEVBQUUsQ0FBQyxHQUFHQSxTQUFTLENBQUM7TUFDekJDO0lBQ0YsQ0FBQyxDQUFDO0VBQ0o7RUFFQSxPQUFPO0lBQUVKLEtBQUs7SUFBRWhCLFVBQVU7SUFBRWlCLGNBQWM7SUFBRWxCO0VBQVksQ0FBQztBQUMzRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUytCLGVBQWVBLENBQUNDLEtBQXNCLEVBQW9EO0VBQ3hHLE1BQU1DLEdBQXFELEdBQUcsRUFBRTtFQUNoRSxLQUFLLE1BQU1DLElBQUksSUFBSUYsS0FBSyxDQUFDZixLQUFLLENBQUNrQixNQUFNLENBQUMsQ0FBQyxFQUFFO0lBQ3ZDLEtBQUssTUFBTUMsQ0FBQyxJQUFJRixJQUFJLENBQUNiLFNBQVMsRUFBRTtNQUM5QixJQUFJZSxDQUFDLENBQUNWLElBQUksS0FBSyxlQUFlLEVBQUVPLEdBQUcsQ0FBQ3hCLElBQUksQ0FBQztRQUFFNEIsSUFBSSxFQUFFRCxDQUFDLENBQUNDLElBQUk7UUFBRUMsTUFBTSxFQUFFRixDQUFDLENBQUNFLE1BQU07UUFBRUMsSUFBSSxFQUFFTCxJQUFJLENBQUN2QjtNQUFHLENBQUMsQ0FBQztJQUM3RjtFQUNGO0VBQ0EsT0FBT3NCLEdBQUc7QUFDWjtBQVlBLFNBQVNSLGFBQWFBLENBQUNILElBQVksRUFBRUMsSUFBZSxFQUFFaUIsR0FBZ0IsRUFBUTtFQUM1RSxJQUFJakIsSUFBSSxDQUFDYyxJQUFJLEtBQUtJLFNBQVMsRUFBRTtJQUMzQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBRCxHQUFHLENBQUNwQixTQUFTLENBQUNRLEdBQUcsQ0FBQyxHQUFHYywyQkFBa0IsR0FBR25CLElBQUksQ0FBQ2MsSUFBSSxFQUFFLENBQUM7SUFDdERHLEdBQUcsQ0FBQ3BCLFNBQVMsQ0FBQ1EsR0FBRyxDQUFDLFlBQVksQ0FBQztJQUMvQlksR0FBRyxDQUFDbkIsU0FBUyxDQUFDWixJQUFJLENBQUM7TUFBRWEsSUFBSTtNQUFFSSxJQUFJLEVBQUUsZUFBZTtNQUFFVyxJQUFJLEVBQUVkLElBQUksQ0FBQ2MsSUFBSTtNQUFFQyxNQUFNLEVBQUVmLElBQUksQ0FBQ2UsTUFBTztNQUFFSyxFQUFFLEVBQUVwQixJQUFJLENBQUNvQjtJQUFJLENBQUMsQ0FBQztJQUN4RztFQUNGO0VBQ0EsSUFBSXBCLElBQUksQ0FBQ3FCLFNBQVMsS0FBSyxXQUFXLEVBQUU7SUFDbENKLEdBQUcsQ0FBQ3BCLFNBQVMsQ0FBQ1EsR0FBRyxDQUFDTCxJQUFJLENBQUNzQixVQUFVLENBQUM7SUFDbENMLEdBQUcsQ0FBQ25CLFNBQVMsQ0FBQ1osSUFBSSxDQUFDO01BQUVhLElBQUk7TUFBRUksSUFBSSxFQUFFLFVBQVU7TUFBRUksR0FBRyxFQUFFUCxJQUFJLENBQUNzQjtJQUFXLENBQUMsQ0FBQztJQUNwRTtFQUNGO0VBRUEsTUFBTXpDLFNBQVMsR0FBR21CLElBQUksQ0FBQ25CLFNBQVU7RUFDakMsSUFBSW1CLElBQUksQ0FBQ3VCLFFBQVEsRUFBRTtJQUNqQixNQUFNekMsS0FBSyxHQUFHbUMsR0FBRyxDQUFDdkMsVUFBVSxDQUFDOEMsR0FBRyxDQUFDM0MsU0FBUyxDQUFDO0lBQzNDLElBQUlDLEtBQUssS0FBS29DLFNBQVMsRUFBRTtNQUN2QkQsR0FBRyxDQUFDeEMsV0FBVyxDQUFDUyxJQUFJLENBQUM7UUFDbkJDLFFBQVEsRUFBRSxPQUFPO1FBQ2pCQyxFQUFFLEVBQUU2QixHQUFHLENBQUM3QixFQUFFO1FBQ1ZDLE9BQU8sRUFBRSxVQUFVVSxJQUFJLG1DQUFtQ2xCLFNBQVM7TUFDckUsQ0FBQyxDQUFDO01BQ0ZvQyxHQUFHLENBQUNuQixTQUFTLENBQUNaLElBQUksQ0FBQztRQUFFYSxJQUFJO1FBQUVJLElBQUksRUFBRSxVQUFVO1FBQUV0QjtNQUFVLENBQUMsQ0FBQztNQUN6RDtJQUNGO0lBQ0EsS0FBSyxNQUFNNEMsR0FBRyxJQUFJM0MsS0FBSyxFQUFFLElBQUkyQyxHQUFHLEtBQUtSLEdBQUcsQ0FBQzdCLEVBQUUsRUFBRTZCLEdBQUcsQ0FBQ3JCLElBQUksQ0FBQ1MsR0FBRyxDQUFDb0IsR0FBRyxDQUFDO0lBQzlEUixHQUFHLENBQUNuQixTQUFTLENBQUNaLElBQUksQ0FBQztNQUFFYSxJQUFJO01BQUVJLElBQUksRUFBRSxVQUFVO01BQUV0QjtJQUFVLENBQUMsQ0FBQztJQUN6RDtFQUNGO0VBRUEsTUFBTXlCLE1BQU0sR0FBRyxHQUFHekIsU0FBUyxJQUFJbUIsSUFBSSxDQUFDVCxJQUFJLEVBQUU7RUFDMUMsSUFBSSxDQUFDMEIsR0FBRyxDQUFDaEMsR0FBRyxDQUFDcUIsTUFBTSxDQUFDLEVBQUU7SUFDcEJXLEdBQUcsQ0FBQ3hDLFdBQVcsQ0FBQ1MsSUFBSSxDQUFDO01BQ25CQyxRQUFRLEVBQUUsT0FBTztNQUNqQkMsRUFBRSxFQUFFNkIsR0FBRyxDQUFDN0IsRUFBRTtNQUNWQyxPQUFPLEVBQUUsVUFBVVUsSUFBSSw4QkFBOEJPLE1BQU07SUFDN0QsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxNQUFNO0lBQ0xXLEdBQUcsQ0FBQ3JCLElBQUksQ0FBQ1MsR0FBRyxDQUFDQyxNQUFNLENBQUM7RUFDdEI7RUFDQVcsR0FBRyxDQUFDbkIsU0FBUyxDQUFDWixJQUFJLENBQUM7SUFBRWEsSUFBSTtJQUFFSSxJQUFJLEVBQUUsTUFBTTtJQUFFRztFQUFPLENBQUMsQ0FBQztBQUNwRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU29CLFlBQVlBLENBQzFCekIsTUFBaUMsRUFDakNRLEtBQXlFLEVBQ2xCO0VBQ3ZELE1BQU1oQyxXQUE4QixHQUFHLEVBQUU7RUFDekMsTUFBTXFCLFNBQTBCLEdBQUcsRUFBRTtFQUNyQyxLQUFLLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFQyxJQUFJLENBQUMsSUFBSWpCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDaUIsTUFBTSxDQUFDLEVBQUU7SUFDakRDLGFBQWEsQ0FBQ0gsSUFBSSxFQUFFQyxJQUFJLEVBQUU7TUFDeEJaLEVBQUUsRUFBRSxlQUFlO01BQ25CUSxJQUFJLEVBQUUsSUFBSXhCLEdBQUcsQ0FBQyxDQUFDO01BQ2Z5QixTQUFTLEVBQUUsSUFBSXpCLEdBQUcsQ0FBQyxDQUFDO01BQ3BCMEIsU0FBUztNQUNUcEIsVUFBVSxFQUFFK0IsS0FBSyxDQUFDL0IsVUFBVTtNQUM1Qk8sR0FBRyxFQUFHRyxFQUFFLElBQUtxQixLQUFLLENBQUNmLEtBQUssQ0FBQ1QsR0FBRyxDQUFDRyxFQUFFLENBQUM7TUFDaENYO0lBQ0YsQ0FBQyxDQUFDO0VBQ0o7RUFDQSxPQUFPO0lBQUVxQixTQUFTO0lBQUVyQixXQUFXLEVBQUVBLFdBQVcsQ0FBQ2tELEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUN2QyxPQUFPO0VBQUUsQ0FBQztBQUN0RSIsImlnbm9yZUxpc3QiOltdfQ==