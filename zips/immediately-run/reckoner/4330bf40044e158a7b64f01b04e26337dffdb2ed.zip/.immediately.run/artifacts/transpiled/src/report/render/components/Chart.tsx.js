var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Chart;
var _bindingsContext = require("../bindingsContext.ts");
var _shape = require("../shape.ts");
var _attrs = require("../attrs.ts");
var _chartEncoding = require("../chartEncoding.ts");
var _ChartFigure = _interopRequireDefault(require("./ChartFigure.tsx"));
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _TierSlot = _interopRequireDefault(require("./TierSlot.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Chart — binds a `source` to a row set and draws it through the presentational ChartFigure
// (§3.3). Shape guard: a non-table binding is a marked broken tile. The tier slot is reserved
// for the host badge. Encoding (kind + fields) comes from the node's literal attributes.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Chart({
  node
}) {
  _s();
  const source = (0, _attrs.attrString)(node, 'source');
  const bound = (0, _bindingsContext.useSource)(source);
  const enc = (0, _chartEncoding.readChartEncoding)(node);
  if (bound.status !== 'ok') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "Chart",
      reason: bound.message ?? 'unavailable',
      variant: bound.status === 'missing' ? 'needs-access' : 'error'
    });
  }
  const rows = (0, _shape.asRows)(bound.value);
  if (!rows.ok) return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: "Chart",
    reason: rows.reason
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("figure", {
    className: "rk-tile rk-chart-tile",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TierSlot.default, {
      tier: bound.tier
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ChartFigure.default, {
      rows: rows.data,
      enc: enc,
      ariaLabel: `${enc.kind} of ${source ?? ''}`
    })]
  });
}
_s(Chart, "5joLNnTxqRabjF7FIIG70b60L3g=", false, function () {
  return [_bindingsContext.useSource];
});
_c = Chart;
var _c;
$RefreshReg$(_c, "Chart");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYmluZGluZ3NDb250ZXh0IiwicmVxdWlyZSIsIl9zaGFwZSIsIl9hdHRycyIsIl9jaGFydEVuY29kaW5nIiwiX0NoYXJ0RmlndXJlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Ccm9rZW5UaWxlIiwiX1RpZXJTbG90IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkNoYXJ0Iiwibm9kZSIsInNvdXJjZSIsImF0dHJTdHJpbmciLCJib3VuZCIsInVzZVNvdXJjZSIsImVuYyIsInJlYWRDaGFydEVuY29kaW5nIiwic3RhdHVzIiwianN4IiwiY29tcG9uZW50IiwicmVhc29uIiwibWVzc2FnZSIsInZhcmlhbnQiLCJyb3dzIiwiYXNSb3dzIiwidmFsdWUiLCJvayIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsInRpZXIiLCJkYXRhIiwiYXJpYUxhYmVsIiwia2luZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2hhcnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIENoYXJ0IOKAlCBiaW5kcyBhIGBzb3VyY2VgIHRvIGEgcm93IHNldCBhbmQgZHJhd3MgaXQgdGhyb3VnaCB0aGUgcHJlc2VudGF0aW9uYWwgQ2hhcnRGaWd1cmVcbi8vICjCpzMuMykuIFNoYXBlIGd1YXJkOiBhIG5vbi10YWJsZSBiaW5kaW5nIGlzIGEgbWFya2VkIGJyb2tlbiB0aWxlLiBUaGUgdGllciBzbG90IGlzIHJlc2VydmVkXG4vLyBmb3IgdGhlIGhvc3QgYmFkZ2UuIEVuY29kaW5nIChraW5kICsgZmllbGRzKSBjb21lcyBmcm9tIHRoZSBub2RlJ3MgbGl0ZXJhbCBhdHRyaWJ1dGVzLlxuaW1wb3J0IHR5cGUgeyBDb21wb25lbnROb2RlIH0gZnJvbSAnLi4vLi4vbm9kZXMudHMnO1xuaW1wb3J0IHsgdXNlU291cmNlIH0gZnJvbSAnLi4vYmluZGluZ3NDb250ZXh0LnRzJztcbmltcG9ydCB7IGFzUm93cyB9IGZyb20gJy4uL3NoYXBlLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyByZWFkQ2hhcnRFbmNvZGluZyB9IGZyb20gJy4uL2NoYXJ0RW5jb2RpbmcudHMnO1xuaW1wb3J0IENoYXJ0RmlndXJlIGZyb20gJy4vQ2hhcnRGaWd1cmUudHN4JztcbmltcG9ydCBCcm9rZW5UaWxlIGZyb20gJy4vQnJva2VuVGlsZS50c3gnO1xuaW1wb3J0IFRpZXJTbG90IGZyb20gJy4vVGllclNsb3QudHN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2hhcnQoeyBub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIGNvbnN0IHNvdXJjZSA9IGF0dHJTdHJpbmcobm9kZSwgJ3NvdXJjZScpO1xuICBjb25zdCBib3VuZCA9IHVzZVNvdXJjZShzb3VyY2UpO1xuICBjb25zdCBlbmMgPSByZWFkQ2hhcnRFbmNvZGluZyhub2RlKTtcblxuICBpZiAoYm91bmQuc3RhdHVzICE9PSAnb2snKSB7XG4gICAgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIkNoYXJ0XCIgcmVhc29uPXtib3VuZC5tZXNzYWdlID8/ICd1bmF2YWlsYWJsZSd9IHZhcmlhbnQ9e2JvdW5kLnN0YXR1cyA9PT0gJ21pc3NpbmcnID8gJ25lZWRzLWFjY2VzcycgOiAnZXJyb3InfSAvPjtcbiAgfVxuICBjb25zdCByb3dzID0gYXNSb3dzKGJvdW5kLnZhbHVlKTtcbiAgaWYgKCFyb3dzLm9rKSByZXR1cm4gPEJyb2tlblRpbGUgY29tcG9uZW50PVwiQ2hhcnRcIiByZWFzb249e3Jvd3MucmVhc29ufSAvPjtcblxuICByZXR1cm4gKFxuICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwicmstdGlsZSByay1jaGFydC10aWxlXCI+XG4gICAgICA8VGllclNsb3QgdGllcj17Ym91bmQudGllcn0gLz5cbiAgICAgIDxDaGFydEZpZ3VyZSByb3dzPXtyb3dzLmRhdGF9IGVuYz17ZW5jfSBhcmlhTGFiZWw9e2Ake2VuYy5raW5kfSBvZiAke3NvdXJjZSA/PyAnJ31gfSAvPlxuICAgIDwvZmlndXJlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFJQSxJQUFBQSxnQkFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsY0FBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksWUFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU0sV0FBQSxHQUFBRCxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU8sU0FBQSxHQUFBRixzQkFBQSxDQUFBTCxPQUFBO0FBQXNDLElBQUFRLFdBQUEsR0FBQVIsT0FBQTtBQUFBLElBQUFTLEVBQUEsR0FBQUMsWUFBQSxJQVZ0QztBQUNBO0FBQ0E7QUFBQSxTQUFBTCx1QkFBQU0sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVVlLFNBQVNHLEtBQUtBLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFOLEVBQUE7RUFDL0QsTUFBTU8sTUFBTSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxRQUFRLENBQUM7RUFDekMsTUFBTUcsS0FBSyxHQUFHLElBQUFDLDBCQUFTLEVBQUNILE1BQU0sQ0FBQztFQUMvQixNQUFNSSxHQUFHLEdBQUcsSUFBQUMsZ0NBQWlCLEVBQUNOLElBQUksQ0FBQztFQUVuQyxJQUFJRyxLQUFLLENBQUNJLE1BQU0sS0FBSyxJQUFJLEVBQUU7SUFDekIsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxHQUFBLEVBQUNqQixXQUFBLENBQUFPLE9BQVU7TUFBQ1csU0FBUyxFQUFDLE9BQU87TUFBQ0MsTUFBTSxFQUFFUCxLQUFLLENBQUNRLE9BQU8sSUFBSSxhQUFjO01BQUNDLE9BQU8sRUFBRVQsS0FBSyxDQUFDSSxNQUFNLEtBQUssU0FBUyxHQUFHLGNBQWMsR0FBRztJQUFRLENBQUUsQ0FBQztFQUNqSjtFQUNBLE1BQU1NLElBQUksR0FBRyxJQUFBQyxhQUFNLEVBQUNYLEtBQUssQ0FBQ1ksS0FBSyxDQUFDO0VBQ2hDLElBQUksQ0FBQ0YsSUFBSSxDQUFDRyxFQUFFLEVBQUUsb0JBQU8sSUFBQXZCLFdBQUEsQ0FBQWUsR0FBQSxFQUFDakIsV0FBQSxDQUFBTyxPQUFVO0lBQUNXLFNBQVMsRUFBQyxPQUFPO0lBQUNDLE1BQU0sRUFBRUcsSUFBSSxDQUFDSDtFQUFPLENBQUUsQ0FBQztFQUUxRSxvQkFDRSxJQUFBakIsV0FBQSxDQUFBd0IsSUFBQTtJQUFRQyxTQUFTLEVBQUMsdUJBQXVCO0lBQUFDLFFBQUEsZ0JBQ3ZDLElBQUExQixXQUFBLENBQUFlLEdBQUEsRUFBQ2hCLFNBQUEsQ0FBQU0sT0FBUTtNQUFDc0IsSUFBSSxFQUFFakIsS0FBSyxDQUFDaUI7SUFBSyxDQUFFLENBQUMsZUFDOUIsSUFBQTNCLFdBQUEsQ0FBQWUsR0FBQSxFQUFDbkIsWUFBQSxDQUFBUyxPQUFXO01BQUNlLElBQUksRUFBRUEsSUFBSSxDQUFDUSxJQUFLO01BQUNoQixHQUFHLEVBQUVBLEdBQUk7TUFBQ2lCLFNBQVMsRUFBRSxHQUFHakIsR0FBRyxDQUFDa0IsSUFBSSxPQUFPdEIsTUFBTSxJQUFJLEVBQUU7SUFBRyxDQUFFLENBQUM7RUFBQSxDQUNqRixDQUFDO0FBRWI7QUFBQ1AsRUFBQSxDQWpCdUJLLEtBQUs7RUFBQSxRQUViSywwQkFBUztBQUFBO0FBQUFvQixFQUFBLEdBRkR6QixLQUFLO0FBQUEsSUFBQXlCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}