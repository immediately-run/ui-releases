var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _react = require("react");
var _server = require("react-dom/server");
var _WhatIfResult = _interopRequireDefault(require("./WhatIfResult.tsx"));
var _hash = require("../engine/hash.ts");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The what-if readout's states (WHATIF_SHADOW_EVALUATION_SPEC §1.1): typed refusals, the
// baseline→shadow line, the downstream delta list, verdict flips, xref diagnostics, and
// the pinned-baseline provenance note. Static-rendered against a hand-built outcome; the
// effect-owning shell (WhatIfPanel/useShadowRunner) is covered by the whatif engine tests.

function pass(results, errors = {}) {
  return {
    results: new Map(Object.entries(results).map(([id, value]) => [id, {
      id,
      value,
      tier: 'static',
      key: (0, _hash.contentKey)(value)
    }])),
    errors: new Map(Object.entries(errors)),
    quarantined: []
  };
}

// `valueOf` is omitted from the override shape: an object literal's inherited
// Object.prototype.valueOf would otherwise clash with the field during assignability.
function success(over) {
  const shadow = over.pass ?? pass({});
  return {
    ok: true,
    baseline: over.baseline ?? pass({}),
    pass: shadow,
    cells: [],
    tests: [],
    verdicts: new Map(),
    deltas: [],
    closure: new Set(),
    verdictFlips: [],
    diagnostics: [],
    valueOf: id => shadow.results.get(id)?.value,
    errorOf: id => shadow.errors.get(id),
    ...over
  };
}
(0, _vitest.describe)('WhatIfResult', () => {
  (0, _vitest.it)('renders a typed refusal', () => {
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_WhatIfResult.default, {
      outcome: {
        ok: false,
        refusal: {
          code: 'formula-ambiguous',
          message: 'occurs more than once'
        }
      },
      cellId: 'm.a'
    }));
    (0, _vitest.expect)(html).toContain('formula-ambiguous');
    (0, _vitest.expect)(html).toContain('occurs more than once');
  });
  (0, _vitest.it)('renders the baseline→shadow line, the downstream deltas, flips, and provenance', () => {
    const outcome = success({
      baseline: pass({
        'm.a': 6,
        'm.b': 12
      }),
      pass: pass({
        'm.a': 106,
        'm.b': 212
      }),
      deltas: [{
        id: 'm.a',
        kind: 'changed',
        before: 6,
        after: 106
      }, {
        id: 'm.b',
        kind: 'changed',
        before: 12,
        after: 212
      }],
      verdictFlips: [{
        subject: 'm.b',
        before: 'pinned',
        after: 'failing'
      }]
    });
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_WhatIfResult.default, {
      outcome,
      cellId: 'm.a'
    }));
    (0, _vitest.expect)(html).toContain('6 → 106');
    (0, _vitest.expect)(html).toContain('m.b');
    (0, _vitest.expect)(html).toContain('12 → 212');
    (0, _vitest.expect)(html).toContain('pinned → failing');
    (0, _vitest.expect)(html).toContain('baseline pinned');
  });
  (0, _vitest.it)('renders a shadow error on the inspected cell and xref diagnostics', () => {
    const outcome = success({
      baseline: pass({
        'm.a': 6
      }),
      pass: pass({}, {
        'm.a': 'boom'
      }),
      deltas: [{
        id: 'm.a',
        kind: 'new-error',
        before: 6,
        afterError: 'boom'
      }],
      diagnostics: [{
        severity: 'error',
        file: 'worksheets/scratch',
        message: 'references unknown fixture "rowz".'
      }]
    });
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_WhatIfResult.default, {
      outcome,
      cellId: 'm.a'
    }));
    (0, _vitest.expect)(html).toContain('error: boom');
    (0, _vitest.expect)(html).toContain('rowz');
  });
  (0, _vitest.it)('says so when nothing changed', () => {
    const outcome = success({
      baseline: pass({
        'm.a': 6
      }),
      pass: pass({
        'm.a': 6
      })
    });
    const html = (0, _server.renderToStaticMarkup)(/*#__PURE__*/(0, _react.createElement)(_WhatIfResult.default, {
      outcome,
      cellId: 'm.a'
    }));
    (0, _vitest.expect)(html).toContain('no change against the baseline');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9zZXJ2ZXIiLCJfV2hhdElmUmVzdWx0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9oYXNoIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwicGFzcyIsInJlc3VsdHMiLCJlcnJvcnMiLCJNYXAiLCJPYmplY3QiLCJlbnRyaWVzIiwibWFwIiwiaWQiLCJ2YWx1ZSIsInRpZXIiLCJrZXkiLCJjb250ZW50S2V5IiwicXVhcmFudGluZWQiLCJzdWNjZXNzIiwib3ZlciIsInNoYWRvdyIsIm9rIiwiYmFzZWxpbmUiLCJjZWxscyIsInRlc3RzIiwidmVyZGljdHMiLCJkZWx0YXMiLCJjbG9zdXJlIiwiU2V0IiwidmVyZGljdEZsaXBzIiwiZGlhZ25vc3RpY3MiLCJ2YWx1ZU9mIiwiZ2V0IiwiZXJyb3JPZiIsImRlc2NyaWJlIiwiaXQiLCJodG1sIiwicmVuZGVyVG9TdGF0aWNNYXJrdXAiLCJjcmVhdGVFbGVtZW50IiwiV2hhdElmUmVzdWx0Iiwib3V0Y29tZSIsInJlZnVzYWwiLCJjb2RlIiwibWVzc2FnZSIsImNlbGxJZCIsImV4cGVjdCIsInRvQ29udGFpbiIsImtpbmQiLCJiZWZvcmUiLCJhZnRlciIsInN1YmplY3QiLCJhZnRlckVycm9yIiwic2V2ZXJpdHkiLCJmaWxlIl0sInNvdXJjZXMiOlsiV2hhdElmUmVzdWx0LnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSB3aGF0LWlmIHJlYWRvdXQncyBzdGF0ZXMgKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMS4xKTogdHlwZWQgcmVmdXNhbHMsIHRoZVxuLy8gYmFzZWxpbmXihpJzaGFkb3cgbGluZSwgdGhlIGRvd25zdHJlYW0gZGVsdGEgbGlzdCwgdmVyZGljdCBmbGlwcywgeHJlZiBkaWFnbm9zdGljcywgYW5kXG4vLyB0aGUgcGlubmVkLWJhc2VsaW5lIHByb3ZlbmFuY2Ugbm90ZS4gU3RhdGljLXJlbmRlcmVkIGFnYWluc3QgYSBoYW5kLWJ1aWx0IG91dGNvbWU7IHRoZVxuLy8gZWZmZWN0LW93bmluZyBzaGVsbCAoV2hhdElmUGFuZWwvdXNlU2hhZG93UnVubmVyKSBpcyBjb3ZlcmVkIGJ5IHRoZSB3aGF0aWYgZW5naW5lIHRlc3RzLlxuaW1wb3J0IHsgZGVzY3JpYmUsIGV4cGVjdCwgaXQgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHJlbmRlclRvU3RhdGljTWFya3VwIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG5pbXBvcnQgV2hhdElmUmVzdWx0IGZyb20gJy4vV2hhdElmUmVzdWx0LnRzeCc7XG5pbXBvcnQgdHlwZSB7IFNoYWRvd091dGNvbWUsIFNoYWRvd1N1Y2Nlc3MgfSBmcm9tICcuL3doYXRpZi50cyc7XG5pbXBvcnQgdHlwZSB7IEFzeW5jUGFzcyB9IGZyb20gJy4uL2VuZ2luZS9hc3luY0VuZ2luZS50cyc7XG5pbXBvcnQgeyBjb250ZW50S2V5IH0gZnJvbSAnLi4vZW5naW5lL2hhc2gudHMnO1xuaW1wb3J0IHR5cGUgeyBWYWx1ZSB9IGZyb20gJy4uL3N0ZGxpYi90eXBlcy50cyc7XG5cbmZ1bmN0aW9uIHBhc3MocmVzdWx0czogUmVjb3JkPHN0cmluZywgVmFsdWU+LCBlcnJvcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fSk6IEFzeW5jUGFzcyB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0czogbmV3IE1hcChcbiAgICAgIE9iamVjdC5lbnRyaWVzKHJlc3VsdHMpLm1hcCgoW2lkLCB2YWx1ZV0pID0+IFtpZCwgeyBpZCwgdmFsdWUsIHRpZXI6ICdzdGF0aWMnIGFzIGNvbnN0LCBrZXk6IGNvbnRlbnRLZXkodmFsdWUpIH1dKSxcbiAgICApLFxuICAgIGVycm9yczogbmV3IE1hcChPYmplY3QuZW50cmllcyhlcnJvcnMpKSxcbiAgICBxdWFyYW50aW5lZDogW10sXG4gIH07XG59XG5cbi8vIGB2YWx1ZU9mYCBpcyBvbWl0dGVkIGZyb20gdGhlIG92ZXJyaWRlIHNoYXBlOiBhbiBvYmplY3QgbGl0ZXJhbCdzIGluaGVyaXRlZFxuLy8gT2JqZWN0LnByb3RvdHlwZS52YWx1ZU9mIHdvdWxkIG90aGVyd2lzZSBjbGFzaCB3aXRoIHRoZSBmaWVsZCBkdXJpbmcgYXNzaWduYWJpbGl0eS5cbmZ1bmN0aW9uIHN1Y2Nlc3Mob3ZlcjogUGFydGlhbDxPbWl0PFNoYWRvd1N1Y2Nlc3MsICd2YWx1ZU9mJyB8ICdlcnJvck9mJz4+KTogU2hhZG93T3V0Y29tZSB7XG4gIGNvbnN0IHNoYWRvdyA9IG92ZXIucGFzcyA/PyBwYXNzKHt9KTtcbiAgcmV0dXJuIHtcbiAgICBvazogdHJ1ZSxcbiAgICBiYXNlbGluZTogb3Zlci5iYXNlbGluZSA/PyBwYXNzKHt9KSxcbiAgICBwYXNzOiBzaGFkb3csXG4gICAgY2VsbHM6IFtdLFxuICAgIHRlc3RzOiBbXSxcbiAgICB2ZXJkaWN0czogbmV3IE1hcCgpLFxuICAgIGRlbHRhczogW10sXG4gICAgY2xvc3VyZTogbmV3IFNldCgpLFxuICAgIHZlcmRpY3RGbGlwczogW10sXG4gICAgZGlhZ25vc3RpY3M6IFtdLFxuICAgIHZhbHVlT2Y6IChpZCkgPT4gc2hhZG93LnJlc3VsdHMuZ2V0KGlkKT8udmFsdWUsXG4gICAgZXJyb3JPZjogKGlkKSA9PiBzaGFkb3cuZXJyb3JzLmdldChpZCksXG4gICAgLi4ub3ZlcixcbiAgfTtcbn1cblxuZGVzY3JpYmUoJ1doYXRJZlJlc3VsdCcsICgpID0+IHtcbiAgaXQoJ3JlbmRlcnMgYSB0eXBlZCByZWZ1c2FsJywgKCkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0YXRpY01hcmt1cChcbiAgICAgIGNyZWF0ZUVsZW1lbnQoV2hhdElmUmVzdWx0LCB7XG4gICAgICAgIG91dGNvbWU6IHsgb2s6IGZhbHNlLCByZWZ1c2FsOiB7IGNvZGU6ICdmb3JtdWxhLWFtYmlndW91cycsIG1lc3NhZ2U6ICdvY2N1cnMgbW9yZSB0aGFuIG9uY2UnIH0gfSxcbiAgICAgICAgY2VsbElkOiAnbS5hJyxcbiAgICAgIH0pLFxuICAgICk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignZm9ybXVsYS1hbWJpZ3VvdXMnKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdvY2N1cnMgbW9yZSB0aGFuIG9uY2UnKTtcbiAgfSk7XG5cbiAgaXQoJ3JlbmRlcnMgdGhlIGJhc2VsaW5l4oaSc2hhZG93IGxpbmUsIHRoZSBkb3duc3RyZWFtIGRlbHRhcywgZmxpcHMsIGFuZCBwcm92ZW5hbmNlJywgKCkgPT4ge1xuICAgIGNvbnN0IG91dGNvbWUgPSBzdWNjZXNzKHtcbiAgICAgIGJhc2VsaW5lOiBwYXNzKHsgJ20uYSc6IDYsICdtLmInOiAxMiB9KSxcbiAgICAgIHBhc3M6IHBhc3MoeyAnbS5hJzogMTA2LCAnbS5iJzogMjEyIH0pLFxuICAgICAgZGVsdGFzOiBbXG4gICAgICAgIHsgaWQ6ICdtLmEnLCBraW5kOiAnY2hhbmdlZCcsIGJlZm9yZTogNiwgYWZ0ZXI6IDEwNiB9LFxuICAgICAgICB7IGlkOiAnbS5iJywga2luZDogJ2NoYW5nZWQnLCBiZWZvcmU6IDEyLCBhZnRlcjogMjEyIH0sXG4gICAgICBdLFxuICAgICAgdmVyZGljdEZsaXBzOiBbeyBzdWJqZWN0OiAnbS5iJywgYmVmb3JlOiAncGlubmVkJywgYWZ0ZXI6ICdmYWlsaW5nJyB9XSxcbiAgICB9KTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyVG9TdGF0aWNNYXJrdXAoY3JlYXRlRWxlbWVudChXaGF0SWZSZXN1bHQsIHsgb3V0Y29tZSwgY2VsbElkOiAnbS5hJyB9KSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignNiDihpIgMTA2Jyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignbS5iJyk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignMTIg4oaSIDIxMicpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ3Bpbm5lZCDihpIgZmFpbGluZycpO1xuICAgIGV4cGVjdChodG1sKS50b0NvbnRhaW4oJ2Jhc2VsaW5lIHBpbm5lZCcpO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBhIHNoYWRvdyBlcnJvciBvbiB0aGUgaW5zcGVjdGVkIGNlbGwgYW5kIHhyZWYgZGlhZ25vc3RpY3MnLCAoKSA9PiB7XG4gICAgY29uc3Qgb3V0Y29tZSA9IHN1Y2Nlc3Moe1xuICAgICAgYmFzZWxpbmU6IHBhc3MoeyAnbS5hJzogNiB9KSxcbiAgICAgIHBhc3M6IHBhc3Moe30sIHsgJ20uYSc6ICdib29tJyB9KSxcbiAgICAgIGRlbHRhczogW3sgaWQ6ICdtLmEnLCBraW5kOiAnbmV3LWVycm9yJywgYmVmb3JlOiA2LCBhZnRlckVycm9yOiAnYm9vbScgfV0sXG4gICAgICBkaWFnbm9zdGljczogW3sgc2V2ZXJpdHk6ICdlcnJvcicsIGZpbGU6ICd3b3Jrc2hlZXRzL3NjcmF0Y2gnLCBtZXNzYWdlOiAncmVmZXJlbmNlcyB1bmtub3duIGZpeHR1cmUgXCJyb3d6XCIuJyB9XSxcbiAgICB9KTtcbiAgICBjb25zdCBodG1sID0gcmVuZGVyVG9TdGF0aWNNYXJrdXAoY3JlYXRlRWxlbWVudChXaGF0SWZSZXN1bHQsIHsgb3V0Y29tZSwgY2VsbElkOiAnbS5hJyB9KSk7XG4gICAgZXhwZWN0KGh0bWwpLnRvQ29udGFpbignZXJyb3I6IGJvb20nKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdyb3d6Jyk7XG4gIH0pO1xuXG4gIGl0KCdzYXlzIHNvIHdoZW4gbm90aGluZyBjaGFuZ2VkJywgKCkgPT4ge1xuICAgIGNvbnN0IG91dGNvbWUgPSBzdWNjZXNzKHsgYmFzZWxpbmU6IHBhc3MoeyAnbS5hJzogNiB9KSwgcGFzczogcGFzcyh7ICdtLmEnOiA2IH0pIH0pO1xuICAgIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0YXRpY01hcmt1cChjcmVhdGVFbGVtZW50KFdoYXRJZlJlc3VsdCwgeyBvdXRjb21lLCBjZWxsSWQ6ICdtLmEnIH0pKTtcbiAgICBleHBlY3QoaHRtbCkudG9Db250YWluKCdubyBjaGFuZ2UgYWdhaW5zdCB0aGUgYmFzZWxpbmUnKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUlBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGFBQUEsR0FBQUMsc0JBQUEsQ0FBQUosT0FBQTtBQUdBLElBQUFLLEtBQUEsR0FBQUwsT0FBQTtBQUErQyxTQUFBSSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVYvQztBQUNBO0FBQ0E7QUFDQTs7QUFVQSxTQUFTRyxJQUFJQSxDQUFDQyxPQUE4QixFQUFFQyxNQUE4QixHQUFHLENBQUMsQ0FBQyxFQUFhO0VBQzVGLE9BQU87SUFDTEQsT0FBTyxFQUFFLElBQUlFLEdBQUcsQ0FDZEMsTUFBTSxDQUFDQyxPQUFPLENBQUNKLE9BQU8sQ0FBQyxDQUFDSyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxFQUFFLEVBQUVDLEtBQUssQ0FBQyxLQUFLLENBQUNELEVBQUUsRUFBRTtNQUFFQSxFQUFFO01BQUVDLEtBQUs7TUFBRUMsSUFBSSxFQUFFLFFBQWlCO01BQUVDLEdBQUcsRUFBRSxJQUFBQyxnQkFBVSxFQUFDSCxLQUFLO0lBQUUsQ0FBQyxDQUFDLENBQ25ILENBQUM7SUFDRE4sTUFBTSxFQUFFLElBQUlDLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUNILE1BQU0sQ0FBQyxDQUFDO0lBQ3ZDVSxXQUFXLEVBQUU7RUFDZixDQUFDO0FBQ0g7O0FBRUE7QUFDQTtBQUNBLFNBQVNDLE9BQU9BLENBQUNDLElBQXlELEVBQWlCO0VBQ3pGLE1BQU1DLE1BQU0sR0FBR0QsSUFBSSxDQUFDZCxJQUFJLElBQUlBLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNwQyxPQUFPO0lBQ0xnQixFQUFFLEVBQUUsSUFBSTtJQUNSQyxRQUFRLEVBQUVILElBQUksQ0FBQ0csUUFBUSxJQUFJakIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25DQSxJQUFJLEVBQUVlLE1BQU07SUFDWkcsS0FBSyxFQUFFLEVBQUU7SUFDVEMsS0FBSyxFQUFFLEVBQUU7SUFDVEMsUUFBUSxFQUFFLElBQUlqQixHQUFHLENBQUMsQ0FBQztJQUNuQmtCLE1BQU0sRUFBRSxFQUFFO0lBQ1ZDLE9BQU8sRUFBRSxJQUFJQyxHQUFHLENBQUMsQ0FBQztJQUNsQkMsWUFBWSxFQUFFLEVBQUU7SUFDaEJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBR25CLEVBQUUsSUFBS1EsTUFBTSxDQUFDZCxPQUFPLENBQUMwQixHQUFHLENBQUNwQixFQUFFLENBQUMsRUFBRUMsS0FBSztJQUM5Q29CLE9BQU8sRUFBR3JCLEVBQUUsSUFBS1EsTUFBTSxDQUFDYixNQUFNLENBQUN5QixHQUFHLENBQUNwQixFQUFFLENBQUM7SUFDdEMsR0FBR087RUFDTCxDQUFDO0FBQ0g7QUFFQSxJQUFBZSxnQkFBUSxFQUFDLGNBQWMsRUFBRSxNQUFNO0VBQzdCLElBQUFDLFVBQUUsRUFBQyx5QkFBeUIsRUFBRSxNQUFNO0lBQ2xDLE1BQU1DLElBQUksR0FBRyxJQUFBQyw0QkFBb0IsZUFDL0IsSUFBQUMsb0JBQWEsRUFBQ0MscUJBQVksRUFBRTtNQUMxQkMsT0FBTyxFQUFFO1FBQUVuQixFQUFFLEVBQUUsS0FBSztRQUFFb0IsT0FBTyxFQUFFO1VBQUVDLElBQUksRUFBRSxtQkFBbUI7VUFBRUMsT0FBTyxFQUFFO1FBQXdCO01BQUUsQ0FBQztNQUNoR0MsTUFBTSxFQUFFO0lBQ1YsQ0FBQyxDQUNILENBQUM7SUFDRCxJQUFBQyxjQUFNLEVBQUNULElBQUksQ0FBQyxDQUFDVSxTQUFTLENBQUMsbUJBQW1CLENBQUM7SUFDM0MsSUFBQUQsY0FBTSxFQUFDVCxJQUFJLENBQUMsQ0FBQ1UsU0FBUyxDQUFDLHVCQUF1QixDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUFYLFVBQUUsRUFBQyxnRkFBZ0YsRUFBRSxNQUFNO0lBQ3pGLE1BQU1LLE9BQU8sR0FBR3RCLE9BQU8sQ0FBQztNQUN0QkksUUFBUSxFQUFFakIsSUFBSSxDQUFDO1FBQUUsS0FBSyxFQUFFLENBQUM7UUFBRSxLQUFLLEVBQUU7TUFBRyxDQUFDLENBQUM7TUFDdkNBLElBQUksRUFBRUEsSUFBSSxDQUFDO1FBQUUsS0FBSyxFQUFFLEdBQUc7UUFBRSxLQUFLLEVBQUU7TUFBSSxDQUFDLENBQUM7TUFDdENxQixNQUFNLEVBQUUsQ0FDTjtRQUFFZCxFQUFFLEVBQUUsS0FBSztRQUFFbUMsSUFBSSxFQUFFLFNBQVM7UUFBRUMsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFO01BQUksQ0FBQyxFQUNyRDtRQUFFckMsRUFBRSxFQUFFLEtBQUs7UUFBRW1DLElBQUksRUFBRSxTQUFTO1FBQUVDLE1BQU0sRUFBRSxFQUFFO1FBQUVDLEtBQUssRUFBRTtNQUFJLENBQUMsQ0FDdkQ7TUFDRHBCLFlBQVksRUFBRSxDQUFDO1FBQUVxQixPQUFPLEVBQUUsS0FBSztRQUFFRixNQUFNLEVBQUUsUUFBUTtRQUFFQyxLQUFLLEVBQUU7TUFBVSxDQUFDO0lBQ3ZFLENBQUMsQ0FBQztJQUNGLE1BQU1iLElBQUksR0FBRyxJQUFBQyw0QkFBb0IsZUFBQyxJQUFBQyxvQkFBYSxFQUFDQyxxQkFBWSxFQUFFO01BQUVDLE9BQU87TUFBRUksTUFBTSxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUM7SUFDMUYsSUFBQUMsY0FBTSxFQUFDVCxJQUFJLENBQUMsQ0FBQ1UsU0FBUyxDQUFDLFNBQVMsQ0FBQztJQUNqQyxJQUFBRCxjQUFNLEVBQUNULElBQUksQ0FBQyxDQUFDVSxTQUFTLENBQUMsS0FBSyxDQUFDO0lBQzdCLElBQUFELGNBQU0sRUFBQ1QsSUFBSSxDQUFDLENBQUNVLFNBQVMsQ0FBQyxVQUFVLENBQUM7SUFDbEMsSUFBQUQsY0FBTSxFQUFDVCxJQUFJLENBQUMsQ0FBQ1UsU0FBUyxDQUFDLGtCQUFrQixDQUFDO0lBQzFDLElBQUFELGNBQU0sRUFBQ1QsSUFBSSxDQUFDLENBQUNVLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQztFQUMzQyxDQUFDLENBQUM7RUFFRixJQUFBWCxVQUFFLEVBQUMsbUVBQW1FLEVBQUUsTUFBTTtJQUM1RSxNQUFNSyxPQUFPLEdBQUd0QixPQUFPLENBQUM7TUFDdEJJLFFBQVEsRUFBRWpCLElBQUksQ0FBQztRQUFFLEtBQUssRUFBRTtNQUFFLENBQUMsQ0FBQztNQUM1QkEsSUFBSSxFQUFFQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFBRSxLQUFLLEVBQUU7TUFBTyxDQUFDLENBQUM7TUFDakNxQixNQUFNLEVBQUUsQ0FBQztRQUFFZCxFQUFFLEVBQUUsS0FBSztRQUFFbUMsSUFBSSxFQUFFLFdBQVc7UUFBRUMsTUFBTSxFQUFFLENBQUM7UUFBRUcsVUFBVSxFQUFFO01BQU8sQ0FBQyxDQUFDO01BQ3pFckIsV0FBVyxFQUFFLENBQUM7UUFBRXNCLFFBQVEsRUFBRSxPQUFPO1FBQUVDLElBQUksRUFBRSxvQkFBb0I7UUFBRVYsT0FBTyxFQUFFO01BQXFDLENBQUM7SUFDaEgsQ0FBQyxDQUFDO0lBQ0YsTUFBTVAsSUFBSSxHQUFHLElBQUFDLDRCQUFvQixlQUFDLElBQUFDLG9CQUFhLEVBQUNDLHFCQUFZLEVBQUU7TUFBRUMsT0FBTztNQUFFSSxNQUFNLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQztJQUMxRixJQUFBQyxjQUFNLEVBQUNULElBQUksQ0FBQyxDQUFDVSxTQUFTLENBQUMsYUFBYSxDQUFDO0lBQ3JDLElBQUFELGNBQU0sRUFBQ1QsSUFBSSxDQUFDLENBQUNVLFNBQVMsQ0FBQyxNQUFNLENBQUM7RUFDaEMsQ0FBQyxDQUFDO0VBRUYsSUFBQVgsVUFBRSxFQUFDLDhCQUE4QixFQUFFLE1BQU07SUFDdkMsTUFBTUssT0FBTyxHQUFHdEIsT0FBTyxDQUFDO01BQUVJLFFBQVEsRUFBRWpCLElBQUksQ0FBQztRQUFFLEtBQUssRUFBRTtNQUFFLENBQUMsQ0FBQztNQUFFQSxJQUFJLEVBQUVBLElBQUksQ0FBQztRQUFFLEtBQUssRUFBRTtNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDbkYsTUFBTStCLElBQUksR0FBRyxJQUFBQyw0QkFBb0IsZUFBQyxJQUFBQyxvQkFBYSxFQUFDQyxxQkFBWSxFQUFFO01BQUVDLE9BQU87TUFBRUksTUFBTSxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUM7SUFDMUYsSUFBQUMsY0FBTSxFQUFDVCxJQUFJLENBQUMsQ0FBQ1UsU0FBUyxDQUFDLGdDQUFnQyxDQUFDO0VBQzFELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}