"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validateExternalReferences = validateExternalReferences;
exports.validateFixtureProvenance = validateFixtureProvenance;
// Cross-reference validation (the deferred item in the barrel header). Two dangling-reference
// classes that otherwise surface as *silent nulls* at run time — a cell reading `feeds.ghost`
// resolves null forever and the report shows a blank where a number should be, with nothing
// saying why:
//
//   1. a worksheet input naming a feed/fixture the document does not declare (needs the
//      evaluated workbook's external references, so it is composed app-side where the
//      engine and the loaded document meet — `validateExternalReferences`);
//   2. a fixture's `sourceFeed` naming a missing feed (pure document knowledge — the loader
//      runs it directly — `validateFixtureProvenance`).
//
// Severity is a function of how *suppliable* the missing thing is: feeds/fixtures/statics
// name document-declared sources, so a miss is an error. Params are runtime-suppliable (a
// host or a widget may set a param the manifest does not default) — a warning, a probable
// typo. And fixture provenance is *historical*, not live (freezing detaches a fixture from
// its feed, §5.4), so a miss there is a warning too — interesting only if the author
// believed the fixture refreshable.

/** One external a worksheet declares: the key it reads, the cell that reads it. */

/** What a document (+ the app running it) can actually supply. */

/**
 * Validate every worksheet external reference against what is suppliable. `feeds.*` /
 * `fixtures.*` / `static.*` name document-declared sources — a miss is an error. `params.*`
 * is a warning. Unknown namespaces are left alone: worksheet-cell references are resolved
 * by the graph builder, which already diagnoses them.
 */
function validateExternalReferences(references, available) {
  const out = [];
  for (const {
    key,
    site
  } of references) {
    const sep = key.indexOf('.');
    if (sep === -1) continue;
    const ns = key.slice(0, sep);
    const name = key.slice(sep + 1);
    const file = available.worksheetPaths[site.slice(0, site.indexOf('.'))] ?? '';
    if (ns === 'feeds') {
      if (!available.feeds.has(name)) {
        out.push({
          severity: 'error',
          file,
          message: `input "${key}" (${site}): no feed named "${name}" is declared — the document's feeds/ directory${name === '' ? ' ' : ` (${[...available.feeds].join(', ')}) `}does not declare it, and no runtime feed supplies it. The cell resolves null.`
        });
      }
    } else if (ns === 'fixtures') {
      if (!available.fixtures.has(name)) {
        out.push({
          severity: 'error',
          file,
          message: `input "${key}" (${site}): no fixture named "${name}" exists in fixtures/ (have: ${[...available.fixtures].join(', ') || 'none'}). The cell resolves null.`
        });
      }
    } else if (ns === 'static') {
      // Nothing declares static values today — the namespace is reserved (§3.1) with no
      // document section for it yet, so any read is currently a structural null.
      out.push({
        severity: 'error',
        file,
        message: `input "${key}" (${site}): the static namespace is not declared by any document section yet — nothing can supply this value. The cell resolves null.`
      });
    } else if (ns === 'params') {
      if (!available.params.has(name)) {
        out.push({
          severity: 'warning',
          file,
          message: `input "${key}" (${site}): no default for param "${name}" in the manifest and no widget sets it — a probable typo (known params: ${[...available.params].join(', ') || 'none'}).`
        });
      }
    }
  }
  return out;
}

/**
 * Validate every fixture's capture provenance against the document's declared feeds. A
 * frame citing `sourceFeed: "orders"` when `feeds/order.feed.json` does not exist is
 * **historical provenance, not a live dependency** — freezing is exactly how a fixture
 * detaches from its feed (§5.4), and a fully-frozen document (the bundled demo is one)
 * legitimately cites feeds it no longer declares. So a miss is a *warning*: uninteresting
 * for a frozen snapshot, but exactly what an author wants to hear if they thought the
 * fixture was still refreshable from a declared feed. Synthetic fixtures legitimately carry
 * no `sourceFeed`.
 */
function validateFixtureProvenance(fixtures, declaredFeeds) {
  const out = [];
  for (const fx of fixtures) {
    const source = fx.frame.provenance.sourceFeed;
    if (source !== undefined && !declaredFeeds.has(source)) {
      out.push({
        severity: 'warning',
        file: fx.path,
        message: `fixture "${fx.name}" cites sourceFeed "${source}", which this document does not declare (declared: ${[...declaredFeeds].join(', ') || 'none'}) — fine for a frozen snapshot; declare the feed if this fixture is meant to be refreshable.`
      });
    }
  }
  return out;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ2YWxpZGF0ZUV4dGVybmFsUmVmZXJlbmNlcyIsInJlZmVyZW5jZXMiLCJhdmFpbGFibGUiLCJvdXQiLCJrZXkiLCJzaXRlIiwic2VwIiwiaW5kZXhPZiIsIm5zIiwic2xpY2UiLCJuYW1lIiwiZmlsZSIsIndvcmtzaGVldFBhdGhzIiwiZmVlZHMiLCJoYXMiLCJwdXNoIiwic2V2ZXJpdHkiLCJtZXNzYWdlIiwiam9pbiIsImZpeHR1cmVzIiwicGFyYW1zIiwidmFsaWRhdGVGaXh0dXJlUHJvdmVuYW5jZSIsImRlY2xhcmVkRmVlZHMiLCJmeCIsInNvdXJjZSIsImZyYW1lIiwicHJvdmVuYW5jZSIsInNvdXJjZUZlZWQiLCJ1bmRlZmluZWQiLCJwYXRoIl0sInNvdXJjZXMiOlsieHJlZi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvbiAodGhlIGRlZmVycmVkIGl0ZW0gaW4gdGhlIGJhcnJlbCBoZWFkZXIpLiBUd28gZGFuZ2xpbmctcmVmZXJlbmNlXG4vLyBjbGFzc2VzIHRoYXQgb3RoZXJ3aXNlIHN1cmZhY2UgYXMgKnNpbGVudCBudWxscyogYXQgcnVuIHRpbWUg4oCUIGEgY2VsbCByZWFkaW5nIGBmZWVkcy5naG9zdGBcbi8vIHJlc29sdmVzIG51bGwgZm9yZXZlciBhbmQgdGhlIHJlcG9ydCBzaG93cyBhIGJsYW5rIHdoZXJlIGEgbnVtYmVyIHNob3VsZCBiZSwgd2l0aCBub3RoaW5nXG4vLyBzYXlpbmcgd2h5OlxuLy9cbi8vICAgMS4gYSB3b3Jrc2hlZXQgaW5wdXQgbmFtaW5nIGEgZmVlZC9maXh0dXJlIHRoZSBkb2N1bWVudCBkb2VzIG5vdCBkZWNsYXJlIChuZWVkcyB0aGVcbi8vICAgICAgZXZhbHVhdGVkIHdvcmtib29rJ3MgZXh0ZXJuYWwgcmVmZXJlbmNlcywgc28gaXQgaXMgY29tcG9zZWQgYXBwLXNpZGUgd2hlcmUgdGhlXG4vLyAgICAgIGVuZ2luZSBhbmQgdGhlIGxvYWRlZCBkb2N1bWVudCBtZWV0IOKAlCBgdmFsaWRhdGVFeHRlcm5hbFJlZmVyZW5jZXNgKTtcbi8vICAgMi4gYSBmaXh0dXJlJ3MgYHNvdXJjZUZlZWRgIG5hbWluZyBhIG1pc3NpbmcgZmVlZCAocHVyZSBkb2N1bWVudCBrbm93bGVkZ2Ug4oCUIHRoZSBsb2FkZXJcbi8vICAgICAgcnVucyBpdCBkaXJlY3RseSDigJQgYHZhbGlkYXRlRml4dHVyZVByb3ZlbmFuY2VgKS5cbi8vXG4vLyBTZXZlcml0eSBpcyBhIGZ1bmN0aW9uIG9mIGhvdyAqc3VwcGxpYWJsZSogdGhlIG1pc3NpbmcgdGhpbmcgaXM6IGZlZWRzL2ZpeHR1cmVzL3N0YXRpY3Ncbi8vIG5hbWUgZG9jdW1lbnQtZGVjbGFyZWQgc291cmNlcywgc28gYSBtaXNzIGlzIGFuIGVycm9yLiBQYXJhbXMgYXJlIHJ1bnRpbWUtc3VwcGxpYWJsZSAoYVxuLy8gaG9zdCBvciBhIHdpZGdldCBtYXkgc2V0IGEgcGFyYW0gdGhlIG1hbmlmZXN0IGRvZXMgbm90IGRlZmF1bHQpIOKAlCBhIHdhcm5pbmcsIGEgcHJvYmFibGVcbi8vIHR5cG8uIEFuZCBmaXh0dXJlIHByb3ZlbmFuY2UgaXMgKmhpc3RvcmljYWwqLCBub3QgbGl2ZSAoZnJlZXppbmcgZGV0YWNoZXMgYSBmaXh0dXJlIGZyb21cbi8vIGl0cyBmZWVkLCDCpzUuNCksIHNvIGEgbWlzcyB0aGVyZSBpcyBhIHdhcm5pbmcgdG9vIOKAlCBpbnRlcmVzdGluZyBvbmx5IGlmIHRoZSBhdXRob3Jcbi8vIGJlbGlldmVkIHRoZSBmaXh0dXJlIHJlZnJlc2hhYmxlLlxuXG5pbXBvcnQgdHlwZSB7IERvY3VtZW50RGlhZ25vc3RpYywgRml4dHVyZUZpbGUgfSBmcm9tICcuL3R5cGVzLnRzJztcblxuLyoqIE9uZSBleHRlcm5hbCBhIHdvcmtzaGVldCBkZWNsYXJlczogdGhlIGtleSBpdCByZWFkcywgdGhlIGNlbGwgdGhhdCByZWFkcyBpdC4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRXh0ZXJuYWxSZWZlcmVuY2Uge1xuICAvKiogVGhlIGRvdHRlZCBrZXkgYXMgZGVjbGFyZWQ6IGBmZWVkcy5vcmRlcnNgLCBgZml4dHVyZXMuaG9sZG91dGAsIGBwYXJhbXMucmVnaW9uYCwg4oCmICovXG4gIGtleTogc3RyaW5nO1xuICAvKiogVGhlIGRlY2xhcmluZyBjZWxsIChgd29ya3NoZWV0LmNlbGxgKSwgZm9yIGFuY2hvcmluZyB0aGUgZGlhZ25vc3RpYy4gKi9cbiAgc2l0ZTogc3RyaW5nO1xufVxuXG4vKiogV2hhdCBhIGRvY3VtZW50ICgrIHRoZSBhcHAgcnVubmluZyBpdCkgY2FuIGFjdHVhbGx5IHN1cHBseS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgWFJlZkF2YWlsYWJpbGl0eSB7XG4gIC8qKiBGZWVkIG5hbWVzIHN1cHBsaWFibGUgbm93OiB0aGUgZG9jdW1lbnQncyBkZWNsYXJlZCBmZWVkcyBwbHVzIGFueSBydW50aW1lIGZlZWRzLiAqL1xuICBmZWVkczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgLyoqIFRoZSBkb2N1bWVudCdzIGZpeHR1cmUgbmFtZXMuICovXG4gIGZpeHR1cmVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xuICAvKiogUGFyYW0gbmFtZXMgc3RhdGljYWxseSBrbm93bjogbWFuaWZlc3QgZGVmYXVsdHMgKyB0ZW1wbGF0ZSB3aWRnZXQgbmFtZXMuICovXG4gIHBhcmFtczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgLyoqIFdvcmtzaGVldCBuYW1lIOKGkiBkb2N1bWVudC1yZWxhdGl2ZSBwYXRoLCB0byBhbmNob3IgZGlhZ25vc3RpY3MgYXQgdGhlIGRlY2xhcmluZyBmaWxlLiAqL1xuICB3b3Jrc2hlZXRQYXRoczogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbn1cblxuLyoqXG4gKiBWYWxpZGF0ZSBldmVyeSB3b3Jrc2hlZXQgZXh0ZXJuYWwgcmVmZXJlbmNlIGFnYWluc3Qgd2hhdCBpcyBzdXBwbGlhYmxlLiBgZmVlZHMuKmAgL1xuICogYGZpeHR1cmVzLipgIC8gYHN0YXRpYy4qYCBuYW1lIGRvY3VtZW50LWRlY2xhcmVkIHNvdXJjZXMg4oCUIGEgbWlzcyBpcyBhbiBlcnJvci4gYHBhcmFtcy4qYFxuICogaXMgYSB3YXJuaW5nLiBVbmtub3duIG5hbWVzcGFjZXMgYXJlIGxlZnQgYWxvbmU6IHdvcmtzaGVldC1jZWxsIHJlZmVyZW5jZXMgYXJlIHJlc29sdmVkXG4gKiBieSB0aGUgZ3JhcGggYnVpbGRlciwgd2hpY2ggYWxyZWFkeSBkaWFnbm9zZXMgdGhlbS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlRXh0ZXJuYWxSZWZlcmVuY2VzKFxuICByZWZlcmVuY2VzOiByZWFkb25seSBFeHRlcm5hbFJlZmVyZW5jZVtdLFxuICBhdmFpbGFibGU6IFhSZWZBdmFpbGFiaWxpdHksXG4pOiBEb2N1bWVudERpYWdub3N0aWNbXSB7XG4gIGNvbnN0IG91dDogRG9jdW1lbnREaWFnbm9zdGljW10gPSBbXTtcbiAgZm9yIChjb25zdCB7IGtleSwgc2l0ZSB9IG9mIHJlZmVyZW5jZXMpIHtcbiAgICBjb25zdCBzZXAgPSBrZXkuaW5kZXhPZignLicpO1xuICAgIGlmIChzZXAgPT09IC0xKSBjb250aW51ZTtcbiAgICBjb25zdCBucyA9IGtleS5zbGljZSgwLCBzZXApO1xuICAgIGNvbnN0IG5hbWUgPSBrZXkuc2xpY2Uoc2VwICsgMSk7XG4gICAgY29uc3QgZmlsZSA9IGF2YWlsYWJsZS53b3Jrc2hlZXRQYXRoc1tzaXRlLnNsaWNlKDAsIHNpdGUuaW5kZXhPZignLicpKV0gPz8gJyc7XG4gICAgaWYgKG5zID09PSAnZmVlZHMnKSB7XG4gICAgICBpZiAoIWF2YWlsYWJsZS5mZWVkcy5oYXMobmFtZSkpIHtcbiAgICAgICAgb3V0LnB1c2goe1xuICAgICAgICAgIHNldmVyaXR5OiAnZXJyb3InLFxuICAgICAgICAgIGZpbGUsXG4gICAgICAgICAgbWVzc2FnZTogYGlucHV0IFwiJHtrZXl9XCIgKCR7c2l0ZX0pOiBubyBmZWVkIG5hbWVkIFwiJHtuYW1lfVwiIGlzIGRlY2xhcmVkIOKAlCB0aGUgZG9jdW1lbnQncyBmZWVkcy8gZGlyZWN0b3J5JHtuYW1lID09PSAnJyA/ICcgJyA6IGAgKCR7Wy4uLmF2YWlsYWJsZS5mZWVkc10uam9pbignLCAnKX0pIGB9ZG9lcyBub3QgZGVjbGFyZSBpdCwgYW5kIG5vIHJ1bnRpbWUgZmVlZCBzdXBwbGllcyBpdC4gVGhlIGNlbGwgcmVzb2x2ZXMgbnVsbC5gLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKG5zID09PSAnZml4dHVyZXMnKSB7XG4gICAgICBpZiAoIWF2YWlsYWJsZS5maXh0dXJlcy5oYXMobmFtZSkpIHtcbiAgICAgICAgb3V0LnB1c2goe1xuICAgICAgICAgIHNldmVyaXR5OiAnZXJyb3InLFxuICAgICAgICAgIGZpbGUsXG4gICAgICAgICAgbWVzc2FnZTogYGlucHV0IFwiJHtrZXl9XCIgKCR7c2l0ZX0pOiBubyBmaXh0dXJlIG5hbWVkIFwiJHtuYW1lfVwiIGV4aXN0cyBpbiBmaXh0dXJlcy8gKGhhdmU6ICR7Wy4uLmF2YWlsYWJsZS5maXh0dXJlc10uam9pbignLCAnKSB8fCAnbm9uZSd9KS4gVGhlIGNlbGwgcmVzb2x2ZXMgbnVsbC5gLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKG5zID09PSAnc3RhdGljJykge1xuICAgICAgLy8gTm90aGluZyBkZWNsYXJlcyBzdGF0aWMgdmFsdWVzIHRvZGF5IOKAlCB0aGUgbmFtZXNwYWNlIGlzIHJlc2VydmVkICjCpzMuMSkgd2l0aCBub1xuICAgICAgLy8gZG9jdW1lbnQgc2VjdGlvbiBmb3IgaXQgeWV0LCBzbyBhbnkgcmVhZCBpcyBjdXJyZW50bHkgYSBzdHJ1Y3R1cmFsIG51bGwuXG4gICAgICBvdXQucHVzaCh7XG4gICAgICAgIHNldmVyaXR5OiAnZXJyb3InLFxuICAgICAgICBmaWxlLFxuICAgICAgICBtZXNzYWdlOiBgaW5wdXQgXCIke2tleX1cIiAoJHtzaXRlfSk6IHRoZSBzdGF0aWMgbmFtZXNwYWNlIGlzIG5vdCBkZWNsYXJlZCBieSBhbnkgZG9jdW1lbnQgc2VjdGlvbiB5ZXQg4oCUIG5vdGhpbmcgY2FuIHN1cHBseSB0aGlzIHZhbHVlLiBUaGUgY2VsbCByZXNvbHZlcyBudWxsLmAsXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKG5zID09PSAncGFyYW1zJykge1xuICAgICAgaWYgKCFhdmFpbGFibGUucGFyYW1zLmhhcyhuYW1lKSkge1xuICAgICAgICBvdXQucHVzaCh7XG4gICAgICAgICAgc2V2ZXJpdHk6ICd3YXJuaW5nJyxcbiAgICAgICAgICBmaWxlLFxuICAgICAgICAgIG1lc3NhZ2U6IGBpbnB1dCBcIiR7a2V5fVwiICgke3NpdGV9KTogbm8gZGVmYXVsdCBmb3IgcGFyYW0gXCIke25hbWV9XCIgaW4gdGhlIG1hbmlmZXN0IGFuZCBubyB3aWRnZXQgc2V0cyBpdCDigJQgYSBwcm9iYWJsZSB0eXBvIChrbm93biBwYXJhbXM6ICR7Wy4uLmF2YWlsYWJsZS5wYXJhbXNdLmpvaW4oJywgJykgfHwgJ25vbmUnfSkuYCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVmFsaWRhdGUgZXZlcnkgZml4dHVyZSdzIGNhcHR1cmUgcHJvdmVuYW5jZSBhZ2FpbnN0IHRoZSBkb2N1bWVudCdzIGRlY2xhcmVkIGZlZWRzLiBBXG4gKiBmcmFtZSBjaXRpbmcgYHNvdXJjZUZlZWQ6IFwib3JkZXJzXCJgIHdoZW4gYGZlZWRzL29yZGVyLmZlZWQuanNvbmAgZG9lcyBub3QgZXhpc3QgaXNcbiAqICoqaGlzdG9yaWNhbCBwcm92ZW5hbmNlLCBub3QgYSBsaXZlIGRlcGVuZGVuY3kqKiDigJQgZnJlZXppbmcgaXMgZXhhY3RseSBob3cgYSBmaXh0dXJlXG4gKiBkZXRhY2hlcyBmcm9tIGl0cyBmZWVkICjCpzUuNCksIGFuZCBhIGZ1bGx5LWZyb3plbiBkb2N1bWVudCAodGhlIGJ1bmRsZWQgZGVtbyBpcyBvbmUpXG4gKiBsZWdpdGltYXRlbHkgY2l0ZXMgZmVlZHMgaXQgbm8gbG9uZ2VyIGRlY2xhcmVzLiBTbyBhIG1pc3MgaXMgYSAqd2FybmluZyo6IHVuaW50ZXJlc3RpbmdcbiAqIGZvciBhIGZyb3plbiBzbmFwc2hvdCwgYnV0IGV4YWN0bHkgd2hhdCBhbiBhdXRob3Igd2FudHMgdG8gaGVhciBpZiB0aGV5IHRob3VnaHQgdGhlXG4gKiBmaXh0dXJlIHdhcyBzdGlsbCByZWZyZXNoYWJsZSBmcm9tIGEgZGVjbGFyZWQgZmVlZC4gU3ludGhldGljIGZpeHR1cmVzIGxlZ2l0aW1hdGVseSBjYXJyeVxuICogbm8gYHNvdXJjZUZlZWRgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVGaXh0dXJlUHJvdmVuYW5jZShcbiAgZml4dHVyZXM6IHJlYWRvbmx5IEZpeHR1cmVGaWxlW10sXG4gIGRlY2xhcmVkRmVlZHM6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4pOiBEb2N1bWVudERpYWdub3N0aWNbXSB7XG4gIGNvbnN0IG91dDogRG9jdW1lbnREaWFnbm9zdGljW10gPSBbXTtcbiAgZm9yIChjb25zdCBmeCBvZiBmaXh0dXJlcykge1xuICAgIGNvbnN0IHNvdXJjZSA9IGZ4LmZyYW1lLnByb3ZlbmFuY2Uuc291cmNlRmVlZDtcbiAgICBpZiAoc291cmNlICE9PSB1bmRlZmluZWQgJiYgIWRlY2xhcmVkRmVlZHMuaGFzKHNvdXJjZSkpIHtcbiAgICAgIG91dC5wdXNoKHtcbiAgICAgICAgc2V2ZXJpdHk6ICd3YXJuaW5nJyxcbiAgICAgICAgZmlsZTogZngucGF0aCxcbiAgICAgICAgbWVzc2FnZTogYGZpeHR1cmUgXCIke2Z4Lm5hbWV9XCIgY2l0ZXMgc291cmNlRmVlZCBcIiR7c291cmNlfVwiLCB3aGljaCB0aGlzIGRvY3VtZW50IGRvZXMgbm90IGRlY2xhcmUgKGRlY2xhcmVkOiAke1suLi5kZWNsYXJlZEZlZWRzXS5qb2luKCcsICcpIHx8ICdub25lJ30pIOKAlCBmaW5lIGZvciBhIGZyb3plbiBzbmFwc2hvdDsgZGVjbGFyZSB0aGUgZmVlZCBpZiB0aGlzIGZpeHR1cmUgaXMgbWVhbnQgdG8gYmUgcmVmcmVzaGFibGUuYCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTs7QUFRQTs7QUFZQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTQSwwQkFBMEJBLENBQ3hDQyxVQUF3QyxFQUN4Q0MsU0FBMkIsRUFDTDtFQUN0QixNQUFNQyxHQUF5QixHQUFHLEVBQUU7RUFDcEMsS0FBSyxNQUFNO0lBQUVDLEdBQUc7SUFBRUM7RUFBSyxDQUFDLElBQUlKLFVBQVUsRUFBRTtJQUN0QyxNQUFNSyxHQUFHLEdBQUdGLEdBQUcsQ0FBQ0csT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUM1QixJQUFJRCxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUU7SUFDaEIsTUFBTUUsRUFBRSxHQUFHSixHQUFHLENBQUNLLEtBQUssQ0FBQyxDQUFDLEVBQUVILEdBQUcsQ0FBQztJQUM1QixNQUFNSSxJQUFJLEdBQUdOLEdBQUcsQ0FBQ0ssS0FBSyxDQUFDSCxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLE1BQU1LLElBQUksR0FBR1QsU0FBUyxDQUFDVSxjQUFjLENBQUNQLElBQUksQ0FBQ0ksS0FBSyxDQUFDLENBQUMsRUFBRUosSUFBSSxDQUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7SUFDN0UsSUFBSUMsRUFBRSxLQUFLLE9BQU8sRUFBRTtNQUNsQixJQUFJLENBQUNOLFNBQVMsQ0FBQ1csS0FBSyxDQUFDQyxHQUFHLENBQUNKLElBQUksQ0FBQyxFQUFFO1FBQzlCUCxHQUFHLENBQUNZLElBQUksQ0FBQztVQUNQQyxRQUFRLEVBQUUsT0FBTztVQUNqQkwsSUFBSTtVQUNKTSxPQUFPLEVBQUUsVUFBVWIsR0FBRyxNQUFNQyxJQUFJLHFCQUFxQkssSUFBSSxrREFBa0RBLElBQUksS0FBSyxFQUFFLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHUixTQUFTLENBQUNXLEtBQUssQ0FBQyxDQUFDSyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUk7UUFDekssQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDLE1BQU0sSUFBSVYsRUFBRSxLQUFLLFVBQVUsRUFBRTtNQUM1QixJQUFJLENBQUNOLFNBQVMsQ0FBQ2lCLFFBQVEsQ0FBQ0wsR0FBRyxDQUFDSixJQUFJLENBQUMsRUFBRTtRQUNqQ1AsR0FBRyxDQUFDWSxJQUFJLENBQUM7VUFDUEMsUUFBUSxFQUFFLE9BQU87VUFDakJMLElBQUk7VUFDSk0sT0FBTyxFQUFFLFVBQVViLEdBQUcsTUFBTUMsSUFBSSx3QkFBd0JLLElBQUksZ0NBQWdDLENBQUMsR0FBR1IsU0FBUyxDQUFDaUIsUUFBUSxDQUFDLENBQUNELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNO1FBQzFJLENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQyxNQUFNLElBQUlWLEVBQUUsS0FBSyxRQUFRLEVBQUU7TUFDMUI7TUFDQTtNQUNBTCxHQUFHLENBQUNZLElBQUksQ0FBQztRQUNQQyxRQUFRLEVBQUUsT0FBTztRQUNqQkwsSUFBSTtRQUNKTSxPQUFPLEVBQUUsVUFBVWIsR0FBRyxNQUFNQyxJQUFJO01BQ2xDLENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTSxJQUFJRyxFQUFFLEtBQUssUUFBUSxFQUFFO01BQzFCLElBQUksQ0FBQ04sU0FBUyxDQUFDa0IsTUFBTSxDQUFDTixHQUFHLENBQUNKLElBQUksQ0FBQyxFQUFFO1FBQy9CUCxHQUFHLENBQUNZLElBQUksQ0FBQztVQUNQQyxRQUFRLEVBQUUsU0FBUztVQUNuQkwsSUFBSTtVQUNKTSxPQUFPLEVBQUUsVUFBVWIsR0FBRyxNQUFNQyxJQUFJLDRCQUE0QkssSUFBSSw0RUFBNEUsQ0FBQyxHQUFHUixTQUFTLENBQUNrQixNQUFNLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU07UUFDeEwsQ0FBQyxDQUFDO01BQ0o7SUFDRjtFQUNGO0VBQ0EsT0FBT2YsR0FBRztBQUNaOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2tCLHlCQUF5QkEsQ0FDdkNGLFFBQWdDLEVBQ2hDRyxhQUFrQyxFQUNaO0VBQ3RCLE1BQU1uQixHQUF5QixHQUFHLEVBQUU7RUFDcEMsS0FBSyxNQUFNb0IsRUFBRSxJQUFJSixRQUFRLEVBQUU7SUFDekIsTUFBTUssTUFBTSxHQUFHRCxFQUFFLENBQUNFLEtBQUssQ0FBQ0MsVUFBVSxDQUFDQyxVQUFVO0lBQzdDLElBQUlILE1BQU0sS0FBS0ksU0FBUyxJQUFJLENBQUNOLGFBQWEsQ0FBQ1IsR0FBRyxDQUFDVSxNQUFNLENBQUMsRUFBRTtNQUN0RHJCLEdBQUcsQ0FBQ1ksSUFBSSxDQUFDO1FBQ1BDLFFBQVEsRUFBRSxTQUFTO1FBQ25CTCxJQUFJLEVBQUVZLEVBQUUsQ0FBQ00sSUFBSTtRQUNiWixPQUFPLEVBQUUsWUFBWU0sRUFBRSxDQUFDYixJQUFJLHVCQUF1QmMsTUFBTSxzREFBc0QsQ0FBQyxHQUFHRixhQUFhLENBQUMsQ0FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU07TUFDeEosQ0FBQyxDQUFDO0lBQ0o7RUFDRjtFQUNBLE9BQU9mLEdBQUc7QUFDWiIsImlnbm9yZUxpc3QiOltdfQ==