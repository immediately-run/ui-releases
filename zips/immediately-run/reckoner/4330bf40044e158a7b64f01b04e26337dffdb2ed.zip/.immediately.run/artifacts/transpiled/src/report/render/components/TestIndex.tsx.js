var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TestIndex;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _attrs = require("../attrs.ts");
var _reflectionContext = require("../reflectionContext.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // TestIndex — the reflection component listing the workbook's test assets
// (AUTHORS_VIEW_SPEC §2): kind label, subject, name, and the latest computed outcome
// (pass/fail + message; a pending suite shows the distinct pending state, never a
// fabricated outcome). Filters are typed and refuse unknown targets with a broken tile.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function TestIndex({
  node
}) {
  _s();
  const reflection = (0, _reflectionContext.useReflection)();
  const worksheet = (0, _attrs.attrString)(node, 'worksheet');
  const subject = (0, _attrs.attrString)(node, 'subject');
  if (reflection === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "TestIndex",
      reason: "available only in the author's view"
    });
  }
  let tests = reflection.tests();
  if (worksheet !== undefined) {
    if (!tests.some(t => t.worksheet === worksheet) && !reflection.cells().some(c => c.worksheet === worksheet)) {
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
        component: "TestIndex",
        reason: `unknown worksheet "${worksheet}"`
      });
    }
    tests = tests.filter(t => t.worksheet === worksheet);
  }
  if (subject !== undefined) {
    if (!reflection.cells().some(c => c.id === subject)) {
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
        component: "TestIndex",
        reason: `unknown subject "${subject}"`
      });
    }
    tests = tests.filter(t => t.subject === subject);
  }
  if (tests.length === 0) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-refl-none",
      children: ["no tests declared", worksheet !== undefined || subject !== undefined ? ' for this filter' : '', "."]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rk-refl-index",
    children: tests.map(t => {
      const outcome = reflection.verdicts === null ? undefined : reflection.verdicts.get(t.subject)?.outcomes.find(o => o.id === t.id);
      const outcomeLabel = reflection.verdicts === null ? 'pending' : outcome === undefined ? '—' : outcome.pass ? 'pass' : 'fail';
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: `rk-refl-test ${outcome?.pass === false ? 'rk-refl-test--fail' : ''}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-kind",
          children: t.kind
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-name",
          children: t.name
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "rk-refl-subject",
          children: ["\u2192 ", t.subject]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "rk-refl-outcome",
          children: outcomeLabel
        }), outcome !== undefined && !outcome.pass && outcome.message !== '' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "rk-refl-test-msg",
          children: outcome.message
        })]
      }, t.id);
    })
  });
}
_s(TestIndex, "EcuPFGw29ARuTs47OEyfycl8jbM=", false, function () {
  return [_reflectionContext.useReflection];
});
_c = TestIndex;
var _c;
$RefreshReg$(_c, "TestIndex");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3JlZmxlY3Rpb25Db250ZXh0IiwiX0Jyb2tlblRpbGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRlc3RJbmRleCIsIm5vZGUiLCJyZWZsZWN0aW9uIiwidXNlUmVmbGVjdGlvbiIsIndvcmtzaGVldCIsImF0dHJTdHJpbmciLCJzdWJqZWN0IiwianN4IiwiY29tcG9uZW50IiwicmVhc29uIiwidGVzdHMiLCJ1bmRlZmluZWQiLCJzb21lIiwidCIsImNlbGxzIiwiYyIsImZpbHRlciIsImlkIiwibGVuZ3RoIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwibWFwIiwib3V0Y29tZSIsInZlcmRpY3RzIiwiZ2V0Iiwib3V0Y29tZXMiLCJmaW5kIiwibyIsIm91dGNvbWVMYWJlbCIsInBhc3MiLCJraW5kIiwibmFtZSIsIm1lc3NhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRlc3RJbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGVzdEluZGV4IOKAlCB0aGUgcmVmbGVjdGlvbiBjb21wb25lbnQgbGlzdGluZyB0aGUgd29ya2Jvb2sncyB0ZXN0IGFzc2V0c1xuLy8gKEFVVEhPUlNfVklFV19TUEVDIMKnMik6IGtpbmQgbGFiZWwsIHN1YmplY3QsIG5hbWUsIGFuZCB0aGUgbGF0ZXN0IGNvbXB1dGVkIG91dGNvbWVcbi8vIChwYXNzL2ZhaWwgKyBtZXNzYWdlOyBhIHBlbmRpbmcgc3VpdGUgc2hvd3MgdGhlIGRpc3RpbmN0IHBlbmRpbmcgc3RhdGUsIG5ldmVyIGFcbi8vIGZhYnJpY2F0ZWQgb3V0Y29tZSkuIEZpbHRlcnMgYXJlIHR5cGVkIGFuZCByZWZ1c2UgdW5rbm93biB0YXJnZXRzIHdpdGggYSBicm9rZW4gdGlsZS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcgfSBmcm9tICcuLi9hdHRycy50cyc7XG5pbXBvcnQgeyB1c2VSZWZsZWN0aW9uIH0gZnJvbSAnLi4vcmVmbGVjdGlvbkNvbnRleHQudHMnO1xuaW1wb3J0IEJyb2tlblRpbGUgZnJvbSAnLi9Ccm9rZW5UaWxlLnRzeCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRlc3RJbmRleCh7IG5vZGUgfTogeyBub2RlOiBDb21wb25lbnROb2RlIH0pIHtcbiAgY29uc3QgcmVmbGVjdGlvbiA9IHVzZVJlZmxlY3Rpb24oKTtcbiAgY29uc3Qgd29ya3NoZWV0ID0gYXR0clN0cmluZyhub2RlLCAnd29ya3NoZWV0Jyk7XG4gIGNvbnN0IHN1YmplY3QgPSBhdHRyU3RyaW5nKG5vZGUsICdzdWJqZWN0Jyk7XG5cbiAgaWYgKHJlZmxlY3Rpb24gPT09IG51bGwpIHtcbiAgICByZXR1cm4gPEJyb2tlblRpbGUgY29tcG9uZW50PVwiVGVzdEluZGV4XCIgcmVhc29uPVwiYXZhaWxhYmxlIG9ubHkgaW4gdGhlIGF1dGhvcidzIHZpZXdcIiAvPjtcbiAgfVxuXG4gIGxldCB0ZXN0cyA9IHJlZmxlY3Rpb24udGVzdHMoKTtcbiAgaWYgKHdvcmtzaGVldCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgaWYgKCF0ZXN0cy5zb21lKCh0KSA9PiB0LndvcmtzaGVldCA9PT0gd29ya3NoZWV0KSAmJiAhcmVmbGVjdGlvbi5jZWxscygpLnNvbWUoKGMpID0+IGMud29ya3NoZWV0ID09PSB3b3Jrc2hlZXQpKSB7XG4gICAgICByZXR1cm4gPEJyb2tlblRpbGUgY29tcG9uZW50PVwiVGVzdEluZGV4XCIgcmVhc29uPXtgdW5rbm93biB3b3Jrc2hlZXQgXCIke3dvcmtzaGVldH1cImB9IC8+O1xuICAgIH1cbiAgICB0ZXN0cyA9IHRlc3RzLmZpbHRlcigodCkgPT4gdC53b3Jrc2hlZXQgPT09IHdvcmtzaGVldCk7XG4gIH1cbiAgaWYgKHN1YmplY3QgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmICghcmVmbGVjdGlvbi5jZWxscygpLnNvbWUoKGMpID0+IGMuaWQgPT09IHN1YmplY3QpKSB7XG4gICAgICByZXR1cm4gPEJyb2tlblRpbGUgY29tcG9uZW50PVwiVGVzdEluZGV4XCIgcmVhc29uPXtgdW5rbm93biBzdWJqZWN0IFwiJHtzdWJqZWN0fVwiYH0gLz47XG4gICAgfVxuICAgIHRlc3RzID0gdGVzdHMuZmlsdGVyKCh0KSA9PiB0LnN1YmplY3QgPT09IHN1YmplY3QpO1xuICB9XG5cbiAgaWYgKHRlc3RzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInJrLXJlZmwtbm9uZVwiPm5vIHRlc3RzIGRlY2xhcmVke3dvcmtzaGVldCAhPT0gdW5kZWZpbmVkIHx8IHN1YmplY3QgIT09IHVuZGVmaW5lZCA/ICcgZm9yIHRoaXMgZmlsdGVyJyA6ICcnfS48L2Rpdj47XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmstcmVmbC1pbmRleFwiPlxuICAgICAge3Rlc3RzLm1hcCgodCkgPT4ge1xuICAgICAgICBjb25zdCBvdXRjb21lID1cbiAgICAgICAgICByZWZsZWN0aW9uLnZlcmRpY3RzID09PSBudWxsXG4gICAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgICAgOiByZWZsZWN0aW9uLnZlcmRpY3RzLmdldCh0LnN1YmplY3QpPy5vdXRjb21lcy5maW5kKChvKSA9PiBvLmlkID09PSB0LmlkKTtcbiAgICAgICAgY29uc3Qgb3V0Y29tZUxhYmVsID1cbiAgICAgICAgICByZWZsZWN0aW9uLnZlcmRpY3RzID09PSBudWxsID8gJ3BlbmRpbmcnIDogb3V0Y29tZSA9PT0gdW5kZWZpbmVkID8gJ+KAlCcgOiBvdXRjb21lLnBhc3MgPyAncGFzcycgOiAnZmFpbCc7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGRpdiBrZXk9e3QuaWR9IGNsYXNzTmFtZT17YHJrLXJlZmwtdGVzdCAke291dGNvbWU/LnBhc3MgPT09IGZhbHNlID8gJ3JrLXJlZmwtdGVzdC0tZmFpbCcgOiAnJ31gfT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXJlZmwta2luZFwiPnt0LmtpbmR9PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmstcmVmbC1uYW1lXCI+e3QubmFtZX08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1yZWZsLXN1YmplY3RcIj7ihpIge3Quc3ViamVjdH08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyay1yZWZsLW91dGNvbWVcIj57b3V0Y29tZUxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgIHtvdXRjb21lICE9PSB1bmRlZmluZWQgJiYgIW91dGNvbWUucGFzcyAmJiBvdXRjb21lLm1lc3NhZ2UgIT09ICcnICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLXRlc3QtbXNnXCI+e291dGNvbWUubWVzc2FnZX08L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFLQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxrQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQTBDLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVAxQztBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTWUsU0FBU0csU0FBU0EsQ0FBQztFQUFFQztBQUE4QixDQUFDLEVBQUU7RUFBQU4sRUFBQTtFQUNuRSxNQUFNTyxVQUFVLEdBQUcsSUFBQUMsZ0NBQWEsRUFBQyxDQUFDO0VBQ2xDLE1BQU1DLFNBQVMsR0FBRyxJQUFBQyxpQkFBVSxFQUFDSixJQUFJLEVBQUUsV0FBVyxDQUFDO0VBQy9DLE1BQU1LLE9BQU8sR0FBRyxJQUFBRCxpQkFBVSxFQUFDSixJQUFJLEVBQUUsU0FBUyxDQUFDO0VBRTNDLElBQUlDLFVBQVUsS0FBSyxJQUFJLEVBQUU7SUFDdkIsb0JBQU8sSUFBQVIsV0FBQSxDQUFBYSxHQUFBLEVBQUNmLFdBQUEsQ0FBQU8sT0FBVTtNQUFDUyxTQUFTLEVBQUMsV0FBVztNQUFDQyxNQUFNLEVBQUM7SUFBcUMsQ0FBRSxDQUFDO0VBQzFGO0VBRUEsSUFBSUMsS0FBSyxHQUFHUixVQUFVLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQzlCLElBQUlOLFNBQVMsS0FBS08sU0FBUyxFQUFFO0lBQzNCLElBQUksQ0FBQ0QsS0FBSyxDQUFDRSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDVCxTQUFTLEtBQUtBLFNBQVMsQ0FBQyxJQUFJLENBQUNGLFVBQVUsQ0FBQ1ksS0FBSyxDQUFDLENBQUMsQ0FBQ0YsSUFBSSxDQUFFRyxDQUFDLElBQUtBLENBQUMsQ0FBQ1gsU0FBUyxLQUFLQSxTQUFTLENBQUMsRUFBRTtNQUMvRyxvQkFBTyxJQUFBVixXQUFBLENBQUFhLEdBQUEsRUFBQ2YsV0FBQSxDQUFBTyxPQUFVO1FBQUNTLFNBQVMsRUFBQyxXQUFXO1FBQUNDLE1BQU0sRUFBRSxzQkFBc0JMLFNBQVM7TUFBSSxDQUFFLENBQUM7SUFDekY7SUFDQU0sS0FBSyxHQUFHQSxLQUFLLENBQUNNLE1BQU0sQ0FBRUgsQ0FBQyxJQUFLQSxDQUFDLENBQUNULFNBQVMsS0FBS0EsU0FBUyxDQUFDO0VBQ3hEO0VBQ0EsSUFBSUUsT0FBTyxLQUFLSyxTQUFTLEVBQUU7SUFDekIsSUFBSSxDQUFDVCxVQUFVLENBQUNZLEtBQUssQ0FBQyxDQUFDLENBQUNGLElBQUksQ0FBRUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNFLEVBQUUsS0FBS1gsT0FBTyxDQUFDLEVBQUU7TUFDckQsb0JBQU8sSUFBQVosV0FBQSxDQUFBYSxHQUFBLEVBQUNmLFdBQUEsQ0FBQU8sT0FBVTtRQUFDUyxTQUFTLEVBQUMsV0FBVztRQUFDQyxNQUFNLEVBQUUsb0JBQW9CSCxPQUFPO01BQUksQ0FBRSxDQUFDO0lBQ3JGO0lBQ0FJLEtBQUssR0FBR0EsS0FBSyxDQUFDTSxNQUFNLENBQUVILENBQUMsSUFBS0EsQ0FBQyxDQUFDUCxPQUFPLEtBQUtBLE9BQU8sQ0FBQztFQUNwRDtFQUVBLElBQUlJLEtBQUssQ0FBQ1EsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUN0QixvQkFBTyxJQUFBeEIsV0FBQSxDQUFBeUIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLEdBQUMsbUJBQWlCLEVBQUNqQixTQUFTLEtBQUtPLFNBQVMsSUFBSUwsT0FBTyxLQUFLSyxTQUFTLEdBQUcsa0JBQWtCLEdBQUcsRUFBRSxFQUFDLEdBQUM7SUFBQSxDQUFLLENBQUM7RUFDM0k7RUFFQSxvQkFDRSxJQUFBakIsV0FBQSxDQUFBYSxHQUFBO0lBQUthLFNBQVMsRUFBQyxlQUFlO0lBQUFDLFFBQUEsRUFDM0JYLEtBQUssQ0FBQ1ksR0FBRyxDQUFFVCxDQUFDLElBQUs7TUFDaEIsTUFBTVUsT0FBTyxHQUNYckIsVUFBVSxDQUFDc0IsUUFBUSxLQUFLLElBQUksR0FDeEJiLFNBQVMsR0FDVFQsVUFBVSxDQUFDc0IsUUFBUSxDQUFDQyxHQUFHLENBQUNaLENBQUMsQ0FBQ1AsT0FBTyxDQUFDLEVBQUVvQixRQUFRLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNYLEVBQUUsS0FBS0osQ0FBQyxDQUFDSSxFQUFFLENBQUM7TUFDN0UsTUFBTVksWUFBWSxHQUNoQjNCLFVBQVUsQ0FBQ3NCLFFBQVEsS0FBSyxJQUFJLEdBQUcsU0FBUyxHQUFHRCxPQUFPLEtBQUtaLFNBQVMsR0FBRyxHQUFHLEdBQUdZLE9BQU8sQ0FBQ08sSUFBSSxHQUFHLE1BQU0sR0FBRyxNQUFNO01BQ3pHLG9CQUNFLElBQUFwQyxXQUFBLENBQUF5QixJQUFBO1FBQWdCQyxTQUFTLEVBQUUsZ0JBQWdCRyxPQUFPLEVBQUVPLElBQUksS0FBSyxLQUFLLEdBQUcsb0JBQW9CLEdBQUcsRUFBRSxFQUFHO1FBQUFULFFBQUEsZ0JBQy9GLElBQUEzQixXQUFBLENBQUFhLEdBQUE7VUFBTWEsU0FBUyxFQUFDLGNBQWM7VUFBQUMsUUFBQSxFQUFFUixDQUFDLENBQUNrQjtRQUFJLENBQU8sQ0FBQyxlQUM5QyxJQUFBckMsV0FBQSxDQUFBYSxHQUFBO1VBQU1hLFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsRUFBRVIsQ0FBQyxDQUFDbUI7UUFBSSxDQUFPLENBQUMsZUFDOUMsSUFBQXRDLFdBQUEsQ0FBQXlCLElBQUE7VUFBTUMsU0FBUyxFQUFDLGlCQUFpQjtVQUFBQyxRQUFBLEdBQUMsU0FBRSxFQUFDUixDQUFDLENBQUNQLE9BQU87UUFBQSxDQUFPLENBQUMsZUFDdEQsSUFBQVosV0FBQSxDQUFBYSxHQUFBO1VBQU1hLFNBQVMsRUFBQyxpQkFBaUI7VUFBQUMsUUFBQSxFQUFFUTtRQUFZLENBQU8sQ0FBQyxFQUN0RE4sT0FBTyxLQUFLWixTQUFTLElBQUksQ0FBQ1ksT0FBTyxDQUFDTyxJQUFJLElBQUlQLE9BQU8sQ0FBQ1UsT0FBTyxLQUFLLEVBQUUsaUJBQy9ELElBQUF2QyxXQUFBLENBQUFhLEdBQUE7VUFBS2EsU0FBUyxFQUFDLGtCQUFrQjtVQUFBQyxRQUFBLEVBQUVFLE9BQU8sQ0FBQ1U7UUFBTyxDQUFNLENBQ3pEO01BQUEsR0FQT3BCLENBQUMsQ0FBQ0ksRUFRUCxDQUFDO0lBRVYsQ0FBQztFQUFDLENBQ0MsQ0FBQztBQUVWO0FBQUN0QixFQUFBLENBbER1QkssU0FBUztFQUFBLFFBQ1pHLGdDQUFhO0FBQUE7QUFBQStCLEVBQUEsR0FEVmxDLFNBQVM7QUFBQSxJQUFBa0MsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}