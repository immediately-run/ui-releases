var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _jsxRuntime = require("react/jsx-runtime");
// The §4.4 staleness affordance (DOCUMENT_NAVIGATOR_SPEC, DN-R11): the session reads
// the document once, so after an edit lands through the platform editor the rendered
// report shows OLD numbers with no indication they are stale — a defect the edit
// feature would introduce, not inherit. This notice is the explicit answer: it names
// the staleness, and its one action re-reads the document through the same mount
// resolution (the report hook's `reload`).

function DocumentChangedNotice({
  onReload
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-stale",
    role: "status",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: "The mounted document changed after this report was rendered \u2014 the figures below are stale."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "rk-chip rk-chip--nav",
      onClick: onReload,
      children: "Reload document"
    })]
  });
}
_c = DocumentChangedNotice;
var _default = exports.default = DocumentChangedNotice;
var _c;
$RefreshReg$(_c, "DocumentChangedNotice");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJEb2N1bWVudENoYW5nZWROb3RpY2UiLCJvblJlbG9hZCIsIl9qc3hSdW50aW1lIiwianN4cyIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsImpzeCIsInR5cGUiLCJvbkNsaWNrIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRG9jdW1lbnRDaGFuZ2VkTm90aWNlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgwqc0LjQgc3RhbGVuZXNzIGFmZm9yZGFuY2UgKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDLCBETi1SMTEpOiB0aGUgc2Vzc2lvbiByZWFkc1xuLy8gdGhlIGRvY3VtZW50IG9uY2UsIHNvIGFmdGVyIGFuIGVkaXQgbGFuZHMgdGhyb3VnaCB0aGUgcGxhdGZvcm0gZWRpdG9yIHRoZSByZW5kZXJlZFxuLy8gcmVwb3J0IHNob3dzIE9MRCBudW1iZXJzIHdpdGggbm8gaW5kaWNhdGlvbiB0aGV5IGFyZSBzdGFsZSDigJQgYSBkZWZlY3QgdGhlIGVkaXRcbi8vIGZlYXR1cmUgd291bGQgaW50cm9kdWNlLCBub3QgaW5oZXJpdC4gVGhpcyBub3RpY2UgaXMgdGhlIGV4cGxpY2l0IGFuc3dlcjogaXQgbmFtZXNcbi8vIHRoZSBzdGFsZW5lc3MsIGFuZCBpdHMgb25lIGFjdGlvbiByZS1yZWFkcyB0aGUgZG9jdW1lbnQgdGhyb3VnaCB0aGUgc2FtZSBtb3VudFxuLy8gcmVzb2x1dGlvbiAodGhlIHJlcG9ydCBob29rJ3MgYHJlbG9hZGApLlxuXG5pbnRlcmZhY2UgRG9jdW1lbnRDaGFuZ2VkTm90aWNlUHJvcHMge1xuICBvblJlbG9hZDogKCkgPT4gdm9pZDtcbn1cblxuZnVuY3Rpb24gRG9jdW1lbnRDaGFuZ2VkTm90aWNlKHsgb25SZWxvYWQgfTogRG9jdW1lbnRDaGFuZ2VkTm90aWNlUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLXN0YWxlXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgPHNwYW4+XG4gICAgICAgIFRoZSBtb3VudGVkIGRvY3VtZW50IGNoYW5nZWQgYWZ0ZXIgdGhpcyByZXBvcnQgd2FzIHJlbmRlcmVkIOKAlCB0aGUgZmlndXJlcyBiZWxvdyBhcmUgc3RhbGUuXG4gICAgICA8L3NwYW4+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyay1jaGlwIHJrLWNoaXAtLW5hdlwiIG9uQ2xpY2s9e29uUmVsb2FkfT5cbiAgICAgICAgUmVsb2FkIGRvY3VtZW50XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgRG9jdW1lbnRDaGFuZ2VkTm90aWNlO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BLFNBQVNBLHFCQUFxQkEsQ0FBQztFQUFFQztBQUFxQyxDQUFDLEVBQUU7RUFDdkUsb0JBQ0UsSUFBQUMsV0FBQSxDQUFBQyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxVQUFVO0lBQUNDLElBQUksRUFBQyxRQUFRO0lBQUFDLFFBQUEsZ0JBQ3JDLElBQUFKLFdBQUEsQ0FBQUssR0FBQTtNQUFBRCxRQUFBLEVBQU07SUFFTixDQUFNLENBQUMsZUFDUCxJQUFBSixXQUFBLENBQUFLLEdBQUE7TUFBUUMsSUFBSSxFQUFDLFFBQVE7TUFBQ0osU0FBUyxFQUFDLHNCQUFzQjtNQUFDSyxPQUFPLEVBQUVSLFFBQVM7TUFBQUssUUFBQSxFQUFDO0lBRTFFLENBQVEsQ0FBQztFQUFBLENBQ04sQ0FBQztBQUVWO0FBQUNJLEVBQUEsR0FYUVYscUJBQXFCO0FBQUEsSUFBQVcsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FhZmIscUJBQXFCO0FBQUEsSUFBQVUsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}