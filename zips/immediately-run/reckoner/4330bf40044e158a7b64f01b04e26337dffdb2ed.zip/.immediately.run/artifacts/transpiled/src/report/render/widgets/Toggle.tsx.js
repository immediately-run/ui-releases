var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Toggle;
var _attrs = require("../attrs.ts");
var _useParam = require("./useParam.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Toggle widget — writes a boolean `params.<name>` (§3.3).
function Toggle({
  node
}) {
  _s();
  const name = (0, _attrs.attrString)(node, 'name') ?? '';
  const def = (0, _attrs.attrBool)(node, 'default');
  const {
    value,
    set
  } = (0, _useParam.useParam)(name, def);
  const on = typeof value === 'boolean' ? value : def;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
    className: "rk-widget rk-widget-toggle",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rk-widget-label",
      children: name
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
      type: "checkbox",
      checked: on,
      onChange: e => set(e.target.checked)
    })]
  });
}
_s(Toggle, "P5g961Dx7UfkNf2t68spDCPaBwI=", false, function () {
  return [_useParam.useParam];
});
_c = Toggle;
var _c;
$RefreshReg$(_c, "Toggle");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYXR0cnMiLCJyZXF1aXJlIiwiX3VzZVBhcmFtIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlRvZ2dsZSIsIm5vZGUiLCJuYW1lIiwiYXR0clN0cmluZyIsImRlZiIsImF0dHJCb29sIiwidmFsdWUiLCJzZXQiLCJ1c2VQYXJhbSIsIm9uIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwidHlwZSIsImNoZWNrZWQiLCJvbkNoYW5nZSIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvZ2dsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVG9nZ2xlIHdpZGdldCDigJQgd3JpdGVzIGEgYm9vbGVhbiBgcGFyYW1zLjxuYW1lPmAgKMKnMy4zKS5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50Tm9kZSB9IGZyb20gJy4uLy4uL25vZGVzLnRzJztcbmltcG9ydCB7IGF0dHJTdHJpbmcsIGF0dHJCb29sIH0gZnJvbSAnLi4vYXR0cnMudHMnO1xuaW1wb3J0IHsgdXNlUGFyYW0gfSBmcm9tICcuL3VzZVBhcmFtLnRzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVG9nZ2xlKHsgbm9kZSB9OiB7IG5vZGU6IENvbXBvbmVudE5vZGUgfSkge1xuICBjb25zdCBuYW1lID0gYXR0clN0cmluZyhub2RlLCAnbmFtZScpID8/ICcnO1xuICBjb25zdCBkZWYgPSBhdHRyQm9vbChub2RlLCAnZGVmYXVsdCcpO1xuICBjb25zdCB7IHZhbHVlLCBzZXQgfSA9IHVzZVBhcmFtKG5hbWUsIGRlZik7XG4gIGNvbnN0IG9uID0gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicgPyB2YWx1ZSA6IGRlZjtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwicmstd2lkZ2V0IHJrLXdpZGdldC10b2dnbGVcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJrLXdpZGdldC1sYWJlbFwiPntuYW1lfTwvc3Bhbj5cbiAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXtvbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXQoZS50YXJnZXQuY2hlY2tlZCl9IC8+XG4gICAgPC9sYWJlbD5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsU0FBQSxHQUFBRCxPQUFBO0FBQXlDLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUFBLElBQUFHLEVBQUEsR0FBQUMsWUFBQSxJQUh6QztBQUtlLFNBQVNDLE1BQU1BLENBQUM7RUFBRUM7QUFBOEIsQ0FBQyxFQUFFO0VBQUFILEVBQUE7RUFDaEUsTUFBTUksSUFBSSxHQUFHLElBQUFDLGlCQUFVLEVBQUNGLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxFQUFFO0VBQzNDLE1BQU1HLEdBQUcsR0FBRyxJQUFBQyxlQUFRLEVBQUNKLElBQUksRUFBRSxTQUFTLENBQUM7RUFDckMsTUFBTTtJQUFFSyxLQUFLO0lBQUVDO0VBQUksQ0FBQyxHQUFHLElBQUFDLGtCQUFRLEVBQUNOLElBQUksRUFBRUUsR0FBRyxDQUFDO0VBQzFDLE1BQU1LLEVBQUUsR0FBRyxPQUFPSCxLQUFLLEtBQUssU0FBUyxHQUFHQSxLQUFLLEdBQUdGLEdBQUc7RUFDbkQsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBYSxJQUFBO0lBQU9DLFNBQVMsRUFBQyw0QkFBNEI7SUFBQUMsUUFBQSxnQkFDM0MsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQTtNQUFNRixTQUFTLEVBQUMsaUJBQWlCO01BQUFDLFFBQUEsRUFBRVY7SUFBSSxDQUFPLENBQUMsZUFDL0MsSUFBQUwsV0FBQSxDQUFBZ0IsR0FBQTtNQUFPQyxJQUFJLEVBQUMsVUFBVTtNQUFDQyxPQUFPLEVBQUVOLEVBQUc7TUFBQ08sUUFBUSxFQUFHQyxDQUFDLElBQUtWLEdBQUcsQ0FBQ1UsQ0FBQyxDQUFDQyxNQUFNLENBQUNILE9BQU87SUFBRSxDQUFFLENBQUM7RUFBQSxDQUN6RSxDQUFDO0FBRVo7QUFBQ2pCLEVBQUEsQ0FYdUJFLE1BQU07RUFBQSxRQUdMUSxrQkFBUTtBQUFBO0FBQUFXLEVBQUEsR0FIVG5CLE1BQU07QUFBQSxJQUFBbUIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}