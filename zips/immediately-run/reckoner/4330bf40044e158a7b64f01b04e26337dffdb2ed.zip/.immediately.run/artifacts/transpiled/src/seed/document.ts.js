"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SEED_ROOT = exports.SEED_FILES = void 0;
var _data = require("./data.ts");
// The bundled demo document (ARCHITECTURE_PLAN §3, §7). Reckoner is normally opened *on* a
// document living in a mount; so the app renders something with zero prompts, it ships one
// self-contained example — the Meridian monthly review — as an in-memory document the real
// `loadDocument` loader reads through an injected reader (src/app/memoryReader.ts).
//
// PORTABILITY: the files are plain string/object constants, NOT Vite `?raw` / `import.meta.glob`
// imports — those are bundler-specific and would break on immediately.run (the "works in vite,
// breaks on the platform" trap). The worksheet is plain `.sheet.js` (executed in the engine's
// SES compartment) and the template is the MDX subset (parsed by src/report/parse).

const SEED_ROOT = exports.SEED_ROOT = 'meridian';
const manifest = {
  format: 1,
  compat: {
    stdlib: '>=0.1.0',
    catalog: '>=0.1.0'
  },
  authoredWith: {
    app: 'reckoner',
    stdlib: '0.1.0',
    catalog: '0.1.0'
  },
  worksheets: ['review'],
  params: {
    span: '12m'
  },
  title: 'Meridian — monthly review'
};

// The formula worksheet: plain JS registering cells; imports resolve only to the stdlib, which
// the engine's compartment endows. Light shaping over the frozen fixtures — the real port of
// the Meridian MRR waterfall/cohort pivot is M2 work; here we prove the runnable pipeline.
const reviewSheet = `import { cell, table, testCell, expectClose, property } from "@reckoner/stdlib";

export const total = cell({
  doc: "Latest monthly recurring revenue, EUR",
  inputs: { rows: "fixtures.exec_summary" },
  formula: ({ rows }) => (rows.length ? rows[rows.length - 1].mrr : null),
});

export const total_prev = cell({
  doc: "Prior-month MRR, EUR — the KPI compare baseline",
  inputs: { rows: "fixtures.exec_summary" },
  formula: ({ rows }) => (rows.length > 1 ? rows[rows.length - 2].mrr : null),
});

export const nrr = cell({
  doc: "Latest net revenue retention, as a ratio",
  inputs: { rows: "fixtures.exec_summary" },
  formula: ({ rows }) => (rows.length ? rows[rows.length - 1].nrrPct / 100 : null),
});

export const mrr_delta = cell({
  doc: "Month-over-month MRR change, EUR — the one cell-to-cell edge in the demo (the value inspector's navigable chip)",
  inputs: { latest: "review.total", prior: "review.total_prev" },
  formula: ({ latest, prior }) => (latest === null || prior === null ? null : latest - prior),
});

export const churn = cell({
  doc: "Latest gross revenue churn, as a ratio",
  inputs: { rows: "fixtures.exec_summary" },
  formula: ({ rows }) => (rows.length ? rows[rows.length - 1].grossChurnPct / 100 : null),
});

export const by_month = cell({
  doc: "MRR by month for the trend line, windowed by the span param",
  inputs: { rows: "fixtures.exec_summary", span: "params.span" },
  formula: ({ rows, span }) => {
    const n = span === "6m" ? 6 : rows.length;
    return table(rows)
      .sort("month")
      .derive({ mrr: (r) => r.mrr })
      .rows()
      .slice(-n)
      .map((r) => ({ month: r.month, mrr: r.mrr }));
  },
});

export const growth_stack = cell({
  doc: "Monthly growth composition (new/expansion/reactivation), long format for a stacked bar",
  inputs: { rows: "fixtures.mrr_movements" },
  formula: ({ rows }) =>
    rows.flatMap((r) => [
      { month: r.month, driver: "new", value: r.newMrr },
      { month: r.month, driver: "expansion", value: r.expansion },
      { month: r.month, driver: "reactivation", value: r.reactivation },
    ]),
});

export const latest_growth = cell({
  doc: "Latest-month growth drivers, for the composition pie",
  inputs: { rows: "fixtures.mrr_movements" },
  formula: ({ rows }) => {
    const r = rows.length ? rows[rows.length - 1] : {};
    return [
      { driver: "new", value: r.newMrr || 0 },
      { driver: "expansion", value: r.expansion || 0 },
      { driver: "reactivation", value: r.reactivation || 0 },
    ];
  },
});

export const by_region = cell({
  doc: "Active customers by region, for the map breakdown",
  inputs: { rows: "fixtures.region_customers" },
  formula: ({ rows }) => rows.map((r) => ({ region: r.region, customers: r.customers })),
});

export const cohort_curves = cell({
  doc: "Retention % by months-since-signup, per cohort, for the small multiples",
  inputs: { rows: "fixtures.cohort_retention" },
  formula: ({ rows }) => rows.map((r) => ({ cohort: r.cohort, offset: r.offset, retention: r.retentionPct })),
});

export const movements = cell({
  doc: "MRR movement waterfall by month, for the detail table",
  inputs: { rows: "fixtures.mrr_movements" },
  formula: ({ rows }) => rows,
});

// The demo's tests — an honest mix for the review surface: this specification test pins
// \`total\` to a plain-JS recomputation of the same fixture (regression evidence: "pinned",
// not "validated", because an example-based test cannot validate the formula it was fitted
// to); the property relation on \`nrr\` is a non-example-based leg (a sane NRR is a ratio in
// (0, 2]), so \`nrr\` reads "validated". Every other cell is genuinely untested — the panel
// shows that honestly rather than decorating the demo.
export const total_check = testCell({
  kind: "specification",
  subject: "review.total",
  expect: ({ result, inputs }) =>
    expectClose(result, inputs.rows[inputs.rows.length - 1].mrr, { abs: 0.01 }),
});

export const nrr_sane = testCell({
  kind: "property",
  subject: "review.nrr",
  relation: property("nrr is a ratio in (0, 2]", (result) => result > 0 && result <= 2),
});
`;

// The report template — the MDX subset. Exercises the breadth of the catalog: KPIs (currency +
// percent), a line trend, a stacked bar, a pie, a map, a callout, faceted retention curves, a
// sortable table, a param widget, and an inline bound value.
const weeklyTemplate = `Recurring-revenue health for Meridian SaaS. Pick a window and the whole report
recomputes — every figure below is derived from the frozen fixtures by the engine.

<Params>
<Select name="span" options={["12m", "6m"]} default="12m" />
</Params>

<Row>
<Kpi source="review.total" compare="review.total_prev" format="currency" />
<Kpi source="review.nrr" format="percent" />
<Kpi source="review.churn" format="percent" />
</Row>

## MRR trend.

<Chart source="review.by_month" kind="line" x="month" y="mrr" />

## Growth composition.

New, expansion and reactivation MRR by month.

<Chart source="review.growth_stack" kind="bar" x="month" y="value" color="driver" stack="stacked" />

<Row>
<Chart source="review.latest_growth" kind="pie" value="value" label="driver" />
<Map source="review.by_region" kind="choropleth" region="region" value="customers" />
</Row>

<Callout tone="info">
Net revenue retention and gross churn are the two levers behind the trend above — watch them together.
</Callout>

## Cohort retention.

Retention curves by signup cohort — each panel is one cohort's decay.

<Facets source="review.cohort_curves" by="cohort">
<Chart kind="line" x="offset" y="retention" />
</Facets>

## Movement detail.

<Table source="review.movements" columns={["month", "newMrr", "expansion", "contraction", "churned", "endMrr"]} sortable />
`;
const provenance = {
  sourceFeed: 'meridian',
  capturedAt: '2026-07-09',
  captureActor: 'generate.py',
  synthetic: true
};
const frame = rows => JSON.stringify({
  rows,
  provenance,
  tier: 'static'
});

/** The document as an in-memory file map, keyed by document-root-relative path. */
const SEED_FILES = exports.SEED_FILES = {
  'meridian/reckoner.json': JSON.stringify(manifest),
  'meridian/worksheets/review.sheet.js': reviewSheet,
  'meridian/templates/weekly.mdx': weeklyTemplate,
  'meridian/fixtures/exec_summary.frame.json': frame(_data.execSummary),
  'meridian/fixtures/mrr_movements.frame.json': frame(_data.mrrMovements),
  'meridian/fixtures/region_customers.frame.json': frame(_data.regionCustomers),
  'meridian/fixtures/cohort_retention.frame.json': frame(_data.cohortRetention)
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGF0YSIsInJlcXVpcmUiLCJTRUVEX1JPT1QiLCJleHBvcnRzIiwibWFuaWZlc3QiLCJmb3JtYXQiLCJjb21wYXQiLCJzdGRsaWIiLCJjYXRhbG9nIiwiYXV0aG9yZWRXaXRoIiwiYXBwIiwid29ya3NoZWV0cyIsInBhcmFtcyIsInNwYW4iLCJ0aXRsZSIsInJldmlld1NoZWV0Iiwid2Vla2x5VGVtcGxhdGUiLCJwcm92ZW5hbmNlIiwic291cmNlRmVlZCIsImNhcHR1cmVkQXQiLCJjYXB0dXJlQWN0b3IiLCJzeW50aGV0aWMiLCJmcmFtZSIsInJvd3MiLCJKU09OIiwic3RyaW5naWZ5IiwidGllciIsIlNFRURfRklMRVMiLCJleGVjU3VtbWFyeSIsIm1yck1vdmVtZW50cyIsInJlZ2lvbkN1c3RvbWVycyIsImNvaG9ydFJldGVudGlvbiJdLCJzb3VyY2VzIjpbImRvY3VtZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBidW5kbGVkIGRlbW8gZG9jdW1lbnQgKEFSQ0hJVEVDVFVSRV9QTEFOIMKnMywgwqc3KS4gUmVja29uZXIgaXMgbm9ybWFsbHkgb3BlbmVkICpvbiogYVxuLy8gZG9jdW1lbnQgbGl2aW5nIGluIGEgbW91bnQ7IHNvIHRoZSBhcHAgcmVuZGVycyBzb21ldGhpbmcgd2l0aCB6ZXJvIHByb21wdHMsIGl0IHNoaXBzIG9uZVxuLy8gc2VsZi1jb250YWluZWQgZXhhbXBsZSDigJQgdGhlIE1lcmlkaWFuIG1vbnRobHkgcmV2aWV3IOKAlCBhcyBhbiBpbi1tZW1vcnkgZG9jdW1lbnQgdGhlIHJlYWxcbi8vIGBsb2FkRG9jdW1lbnRgIGxvYWRlciByZWFkcyB0aHJvdWdoIGFuIGluamVjdGVkIHJlYWRlciAoc3JjL2FwcC9tZW1vcnlSZWFkZXIudHMpLlxuLy9cbi8vIFBPUlRBQklMSVRZOiB0aGUgZmlsZXMgYXJlIHBsYWluIHN0cmluZy9vYmplY3QgY29uc3RhbnRzLCBOT1QgVml0ZSBgP3Jhd2AgLyBgaW1wb3J0Lm1ldGEuZ2xvYmBcbi8vIGltcG9ydHMg4oCUIHRob3NlIGFyZSBidW5kbGVyLXNwZWNpZmljIGFuZCB3b3VsZCBicmVhayBvbiBpbW1lZGlhdGVseS5ydW4gKHRoZSBcIndvcmtzIGluIHZpdGUsXG4vLyBicmVha3Mgb24gdGhlIHBsYXRmb3JtXCIgdHJhcCkuIFRoZSB3b3Jrc2hlZXQgaXMgcGxhaW4gYC5zaGVldC5qc2AgKGV4ZWN1dGVkIGluIHRoZSBlbmdpbmUnc1xuLy8gU0VTIGNvbXBhcnRtZW50KSBhbmQgdGhlIHRlbXBsYXRlIGlzIHRoZSBNRFggc3Vic2V0IChwYXJzZWQgYnkgc3JjL3JlcG9ydC9wYXJzZSkuXG5cbmltcG9ydCB7IGV4ZWNTdW1tYXJ5LCBtcnJNb3ZlbWVudHMsIHJlZ2lvbkN1c3RvbWVycywgY29ob3J0UmV0ZW50aW9uIH0gZnJvbSAnLi9kYXRhLnRzJztcbmltcG9ydCB0eXBlIHsgVmFsdWUgfSBmcm9tICcuLi9zdGRsaWIvdHlwZXMudHMnO1xuXG5leHBvcnQgY29uc3QgU0VFRF9ST09UID0gJ21lcmlkaWFuJztcblxuY29uc3QgbWFuaWZlc3QgPSB7XG4gIGZvcm1hdDogMSxcbiAgY29tcGF0OiB7IHN0ZGxpYjogJz49MC4xLjAnLCBjYXRhbG9nOiAnPj0wLjEuMCcgfSxcbiAgYXV0aG9yZWRXaXRoOiB7IGFwcDogJ3JlY2tvbmVyJywgc3RkbGliOiAnMC4xLjAnLCBjYXRhbG9nOiAnMC4xLjAnIH0sXG4gIHdvcmtzaGVldHM6IFsncmV2aWV3J10sXG4gIHBhcmFtczogeyBzcGFuOiAnMTJtJyB9IGFzIFJlY29yZDxzdHJpbmcsIFZhbHVlPixcbiAgdGl0bGU6ICdNZXJpZGlhbiDigJQgbW9udGhseSByZXZpZXcnLFxufTtcblxuLy8gVGhlIGZvcm11bGEgd29ya3NoZWV0OiBwbGFpbiBKUyByZWdpc3RlcmluZyBjZWxsczsgaW1wb3J0cyByZXNvbHZlIG9ubHkgdG8gdGhlIHN0ZGxpYiwgd2hpY2hcbi8vIHRoZSBlbmdpbmUncyBjb21wYXJ0bWVudCBlbmRvd3MuIExpZ2h0IHNoYXBpbmcgb3ZlciB0aGUgZnJvemVuIGZpeHR1cmVzIOKAlCB0aGUgcmVhbCBwb3J0IG9mXG4vLyB0aGUgTWVyaWRpYW4gTVJSIHdhdGVyZmFsbC9jb2hvcnQgcGl2b3QgaXMgTTIgd29yazsgaGVyZSB3ZSBwcm92ZSB0aGUgcnVubmFibGUgcGlwZWxpbmUuXG5jb25zdCByZXZpZXdTaGVldCA9IGBpbXBvcnQgeyBjZWxsLCB0YWJsZSwgdGVzdENlbGwsIGV4cGVjdENsb3NlLCBwcm9wZXJ0eSB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5cbmV4cG9ydCBjb25zdCB0b3RhbCA9IGNlbGwoe1xuICBkb2M6IFwiTGF0ZXN0IG1vbnRobHkgcmVjdXJyaW5nIHJldmVudWUsIEVVUlwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5leGVjX3N1bW1hcnlcIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IChyb3dzLmxlbmd0aCA/IHJvd3Nbcm93cy5sZW5ndGggLSAxXS5tcnIgOiBudWxsKSxcbn0pO1xuXG5leHBvcnQgY29uc3QgdG90YWxfcHJldiA9IGNlbGwoe1xuICBkb2M6IFwiUHJpb3ItbW9udGggTVJSLCBFVVIg4oCUIHRoZSBLUEkgY29tcGFyZSBiYXNlbGluZVwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5leGVjX3N1bW1hcnlcIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IChyb3dzLmxlbmd0aCA+IDEgPyByb3dzW3Jvd3MubGVuZ3RoIC0gMl0ubXJyIDogbnVsbCksXG59KTtcblxuZXhwb3J0IGNvbnN0IG5yciA9IGNlbGwoe1xuICBkb2M6IFwiTGF0ZXN0IG5ldCByZXZlbnVlIHJldGVudGlvbiwgYXMgYSByYXRpb1wiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5leGVjX3N1bW1hcnlcIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IChyb3dzLmxlbmd0aCA/IHJvd3Nbcm93cy5sZW5ndGggLSAxXS5ucnJQY3QgLyAxMDAgOiBudWxsKSxcbn0pO1xuXG5leHBvcnQgY29uc3QgbXJyX2RlbHRhID0gY2VsbCh7XG4gIGRvYzogXCJNb250aC1vdmVyLW1vbnRoIE1SUiBjaGFuZ2UsIEVVUiDigJQgdGhlIG9uZSBjZWxsLXRvLWNlbGwgZWRnZSBpbiB0aGUgZGVtbyAodGhlIHZhbHVlIGluc3BlY3RvcidzIG5hdmlnYWJsZSBjaGlwKVwiLFxuICBpbnB1dHM6IHsgbGF0ZXN0OiBcInJldmlldy50b3RhbFwiLCBwcmlvcjogXCJyZXZpZXcudG90YWxfcHJldlwiIH0sXG4gIGZvcm11bGE6ICh7IGxhdGVzdCwgcHJpb3IgfSkgPT4gKGxhdGVzdCA9PT0gbnVsbCB8fCBwcmlvciA9PT0gbnVsbCA/IG51bGwgOiBsYXRlc3QgLSBwcmlvciksXG59KTtcblxuZXhwb3J0IGNvbnN0IGNodXJuID0gY2VsbCh7XG4gIGRvYzogXCJMYXRlc3QgZ3Jvc3MgcmV2ZW51ZSBjaHVybiwgYXMgYSByYXRpb1wiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5leGVjX3N1bW1hcnlcIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IChyb3dzLmxlbmd0aCA/IHJvd3Nbcm93cy5sZW5ndGggLSAxXS5ncm9zc0NodXJuUGN0IC8gMTAwIDogbnVsbCksXG59KTtcblxuZXhwb3J0IGNvbnN0IGJ5X21vbnRoID0gY2VsbCh7XG4gIGRvYzogXCJNUlIgYnkgbW9udGggZm9yIHRoZSB0cmVuZCBsaW5lLCB3aW5kb3dlZCBieSB0aGUgc3BhbiBwYXJhbVwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5leGVjX3N1bW1hcnlcIiwgc3BhbjogXCJwYXJhbXMuc3BhblwiIH0sXG4gIGZvcm11bGE6ICh7IHJvd3MsIHNwYW4gfSkgPT4ge1xuICAgIGNvbnN0IG4gPSBzcGFuID09PSBcIjZtXCIgPyA2IDogcm93cy5sZW5ndGg7XG4gICAgcmV0dXJuIHRhYmxlKHJvd3MpXG4gICAgICAuc29ydChcIm1vbnRoXCIpXG4gICAgICAuZGVyaXZlKHsgbXJyOiAocikgPT4gci5tcnIgfSlcbiAgICAgIC5yb3dzKClcbiAgICAgIC5zbGljZSgtbilcbiAgICAgIC5tYXAoKHIpID0+ICh7IG1vbnRoOiByLm1vbnRoLCBtcnI6IHIubXJyIH0pKTtcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZ3Jvd3RoX3N0YWNrID0gY2VsbCh7XG4gIGRvYzogXCJNb250aGx5IGdyb3d0aCBjb21wb3NpdGlvbiAobmV3L2V4cGFuc2lvbi9yZWFjdGl2YXRpb24pLCBsb25nIGZvcm1hdCBmb3IgYSBzdGFja2VkIGJhclwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5tcnJfbW92ZW1lbnRzXCIgfSxcbiAgZm9ybXVsYTogKHsgcm93cyB9KSA9PlxuICAgIHJvd3MuZmxhdE1hcCgocikgPT4gW1xuICAgICAgeyBtb250aDogci5tb250aCwgZHJpdmVyOiBcIm5ld1wiLCB2YWx1ZTogci5uZXdNcnIgfSxcbiAgICAgIHsgbW9udGg6IHIubW9udGgsIGRyaXZlcjogXCJleHBhbnNpb25cIiwgdmFsdWU6IHIuZXhwYW5zaW9uIH0sXG4gICAgICB7IG1vbnRoOiByLm1vbnRoLCBkcml2ZXI6IFwicmVhY3RpdmF0aW9uXCIsIHZhbHVlOiByLnJlYWN0aXZhdGlvbiB9LFxuICAgIF0pLFxufSk7XG5cbmV4cG9ydCBjb25zdCBsYXRlc3RfZ3Jvd3RoID0gY2VsbCh7XG4gIGRvYzogXCJMYXRlc3QtbW9udGggZ3Jvd3RoIGRyaXZlcnMsIGZvciB0aGUgY29tcG9zaXRpb24gcGllXCIsXG4gIGlucHV0czogeyByb3dzOiBcImZpeHR1cmVzLm1ycl9tb3ZlbWVudHNcIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IHtcbiAgICBjb25zdCByID0gcm93cy5sZW5ndGggPyByb3dzW3Jvd3MubGVuZ3RoIC0gMV0gOiB7fTtcbiAgICByZXR1cm4gW1xuICAgICAgeyBkcml2ZXI6IFwibmV3XCIsIHZhbHVlOiByLm5ld01yciB8fCAwIH0sXG4gICAgICB7IGRyaXZlcjogXCJleHBhbnNpb25cIiwgdmFsdWU6IHIuZXhwYW5zaW9uIHx8IDAgfSxcbiAgICAgIHsgZHJpdmVyOiBcInJlYWN0aXZhdGlvblwiLCB2YWx1ZTogci5yZWFjdGl2YXRpb24gfHwgMCB9LFxuICAgIF07XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGJ5X3JlZ2lvbiA9IGNlbGwoe1xuICBkb2M6IFwiQWN0aXZlIGN1c3RvbWVycyBieSByZWdpb24sIGZvciB0aGUgbWFwIGJyZWFrZG93blwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5yZWdpb25fY3VzdG9tZXJzXCIgfSxcbiAgZm9ybXVsYTogKHsgcm93cyB9KSA9PiByb3dzLm1hcCgocikgPT4gKHsgcmVnaW9uOiByLnJlZ2lvbiwgY3VzdG9tZXJzOiByLmN1c3RvbWVycyB9KSksXG59KTtcblxuZXhwb3J0IGNvbnN0IGNvaG9ydF9jdXJ2ZXMgPSBjZWxsKHtcbiAgZG9jOiBcIlJldGVudGlvbiAlIGJ5IG1vbnRocy1zaW5jZS1zaWdudXAsIHBlciBjb2hvcnQsIGZvciB0aGUgc21hbGwgbXVsdGlwbGVzXCIsXG4gIGlucHV0czogeyByb3dzOiBcImZpeHR1cmVzLmNvaG9ydF9yZXRlbnRpb25cIiB9LFxuICBmb3JtdWxhOiAoeyByb3dzIH0pID0+IHJvd3MubWFwKChyKSA9PiAoeyBjb2hvcnQ6IHIuY29ob3J0LCBvZmZzZXQ6IHIub2Zmc2V0LCByZXRlbnRpb246IHIucmV0ZW50aW9uUGN0IH0pKSxcbn0pO1xuXG5leHBvcnQgY29uc3QgbW92ZW1lbnRzID0gY2VsbCh7XG4gIGRvYzogXCJNUlIgbW92ZW1lbnQgd2F0ZXJmYWxsIGJ5IG1vbnRoLCBmb3IgdGhlIGRldGFpbCB0YWJsZVwiLFxuICBpbnB1dHM6IHsgcm93czogXCJmaXh0dXJlcy5tcnJfbW92ZW1lbnRzXCIgfSxcbiAgZm9ybXVsYTogKHsgcm93cyB9KSA9PiByb3dzLFxufSk7XG5cbi8vIFRoZSBkZW1vJ3MgdGVzdHMg4oCUIGFuIGhvbmVzdCBtaXggZm9yIHRoZSByZXZpZXcgc3VyZmFjZTogdGhpcyBzcGVjaWZpY2F0aW9uIHRlc3QgcGluc1xuLy8gXFxgdG90YWxcXGAgdG8gYSBwbGFpbi1KUyByZWNvbXB1dGF0aW9uIG9mIHRoZSBzYW1lIGZpeHR1cmUgKHJlZ3Jlc3Npb24gZXZpZGVuY2U6IFwicGlubmVkXCIsXG4vLyBub3QgXCJ2YWxpZGF0ZWRcIiwgYmVjYXVzZSBhbiBleGFtcGxlLWJhc2VkIHRlc3QgY2Fubm90IHZhbGlkYXRlIHRoZSBmb3JtdWxhIGl0IHdhcyBmaXR0ZWRcbi8vIHRvKTsgdGhlIHByb3BlcnR5IHJlbGF0aW9uIG9uIFxcYG5yclxcYCBpcyBhIG5vbi1leGFtcGxlLWJhc2VkIGxlZyAoYSBzYW5lIE5SUiBpcyBhIHJhdGlvIGluXG4vLyAoMCwgMl0pLCBzbyBcXGBucnJcXGAgcmVhZHMgXCJ2YWxpZGF0ZWRcIi4gRXZlcnkgb3RoZXIgY2VsbCBpcyBnZW51aW5lbHkgdW50ZXN0ZWQg4oCUIHRoZSBwYW5lbFxuLy8gc2hvd3MgdGhhdCBob25lc3RseSByYXRoZXIgdGhhbiBkZWNvcmF0aW5nIHRoZSBkZW1vLlxuZXhwb3J0IGNvbnN0IHRvdGFsX2NoZWNrID0gdGVzdENlbGwoe1xuICBraW5kOiBcInNwZWNpZmljYXRpb25cIixcbiAgc3ViamVjdDogXCJyZXZpZXcudG90YWxcIixcbiAgZXhwZWN0OiAoeyByZXN1bHQsIGlucHV0cyB9KSA9PlxuICAgIGV4cGVjdENsb3NlKHJlc3VsdCwgaW5wdXRzLnJvd3NbaW5wdXRzLnJvd3MubGVuZ3RoIC0gMV0ubXJyLCB7IGFiczogMC4wMSB9KSxcbn0pO1xuXG5leHBvcnQgY29uc3QgbnJyX3NhbmUgPSB0ZXN0Q2VsbCh7XG4gIGtpbmQ6IFwicHJvcGVydHlcIixcbiAgc3ViamVjdDogXCJyZXZpZXcubnJyXCIsXG4gIHJlbGF0aW9uOiBwcm9wZXJ0eShcIm5yciBpcyBhIHJhdGlvIGluICgwLCAyXVwiLCAocmVzdWx0KSA9PiByZXN1bHQgPiAwICYmIHJlc3VsdCA8PSAyKSxcbn0pO1xuYDtcblxuLy8gVGhlIHJlcG9ydCB0ZW1wbGF0ZSDigJQgdGhlIE1EWCBzdWJzZXQuIEV4ZXJjaXNlcyB0aGUgYnJlYWR0aCBvZiB0aGUgY2F0YWxvZzogS1BJcyAoY3VycmVuY3kgK1xuLy8gcGVyY2VudCksIGEgbGluZSB0cmVuZCwgYSBzdGFja2VkIGJhciwgYSBwaWUsIGEgbWFwLCBhIGNhbGxvdXQsIGZhY2V0ZWQgcmV0ZW50aW9uIGN1cnZlcywgYVxuLy8gc29ydGFibGUgdGFibGUsIGEgcGFyYW0gd2lkZ2V0LCBhbmQgYW4gaW5saW5lIGJvdW5kIHZhbHVlLlxuY29uc3Qgd2Vla2x5VGVtcGxhdGUgPSBgUmVjdXJyaW5nLXJldmVudWUgaGVhbHRoIGZvciBNZXJpZGlhbiBTYWFTLiBQaWNrIGEgd2luZG93IGFuZCB0aGUgd2hvbGUgcmVwb3J0XG5yZWNvbXB1dGVzIOKAlCBldmVyeSBmaWd1cmUgYmVsb3cgaXMgZGVyaXZlZCBmcm9tIHRoZSBmcm96ZW4gZml4dHVyZXMgYnkgdGhlIGVuZ2luZS5cblxuPFBhcmFtcz5cbjxTZWxlY3QgbmFtZT1cInNwYW5cIiBvcHRpb25zPXtbXCIxMm1cIiwgXCI2bVwiXX0gZGVmYXVsdD1cIjEybVwiIC8+XG48L1BhcmFtcz5cblxuPFJvdz5cbjxLcGkgc291cmNlPVwicmV2aWV3LnRvdGFsXCIgY29tcGFyZT1cInJldmlldy50b3RhbF9wcmV2XCIgZm9ybWF0PVwiY3VycmVuY3lcIiAvPlxuPEtwaSBzb3VyY2U9XCJyZXZpZXcubnJyXCIgZm9ybWF0PVwicGVyY2VudFwiIC8+XG48S3BpIHNvdXJjZT1cInJldmlldy5jaHVyblwiIGZvcm1hdD1cInBlcmNlbnRcIiAvPlxuPC9Sb3c+XG5cbiMjIE1SUiB0cmVuZC5cblxuPENoYXJ0IHNvdXJjZT1cInJldmlldy5ieV9tb250aFwiIGtpbmQ9XCJsaW5lXCIgeD1cIm1vbnRoXCIgeT1cIm1yclwiIC8+XG5cbiMjIEdyb3d0aCBjb21wb3NpdGlvbi5cblxuTmV3LCBleHBhbnNpb24gYW5kIHJlYWN0aXZhdGlvbiBNUlIgYnkgbW9udGguXG5cbjxDaGFydCBzb3VyY2U9XCJyZXZpZXcuZ3Jvd3RoX3N0YWNrXCIga2luZD1cImJhclwiIHg9XCJtb250aFwiIHk9XCJ2YWx1ZVwiIGNvbG9yPVwiZHJpdmVyXCIgc3RhY2s9XCJzdGFja2VkXCIgLz5cblxuPFJvdz5cbjxDaGFydCBzb3VyY2U9XCJyZXZpZXcubGF0ZXN0X2dyb3d0aFwiIGtpbmQ9XCJwaWVcIiB2YWx1ZT1cInZhbHVlXCIgbGFiZWw9XCJkcml2ZXJcIiAvPlxuPE1hcCBzb3VyY2U9XCJyZXZpZXcuYnlfcmVnaW9uXCIga2luZD1cImNob3JvcGxldGhcIiByZWdpb249XCJyZWdpb25cIiB2YWx1ZT1cImN1c3RvbWVyc1wiIC8+XG48L1Jvdz5cblxuPENhbGxvdXQgdG9uZT1cImluZm9cIj5cbk5ldCByZXZlbnVlIHJldGVudGlvbiBhbmQgZ3Jvc3MgY2h1cm4gYXJlIHRoZSB0d28gbGV2ZXJzIGJlaGluZCB0aGUgdHJlbmQgYWJvdmUg4oCUIHdhdGNoIHRoZW0gdG9nZXRoZXIuXG48L0NhbGxvdXQ+XG5cbiMjIENvaG9ydCByZXRlbnRpb24uXG5cblJldGVudGlvbiBjdXJ2ZXMgYnkgc2lnbnVwIGNvaG9ydCDigJQgZWFjaCBwYW5lbCBpcyBvbmUgY29ob3J0J3MgZGVjYXkuXG5cbjxGYWNldHMgc291cmNlPVwicmV2aWV3LmNvaG9ydF9jdXJ2ZXNcIiBieT1cImNvaG9ydFwiPlxuPENoYXJ0IGtpbmQ9XCJsaW5lXCIgeD1cIm9mZnNldFwiIHk9XCJyZXRlbnRpb25cIiAvPlxuPC9GYWNldHM+XG5cbiMjIE1vdmVtZW50IGRldGFpbC5cblxuPFRhYmxlIHNvdXJjZT1cInJldmlldy5tb3ZlbWVudHNcIiBjb2x1bW5zPXtbXCJtb250aFwiLCBcIm5ld01yclwiLCBcImV4cGFuc2lvblwiLCBcImNvbnRyYWN0aW9uXCIsIFwiY2h1cm5lZFwiLCBcImVuZE1yclwiXX0gc29ydGFibGUgLz5cbmA7XG5cbmNvbnN0IHByb3ZlbmFuY2UgPSB7IHNvdXJjZUZlZWQ6ICdtZXJpZGlhbicsIGNhcHR1cmVkQXQ6ICcyMDI2LTA3LTA5JywgY2FwdHVyZUFjdG9yOiAnZ2VuZXJhdGUucHknLCBzeW50aGV0aWM6IHRydWUgfTtcbmNvbnN0IGZyYW1lID0gKHJvd3M6IHVua25vd24pOiBzdHJpbmcgPT4gSlNPTi5zdHJpbmdpZnkoeyByb3dzLCBwcm92ZW5hbmNlLCB0aWVyOiAnc3RhdGljJyB9KTtcblxuLyoqIFRoZSBkb2N1bWVudCBhcyBhbiBpbi1tZW1vcnkgZmlsZSBtYXAsIGtleWVkIGJ5IGRvY3VtZW50LXJvb3QtcmVsYXRpdmUgcGF0aC4gKi9cbmV4cG9ydCBjb25zdCBTRUVEX0ZJTEVTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAnbWVyaWRpYW4vcmVja29uZXIuanNvbic6IEpTT04uc3RyaW5naWZ5KG1hbmlmZXN0KSxcbiAgJ21lcmlkaWFuL3dvcmtzaGVldHMvcmV2aWV3LnNoZWV0LmpzJzogcmV2aWV3U2hlZXQsXG4gICdtZXJpZGlhbi90ZW1wbGF0ZXMvd2Vla2x5Lm1keCc6IHdlZWtseVRlbXBsYXRlLFxuICAnbWVyaWRpYW4vZml4dHVyZXMvZXhlY19zdW1tYXJ5LmZyYW1lLmpzb24nOiBmcmFtZShleGVjU3VtbWFyeSksXG4gICdtZXJpZGlhbi9maXh0dXJlcy9tcnJfbW92ZW1lbnRzLmZyYW1lLmpzb24nOiBmcmFtZShtcnJNb3ZlbWVudHMpLFxuICAnbWVyaWRpYW4vZml4dHVyZXMvcmVnaW9uX2N1c3RvbWVycy5mcmFtZS5qc29uJzogZnJhbWUocmVnaW9uQ3VzdG9tZXJzKSxcbiAgJ21lcmlkaWFuL2ZpeHR1cmVzL2NvaG9ydF9yZXRlbnRpb24uZnJhbWUuanNvbic6IGZyYW1lKGNvaG9ydFJldGVudGlvbiksXG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFVQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS08sTUFBTUMsU0FBUyxHQUFBQyxPQUFBLENBQUFELFNBQUEsR0FBRyxVQUFVO0FBRW5DLE1BQU1FLFFBQVEsR0FBRztFQUNmQyxNQUFNLEVBQUUsQ0FBQztFQUNUQyxNQUFNLEVBQUU7SUFBRUMsTUFBTSxFQUFFLFNBQVM7SUFBRUMsT0FBTyxFQUFFO0VBQVUsQ0FBQztFQUNqREMsWUFBWSxFQUFFO0lBQUVDLEdBQUcsRUFBRSxVQUFVO0lBQUVILE1BQU0sRUFBRSxPQUFPO0lBQUVDLE9BQU8sRUFBRTtFQUFRLENBQUM7RUFDcEVHLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQztFQUN0QkMsTUFBTSxFQUFFO0lBQUVDLElBQUksRUFBRTtFQUFNLENBQTBCO0VBQ2hEQyxLQUFLLEVBQUU7QUFDVCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLFdBQVcsR0FBRztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLGNBQWMsR0FBRztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBRUQsTUFBTUMsVUFBVSxHQUFHO0VBQUVDLFVBQVUsRUFBRSxVQUFVO0VBQUVDLFVBQVUsRUFBRSxZQUFZO0VBQUVDLFlBQVksRUFBRSxhQUFhO0VBQUVDLFNBQVMsRUFBRTtBQUFLLENBQUM7QUFDckgsTUFBTUMsS0FBSyxHQUFJQyxJQUFhLElBQWFDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO0VBQUVGLElBQUk7RUFBRU4sVUFBVTtFQUFFUyxJQUFJLEVBQUU7QUFBUyxDQUFDLENBQUM7O0FBRTdGO0FBQ08sTUFBTUMsVUFBa0MsR0FBQXhCLE9BQUEsQ0FBQXdCLFVBQUEsR0FBRztFQUNoRCx3QkFBd0IsRUFBRUgsSUFBSSxDQUFDQyxTQUFTLENBQUNyQixRQUFRLENBQUM7RUFDbEQscUNBQXFDLEVBQUVXLFdBQVc7RUFDbEQsK0JBQStCLEVBQUVDLGNBQWM7RUFDL0MsMkNBQTJDLEVBQUVNLEtBQUssQ0FBQ00saUJBQVcsQ0FBQztFQUMvRCw0Q0FBNEMsRUFBRU4sS0FBSyxDQUFDTyxrQkFBWSxDQUFDO0VBQ2pFLCtDQUErQyxFQUFFUCxLQUFLLENBQUNRLHFCQUFlLENBQUM7RUFDdkUsK0NBQStDLEVBQUVSLEtBQUssQ0FBQ1MscUJBQWU7QUFDeEUsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==