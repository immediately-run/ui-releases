"use strict";

var _vitest = require("vitest");
var stdlib = _interopRequireWildcard(require("../stdlib/index.ts"));
var _compartment = require("./compartment.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// A worksheet in its already-transpiled (plain JS) form, as the sandbox produces in-platform.
const WORKSHEET = `
import { cell, table, sum } from "@reckoner/stdlib";

export const by_month = cell({
  doc: "revenue by month",
  inputs: { orders: "feeds.orders" },
  formula: ({ orders }) => table(orders).groupBy("month").rollup({ revenue: sum("eur") }).rows(),
});

export const total = cell({
  doc: "total revenue",
  inputs: { m: "revenue.by_month" },
  formula: ({ m }) => m.reduce((a, r) => a + r.revenue, 0),
});

export const NOTE = "not a cell — must be ignored";
`;
(0, _vitest.describe)('evaluateWorksheet — real SES Compartment', () => {
  (0, _vitest.it)('extracts the registered cells (ignoring non-cell exports)', () => {
    const defs = (0, _compartment.evaluateWorksheet)(WORKSHEET, stdlib);
    (0, _vitest.expect)(Object.keys(defs).sort()).toEqual(['by_month', 'total']);
    (0, _vitest.expect)(defs.by_month.kind).toBe('cell');
    (0, _vitest.expect)(defs.by_month.dependencies).toEqual(['feeds.orders']);
    (0, _vitest.expect)(defs.total.dependencies).toEqual(['revenue.by_month']);
  });
  (0, _vitest.it)('the confined formula computes correctly using the endowed stdlib', () => {
    const defs = (0, _compartment.evaluateWorksheet)(WORKSHEET, stdlib);
    const orders = [{
      month: '2026-01',
      eur: 100
    }, {
      month: '2026-02',
      eur: 50
    }, {
      month: '2026-01',
      eur: 40
    }];
    const result = defs.by_month.formula({
      orders
    });
    (0, _vitest.expect)(result).toEqual([{
      month: '2026-01',
      revenue: 140
    }, {
      month: '2026-02',
      revenue: 50
    }]);
  });
});
(0, _vitest.describe)('evaluateConfined — starvation', () => {
  (0, _vitest.it)('evaluates with endowments and reaches no ambient globals', () => {
    (0, _vitest.expect)((0, _compartment.evaluateConfined)('add(20, 22)', {
      add: (a, b) => a + b
    })).toBe(42);
    (0, _vitest.expect)((0, _compartment.evaluateConfined)('typeof process')).toBe('undefined');
    (0, _vitest.expect)((0, _compartment.evaluateConfined)('typeof fetch')).toBe('undefined');
    (0, _vitest.expect)((0, _compartment.evaluateConfined)('typeof globalThis.require')).toBe('undefined');
  });
  (0, _vitest.it)('a worksheet formula cannot reach ambient state either', () => {
    const src = `
      import { cell } from "@reckoner/stdlib";
      export const probe = cell({ doc: "probe", formula: () => typeof process });
    `;
    const defs = (0, _compartment.evaluateWorksheet)(src, stdlib);
    (0, _vitest.expect)(defs.probe.formula({})).toBe('undefined');
  });
});
(0, _vitest.describe)('evaluateWorksheet — line-anchored transform (WHATIF_SHADOW_EVALUATION_SPEC §3.3, G-WIF-1a)', () => {
  (0, _vitest.it)('leaves `export const` inside a formula string literal untouched and registers no phantom export', () => {
    const sheet = `
import { cell } from "@reckoner/stdlib";

export const label = cell({
  doc: "a formula whose result contains the token text",
  formula: () => "export const x = 1",
});
`;
    const defs = (0, _compartment.evaluateWorksheet)(sheet, stdlib);
    // No phantom `x` export collected from inside the string; the build succeeds.
    (0, _vitest.expect)(Object.keys(defs)).toEqual(['label']);
    const def = defs.label;
    // The rewrite did not reach into the formula: toString round-trips file text verbatim,
    // which is what the what-if splice's fidelity assumption rests on.
    (0, _vitest.expect)(def.formula.toString()).toContain('"export const x = 1"');
    (0, _vitest.expect)(def.formula({})).toBe('export const x = 1');
  });
});
(0, _vitest.describe)('exportSpans — declaration blocks on the raw source (R3-427)', () => {
  const lines = ['import { cell } from "@reckoner/stdlib";', '', 'export const a = cell({', '  doc: "first",', '  formula: () => 1,', '});', '', 'export const b = cell({', '  doc: "second — its formula RETURNS the token text",', '  formula: () => "export const x = 1",', '});', ''];
  const sheet = lines.join('\n');
  (0, _vitest.it)('spans every export, contiguous blocks, keyword-anchored lines — and no phantom span from a string literal', () => {
    const spans = (0, _compartment.exportSpans)(sheet);
    (0, _vitest.expect)(Object.keys(spans).sort()).toEqual(['a', 'b']); // no phantom `x` from the string
    (0, _vitest.expect)(spans.a.line).toBe(3);
    (0, _vitest.expect)(spans.b.line).toBe(8);
    (0, _vitest.expect)(spans.a.end).toBeLessThanOrEqual(spans.b.start);
    (0, _vitest.expect)(spans.b.end).toBe(sheet.length);
    // Each block really contains its own declaration — including the token-bearing string.
    (0, _vitest.expect)(sheet.slice(spans.a.start, spans.a.end)).toContain('doc: "first"');
    (0, _vitest.expect)(sheet.slice(spans.b.start, spans.b.end)).toContain('export const x = 1');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsInN0ZGxpYiIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX2NvbXBhcnRtZW50IiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwiV09SS1NIRUVUIiwiZGVzY3JpYmUiLCJpdCIsImRlZnMiLCJldmFsdWF0ZVdvcmtzaGVldCIsImV4cGVjdCIsImtleXMiLCJzb3J0IiwidG9FcXVhbCIsImJ5X21vbnRoIiwia2luZCIsInRvQmUiLCJkZXBlbmRlbmNpZXMiLCJ0b3RhbCIsIm9yZGVycyIsIm1vbnRoIiwiZXVyIiwicmVzdWx0IiwiZm9ybXVsYSIsInJldmVudWUiLCJldmFsdWF0ZUNvbmZpbmVkIiwiYWRkIiwiYiIsInNyYyIsInByb2JlIiwic2hlZXQiLCJkZWYiLCJsYWJlbCIsInRvU3RyaW5nIiwidG9Db250YWluIiwibGluZXMiLCJqb2luIiwic3BhbnMiLCJleHBvcnRTcGFucyIsImxpbmUiLCJlbmQiLCJ0b0JlTGVzc1RoYW5PckVxdWFsIiwic3RhcnQiLCJsZW5ndGgiLCJzbGljZSJdLCJzb3VyY2VzIjpbImNvbXBhcnRtZW50LnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0ICogYXMgc3RkbGliIGZyb20gJy4uL3N0ZGxpYi9pbmRleC50cyc7XG5pbXBvcnQgeyBldmFsdWF0ZVdvcmtzaGVldCwgZXZhbHVhdGVDb25maW5lZCwgZXhwb3J0U3BhbnMgfSBmcm9tICcuL2NvbXBhcnRtZW50LnRzJztcbmltcG9ydCB0eXBlIHsgQ2VsbERlZiB9IGZyb20gJy4uL3N0ZGxpYi9jZWxsLnRzJztcbmltcG9ydCB0eXBlIHsgUm93IH0gZnJvbSAnLi4vc3RkbGliL3R5cGVzLnRzJztcblxuLy8gQSB3b3Jrc2hlZXQgaW4gaXRzIGFscmVhZHktdHJhbnNwaWxlZCAocGxhaW4gSlMpIGZvcm0sIGFzIHRoZSBzYW5kYm94IHByb2R1Y2VzIGluLXBsYXRmb3JtLlxuY29uc3QgV09SS1NIRUVUID0gYFxuaW1wb3J0IHsgY2VsbCwgdGFibGUsIHN1bSB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5cbmV4cG9ydCBjb25zdCBieV9tb250aCA9IGNlbGwoe1xuICBkb2M6IFwicmV2ZW51ZSBieSBtb250aFwiLFxuICBpbnB1dHM6IHsgb3JkZXJzOiBcImZlZWRzLm9yZGVyc1wiIH0sXG4gIGZvcm11bGE6ICh7IG9yZGVycyB9KSA9PiB0YWJsZShvcmRlcnMpLmdyb3VwQnkoXCJtb250aFwiKS5yb2xsdXAoeyByZXZlbnVlOiBzdW0oXCJldXJcIikgfSkucm93cygpLFxufSk7XG5cbmV4cG9ydCBjb25zdCB0b3RhbCA9IGNlbGwoe1xuICBkb2M6IFwidG90YWwgcmV2ZW51ZVwiLFxuICBpbnB1dHM6IHsgbTogXCJyZXZlbnVlLmJ5X21vbnRoXCIgfSxcbiAgZm9ybXVsYTogKHsgbSB9KSA9PiBtLnJlZHVjZSgoYSwgcikgPT4gYSArIHIucmV2ZW51ZSwgMCksXG59KTtcblxuZXhwb3J0IGNvbnN0IE5PVEUgPSBcIm5vdCBhIGNlbGwg4oCUIG11c3QgYmUgaWdub3JlZFwiO1xuYDtcblxuZGVzY3JpYmUoJ2V2YWx1YXRlV29ya3NoZWV0IOKAlCByZWFsIFNFUyBDb21wYXJ0bWVudCcsICgpID0+IHtcbiAgaXQoJ2V4dHJhY3RzIHRoZSByZWdpc3RlcmVkIGNlbGxzIChpZ25vcmluZyBub24tY2VsbCBleHBvcnRzKScsICgpID0+IHtcbiAgICBjb25zdCBkZWZzID0gZXZhbHVhdGVXb3Jrc2hlZXQoV09SS1NIRUVULCBzdGRsaWIpO1xuICAgIGV4cGVjdChPYmplY3Qua2V5cyhkZWZzKS5zb3J0KCkpLnRvRXF1YWwoWydieV9tb250aCcsICd0b3RhbCddKTtcbiAgICBleHBlY3QoZGVmcy5ieV9tb250aC5raW5kKS50b0JlKCdjZWxsJyk7XG4gICAgZXhwZWN0KGRlZnMuYnlfbW9udGguZGVwZW5kZW5jaWVzKS50b0VxdWFsKFsnZmVlZHMub3JkZXJzJ10pO1xuICAgIGV4cGVjdChkZWZzLnRvdGFsLmRlcGVuZGVuY2llcykudG9FcXVhbChbJ3JldmVudWUuYnlfbW9udGgnXSk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgY29uZmluZWQgZm9ybXVsYSBjb21wdXRlcyBjb3JyZWN0bHkgdXNpbmcgdGhlIGVuZG93ZWQgc3RkbGliJywgKCkgPT4ge1xuICAgIGNvbnN0IGRlZnMgPSBldmFsdWF0ZVdvcmtzaGVldChXT1JLU0hFRVQsIHN0ZGxpYik7XG4gICAgY29uc3Qgb3JkZXJzOiBSb3dbXSA9IFtcbiAgICAgIHsgbW9udGg6ICcyMDI2LTAxJywgZXVyOiAxMDAgfSxcbiAgICAgIHsgbW9udGg6ICcyMDI2LTAyJywgZXVyOiA1MCB9LFxuICAgICAgeyBtb250aDogJzIwMjYtMDEnLCBldXI6IDQwIH0sXG4gICAgXTtcbiAgICBjb25zdCByZXN1bHQgPSAoZGVmcy5ieV9tb250aCBhcyBDZWxsRGVmKS5mb3JtdWxhKHsgb3JkZXJzIH0pO1xuICAgIGV4cGVjdChyZXN1bHQpLnRvRXF1YWwoW1xuICAgICAgeyBtb250aDogJzIwMjYtMDEnLCByZXZlbnVlOiAxNDAgfSxcbiAgICAgIHsgbW9udGg6ICcyMDI2LTAyJywgcmV2ZW51ZTogNTAgfSxcbiAgICBdKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ2V2YWx1YXRlQ29uZmluZWQg4oCUIHN0YXJ2YXRpb24nLCAoKSA9PiB7XG4gIGl0KCdldmFsdWF0ZXMgd2l0aCBlbmRvd21lbnRzIGFuZCByZWFjaGVzIG5vIGFtYmllbnQgZ2xvYmFscycsICgpID0+IHtcbiAgICBleHBlY3QoZXZhbHVhdGVDb25maW5lZCgnYWRkKDIwLCAyMiknLCB7IGFkZDogKGE6IG51bWJlciwgYjogbnVtYmVyKSA9PiBhICsgYiB9KSkudG9CZSg0Mik7XG4gICAgZXhwZWN0KGV2YWx1YXRlQ29uZmluZWQoJ3R5cGVvZiBwcm9jZXNzJykpLnRvQmUoJ3VuZGVmaW5lZCcpO1xuICAgIGV4cGVjdChldmFsdWF0ZUNvbmZpbmVkKCd0eXBlb2YgZmV0Y2gnKSkudG9CZSgndW5kZWZpbmVkJyk7XG4gICAgZXhwZWN0KGV2YWx1YXRlQ29uZmluZWQoJ3R5cGVvZiBnbG9iYWxUaGlzLnJlcXVpcmUnKSkudG9CZSgndW5kZWZpbmVkJyk7XG4gIH0pO1xuXG4gIGl0KCdhIHdvcmtzaGVldCBmb3JtdWxhIGNhbm5vdCByZWFjaCBhbWJpZW50IHN0YXRlIGVpdGhlcicsICgpID0+IHtcbiAgICBjb25zdCBzcmMgPSBgXG4gICAgICBpbXBvcnQgeyBjZWxsIH0gZnJvbSBcIkByZWNrb25lci9zdGRsaWJcIjtcbiAgICAgIGV4cG9ydCBjb25zdCBwcm9iZSA9IGNlbGwoeyBkb2M6IFwicHJvYmVcIiwgZm9ybXVsYTogKCkgPT4gdHlwZW9mIHByb2Nlc3MgfSk7XG4gICAgYDtcbiAgICBjb25zdCBkZWZzID0gZXZhbHVhdGVXb3Jrc2hlZXQoc3JjLCBzdGRsaWIpO1xuICAgIGV4cGVjdCgoZGVmcy5wcm9iZSBhcyBDZWxsRGVmKS5mb3JtdWxhKHt9KSkudG9CZSgndW5kZWZpbmVkJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdldmFsdWF0ZVdvcmtzaGVldCDigJQgbGluZS1hbmNob3JlZCB0cmFuc2Zvcm0gKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMy4zLCBHLVdJRi0xYSknLCAoKSA9PiB7XG4gIGl0KCdsZWF2ZXMgYGV4cG9ydCBjb25zdGAgaW5zaWRlIGEgZm9ybXVsYSBzdHJpbmcgbGl0ZXJhbCB1bnRvdWNoZWQgYW5kIHJlZ2lzdGVycyBubyBwaGFudG9tIGV4cG9ydCcsICgpID0+IHtcbiAgICBjb25zdCBzaGVldCA9IGBcbmltcG9ydCB7IGNlbGwgfSBmcm9tIFwiQHJlY2tvbmVyL3N0ZGxpYlwiO1xuXG5leHBvcnQgY29uc3QgbGFiZWwgPSBjZWxsKHtcbiAgZG9jOiBcImEgZm9ybXVsYSB3aG9zZSByZXN1bHQgY29udGFpbnMgdGhlIHRva2VuIHRleHRcIixcbiAgZm9ybXVsYTogKCkgPT4gXCJleHBvcnQgY29uc3QgeCA9IDFcIixcbn0pO1xuYDtcbiAgICBjb25zdCBkZWZzID0gZXZhbHVhdGVXb3Jrc2hlZXQoc2hlZXQsIHN0ZGxpYik7XG4gICAgLy8gTm8gcGhhbnRvbSBgeGAgZXhwb3J0IGNvbGxlY3RlZCBmcm9tIGluc2lkZSB0aGUgc3RyaW5nOyB0aGUgYnVpbGQgc3VjY2VlZHMuXG4gICAgZXhwZWN0KE9iamVjdC5rZXlzKGRlZnMpKS50b0VxdWFsKFsnbGFiZWwnXSk7XG4gICAgY29uc3QgZGVmID0gZGVmcy5sYWJlbCBhcyBDZWxsRGVmO1xuICAgIC8vIFRoZSByZXdyaXRlIGRpZCBub3QgcmVhY2ggaW50byB0aGUgZm9ybXVsYTogdG9TdHJpbmcgcm91bmQtdHJpcHMgZmlsZSB0ZXh0IHZlcmJhdGltLFxuICAgIC8vIHdoaWNoIGlzIHdoYXQgdGhlIHdoYXQtaWYgc3BsaWNlJ3MgZmlkZWxpdHkgYXNzdW1wdGlvbiByZXN0cyBvbi5cbiAgICBleHBlY3QoZGVmLmZvcm11bGEudG9TdHJpbmcoKSkudG9Db250YWluKCdcImV4cG9ydCBjb25zdCB4ID0gMVwiJyk7XG4gICAgZXhwZWN0KGRlZi5mb3JtdWxhKHt9KSkudG9CZSgnZXhwb3J0IGNvbnN0IHggPSAxJyk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCdleHBvcnRTcGFucyDigJQgZGVjbGFyYXRpb24gYmxvY2tzIG9uIHRoZSByYXcgc291cmNlIChSMy00MjcpJywgKCkgPT4ge1xuICBjb25zdCBsaW5lcyA9IFtcbiAgICAnaW1wb3J0IHsgY2VsbCB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7JyxcbiAgICAnJyxcbiAgICAnZXhwb3J0IGNvbnN0IGEgPSBjZWxsKHsnLFxuICAgICcgIGRvYzogXCJmaXJzdFwiLCcsXG4gICAgJyAgZm9ybXVsYTogKCkgPT4gMSwnLFxuICAgICd9KTsnLFxuICAgICcnLFxuICAgICdleHBvcnQgY29uc3QgYiA9IGNlbGwoeycsXG4gICAgJyAgZG9jOiBcInNlY29uZCDigJQgaXRzIGZvcm11bGEgUkVUVVJOUyB0aGUgdG9rZW4gdGV4dFwiLCcsXG4gICAgJyAgZm9ybXVsYTogKCkgPT4gXCJleHBvcnQgY29uc3QgeCA9IDFcIiwnLFxuICAgICd9KTsnLFxuICAgICcnLFxuICBdO1xuICBjb25zdCBzaGVldCA9IGxpbmVzLmpvaW4oJ1xcbicpO1xuXG4gIGl0KCdzcGFucyBldmVyeSBleHBvcnQsIGNvbnRpZ3VvdXMgYmxvY2tzLCBrZXl3b3JkLWFuY2hvcmVkIGxpbmVzIOKAlCBhbmQgbm8gcGhhbnRvbSBzcGFuIGZyb20gYSBzdHJpbmcgbGl0ZXJhbCcsICgpID0+IHtcbiAgICBjb25zdCBzcGFucyA9IGV4cG9ydFNwYW5zKHNoZWV0KTtcbiAgICBleHBlY3QoT2JqZWN0LmtleXMoc3BhbnMpLnNvcnQoKSkudG9FcXVhbChbJ2EnLCAnYiddKTsgLy8gbm8gcGhhbnRvbSBgeGAgZnJvbSB0aGUgc3RyaW5nXG4gICAgZXhwZWN0KHNwYW5zLmEubGluZSkudG9CZSgzKTtcbiAgICBleHBlY3Qoc3BhbnMuYi5saW5lKS50b0JlKDgpO1xuICAgIGV4cGVjdChzcGFucy5hLmVuZCkudG9CZUxlc3NUaGFuT3JFcXVhbChzcGFucy5iLnN0YXJ0KTtcbiAgICBleHBlY3Qoc3BhbnMuYi5lbmQpLnRvQmUoc2hlZXQubGVuZ3RoKTtcbiAgICAvLyBFYWNoIGJsb2NrIHJlYWxseSBjb250YWlucyBpdHMgb3duIGRlY2xhcmF0aW9uIOKAlCBpbmNsdWRpbmcgdGhlIHRva2VuLWJlYXJpbmcgc3RyaW5nLlxuICAgIGV4cGVjdChzaGVldC5zbGljZShzcGFucy5hLnN0YXJ0LCBzcGFucy5hLmVuZCkpLnRvQ29udGFpbignZG9jOiBcImZpcnN0XCInKTtcbiAgICBleHBlY3Qoc2hlZXQuc2xpY2Uoc3BhbnMuYi5zdGFydCwgc3BhbnMuYi5lbmQpKS50b0NvbnRhaW4oJ2V4cG9ydCBjb25zdCB4ID0gMScpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUMsdUJBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLFlBQUEsR0FBQUgsT0FBQTtBQUFvRixTQUFBSSx5QkFBQUMsQ0FBQSw2QkFBQUMsT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRix3QkFBQSxZQUFBQSxDQUFBQyxDQUFBLFdBQUFBLENBQUEsR0FBQUcsQ0FBQSxHQUFBRCxDQUFBLEtBQUFGLENBQUE7QUFBQSxTQUFBSCx3QkFBQUcsQ0FBQSxFQUFBRSxDQUFBLFNBQUFBLENBQUEsSUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUFJLFVBQUEsU0FBQUosQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFLLE9BQUEsRUFBQUwsQ0FBQSxRQUFBRyxDQUFBLEdBQUFKLHdCQUFBLENBQUFHLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFHLEdBQUEsQ0FBQU4sQ0FBQSxVQUFBRyxDQUFBLENBQUFJLEdBQUEsQ0FBQVAsQ0FBQSxPQUFBUSxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFkLENBQUEsb0JBQUFjLENBQUEsT0FBQUMsY0FBQSxDQUFBQyxJQUFBLENBQUFoQixDQUFBLEVBQUFjLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWIsQ0FBQSxFQUFBYyxDQUFBLFVBQUFHLENBQUEsS0FBQUEsQ0FBQSxDQUFBVixHQUFBLElBQUFVLENBQUEsQ0FBQUMsR0FBQSxJQUFBUCxNQUFBLENBQUFDLGNBQUEsQ0FBQUosQ0FBQSxFQUFBTSxDQUFBLEVBQUFHLENBQUEsSUFBQVQsQ0FBQSxDQUFBTSxDQUFBLElBQUFkLENBQUEsQ0FBQWMsQ0FBQSxZQUFBTixDQUFBLENBQUFILE9BQUEsR0FBQUwsQ0FBQSxFQUFBRyxDQUFBLElBQUFBLENBQUEsQ0FBQWUsR0FBQSxDQUFBbEIsQ0FBQSxFQUFBUSxDQUFBLEdBQUFBLENBQUE7QUFJcEY7QUFDQSxNQUFNVyxTQUFTLEdBQUc7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUVELElBQUFDLGdCQUFRLEVBQUMsMENBQTBDLEVBQUUsTUFBTTtFQUN6RCxJQUFBQyxVQUFFLEVBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsOEJBQWlCLEVBQUNKLFNBQVMsRUFBRXZCLE1BQU0sQ0FBQztJQUNqRCxJQUFBNEIsY0FBTSxFQUFDYixNQUFNLENBQUNjLElBQUksQ0FBQ0gsSUFBSSxDQUFDLENBQUNJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQy9ELElBQUFILGNBQU0sRUFBQ0YsSUFBSSxDQUFDTSxRQUFRLENBQUNDLElBQUksQ0FBQyxDQUFDQyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3ZDLElBQUFOLGNBQU0sRUFBQ0YsSUFBSSxDQUFDTSxRQUFRLENBQUNHLFlBQVksQ0FBQyxDQUFDSixPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUM1RCxJQUFBSCxjQUFNLEVBQUNGLElBQUksQ0FBQ1UsS0FBSyxDQUFDRCxZQUFZLENBQUMsQ0FBQ0osT0FBTyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsa0VBQWtFLEVBQUUsTUFBTTtJQUMzRSxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsOEJBQWlCLEVBQUNKLFNBQVMsRUFBRXZCLE1BQU0sQ0FBQztJQUNqRCxNQUFNcUMsTUFBYSxHQUFHLENBQ3BCO01BQUVDLEtBQUssRUFBRSxTQUFTO01BQUVDLEdBQUcsRUFBRTtJQUFJLENBQUMsRUFDOUI7TUFBRUQsS0FBSyxFQUFFLFNBQVM7TUFBRUMsR0FBRyxFQUFFO0lBQUcsQ0FBQyxFQUM3QjtNQUFFRCxLQUFLLEVBQUUsU0FBUztNQUFFQyxHQUFHLEVBQUU7SUFBRyxDQUFDLENBQzlCO0lBQ0QsTUFBTUMsTUFBTSxHQUFJZCxJQUFJLENBQUNNLFFBQVEsQ0FBYVMsT0FBTyxDQUFDO01BQUVKO0lBQU8sQ0FBQyxDQUFDO0lBQzdELElBQUFULGNBQU0sRUFBQ1ksTUFBTSxDQUFDLENBQUNULE9BQU8sQ0FBQyxDQUNyQjtNQUFFTyxLQUFLLEVBQUUsU0FBUztNQUFFSSxPQUFPLEVBQUU7SUFBSSxDQUFDLEVBQ2xDO01BQUVKLEtBQUssRUFBRSxTQUFTO01BQUVJLE9BQU8sRUFBRTtJQUFHLENBQUMsQ0FDbEMsQ0FBQztFQUNKLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFsQixnQkFBUSxFQUFDLCtCQUErQixFQUFFLE1BQU07RUFDOUMsSUFBQUMsVUFBRSxFQUFDLDBEQUEwRCxFQUFFLE1BQU07SUFDbkUsSUFBQUcsY0FBTSxFQUFDLElBQUFlLDZCQUFnQixFQUFDLGFBQWEsRUFBRTtNQUFFQyxHQUFHLEVBQUVBLENBQUM5QixDQUFTLEVBQUUrQixDQUFTLEtBQUsvQixDQUFDLEdBQUcrQjtJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNYLElBQUksQ0FBQyxFQUFFLENBQUM7SUFDMUYsSUFBQU4sY0FBTSxFQUFDLElBQUFlLDZCQUFnQixFQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ1QsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUM1RCxJQUFBTixjQUFNLEVBQUMsSUFBQWUsNkJBQWdCLEVBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ1QsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUMxRCxJQUFBTixjQUFNLEVBQUMsSUFBQWUsNkJBQWdCLEVBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDVCxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3pFLENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQyx1REFBdUQsRUFBRSxNQUFNO0lBQ2hFLE1BQU1xQixHQUFHLEdBQUc7QUFDaEI7QUFDQTtBQUNBLEtBQUs7SUFDRCxNQUFNcEIsSUFBSSxHQUFHLElBQUFDLDhCQUFpQixFQUFDbUIsR0FBRyxFQUFFOUMsTUFBTSxDQUFDO0lBQzNDLElBQUE0QixjQUFNLEVBQUVGLElBQUksQ0FBQ3FCLEtBQUssQ0FBYU4sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ1AsSUFBSSxDQUFDLFdBQVcsQ0FBQztFQUMvRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBVixnQkFBUSxFQUFDLDRGQUE0RixFQUFFLE1BQU07RUFDM0csSUFBQUMsVUFBRSxFQUFDLGlHQUFpRyxFQUFFLE1BQU07SUFDMUcsTUFBTXVCLEtBQUssR0FBRztBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0lBQ0csTUFBTXRCLElBQUksR0FBRyxJQUFBQyw4QkFBaUIsRUFBQ3FCLEtBQUssRUFBRWhELE1BQU0sQ0FBQztJQUM3QztJQUNBLElBQUE0QixjQUFNLEVBQUNiLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDSCxJQUFJLENBQUMsQ0FBQyxDQUFDSyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM1QyxNQUFNa0IsR0FBRyxHQUFHdkIsSUFBSSxDQUFDd0IsS0FBZ0I7SUFDakM7SUFDQTtJQUNBLElBQUF0QixjQUFNLEVBQUNxQixHQUFHLENBQUNSLE9BQU8sQ0FBQ1UsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxTQUFTLENBQUMsc0JBQXNCLENBQUM7SUFDaEUsSUFBQXhCLGNBQU0sRUFBQ3FCLEdBQUcsQ0FBQ1IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ1AsSUFBSSxDQUFDLG9CQUFvQixDQUFDO0VBQ3BELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFWLGdCQUFRLEVBQUMsNkRBQTZELEVBQUUsTUFBTTtFQUM1RSxNQUFNNkIsS0FBSyxHQUFHLENBQ1osMENBQTBDLEVBQzFDLEVBQUUsRUFDRix5QkFBeUIsRUFDekIsaUJBQWlCLEVBQ2pCLHFCQUFxQixFQUNyQixLQUFLLEVBQ0wsRUFBRSxFQUNGLHlCQUF5QixFQUN6Qix1REFBdUQsRUFDdkQsd0NBQXdDLEVBQ3hDLEtBQUssRUFDTCxFQUFFLENBQ0g7RUFDRCxNQUFNTCxLQUFLLEdBQUdLLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztFQUU5QixJQUFBN0IsVUFBRSxFQUFDLDJHQUEyRyxFQUFFLE1BQU07SUFDcEgsTUFBTThCLEtBQUssR0FBRyxJQUFBQyx3QkFBVyxFQUFDUixLQUFLLENBQUM7SUFDaEMsSUFBQXBCLGNBQU0sRUFBQ2IsTUFBTSxDQUFDYyxJQUFJLENBQUMwQixLQUFLLENBQUMsQ0FBQ3pCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2RCxJQUFBSCxjQUFNLEVBQUMyQixLQUFLLENBQUN6QyxDQUFDLENBQUMyQyxJQUFJLENBQUMsQ0FBQ3ZCLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDNUIsSUFBQU4sY0FBTSxFQUFDMkIsS0FBSyxDQUFDVixDQUFDLENBQUNZLElBQUksQ0FBQyxDQUFDdkIsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM1QixJQUFBTixjQUFNLEVBQUMyQixLQUFLLENBQUN6QyxDQUFDLENBQUM0QyxHQUFHLENBQUMsQ0FBQ0MsbUJBQW1CLENBQUNKLEtBQUssQ0FBQ1YsQ0FBQyxDQUFDZSxLQUFLLENBQUM7SUFDdEQsSUFBQWhDLGNBQU0sRUFBQzJCLEtBQUssQ0FBQ1YsQ0FBQyxDQUFDYSxHQUFHLENBQUMsQ0FBQ3hCLElBQUksQ0FBQ2MsS0FBSyxDQUFDYSxNQUFNLENBQUM7SUFDdEM7SUFDQSxJQUFBakMsY0FBTSxFQUFDb0IsS0FBSyxDQUFDYyxLQUFLLENBQUNQLEtBQUssQ0FBQ3pDLENBQUMsQ0FBQzhDLEtBQUssRUFBRUwsS0FBSyxDQUFDekMsQ0FBQyxDQUFDNEMsR0FBRyxDQUFDLENBQUMsQ0FBQ04sU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUN6RSxJQUFBeEIsY0FBTSxFQUFDb0IsS0FBSyxDQUFDYyxLQUFLLENBQUNQLEtBQUssQ0FBQ1YsQ0FBQyxDQUFDZSxLQUFLLEVBQUVMLEtBQUssQ0FBQ1YsQ0FBQyxDQUFDYSxHQUFHLENBQUMsQ0FBQyxDQUFDTixTQUFTLENBQUMsb0JBQW9CLENBQUM7RUFDakYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119