var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SuiteSummary;
var _suiteReport = require("../../../engine/suiteReport.ts");
var _reflectionContext = require("../reflectionContext.ts");
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // SuiteSummary — the reflection component rendering the workbook-level suite line
// (AUTHORS_VIEW_SPEC §2, §3.4): the SAME `summarizeSuite` over the SAME results object
// the workbook panel shows — one computation, two surfaces that cannot disagree. A
// pending suite renders the panel's "Running suites…" line, never a verdict count
// (`summarizeSuite(cells, null)` would count every cell untested — the false-verdict
// render G-AV-6 forbids).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function SuiteSummary({
  node: _node
}) {
  _s();
  void _node; // uniform NodeComponent signature; SuiteSummary takes no attributes
  const reflection = (0, _reflectionContext.useReflection)();
  if (reflection === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
      component: "SuiteSummary",
      reason: "available only in the author's view"
    });
  }
  if (reflection.verdicts === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-refl-suite rk-refl-suite--pending",
      children: "Running suites\u2026"
    });
  }
  const report = (0, _suiteReport.summarizeSuite)(reflection.cells(), reflection.verdicts);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: `rk-refl-suite ${report.ok ? 'rk-refl-suite--ok' : 'rk-refl-suite--fail'}`,
    role: "status",
    children: report.line
  });
}
_s(SuiteSummary, "EcuPFGw29ARuTs47OEyfycl8jbM=", false, function () {
  return [_reflectionContext.useReflection];
});
_c = SuiteSummary;
var _c;
$RefreshReg$(_c, "SuiteSummary");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc3VpdGVSZXBvcnQiLCJyZXF1aXJlIiwiX3JlZmxlY3Rpb25Db250ZXh0IiwiX0Jyb2tlblRpbGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlN1aXRlU3VtbWFyeSIsIm5vZGUiLCJfbm9kZSIsInJlZmxlY3Rpb24iLCJ1c2VSZWZsZWN0aW9uIiwianN4IiwiY29tcG9uZW50IiwicmVhc29uIiwidmVyZGljdHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsInJlcG9ydCIsInN1bW1hcml6ZVN1aXRlIiwiY2VsbHMiLCJvayIsInJvbGUiLCJsaW5lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTdWl0ZVN1bW1hcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFN1aXRlU3VtbWFyeSDigJQgdGhlIHJlZmxlY3Rpb24gY29tcG9uZW50IHJlbmRlcmluZyB0aGUgd29ya2Jvb2stbGV2ZWwgc3VpdGUgbGluZVxuLy8gKEFVVEhPUlNfVklFV19TUEVDIMKnMiwgwqczLjQpOiB0aGUgU0FNRSBgc3VtbWFyaXplU3VpdGVgIG92ZXIgdGhlIFNBTUUgcmVzdWx0cyBvYmplY3Rcbi8vIHRoZSB3b3JrYm9vayBwYW5lbCBzaG93cyDigJQgb25lIGNvbXB1dGF0aW9uLCB0d28gc3VyZmFjZXMgdGhhdCBjYW5ub3QgZGlzYWdyZWUuIEFcbi8vIHBlbmRpbmcgc3VpdGUgcmVuZGVycyB0aGUgcGFuZWwncyBcIlJ1bm5pbmcgc3VpdGVz4oCmXCIgbGluZSwgbmV2ZXIgYSB2ZXJkaWN0IGNvdW50XG4vLyAoYHN1bW1hcml6ZVN1aXRlKGNlbGxzLCBudWxsKWAgd291bGQgY291bnQgZXZlcnkgY2VsbCB1bnRlc3RlZCDigJQgdGhlIGZhbHNlLXZlcmRpY3Rcbi8vIHJlbmRlciBHLUFWLTYgZm9yYmlkcykuXG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudE5vZGUgfSBmcm9tICcuLi8uLi9ub2Rlcy50cyc7XG5pbXBvcnQgeyBzdW1tYXJpemVTdWl0ZSB9IGZyb20gJy4uLy4uLy4uL2VuZ2luZS9zdWl0ZVJlcG9ydC50cyc7XG5pbXBvcnQgeyB1c2VSZWZsZWN0aW9uIH0gZnJvbSAnLi4vcmVmbGVjdGlvbkNvbnRleHQudHMnO1xuaW1wb3J0IEJyb2tlblRpbGUgZnJvbSAnLi9Ccm9rZW5UaWxlLnRzeCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN1aXRlU3VtbWFyeSh7IG5vZGU6IF9ub2RlIH06IHsgbm9kZTogQ29tcG9uZW50Tm9kZSB9KSB7XG4gIHZvaWQgX25vZGU7IC8vIHVuaWZvcm0gTm9kZUNvbXBvbmVudCBzaWduYXR1cmU7IFN1aXRlU3VtbWFyeSB0YWtlcyBubyBhdHRyaWJ1dGVzXG4gIGNvbnN0IHJlZmxlY3Rpb24gPSB1c2VSZWZsZWN0aW9uKCk7XG4gIGlmIChyZWZsZWN0aW9uID09PSBudWxsKSB7XG4gICAgcmV0dXJuIDxCcm9rZW5UaWxlIGNvbXBvbmVudD1cIlN1aXRlU3VtbWFyeVwiIHJlYXNvbj1cImF2YWlsYWJsZSBvbmx5IGluIHRoZSBhdXRob3IncyB2aWV3XCIgLz47XG4gIH1cbiAgaWYgKHJlZmxlY3Rpb24udmVyZGljdHMgPT09IG51bGwpIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJyay1yZWZsLXN1aXRlIHJrLXJlZmwtc3VpdGUtLXBlbmRpbmdcIj5SdW5uaW5nIHN1aXRlc+KApjwvZGl2PjtcbiAgfVxuICBjb25zdCByZXBvcnQgPSBzdW1tYXJpemVTdWl0ZShyZWZsZWN0aW9uLmNlbGxzKCksIHJlZmxlY3Rpb24udmVyZGljdHMpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgcmstcmVmbC1zdWl0ZSAke3JlcG9ydC5vayA/ICdyay1yZWZsLXN1aXRlLS1vaycgOiAncmstcmVmbC1zdWl0ZS0tZmFpbCd9YH0gcm9sZT1cInN0YXR1c1wiPlxuICAgICAge3JlcG9ydC5saW5lfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFPQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxrQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQTBDLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVQxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQU1lLFNBQVNHLFlBQVlBLENBQUM7RUFBRUMsSUFBSSxFQUFFQztBQUErQixDQUFDLEVBQUU7RUFBQVAsRUFBQTtFQUM3RSxLQUFLTyxLQUFLLENBQUMsQ0FBQztFQUNaLE1BQU1DLFVBQVUsR0FBRyxJQUFBQyxnQ0FBYSxFQUFDLENBQUM7RUFDbEMsSUFBSUQsVUFBVSxLQUFLLElBQUksRUFBRTtJQUN2QixvQkFBTyxJQUFBVCxXQUFBLENBQUFXLEdBQUEsRUFBQ2IsV0FBQSxDQUFBTyxPQUFVO01BQUNPLFNBQVMsRUFBQyxjQUFjO01BQUNDLE1BQU0sRUFBQztJQUFxQyxDQUFFLENBQUM7RUFDN0Y7RUFDQSxJQUFJSixVQUFVLENBQUNLLFFBQVEsS0FBSyxJQUFJLEVBQUU7SUFDaEMsb0JBQU8sSUFBQWQsV0FBQSxDQUFBVyxHQUFBO01BQUtJLFNBQVMsRUFBQyxzQ0FBc0M7TUFBQUMsUUFBQSxFQUFDO0lBQWUsQ0FBSyxDQUFDO0VBQ3BGO0VBQ0EsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDJCQUFjLEVBQUNULFVBQVUsQ0FBQ1UsS0FBSyxDQUFDLENBQUMsRUFBRVYsVUFBVSxDQUFDSyxRQUFRLENBQUM7RUFDdEUsb0JBQ0UsSUFBQWQsV0FBQSxDQUFBVyxHQUFBO0lBQUtJLFNBQVMsRUFBRSxpQkFBaUJFLE1BQU0sQ0FBQ0csRUFBRSxHQUFHLG1CQUFtQixHQUFHLHFCQUFxQixFQUFHO0lBQUNDLElBQUksRUFBQyxRQUFRO0lBQUFMLFFBQUEsRUFDdEdDLE1BQU0sQ0FBQ0s7RUFBSSxDQUNULENBQUM7QUFFVjtBQUFDckIsRUFBQSxDQWZ1QkssWUFBWTtFQUFBLFFBRWZJLGdDQUFhO0FBQUE7QUFBQWEsRUFBQSxHQUZWakIsWUFBWTtBQUFBLElBQUFpQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}