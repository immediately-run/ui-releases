var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Placeholder;
var _jsxRuntime = require("react/jsx-runtime");
// The unknown-component placeholder (§3.3): a document may name a component this app doesn't
// provide (a fork's component, a newer catalog entry). It renders a visible, explanatory
// block — never a page-killing error, never silent omission — which is also the fork story:
// component *usages* are content, so a document degrades gracefully in stock Reckoner.
function Placeholder({
  name
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rk-placeholder",
    role: "note",
    children: ["This report uses ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("code", {
      children: ["<", name, ">"]
    }), ", which this app doesn't provide."]
  });
}
_c = Placeholder;
var _c;
$RefreshReg$(_c, "Placeholder");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQbGFjZWhvbGRlciIsIm5hbWUiLCJfanN4UnVudGltZSIsImpzeHMiLCJjbGFzc05hbWUiLCJyb2xlIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBsYWNlaG9sZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgdW5rbm93bi1jb21wb25lbnQgcGxhY2Vob2xkZXIgKMKnMy4zKTogYSBkb2N1bWVudCBtYXkgbmFtZSBhIGNvbXBvbmVudCB0aGlzIGFwcCBkb2Vzbid0XG4vLyBwcm92aWRlIChhIGZvcmsncyBjb21wb25lbnQsIGEgbmV3ZXIgY2F0YWxvZyBlbnRyeSkuIEl0IHJlbmRlcnMgYSB2aXNpYmxlLCBleHBsYW5hdG9yeVxuLy8gYmxvY2sg4oCUIG5ldmVyIGEgcGFnZS1raWxsaW5nIGVycm9yLCBuZXZlciBzaWxlbnQgb21pc3Npb24g4oCUIHdoaWNoIGlzIGFsc28gdGhlIGZvcmsgc3Rvcnk6XG4vLyBjb21wb25lbnQgKnVzYWdlcyogYXJlIGNvbnRlbnQsIHNvIGEgZG9jdW1lbnQgZGVncmFkZXMgZ3JhY2VmdWxseSBpbiBzdG9jayBSZWNrb25lci5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBsYWNlaG9sZGVyKHsgbmFtZSB9OiB7IG5hbWU6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyay1wbGFjZWhvbGRlclwiIHJvbGU9XCJub3RlXCI+XG4gICAgICBUaGlzIHJlcG9ydCB1c2VzIDxjb2RlPiZsdDt7bmFtZX0mZ3Q7PC9jb2RlPiwgd2hpY2ggdGhpcyBhcHAgZG9lc24mYXBvczt0IHByb3ZpZGUuXG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNlLFNBQVNBLFdBQVdBLENBQUM7RUFBRUM7QUFBdUIsQ0FBQyxFQUFFO0VBQzlELG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsSUFBQTtJQUFLQyxTQUFTLEVBQUMsZ0JBQWdCO0lBQUNDLElBQUksRUFBQyxNQUFNO0lBQUFDLFFBQUEsR0FBQyxtQkFDekIsbUJBQUFKLFdBQUEsQ0FBQUMsSUFBQTtNQUFBRyxRQUFBLEdBQU0sR0FBSSxFQUFDTCxJQUFJLEVBQUMsR0FBSTtJQUFBLENBQU0sQ0FBQyxxQ0FDOUM7RUFBQSxDQUFLLENBQUM7QUFFVjtBQUFDTSxFQUFBLEdBTnVCUCxXQUFXO0FBQUEsSUFBQU8sRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}