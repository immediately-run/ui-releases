var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = BrokenBoundTile;
var _BrokenTile = _interopRequireDefault(require("./BrokenTile.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// BrokenBoundTile — the one shared degraded-binding state (R3-788 review, R6): every bound
// component renders this when its binding cannot answer, so a future BindingStatus arm
// changes here, once, instead of drifting across per-component copies of the Kpi mapping
// (Kpi/Chart/Table/Facets/Gauge/GeoMap/Flow still carry their own; migrating them is its
// own item). `missing` reads as a needs-access affordance, `error` as a broken tile with
// the binding's message.

function BrokenBoundTile({
  component,
  bound
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BrokenTile.default, {
    component: component,
    reason: bound.message ?? 'unavailable',
    variant: bound.status === 'missing' ? 'needs-access' : 'error'
  });
}
_c = BrokenBoundTile;
var _c;
$RefreshReg$(_c, "BrokenBoundTile");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfQnJva2VuVGlsZSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJCcm9rZW5Cb3VuZFRpbGUiLCJjb21wb25lbnQiLCJib3VuZCIsImpzeCIsInJlYXNvbiIsIm1lc3NhZ2UiLCJ2YXJpYW50Iiwic3RhdHVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCcm9rZW5Cb3VuZFRpbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEJyb2tlbkJvdW5kVGlsZSDigJQgdGhlIG9uZSBzaGFyZWQgZGVncmFkZWQtYmluZGluZyBzdGF0ZSAoUjMtNzg4IHJldmlldywgUjYpOiBldmVyeSBib3VuZFxuLy8gY29tcG9uZW50IHJlbmRlcnMgdGhpcyB3aGVuIGl0cyBiaW5kaW5nIGNhbm5vdCBhbnN3ZXIsIHNvIGEgZnV0dXJlIEJpbmRpbmdTdGF0dXMgYXJtXG4vLyBjaGFuZ2VzIGhlcmUsIG9uY2UsIGluc3RlYWQgb2YgZHJpZnRpbmcgYWNyb3NzIHBlci1jb21wb25lbnQgY29waWVzIG9mIHRoZSBLcGkgbWFwcGluZ1xuLy8gKEtwaS9DaGFydC9UYWJsZS9GYWNldHMvR2F1Z2UvR2VvTWFwL0Zsb3cgc3RpbGwgY2FycnkgdGhlaXIgb3duOyBtaWdyYXRpbmcgdGhlbSBpcyBpdHNcbi8vIG93biBpdGVtKS4gYG1pc3NpbmdgIHJlYWRzIGFzIGEgbmVlZHMtYWNjZXNzIGFmZm9yZGFuY2UsIGBlcnJvcmAgYXMgYSBicm9rZW4gdGlsZSB3aXRoXG4vLyB0aGUgYmluZGluZydzIG1lc3NhZ2UuXG5pbXBvcnQgdHlwZSB7IEJvdW5kVmFsdWUgfSBmcm9tICcuLi9iaW5kaW5ncy50cyc7XG5pbXBvcnQgQnJva2VuVGlsZSBmcm9tICcuL0Jyb2tlblRpbGUudHN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQnJva2VuQm91bmRUaWxlKHsgY29tcG9uZW50LCBib3VuZCB9OiB7IGNvbXBvbmVudDogc3RyaW5nOyBib3VuZDogQm91bmRWYWx1ZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPEJyb2tlblRpbGVcbiAgICAgIGNvbXBvbmVudD17Y29tcG9uZW50fVxuICAgICAgcmVhc29uPXtib3VuZC5tZXNzYWdlID8/ICd1bmF2YWlsYWJsZSd9XG4gICAgICB2YXJpYW50PXtib3VuZC5zdGF0dXMgPT09ICdtaXNzaW5nJyA/ICduZWVkcy1hY2Nlc3MnIDogJ2Vycm9yJ31cbiAgICAvPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFPQSxJQUFBQSxXQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFBMEMsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsU0FBQUQsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFQMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUllLFNBQVNHLGVBQWVBLENBQUM7RUFBRUMsU0FBUztFQUFFQztBQUFnRCxDQUFDLEVBQUU7RUFDdEcsb0JBQ0UsSUFBQU4sV0FBQSxDQUFBTyxHQUFBLEVBQUNWLFdBQUEsQ0FBQU0sT0FBVTtJQUNURSxTQUFTLEVBQUVBLFNBQVU7SUFDckJHLE1BQU0sRUFBRUYsS0FBSyxDQUFDRyxPQUFPLElBQUksYUFBYztJQUN2Q0MsT0FBTyxFQUFFSixLQUFLLENBQUNLLE1BQU0sS0FBSyxTQUFTLEdBQUcsY0FBYyxHQUFHO0VBQVEsQ0FDaEUsQ0FBQztBQUVOO0FBQUNDLEVBQUEsR0FSdUJSLGVBQWU7QUFBQSxJQUFBUSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}