var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _AgentDemo = _interopRequireDefault(require("./components/AgentDemo"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The embedded-agent demo (UI_AS_APPS_SPEC §5.5 / §5.9 / G12): an app reads its
// own grant-FILTERED method catalog and treats it as the agent's tool list. Any
// "agent" — here a manual/scripted tool-runner standing in for an LLM — can only
// drive the methods in that list; naming a method OUTSIDE it still hits the §8.4
// gate and returns `forbidden`. Agent confinement therefore equals APP
// confinement: it falls out of the capability model, with no agent sandbox.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_AgentDemo.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0FnZW50RGVtbyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIFRoZSBlbWJlZGRlZC1hZ2VudCBkZW1vIChVSV9BU19BUFBTX1NQRUMgwqc1LjUgLyDCpzUuOSAvIEcxMik6IGFuIGFwcCByZWFkcyBpdHNcbi8vIG93biBncmFudC1GSUxURVJFRCBtZXRob2QgY2F0YWxvZyBhbmQgdHJlYXRzIGl0IGFzIHRoZSBhZ2VudCdzIHRvb2wgbGlzdC4gQW55XG4vLyBcImFnZW50XCIg4oCUIGhlcmUgYSBtYW51YWwvc2NyaXB0ZWQgdG9vbC1ydW5uZXIgc3RhbmRpbmcgaW4gZm9yIGFuIExMTSDigJQgY2FuIG9ubHlcbi8vIGRyaXZlIHRoZSBtZXRob2RzIGluIHRoYXQgbGlzdDsgbmFtaW5nIGEgbWV0aG9kIE9VVFNJREUgaXQgc3RpbGwgaGl0cyB0aGUgwqc4LjRcbi8vIGdhdGUgYW5kIHJldHVybnMgYGZvcmJpZGRlbmAuIEFnZW50IGNvbmZpbmVtZW50IHRoZXJlZm9yZSBlcXVhbHMgQVBQXG4vLyBjb25maW5lbWVudDogaXQgZmFsbHMgb3V0IG9mIHRoZSBjYXBhYmlsaXR5IG1vZGVsLCB3aXRoIG5vIGFnZW50IHNhbmRib3guXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IEFnZW50RGVtbyBmcm9tIFwiLi9jb21wb25lbnRzL0FnZW50RGVtb1wiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiA8QWdlbnREZW1vIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BQSxPQUFBO0FBQ0EsSUFBQUMsVUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQStDLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUi9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUNiLG9CQUFPLElBQUFKLFdBQUEsQ0FBQUssR0FBQSxFQUFDUCxVQUFBLENBQUFLLE9BQVMsSUFBRSxDQUFDO0FBQ3RCO0FBQUNHLEVBQUEsR0FGUUYsR0FBRztBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBTCxPQUFBLEdBSUdDLEdBQUc7QUFBQSxJQUFBRSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}