var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = AgentDemo;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
require("./AgentDemo.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The embedded-agent demo (§5.5 / §5.9). Shows the app's grant-filtered method
// catalog AS the agent's tool list, lets you "run" a tool through `invoke()`, and
// proves confinement (G12/T23): a method NOT in the catalog — named directly —
// still returns `forbidden` at the host gate. A real LLM agent would be handed
// `useCatalog()` verbatim as its tools; the principle is identical.
// A method we deliberately do NOT hold (this app's grant lacks spaces:admin), to
// show the gate refusing an off-catalog call — the agent can't escape its grant.
const OFF_CATALOG = "spaces:share";

// §5.6 L2 inter-app messaging (T19). This app's binding declares an ipc edge to
// panel.files ONLY (`ipc.to: ["panel.files"]`). Posting there is delivered (the
// file explorer declared it `accepts` us); posting anywhere else is refused at the
// host — the same two-sided-consent confinement the catalog gate shows above.
const FILES_REGION = "panel.files";
const NO_EDGE_REGION = "panel.spaces";
function AgentDemo() {
  _s();
  const catalog = (0, _sdk.useCatalog)();
  const [log, setLog] = (0, _react.useState)([]);
  const [running, setRunning] = (0, _react.useState)(null);
  const run = async name => {
    setRunning(name);
    try {
      const value = await (0, _sdk.invoke)(name, {});
      setLog(l => [{
        name,
        result: {
          kind: "ok",
          value
        }
      }, ...l]);
    } catch (e) {
      const code = e?.code ?? "error";
      setLog(l => [{
        name,
        result: {
          kind: "err",
          code,
          message: e?.message ?? String(e)
        }
      }, ...l]);
    } finally {
      setRunning(null);
    }
  };
  const inCatalog = name => catalog.some(m => m.name === name);

  // --- inter-app messaging (§5.6) ------------------------------------------
  const [path, setPath] = (0, _react.useState)("/README.md");
  const [ipcLog, setIpcLog] = (0, _react.useState)([]);
  const [posting, setPosting] = (0, _react.useState)(null);

  // --- task invocation (§5.7): invoke another app, get a typed result back ------
  const [color, setColor] = (0, _react.useState)("#3b82f6");
  const [picking, setPicking] = (0, _react.useState)(false);
  const [pickNote, setPickNote] = (0, _react.useState)(null);
  const pickColor = async () => {
    setPicking(true);
    setPickNote(null);
    try {
      const res = await (0, _sdk.invokeTask)("pick-color", {
        initial: color
      });
      if (res?.color) setColor(res.color);
    } catch (e) {
      const code = e?.code ?? "error";
      // `cancelled` is a normal outcome (user dismissed the overlay), not an error.
      setPickNote(code === "cancelled" ? "cancelled" : code);
    } finally {
      setPicking(false);
    }
  };

  // --- file delegation (§5.7/§8.7): hand a callee a file from MY OWN space -------
  const [editing, setEditing] = (0, _react.useState)(false);
  const [editNote, setEditNote] = (0, _react.useState)(null);
  const editFile = async () => {
    setEditing(true);
    setEditNote(null);
    try {
      // Open this app's own workspace (a granted space), then delegate ONE file in
      // it to the bound edit-file app — the host mints an attenuated chroot; this
      // app never sees the editor's code, only the typed { saved } result.
      const space = await (0, _sdk.openAppSpace)();
      const res = await (0, _sdk.invokeTask)("edit-file", {
        file: (0, _sdk.capFile)({
          mountId: `space:${space.id}`,
          relPath: "demo.txt"
        }, {
          mode: "rw"
        })
      });
      setEditNote(res?.saved ? "saved demo.txt to your space ✓" : "done");
    } catch (e) {
      const code = e?.code ?? "error";
      setEditNote(code === "cancelled" ? "cancelled" : code === "auth-required" ? "sign in to use a space" : code);
    } finally {
      setEditing(false);
    }
  };
  const post = async (to, data) => {
    setPosting(to);
    try {
      await (0, _sdk.postToRegion)(to, data);
      setIpcLog(l => [{
        to,
        result: {
          kind: "ok",
          value: "delivered"
        }
      }, ...l]);
    } catch (e) {
      const code = e?.code ?? "error";
      setIpcLog(l => [{
        to,
        result: {
          kind: "err",
          code,
          message: e?.message ?? String(e)
        }
      }, ...l]);
    } finally {
      setPosting(null);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ad",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ad-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ad-title",
        children: "Agent tools"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "ad-sub",
        children: [catalog.length, " in this app's catalog"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ad-tools",
      children: catalog.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "ad-tool",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          className: "ad-name",
          children: m.name
        }), m.stream && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-badge",
          children: "stream"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: running === m.name || m.stream,
          title: m.stream ? "streaming — use invokeStream" : `requires ${m.capability}`,
          onClick: () => run(m.name),
          children: running === m.name ? "…" : "Run"
        })]
      }, m.name))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Confinement check (G12)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: OFF_CATALOG
        }), " is ", inCatalog(OFF_CATALOG) ? "in" : "NOT in", " this app's catalog. Calling it anyway should be refused by the host gate:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "ad-run ad-danger",
        onClick: () => run(OFF_CATALOG),
        children: ["Try ", OFF_CATALOG]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Message another panel (\xA75.6, T19)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["This app declares an ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "ipc"
        }), " edge to ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: FILES_REGION
        }), " only. Ask the file explorer to reveal a path \u2014 it\u2019ll show the message with a host-attached (unspoofable) ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "from"
        }), ":"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ad-ipc-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          className: "ad-ipc-input",
          value: path,
          onChange: e => setPath(e.target.value),
          "aria-label": "Path to reveal"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: posting === FILES_REGION,
          onClick: () => post(FILES_REGION, {
            reveal: path
          }),
          children: "Reveal in Files"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["Posting to a region this app declared no edge to (", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: NO_EDGE_REGION
        }), ") is refused by the host \u2014 neither side opened it:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "ad-run ad-danger",
        disabled: posting === NO_EDGE_REGION,
        onClick: () => post(NO_EDGE_REGION, {
          reveal: path
        }),
        children: ["Try messaging ", NO_EDGE_REGION]
      }), ipcLog.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "ad-log",
        children: ipcLog.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
          className: `ad-logline ${e.result.kind}`,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
            children: e.to
          }), " \u2192", " ", e.result.kind === "ok" ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ad-ok",
            children: "delivered"
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ad-err",
            children: e.result.code
          })]
        }, i))
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Invoke another app (\xA75.7, task contract)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["A tool can call ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "pick-color"
        }), " and get a typed color back. The host loads the user's bound picker in an overlay, the picker returns a value, and this app never sees the picker's code or grants \u2014 just the result:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ad-ipc-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-color-chip",
          style: {
            background: color
          },
          "aria-label": `color ${color}`
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          className: "ad-color-val",
          children: color
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: picking,
          onClick: pickColor,
          children: picking ? "Picking…" : "Pick a color"
        })]
      }), pickNote && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["invokeTask \u2192 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: pickNote
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Delegate a file to another app (\xA75.7/\xA78.7)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["Hand the ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "edit-file"
        }), " app ONE file from your space. The host mints an attenuated, task-scoped chroot \u2014 the editor can name nothing else, and a read-only delegation is a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "EROFS"
        }), " wall. Your grant narrows; it never amplifies (G7):"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ad-run",
        disabled: editing,
        onClick: editFile,
        children: editing ? "Editing…" : "Edit demo.txt in my space"
      }), editNote && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["edit-file \u2192 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: editNote
        })]
      })]
    }), log.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ad-log",
      children: log.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: `ad-logline ${e.result.kind}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: e.name
        }), " \u2192", " ", e.result.kind === "ok" ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-ok",
          children: "ok"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: e.result.code
        })]
      }, i))
    })]
  });
}
_s(AgentDemo, "vKOhtG+oigPIBFhGDo+gQP37Y9M=", false, function () {
  return [_sdk.useCatalog];
});
_c = AgentDemo;
var _c;
$RefreshReg$(_c, "AgentDemo");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJPRkZfQ0FUQUxPRyIsIkZJTEVTX1JFR0lPTiIsIk5PX0VER0VfUkVHSU9OIiwiQWdlbnREZW1vIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJsb2ciLCJzZXRMb2ciLCJ1c2VTdGF0ZSIsInJ1bm5pbmciLCJzZXRSdW5uaW5nIiwicnVuIiwibmFtZSIsInZhbHVlIiwiaW52b2tlIiwibCIsInJlc3VsdCIsImtpbmQiLCJlIiwiY29kZSIsIm1lc3NhZ2UiLCJTdHJpbmciLCJpbkNhdGFsb2ciLCJzb21lIiwibSIsInBhdGgiLCJzZXRQYXRoIiwiaXBjTG9nIiwic2V0SXBjTG9nIiwicG9zdGluZyIsInNldFBvc3RpbmciLCJjb2xvciIsInNldENvbG9yIiwicGlja2luZyIsInNldFBpY2tpbmciLCJwaWNrTm90ZSIsInNldFBpY2tOb3RlIiwicGlja0NvbG9yIiwicmVzIiwiaW52b2tlVGFzayIsImluaXRpYWwiLCJlZGl0aW5nIiwic2V0RWRpdGluZyIsImVkaXROb3RlIiwic2V0RWRpdE5vdGUiLCJlZGl0RmlsZSIsInNwYWNlIiwib3BlbkFwcFNwYWNlIiwiZmlsZSIsImNhcEZpbGUiLCJtb3VudElkIiwiaWQiLCJyZWxQYXRoIiwibW9kZSIsInNhdmVkIiwicG9zdCIsInRvIiwiZGF0YSIsInBvc3RUb1JlZ2lvbiIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsImxlbmd0aCIsIm1hcCIsInN0cmVhbSIsInR5cGUiLCJkaXNhYmxlZCIsInRpdGxlIiwiY2FwYWJpbGl0eSIsIm9uQ2xpY2siLCJvbkNoYW5nZSIsInRhcmdldCIsInJldmVhbCIsImkiLCJzdHlsZSIsImJhY2tncm91bmQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFnZW50RGVtby50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGVtYmVkZGVkLWFnZW50IGRlbW8gKMKnNS41IC8gwqc1LjkpLiBTaG93cyB0aGUgYXBwJ3MgZ3JhbnQtZmlsdGVyZWQgbWV0aG9kXG4vLyBjYXRhbG9nIEFTIHRoZSBhZ2VudCdzIHRvb2wgbGlzdCwgbGV0cyB5b3UgXCJydW5cIiBhIHRvb2wgdGhyb3VnaCBgaW52b2tlKClgLCBhbmRcbi8vIHByb3ZlcyBjb25maW5lbWVudCAoRzEyL1QyMyk6IGEgbWV0aG9kIE5PVCBpbiB0aGUgY2F0YWxvZyDigJQgbmFtZWQgZGlyZWN0bHkg4oCUXG4vLyBzdGlsbCByZXR1cm5zIGBmb3JiaWRkZW5gIGF0IHRoZSBob3N0IGdhdGUuIEEgcmVhbCBMTE0gYWdlbnQgd291bGQgYmUgaGFuZGVkXG4vLyBgdXNlQ2F0YWxvZygpYCB2ZXJiYXRpbSBhcyBpdHMgdG9vbHM7IHRoZSBwcmluY2lwbGUgaXMgaWRlbnRpY2FsLlxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIHVzZUNhdGFsb2csXG4gIGludm9rZSxcbiAgcG9zdFRvUmVnaW9uLFxuICBpbnZva2VUYXNrLFxuICBjYXBGaWxlLFxuICBvcGVuQXBwU3BhY2UsXG4gIHR5cGUgQXBpTWV0aG9kLFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCBcIi4vQWdlbnREZW1vLmNzc1wiO1xuXG4vLyBBIG1ldGhvZCB3ZSBkZWxpYmVyYXRlbHkgZG8gTk9UIGhvbGQgKHRoaXMgYXBwJ3MgZ3JhbnQgbGFja3Mgc3BhY2VzOmFkbWluKSwgdG9cbi8vIHNob3cgdGhlIGdhdGUgcmVmdXNpbmcgYW4gb2ZmLWNhdGFsb2cgY2FsbCDigJQgdGhlIGFnZW50IGNhbid0IGVzY2FwZSBpdHMgZ3JhbnQuXG5jb25zdCBPRkZfQ0FUQUxPRyA9IFwic3BhY2VzOnNoYXJlXCI7XG5cbi8vIMKnNS42IEwyIGludGVyLWFwcCBtZXNzYWdpbmcgKFQxOSkuIFRoaXMgYXBwJ3MgYmluZGluZyBkZWNsYXJlcyBhbiBpcGMgZWRnZSB0b1xuLy8gcGFuZWwuZmlsZXMgT05MWSAoYGlwYy50bzogW1wicGFuZWwuZmlsZXNcIl1gKS4gUG9zdGluZyB0aGVyZSBpcyBkZWxpdmVyZWQgKHRoZVxuLy8gZmlsZSBleHBsb3JlciBkZWNsYXJlZCBpdCBgYWNjZXB0c2AgdXMpOyBwb3N0aW5nIGFueXdoZXJlIGVsc2UgaXMgcmVmdXNlZCBhdCB0aGVcbi8vIGhvc3Qg4oCUIHRoZSBzYW1lIHR3by1zaWRlZC1jb25zZW50IGNvbmZpbmVtZW50IHRoZSBjYXRhbG9nIGdhdGUgc2hvd3MgYWJvdmUuXG5jb25zdCBGSUxFU19SRUdJT04gPSBcInBhbmVsLmZpbGVzXCI7XG5jb25zdCBOT19FREdFX1JFR0lPTiA9IFwicGFuZWwuc3BhY2VzXCI7XG5cbnR5cGUgUmVzdWx0ID0geyBraW5kOiBcIm9rXCI7IHZhbHVlOiB1bmtub3duIH0gfCB7IGtpbmQ6IFwiZXJyXCI7IGNvZGU6IHN0cmluZzsgbWVzc2FnZTogc3RyaW5nIH07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFnZW50RGVtbygpIHtcbiAgY29uc3QgY2F0YWxvZyA9IHVzZUNhdGFsb2coKTtcbiAgY29uc3QgW2xvZywgc2V0TG9nXSA9IHVzZVN0YXRlPEFycmF5PHsgbmFtZTogc3RyaW5nOyByZXN1bHQ6IFJlc3VsdCB9Pj4oW10pO1xuICBjb25zdCBbcnVubmluZywgc2V0UnVubmluZ10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBydW4gPSBhc3luYyAobmFtZTogc3RyaW5nKSA9PiB7XG4gICAgc2V0UnVubmluZyhuYW1lKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBpbnZva2UobmFtZSwge30pO1xuICAgICAgc2V0TG9nKChsKSA9PiBbeyBuYW1lLCByZXN1bHQ6IHsga2luZDogXCJva1wiLCB2YWx1ZSB9IH0sIC4uLmxdKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIHNldExvZygobCkgPT4gW1xuICAgICAgICB7IG5hbWUsIHJlc3VsdDogeyBraW5kOiBcImVyclwiLCBjb2RlLCBtZXNzYWdlOiAoZSBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gU3RyaW5nKGUpIH0gfSxcbiAgICAgICAgLi4ubCxcbiAgICAgIF0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRSdW5uaW5nKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBpbkNhdGFsb2cgPSAobmFtZTogc3RyaW5nKSA9PiBjYXRhbG9nLnNvbWUoKG06IEFwaU1ldGhvZCkgPT4gbS5uYW1lID09PSBuYW1lKTtcblxuICAvLyAtLS0gaW50ZXItYXBwIG1lc3NhZ2luZyAowqc1LjYpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBbcGF0aCwgc2V0UGF0aF0gPSB1c2VTdGF0ZShcIi9SRUFETUUubWRcIik7XG4gIGNvbnN0IFtpcGNMb2csIHNldElwY0xvZ10gPSB1c2VTdGF0ZTxBcnJheTx7IHRvOiBzdHJpbmc7IHJlc3VsdDogUmVzdWx0IH0+PihbXSk7XG4gIGNvbnN0IFtwb3N0aW5nLCBzZXRQb3N0aW5nXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIC0tLSB0YXNrIGludm9jYXRpb24gKMKnNS43KTogaW52b2tlIGFub3RoZXIgYXBwLCBnZXQgYSB0eXBlZCByZXN1bHQgYmFjayAtLS0tLS1cbiAgY29uc3QgW2NvbG9yLCBzZXRDb2xvcl0gPSB1c2VTdGF0ZShcIiMzYjgyZjZcIik7XG4gIGNvbnN0IFtwaWNraW5nLCBzZXRQaWNraW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BpY2tOb3RlLCBzZXRQaWNrTm90ZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBwaWNrQ29sb3IgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0UGlja2luZyh0cnVlKTtcbiAgICBzZXRQaWNrTm90ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgaW52b2tlVGFzazx7IGNvbG9yOiBzdHJpbmcgfT4oXCJwaWNrLWNvbG9yXCIsIHsgaW5pdGlhbDogY29sb3IgfSk7XG4gICAgICBpZiAocmVzPy5jb2xvcikgc2V0Q29sb3IocmVzLmNvbG9yKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIC8vIGBjYW5jZWxsZWRgIGlzIGEgbm9ybWFsIG91dGNvbWUgKHVzZXIgZGlzbWlzc2VkIHRoZSBvdmVybGF5KSwgbm90IGFuIGVycm9yLlxuICAgICAgc2V0UGlja05vdGUoY29kZSA9PT0gXCJjYW5jZWxsZWRcIiA/IFwiY2FuY2VsbGVkXCIgOiBjb2RlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UGlja2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLSBmaWxlIGRlbGVnYXRpb24gKMKnNS43L8KnOC43KTogaGFuZCBhIGNhbGxlZSBhIGZpbGUgZnJvbSBNWSBPV04gc3BhY2UgLS0tLS0tLVxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0Tm90ZSwgc2V0RWRpdE5vdGVdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgZWRpdEZpbGUgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0RWRpdGluZyh0cnVlKTtcbiAgICBzZXRFZGl0Tm90ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgLy8gT3BlbiB0aGlzIGFwcCdzIG93biB3b3Jrc3BhY2UgKGEgZ3JhbnRlZCBzcGFjZSksIHRoZW4gZGVsZWdhdGUgT05FIGZpbGUgaW5cbiAgICAgIC8vIGl0IHRvIHRoZSBib3VuZCBlZGl0LWZpbGUgYXBwIOKAlCB0aGUgaG9zdCBtaW50cyBhbiBhdHRlbnVhdGVkIGNocm9vdDsgdGhpc1xuICAgICAgLy8gYXBwIG5ldmVyIHNlZXMgdGhlIGVkaXRvcidzIGNvZGUsIG9ubHkgdGhlIHR5cGVkIHsgc2F2ZWQgfSByZXN1bHQuXG4gICAgICBjb25zdCBzcGFjZSA9IGF3YWl0IG9wZW5BcHBTcGFjZSgpO1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgaW52b2tlVGFzazx7IHNhdmVkOiBib29sZWFuIH0+KFwiZWRpdC1maWxlXCIsIHtcbiAgICAgICAgZmlsZTogY2FwRmlsZSh7IG1vdW50SWQ6IGBzcGFjZToke3NwYWNlLmlkfWAsIHJlbFBhdGg6IFwiZGVtby50eHRcIiB9LCB7IG1vZGU6IFwicndcIiB9KSxcbiAgICAgIH0pO1xuICAgICAgc2V0RWRpdE5vdGUocmVzPy5zYXZlZCA/IFwic2F2ZWQgZGVtby50eHQgdG8geW91ciBzcGFjZSDinJNcIiA6IFwiZG9uZVwiKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIHNldEVkaXROb3RlKFxuICAgICAgICBjb2RlID09PSBcImNhbmNlbGxlZFwiXG4gICAgICAgICAgPyBcImNhbmNlbGxlZFwiXG4gICAgICAgICAgOiBjb2RlID09PSBcImF1dGgtcmVxdWlyZWRcIlxuICAgICAgICAgICAgPyBcInNpZ24gaW4gdG8gdXNlIGEgc3BhY2VcIlxuICAgICAgICAgICAgOiBjb2RlLFxuICAgICAgKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0RWRpdGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHBvc3QgPSBhc3luYyAodG86IHN0cmluZywgZGF0YTogdW5rbm93bikgPT4ge1xuICAgIHNldFBvc3RpbmcodG8pO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBwb3N0VG9SZWdpb24odG8sIGRhdGEpO1xuICAgICAgc2V0SXBjTG9nKChsKSA9PiBbeyB0bywgcmVzdWx0OiB7IGtpbmQ6IFwib2tcIiwgdmFsdWU6IFwiZGVsaXZlcmVkXCIgfSB9LCAuLi5sXSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZSA/PyBcImVycm9yXCI7XG4gICAgICBzZXRJcGNMb2coKGwpID0+IFtcbiAgICAgICAgeyB0bywgcmVzdWx0OiB7IGtpbmQ6IFwiZXJyXCIsIGNvZGUsIG1lc3NhZ2U6IChlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBTdHJpbmcoZSkgfSB9LFxuICAgICAgICAuLi5sLFxuICAgICAgXSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFBvc3RpbmcobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhZFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJhZC1oZFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZC10aXRsZVwiPkFnZW50IHRvb2xzPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZC1zdWJcIj57Y2F0YWxvZy5sZW5ndGh9IGluIHRoaXMgYXBwJ3MgY2F0YWxvZzwvc3Bhbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiYWQtdG9vbHNcIj5cbiAgICAgICAge2NhdGFsb2cubWFwKChtKSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17bS5uYW1lfSBjbGFzc05hbWU9XCJhZC10b29sXCI+XG4gICAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJhZC1uYW1lXCI+e20ubmFtZX08L2NvZGU+XG4gICAgICAgICAgICB7bS5zdHJlYW0gJiYgPHNwYW4gY2xhc3NOYW1lPVwiYWQtYmFkZ2VcIj5zdHJlYW08L3NwYW4+fVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWQtcnVuXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3J1bm5pbmcgPT09IG0ubmFtZSB8fCBtLnN0cmVhbX1cbiAgICAgICAgICAgICAgdGl0bGU9e20uc3RyZWFtID8gXCJzdHJlYW1pbmcg4oCUIHVzZSBpbnZva2VTdHJlYW1cIiA6IGByZXF1aXJlcyAke20uY2FwYWJpbGl0eX1gfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBydW4obS5uYW1lKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3J1bm5pbmcgPT09IG0ubmFtZSA/IFwi4oCmXCIgOiBcIlJ1blwifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkLWVzY2FwZVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtaFwiPkNvbmZpbmVtZW50IGNoZWNrIChHMTIpPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgPGNvZGU+e09GRl9DQVRBTE9HfTwvY29kZT4gaXMge2luQ2F0YWxvZyhPRkZfQ0FUQUxPRykgPyBcImluXCIgOiBcIk5PVCBpblwifSB0aGlzIGFwcCdzXG4gICAgICAgICAgY2F0YWxvZy4gQ2FsbGluZyBpdCBhbnl3YXkgc2hvdWxkIGJlIHJlZnVzZWQgYnkgdGhlIGhvc3QgZ2F0ZTpcbiAgICAgICAgPC9wPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhZC1ydW4gYWQtZGFuZ2VyXCIgb25DbGljaz17KCkgPT4gcnVuKE9GRl9DQVRBTE9HKX0+XG4gICAgICAgICAgVHJ5IHtPRkZfQ0FUQUxPR31cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZC1lc2NhcGVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLWhcIj5NZXNzYWdlIGFub3RoZXIgcGFuZWwgKMKnNS42LCBUMTkpPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgVGhpcyBhcHAgZGVjbGFyZXMgYW4gPGNvZGU+aXBjPC9jb2RlPiBlZGdlIHRvIDxjb2RlPntGSUxFU19SRUdJT059PC9jb2RlPiBvbmx5LlxuICAgICAgICAgIEFzayB0aGUgZmlsZSBleHBsb3JlciB0byByZXZlYWwgYSBwYXRoIOKAlCBpdOKAmWxsIHNob3cgdGhlIG1lc3NhZ2Ugd2l0aCBhIGhvc3QtYXR0YWNoZWRcbiAgICAgICAgICAodW5zcG9vZmFibGUpIDxjb2RlPmZyb208L2NvZGU+OlxuICAgICAgICA8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtaXBjLXJvd1wiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWQtaXBjLWlucHV0XCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXRofVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXRoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJQYXRoIHRvIHJldmVhbFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFkLXJ1blwiXG4gICAgICAgICAgICBkaXNhYmxlZD17cG9zdGluZyA9PT0gRklMRVNfUkVHSU9OfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcG9zdChGSUxFU19SRUdJT04sIHsgcmV2ZWFsOiBwYXRoIH0pfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIFJldmVhbCBpbiBGaWxlc1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgIFBvc3RpbmcgdG8gYSByZWdpb24gdGhpcyBhcHAgZGVjbGFyZWQgbm8gZWRnZSB0byAoPGNvZGU+e05PX0VER0VfUkVHSU9OfTwvY29kZT4pIGlzXG4gICAgICAgICAgcmVmdXNlZCBieSB0aGUgaG9zdCDigJQgbmVpdGhlciBzaWRlIG9wZW5lZCBpdDpcbiAgICAgICAgPC9wPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWQtcnVuIGFkLWRhbmdlclwiXG4gICAgICAgICAgZGlzYWJsZWQ9e3Bvc3RpbmcgPT09IE5PX0VER0VfUkVHSU9OfVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHBvc3QoTk9fRURHRV9SRUdJT04sIHsgcmV2ZWFsOiBwYXRoIH0pfVxuICAgICAgICA+XG4gICAgICAgICAgVHJ5IG1lc3NhZ2luZyB7Tk9fRURHRV9SRUdJT059XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHtpcGNMb2cubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImFkLWxvZ1wiPlxuICAgICAgICAgICAge2lwY0xvZy5tYXAoKGUsIGkpID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17aX0gY2xhc3NOYW1lPXtgYWQtbG9nbGluZSAke2UucmVzdWx0LmtpbmR9YH0+XG4gICAgICAgICAgICAgICAgPGNvZGU+e2UudG99PC9jb2RlPiDihpJ7XCIgXCJ9XG4gICAgICAgICAgICAgICAge2UucmVzdWx0LmtpbmQgPT09IFwib2tcIiA/IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFkLW9rXCI+ZGVsaXZlcmVkPC9zcGFuPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZC1lcnJcIj57ZS5yZXN1bHQuY29kZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZC1lc2NhcGVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLWhcIj5JbnZva2UgYW5vdGhlciBhcHAgKMKnNS43LCB0YXNrIGNvbnRyYWN0KTwvcD5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgIEEgdG9vbCBjYW4gY2FsbCA8Y29kZT5waWNrLWNvbG9yPC9jb2RlPiBhbmQgZ2V0IGEgdHlwZWQgY29sb3IgYmFjay4gVGhlIGhvc3RcbiAgICAgICAgICBsb2FkcyB0aGUgdXNlcidzIGJvdW5kIHBpY2tlciBpbiBhbiBvdmVybGF5LCB0aGUgcGlja2VyIHJldHVybnMgYSB2YWx1ZSwgYW5kXG4gICAgICAgICAgdGhpcyBhcHAgbmV2ZXIgc2VlcyB0aGUgcGlja2VyJ3MgY29kZSBvciBncmFudHMg4oCUIGp1c3QgdGhlIHJlc3VsdDpcbiAgICAgICAgPC9wPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkLWlwYy1yb3dcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZC1jb2xvci1jaGlwXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogY29sb3IgfX0gYXJpYS1sYWJlbD17YGNvbG9yICR7Y29sb3J9YH0gLz5cbiAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJhZC1jb2xvci12YWxcIj57Y29sb3J9PC9jb2RlPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImFkLXJ1blwiIGRpc2FibGVkPXtwaWNraW5nfSBvbkNsaWNrPXtwaWNrQ29sb3J9PlxuICAgICAgICAgICAge3BpY2tpbmcgPyBcIlBpY2tpbmfigKZcIiA6IFwiUGljayBhIGNvbG9yXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7cGlja05vdGUgJiYgKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1zdWJcIj5cbiAgICAgICAgICAgIGludm9rZVRhc2sg4oaSIDxzcGFuIGNsYXNzTmFtZT1cImFkLWVyclwiPntwaWNrTm90ZX08L3NwYW4+XG4gICAgICAgICAgPC9wPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtZXNjYXBlXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1oXCI+RGVsZWdhdGUgYSBmaWxlIHRvIGFub3RoZXIgYXBwICjCpzUuNy/CpzguNyk8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1zdWJcIj5cbiAgICAgICAgICBIYW5kIHRoZSA8Y29kZT5lZGl0LWZpbGU8L2NvZGU+IGFwcCBPTkUgZmlsZSBmcm9tIHlvdXIgc3BhY2UuIFRoZSBob3N0IG1pbnRzXG4gICAgICAgICAgYW4gYXR0ZW51YXRlZCwgdGFzay1zY29wZWQgY2hyb290IOKAlCB0aGUgZWRpdG9yIGNhbiBuYW1lIG5vdGhpbmcgZWxzZSwgYW5kIGFcbiAgICAgICAgICByZWFkLW9ubHkgZGVsZWdhdGlvbiBpcyBhIHJlYWwgPGNvZGU+RVJPRlM8L2NvZGU+IHdhbGwuIFlvdXIgZ3JhbnQgbmFycm93cztcbiAgICAgICAgICBpdCBuZXZlciBhbXBsaWZpZXMgKEc3KTpcbiAgICAgICAgPC9wPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhZC1ydW5cIiBkaXNhYmxlZD17ZWRpdGluZ30gb25DbGljaz17ZWRpdEZpbGV9PlxuICAgICAgICAgIHtlZGl0aW5nID8gXCJFZGl0aW5n4oCmXCIgOiBcIkVkaXQgZGVtby50eHQgaW4gbXkgc3BhY2VcIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHtlZGl0Tm90ZSAmJiAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgICAgZWRpdC1maWxlIOKGkiA8c3BhbiBjbGFzc05hbWU9XCJhZC1lcnJcIj57ZWRpdE5vdGV9PC9zcGFuPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7bG9nLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYWQtbG9nXCI+XG4gICAgICAgICAge2xvZy5tYXAoKGUsIGkpID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e2l9IGNsYXNzTmFtZT17YGFkLWxvZ2xpbmUgJHtlLnJlc3VsdC5raW5kfWB9PlxuICAgICAgICAgICAgICA8Y29kZT57ZS5uYW1lfTwvY29kZT4g4oaSe1wiIFwifVxuICAgICAgICAgICAgICB7ZS5yZXN1bHQua2luZCA9PT0gXCJva1wiID8gKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFkLW9rXCI+b2s8L3NwYW4+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWQtZXJyXCI+e2UucmVzdWx0LmNvZGV9PC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUtBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQVNBQSxPQUFBO0FBQXlCLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUFBLElBQUFHLEVBQUEsR0FBQUMsWUFBQSxJQWZ6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYUE7QUFDQTtBQUNBLE1BQU1DLFdBQVcsR0FBRyxjQUFjOztBQUVsQztBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLFlBQVksR0FBRyxhQUFhO0FBQ2xDLE1BQU1DLGNBQWMsR0FBRyxjQUFjO0FBSXRCLFNBQVNDLFNBQVNBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2xDLE1BQU1NLE9BQU8sR0FBRyxJQUFBQyxlQUFVLEVBQUMsQ0FBQztFQUM1QixNQUFNLENBQUNDLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUEwQyxFQUFFLENBQUM7RUFDM0UsTUFBTSxDQUFDQyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBRTNELE1BQU1HLEdBQUcsR0FBRyxNQUFPQyxJQUFZLElBQUs7SUFDbENGLFVBQVUsQ0FBQ0UsSUFBSSxDQUFDO0lBQ2hCLElBQUk7TUFDRixNQUFNQyxLQUFLLEdBQUcsTUFBTSxJQUFBQyxXQUFNLEVBQUNGLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztNQUNwQ0wsTUFBTSxDQUFFUSxDQUFDLElBQUssQ0FBQztRQUFFSCxJQUFJO1FBQUVJLE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUUsSUFBSTtVQUFFSjtRQUFNO01BQUUsQ0FBQyxFQUFFLEdBQUdFLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUMsQ0FBQyxPQUFPRyxDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUksSUFBSSxPQUFPO01BQ3REWixNQUFNLENBQUVRLENBQUMsSUFBSyxDQUNaO1FBQUVILElBQUk7UUFBRUksTUFBTSxFQUFFO1VBQUVDLElBQUksRUFBRSxLQUFLO1VBQUVFLElBQUk7VUFBRUMsT0FBTyxFQUFHRixDQUFDLEVBQVlFLE9BQU8sSUFBSUMsTUFBTSxDQUFDSCxDQUFDO1FBQUU7TUFBRSxDQUFDLEVBQ3BGLEdBQUdILENBQUMsQ0FDTCxDQUFDO0lBQ0osQ0FBQyxTQUFTO01BQ1JMLFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDbEI7RUFDRixDQUFDO0VBRUQsTUFBTVksU0FBUyxHQUFJVixJQUFZLElBQUtSLE9BQU8sQ0FBQ21CLElBQUksQ0FBRUMsQ0FBWSxJQUFLQSxDQUFDLENBQUNaLElBQUksS0FBS0EsSUFBSSxDQUFDOztFQUVuRjtFQUNBLE1BQU0sQ0FBQ2EsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBbEIsZUFBUSxFQUFDLFlBQVksQ0FBQztFQUM5QyxNQUFNLENBQUNtQixNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFwQixlQUFRLEVBQXdDLEVBQUUsQ0FBQztFQUMvRSxNQUFNLENBQUNxQixPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUF0QixlQUFRLEVBQWdCLElBQUksQ0FBQzs7RUFFM0Q7RUFDQSxNQUFNLENBQUN1QixLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUF4QixlQUFRLEVBQUMsU0FBUyxDQUFDO0VBQzdDLE1BQU0sQ0FBQ3lCLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQTFCLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDN0MsTUFBTSxDQUFDMkIsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBNUIsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFFN0QsTUFBTTZCLFNBQVMsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDNUJILFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDaEJFLFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFDakIsSUFBSTtNQUNGLE1BQU1FLEdBQUcsR0FBRyxNQUFNLElBQUFDLGVBQVUsRUFBb0IsWUFBWSxFQUFFO1FBQUVDLE9BQU8sRUFBRVQ7TUFBTSxDQUFDLENBQUM7TUFDakYsSUFBSU8sR0FBRyxFQUFFUCxLQUFLLEVBQUVDLFFBQVEsQ0FBQ00sR0FBRyxDQUFDUCxLQUFLLENBQUM7SUFDckMsQ0FBQyxDQUFDLE9BQU9iLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSSxJQUFJLE9BQU87TUFDdEQ7TUFDQWlCLFdBQVcsQ0FBQ2pCLElBQUksS0FBSyxXQUFXLEdBQUcsV0FBVyxHQUFHQSxJQUFJLENBQUM7SUFDeEQsQ0FBQyxTQUFTO01BQ1JlLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDbkI7RUFDRixDQUFDOztFQUVEO0VBQ0EsTUFBTSxDQUFDTyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFsQyxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDLE1BQU0sQ0FBQ21DLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQXBDLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBRTdELE1BQU1xQyxRQUFRLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQzNCSCxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2hCRSxXQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2pCLElBQUk7TUFDRjtNQUNBO01BQ0E7TUFDQSxNQUFNRSxLQUFLLEdBQUcsTUFBTSxJQUFBQyxpQkFBWSxFQUFDLENBQUM7TUFDbEMsTUFBTVQsR0FBRyxHQUFHLE1BQU0sSUFBQUMsZUFBVSxFQUFxQixXQUFXLEVBQUU7UUFDNURTLElBQUksRUFBRSxJQUFBQyxZQUFPLEVBQUM7VUFBRUMsT0FBTyxFQUFFLFNBQVNKLEtBQUssQ0FBQ0ssRUFBRSxFQUFFO1VBQUVDLE9BQU8sRUFBRTtRQUFXLENBQUMsRUFBRTtVQUFFQyxJQUFJLEVBQUU7UUFBSyxDQUFDO01BQ3JGLENBQUMsQ0FBQztNQUNGVCxXQUFXLENBQUNOLEdBQUcsRUFBRWdCLEtBQUssR0FBRyxnQ0FBZ0MsR0FBRyxNQUFNLENBQUM7SUFDckUsQ0FBQyxDQUFDLE9BQU9wQyxDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUksSUFBSSxPQUFPO01BQ3REeUIsV0FBVyxDQUNUekIsSUFBSSxLQUFLLFdBQVcsR0FDaEIsV0FBVyxHQUNYQSxJQUFJLEtBQUssZUFBZSxHQUN0Qix3QkFBd0IsR0FDeEJBLElBQ1IsQ0FBQztJQUNILENBQUMsU0FBUztNQUNSdUIsVUFBVSxDQUFDLEtBQUssQ0FBQztJQUNuQjtFQUNGLENBQUM7RUFFRCxNQUFNYSxJQUFJLEdBQUcsTUFBQUEsQ0FBT0MsRUFBVSxFQUFFQyxJQUFhLEtBQUs7SUFDaEQzQixVQUFVLENBQUMwQixFQUFFLENBQUM7SUFDZCxJQUFJO01BQ0YsTUFBTSxJQUFBRSxpQkFBWSxFQUFDRixFQUFFLEVBQUVDLElBQUksQ0FBQztNQUM1QjdCLFNBQVMsQ0FBRWIsQ0FBQyxJQUFLLENBQUM7UUFBRXlDLEVBQUU7UUFBRXhDLE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUUsSUFBSTtVQUFFSixLQUFLLEVBQUU7UUFBWTtNQUFFLENBQUMsRUFBRSxHQUFHRSxDQUFDLENBQUMsQ0FBQztJQUM5RSxDQUFDLENBQUMsT0FBT0csQ0FBQyxFQUFFO01BQ1YsTUFBTUMsSUFBSSxHQUFJRCxDQUFDLEVBQXdCQyxJQUFJLElBQUksT0FBTztNQUN0RFMsU0FBUyxDQUFFYixDQUFDLElBQUssQ0FDZjtRQUFFeUMsRUFBRTtRQUFFeEMsTUFBTSxFQUFFO1VBQUVDLElBQUksRUFBRSxLQUFLO1VBQUVFLElBQUk7VUFBRUMsT0FBTyxFQUFHRixDQUFDLEVBQVlFLE9BQU8sSUFBSUMsTUFBTSxDQUFDSCxDQUFDO1FBQUU7TUFBRSxDQUFDLEVBQ2xGLEdBQUdILENBQUMsQ0FDTCxDQUFDO0lBQ0osQ0FBQyxTQUFTO01BQ1JlLFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDbEI7RUFDRixDQUFDO0VBRUQsb0JBQ0UsSUFBQWpDLFdBQUEsQ0FBQThELElBQUE7SUFBS0MsU0FBUyxFQUFDLElBQUk7SUFBQUMsUUFBQSxnQkFDakIsSUFBQWhFLFdBQUEsQ0FBQThELElBQUE7TUFBUUMsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxnQkFDdkIsSUFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQVcsQ0FBTSxDQUFDLGVBQzdDLElBQUFoRSxXQUFBLENBQUE4RCxJQUFBO1FBQU1DLFNBQVMsRUFBQyxRQUFRO1FBQUFDLFFBQUEsR0FBRXpELE9BQU8sQ0FBQzJELE1BQU0sRUFBQyx3QkFBc0I7TUFBQSxDQUFNLENBQUM7SUFBQSxDQUNoRSxDQUFDLGVBRVQsSUFBQWxFLFdBQUEsQ0FBQWlFLEdBQUE7TUFBSUYsU0FBUyxFQUFDLFVBQVU7TUFBQUMsUUFBQSxFQUNyQnpELE9BQU8sQ0FBQzRELEdBQUcsQ0FBRXhDLENBQUMsaUJBQ2IsSUFBQTNCLFdBQUEsQ0FBQThELElBQUE7UUFBaUJDLFNBQVMsRUFBQyxTQUFTO1FBQUFDLFFBQUEsZ0JBQ2xDLElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQU1GLFNBQVMsRUFBQyxTQUFTO1VBQUFDLFFBQUEsRUFBRXJDLENBQUMsQ0FBQ1o7UUFBSSxDQUFPLENBQUMsRUFDeENZLENBQUMsQ0FBQ3lDLE1BQU0saUJBQUksSUFBQXBFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBTUYsU0FBUyxFQUFDLFVBQVU7VUFBQUMsUUFBQSxFQUFDO1FBQU0sQ0FBTSxDQUFDLGVBQ3JELElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQ0VJLElBQUksRUFBQyxRQUFRO1VBQ2JOLFNBQVMsRUFBQyxRQUFRO1VBQ2xCTyxRQUFRLEVBQUUxRCxPQUFPLEtBQUtlLENBQUMsQ0FBQ1osSUFBSSxJQUFJWSxDQUFDLENBQUN5QyxNQUFPO1VBQ3pDRyxLQUFLLEVBQUU1QyxDQUFDLENBQUN5QyxNQUFNLEdBQUcsOEJBQThCLEdBQUcsWUFBWXpDLENBQUMsQ0FBQzZDLFVBQVUsRUFBRztVQUM5RUMsT0FBTyxFQUFFQSxDQUFBLEtBQU0zRCxHQUFHLENBQUNhLENBQUMsQ0FBQ1osSUFBSSxDQUFFO1VBQUFpRCxRQUFBLEVBRTFCcEQsT0FBTyxLQUFLZSxDQUFDLENBQUNaLElBQUksR0FBRyxHQUFHLEdBQUc7UUFBSyxDQUMzQixDQUFDO01BQUEsR0FYRlksQ0FBQyxDQUFDWixJQVlQLENBQ0w7SUFBQyxDQUNBLENBQUMsZUFFTCxJQUFBZixXQUFBLENBQUE4RCxJQUFBO01BQUtDLFNBQVMsRUFBQyxXQUFXO01BQUFDLFFBQUEsZ0JBQ3hCLElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1FBQUdGLFNBQVMsRUFBQyxhQUFhO1FBQUFDLFFBQUEsRUFBQztNQUF1QixDQUFHLENBQUMsZUFDdEQsSUFBQWhFLFdBQUEsQ0FBQThELElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxnQkFDMUIsSUFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBQUQsUUFBQSxFQUFPN0Q7UUFBVyxDQUFPLENBQUMsUUFBSSxFQUFDc0IsU0FBUyxDQUFDdEIsV0FBVyxDQUFDLEdBQUcsSUFBSSxHQUFHLFFBQVEsRUFBQyw0RUFFMUU7TUFBQSxDQUFHLENBQUMsZUFDSixJQUFBSCxXQUFBLENBQUE4RCxJQUFBO1FBQVFPLElBQUksRUFBQyxRQUFRO1FBQUNOLFNBQVMsRUFBQyxrQkFBa0I7UUFBQ1UsT0FBTyxFQUFFQSxDQUFBLEtBQU0zRCxHQUFHLENBQUNYLFdBQVcsQ0FBRTtRQUFBNkQsUUFBQSxHQUFDLE1BQzlFLEVBQUM3RCxXQUFXO01BQUEsQ0FDVixDQUFDO0lBQUEsQ0FDTixDQUFDLGVBRU4sSUFBQUgsV0FBQSxDQUFBOEQsSUFBQTtNQUFLQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLGdCQUN4QixJQUFBaEUsV0FBQSxDQUFBaUUsR0FBQTtRQUFHRixTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLEVBQUM7TUFBaUMsQ0FBRyxDQUFDLGVBQ2hFLElBQUFoRSxXQUFBLENBQUE4RCxJQUFBO1FBQUdDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsR0FBQyx1QkFDTixtQkFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQUcsQ0FBTSxDQUFDLGFBQVMsbUJBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQUFELFFBQUEsRUFBTzVEO1FBQVksQ0FBTyxDQUFDLHdIQUUzRCxtQkFBQUosV0FBQSxDQUFBaUUsR0FBQTtVQUFBRCxRQUFBLEVBQU07UUFBSSxDQUFNLENBQUMsS0FDakM7TUFBQSxDQUFHLENBQUMsZUFDSixJQUFBaEUsV0FBQSxDQUFBOEQsSUFBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLGdCQUN6QixJQUFBaEUsV0FBQSxDQUFBaUUsR0FBQTtVQUNFRixTQUFTLEVBQUMsY0FBYztVQUN4Qi9DLEtBQUssRUFBRVksSUFBSztVQUNaOEMsUUFBUSxFQUFHckQsQ0FBQyxJQUFLUSxPQUFPLENBQUNSLENBQUMsQ0FBQ3NELE1BQU0sQ0FBQzNELEtBQUssQ0FBRTtVQUN6QyxjQUFXO1FBQWdCLENBQzVCLENBQUMsZUFDRixJQUFBaEIsV0FBQSxDQUFBaUUsR0FBQTtVQUNFSSxJQUFJLEVBQUMsUUFBUTtVQUNiTixTQUFTLEVBQUMsUUFBUTtVQUNsQk8sUUFBUSxFQUFFdEMsT0FBTyxLQUFLNUIsWUFBYTtVQUNuQ3FFLE9BQU8sRUFBRUEsQ0FBQSxLQUFNZixJQUFJLENBQUN0RCxZQUFZLEVBQUU7WUFBRXdFLE1BQU0sRUFBRWhEO1VBQUssQ0FBQyxDQUFFO1VBQUFvQyxRQUFBLEVBQ3JEO1FBRUQsQ0FBUSxDQUFDO01BQUEsQ0FDTixDQUFDLGVBQ04sSUFBQWhFLFdBQUEsQ0FBQThELElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxHQUFDLG9EQUN1QixtQkFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBQUQsUUFBQSxFQUFPM0Q7UUFBYyxDQUFPLENBQUMsMkRBRWpGO01BQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQUwsV0FBQSxDQUFBOEQsSUFBQTtRQUNFTyxJQUFJLEVBQUMsUUFBUTtRQUNiTixTQUFTLEVBQUMsa0JBQWtCO1FBQzVCTyxRQUFRLEVBQUV0QyxPQUFPLEtBQUszQixjQUFlO1FBQ3JDb0UsT0FBTyxFQUFFQSxDQUFBLEtBQU1mLElBQUksQ0FBQ3JELGNBQWMsRUFBRTtVQUFFdUUsTUFBTSxFQUFFaEQ7UUFBSyxDQUFDLENBQUU7UUFBQW9DLFFBQUEsR0FDdkQsZ0JBQ2UsRUFBQzNELGNBQWM7TUFBQSxDQUN2QixDQUFDLEVBRVJ5QixNQUFNLENBQUNvQyxNQUFNLEdBQUcsQ0FBQyxpQkFDaEIsSUFBQWxFLFdBQUEsQ0FBQWlFLEdBQUE7UUFBSUYsU0FBUyxFQUFDLFFBQVE7UUFBQUMsUUFBQSxFQUNuQmxDLE1BQU0sQ0FBQ3FDLEdBQUcsQ0FBQyxDQUFDOUMsQ0FBQyxFQUFFd0QsQ0FBQyxrQkFDZixJQUFBN0UsV0FBQSxDQUFBOEQsSUFBQTtVQUFZQyxTQUFTLEVBQUUsY0FBYzFDLENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLEVBQUc7VUFBQTRDLFFBQUEsZ0JBQ25ELElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1lBQUFELFFBQUEsRUFBTzNDLENBQUMsQ0FBQ3NDO1VBQUUsQ0FBTyxDQUFDLFdBQUUsRUFBQyxHQUFHLEVBQ3hCdEMsQ0FBQyxDQUFDRixNQUFNLENBQUNDLElBQUksS0FBSyxJQUFJLGdCQUNyQixJQUFBcEIsV0FBQSxDQUFBaUUsR0FBQTtZQUFNRixTQUFTLEVBQUMsT0FBTztZQUFBQyxRQUFBLEVBQUM7VUFBUyxDQUFNLENBQUMsZ0JBRXhDLElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1lBQU1GLFNBQVMsRUFBQyxRQUFRO1lBQUFDLFFBQUEsRUFBRTNDLENBQUMsQ0FBQ0YsTUFBTSxDQUFDRztVQUFJLENBQU8sQ0FDL0M7UUFBQSxHQU5NdUQsQ0FPTCxDQUNMO01BQUMsQ0FDQSxDQUNMO0lBQUEsQ0FDRSxDQUFDLGVBRU4sSUFBQTdFLFdBQUEsQ0FBQThELElBQUE7TUFBS0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxnQkFDeEIsSUFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7UUFBR0YsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQUFDO01BQXdDLENBQUcsQ0FBQyxlQUN2RSxJQUFBaEUsV0FBQSxDQUFBOEQsSUFBQTtRQUFHQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEdBQUMsa0JBQ1gsbUJBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQUFELFFBQUEsRUFBTTtRQUFVLENBQU0sQ0FBQyw4TEFHekM7TUFBQSxDQUFHLENBQUMsZUFDSixJQUFBaEUsV0FBQSxDQUFBOEQsSUFBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLGdCQUN6QixJQUFBaEUsV0FBQSxDQUFBaUUsR0FBQTtVQUFNRixTQUFTLEVBQUMsZUFBZTtVQUFDZSxLQUFLLEVBQUU7WUFBRUMsVUFBVSxFQUFFN0M7VUFBTSxDQUFFO1VBQUMsY0FBWSxTQUFTQSxLQUFLO1FBQUcsQ0FBRSxDQUFDLGVBQzlGLElBQUFsQyxXQUFBLENBQUFpRSxHQUFBO1VBQU1GLFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsRUFBRTlCO1FBQUssQ0FBTyxDQUFDLGVBQzdDLElBQUFsQyxXQUFBLENBQUFpRSxHQUFBO1VBQVFJLElBQUksRUFBQyxRQUFRO1VBQUNOLFNBQVMsRUFBQyxRQUFRO1VBQUNPLFFBQVEsRUFBRWxDLE9BQVE7VUFBQ3FDLE9BQU8sRUFBRWpDLFNBQVU7VUFBQXdCLFFBQUEsRUFDNUU1QixPQUFPLEdBQUcsVUFBVSxHQUFHO1FBQWMsQ0FDaEMsQ0FBQztNQUFBLENBQ04sQ0FBQyxFQUNMRSxRQUFRLGlCQUNQLElBQUF0QyxXQUFBLENBQUE4RCxJQUFBO1FBQUdDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsR0FBQyxvQkFDZCxtQkFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBTUYsU0FBUyxFQUFDLFFBQVE7VUFBQUMsUUFBQSxFQUFFMUI7UUFBUSxDQUFPLENBQUM7TUFBQSxDQUN0RCxDQUNKO0lBQUEsQ0FDRSxDQUFDLGVBRU4sSUFBQXRDLFdBQUEsQ0FBQThELElBQUE7TUFBS0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxnQkFDeEIsSUFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7UUFBR0YsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQUFDO01BQTBDLENBQUcsQ0FBQyxlQUN6RSxJQUFBaEUsV0FBQSxDQUFBOEQsSUFBQTtRQUFHQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEdBQUMsV0FDbEIsbUJBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQUFELFFBQUEsRUFBTTtRQUFTLENBQU0sQ0FBQyxrS0FFQSxtQkFBQWhFLFdBQUEsQ0FBQWlFLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQUssQ0FBTSxDQUFDLHVEQUVuRDtNQUFBLENBQUcsQ0FBQyxlQUNKLElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1FBQVFJLElBQUksRUFBQyxRQUFRO1FBQUNOLFNBQVMsRUFBQyxRQUFRO1FBQUNPLFFBQVEsRUFBRTFCLE9BQVE7UUFBQzZCLE9BQU8sRUFBRXpCLFFBQVM7UUFBQWdCLFFBQUEsRUFDM0VwQixPQUFPLEdBQUcsVUFBVSxHQUFHO01BQTJCLENBQzdDLENBQUMsRUFDUkUsUUFBUSxpQkFDUCxJQUFBOUMsV0FBQSxDQUFBOEQsSUFBQTtRQUFHQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEdBQUMsbUJBQ2YsbUJBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQU1GLFNBQVMsRUFBQyxRQUFRO1VBQUFDLFFBQUEsRUFBRWxCO1FBQVEsQ0FBTyxDQUFDO01BQUEsQ0FDckQsQ0FDSjtJQUFBLENBQ0UsQ0FBQyxFQUVMckMsR0FBRyxDQUFDeUQsTUFBTSxHQUFHLENBQUMsaUJBQ2IsSUFBQWxFLFdBQUEsQ0FBQWlFLEdBQUE7TUFBSUYsU0FBUyxFQUFDLFFBQVE7TUFBQUMsUUFBQSxFQUNuQnZELEdBQUcsQ0FBQzBELEdBQUcsQ0FBQyxDQUFDOUMsQ0FBQyxFQUFFd0QsQ0FBQyxrQkFDWixJQUFBN0UsV0FBQSxDQUFBOEQsSUFBQTtRQUFZQyxTQUFTLEVBQUUsY0FBYzFDLENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLEVBQUc7UUFBQTRDLFFBQUEsZ0JBQ25ELElBQUFoRSxXQUFBLENBQUFpRSxHQUFBO1VBQUFELFFBQUEsRUFBTzNDLENBQUMsQ0FBQ047UUFBSSxDQUFPLENBQUMsV0FBRSxFQUFDLEdBQUcsRUFDMUJNLENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLEtBQUssSUFBSSxnQkFDckIsSUFBQXBCLFdBQUEsQ0FBQWlFLEdBQUE7VUFBTUYsU0FBUyxFQUFDLE9BQU87VUFBQUMsUUFBQSxFQUFDO1FBQUUsQ0FBTSxDQUFDLGdCQUVqQyxJQUFBaEUsV0FBQSxDQUFBaUUsR0FBQTtVQUFNRixTQUFTLEVBQUMsUUFBUTtVQUFBQyxRQUFBLEVBQUUzQyxDQUFDLENBQUNGLE1BQU0sQ0FBQ0c7UUFBSSxDQUFPLENBQy9DO01BQUEsR0FOTXVELENBT0wsQ0FDTDtJQUFDLENBQ0EsQ0FDTDtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUM1RSxFQUFBLENBN091QkssU0FBUztFQUFBLFFBQ2ZFLGVBQVU7QUFBQTtBQUFBd0UsRUFBQSxHQURKMUUsU0FBUztBQUFBLElBQUEwRSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}