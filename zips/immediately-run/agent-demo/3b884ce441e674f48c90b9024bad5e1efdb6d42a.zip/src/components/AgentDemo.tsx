// The embedded-agent demo (§5.5 / §5.9). Shows the app's grant-filtered method
// catalog AS the agent's tool list, lets you "run" a tool through `invoke()`, and
// proves confinement (G12/T23): a method NOT in the catalog — named directly —
// still returns `forbidden` at the host gate. A real LLM agent would be handed
// `useCatalog()` verbatim as its tools; the principle is identical.
import { useState } from "react";
import {
  useCatalog,
  invoke,
  postToRegion,
  invokeTask,
  capFile,
  openFs,
  openSettings,
  type ApiMethod,
} from "@immediately-run/sdk";
import "./AgentDemo.css";

// A method we deliberately do NOT hold (this app's grant lacks spaces:admin), to
// show the gate refusing an off-catalog call — the agent can't escape its grant.
const OFF_CATALOG = "spaces:share";

// R3-612 — the delegated file, named once: the create (capFile relPath) and the
// remove (openFs().rm) must never drift apart on a rename.
const DEMO_FILE = "demo.txt";

// §5.6 L2 inter-app messaging (T19). This app's binding declares an ipc edge to
// panel.files ONLY (`ipc.to: ["panel.files"]`). Posting there is delivered (the
// file explorer declared it `accepts` us); posting anywhere else is refused at the
// host — the same two-sided-consent confinement the catalog gate shows above.
const FILES_REGION = "panel.files";
const NO_EDGE_REGION = "panel.spaces";

type Result = { kind: "ok"; value: unknown } | { kind: "err"; code: string; message: string };

export default function AgentDemo() {
  const catalog = useCatalog();
  const [log, setLog] = useState<Array<{ name: string; result: Result }>>([]);
  const [running, setRunning] = useState<string | null>(null);

  const run = async (name: string) => {
    setRunning(name);
    try {
      const value = await invoke(name, {});
      setLog((l) => [{ name, result: { kind: "ok", value } }, ...l]);
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      setLog((l) => [
        { name, result: { kind: "err", code, message: (e as Error)?.message ?? String(e) } },
        ...l,
      ]);
    } finally {
      setRunning(null);
    }
  };

  const inCatalog = (name: string) => catalog.some((m: ApiMethod) => m.name === name);

  // --- inter-app messaging (§5.6) ------------------------------------------
  const [path, setPath] = useState("/README.md");
  const [ipcLog, setIpcLog] = useState<Array<{ to: string; result: Result }>>([]);
  const [posting, setPosting] = useState<string | null>(null);

  // --- task invocation (§5.7): invoke another app, get a typed result back ------
  const [color, setColor] = useState("#3b82f6");
  const [picking, setPicking] = useState(false);
  const [pickNote, setPickNote] = useState<string | null>(null);

  const pickColor = async () => {
    setPicking(true);
    setPickNote(null);
    try {
      const res = await invokeTask<{ color: string }>("pick-color", { initial: color });
      if (res?.color) setColor(res.color);
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      // `cancelled` is a normal outcome (user dismissed the overlay), not an error.
      // `forbidden` is expected when this demo runs OUTSIDE the agents activity:
      // `task:invoke` is elevated and conferred by the panel.agent/stage bindings,
      // and no consent path exists yet for a plain capability on a URL-loaded app
      // (boot consent covers mounts+net:fetch; M1 pre-auth validates but does not
      // mint plain caps — R3-233). Say so instead of leaving a bare code.
      setPickNote(
        code === "cancelled"
          ? "cancelled"
          : code === "forbidden"
            ? "forbidden — task:invoke is conferred by the agents-activity bindings; the standalone copy of this demo cannot acquire it (no consent path for plain capabilities yet)"
            : code,
      );
    } finally {
      setPicking(false);
    }
  };

  // --- M2 attenuated delegation (§8.15): hand a callee a CAPABILITY, narrowed ----
  // The R3-43 drill-2 fixture. `probe` is provided by an app that declares a REQUIRED
  // `net:fetch` host; the host mints it the INTERSECTION of that and what this app
  // holds, never the union. The callee then spends it and reports what it could and
  // could not reach — so a grant that was minted but not honoured, or honoured but not
  // attenuated, is distinguishable from a correct one.
  const [probing, setProbing] = useState(false);
  const [probeNote, setProbeNote] = useState<string | null>(null);

  const runProbe = async () => {
    setProbing(true);
    setProbeNote(null);
    try {
      const res = await invokeTask<{
        probed: boolean;
        declaredHostOk: boolean;
        declaredDetail: string;
        undeclaredHostOk: boolean;
        undeclaredDetail: string;
      }>("probe", { label: "R3-43 drill 2" });
      // Report the PASS condition explicitly rather than dumping the payload: the
      // delegated host must be reachable AND the undeclared one must not be. Naming
      // which half failed is the difference between a drill and a shrug.
      const ok = res?.declaredHostOk && !res?.undeclaredHostOk;
      setProbeNote(
        ok
          ? `delegated + attenuated ✓ (declared ${res.declaredDetail}, undeclared ${res.undeclaredDetail})`
          : `UNEXPECTED — declared ${res?.declaredHostOk ? "reachable" : "blocked"} (${res?.declaredDetail}), ` +
            `undeclared ${res?.undeclaredHostOk ? "REACHABLE — not attenuated" : "blocked"} (${res?.undeclaredDetail})`,
      );
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      // `consent-required` is the NEGATIVE leg of the drill, not a failure: it is what
      // must happen when this app holds no net:fetch covering the callee's host.
      setProbeNote(
        code === "cancelled"
          ? "cancelled"
          : code === "consent-required"
            ? "consent-required — the negative leg: this app holds no net:fetch covering the callee's declared host, so nothing was minted and no overlay opened"
            : code === "forbidden"
              ? "forbidden — task:invoke is conferred by the agents-activity bindings"
              : code,
      );
    } finally {
      setProbing(false);
    }
  };

  // --- file delegation (§5.7/§8.7): hand a callee a file from MY OWN space -------
  const [editing, setEditing] = useState(false);
  const [editNote, setEditNote] = useState<string | null>(null);

  const editFile = async () => {
    setEditing(true);
    setEditNote(null);
    try {
      // Open this app's own per-user settings (a private ~/.config-style mount),
      // then delegate ONE file in it to the bound edit-file app — the host mints an
      // attenuated chroot; this app never sees the editor's code, only the typed
      // { saved } result.
      const settings = await openSettings();
      const res = await invokeTask<{ saved: boolean }>("edit-file", {
        file: capFile({ mountId: settings.id ?? settings.path, relPath: DEMO_FILE }, { mode: "rw" }),
      });
      setEditNote(res?.saved ? `saved ${DEMO_FILE} to your settings ✓` : "done");
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      setEditNote(
        code === "cancelled"
          ? "cancelled"
          : code === "auth-required"
            ? "sign in to use a space"
            : code === "forbidden"
              ? "forbidden — task:invoke is conferred by the agents-activity bindings; the standalone copy of this demo cannot acquire it (no consent path for plain capabilities yet)"
              : code,
      );
    } finally {
      setEditing(false);
    }
  };

  // R3-612 / R-IX-5 — where a thing can be created it can be removed: this control
  // created demo.txt in the settings mount, so the SAME mount takes it back. The
  // typed `FsError` codes surface verbatim — a read-only mount's refusal is the
  // honest answer, never a fake success.
  const [removing, setRemoving] = useState(false);

  const removeDemoFile = async () => {
    setRemoving(true);
    setEditNote(null);
    try {
      const settings = await openSettings();
      await openFs(settings).rm(DEMO_FILE);
      setEditNote(`removed ${DEMO_FILE} from your settings`);
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      setEditNote(
        code === "cancelled"
          ? "cancelled"
          : code === "auth-required"
            ? "sign in to use a space"
            : code === "forbidden"
              ? "forbidden — this app cannot remove from the settings mount"
              : code,
      );
    } finally {
      setRemoving(false);
    }
  };

  const post = async (to: string, data: unknown) => {
    setPosting(to);
    try {
      await postToRegion(to, data);
      setIpcLog((l) => [{ to, result: { kind: "ok", value: "delivered" } }, ...l]);
    } catch (e) {
      const code = (e as { code?: string })?.code ?? "error";
      setIpcLog((l) => [
        { to, result: { kind: "err", code, message: (e as Error)?.message ?? String(e) } },
        ...l,
      ]);
    } finally {
      setPosting(null);
    }
  };

  return (
    <div className="ad">
      <header className="ad-hd">
        <span className="ad-title">Agent tools</span>
        <span className="ad-sub">{catalog.length} in this app's catalog</span>
      </header>

      <ul className="ad-tools">
        {catalog.map((m) => (
          <li key={m.name} className="ad-tool">
            <code className="ad-name">{m.name}</code>
            {m.stream && <span className="ad-badge">stream</span>}
            <button
              type="button"
              className="ad-run"
              disabled={running === m.name || m.stream}
              title={m.stream ? "streaming — use invokeStream" : `requires ${m.capability}`}
              onClick={() => run(m.name)}
            >
              {running === m.name ? "Running…" : "Run"}
            </button>
          </li>
        ))}
      </ul>

      <div className="ad-escape">
        <p className="ad-escape-h">Confinement check (G12)</p>
        <p className="ad-escape-sub">
          <code>{OFF_CATALOG}</code> is {inCatalog(OFF_CATALOG) ? "in" : "NOT in"} this app's
          catalog. Calling it anyway should be refused by the host gate:
        </p>
        <button
          type="button"
          className="ad-run ad-danger"
          disabled={running === OFF_CATALOG}
          onClick={() => run(OFF_CATALOG)}
        >
          {running === OFF_CATALOG ? "Trying…" : `Try ${OFF_CATALOG}`}
        </button>
      </div>

      <div className="ad-escape">
        <p className="ad-escape-h">Message another panel (§5.6, T19)</p>
        <p className="ad-escape-sub">
          This app declares an <code>ipc</code> edge to <code>{FILES_REGION}</code> only.
          Ask the file explorer to reveal a path — it’ll show the message with a host-attached
          (unspoofable) <code>from</code>:
        </p>
        <div className="ad-ipc-row">
          <input
            className="ad-ipc-input"
            value={path}
            onChange={(e) => setPath(e.target.value)}
            aria-label="Path to reveal"
          />
          <button
            type="button"
            className="ad-run"
            disabled={posting === FILES_REGION}
            onClick={() => post(FILES_REGION, { reveal: path })}
          >
            {posting === FILES_REGION ? "Sending…" : "Reveal in Files"}
          </button>
        </div>
        <p className="ad-escape-sub">
          Posting to a region this app declared no edge to (<code>{NO_EDGE_REGION}</code>) is
          refused by the host — neither side opened it:
        </p>
        <button
          type="button"
          className="ad-run ad-danger"
          disabled={posting === NO_EDGE_REGION}
          onClick={() => post(NO_EDGE_REGION, { reveal: path })}
        >
          {posting === NO_EDGE_REGION ? "Sending…" : `Try messaging ${NO_EDGE_REGION}`}
        </button>

        {ipcLog.length > 0 && (
          <ul className="ad-log">
            {ipcLog.map((e, i) => (
              <li key={i} className={`ad-logline ${e.result.kind}`}>
                <code>{e.to}</code> →{" "}
                {e.result.kind === "ok" ? (
                  <span className="ad-ok">delivered</span>
                ) : (
                  <span className="ad-err">{e.result.code}</span>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="ad-escape">
        <p className="ad-escape-h">Invoke another app (§5.7, task contract)</p>
        <p className="ad-escape-sub">
          A tool can call <code>pick-color</code> and get a typed color back. The host
          loads the user's bound picker in an overlay, the picker returns a value, and
          this app never sees the picker's code or grants — just the result:
        </p>
        <div className="ad-ipc-row">
          <span className="ad-color-chip" style={{ background: color }} aria-label={`color ${color}`} />
          <code className="ad-color-val">{color}</code>
          <button type="button" className="ad-run" disabled={picking} onClick={pickColor}>
            {picking ? "Picking…" : "Pick a color"}
          </button>
        </div>
        {pickNote && (
          <p className="ad-escape-sub">
            invokeTask → <span className="ad-err">{pickNote}</span>
          </p>
        )}
      </div>

      <div className="ad-escape">
        <p className="ad-escape-h">Delegate a capability, attenuated (§8.15 / M2)</p>
        <p className="ad-escape-sub">
          Invoke an app that <em>requires</em> a <code>net:fetch</code> host. The host
          mints it the intersection with what this app holds — never the union — and the
          callee spends it, reporting what it could and could not reach. It also probes a
          host it never declared: <em>blocked</em> there is the proof the grant was
          attenuated rather than inherited.
        </p>
        <button type="button" className="ad-run" disabled={probing} onClick={runProbe}>
          {probing ? "Probing…" : "Run the delegation probe"}
        </button>
        {probeNote && (
          <p className="ad-escape-sub">
            invokeTask → <span className="ad-err">{probeNote}</span>
          </p>
        )}
      </div>

      <div className="ad-escape">
        <p className="ad-escape-h">Delegate a file to another app (§5.7/§8.7)</p>
        <p className="ad-escape-sub">
          Hand the <code>edit-file</code> app ONE file from your space. The host mints
          an attenuated, task-scoped chroot — the editor can name nothing else, and a
          read-only delegation is a real <code>EROFS</code> wall. Your grant narrows;
          it never amplifies (G7):
        </p>
        <div className="ad-escape-actions">
          <button type="button" className="ad-run" disabled={editing || removing} onClick={editFile}>
            {editing ? "Editing…" : `Edit ${DEMO_FILE} in my space`}
          </button>
          <button type="button" className="ad-run" disabled={editing || removing} onClick={() => void removeDemoFile()}>
            {removing ? "Removing…" : `Remove ${DEMO_FILE}`}
          </button>
        </div>
        {editNote && (
          <p className="ad-escape-sub">
            {DEMO_FILE} → <span className="ad-err">{editNote}</span>
          </p>
        )}
      </div>

      {log.length > 0 && (
        <ul className="ad-log">
          {log.map((e, i) => (
            <li key={i} className={`ad-logline ${e.result.kind}`}>
              <code>{e.name}</code> →{" "}
              {e.result.kind === "ok" ? (
                <span className="ad-ok">ok</span>
              ) : (
                <span className="ad-err">{e.result.code}</span>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
