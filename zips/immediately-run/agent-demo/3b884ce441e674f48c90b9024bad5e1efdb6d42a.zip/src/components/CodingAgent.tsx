// A real in-browser coding-agent loop (LLM_AND_AGENTS_SPEC §3.3). It hands the
// model two tool sources merged into one list: the app's grant-filtered §5.5
// catalog (driven through the host's gated `invoke()`) and mount-scoped
// filesystem tools (read/write/list/stat/glob/grep/delete over the app's working
// tree). Confinement is automatic (G12/T24): the model can only drive methods in
// this app's catalog or files inside its mount chroot; anything else returns
// `forbidden`/`not found`.
//
// Inference goes through the platform `llm.chat` service (SDK `chat()`): the app
// names no vendor and no model and holds no key — the host injects the user's key and
// resolves the user's preferred provider/model (AGENT_AUTHORING_ARCHITECTURE §3; H2
// favours chat() over net:fetch+secrets). Needs only the `llm:chat` capability.
import { useEffect, useMemo, useRef, useState } from "react";
import { useCatalog, useMounts, getAppMountPath, describeChat } from "@immediately-run/sdk";
import { catalogToolset, mergeToolsets } from "../lib/toolset";
import { createFsToolset, resolveWorkingTreeMount } from "../lib/fsTools";
import { createProjectToolset } from "../lib/projectTools";
import { createDiagnosticsToolset } from "../lib/diagnosticsTools";
import { createGitToolset } from "../lib/gitTools";
import { buildSystemPrompt, todayIso } from "../lib/agentPrompt";
import { withSkills } from "../lib/skills";
import { createChatModelClient } from "../lib/chatModelClient";
import { runAgent, type LoopBoundary } from "../lib/agentLoop";
import { openConversationStore, deriveTitle, type ConversationStore } from "../lib/conversationStore";
import type { Conversation } from "../lib/conversationModel";
import { messagesToLog, type LogEntry } from "../lib/transcript";
import TranscriptRows from "./TranscriptRows";
import { leaseFailure, leaseFailureText, leaseHeldText } from "../lib/storeError";
import { useLeaseRefresh } from "../hooks/useLeaseRefresh";
import "./CodingAgent.css";

/** R-ARD-10: the row for a run that cannot be persisted at all (no store — no
 *  host / signed out / settings mount dead). One copy: the mount effect and the
 *  run-start re-check both use it, so the copy cannot drift. */
const noStoreRow = (e: unknown): LogEntry => ({
  kind: "error",
  text: `This run can't be saved (${(e as Error)?.message ?? String(e)}) — closing the tab loses it.`,
});

export default function CodingAgent() {
  const catalog = useCatalog();
  const mounts = useMounts();
  const [prompt, setPrompt] = useState("");
  const [log, setLog] = useState<LogEntry[]>([]);
  const [streaming, setStreaming] = useState("");
  // R3-335 — the in-flight reasoning for the current block (cleared when the whole block
  // arrives and becomes a transcript row).
  const [thinking, setThinking] = useState("");
  const [running, setRunning] = useState(false);
  /** R3-561: which conversation this run holds the lease on, for the refresh
   *  interval below (a ref, so arming it does not wait for a render). */
  const runningIdRef = useRef<string | null>(null);

  // Persistence (Phase 01): keep this run in a durable conversation so it survives
  // reload. Best-effort — `openSettings()` is inert in local dev / signed out, so a
  // failure degrades to today's ephemeral behavior rather than crashing.
  const storeRef = useRef<ConversationStore | null>(null);
  const convRef = useRef<Conversation | null>(null);
  // R-ARD-10: why the store is absent, when it is — the run-start re-check needs
  // it after `setLog([])` wipes the mount-time row.
  const storeOpenErrorRef = useRef<unknown>(null);
  // R3-224 (§3.3): the stop button's abort controller for the in-flight run.
  const abortRef = useRef<AbortController | null>(null);
  useEffect(() => {
    let live = true;
    void (async () => {
      try {
        const store = await openConversationStore();
        if (!live) return;
        storeRef.current = store;
        const [newest] = await store.list();
        const conv = newest ? await store.load(newest.id) : await store.create();
        if (!live || !conv) return;
        convRef.current = conv;
        if (conv.messages.length) setLog(messagesToLog(conv.messages));
      } catch (e) {
        // R-ARD-10: no store at all (no host / signed out / settings mount dead)
        // means a fully ephemeral run — allowed, but never a silent downgrade.
        if (live) {
          storeOpenErrorRef.current = e;
          setLog((l) => [...l, noStoreRow(e)]);
        }
      }
    })();
    return () => {
      live = false;
    };
  }, []);

  // Merge the platform catalog with filesystem + project tools chrooted to the working
  // tree. When a stage app's tree is conferred (`type:'worktree'`, AA-23) author THAT;
  // otherwise (standalone agent) fall back to this app's own repo. Re-derived when the
  // conferred mount or its writability changes.
  // R3-339 — does the model the user configured accept images? The tool is told, so a
  // `read_file` on a PNG can SAY the model cannot look at it instead of sending
  // something that errors upstream. Re-read when the provider changes.
  const vision = useMemo(() => describeChat()?.features.vision === true, []);

  // `withSkills` runs LAST (R3-331): which host skills are offered depends on which
  // tools this run actually got, so selection needs the merged list.
  const { toolset, skills } = useMemo(() => {
    const { root, readOnly } = resolveWorkingTreeMount(mounts, getAppMountPath());
    const fsTools = createFsToolset({ root, readOnly, vision });
    const projectTools = createProjectToolset({ root, readOnly });
    const diagnosticsTools = createDiagnosticsToolset();
    // R3-332: git-READ over the same working tree. Empty (and therefore invisible to
    // the model) unless the app holds `vcs:read`.
    const gitTools = createGitToolset({ catalog });
    // `withSkills` stays LAST (R3-331): which host skills are offered depends on the
    // final merged tool list, so it has to see the git tools too.
    return withSkills(mergeToolsets(catalogToolset(catalog), fsTools, projectTools, diagnosticsTools, gitTools));
  }, [catalog, mounts, vision]);

  // The workspace root the fs tools are chrooted to — env grounding for the prompt.
  const workspaceRoot = useMemo(
    () => resolveWorkingTreeMount(mounts, getAppMountPath()).root,
    [mounts],
  );

  const append = (e: LogEntry) => setLog((l) => [...l, e]);

  // R3-561 / R-ARD-18: this surface runs and appends exactly as ConversationStage
  // does, so it refreshes the lease on the same interval. Round 1 fixed the stage
  // only; the argument — a model turn outlasts the TTL and boundary appends cannot
  // cover it — was never specific to that component, and this is the surface where
  // a second frame is most reachable, since it adopts the newest conversation.
  useLeaseRefresh(storeRef, runningIdRef, running);

  const run = async () => {
    if (!prompt.trim() || running) return;
    setRunning(true);
    setLog([]);
    // R-ARD-10: the mount-time no-store row was just wiped by setLog([]) above —
    // an ephemeral run must SAY it is ephemeral on every run, not only at mount.
    if (!storeRef.current && storeOpenErrorRef.current !== null) {
      append(noStoreRow(storeOpenErrorRef.current));
    }
    setStreaming("");
    setThinking("");
    append({ kind: "user", text: prompt });
    const controller = new AbortController();
    abortRef.current = controller;
    // R3-559: the conversation must exist BEFORE the run starts — the checkpoint
    // journal appends into it from the first boundary (B0), so a fresh run creates
    // its record up-front rather than at persist time.
    const store = storeRef.current;
    if (store && !convRef.current) {
      try {
        convRef.current = await store.create();
      } catch (e) {
        // R-ARD-10: an un-checkpointable run is allowed to start, and SAYS SO —
        // never a silent downgrade to ephemeral. The run proceeds exactly as the
        // pre-journal agent did; the user is told what that costs.
        append(noStoreRow(e));
      }
    }
    // Same rule for the journal tier: journalless is a degradation the user can
    // see (the conversation still saves at run end; the checkpoint floor is gone).
    if (store && convRef.current && !store.hasJournal()) {
      append({
        kind: "error",
        text: "Checkpoints are off (no device-local store) — closing this tab loses the in-flight turn; the conversation itself still saves when the run ends.",
      });
    }
    // R3-561 / R-ARD-18: take the advisory run lease. This demo is the THIRD opener
    // of the same store — the panel and the stage are the other two — and it adopts
    // the NEWEST conversation at mount, so "the agents activity and this tab, same
    // conversation" is reachable rather than theoretical. Without this the first
    // append would throw and print internal copy about a lease the user never saw.
    //
    // No takeover BUTTON here, deliberately: this surface's whole UI is a prompt
    // and a Run/Stop control, and inventing an affordance row for a demo would be
    // the bespoke UI the run-mode rule warns against. R-ARD-18a still forbids a
    // DEAD END, so the copy names what genuinely frees the lease — its TTL — and
    // not an action this component does not have. (An earlier version said "start
    // a new conversation here", which is an instruction the user cannot follow:
    // there is no such control, and the mount effect re-adopts the newest
    // conversation, so a reload lands on the same refusal.)
    //
    // The REFRESH, unlike the button, is not optional here — this surface runs and
    // appends exactly as the stage does, so it gets the same `useLeaseRefresh`.
    if (store && convRef.current) {
      try {
        if ((await store.acquireRun(convRef.current.id)) === "held") {
          append({ kind: "error", text: leaseHeldText(false) });
          setRunning(false);
          abortRef.current = null;
          return;
        }
      } catch (e) {
        // A lease we cannot read is not a lease we lost. Say the store is degraded
        // and run, rather than refusing on an unknown.
        append(noStoreRow(e));
      }
    }
    runningIdRef.current = convRef.current?.id ?? null;
    const journalConv = store?.hasJournal() ? convRef.current : null;
    try {
      const transcript = await runAgent({
        client: createChatModelClient(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: buildSystemPrompt({ tools: toolset.tools, skills, workspaceRoot, today: todayIso() }),
        prompt,
        // R3-224 (§3.3): the stop button aborts the loop AND the in-flight LLM turn.
        signal: controller.signal,
        // Token accounting + auto-compaction let the loop run past ~12 turns
        // (R3-220): the resolved provider's window drives when to compact.
        contextWindow: describeChat()?.features.maxContextTokens,
        events: {
          // R3-559: append every boundary to the conversation's journal (B2
          // intent is durable before its executor runs — R-ARD-10a). The loop
          // awaits this; a failed append unwinds the run at that boundary.
          ...(journalConv
            ? {
                onBoundary: async (b: LoopBoundary) => {
                  await store!.append(journalConv.id, b);
                },
              }
            : {}),
          onAssistantDelta: (text) => setStreaming((s) => s + text),
          // R3-335 — the live thinking surface. Now that compaction lets a task run past
          // a dozen turns, the silent stretches are longer, and "is it stuck or
          // thinking?" had no answer on screen.
          onReasoningDelta: (text) => setThinking((t) => t + text),
          onReasoning: (block) => {
            setThinking("");
            append(
              block.redactedData !== undefined
                ? { kind: "reasoning", text: "", redacted: true }
                : { kind: "reasoning", text: block.text },
            );
          },
          onAssistantText: (text) => {
            if (text.trim()) append({ kind: "text", text });
            setStreaming("");
          },
          onToolUse: (name, input) => append({ kind: "tool", name, input }),
          onToolResult: (name, r) =>
            append({ kind: "result", name, content: r.content, isError: r.isError }),
          onNudge: () => append({ kind: "nudge" }),
          onCompact: ({ summarizedCount }) => {
            append({ kind: "compaction", summary: `${summarizedCount} earlier messages summarized` });
            // R3-559 (R-ARD-9): fold at the compaction boundary, best-effort — the
            // run-end fold is the authoritative write (see ConversationStage).
            if (journalConv) {
              void store!.fold(journalConv.id).catch((e) => {
                console.warn("mid-run fold at compaction failed (run-end fold still will)", e);
              });
            }
          },
        },
      });
      await persist(transcript);
    } catch (e) {
      // R3-561: the two lease codes are UX states, not codes to print (§9). Same
      // mapping as the stage's two catches, `canTakeOver: false` — this surface
      // has no affordance row, so the copy names the TTL, which actually frees the
      // lease, rather than a button it does not ship.
      const lease = leaseFailure(e);
      append(
        lease
          ? { kind: "error", text: leaseFailureText(lease, false) }
          : { kind: "error", text: (e as Error)?.message ?? String(e) },
      );
    } finally {
      setStreaming("");
      setThinking("");
      setRunning(false);
      abortRef.current = null;
      // R3-561: hand the lease back — the id the RUN held, read before it is
      // cleared, not whatever is on screen. Fired, not awaited; see
      // `releaseHeldLease` in ConversationStage for the argument.
      {
        const store = storeRef.current;
        const id = runningIdRef.current;
        if (store && id) void store.releaseRun(id).catch(() => {});
      }
      runningIdRef.current = null;
    }
  };

  // R3-224 (§3.3): abort the in-flight run — the loop AND the upstream LLM request.
  const stop = () => abortRef.current?.abort();

  // Save the run into its conversation — a FOLD when the journal tier is wired
  // (R3-559: stamps the fold watermark + carried run-state, reclaims the
  // superseded entries), a plain save otherwise. Best-effort; no-op without a store.
  const persist = async (messages: Conversation["messages"]) => {
    const store = storeRef.current;
    if (!store) return;
    try {
      const conv = convRef.current ?? (await store.create());
      const title = conv.title === "New conversation" ? deriveTitle(messages) : conv.title;
      convRef.current = store.hasJournal()
        ? await store.fold(conv.id, { messages, title })
        : await store.save({ ...conv, title, messages });
    } catch {
      /* persistence is best-effort — never break the run on a write failure */
    }
  };

  // R3-612 / R-IX-5 — every run lands in a durable conversation, so this surface
  // must offer a fresh start and name where the runs go. The Conversations list
  // is where they accumulate and where one can be removed; this surface names
  // that place rather than growing its own browser.
  const newConversation = async () => {
    const store = storeRef.current;
    if (!store || running) return;
    try {
      const conv = await store.create();
      convRef.current = conv;
      setLog([]);
      setStreaming("");
      setThinking("");
    } catch (e) {
      setLog((l) => [
        ...l,
        { kind: "error", text: `Could not start a new conversation (${(e as Error)?.message ?? String(e)})` },
      ]);
    }
  };

  return (
    <div className="ca">
      <header className="ca-hd">
        <span className="ca-title">Coding agent</span>
        <span className="ca-sub">{toolset.tools.length} tools (catalog + files + project + diagnostics)</span>
        <button type="button" className="ca-new" disabled={running} onClick={() => void newConversation()}>
          New conversation
        </button>
      </header>

      <div className="ca-prompt-row">
        <input
          className="ca-prompt"
          placeholder="Ask the agent to read, search, or edit your app…"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void run();
          }}
          aria-label="Prompt"
        />
        <button
          type="button"
          className="ca-run"
          // While running, this is a live Stop control (R3-224) — abort the in-flight turn.
          onClick={() => (running ? stop() : void run())}
        >
          {running ? "Stop" : "Run"}
        </button>
      </div>

      {/* aria-live matches the conversation stage's transcript (ConversationStage),
           so screen readers hear turns land here too. */}
      <ul className="ca-log" aria-live="polite">
        {/* R3-612 / R-IX-5 — the empty state names where runs are kept: this
            surface persists silently otherwise, and the list (which removes)
            is the only place that shows the accumulation. */}
        {!log.length && !thinking && !streaming && (
          <li className="ca-line ca-empty">Runs are saved to your Conversations list.</li>
        )}
        {/* Folded tool calls + markdown replies (R3-473/R3-474) — shared with the
            conversation stage so both transcripts read identically. */}
        <TranscriptRows log={log} />
        {thinking && (
          <li className="ca-line ca-live">
            {/* Open while it streams — the point is to SHOW that work is happening —
                then collapsed once it becomes a transcript row. */}
            <details className="ca-reasoning" open>
              <summary>thinking…</summary>
              <span className="ca-reasoning-body">{thinking}</span>
            </details>
          </li>
        )}
        {streaming && (
          <li className="ca-line ca-text ca-live">
            <span className="ca-text">{streaming}</span>
          </li>
        )}
      </ul>
    </div>
  );
}
