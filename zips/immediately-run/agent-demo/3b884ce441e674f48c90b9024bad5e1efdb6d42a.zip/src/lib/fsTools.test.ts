import { describe, it, expect } from 'vitest';
import { createFsToolset, resolveWorkingTreeMount, findConferredWorktree, type FsPortLike, type FsDirent, type FsStat } from './fsTools';

// AA-23: the workbench agent must author the STAGE app's conferred working tree
// (`type:'worktree'`), NOT its own repo — targeting `getAppMountPath()` was the bug
// that made it read `not found` for every grove path.
describe('resolveWorkingTreeMount (standalone, self-fallback)', () => {
  const OWN = '/mnt/own-agent-repo';

  it('targets the conferred stage-app worktree by identity (rw), not the agent\'s own repo', () => {
    const mounts = [
      { path: OWN, type: 'repo', mode: 'rw' as const },
      { path: '/mnt/stage-grove', type: 'worktree', mode: 'rw' as const },
    ];
    expect(resolveWorkingTreeMount(mounts, OWN)).toEqual({ root: '/mnt/stage-grove', readOnly: false });
  });

  it('honors a read-only conferred worktree', () => {
    const mounts = [{ path: '/mnt/stage-grove', type: 'worktree', mode: 'ro' as const }];
    expect(resolveWorkingTreeMount(mounts, OWN)).toEqual({ root: '/mnt/stage-grove', readOnly: true });
  });

  it('falls back to the agent\'s own repo when no worktree is conferred (standalone agent)', () => {
    const mounts = [{ path: OWN, type: 'repo', mode: 'rw' as const }];
    expect(resolveWorkingTreeMount(mounts, OWN)).toEqual({ root: OWN, readOnly: false });
  });

  it('fallback reports read-only when the own repo is ro', () => {
    const mounts = [{ path: OWN, type: 'repo', mode: 'ro' as const }];
    expect(resolveWorkingTreeMount(mounts, OWN)).toEqual({ root: OWN, readOnly: true });
  });

  it('fallback to appMountPath even when the own mount is absent from the list', () => {
    expect(resolveWorkingTreeMount([], OWN)).toEqual({ root: OWN, readOnly: false });
  });
});

// The stage agent uses findConferredWorktree and REFUSES (null) rather than ever
// authoring its own repo — the fix for the "silently authors itself" failure.
describe('findConferredWorktree (stage agent — never self)', () => {
  const OWN = '/mnt/own-agent-repo';

  it('returns the conferred stage tree (a worktree that is NOT the agent\'s own)', () => {
    const mounts = [
      { path: OWN, type: 'worktree', mode: 'rw' as const }, // the agent's OWN dual-mount
      { path: '/mnt/stage-grove', type: 'worktree', mode: 'rw' as const },
    ];
    // Even though BOTH are worktrees, it must pick the one that isn't the agent's own.
    expect(findConferredWorktree(mounts, OWN)).toEqual({ root: '/mnt/stage-grove', readOnly: false });
  });

  it('returns null when the ONLY worktree is the agent\'s own (collision → no stage tree)', () => {
    // The dev-override / dual-mount case that made the workbench author itself.
    const mounts = [{ path: OWN, type: 'worktree', mode: 'rw' as const }];
    expect(findConferredWorktree(mounts, OWN)).toBeNull();
  });

  it('returns null when no worktree is conferred at all (does NOT fall back to self)', () => {
    expect(findConferredWorktree([{ path: OWN, type: 'repo', mode: 'rw' as const }], OWN)).toBeNull();
    expect(findConferredWorktree([], OWN)).toBeNull();
  });

  // R3-491: this answers "which tree does the agent author", and NOTHING else. It
  // used to also hand back the mount's `owner/repo` label as the conversation
  // scoping key, which made the panel's scope depend on a filesystem port it should
  // never have needed. Both halves read that key from `useWorkspace()` now, and the
  // label must not come back here — otherwise the coupling silently returns the
  // first time someone reaches for the convenient field.
  it('does NOT return the mount label — the scoping key is not a filesystem fact', () => {
    const mounts = [
      { path: OWN, type: 'worktree', mode: 'rw' as const, name: 'immediately-run/agent-demo' },
      { path: '/mnt/stage-grove', type: 'worktree', mode: 'ro' as const, name: 'neumark-family/recipes' },
    ];
    const conferred = findConferredWorktree(mounts, OWN);
    // Exactly the filesystem facts — a `name`/`repo` field would fail this.
    expect(conferred).toEqual({ root: '/mnt/stage-grove', readOnly: true });
    expect(Object.keys(conferred!).sort()).toEqual(['readOnly', 'root']);
  });
});

// A tiny in-memory fs implementing the FsPortLike subset the tools use. Paths are
// absolute POSIX. Good enough to exercise chroot resolution, walking, and the
// read-only / not-found branches without touching a real disk.
class MemFs implements FsPortLike {
  files = new Map<string, string>();
  dirs = new Set<string>(['/']);
  constructor(seed: Record<string, string> = {}) {
    for (const [p, c] of Object.entries(seed)) this.put(p, c);
  }
  put(p: string, c: string) {
    this.files.set(p, c);
    let d = p.slice(0, p.lastIndexOf('/'));
    while (d) {
      this.dirs.add(d);
      d = d.slice(0, d.lastIndexOf('/'));
    }
  }
  private err(code: string): Error {
    return Object.assign(new Error(code), { code });
  }
  // R3-338 added a BYTE-mode read to the port; the fake mirrors both overloads so a
  // binary round-trip is testable without a real fs.
  async readFile(path: string, encoding?: 'utf8'): Promise<string & Uint8Array> {
    if (this.dirs.has(path) && !this.files.has(path)) throw this.err('EISDIR');
    if (!this.files.has(path)) throw this.err('ENOENT');
    const text = this.files.get(path)!;
    return (encoding === 'utf8' ? text : new TextEncoder().encode(text)) as string & Uint8Array;
  }
  async writeFile(path: string, data: string | Uint8Array): Promise<void> {
    this.put(path, typeof data === 'string' ? data : new TextDecoder().decode(data));
  }
  async rename(from: string, to: string): Promise<void> {
    if (!this.files.has(from)) throw this.err('ENOENT');
    this.put(to, this.files.get(from)!);
    this.files.delete(from);
  }
  async mkdir(path: string): Promise<unknown> {
    let d = path;
    while (d) {
      this.dirs.add(d);
      d = d.slice(0, d.lastIndexOf('/'));
    }
    return undefined;
  }
  async readdir(path: string): Promise<FsDirent[]> {
    if (!this.dirs.has(path)) throw this.err(this.files.has(path) ? 'ENOTDIR' : 'ENOENT');
    const prefix = path === '/' ? '/' : `${path}/`;
    const names = new Set<string>();
    for (const f of [...this.files.keys(), ...this.dirs]) {
      if (f.startsWith(prefix) && f !== path) names.add(f.slice(prefix.length).split('/')[0]);
    }
    return [...names].map((name) => {
      const abs = prefix + name;
      const isDir = this.dirs.has(abs);
      return { name, isDirectory: () => isDir };
    });
  }
  async stat(path: string): Promise<FsStat> {
    if (this.files.has(path)) {
      const size = this.files.get(path)!.length;
      return { size, mtimeMs: 1, isFile: () => true, isDirectory: () => false };
    }
    if (this.dirs.has(path)) return { size: 0, mtimeMs: 1, isFile: () => false, isDirectory: () => true };
    throw this.err('ENOENT');
  }
  async unlink(path: string): Promise<void> {
    if (!this.files.delete(path)) throw this.err('ENOENT');
  }
}

const seed = () =>
  new MemFs({
    '/app/package.json': '{"name":"x"}',
    '/app/src/App.tsx': 'export default function App(){ return null }\nconst TODO = 1\n',
    '/app/src/lib/util.ts': 'export const add = (a:number,b:number)=>a+b // TODO refactor\n',
    '/etc/secret': 'TOPSECRET',
  });

const ts = (fs: MemFs, readOnly = false) => createFsToolset({ root: '/app', fs, readOnly });

describe('fsTools — mount-chroot filesystem tools (§3.3 phase 2)', () => {
  it('exposes the file tools — the original eight plus R3-338\'s three refactoring primitives', () => {
    const names = ts(seed()).tools.map((t) => t.name).sort();
    expect(names).toEqual([
      'copy_file',
      'delete_file',
      'edit_file',
      'glob',
      'grep',
      'list_dir',
      'move_file',
      'read_file',
      'replace_in_files',
      'stat',
      'write_file',
    ]);
  });

  it('read_file returns content; missing path → not found', async () => {
    const { execute } = ts(seed());
    expect(await execute('read_file', { path: 'package.json' })).toEqual({ content: '{"name":"x"}' });
    const miss = await execute('read_file', { path: 'nope.ts' });
    expect(miss).toEqual({ content: 'not found', isError: true });
  });

  it('a leading-slash path is workspace-root-relative, not filesystem-absolute', async () => {
    // The app sees its mount as "/"; "/package.json" means <root>/package.json,
    // matching how models naturally address files (and how list_dir reports them).
    const { execute } = ts(seed());
    expect(await execute('read_file', { path: '/package.json' })).toEqual({ content: '{"name":"x"}' });
    expect(await execute('read_file', { path: '/src/App.tsx' })).toEqual({
      content: 'export default function App(){ return null }\nconst TODO = 1\n',
    });
  });

  it('write_file creates parents and writes; reports bytes', async () => {
    const fs = seed();
    const res = await ts(fs).execute('write_file', { path: 'src/new/x.ts', content: 'hello' });
    expect(res.isError).toBeUndefined();
    expect(fs.files.get('/app/src/new/x.ts')).toBe('hello');
  });

  it('write_file and delete_file are refused on a read-only mount (no raw EROFS)', async () => {
    const fs = seed();
    const w = await ts(fs, true).execute('write_file', { path: 'src/App.tsx', content: 'x' });
    expect(w).toMatchObject({ isError: true });
    expect(w.content).toContain('read-only');
    const d = await ts(fs, true).execute('delete_file', { path: 'src/App.tsx' });
    expect(d).toMatchObject({ isError: true });
    // unchanged
    expect(fs.files.has('/app/src/App.tsx')).toBe(true);
  });

  it('list_dir lists directories first, then files', async () => {
    const { content } = await ts(seed()).execute('list_dir', { path: 'src' });
    expect(content).toBe('lib/\nApp.tsx');
  });

  it('stat reports type and size', async () => {
    const { content } = await ts(seed()).execute('stat', { path: 'package.json' });
    expect(JSON.parse(content)).toMatchObject({ path: 'package.json', type: 'file' });
  });

  it('glob matches across the tree', async () => {
    const { content } = await ts(seed()).execute('glob', { pattern: 'src/**/*.ts' });
    expect(content.split('\n').sort()).toEqual(['src/lib/util.ts']);
    const tsx = await ts(seed()).execute('glob', { pattern: 'src/*.tsx' });
    expect(tsx.content).toBe('src/App.tsx');
  });

  it('grep returns path:line: text hits', async () => {
    const { content } = await ts(seed()).execute('grep', { pattern: 'TODO' });
    const lines = content.split('\n').sort();
    expect(lines).toHaveLength(2);
    expect(lines[0]).toMatch(/^src\/App\.tsx:2: /);
    expect(lines[1]).toMatch(/^src\/lib\/util\.ts:1: /);
  });

  it('delete_file removes a file', async () => {
    const fs = seed();
    const res = await ts(fs).execute('delete_file', { path: 'package.json' });
    expect(res.isError).toBeUndefined();
    expect(fs.files.has('/app/package.json')).toBe(false);
  });

  it('cannot escape the chroot via .. or an absolute outside path (T24)', async () => {
    const { execute } = ts(seed());
    expect(await execute('read_file', { path: '../etc/secret' })).toEqual({ content: 'not found', isError: true });
    expect(await execute('read_file', { path: '/etc/secret' })).toEqual({ content: 'not found', isError: true });
    expect(await execute('read_file', { path: 'src/../../etc/secret' })).toEqual({ content: 'not found', isError: true });
  });

  it('an unknown tool name is forbidden without touching fs', async () => {
    const res = await ts(seed()).execute('rm_rf', {});
    expect(res).toMatchObject({ isError: true });
    expect(res.content).toContain('forbidden');
  });
});

// edit_file — the surgical string-replace that lets the agent change part of a large
// file without regenerating the whole thing (the fix for the big-file write_file stall).
describe('edit_file', () => {
  it('replaces a unique snippet in place without rewriting the whole file', async () => {
    const fs = seed();
    const res = await ts(fs).execute('edit_file', {
      path: 'src/lib/util.ts',
      old_string: '(a:number,b:number)=>a+b',
      new_string: '(a:number,b:number)=>a + b',
    });
    expect(res.isError).toBeUndefined();
    expect(res.content).toContain('1 replacement');
    expect(fs.files.get('/app/src/lib/util.ts')).toBe('export const add = (a:number,b:number)=>a + b // TODO refactor\n');
  });

  it('inserts by anchoring: old_string → anchor + addition (large-file insert)', async () => {
    const fs = seed();
    // Simulate adding a CSS rule after an existing one without resending the file.
    fs.put('/app/src/GroveApp.css', '.grove-quote { color: red; }\n/* code block */\n');
    const res = await ts(fs).execute('edit_file', {
      path: 'src/GroveApp.css',
      old_string: '.grove-quote { color: red; }\n',
      new_string: '.grove-quote { color: red; }\n.grove-keyvalue { margin: 1rem 0; }\n',
    });
    expect(res.isError).toBeUndefined();
    expect(fs.files.get('/app/src/GroveApp.css')).toBe(
      '.grove-quote { color: red; }\n.grove-keyvalue { margin: 1rem 0; }\n/* code block */\n',
    );
  });

  it('inserts new_string verbatim — `$` and backslashes are not special (no String.replace pattern surprises)', async () => {
    const fs = seed();
    fs.put('/app/src/money.ts', 'const a = MARK;\n');
    const res = await ts(fs).execute('edit_file', {
      path: 'src/money.ts',
      old_string: 'MARK',
      new_string: "'$1 \\n $& cost'",
    });
    expect(res.isError).toBeUndefined();
    expect(fs.files.get('/app/src/money.ts')).toBe("const a = '$1 \\n $& cost';\n");
  });

  it('refuses a non-unique old_string unless replace_all is set', async () => {
    const fs = seed();
    fs.put('/app/dup.txt', 'x\nx\nx\n');
    const ambiguous = await ts(fs).execute('edit_file', { path: 'dup.txt', old_string: 'x', new_string: 'y' });
    expect(ambiguous).toMatchObject({ isError: true });
    expect(ambiguous.content).toContain('not unique');
    expect(fs.files.get('/app/dup.txt')).toBe('x\nx\nx\n'); // untouched on refusal

    const all = await ts(fs).execute('edit_file', { path: 'dup.txt', old_string: 'x', new_string: 'y', replace_all: true });
    expect(all.isError).toBeUndefined();
    expect(all.content).toContain('3 replacements');
    expect(fs.files.get('/app/dup.txt')).toBe('y\ny\ny\n');
  });

  it('errors when old_string is not found, leaving the file untouched', async () => {
    const fs = seed();
    const res = await ts(fs).execute('edit_file', { path: 'package.json', old_string: 'nope', new_string: 'x' });
    expect(res).toMatchObject({ isError: true });
    expect(res.content).toContain('not found');
    expect(fs.files.get('/app/package.json')).toBe('{"name":"x"}');
  });

  it('rejects an empty old_string and a no-op (old === new)', async () => {
    const { execute } = ts(seed());
    expect(await execute('edit_file', { path: 'package.json', old_string: '', new_string: 'x' })).toMatchObject({ isError: true });
    expect(await execute('edit_file', { path: 'package.json', old_string: 'x', new_string: 'x' })).toMatchObject({ isError: true });
  });

  it('refuses on a read-only mount and never writes', async () => {
    const fs = seed();
    const res = await ts(fs, true).execute('edit_file', { path: 'package.json', old_string: 'x', new_string: 'y' });
    expect(res).toMatchObject({ isError: true });
    expect(res.content).toContain('read-only');
    expect(fs.files.get('/app/package.json')).toBe('{"name":"x"}');
  });

  it('cannot escape the chroot', async () => {
    const res = await ts(seed()).execute('edit_file', { path: '../etc/secret', old_string: 'TOPSECRET', new_string: 'leak' });
    expect(res).toEqual({ content: 'not found', isError: true });
  });
});

describe('read_file offset/limit paging (R3-223)', () => {
  // A 10-line file (no trailing newline) → deterministic line addressing.
  const linesFs = () => new MemFs({ '/app/lines.txt': Array.from({ length: 10 }, (_, i) => `L${i + 1}`).join('\n') });

  it('read_file advertises offset/limit in its schema', () => {
    const tool = ts(seed()).tools.find((t) => t.name === 'read_file')!;
    const props = (tool.input_schema as { properties: Record<string, unknown> }).properties;
    expect(props).toHaveProperty('offset');
    expect(props).toHaveProperty('limit');
  });

  it('offset+limit returns exactly the requested line window', async () => {
    const { execute } = ts(linesFs());
    const res = await execute('read_file', { path: 'lines.txt', offset: 3, limit: 2 });
    expect(res.content.split('\n\n')[0]).toBe('L3\nL4'); // exactly lines 3–4
    expect(res.content).toContain('continue with offset=5'); // names the next offset
  });

  it('a window that reaches EOF is marked end-of-file, not "continue"', async () => {
    const { execute } = ts(linesFs());
    const res = await execute('read_file', { path: 'lines.txt', offset: 9, limit: 5 });
    expect(res.content.split('\n\n')[0]).toBe('L9\nL10');
    expect(res.content).toContain('end of file');
    expect(res.content).not.toContain('continue with offset');
  });

  it('offset past EOF returns an explicit empty notice', async () => {
    const { execute } = ts(linesFs());
    const res = await execute('read_file', { path: 'lines.txt', offset: 99 });
    expect(res.content).toContain('past end of file');
  });

  it('omitting offset AND limit preserves verbatim behavior for a small file', async () => {
    const { execute } = ts(seed());
    // No annotation, byte-for-byte content (the fast path).
    expect(await execute('read_file', { path: '/src/App.tsx' })).toEqual({
      content: 'export default function App(){ return null }\nconst TODO = 1\n',
    });
  });

  it('a >READ_CAP file is FULLY readable by paging offset until EOF', async () => {
    // ~98 KB across 1000 lines (each ~97 bytes) — larger than the 64 KB window, so
    // the old whole-file read truncated the tail irrecoverably.
    const NLINES = 1000;
    const original = Array.from({ length: NLINES }, (_, i) => `line ${i + 1} ` + 'x'.repeat(90)).join('\n');
    const { execute } = ts(new MemFs({ '/app/big.txt': original }));

    const collected: string[] = [];
    let offset = 1;
    let guard = 0;
    for (;;) {
      if (guard++ > 100) throw new Error('paging did not terminate');
      const res = await execute('read_file', { path: 'big.txt', offset });
      const body = res.content.replace(/\n\n\[[^\]]*\]$/, ''); // strip the trailing notice
      collected.push(body);
      const m = /continue with offset=(\d+)/.exec(res.content);
      if (!m) break; // reached EOF
      offset = Number(m[1]);
    }
    expect(collected.join('\n')).toBe(original); // every byte recovered
  });
});
