var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TranscriptRows;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _index = require("@immediately-run/sdk/safeContent/index");
var _displayRows = require("../lib/displayRows");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The transcript rows shared by ConversationStage and the standalone CodingAgent
// (R3-473/R3-474). Renders a `LogEntry[]` as `<li>`s inside the caller's
// `.ca-log` list; the callers keep their own live rows (streaming text, in-flight
// thinking) after these.
//
// Two departures from the old inline rendering:
//   - Tool interactions fold (R3-473): each call+result pair collapses behind a
//     one-line summary (`<details>`, the same pattern as the reasoning rows).
//     An ERROR result renders open by default — a failed call folded away hides
//     exactly what the user needs to see — and stays user-collapsible (React only
//     resets `open` when the prop changes, so a toggle sticks).
//   - Assistant text renders as markdown (R3-474) through the platform's safe
//     renderer — content as DATA, no evaluator — with the raw text as the parse
//     fallback so nothing flashes empty. User turns stay plain: they are typed
//     text, not markup.
function ToolCallItem({
  row
}) {
  const summary = (0, _displayRows.summarizeToolInput)(row.input);
  const status = row.result ? row.result.isError ? "✗" : "✓" : "⋯";
  const statusClass = row.result ? row.result.isError ? "ca-err" : "ca-ok" : "ca-tool-running";
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
    className: "ca-toolcall",
    open: row.result?.isError ? true : undefined,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("summary", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: statusClass,
        children: status
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        children: row.name
      }), summary && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-toolcall-arg",
        children: summary
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-toolcall-body",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
        className: "ca-toolcall-pre",
        children: JSON.stringify(row.input, null, 2)
      }), row.result && /*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
        className: `ca-toolcall-pre${row.result.isError ? " ca-err" : ""}`,
        children: row.result.content
      })]
    })]
  });
}
_c = ToolCallItem;
function TranscriptRows({
  log
}) {
  _s();
  const rows = (0, _react.useMemo)(() => (0, _displayRows.toDisplayRows)(log), [log]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_jsxRuntime.Fragment, {
    children: rows.map(row => {
      if (row.kind === "toolcall") {
        return /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          className: "ca-line ca-tool",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(ToolCallItem, {
            row: row
          })
        }, row.key);
      }
      const e = row.entry;
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: `ca-line ca-${e.kind}`,
        children: [e.kind === "user" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-user",
          children: e.text
        }), e.kind === "text" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "ca-text ca-md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_index.SafeContent, {
            source: e.text,
            fallback: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "ca-text",
              children: e.text
            })
          })
        }), e.kind === "result" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: e.isError ? "ca-err" : "ca-ok",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
            children: e.name
          }), " ", e.isError ? "✗" : "✓", " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
            className: "ca-args",
            children: e.content
          })]
        }), e.kind === "error" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-err",
          children: e.text
        }), e.kind === "nudge" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-nudge",
          children: "\u21BA nudging the model to continue\u2026"
        }), e.kind === "compaction" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-compaction",
          title: e.summary,
          children: "\u2691 compacted earlier turns to stay within the context window"
        }), e.kind === "steer" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "ca-steer",
          children: [e.mode === "interrupt" ? "⟂ interrupted and steered:" : "↳ steered:", " ", e.text]
        }), e.kind === "interrupted" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-interrupted",
          children: "\u27C2 turn interrupted by you"
        }), e.kind === "reasoning" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
          className: "ca-reasoning",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
            children: e.redacted ? "thinking (redacted by the provider)" : "thinking"
          }), !e.redacted && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ca-reasoning-body",
            children: e.text
          })]
        }), e.kind === "image" && /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
          className: "ca-image",
          src: `data:${e.mimeType};base64,${e.data}`,
          alt: "Image the agent read from the workspace"
        })]
      }, row.key);
    })
  });
}
_s(TranscriptRows, "LHVMCglWcQeRoCgUufL/A5uf67g=");
_c2 = TranscriptRows;
var _c, _c2;
$RefreshReg$(_c, "ToolCallItem");
$RefreshReg$(_c2, "TranscriptRows");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2luZGV4IiwiX2Rpc3BsYXlSb3dzIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlRvb2xDYWxsSXRlbSIsInJvdyIsInN1bW1hcnkiLCJzdW1tYXJpemVUb29sSW5wdXQiLCJpbnB1dCIsInN0YXR1cyIsInJlc3VsdCIsImlzRXJyb3IiLCJzdGF0dXNDbGFzcyIsImpzeHMiLCJjbGFzc05hbWUiLCJvcGVuIiwidW5kZWZpbmVkIiwiY2hpbGRyZW4iLCJqc3giLCJuYW1lIiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnQiLCJfYyIsIlRyYW5zY3JpcHRSb3dzIiwibG9nIiwicm93cyIsInVzZU1lbW8iLCJ0b0Rpc3BsYXlSb3dzIiwiRnJhZ21lbnQiLCJtYXAiLCJraW5kIiwia2V5IiwiZSIsImVudHJ5IiwidGV4dCIsIlNhZmVDb250ZW50Iiwic291cmNlIiwiZmFsbGJhY2siLCJ0aXRsZSIsIm1vZGUiLCJyZWRhY3RlZCIsInNyYyIsIm1pbWVUeXBlIiwiZGF0YSIsImFsdCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zY3JpcHRSb3dzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgdHJhbnNjcmlwdCByb3dzIHNoYXJlZCBieSBDb252ZXJzYXRpb25TdGFnZSBhbmQgdGhlIHN0YW5kYWxvbmUgQ29kaW5nQWdlbnRcbi8vIChSMy00NzMvUjMtNDc0KS4gUmVuZGVycyBhIGBMb2dFbnRyeVtdYCBhcyBgPGxpPmBzIGluc2lkZSB0aGUgY2FsbGVyJ3Ncbi8vIGAuY2EtbG9nYCBsaXN0OyB0aGUgY2FsbGVycyBrZWVwIHRoZWlyIG93biBsaXZlIHJvd3MgKHN0cmVhbWluZyB0ZXh0LCBpbi1mbGlnaHRcbi8vIHRoaW5raW5nKSBhZnRlciB0aGVzZS5cbi8vXG4vLyBUd28gZGVwYXJ0dXJlcyBmcm9tIHRoZSBvbGQgaW5saW5lIHJlbmRlcmluZzpcbi8vICAgLSBUb29sIGludGVyYWN0aW9ucyBmb2xkIChSMy00NzMpOiBlYWNoIGNhbGwrcmVzdWx0IHBhaXIgY29sbGFwc2VzIGJlaGluZCBhXG4vLyAgICAgb25lLWxpbmUgc3VtbWFyeSAoYDxkZXRhaWxzPmAsIHRoZSBzYW1lIHBhdHRlcm4gYXMgdGhlIHJlYXNvbmluZyByb3dzKS5cbi8vICAgICBBbiBFUlJPUiByZXN1bHQgcmVuZGVycyBvcGVuIGJ5IGRlZmF1bHQg4oCUIGEgZmFpbGVkIGNhbGwgZm9sZGVkIGF3YXkgaGlkZXNcbi8vICAgICBleGFjdGx5IHdoYXQgdGhlIHVzZXIgbmVlZHMgdG8gc2VlIOKAlCBhbmQgc3RheXMgdXNlci1jb2xsYXBzaWJsZSAoUmVhY3Qgb25seVxuLy8gICAgIHJlc2V0cyBgb3BlbmAgd2hlbiB0aGUgcHJvcCBjaGFuZ2VzLCBzbyBhIHRvZ2dsZSBzdGlja3MpLlxuLy8gICAtIEFzc2lzdGFudCB0ZXh0IHJlbmRlcnMgYXMgbWFya2Rvd24gKFIzLTQ3NCkgdGhyb3VnaCB0aGUgcGxhdGZvcm0ncyBzYWZlXG4vLyAgICAgcmVuZGVyZXIg4oCUIGNvbnRlbnQgYXMgREFUQSwgbm8gZXZhbHVhdG9yIOKAlCB3aXRoIHRoZSByYXcgdGV4dCBhcyB0aGUgcGFyc2Vcbi8vICAgICBmYWxsYmFjayBzbyBub3RoaW5nIGZsYXNoZXMgZW1wdHkuIFVzZXIgdHVybnMgc3RheSBwbGFpbjogdGhleSBhcmUgdHlwZWRcbi8vICAgICB0ZXh0LCBub3QgbWFya3VwLlxuaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgU2FmZUNvbnRlbnQgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvc2FmZUNvbnRlbnQvaW5kZXhcIjtcbmltcG9ydCB0eXBlIHsgTG9nRW50cnkgfSBmcm9tIFwiLi4vbGliL3RyYW5zY3JpcHRcIjtcbmltcG9ydCB7IHRvRGlzcGxheVJvd3MsIHN1bW1hcml6ZVRvb2xJbnB1dCwgdHlwZSBUb29sQ2FsbFJvdyB9IGZyb20gXCIuLi9saWIvZGlzcGxheVJvd3NcIjtcblxuZnVuY3Rpb24gVG9vbENhbGxJdGVtKHsgcm93IH06IHsgcm93OiBUb29sQ2FsbFJvdyB9KSB7XG4gIGNvbnN0IHN1bW1hcnkgPSBzdW1tYXJpemVUb29sSW5wdXQocm93LmlucHV0KTtcbiAgY29uc3Qgc3RhdHVzID0gcm93LnJlc3VsdCA/IChyb3cucmVzdWx0LmlzRXJyb3IgPyBcIuKcl1wiIDogXCLinJNcIikgOiBcIuKLr1wiO1xuICBjb25zdCBzdGF0dXNDbGFzcyA9IHJvdy5yZXN1bHQgPyAocm93LnJlc3VsdC5pc0Vycm9yID8gXCJjYS1lcnJcIiA6IFwiY2Etb2tcIikgOiBcImNhLXRvb2wtcnVubmluZ1wiO1xuICByZXR1cm4gKFxuICAgIDxkZXRhaWxzIGNsYXNzTmFtZT1cImNhLXRvb2xjYWxsXCIgb3Blbj17cm93LnJlc3VsdD8uaXNFcnJvciA/IHRydWUgOiB1bmRlZmluZWR9PlxuICAgICAgPHN1bW1hcnk+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3RhdHVzQ2xhc3N9PntzdGF0dXN9PC9zcGFuPiA8Y29kZT57cm93Lm5hbWV9PC9jb2RlPlxuICAgICAgICB7c3VtbWFyeSAmJiA8c3BhbiBjbGFzc05hbWU9XCJjYS10b29sY2FsbC1hcmdcIj57c3VtbWFyeX08L3NwYW4+fVxuICAgICAgPC9zdW1tYXJ5PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYS10b29sY2FsbC1ib2R5XCI+XG4gICAgICAgIDxwcmUgY2xhc3NOYW1lPVwiY2EtdG9vbGNhbGwtcHJlXCI+e0pTT04uc3RyaW5naWZ5KHJvdy5pbnB1dCwgbnVsbCwgMil9PC9wcmU+XG4gICAgICAgIHtyb3cucmVzdWx0ICYmIChcbiAgICAgICAgICA8cHJlIGNsYXNzTmFtZT17YGNhLXRvb2xjYWxsLXByZSR7cm93LnJlc3VsdC5pc0Vycm9yID8gXCIgY2EtZXJyXCIgOiBcIlwifWB9Pntyb3cucmVzdWx0LmNvbnRlbnR9PC9wcmU+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2RldGFpbHM+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRyYW5zY3JpcHRSb3dzKHsgbG9nIH06IHsgbG9nOiByZWFkb25seSBMb2dFbnRyeVtdIH0pIHtcbiAgY29uc3Qgcm93cyA9IHVzZU1lbW8oKCkgPT4gdG9EaXNwbGF5Um93cyhsb2cpLCBbbG9nXSk7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtyb3dzLm1hcCgocm93KSA9PiB7XG4gICAgICAgIGlmIChyb3cua2luZCA9PT0gXCJ0b29sY2FsbFwiKSB7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e3Jvdy5rZXl9IGNsYXNzTmFtZT1cImNhLWxpbmUgY2EtdG9vbFwiPlxuICAgICAgICAgICAgICA8VG9vbENhbGxJdGVtIHJvdz17cm93fSAvPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGUgPSByb3cuZW50cnk7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGxpIGtleT17cm93LmtleX0gY2xhc3NOYW1lPXtgY2EtbGluZSBjYS0ke2Uua2luZH1gfT5cbiAgICAgICAgICAgIHtlLmtpbmQgPT09IFwidXNlclwiICYmIDxzcGFuIGNsYXNzTmFtZT1cImNhLXVzZXJcIj57ZS50ZXh0fTwvc3Bhbj59XG4gICAgICAgICAgICB7ZS5raW5kID09PSBcInRleHRcIiAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EtdGV4dCBjYS1tZFwiPlxuICAgICAgICAgICAgICAgIDxTYWZlQ29udGVudCBzb3VyY2U9e2UudGV4dH0gZmFsbGJhY2s9ezxzcGFuIGNsYXNzTmFtZT1cImNhLXRleHRcIj57ZS50ZXh0fTwvc3Bhbj59IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHsvKiBBbiBvcnBoYW4gcmVzdWx0IChpdHMgY2FsbCBmZWxsIG9mZiBhIHRydW5jYXRlZCByZXBsYXkpIOKAlCBzdGlsbCBzaG93bi4gKi99XG4gICAgICAgICAgICB7ZS5raW5kID09PSBcInJlc3VsdFwiICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtlLmlzRXJyb3IgPyBcImNhLWVyclwiIDogXCJjYS1va1wifT5cbiAgICAgICAgICAgICAgICA8Y29kZT57ZS5uYW1lfTwvY29kZT4ge2UuaXNFcnJvciA/IFwi4pyXXCIgOiBcIuKck1wifSA8Y29kZSBjbGFzc05hbWU9XCJjYS1hcmdzXCI+e2UuY29udGVudH08L2NvZGU+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7ZS5raW5kID09PSBcImVycm9yXCIgJiYgPHNwYW4gY2xhc3NOYW1lPVwiY2EtZXJyXCI+e2UudGV4dH08L3NwYW4+fVxuICAgICAgICAgICAge2Uua2luZCA9PT0gXCJudWRnZVwiICYmIDxzcGFuIGNsYXNzTmFtZT1cImNhLW51ZGdlXCI+4oa6IG51ZGdpbmcgdGhlIG1vZGVsIHRvIGNvbnRpbnVl4oCmPC9zcGFuPn1cbiAgICAgICAgICAgIHtlLmtpbmQgPT09IFwiY29tcGFjdGlvblwiICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtY29tcGFjdGlvblwiIHRpdGxlPXtlLnN1bW1hcnl9PlxuICAgICAgICAgICAgICAgIOKakSBjb21wYWN0ZWQgZWFybGllciB0dXJucyB0byBzdGF5IHdpdGhpbiB0aGUgY29udGV4dCB3aW5kb3dcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtlLmtpbmQgPT09IFwic3RlZXJcIiAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXN0ZWVyXCI+XG4gICAgICAgICAgICAgICAge2UubW9kZSA9PT0gXCJpbnRlcnJ1cHRcIiA/IFwi4p+CIGludGVycnVwdGVkIGFuZCBzdGVlcmVkOlwiIDogXCLihrMgc3RlZXJlZDpcIn0ge2UudGV4dH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtlLmtpbmQgPT09IFwiaW50ZXJydXB0ZWRcIiAmJiA8c3BhbiBjbGFzc05hbWU9XCJjYS1pbnRlcnJ1cHRlZFwiPuKfgiB0dXJuIGludGVycnVwdGVkIGJ5IHlvdTwvc3Bhbj59XG4gICAgICAgICAgICB7ZS5raW5kID09PSBcInJlYXNvbmluZ1wiICYmIChcbiAgICAgICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiY2EtcmVhc29uaW5nXCI+XG4gICAgICAgICAgICAgICAgPHN1bW1hcnk+e2UucmVkYWN0ZWQgPyBcInRoaW5raW5nIChyZWRhY3RlZCBieSB0aGUgcHJvdmlkZXIpXCIgOiBcInRoaW5raW5nXCJ9PC9zdW1tYXJ5PlxuICAgICAgICAgICAgICAgIHshZS5yZWRhY3RlZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJjYS1yZWFzb25pbmctYm9keVwiPntlLnRleHR9PC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9kZXRhaWxzPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtlLmtpbmQgPT09IFwiaW1hZ2VcIiAmJiAoXG4gICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYS1pbWFnZVwiXG4gICAgICAgICAgICAgICAgc3JjPXtgZGF0YToke2UubWltZVR5cGV9O2Jhc2U2NCwke2UuZGF0YX1gfVxuICAgICAgICAgICAgICAgIGFsdD1cIkltYWdlIHRoZSBhZ2VudCByZWFkIGZyb20gdGhlIHdvcmtzcGFjZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFlQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxZQUFBLEdBQUFGLE9BQUE7QUFBeUYsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBbEJ6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQSxTQUFTQyxZQUFZQSxDQUFDO0VBQUVDO0FBQTBCLENBQUMsRUFBRTtFQUNuRCxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsK0JBQWtCLEVBQUNGLEdBQUcsQ0FBQ0csS0FBSyxDQUFDO0VBQzdDLE1BQU1DLE1BQU0sR0FBR0osR0FBRyxDQUFDSyxNQUFNLEdBQUlMLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDQyxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBSSxHQUFHO0VBQ2xFLE1BQU1DLFdBQVcsR0FBR1AsR0FBRyxDQUFDSyxNQUFNLEdBQUlMLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDQyxPQUFPLEdBQUcsUUFBUSxHQUFHLE9BQU8sR0FBSSxpQkFBaUI7RUFDOUYsb0JBQ0UsSUFBQVYsV0FBQSxDQUFBWSxJQUFBO0lBQVNDLFNBQVMsRUFBQyxhQUFhO0lBQUNDLElBQUksRUFBRVYsR0FBRyxDQUFDSyxNQUFNLEVBQUVDLE9BQU8sR0FBRyxJQUFJLEdBQUdLLFNBQVU7SUFBQUMsUUFBQSxnQkFDNUUsSUFBQWhCLFdBQUEsQ0FBQVksSUFBQTtNQUFBSSxRQUFBLGdCQUNFLElBQUFoQixXQUFBLENBQUFpQixHQUFBO1FBQU1KLFNBQVMsRUFBRUYsV0FBWTtRQUFBSyxRQUFBLEVBQUVSO01BQU0sQ0FBTyxDQUFDLEtBQUMsbUJBQUFSLFdBQUEsQ0FBQWlCLEdBQUE7UUFBQUQsUUFBQSxFQUFPWixHQUFHLENBQUNjO01BQUksQ0FBTyxDQUFDLEVBQ3BFYixPQUFPLGlCQUFJLElBQUFMLFdBQUEsQ0FBQWlCLEdBQUE7UUFBTUosU0FBUyxFQUFDLGlCQUFpQjtRQUFBRyxRQUFBLEVBQUVYO01BQU8sQ0FBTyxDQUFDO0lBQUEsQ0FDdkQsQ0FBQyxlQUNWLElBQUFMLFdBQUEsQ0FBQVksSUFBQTtNQUFLQyxTQUFTLEVBQUMsa0JBQWtCO01BQUFHLFFBQUEsZ0JBQy9CLElBQUFoQixXQUFBLENBQUFpQixHQUFBO1FBQUtKLFNBQVMsRUFBQyxpQkFBaUI7UUFBQUcsUUFBQSxFQUFFRyxJQUFJLENBQUNDLFNBQVMsQ0FBQ2hCLEdBQUcsQ0FBQ0csS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO01BQUMsQ0FBTSxDQUFDLEVBQzFFSCxHQUFHLENBQUNLLE1BQU0saUJBQ1QsSUFBQVQsV0FBQSxDQUFBaUIsR0FBQTtRQUFLSixTQUFTLEVBQUUsa0JBQWtCVCxHQUFHLENBQUNLLE1BQU0sQ0FBQ0MsT0FBTyxHQUFHLFNBQVMsR0FBRyxFQUFFLEVBQUc7UUFBQU0sUUFBQSxFQUFFWixHQUFHLENBQUNLLE1BQU0sQ0FBQ1k7TUFBTyxDQUFNLENBQ25HO0lBQUEsQ0FDRSxDQUFDO0VBQUEsQ0FDQyxDQUFDO0FBRWQ7QUFBQ0MsRUFBQSxHQWxCUW5CLFlBQVk7QUFvQk4sU0FBU29CLGNBQWNBLENBQUM7RUFBRUM7QUFBa0MsQ0FBQyxFQUFFO0VBQUF2QixFQUFBO0VBQzVFLE1BQU13QixJQUFJLEdBQUcsSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsMEJBQWEsRUFBQ0gsR0FBRyxDQUFDLEVBQUUsQ0FBQ0EsR0FBRyxDQUFDLENBQUM7RUFDckQsb0JBQ0UsSUFBQXhCLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQWpCLFdBQUEsQ0FBQTRCLFFBQUE7SUFBQVosUUFBQSxFQUNHUyxJQUFJLENBQUNJLEdBQUcsQ0FBRXpCLEdBQUcsSUFBSztNQUNqQixJQUFJQSxHQUFHLENBQUMwQixJQUFJLEtBQUssVUFBVSxFQUFFO1FBQzNCLG9CQUNFLElBQUE5QixXQUFBLENBQUFpQixHQUFBO1VBQWtCSixTQUFTLEVBQUMsaUJBQWlCO1VBQUFHLFFBQUEsZUFDM0MsSUFBQWhCLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsWUFBWTtZQUFDQyxHQUFHLEVBQUVBO1VBQUksQ0FBRTtRQUFDLEdBRG5CQSxHQUFHLENBQUMyQixHQUVULENBQUM7TUFFVDtNQUNBLE1BQU1DLENBQUMsR0FBRzVCLEdBQUcsQ0FBQzZCLEtBQUs7TUFDbkIsb0JBQ0UsSUFBQWpDLFdBQUEsQ0FBQVksSUFBQTtRQUFrQkMsU0FBUyxFQUFFLGNBQWNtQixDQUFDLENBQUNGLElBQUksRUFBRztRQUFBZCxRQUFBLEdBQ2pEZ0IsQ0FBQyxDQUFDRixJQUFJLEtBQUssTUFBTSxpQkFBSSxJQUFBOUIsV0FBQSxDQUFBaUIsR0FBQTtVQUFNSixTQUFTLEVBQUMsU0FBUztVQUFBRyxRQUFBLEVBQUVnQixDQUFDLENBQUNFO1FBQUksQ0FBTyxDQUFDLEVBQzlERixDQUFDLENBQUNGLElBQUksS0FBSyxNQUFNLGlCQUNoQixJQUFBOUIsV0FBQSxDQUFBaUIsR0FBQTtVQUFLSixTQUFTLEVBQUMsZUFBZTtVQUFBRyxRQUFBLGVBQzVCLElBQUFoQixXQUFBLENBQUFpQixHQUFBLEVBQUNuQixNQUFBLENBQUFxQyxXQUFXO1lBQUNDLE1BQU0sRUFBRUosQ0FBQyxDQUFDRSxJQUFLO1lBQUNHLFFBQVEsZUFBRSxJQUFBckMsV0FBQSxDQUFBaUIsR0FBQTtjQUFNSixTQUFTLEVBQUMsU0FBUztjQUFBRyxRQUFBLEVBQUVnQixDQUFDLENBQUNFO1lBQUksQ0FBTztVQUFFLENBQUU7UUFBQyxDQUNqRixDQUNOLEVBRUFGLENBQUMsQ0FBQ0YsSUFBSSxLQUFLLFFBQVEsaUJBQ2xCLElBQUE5QixXQUFBLENBQUFZLElBQUE7VUFBTUMsU0FBUyxFQUFFbUIsQ0FBQyxDQUFDdEIsT0FBTyxHQUFHLFFBQVEsR0FBRyxPQUFRO1VBQUFNLFFBQUEsZ0JBQzlDLElBQUFoQixXQUFBLENBQUFpQixHQUFBO1lBQUFELFFBQUEsRUFBT2dCLENBQUMsQ0FBQ2Q7VUFBSSxDQUFPLENBQUMsS0FBQyxFQUFDYyxDQUFDLENBQUN0QixPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBQyxHQUFDLG1CQUFBVixXQUFBLENBQUFpQixHQUFBO1lBQU1KLFNBQVMsRUFBQyxTQUFTO1lBQUFHLFFBQUEsRUFBRWdCLENBQUMsQ0FBQ1g7VUFBTyxDQUFPLENBQUM7UUFBQSxDQUN0RixDQUNQLEVBQ0FXLENBQUMsQ0FBQ0YsSUFBSSxLQUFLLE9BQU8saUJBQUksSUFBQTlCLFdBQUEsQ0FBQWlCLEdBQUE7VUFBTUosU0FBUyxFQUFDLFFBQVE7VUFBQUcsUUFBQSxFQUFFZ0IsQ0FBQyxDQUFDRTtRQUFJLENBQU8sQ0FBQyxFQUM5REYsQ0FBQyxDQUFDRixJQUFJLEtBQUssT0FBTyxpQkFBSSxJQUFBOUIsV0FBQSxDQUFBaUIsR0FBQTtVQUFNSixTQUFTLEVBQUMsVUFBVTtVQUFBRyxRQUFBLEVBQUM7UUFBZ0MsQ0FBTSxDQUFDLEVBQ3hGZ0IsQ0FBQyxDQUFDRixJQUFJLEtBQUssWUFBWSxpQkFDdEIsSUFBQTlCLFdBQUEsQ0FBQWlCLEdBQUE7VUFBTUosU0FBUyxFQUFDLGVBQWU7VUFBQ3lCLEtBQUssRUFBRU4sQ0FBQyxDQUFDM0IsT0FBUTtVQUFBVyxRQUFBLEVBQUM7UUFFbEQsQ0FBTSxDQUNQLEVBQ0FnQixDQUFDLENBQUNGLElBQUksS0FBSyxPQUFPLGlCQUNqQixJQUFBOUIsV0FBQSxDQUFBWSxJQUFBO1VBQU1DLFNBQVMsRUFBQyxVQUFVO1VBQUFHLFFBQUEsR0FDdkJnQixDQUFDLENBQUNPLElBQUksS0FBSyxXQUFXLEdBQUcsNEJBQTRCLEdBQUcsWUFBWSxFQUFDLEdBQUMsRUFBQ1AsQ0FBQyxDQUFDRSxJQUFJO1FBQUEsQ0FDMUUsQ0FDUCxFQUNBRixDQUFDLENBQUNGLElBQUksS0FBSyxhQUFhLGlCQUFJLElBQUE5QixXQUFBLENBQUFpQixHQUFBO1VBQU1KLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUcsUUFBQSxFQUFDO1FBQXlCLENBQU0sQ0FBQyxFQUM3RmdCLENBQUMsQ0FBQ0YsSUFBSSxLQUFLLFdBQVcsaUJBQ3JCLElBQUE5QixXQUFBLENBQUFZLElBQUE7VUFBU0MsU0FBUyxFQUFDLGNBQWM7VUFBQUcsUUFBQSxnQkFDL0IsSUFBQWhCLFdBQUEsQ0FBQWlCLEdBQUE7WUFBQUQsUUFBQSxFQUFVZ0IsQ0FBQyxDQUFDUSxRQUFRLEdBQUcscUNBQXFDLEdBQUc7VUFBVSxDQUFVLENBQUMsRUFDbkYsQ0FBQ1IsQ0FBQyxDQUFDUSxRQUFRLGlCQUFJLElBQUF4QyxXQUFBLENBQUFpQixHQUFBO1lBQU1KLFNBQVMsRUFBQyxtQkFBbUI7WUFBQUcsUUFBQSxFQUFFZ0IsQ0FBQyxDQUFDRTtVQUFJLENBQU8sQ0FBQztRQUFBLENBQzVELENBQ1YsRUFDQUYsQ0FBQyxDQUFDRixJQUFJLEtBQUssT0FBTyxpQkFDakIsSUFBQTlCLFdBQUEsQ0FBQWlCLEdBQUE7VUFDRUosU0FBUyxFQUFDLFVBQVU7VUFDcEI0QixHQUFHLEVBQUUsUUFBUVQsQ0FBQyxDQUFDVSxRQUFRLFdBQVdWLENBQUMsQ0FBQ1csSUFBSSxFQUFHO1VBQzNDQyxHQUFHLEVBQUM7UUFBeUMsQ0FDOUMsQ0FDRjtNQUFBLEdBdENNeEMsR0FBRyxDQUFDMkIsR0F1Q1QsQ0FBQztJQUVULENBQUM7RUFBQyxDQUNGLENBQUM7QUFFUDtBQUFDOUIsRUFBQSxDQTFEdUJzQixjQUFjO0FBQUFzQixHQUFBLEdBQWR0QixjQUFjO0FBQUEsSUFBQUQsRUFBQSxFQUFBdUIsR0FBQTtBQUFBQyxZQUFBLENBQUF4QixFQUFBO0FBQUF3QixZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}