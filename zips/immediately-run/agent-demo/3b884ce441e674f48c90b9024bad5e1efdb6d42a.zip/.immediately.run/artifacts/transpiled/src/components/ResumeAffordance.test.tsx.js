var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _react = require("@testing-library/react");
var _ResumeAffordance = _interopRequireDefault(require("./ResumeAffordance"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// @vitest-environment happy-dom
// R3-695 — the attended-resume affordance's shape, pinned (AGENT_RUN_DURABILITY
// §5.3, the 2026-09-15 disposition): the offered choices are EXACTLY TWO
// ("Resume run", "Keep the files and end the run"), the file-changes-stay copy
// is said plainly, and the third spec'd choice — discard the tail AND revert
// the run's writes — is NOT offered (a discard button would silently keep the
// files: the rev-2 trap). Extracted from ConversationStage so the shape is
// assertable without mounting the stage.

(0, _vitest.afterEach)(_react.cleanup);
(0, _vitest.describe)("ResumeAffordance — the two-choice shape (R-ARD-15 / §5.3 disposition)", () => {
  (0, _vitest.it)("offers exactly the two disposition choices — resume, and keep-the-files-and-end — and no third", () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ResumeAffordance.default, {
      journalDepth: 14,
      onResume: () => {},
      onKeepAndEnd: () => {}
    }));
    const buttons = _react.screen.getAllByRole("button");
    (0, _vitest.expect)(buttons.map(b => b.textContent)).toEqual(["Resume run", "Keep the files and end the run"]);
    // No discard-and-revert anywhere: the disposition killed it, and copy that
    // offers what will not happen is the trap the disposition exists to remove.
    (0, _vitest.expect)(document.body.textContent).not.toMatch(/discard/i);
  });
  (0, _vitest.it)("says the file changes stay, renders the work artifact ('interrupted after N steps'), never an unanswerable question", () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ResumeAffordance.default, {
      journalDepth: 14,
      onResume: () => {},
      onKeepAndEnd: () => {}
    }));
    const text = _react.screen.getByRole("status").textContent ?? "";
    (0, _vitest.expect)(text).toContain("interrupted after 14 steps");
    (0, _vitest.expect)(text).toContain("the file changes so far stay");
    (0, _vitest.expect)(text).not.toMatch(/\?$/); // §5.3: never a question the user cannot answer
  });
  (0, _vitest.it)("routes each choice to its verb", () => {
    const onResume = _vitest.vi.fn();
    const onKeepAndEnd = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ResumeAffordance.default, {
      journalDepth: 3,
      onResume: onResume,
      onKeepAndEnd: onKeepAndEnd
    }));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Resume run"
    }));
    (0, _vitest.expect)(onResume).toHaveBeenCalledTimes(1);
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Keep the files and end the run"
    }));
    (0, _vitest.expect)(onKeepAndEnd).toHaveBeenCalledTimes(1);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9SZXN1bWVBZmZvcmRhbmNlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiYWZ0ZXJFYWNoIiwiY2xlYW51cCIsImRlc2NyaWJlIiwiaXQiLCJyZW5kZXIiLCJqc3giLCJqb3VybmFsRGVwdGgiLCJvblJlc3VtZSIsIm9uS2VlcEFuZEVuZCIsImJ1dHRvbnMiLCJzY3JlZW4iLCJnZXRBbGxCeVJvbGUiLCJleHBlY3QiLCJtYXAiLCJiIiwidGV4dENvbnRlbnQiLCJ0b0VxdWFsIiwiZG9jdW1lbnQiLCJib2R5Iiwibm90IiwidG9NYXRjaCIsInRleHQiLCJnZXRCeVJvbGUiLCJ0b0NvbnRhaW4iLCJ2aSIsImZuIiwiZmlyZUV2ZW50IiwiY2xpY2siLCJuYW1lIiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIl0sInNvdXJjZXMiOlsiUmVzdW1lQWZmb3JkYW5jZS50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGhhcHB5LWRvbVxuLy8gUjMtNjk1IOKAlCB0aGUgYXR0ZW5kZWQtcmVzdW1lIGFmZm9yZGFuY2UncyBzaGFwZSwgcGlubmVkIChBR0VOVF9SVU5fRFVSQUJJTElUWVxuLy8gwqc1LjMsIHRoZSAyMDI2LTA5LTE1IGRpc3Bvc2l0aW9uKTogdGhlIG9mZmVyZWQgY2hvaWNlcyBhcmUgRVhBQ1RMWSBUV09cbi8vIChcIlJlc3VtZSBydW5cIiwgXCJLZWVwIHRoZSBmaWxlcyBhbmQgZW5kIHRoZSBydW5cIiksIHRoZSBmaWxlLWNoYW5nZXMtc3RheSBjb3B5XG4vLyBpcyBzYWlkIHBsYWlubHksIGFuZCB0aGUgdGhpcmQgc3BlYydkIGNob2ljZSDigJQgZGlzY2FyZCB0aGUgdGFpbCBBTkQgcmV2ZXJ0XG4vLyB0aGUgcnVuJ3Mgd3JpdGVzIOKAlCBpcyBOT1Qgb2ZmZXJlZCAoYSBkaXNjYXJkIGJ1dHRvbiB3b3VsZCBzaWxlbnRseSBrZWVwIHRoZVxuLy8gZmlsZXM6IHRoZSByZXYtMiB0cmFwKS4gRXh0cmFjdGVkIGZyb20gQ29udmVyc2F0aW9uU3RhZ2Ugc28gdGhlIHNoYXBlIGlzXG4vLyBhc3NlcnRhYmxlIHdpdGhvdXQgbW91bnRpbmcgdGhlIHN0YWdlLlxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QsIHZpLCBhZnRlckVhY2ggfSBmcm9tIFwidml0ZXN0XCI7XG5pbXBvcnQgeyByZW5kZXIsIHNjcmVlbiwgZmlyZUV2ZW50LCBjbGVhbnVwIH0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcbmltcG9ydCBSZXN1bWVBZmZvcmRhbmNlIGZyb20gXCIuL1Jlc3VtZUFmZm9yZGFuY2VcIjtcblxuYWZ0ZXJFYWNoKGNsZWFudXApO1xuXG5kZXNjcmliZShcIlJlc3VtZUFmZm9yZGFuY2Ug4oCUIHRoZSB0d28tY2hvaWNlIHNoYXBlIChSLUFSRC0xNSAvIMKnNS4zIGRpc3Bvc2l0aW9uKVwiLCAoKSA9PiB7XG4gIGl0KFwib2ZmZXJzIGV4YWN0bHkgdGhlIHR3byBkaXNwb3NpdGlvbiBjaG9pY2VzIOKAlCByZXN1bWUsIGFuZCBrZWVwLXRoZS1maWxlcy1hbmQtZW5kIOKAlCBhbmQgbm8gdGhpcmRcIiwgKCkgPT4ge1xuICAgIHJlbmRlcig8UmVzdW1lQWZmb3JkYW5jZSBqb3VybmFsRGVwdGg9ezE0fSBvblJlc3VtZT17KCkgPT4ge319IG9uS2VlcEFuZEVuZD17KCkgPT4ge319IC8+KTtcbiAgICBjb25zdCBidXR0b25zID0gc2NyZWVuLmdldEFsbEJ5Um9sZShcImJ1dHRvblwiKTtcbiAgICBleHBlY3QoYnV0dG9ucy5tYXAoKGIpID0+IGIudGV4dENvbnRlbnQpKS50b0VxdWFsKFtcIlJlc3VtZSBydW5cIiwgXCJLZWVwIHRoZSBmaWxlcyBhbmQgZW5kIHRoZSBydW5cIl0pO1xuICAgIC8vIE5vIGRpc2NhcmQtYW5kLXJldmVydCBhbnl3aGVyZTogdGhlIGRpc3Bvc2l0aW9uIGtpbGxlZCBpdCwgYW5kIGNvcHkgdGhhdFxuICAgIC8vIG9mZmVycyB3aGF0IHdpbGwgbm90IGhhcHBlbiBpcyB0aGUgdHJhcCB0aGUgZGlzcG9zaXRpb24gZXhpc3RzIHRvIHJlbW92ZS5cbiAgICBleHBlY3QoZG9jdW1lbnQuYm9keS50ZXh0Q29udGVudCkubm90LnRvTWF0Y2goL2Rpc2NhcmQvaSk7XG4gIH0pO1xuXG4gIGl0KFwic2F5cyB0aGUgZmlsZSBjaGFuZ2VzIHN0YXksIHJlbmRlcnMgdGhlIHdvcmsgYXJ0aWZhY3QgKCdpbnRlcnJ1cHRlZCBhZnRlciBOIHN0ZXBzJyksIG5ldmVyIGFuIHVuYW5zd2VyYWJsZSBxdWVzdGlvblwiLCAoKSA9PiB7XG4gICAgcmVuZGVyKDxSZXN1bWVBZmZvcmRhbmNlIGpvdXJuYWxEZXB0aD17MTR9IG9uUmVzdW1lPXsoKSA9PiB7fX0gb25LZWVwQW5kRW5kPXsoKSA9PiB7fX0gLz4pO1xuICAgIGNvbnN0IHRleHQgPSBzY3JlZW4uZ2V0QnlSb2xlKFwic3RhdHVzXCIpLnRleHRDb250ZW50ID8/IFwiXCI7XG4gICAgZXhwZWN0KHRleHQpLnRvQ29udGFpbihcImludGVycnVwdGVkIGFmdGVyIDE0IHN0ZXBzXCIpO1xuICAgIGV4cGVjdCh0ZXh0KS50b0NvbnRhaW4oXCJ0aGUgZmlsZSBjaGFuZ2VzIHNvIGZhciBzdGF5XCIpO1xuICAgIGV4cGVjdCh0ZXh0KS5ub3QudG9NYXRjaCgvXFw/JC8pOyAvLyDCpzUuMzogbmV2ZXIgYSBxdWVzdGlvbiB0aGUgdXNlciBjYW5ub3QgYW5zd2VyXG4gIH0pO1xuXG4gIGl0KFwicm91dGVzIGVhY2ggY2hvaWNlIHRvIGl0cyB2ZXJiXCIsICgpID0+IHtcbiAgICBjb25zdCBvblJlc3VtZSA9IHZpLmZuKCk7XG4gICAgY29uc3Qgb25LZWVwQW5kRW5kID0gdmkuZm4oKTtcbiAgICByZW5kZXIoPFJlc3VtZUFmZm9yZGFuY2Ugam91cm5hbERlcHRoPXszfSBvblJlc3VtZT17b25SZXN1bWV9IG9uS2VlcEFuZEVuZD17b25LZWVwQW5kRW5kfSAvPik7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlJlc3VtZSBydW5cIiB9KSk7XG4gICAgZXhwZWN0KG9uUmVzdW1lKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIktlZXAgdGhlIGZpbGVzIGFuZCBlbmQgdGhlIHJ1blwiIH0pKTtcbiAgICBleHBlY3Qob25LZWVwQW5kRW5kKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFRQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxpQkFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQWtELElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLFNBQUFHLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBVmxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsSUFBQUcsaUJBQVMsRUFBQ0MsY0FBTyxDQUFDO0FBRWxCLElBQUFDLGdCQUFRLEVBQUMsdUVBQXVFLEVBQUUsTUFBTTtFQUN0RixJQUFBQyxVQUFFLEVBQUMsZ0dBQWdHLEVBQUUsTUFBTTtJQUN6RyxJQUFBQyxhQUFNLGVBQUMsSUFBQVIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLGlCQUFBLENBQUFLLE9BQWdCO01BQUNPLFlBQVksRUFBRSxFQUFHO01BQUNDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBRTtNQUFDQyxZQUFZLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDMUYsTUFBTUMsT0FBTyxHQUFHQyxhQUFNLENBQUNDLFlBQVksQ0FBQyxRQUFRLENBQUM7SUFDN0MsSUFBQUMsY0FBTSxFQUFDSCxPQUFPLENBQUNJLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLFlBQVksRUFBRSxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ25HO0lBQ0E7SUFDQSxJQUFBSixjQUFNLEVBQUNLLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDSCxXQUFXLENBQUMsQ0FBQ0ksR0FBRyxDQUFDQyxPQUFPLENBQUMsVUFBVSxDQUFDO0VBQzNELENBQUMsQ0FBQztFQUVGLElBQUFqQixVQUFFLEVBQUMscUhBQXFILEVBQUUsTUFBTTtJQUM5SCxJQUFBQyxhQUFNLGVBQUMsSUFBQVIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLGlCQUFBLENBQUFLLE9BQWdCO01BQUNPLFlBQVksRUFBRSxFQUFHO01BQUNDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBRTtNQUFDQyxZQUFZLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDMUYsTUFBTWEsSUFBSSxHQUFHWCxhQUFNLENBQUNZLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ1AsV0FBVyxJQUFJLEVBQUU7SUFDekQsSUFBQUgsY0FBTSxFQUFDUyxJQUFJLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLDRCQUE0QixDQUFDO0lBQ3BELElBQUFYLGNBQU0sRUFBQ1MsSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQyw4QkFBOEIsQ0FBQztJQUN0RCxJQUFBWCxjQUFNLEVBQUNTLElBQUksQ0FBQyxDQUFDRixHQUFHLENBQUNDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ25DLENBQUMsQ0FBQztFQUVGLElBQUFqQixVQUFFLEVBQUMsZ0NBQWdDLEVBQUUsTUFBTTtJQUN6QyxNQUFNSSxRQUFRLEdBQUdpQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU1qQixZQUFZLEdBQUdnQixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQzVCLElBQUFyQixhQUFNLGVBQUMsSUFBQVIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLGlCQUFBLENBQUFLLE9BQWdCO01BQUNPLFlBQVksRUFBRSxDQUFFO01BQUNDLFFBQVEsRUFBRUEsUUFBUztNQUFDQyxZQUFZLEVBQUVBO0lBQWEsQ0FBRSxDQUFDLENBQUM7SUFDN0ZrQixnQkFBUyxDQUFDQyxLQUFLLENBQUNqQixhQUFNLENBQUNZLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRU0sSUFBSSxFQUFFO0lBQWEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsSUFBQWhCLGNBQU0sRUFBQ0wsUUFBUSxDQUFDLENBQUNzQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDekNILGdCQUFTLENBQUNDLEtBQUssQ0FBQ2pCLGFBQU0sQ0FBQ1ksU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFTSxJQUFJLEVBQUU7SUFBaUMsQ0FBQyxDQUFDLENBQUM7SUFDdkYsSUFBQWhCLGNBQU0sRUFBQ0osWUFBWSxDQUFDLENBQUNxQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7RUFDL0MsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}