var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ResumeAffordance;
var _jsxRuntime = require("react/jsx-runtime");
// R3-560 / R-ARD-15 — the attended-resume affordance, extracted (R3-695) so the
// §5.3 disposition's shape is testable: the offered choices are EXACTLY TWO
// ("resume", "keep the files and end the run"), the file-changes-stay copy is
// said plainly, and the third spec'd choice — discard the tail AND revert the
// run's writes — is NOT offered (disposition of 2026-09-15: the app cannot
// bound which writes were one run's, so a discard button would silently keep
// the files — the rev-2 trap). AGENT_RUN_DURABILITY_SPEC §5.3 is the single
// source; this component renders it and adds nothing.

function ResumeAffordance({
  journalDepth,
  onResume,
  onKeepAndEnd
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ca-line ca-error",
    role: "status",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "ca-err",
      children: ["This run was interrupted after ", journalDepth, " steps. You can resume it from its last checkpoint \u2014 either way, the file changes so far stay."]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-resume-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-run",
        onClick: onResume,
        children: "Resume run"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-steer-btn",
        onClick: onKeepAndEnd,
        children: "Keep the files and end the run"
      })]
    })]
  });
}
_c = ResumeAffordance;
var _c;
$RefreshReg$(_c, "ResumeAffordance");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJSZXN1bWVBZmZvcmRhbmNlIiwiam91cm5hbERlcHRoIiwib25SZXN1bWUiLCJvbktlZXBBbmRFbmQiLCJfanN4UnVudGltZSIsImpzeHMiLCJjbGFzc05hbWUiLCJyb2xlIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwib25DbGljayIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVzdW1lQWZmb3JkYW5jZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUjMtNTYwIC8gUi1BUkQtMTUg4oCUIHRoZSBhdHRlbmRlZC1yZXN1bWUgYWZmb3JkYW5jZSwgZXh0cmFjdGVkIChSMy02OTUpIHNvIHRoZVxuLy8gwqc1LjMgZGlzcG9zaXRpb24ncyBzaGFwZSBpcyB0ZXN0YWJsZTogdGhlIG9mZmVyZWQgY2hvaWNlcyBhcmUgRVhBQ1RMWSBUV09cbi8vIChcInJlc3VtZVwiLCBcImtlZXAgdGhlIGZpbGVzIGFuZCBlbmQgdGhlIHJ1blwiKSwgdGhlIGZpbGUtY2hhbmdlcy1zdGF5IGNvcHkgaXNcbi8vIHNhaWQgcGxhaW5seSwgYW5kIHRoZSB0aGlyZCBzcGVjJ2QgY2hvaWNlIOKAlCBkaXNjYXJkIHRoZSB0YWlsIEFORCByZXZlcnQgdGhlXG4vLyBydW4ncyB3cml0ZXMg4oCUIGlzIE5PVCBvZmZlcmVkIChkaXNwb3NpdGlvbiBvZiAyMDI2LTA5LTE1OiB0aGUgYXBwIGNhbm5vdFxuLy8gYm91bmQgd2hpY2ggd3JpdGVzIHdlcmUgb25lIHJ1bidzLCBzbyBhIGRpc2NhcmQgYnV0dG9uIHdvdWxkIHNpbGVudGx5IGtlZXBcbi8vIHRoZSBmaWxlcyDigJQgdGhlIHJldi0yIHRyYXApLiBBR0VOVF9SVU5fRFVSQUJJTElUWV9TUEVDIMKnNS4zIGlzIHRoZSBzaW5nbGVcbi8vIHNvdXJjZTsgdGhpcyBjb21wb25lbnQgcmVuZGVycyBpdCBhbmQgYWRkcyBub3RoaW5nLlxuaW50ZXJmYWNlIFJlc3VtZUFmZm9yZGFuY2VQcm9wcyB7XG4gIC8qKiBSMy01NjA6IHRoZSBqb3VybmFsIGRlcHRoIGFib3ZlIHRoZSBmb2xkIOKAlCBcImludGVycnVwdGVkIGFmdGVyIE4gc3RlcHNcIi4gKi9cbiAgam91cm5hbERlcHRoOiBudW1iZXI7XG4gIG9uUmVzdW1lOiAoKSA9PiB2b2lkO1xuICBvbktlZXBBbmRFbmQ6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlc3VtZUFmZm9yZGFuY2UoeyBqb3VybmFsRGVwdGgsIG9uUmVzdW1lLCBvbktlZXBBbmRFbmQgfTogUmVzdW1lQWZmb3JkYW5jZVByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYS1saW5lIGNhLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtZXJyXCI+XG4gICAgICAgIFRoaXMgcnVuIHdhcyBpbnRlcnJ1cHRlZCBhZnRlciB7am91cm5hbERlcHRofSBzdGVwcy4gWW91IGNhbiByZXN1bWUgaXQgZnJvbSBpdHMgbGFzdCBjaGVja3BvaW50IOKAlCBlaXRoZXJcbiAgICAgICAgd2F5LCB0aGUgZmlsZSBjaGFuZ2VzIHNvIGZhciBzdGF5LlxuICAgICAgPC9zcGFuPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYS1yZXN1bWUtcm93XCI+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNhLXJ1blwiIG9uQ2xpY2s9e29uUmVzdW1lfT5cbiAgICAgICAgICBSZXN1bWUgcnVuXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjYS1zdGVlci1idG5cIiBvbkNsaWNrPXtvbktlZXBBbmRFbmR9PlxuICAgICAgICAgIEtlZXAgdGhlIGZpbGVzIGFuZCBlbmQgdGhlIHJ1blxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFRZSxTQUFTQSxnQkFBZ0JBLENBQUM7RUFBRUMsWUFBWTtFQUFFQyxRQUFRO0VBQUVDO0FBQW9DLENBQUMsRUFBRTtFQUN4RyxvQkFDRSxJQUFBQyxXQUFBLENBQUFDLElBQUE7SUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtJQUFDQyxJQUFJLEVBQUMsUUFBUTtJQUFBQyxRQUFBLGdCQUM3QyxJQUFBSixXQUFBLENBQUFDLElBQUE7TUFBTUMsU0FBUyxFQUFDLFFBQVE7TUFBQUUsUUFBQSxHQUFDLGlDQUNRLEVBQUNQLFlBQVksRUFBQyxxR0FFL0M7SUFBQSxDQUFNLENBQUMsZUFDUCxJQUFBRyxXQUFBLENBQUFDLElBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQUUsUUFBQSxnQkFDNUIsSUFBQUosV0FBQSxDQUFBSyxHQUFBO1FBQVFDLElBQUksRUFBQyxRQUFRO1FBQUNKLFNBQVMsRUFBQyxRQUFRO1FBQUNLLE9BQU8sRUFBRVQsUUFBUztRQUFBTSxRQUFBLEVBQUM7TUFFNUQsQ0FBUSxDQUFDLGVBQ1QsSUFBQUosV0FBQSxDQUFBSyxHQUFBO1FBQVFDLElBQUksRUFBQyxRQUFRO1FBQUNKLFNBQVMsRUFBQyxjQUFjO1FBQUNLLE9BQU8sRUFBRVIsWUFBYTtRQUFBSyxRQUFBLEVBQUM7TUFFdEUsQ0FBUSxDQUFDO0lBQUEsQ0FDTixDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ0ksRUFBQSxHQWpCdUJaLGdCQUFnQjtBQUFBLElBQUFZLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}