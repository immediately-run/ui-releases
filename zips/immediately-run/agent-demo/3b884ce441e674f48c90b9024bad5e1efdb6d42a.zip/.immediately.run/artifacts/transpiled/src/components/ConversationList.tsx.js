var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ConversationList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _conversationStore = require("../lib/conversationStore");
var _conversationScope = require("../lib/conversationScope");
var _conversationUpdate = require("../lib/conversationUpdate");
var _conversationIpc = require("../lib/conversationIpc");
var _storeError = require("../lib/storeError");
require("./ConversationList.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The conversation LIST — the panel-slot half of the agents activity (plan Phase
// 04, region `panel.agent`). The analog of the file explorer: it lists the user's
// conversations and a "new" button, and on selection posts the conversation id to
// the stage over IPC. It runs no agent and holds no net:fetch — all model calls
// happen in the stage (ConversationStage).
//
// R3-475 — the list is SCOPED to the repository loaded in the workbench: the
// scoping key is `useWorkspace()?.label` (the workspace the host projects to the
// panel), NOT a conferred worktree mount — the `exposesWorkingTree` shortcut was
// rejected (the panel holds no such capability and site-main pins it absent; see
// the item's narrowed history). Conversations stamped with another repo never mix
// into the list; they surface under "Other repositories" (repo + count). Legacy
// unstamped conversations ride along with every scope and get stamped on their
// next save.
function relTime(ms) {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 45) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

/** R3-475 — what an other-repositories count IS, in words ("2 conversations in
 *  other/repo"): the hover title and the visually-hidden accessible text are the
 *  one string, so they can never disagree. */
function countLabel(g) {
  return `${g.count} ${g.count === 1 ? "conversation" : "conversations"} in ${g.repo}`;
}
function ConversationList() {
  _s();
  const storeRef = (0, _react.useRef)(null);
  const [items, setItems] = (0, _react.useState)([]);
  const [selected, setSelected] = (0, _react.useState)(null);
  const [ready, setReady] = (0, _react.useState)(false);
  // Why the store is unavailable, if it is. Without it "New conversation" is a
  // silent no-op and the list is permanently empty — never leave that unexplained
  // (R3-247).
  const [storeError, setStoreError] = (0, _react.useState)(null);

  // The repository loaded in the workbench (R3-475), from the baseline workspace
  // channel (R3-491). `undefined` when there is no editing session — the channel
  // reports `null` and `scopeConversations` then lists only unstamped conversations,
  // which is the honest answer rather than a guess.
  const currentRepo = (0, _sdk.useWorkspace)()?.label;

  // Scope the list (R3-475): this repo's conversations (plus legacy unstamped
  // ones) vs. every other repo, grouped. Pure rule in conversationScope.ts.
  const {
    mine,
    others
  } = (0, _react.useMemo)(() => (0, _conversationScope.scopeConversations)(items, currentRepo), [items, currentRepo]);

  // The selection the stage should show: the user's explicit choice while it is
  // still in scope, else the newest in-scope conversation (so the stage isn't
  // blank, and a repo switch or delete re-lands somewhere sensible). DERIVED, not
  // set from an effect — there is one writer (`setSelected`, gesture handlers),
  // while the announcements come from both a gesture post (`openConversation`,
  // so a re-tap of the selected row still lands) and the derived-change effect below.
  const effectiveSelected = (0, _react.useMemo)(() => {
    if (selected && mine.some(c => c.id === selected)) return selected;
    return mine[0]?.id ?? null;
  }, [selected, mine]);

  // Announce a DERIVED selection change to the stage — the bookkeeping fallback (first
  // row on load, next after a delete/scope change). A user's tap is also announced
  // directly by `openConversation`, so a re-tap of the already-selected row — which does
  // not change `effectiveSelected` and so skips this effect — still posts (R3-616). A
  // tap on a *different* row is therefore announced twice — by the gesture post and
  // again by this effect — the item's accepted cost, harmless because the arbiter is
  // idempotent.
  (0, _react.useEffect)(() => {
    if (!effectiveSelected) return;
    void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(effectiveSelected)).catch(() => {});
  }, [effectiveSelected]);

  // The current selection, readable from the IPC listener without re-subscribing it
  // on every change (the stage asks for it when it mounts). Mirrored in an effect,
  // not during render — the listener only ever reads it asynchronously.
  const selectedRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    selectedRef.current = effectiveSelected;
  }, [effectiveSelected]);

  // OPEN = select AND take the user there (R3-243). Distinct from `select` on
  // purpose: only a tap that MEANS "show me this" advances the column. Selecting
  // the first conversation on load, or the next one after a delete, is bookkeeping
  // — advancing there would move the user somewhere they didn't ask to go, and the
  // host would refuse it anyway (no gesture).
  //
  // The host ignores a reveal it doesn't like, so this needs no success handling;
  // it only swallows the authorization rejection (an older host has no `reveal`
  // method, which must degrade to today's behaviour rather than an unhandled reject).
  const openConversation = (0, _react.useCallback)(id => {
    setSelected(id);
    // A tap is an event, not a state transition: announce it directly (R3-616) so a tap
    // on the already-selected row still posts — the derived-value effect above only fires
    // when `effectiveSelected` changes, so the re-tap case was previously silent.
    void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(id)).catch(() => {});
    void (0, _sdk.revealRegion)(_conversationIpc.STAGE_REGION).catch(() => {});
  }, []);
  const refresh = (0, _react.useCallback)(async () => {
    const store = storeRef.current;
    if (!store) return;
    try {
      setItems(await store.list());
    } catch {
      /* transient read failure — keep the last good list */
    }
  }, []);

  // Open the store and list. Selection happens in the scoped effect below, so the
  // stage isn't seeded with another repo's newest conversation (R3-475).
  (0, _react.useEffect)(() => {
    let live = true;
    void (async () => {
      try {
        const store = await (0, _conversationStore.openConversationStore)();
        if (!live) return;
        storeRef.current = store;
        const list = await store.list();
        if (!live) return;
        setItems(list);
        setStoreError(null);
      } catch (e) {
        if (live) setStoreError((0, _storeError.describeStoreFailure)(e));
      } finally {
        if (live) setReady(true);
      }
    })();
    return () => {
      live = false;
    };
  }, []);

  // Keep the list fresh. A `conversation-updated` message names ONE conversation,
  // so the handler loads that row and patches it in place (R3-612 / R-IX-4) — a
  // full `list()` re-reads every conversation JSON (cap 500) to learn one row's
  // title and timestamp moved. `refresh()` stays for the focus-regain path, where
  // there is no narrower signal; the mount path lists directly (it needs the
  // store-open error handling too).
  const patchOne = (0, _react.useCallback)(async id => {
    const store = storeRef.current;
    if (!store) return;
    try {
      const conv = await store.load(id);
      // `null` = deleted elsewhere (or corrupt): the row goes.
      setItems(l => conv ? (0, _conversationUpdate.applyConversationUpdate)(l, (0, _conversationStore.metaOf)(conv)) : l.filter(c => c.id !== id));
    } catch {
      // Read failure — keep the last good list, the same resolution as refresh().
    }
  }, []);
  (0, _react.useEffect)(() => {
    const off = (0, _sdk.onRegionMessage)(m => {
      if ((0, _conversationIpc.isUpdated)(m.data)) void patchOne(m.data.id);
      // The stage mounted and wants to know what it should be showing (R3-243). It
      // may have missed the `select-conversation` entirely: on mobile it does not
      // exist until the reveal puts it on screen, which happens after the post.
      // Answering here is what makes tapping an OLDER conversation land on that one
      // rather than on the newest.
      else if ((0, _conversationIpc.isRequestSelection)(m.data) && selectedRef.current) {
        void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(selectedRef.current)).catch(() => {});
      }
    });
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      off();
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh, patchOne]);
  const newConversation = async () => {
    const store = storeRef.current;
    // No store ⇒ the button cannot work. Say why rather than doing nothing.
    if (!store) {
      setStoreError(prev => prev ?? (0, _storeError.describeStoreFailure)(new Error("settings unavailable")));
      return;
    }
    try {
      // Stamped with the loaded repo (R3-475) so it scopes correctly from birth.
      const conv = await store.create(undefined, currentRepo);
      setItems(l => [(0, _conversationStore.metaOf)(conv), ...l]);
      setStoreError(null);
      openConversation(conv.id);
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e));
    }
  };
  const remove = async id => {
    const store = storeRef.current;
    if (!store) return;
    try {
      await store.remove(id);
    } catch (e) {
      // A delete that failed must leave the row in place and say why (R-IX-3):
      // dropping it anyway would show a change that did not happen. Same
      // failure surface as create/save above.
      setStoreError((0, _storeError.describeStoreFailure)(e));
      return;
    }
    setItems(l => l.filter(c => c.id !== id));
    if (selected === id) setSelected(null); // the scoped effect re-selects
    setStoreError(null);
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "cl",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "cl-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "cl-title",
        children: "Conversations"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "cl-new",
        onClick: () => void newConversation(),
        children: "New conversation"
      })]
    }), currentRepo && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-scope",
      title: "Conversations are scoped to the repository loaded in the workbench.",
      children: currentRepo
    }), storeError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-empty cl-error",
      role: "status",
      children: storeError
    }), ready && !storeError && mine.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-empty",
      children: "No conversations here yet. Start one with \u201CNew conversation\u201D."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "cl-list",
      children: mine.map(c => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: `cl-row${effectiveSelected === c.id ? " cl-row-active" : ""}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "cl-row-open",
          "aria-pressed": effectiveSelected === c.id,
          onClick: () => openConversation(c.id),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "cl-row-title",
            children: c.title
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "cl-row-time",
            children: relTime(c.updatedAt)
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "cl-del",
          "aria-label": `Delete ${c.title}`,
          onClick: () => void remove(c.id),
          children: "\xD7"
        })]
      }, c.id))
    }), ready && others.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
      className: "cl-others",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
        children: "Other repositories"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "cl-others-list",
        children: others.map(g => {
          // R3-475 — the count must say what it counts: a bare digit has no
          // hover label and announces as a lone number to a screen reader.
          // The row's own title says what OPENING the repo does; the count's
          // label says what the number IS. (The accessible text is
          // visually-hidden real text, not aria-label on a generic span —
          // naming is prohibited on role=generic, so aria-label would be a
          // placebo.)
          const label = countLabel(g);
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
            className: "cl-others-row",
            title: `Open ${g.repo} on immediately.run to see these conversations.`,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "cl-others-repo",
              children: g.repo
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "cl-others-count",
              title: label,
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "cl-vh",
                children: label
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                "aria-hidden": "true",
                children: g.count
              })]
            })]
          }, g.repo);
        })
      })]
    })]
  });
}
_s(ConversationList, "7vY28WZ+cphe8xs0tvBtCFzf4ok=", false, function () {
  return [_sdk.useWorkspace];
});
_c = ConversationList;
var _c;
$RefreshReg$(_c, "ConversationList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb252ZXJzYXRpb25TdG9yZSIsIl9jb252ZXJzYXRpb25TY29wZSIsIl9jb252ZXJzYXRpb25VcGRhdGUiLCJfY29udmVyc2F0aW9uSXBjIiwiX3N0b3JlRXJyb3IiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwicmVsVGltZSIsIm1zIiwicyIsIk1hdGgiLCJtYXgiLCJyb3VuZCIsIkRhdGUiLCJub3ciLCJtIiwiaCIsImNvdW50TGFiZWwiLCJnIiwiY291bnQiLCJyZXBvIiwiQ29udmVyc2F0aW9uTGlzdCIsInN0b3JlUmVmIiwidXNlUmVmIiwiaXRlbXMiLCJzZXRJdGVtcyIsInVzZVN0YXRlIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInJlYWR5Iiwic2V0UmVhZHkiLCJzdG9yZUVycm9yIiwic2V0U3RvcmVFcnJvciIsImN1cnJlbnRSZXBvIiwidXNlV29ya3NwYWNlIiwibGFiZWwiLCJtaW5lIiwib3RoZXJzIiwidXNlTWVtbyIsInNjb3BlQ29udmVyc2F0aW9ucyIsImVmZmVjdGl2ZVNlbGVjdGVkIiwic29tZSIsImMiLCJpZCIsInVzZUVmZmVjdCIsInBvc3RUb1JlZ2lvbiIsIlNUQUdFX1JFR0lPTiIsInNlbGVjdE1lc3NhZ2UiLCJjYXRjaCIsInNlbGVjdGVkUmVmIiwiY3VycmVudCIsIm9wZW5Db252ZXJzYXRpb24iLCJ1c2VDYWxsYmFjayIsInJldmVhbFJlZ2lvbiIsInJlZnJlc2giLCJzdG9yZSIsImxpc3QiLCJsaXZlIiwib3BlbkNvbnZlcnNhdGlvblN0b3JlIiwiZSIsImRlc2NyaWJlU3RvcmVGYWlsdXJlIiwicGF0Y2hPbmUiLCJjb252IiwibG9hZCIsImwiLCJhcHBseUNvbnZlcnNhdGlvblVwZGF0ZSIsIm1ldGFPZiIsImZpbHRlciIsIm9mZiIsIm9uUmVnaW9uTWVzc2FnZSIsImlzVXBkYXRlZCIsImRhdGEiLCJpc1JlcXVlc3RTZWxlY3Rpb24iLCJvbkZvY3VzIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJuZXdDb252ZXJzYXRpb24iLCJwcmV2IiwiRXJyb3IiLCJjcmVhdGUiLCJ1bmRlZmluZWQiLCJyZW1vdmUiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwib25DbGljayIsInRpdGxlIiwicm9sZSIsImxlbmd0aCIsIm1hcCIsInVwZGF0ZWRBdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udmVyc2F0aW9uTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGNvbnZlcnNhdGlvbiBMSVNUIOKAlCB0aGUgcGFuZWwtc2xvdCBoYWxmIG9mIHRoZSBhZ2VudHMgYWN0aXZpdHkgKHBsYW4gUGhhc2Vcbi8vIDA0LCByZWdpb24gYHBhbmVsLmFnZW50YCkuIFRoZSBhbmFsb2cgb2YgdGhlIGZpbGUgZXhwbG9yZXI6IGl0IGxpc3RzIHRoZSB1c2VyJ3Ncbi8vIGNvbnZlcnNhdGlvbnMgYW5kIGEgXCJuZXdcIiBidXR0b24sIGFuZCBvbiBzZWxlY3Rpb24gcG9zdHMgdGhlIGNvbnZlcnNhdGlvbiBpZCB0b1xuLy8gdGhlIHN0YWdlIG92ZXIgSVBDLiBJdCBydW5zIG5vIGFnZW50IGFuZCBob2xkcyBubyBuZXQ6ZmV0Y2gg4oCUIGFsbCBtb2RlbCBjYWxsc1xuLy8gaGFwcGVuIGluIHRoZSBzdGFnZSAoQ29udmVyc2F0aW9uU3RhZ2UpLlxuLy9cbi8vIFIzLTQ3NSDigJQgdGhlIGxpc3QgaXMgU0NPUEVEIHRvIHRoZSByZXBvc2l0b3J5IGxvYWRlZCBpbiB0aGUgd29ya2JlbmNoOiB0aGVcbi8vIHNjb3Bpbmcga2V5IGlzIGB1c2VXb3Jrc3BhY2UoKT8ubGFiZWxgICh0aGUgd29ya3NwYWNlIHRoZSBob3N0IHByb2plY3RzIHRvIHRoZVxuLy8gcGFuZWwpLCBOT1QgYSBjb25mZXJyZWQgd29ya3RyZWUgbW91bnQg4oCUIHRoZSBgZXhwb3Nlc1dvcmtpbmdUcmVlYCBzaG9ydGN1dCB3YXNcbi8vIHJlamVjdGVkICh0aGUgcGFuZWwgaG9sZHMgbm8gc3VjaCBjYXBhYmlsaXR5IGFuZCBzaXRlLW1haW4gcGlucyBpdCBhYnNlbnQ7IHNlZVxuLy8gdGhlIGl0ZW0ncyBuYXJyb3dlZCBoaXN0b3J5KS4gQ29udmVyc2F0aW9ucyBzdGFtcGVkIHdpdGggYW5vdGhlciByZXBvIG5ldmVyIG1peFxuLy8gaW50byB0aGUgbGlzdDsgdGhleSBzdXJmYWNlIHVuZGVyIFwiT3RoZXIgcmVwb3NpdG9yaWVzXCIgKHJlcG8gKyBjb3VudCkuIExlZ2FjeVxuLy8gdW5zdGFtcGVkIGNvbnZlcnNhdGlvbnMgcmlkZSBhbG9uZyB3aXRoIGV2ZXJ5IHNjb3BlIGFuZCBnZXQgc3RhbXBlZCBvbiB0aGVpclxuLy8gbmV4dCBzYXZlLlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgcG9zdFRvUmVnaW9uLCBvblJlZ2lvbk1lc3NhZ2UsIHJldmVhbFJlZ2lvbiwgdXNlV29ya3NwYWNlIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyBvcGVuQ29udmVyc2F0aW9uU3RvcmUsIG1ldGFPZiwgdHlwZSBDb252ZXJzYXRpb25TdG9yZSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uU3RvcmVcIjtcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uTWV0YSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uTW9kZWxcIjtcbmltcG9ydCB7IHNjb3BlQ29udmVyc2F0aW9ucywgdHlwZSBSZXBvR3JvdXAgfSBmcm9tIFwiLi4vbGliL2NvbnZlcnNhdGlvblNjb3BlXCI7XG5pbXBvcnQgeyBhcHBseUNvbnZlcnNhdGlvblVwZGF0ZSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uVXBkYXRlXCI7XG5pbXBvcnQgeyBTVEFHRV9SRUdJT04sIGlzVXBkYXRlZCwgaXNSZXF1ZXN0U2VsZWN0aW9uLCBzZWxlY3RNZXNzYWdlIH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25JcGNcIjtcbmltcG9ydCB7IGRlc2NyaWJlU3RvcmVGYWlsdXJlIH0gZnJvbSBcIi4uL2xpYi9zdG9yZUVycm9yXCI7XG5pbXBvcnQgXCIuL0NvbnZlcnNhdGlvbkxpc3QuY3NzXCI7XG5cbmZ1bmN0aW9uIHJlbFRpbWUobXM6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IHMgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gbXMpIC8gMTAwMCkpO1xuICBpZiAocyA8IDQ1KSByZXR1cm4gXCJqdXN0IG5vd1wiO1xuICBjb25zdCBtID0gTWF0aC5yb3VuZChzIC8gNjApO1xuICBpZiAobSA8IDYwKSByZXR1cm4gYCR7bX1tIGFnb2A7XG4gIGNvbnN0IGggPSBNYXRoLnJvdW5kKG0gLyA2MCk7XG4gIGlmIChoIDwgMjQpIHJldHVybiBgJHtofWggYWdvYDtcbiAgcmV0dXJuIGAke01hdGgucm91bmQoaCAvIDI0KX1kIGFnb2A7XG59XG5cbi8qKiBSMy00NzUg4oCUIHdoYXQgYW4gb3RoZXItcmVwb3NpdG9yaWVzIGNvdW50IElTLCBpbiB3b3JkcyAoXCIyIGNvbnZlcnNhdGlvbnMgaW5cbiAqICBvdGhlci9yZXBvXCIpOiB0aGUgaG92ZXIgdGl0bGUgYW5kIHRoZSB2aXN1YWxseS1oaWRkZW4gYWNjZXNzaWJsZSB0ZXh0IGFyZSB0aGVcbiAqICBvbmUgc3RyaW5nLCBzbyB0aGV5IGNhbiBuZXZlciBkaXNhZ3JlZS4gKi9cbmZ1bmN0aW9uIGNvdW50TGFiZWwoZzogUmVwb0dyb3VwKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2cuY291bnR9ICR7Zy5jb3VudCA9PT0gMSA/IFwiY29udmVyc2F0aW9uXCIgOiBcImNvbnZlcnNhdGlvbnNcIn0gaW4gJHtnLnJlcG99YDtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ29udmVyc2F0aW9uTGlzdCgpIHtcbiAgY29uc3Qgc3RvcmVSZWYgPSB1c2VSZWY8Q29udmVyc2F0aW9uU3RvcmUgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZTxDb252ZXJzYXRpb25NZXRhW10+KFtdKTtcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3JlYWR5LCBzZXRSZWFkeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIC8vIFdoeSB0aGUgc3RvcmUgaXMgdW5hdmFpbGFibGUsIGlmIGl0IGlzLiBXaXRob3V0IGl0IFwiTmV3IGNvbnZlcnNhdGlvblwiIGlzIGFcbiAgLy8gc2lsZW50IG5vLW9wIGFuZCB0aGUgbGlzdCBpcyBwZXJtYW5lbnRseSBlbXB0eSDigJQgbmV2ZXIgbGVhdmUgdGhhdCB1bmV4cGxhaW5lZFxuICAvLyAoUjMtMjQ3KS5cbiAgY29uc3QgW3N0b3JlRXJyb3IsIHNldFN0b3JlRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gVGhlIHJlcG9zaXRvcnkgbG9hZGVkIGluIHRoZSB3b3JrYmVuY2ggKFIzLTQ3NSksIGZyb20gdGhlIGJhc2VsaW5lIHdvcmtzcGFjZVxuICAvLyBjaGFubmVsIChSMy00OTEpLiBgdW5kZWZpbmVkYCB3aGVuIHRoZXJlIGlzIG5vIGVkaXRpbmcgc2Vzc2lvbiDigJQgdGhlIGNoYW5uZWxcbiAgLy8gcmVwb3J0cyBgbnVsbGAgYW5kIGBzY29wZUNvbnZlcnNhdGlvbnNgIHRoZW4gbGlzdHMgb25seSB1bnN0YW1wZWQgY29udmVyc2F0aW9ucyxcbiAgLy8gd2hpY2ggaXMgdGhlIGhvbmVzdCBhbnN3ZXIgcmF0aGVyIHRoYW4gYSBndWVzcy5cbiAgY29uc3QgY3VycmVudFJlcG8gPSB1c2VXb3Jrc3BhY2UoKT8ubGFiZWw7XG5cbiAgLy8gU2NvcGUgdGhlIGxpc3QgKFIzLTQ3NSk6IHRoaXMgcmVwbydzIGNvbnZlcnNhdGlvbnMgKHBsdXMgbGVnYWN5IHVuc3RhbXBlZFxuICAvLyBvbmVzKSB2cy4gZXZlcnkgb3RoZXIgcmVwbywgZ3JvdXBlZC4gUHVyZSBydWxlIGluIGNvbnZlcnNhdGlvblNjb3BlLnRzLlxuICBjb25zdCB7IG1pbmUsIG90aGVycyB9ID0gdXNlTWVtbygoKSA9PiBzY29wZUNvbnZlcnNhdGlvbnMoaXRlbXMsIGN1cnJlbnRSZXBvKSwgW2l0ZW1zLCBjdXJyZW50UmVwb10pO1xuXG4gIC8vIFRoZSBzZWxlY3Rpb24gdGhlIHN0YWdlIHNob3VsZCBzaG93OiB0aGUgdXNlcidzIGV4cGxpY2l0IGNob2ljZSB3aGlsZSBpdCBpc1xuICAvLyBzdGlsbCBpbiBzY29wZSwgZWxzZSB0aGUgbmV3ZXN0IGluLXNjb3BlIGNvbnZlcnNhdGlvbiAoc28gdGhlIHN0YWdlIGlzbid0XG4gIC8vIGJsYW5rLCBhbmQgYSByZXBvIHN3aXRjaCBvciBkZWxldGUgcmUtbGFuZHMgc29tZXdoZXJlIHNlbnNpYmxlKS4gREVSSVZFRCwgbm90XG4gIC8vIHNldCBmcm9tIGFuIGVmZmVjdCDigJQgdGhlcmUgaXMgb25lIHdyaXRlciAoYHNldFNlbGVjdGVkYCwgZ2VzdHVyZSBoYW5kbGVycyksXG4gIC8vIHdoaWxlIHRoZSBhbm5vdW5jZW1lbnRzIGNvbWUgZnJvbSBib3RoIGEgZ2VzdHVyZSBwb3N0IChgb3BlbkNvbnZlcnNhdGlvbmAsXG4gIC8vIHNvIGEgcmUtdGFwIG9mIHRoZSBzZWxlY3RlZCByb3cgc3RpbGwgbGFuZHMpIGFuZCB0aGUgZGVyaXZlZC1jaGFuZ2UgZWZmZWN0IGJlbG93LlxuICBjb25zdCBlZmZlY3RpdmVTZWxlY3RlZCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZCAmJiBtaW5lLnNvbWUoKGMpID0+IGMuaWQgPT09IHNlbGVjdGVkKSkgcmV0dXJuIHNlbGVjdGVkO1xuICAgIHJldHVybiBtaW5lWzBdPy5pZCA/PyBudWxsO1xuICB9LCBbc2VsZWN0ZWQsIG1pbmVdKTtcblxuICAvLyBBbm5vdW5jZSBhIERFUklWRUQgc2VsZWN0aW9uIGNoYW5nZSB0byB0aGUgc3RhZ2Ug4oCUIHRoZSBib29ra2VlcGluZyBmYWxsYmFjayAoZmlyc3RcbiAgLy8gcm93IG9uIGxvYWQsIG5leHQgYWZ0ZXIgYSBkZWxldGUvc2NvcGUgY2hhbmdlKS4gQSB1c2VyJ3MgdGFwIGlzIGFsc28gYW5ub3VuY2VkXG4gIC8vIGRpcmVjdGx5IGJ5IGBvcGVuQ29udmVyc2F0aW9uYCwgc28gYSByZS10YXAgb2YgdGhlIGFscmVhZHktc2VsZWN0ZWQgcm93IOKAlCB3aGljaCBkb2VzXG4gIC8vIG5vdCBjaGFuZ2UgYGVmZmVjdGl2ZVNlbGVjdGVkYCBhbmQgc28gc2tpcHMgdGhpcyBlZmZlY3Qg4oCUIHN0aWxsIHBvc3RzIChSMy02MTYpLiBBXG4gIC8vIHRhcCBvbiBhICpkaWZmZXJlbnQqIHJvdyBpcyB0aGVyZWZvcmUgYW5ub3VuY2VkIHR3aWNlIOKAlCBieSB0aGUgZ2VzdHVyZSBwb3N0IGFuZFxuICAvLyBhZ2FpbiBieSB0aGlzIGVmZmVjdCDigJQgdGhlIGl0ZW0ncyBhY2NlcHRlZCBjb3N0LCBoYXJtbGVzcyBiZWNhdXNlIHRoZSBhcmJpdGVyIGlzXG4gIC8vIGlkZW1wb3RlbnQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlZmZlY3RpdmVTZWxlY3RlZCkgcmV0dXJuO1xuICAgIHZvaWQgcG9zdFRvUmVnaW9uKFNUQUdFX1JFR0lPTiwgc2VsZWN0TWVzc2FnZShlZmZlY3RpdmVTZWxlY3RlZCkpLmNhdGNoKCgpID0+IHt9KTtcbiAgfSwgW2VmZmVjdGl2ZVNlbGVjdGVkXSk7XG5cbiAgLy8gVGhlIGN1cnJlbnQgc2VsZWN0aW9uLCByZWFkYWJsZSBmcm9tIHRoZSBJUEMgbGlzdGVuZXIgd2l0aG91dCByZS1zdWJzY3JpYmluZyBpdFxuICAvLyBvbiBldmVyeSBjaGFuZ2UgKHRoZSBzdGFnZSBhc2tzIGZvciBpdCB3aGVuIGl0IG1vdW50cykuIE1pcnJvcmVkIGluIGFuIGVmZmVjdCxcbiAgLy8gbm90IGR1cmluZyByZW5kZXIg4oCUIHRoZSBsaXN0ZW5lciBvbmx5IGV2ZXIgcmVhZHMgaXQgYXN5bmNocm9ub3VzbHkuXG4gIGNvbnN0IHNlbGVjdGVkUmVmID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNlbGVjdGVkUmVmLmN1cnJlbnQgPSBlZmZlY3RpdmVTZWxlY3RlZDtcbiAgfSwgW2VmZmVjdGl2ZVNlbGVjdGVkXSk7XG5cbiAgLy8gT1BFTiA9IHNlbGVjdCBBTkQgdGFrZSB0aGUgdXNlciB0aGVyZSAoUjMtMjQzKS4gRGlzdGluY3QgZnJvbSBgc2VsZWN0YCBvblxuICAvLyBwdXJwb3NlOiBvbmx5IGEgdGFwIHRoYXQgTUVBTlMgXCJzaG93IG1lIHRoaXNcIiBhZHZhbmNlcyB0aGUgY29sdW1uLiBTZWxlY3RpbmdcbiAgLy8gdGhlIGZpcnN0IGNvbnZlcnNhdGlvbiBvbiBsb2FkLCBvciB0aGUgbmV4dCBvbmUgYWZ0ZXIgYSBkZWxldGUsIGlzIGJvb2trZWVwaW5nXG4gIC8vIOKAlCBhZHZhbmNpbmcgdGhlcmUgd291bGQgbW92ZSB0aGUgdXNlciBzb21ld2hlcmUgdGhleSBkaWRuJ3QgYXNrIHRvIGdvLCBhbmQgdGhlXG4gIC8vIGhvc3Qgd291bGQgcmVmdXNlIGl0IGFueXdheSAobm8gZ2VzdHVyZSkuXG4gIC8vXG4gIC8vIFRoZSBob3N0IGlnbm9yZXMgYSByZXZlYWwgaXQgZG9lc24ndCBsaWtlLCBzbyB0aGlzIG5lZWRzIG5vIHN1Y2Nlc3MgaGFuZGxpbmc7XG4gIC8vIGl0IG9ubHkgc3dhbGxvd3MgdGhlIGF1dGhvcml6YXRpb24gcmVqZWN0aW9uIChhbiBvbGRlciBob3N0IGhhcyBubyBgcmV2ZWFsYFxuICAvLyBtZXRob2QsIHdoaWNoIG11c3QgZGVncmFkZSB0byB0b2RheSdzIGJlaGF2aW91ciByYXRoZXIgdGhhbiBhbiB1bmhhbmRsZWQgcmVqZWN0KS5cbiAgY29uc3Qgb3BlbkNvbnZlcnNhdGlvbiA9IHVzZUNhbGxiYWNrKChpZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWQoaWQpO1xuICAgIC8vIEEgdGFwIGlzIGFuIGV2ZW50LCBub3QgYSBzdGF0ZSB0cmFuc2l0aW9uOiBhbm5vdW5jZSBpdCBkaXJlY3RseSAoUjMtNjE2KSBzbyBhIHRhcFxuICAgIC8vIG9uIHRoZSBhbHJlYWR5LXNlbGVjdGVkIHJvdyBzdGlsbCBwb3N0cyDigJQgdGhlIGRlcml2ZWQtdmFsdWUgZWZmZWN0IGFib3ZlIG9ubHkgZmlyZXNcbiAgICAvLyB3aGVuIGBlZmZlY3RpdmVTZWxlY3RlZGAgY2hhbmdlcywgc28gdGhlIHJlLXRhcCBjYXNlIHdhcyBwcmV2aW91c2x5IHNpbGVudC5cbiAgICB2b2lkIHBvc3RUb1JlZ2lvbihTVEFHRV9SRUdJT04sIHNlbGVjdE1lc3NhZ2UoaWQpKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgdm9pZCByZXZlYWxSZWdpb24oU1RBR0VfUkVHSU9OKS5jYXRjaCgoKSA9PiB7fSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCByZWZyZXNoID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBpZiAoIXN0b3JlKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIHNldEl0ZW1zKGF3YWl0IHN0b3JlLmxpc3QoKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiB0cmFuc2llbnQgcmVhZCBmYWlsdXJlIOKAlCBrZWVwIHRoZSBsYXN0IGdvb2QgbGlzdCAqL1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIC8vIE9wZW4gdGhlIHN0b3JlIGFuZCBsaXN0LiBTZWxlY3Rpb24gaGFwcGVucyBpbiB0aGUgc2NvcGVkIGVmZmVjdCBiZWxvdywgc28gdGhlXG4gIC8vIHN0YWdlIGlzbid0IHNlZWRlZCB3aXRoIGFub3RoZXIgcmVwbydzIG5ld2VzdCBjb252ZXJzYXRpb24gKFIzLTQ3NSkuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGxpdmUgPSB0cnVlO1xuICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXdhaXQgb3BlbkNvbnZlcnNhdGlvblN0b3JlKCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzdG9yZVJlZi5jdXJyZW50ID0gc3RvcmU7XG4gICAgICAgIGNvbnN0IGxpc3QgPSBhd2FpdCBzdG9yZS5saXN0KCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzZXRJdGVtcyhsaXN0KTtcbiAgICAgICAgc2V0U3RvcmVFcnJvcihudWxsKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGxpdmUpIHNldFN0b3JlRXJyb3IoZGVzY3JpYmVTdG9yZUZhaWx1cmUoZSkpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaWYgKGxpdmUpIHNldFJlYWR5KHRydWUpO1xuICAgICAgfVxuICAgIH0pKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGxpdmUgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgLy8gS2VlcCB0aGUgbGlzdCBmcmVzaC4gQSBgY29udmVyc2F0aW9uLXVwZGF0ZWRgIG1lc3NhZ2UgbmFtZXMgT05FIGNvbnZlcnNhdGlvbixcbiAgLy8gc28gdGhlIGhhbmRsZXIgbG9hZHMgdGhhdCByb3cgYW5kIHBhdGNoZXMgaXQgaW4gcGxhY2UgKFIzLTYxMiAvIFItSVgtNCkg4oCUIGFcbiAgLy8gZnVsbCBgbGlzdCgpYCByZS1yZWFkcyBldmVyeSBjb252ZXJzYXRpb24gSlNPTiAoY2FwIDUwMCkgdG8gbGVhcm4gb25lIHJvdydzXG4gIC8vIHRpdGxlIGFuZCB0aW1lc3RhbXAgbW92ZWQuIGByZWZyZXNoKClgIHN0YXlzIGZvciB0aGUgZm9jdXMtcmVnYWluIHBhdGgsIHdoZXJlXG4gIC8vIHRoZXJlIGlzIG5vIG5hcnJvd2VyIHNpZ25hbDsgdGhlIG1vdW50IHBhdGggbGlzdHMgZGlyZWN0bHkgKGl0IG5lZWRzIHRoZVxuICAvLyBzdG9yZS1vcGVuIGVycm9yIGhhbmRsaW5nIHRvbykuXG4gIGNvbnN0IHBhdGNoT25lID0gdXNlQ2FsbGJhY2soYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzdG9yZSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb252ID0gYXdhaXQgc3RvcmUubG9hZChpZCk7XG4gICAgICAvLyBgbnVsbGAgPSBkZWxldGVkIGVsc2V3aGVyZSAob3IgY29ycnVwdCk6IHRoZSByb3cgZ29lcy5cbiAgICAgIHNldEl0ZW1zKChsKSA9PiAoY29udiA/IGFwcGx5Q29udmVyc2F0aW9uVXBkYXRlKGwsIG1ldGFPZihjb252KSkgOiBsLmZpbHRlcigoYykgPT4gYy5pZCAhPT0gaWQpKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBSZWFkIGZhaWx1cmUg4oCUIGtlZXAgdGhlIGxhc3QgZ29vZCBsaXN0LCB0aGUgc2FtZSByZXNvbHV0aW9uIGFzIHJlZnJlc2goKS5cbiAgICB9XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG9mZiA9IG9uUmVnaW9uTWVzc2FnZSgobSkgPT4ge1xuICAgICAgaWYgKGlzVXBkYXRlZChtLmRhdGEpKSB2b2lkIHBhdGNoT25lKG0uZGF0YS5pZCk7XG4gICAgICAvLyBUaGUgc3RhZ2UgbW91bnRlZCBhbmQgd2FudHMgdG8ga25vdyB3aGF0IGl0IHNob3VsZCBiZSBzaG93aW5nIChSMy0yNDMpLiBJdFxuICAgICAgLy8gbWF5IGhhdmUgbWlzc2VkIHRoZSBgc2VsZWN0LWNvbnZlcnNhdGlvbmAgZW50aXJlbHk6IG9uIG1vYmlsZSBpdCBkb2VzIG5vdFxuICAgICAgLy8gZXhpc3QgdW50aWwgdGhlIHJldmVhbCBwdXRzIGl0IG9uIHNjcmVlbiwgd2hpY2ggaGFwcGVucyBhZnRlciB0aGUgcG9zdC5cbiAgICAgIC8vIEFuc3dlcmluZyBoZXJlIGlzIHdoYXQgbWFrZXMgdGFwcGluZyBhbiBPTERFUiBjb252ZXJzYXRpb24gbGFuZCBvbiB0aGF0IG9uZVxuICAgICAgLy8gcmF0aGVyIHRoYW4gb24gdGhlIG5ld2VzdC5cbiAgICAgIGVsc2UgaWYgKGlzUmVxdWVzdFNlbGVjdGlvbihtLmRhdGEpICYmIHNlbGVjdGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgdm9pZCBwb3N0VG9SZWdpb24oU1RBR0VfUkVHSU9OLCBzZWxlY3RNZXNzYWdlKHNlbGVjdGVkUmVmLmN1cnJlbnQpKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3Qgb25Gb2N1cyA9ICgpID0+IHZvaWQgcmVmcmVzaCgpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNcIiwgb25Gb2N1cyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG9mZigpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJmb2N1c1wiLCBvbkZvY3VzKTtcbiAgICB9O1xuICB9LCBbcmVmcmVzaCwgcGF0Y2hPbmVdKTtcblxuICBjb25zdCBuZXdDb252ZXJzYXRpb24gPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIC8vIE5vIHN0b3JlIOKHkiB0aGUgYnV0dG9uIGNhbm5vdCB3b3JrLiBTYXkgd2h5IHJhdGhlciB0aGFuIGRvaW5nIG5vdGhpbmcuXG4gICAgaWYgKCFzdG9yZSkge1xuICAgICAgc2V0U3RvcmVFcnJvcigocHJldikgPT4gcHJldiA/PyBkZXNjcmliZVN0b3JlRmFpbHVyZShuZXcgRXJyb3IoXCJzZXR0aW5ncyB1bmF2YWlsYWJsZVwiKSkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgLy8gU3RhbXBlZCB3aXRoIHRoZSBsb2FkZWQgcmVwbyAoUjMtNDc1KSBzbyBpdCBzY29wZXMgY29ycmVjdGx5IGZyb20gYmlydGguXG4gICAgICBjb25zdCBjb252ID0gYXdhaXQgc3RvcmUuY3JlYXRlKHVuZGVmaW5lZCwgY3VycmVudFJlcG8pO1xuICAgICAgc2V0SXRlbXMoKGwpID0+IFttZXRhT2YoY29udiksIC4uLmxdKTtcbiAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICBvcGVuQ29udmVyc2F0aW9uKGNvbnYuaWQpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmVTdG9yZUZhaWx1cmUoZSkpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCByZW1vdmUgPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBpZiAoIXN0b3JlKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHN0b3JlLnJlbW92ZShpZCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gQSBkZWxldGUgdGhhdCBmYWlsZWQgbXVzdCBsZWF2ZSB0aGUgcm93IGluIHBsYWNlIGFuZCBzYXkgd2h5IChSLUlYLTMpOlxuICAgICAgLy8gZHJvcHBpbmcgaXQgYW55d2F5IHdvdWxkIHNob3cgYSBjaGFuZ2UgdGhhdCBkaWQgbm90IGhhcHBlbi4gU2FtZVxuICAgICAgLy8gZmFpbHVyZSBzdXJmYWNlIGFzIGNyZWF0ZS9zYXZlIGFib3ZlLlxuICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZVN0b3JlRmFpbHVyZShlKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEl0ZW1zKChsKSA9PiBsLmZpbHRlcigoYykgPT4gYy5pZCAhPT0gaWQpKTtcbiAgICBpZiAoc2VsZWN0ZWQgPT09IGlkKSBzZXRTZWxlY3RlZChudWxsKTsgLy8gdGhlIHNjb3BlZCBlZmZlY3QgcmUtc2VsZWN0c1xuICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNsXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImNsLWhkXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNsLXRpdGxlXCI+Q29udmVyc2F0aW9uczwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY2wtbmV3XCIgb25DbGljaz17KCkgPT4gdm9pZCBuZXdDb252ZXJzYXRpb24oKX0+XG4gICAgICAgICAgTmV3IGNvbnZlcnNhdGlvblxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7Y3VycmVudFJlcG8gJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJjbC1zY29wZVwiIHRpdGxlPVwiQ29udmVyc2F0aW9ucyBhcmUgc2NvcGVkIHRvIHRoZSByZXBvc2l0b3J5IGxvYWRlZCBpbiB0aGUgd29ya2JlbmNoLlwiPlxuICAgICAgICAgIHtjdXJyZW50UmVwb31cbiAgICAgICAgPC9wPlxuICAgICAgKX1cblxuICAgICAge3N0b3JlRXJyb3IgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJjbC1lbXB0eSBjbC1lcnJvclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICB7c3RvcmVFcnJvcn1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cblxuICAgICAge3JlYWR5ICYmICFzdG9yZUVycm9yICYmIG1pbmUubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2wtZW1wdHlcIj5ObyBjb252ZXJzYXRpb25zIGhlcmUgeWV0LiBTdGFydCBvbmUgd2l0aCDigJxOZXcgY29udmVyc2F0aW9u4oCdLjwvcD5cbiAgICAgICl9XG5cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJjbC1saXN0XCI+XG4gICAgICAgIHttaW5lLm1hcCgoYykgPT4gKFxuICAgICAgICAgIDxsaSBrZXk9e2MuaWR9IGNsYXNzTmFtZT17YGNsLXJvdyR7ZWZmZWN0aXZlU2VsZWN0ZWQgPT09IGMuaWQgPyBcIiBjbC1yb3ctYWN0aXZlXCIgOiBcIlwifWB9PlxuICAgICAgICAgICAgey8qIFIzLTYxMiDigJQgdGhlIG9wZW4gYWN0aW9uIGlzIGEgUkVBTCBidXR0b24gb3ZlciB0aGUgcm93J3MgbWFpblxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGEgcm93LWxldmVsIGJ1dHRvbiByb2xlIGNvbnRhaW5pbmcgdGhpcyBjb250cm9sIG1hZGUgdGhlXG4gICAgICAgICAgICAgICAgcm93J3MgbmFtZS1mcm9tLWNvbnRlbnQgYWJzb3JiIFwiRGVsZXRlIOKAplwiIGFuZCBnYXZlIHRoZSB0d29cbiAgICAgICAgICAgICAgICBjb250cm9scyBvbmUgYWN0aXZhdGlvbiBzdXJmYWNlIChXQ0FHIDQuMS4yLCB0d2ljZSkuIFNlbGVjdGVkXG4gICAgICAgICAgICAgICAgc3RhdGUgdHJhdmVscyB2aWEgYXJpYS1wcmVzc2VkIG9uIHRoZSBvcGVuIGNvbnRyb2wuICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2wtcm93LW9wZW5cIlxuICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2VmZmVjdGl2ZVNlbGVjdGVkID09PSBjLmlkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuQ29udmVyc2F0aW9uKGMuaWQpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1yb3ctdGl0bGVcIj57Yy50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNsLXJvdy10aW1lXCI+e3JlbFRpbWUoYy51cGRhdGVkQXQpfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2wtZGVsXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YERlbGV0ZSAke2MudGl0bGV9YH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCByZW1vdmUoYy5pZCl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIMOXXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG5cbiAgICAgIHsvKiBDb252ZXJzYXRpb25zIGJlbG9uZ2luZyB0byBPVEhFUiByZXBvc2l0b3JpZXMgKFIzLTQ3NSk6IHZpc2libGUgc28gdGhleSBhcmVcbiAgICAgICAgICBuZXZlciBsb3N0LCBidXQgbmV2ZXIgbWl4ZWQgaW50byB0aGUgbGlzdCBhYm92ZS4gT3BlbmluZyBvbmUgb2YgdGhlc2UgcmVwb3NcbiAgICAgICAgICBpbiBhIG5ldyB0YWIgbmVlZHMgYSBob3N0LW1lZGlhdGVkIGFmZm9yZGFuY2Ug4oCUIGEgdGFiIG9wZW5lZCBmcm9tIHRoaXNcbiAgICAgICAgICBzYW5kYm94ZWQgZnJhbWUgaW5oZXJpdHMgdGhlIHNhbmRib3ggKG9wYXF1ZSBvcmlnaW4sIG1lYXN1cmVkKSBhbmQgdGhlXG4gICAgICAgICAgd29ya2JlbmNoIGNhbm5vdCBydW4gaW4gaXQg4oCUIHNvIHVudGlsIHRoYXQgbGFuZHMgdGhlIHJvd3MgbmFtZSB0aGUgcmVwbyB0b1xuICAgICAgICAgIG9wZW4gcmF0aGVyIHRoYW4gcHJldGVuZGluZyBhIGxpbmsgd29ya3MuICovfVxuICAgICAge3JlYWR5ICYmIG90aGVycy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiY2wtb3RoZXJzXCI+XG4gICAgICAgICAgPHN1bW1hcnk+T3RoZXIgcmVwb3NpdG9yaWVzPC9zdW1tYXJ5PlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJjbC1vdGhlcnMtbGlzdFwiPlxuICAgICAgICAgICAge290aGVycy5tYXAoKGcpID0+IHtcbiAgICAgICAgICAgICAgLy8gUjMtNDc1IOKAlCB0aGUgY291bnQgbXVzdCBzYXkgd2hhdCBpdCBjb3VudHM6IGEgYmFyZSBkaWdpdCBoYXMgbm9cbiAgICAgICAgICAgICAgLy8gaG92ZXIgbGFiZWwgYW5kIGFubm91bmNlcyBhcyBhIGxvbmUgbnVtYmVyIHRvIGEgc2NyZWVuIHJlYWRlci5cbiAgICAgICAgICAgICAgLy8gVGhlIHJvdydzIG93biB0aXRsZSBzYXlzIHdoYXQgT1BFTklORyB0aGUgcmVwbyBkb2VzOyB0aGUgY291bnQnc1xuICAgICAgICAgICAgICAvLyBsYWJlbCBzYXlzIHdoYXQgdGhlIG51bWJlciBJUy4gKFRoZSBhY2Nlc3NpYmxlIHRleHQgaXNcbiAgICAgICAgICAgICAgLy8gdmlzdWFsbHktaGlkZGVuIHJlYWwgdGV4dCwgbm90IGFyaWEtbGFiZWwgb24gYSBnZW5lcmljIHNwYW4g4oCUXG4gICAgICAgICAgICAgIC8vIG5hbWluZyBpcyBwcm9oaWJpdGVkIG9uIHJvbGU9Z2VuZXJpYywgc28gYXJpYS1sYWJlbCB3b3VsZCBiZSBhXG4gICAgICAgICAgICAgIC8vIHBsYWNlYm8uKVxuICAgICAgICAgICAgICBjb25zdCBsYWJlbCA9IGNvdW50TGFiZWwoZyk7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICBrZXk9e2cucmVwb31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNsLW90aGVycy1yb3dcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2BPcGVuICR7Zy5yZXBvfSBvbiBpbW1lZGlhdGVseS5ydW4gdG8gc2VlIHRoZXNlIGNvbnZlcnNhdGlvbnMuYH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1vdGhlcnMtcmVwb1wiPntnLnJlcG99PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2wtb3RoZXJzLWNvdW50XCIgdGl0bGU9e2xhYmVsfT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2wtdmhcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj57Zy5jb3VudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGV0YWlscz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFjQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxrQkFBQSxHQUFBRixPQUFBO0FBRUEsSUFBQUcsa0JBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLG1CQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxnQkFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQ0FBLE9BQUE7QUFBZ0MsSUFBQU8sV0FBQSxHQUFBUCxPQUFBO0FBQUEsSUFBQVEsRUFBQSxHQUFBQyxZQUFBLElBdEJoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBV0EsU0FBU0MsT0FBT0EsQ0FBQ0MsRUFBVSxFQUFVO0VBQ25DLE1BQU1DLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxFQUFFRCxJQUFJLENBQUNFLEtBQUssQ0FBQyxDQUFDQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEdBQUdOLEVBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQztFQUMzRCxJQUFJQyxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sVUFBVTtFQUM3QixNQUFNTSxDQUFDLEdBQUdMLElBQUksQ0FBQ0UsS0FBSyxDQUFDSCxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQzVCLElBQUlNLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxHQUFHQSxDQUFDLE9BQU87RUFDOUIsTUFBTUMsQ0FBQyxHQUFHTixJQUFJLENBQUNFLEtBQUssQ0FBQ0csQ0FBQyxHQUFHLEVBQUUsQ0FBQztFQUM1QixJQUFJQyxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sR0FBR0EsQ0FBQyxPQUFPO0VBQzlCLE9BQU8sR0FBR04sSUFBSSxDQUFDRSxLQUFLLENBQUNJLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTztBQUNyQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxVQUFVQSxDQUFDQyxDQUFZLEVBQVU7RUFDeEMsT0FBTyxHQUFHQSxDQUFDLENBQUNDLEtBQUssSUFBSUQsQ0FBQyxDQUFDQyxLQUFLLEtBQUssQ0FBQyxHQUFHLGNBQWMsR0FBRyxlQUFlLE9BQU9ELENBQUMsQ0FBQ0UsSUFBSSxFQUFFO0FBQ3RGO0FBRWUsU0FBU0MsZ0JBQWdCQSxDQUFBLEVBQUc7RUFBQWhCLEVBQUE7RUFDekMsTUFBTWlCLFFBQVEsR0FBRyxJQUFBQyxhQUFNLEVBQTJCLElBQUksQ0FBQztFQUN2RCxNQUFNLENBQUNDLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFxQixFQUFFLENBQUM7RUFDMUQsTUFBTSxDQUFDQyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQzdELE1BQU0sQ0FBQ0csS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ3pDO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0ssVUFBVSxFQUFFQyxhQUFhLENBQUMsR0FBRyxJQUFBTixlQUFRLEVBQWdCLElBQUksQ0FBQzs7RUFFakU7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNTyxXQUFXLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDLEVBQUVDLEtBQUs7O0VBRXpDO0VBQ0E7RUFDQSxNQUFNO0lBQUVDLElBQUk7SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMscUNBQWtCLEVBQUNmLEtBQUssRUFBRVMsV0FBVyxDQUFDLEVBQUUsQ0FBQ1QsS0FBSyxFQUFFUyxXQUFXLENBQUMsQ0FBQzs7RUFFcEc7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTU8saUJBQWlCLEdBQUcsSUFBQUYsY0FBTyxFQUFDLE1BQU07SUFDdEMsSUFBSVgsUUFBUSxJQUFJUyxJQUFJLENBQUNLLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBS2hCLFFBQVEsQ0FBQyxFQUFFLE9BQU9BLFFBQVE7SUFDcEUsT0FBT1MsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFTyxFQUFFLElBQUksSUFBSTtFQUM1QixDQUFDLEVBQUUsQ0FBQ2hCLFFBQVEsRUFBRVMsSUFBSSxDQUFDLENBQUM7O0VBRXBCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQVEsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDSixpQkFBaUIsRUFBRTtJQUN4QixLQUFLLElBQUFLLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUUsSUFBQUMsOEJBQWEsRUFBQ1AsaUJBQWlCLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuRixDQUFDLEVBQUUsQ0FBQ1IsaUJBQWlCLENBQUMsQ0FBQzs7RUFFdkI7RUFDQTtFQUNBO0VBQ0EsTUFBTVMsV0FBVyxHQUFHLElBQUExQixhQUFNLEVBQWdCLElBQUksQ0FBQztFQUMvQyxJQUFBcUIsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RLLFdBQVcsQ0FBQ0MsT0FBTyxHQUFHVixpQkFBaUI7RUFDekMsQ0FBQyxFQUFFLENBQUNBLGlCQUFpQixDQUFDLENBQUM7O0VBRXZCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1XLGdCQUFnQixHQUFHLElBQUFDLGtCQUFXLEVBQUVULEVBQVUsSUFBSztJQUNuRGYsV0FBVyxDQUFDZSxFQUFFLENBQUM7SUFDZjtJQUNBO0lBQ0E7SUFDQSxLQUFLLElBQUFFLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUUsSUFBQUMsOEJBQWEsRUFBQ0osRUFBRSxDQUFDLENBQUMsQ0FBQ0ssS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDbEUsS0FBSyxJQUFBSyxpQkFBWSxFQUFDUCw2QkFBWSxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ2pELENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNTSxPQUFPLEdBQUcsSUFBQUYsa0JBQVcsRUFBQyxZQUFZO0lBQ3RDLE1BQU1HLEtBQUssR0FBR2pDLFFBQVEsQ0FBQzRCLE9BQU87SUFDOUIsSUFBSSxDQUFDSyxLQUFLLEVBQUU7SUFDWixJQUFJO01BQ0Y5QixRQUFRLENBQUMsTUFBTThCLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5QixDQUFDLENBQUMsTUFBTTtNQUNOO0lBQUE7RUFFSixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQSxJQUFBWixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJYSxJQUFJLEdBQUcsSUFBSTtJQUNmLEtBQUssQ0FBQyxZQUFZO01BQ2hCLElBQUk7UUFDRixNQUFNRixLQUFLLEdBQUcsTUFBTSxJQUFBRyx3Q0FBcUIsRUFBQyxDQUFDO1FBQzNDLElBQUksQ0FBQ0QsSUFBSSxFQUFFO1FBQ1huQyxRQUFRLENBQUM0QixPQUFPLEdBQUdLLEtBQUs7UUFDeEIsTUFBTUMsSUFBSSxHQUFHLE1BQU1ELEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDQyxJQUFJLEVBQUU7UUFDWGhDLFFBQVEsQ0FBQytCLElBQUksQ0FBQztRQUNkeEIsYUFBYSxDQUFDLElBQUksQ0FBQztNQUNyQixDQUFDLENBQUMsT0FBTzJCLENBQUMsRUFBRTtRQUNWLElBQUlGLElBQUksRUFBRXpCLGFBQWEsQ0FBQyxJQUFBNEIsZ0NBQW9CLEVBQUNELENBQUMsQ0FBQyxDQUFDO01BQ2xELENBQUMsU0FBUztRQUNSLElBQUlGLElBQUksRUFBRTNCLFFBQVEsQ0FBQyxJQUFJLENBQUM7TUFDMUI7SUFDRixDQUFDLEVBQUUsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYMkIsSUFBSSxHQUFHLEtBQUs7SUFDZCxDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNSSxRQUFRLEdBQUcsSUFBQVQsa0JBQVcsRUFBQyxNQUFPVCxFQUFVLElBQUs7SUFDakQsTUFBTVksS0FBSyxHQUFHakMsUUFBUSxDQUFDNEIsT0FBTztJQUM5QixJQUFJLENBQUNLLEtBQUssRUFBRTtJQUNaLElBQUk7TUFDRixNQUFNTyxJQUFJLEdBQUcsTUFBTVAsS0FBSyxDQUFDUSxJQUFJLENBQUNwQixFQUFFLENBQUM7TUFDakM7TUFDQWxCLFFBQVEsQ0FBRXVDLENBQUMsSUFBTUYsSUFBSSxHQUFHLElBQUFHLDJDQUF1QixFQUFDRCxDQUFDLEVBQUUsSUFBQUUseUJBQU0sRUFBQ0osSUFBSSxDQUFDLENBQUMsR0FBR0UsQ0FBQyxDQUFDRyxNQUFNLENBQUV6QixDQUFDLElBQUtBLENBQUMsQ0FBQ0MsRUFBRSxLQUFLQSxFQUFFLENBQUUsQ0FBQztJQUNuRyxDQUFDLENBQUMsTUFBTTtNQUNOO0lBQUE7RUFFSixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTXdCLEdBQUcsR0FBRyxJQUFBQyxvQkFBZSxFQUFFdEQsQ0FBQyxJQUFLO01BQ2pDLElBQUksSUFBQXVELDBCQUFTLEVBQUN2RCxDQUFDLENBQUN3RCxJQUFJLENBQUMsRUFBRSxLQUFLVixRQUFRLENBQUM5QyxDQUFDLENBQUN3RCxJQUFJLENBQUM1QixFQUFFLENBQUM7TUFDL0M7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUFBLEtBQ0ssSUFBSSxJQUFBNkIsbUNBQWtCLEVBQUN6RCxDQUFDLENBQUN3RCxJQUFJLENBQUMsSUFBSXRCLFdBQVcsQ0FBQ0MsT0FBTyxFQUFFO1FBQzFELEtBQUssSUFBQUwsaUJBQVksRUFBQ0MsNkJBQVksRUFBRSxJQUFBQyw4QkFBYSxFQUFDRSxXQUFXLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUNGLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQ3JGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsTUFBTXlCLE9BQU8sR0FBR0EsQ0FBQSxLQUFNLEtBQUtuQixPQUFPLENBQUMsQ0FBQztJQUNwQ29CLE1BQU0sQ0FBQ0MsZ0JBQWdCLENBQUMsT0FBTyxFQUFFRixPQUFPLENBQUM7SUFDekMsT0FBTyxNQUFNO01BQ1hMLEdBQUcsQ0FBQyxDQUFDO01BQ0xNLE1BQU0sQ0FBQ0UsbUJBQW1CLENBQUMsT0FBTyxFQUFFSCxPQUFPLENBQUM7SUFDOUMsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDbkIsT0FBTyxFQUFFTyxRQUFRLENBQUMsQ0FBQztFQUV2QixNQUFNZ0IsZUFBZSxHQUFHLE1BQUFBLENBQUEsS0FBWTtJQUNsQyxNQUFNdEIsS0FBSyxHQUFHakMsUUFBUSxDQUFDNEIsT0FBTztJQUM5QjtJQUNBLElBQUksQ0FBQ0ssS0FBSyxFQUFFO01BQ1Z2QixhQUFhLENBQUU4QyxJQUFJLElBQUtBLElBQUksSUFBSSxJQUFBbEIsZ0NBQW9CLEVBQUMsSUFBSW1CLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7TUFDeEY7SUFDRjtJQUNBLElBQUk7TUFDRjtNQUNBLE1BQU1qQixJQUFJLEdBQUcsTUFBTVAsS0FBSyxDQUFDeUIsTUFBTSxDQUFDQyxTQUFTLEVBQUVoRCxXQUFXLENBQUM7TUFDdkRSLFFBQVEsQ0FBRXVDLENBQUMsSUFBSyxDQUFDLElBQUFFLHlCQUFNLEVBQUNKLElBQUksQ0FBQyxFQUFFLEdBQUdFLENBQUMsQ0FBQyxDQUFDO01BQ3JDaEMsYUFBYSxDQUFDLElBQUksQ0FBQztNQUNuQm1CLGdCQUFnQixDQUFDVyxJQUFJLENBQUNuQixFQUFFLENBQUM7SUFDM0IsQ0FBQyxDQUFDLE9BQU9nQixDQUFDLEVBQUU7TUFDVjNCLGFBQWEsQ0FBQyxJQUFBNEIsZ0NBQW9CLEVBQUNELENBQUMsQ0FBQyxDQUFDO0lBQ3hDO0VBQ0YsQ0FBQztFQUVELE1BQU11QixNQUFNLEdBQUcsTUFBT3ZDLEVBQVUsSUFBSztJQUNuQyxNQUFNWSxLQUFLLEdBQUdqQyxRQUFRLENBQUM0QixPQUFPO0lBQzlCLElBQUksQ0FBQ0ssS0FBSyxFQUFFO0lBQ1osSUFBSTtNQUNGLE1BQU1BLEtBQUssQ0FBQzJCLE1BQU0sQ0FBQ3ZDLEVBQUUsQ0FBQztJQUN4QixDQUFDLENBQUMsT0FBT2dCLENBQUMsRUFBRTtNQUNWO01BQ0E7TUFDQTtNQUNBM0IsYUFBYSxDQUFDLElBQUE0QixnQ0FBb0IsRUFBQ0QsQ0FBQyxDQUFDLENBQUM7TUFDdEM7SUFDRjtJQUNBbEMsUUFBUSxDQUFFdUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNHLE1BQU0sQ0FBRXpCLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUtBLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLElBQUloQixRQUFRLEtBQUtnQixFQUFFLEVBQUVmLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3hDSSxhQUFhLENBQUMsSUFBSSxDQUFDO0VBQ3JCLENBQUM7RUFFRCxvQkFDRSxJQUFBNUIsV0FBQSxDQUFBK0UsSUFBQTtJQUFLQyxTQUFTLEVBQUMsSUFBSTtJQUFBQyxRQUFBLGdCQUNqQixJQUFBakYsV0FBQSxDQUFBK0UsSUFBQTtNQUFRQyxTQUFTLEVBQUMsT0FBTztNQUFBQyxRQUFBLGdCQUN2QixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtRQUFNRixTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLEVBQUM7TUFBYSxDQUFNLENBQUMsZUFDL0MsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7UUFBUUMsSUFBSSxFQUFDLFFBQVE7UUFBQ0gsU0FBUyxFQUFDLFFBQVE7UUFBQ0ksT0FBTyxFQUFFQSxDQUFBLEtBQU0sS0FBS1gsZUFBZSxDQUFDLENBQUU7UUFBQVEsUUFBQSxFQUFDO01BRWhGLENBQVEsQ0FBQztJQUFBLENBQ0gsQ0FBQyxFQUVScEQsV0FBVyxpQkFDVixJQUFBN0IsV0FBQSxDQUFBa0YsR0FBQTtNQUFHRixTQUFTLEVBQUMsVUFBVTtNQUFDSyxLQUFLLEVBQUMscUVBQXFFO01BQUFKLFFBQUEsRUFDaEdwRDtJQUFXLENBQ1gsQ0FDSixFQUVBRixVQUFVLGlCQUNULElBQUEzQixXQUFBLENBQUFrRixHQUFBO01BQUdGLFNBQVMsRUFBQyxtQkFBbUI7TUFBQ00sSUFBSSxFQUFDLFFBQVE7TUFBQUwsUUFBQSxFQUMzQ3REO0lBQVUsQ0FDVixDQUNKLEVBRUFGLEtBQUssSUFBSSxDQUFDRSxVQUFVLElBQUlLLElBQUksQ0FBQ3VELE1BQU0sS0FBSyxDQUFDLGlCQUN4QyxJQUFBdkYsV0FBQSxDQUFBa0YsR0FBQTtNQUFHRixTQUFTLEVBQUMsVUFBVTtNQUFBQyxRQUFBLEVBQUM7SUFBNkQsQ0FBRyxDQUN6RixlQUVELElBQUFqRixXQUFBLENBQUFrRixHQUFBO01BQUlGLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsRUFDcEJqRCxJQUFJLENBQUN3RCxHQUFHLENBQUVsRCxDQUFDLGlCQUNWLElBQUF0QyxXQUFBLENBQUErRSxJQUFBO1FBQWVDLFNBQVMsRUFBRSxTQUFTNUMsaUJBQWlCLEtBQUtFLENBQUMsQ0FBQ0MsRUFBRSxHQUFHLGdCQUFnQixHQUFHLEVBQUUsRUFBRztRQUFBMEMsUUFBQSxnQkFNdEYsSUFBQWpGLFdBQUEsQ0FBQStFLElBQUE7VUFDRUksSUFBSSxFQUFDLFFBQVE7VUFDYkgsU0FBUyxFQUFDLGFBQWE7VUFDdkIsZ0JBQWM1QyxpQkFBaUIsS0FBS0UsQ0FBQyxDQUFDQyxFQUFHO1VBQ3pDNkMsT0FBTyxFQUFFQSxDQUFBLEtBQU1yQyxnQkFBZ0IsQ0FBQ1QsQ0FBQyxDQUFDQyxFQUFFLENBQUU7VUFBQTBDLFFBQUEsZ0JBRXRDLElBQUFqRixXQUFBLENBQUFrRixHQUFBO1lBQU1GLFNBQVMsRUFBQyxjQUFjO1lBQUFDLFFBQUEsRUFBRTNDLENBQUMsQ0FBQytDO1VBQUssQ0FBTyxDQUFDLGVBQy9DLElBQUFyRixXQUFBLENBQUFrRixHQUFBO1lBQU1GLFNBQVMsRUFBQyxhQUFhO1lBQUFDLFFBQUEsRUFBRTlFLE9BQU8sQ0FBQ21DLENBQUMsQ0FBQ21ELFNBQVM7VUFBQyxDQUFPLENBQUM7UUFBQSxDQUNyRCxDQUFDLGVBQ1QsSUFBQXpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFDRUMsSUFBSSxFQUFDLFFBQVE7VUFDYkgsU0FBUyxFQUFDLFFBQVE7VUFDbEIsY0FBWSxVQUFVMUMsQ0FBQyxDQUFDK0MsS0FBSyxFQUFHO1VBQ2hDRCxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLTixNQUFNLENBQUN4QyxDQUFDLENBQUNDLEVBQUUsQ0FBRTtVQUFBMEMsUUFBQSxFQUNsQztRQUVELENBQVEsQ0FBQztNQUFBLEdBdEJGM0MsQ0FBQyxDQUFDQyxFQXVCUCxDQUNMO0lBQUMsQ0FDQSxDQUFDLEVBUUpkLEtBQUssSUFBSVEsTUFBTSxDQUFDc0QsTUFBTSxHQUFHLENBQUMsaUJBQ3pCLElBQUF2RixXQUFBLENBQUErRSxJQUFBO01BQVNDLFNBQVMsRUFBQyxXQUFXO01BQUFDLFFBQUEsZ0JBQzVCLElBQUFqRixXQUFBLENBQUFrRixHQUFBO1FBQUFELFFBQUEsRUFBUztNQUFrQixDQUFTLENBQUMsZUFDckMsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7UUFBSUYsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLEVBQzNCaEQsTUFBTSxDQUFDdUQsR0FBRyxDQUFFMUUsQ0FBQyxJQUFLO1VBQ2pCO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsTUFBTWlCLEtBQUssR0FBR2xCLFVBQVUsQ0FBQ0MsQ0FBQyxDQUFDO1VBQzNCLG9CQUNFLElBQUFkLFdBQUEsQ0FBQStFLElBQUE7WUFFRUMsU0FBUyxFQUFDLGVBQWU7WUFDekJLLEtBQUssRUFBRSxRQUFRdkUsQ0FBQyxDQUFDRSxJQUFJLGlEQUFrRDtZQUFBaUUsUUFBQSxnQkFFdkUsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7Y0FBTUYsU0FBUyxFQUFDLGdCQUFnQjtjQUFBQyxRQUFBLEVBQUVuRSxDQUFDLENBQUNFO1lBQUksQ0FBTyxDQUFDLGVBQ2hELElBQUFoQixXQUFBLENBQUErRSxJQUFBO2NBQU1DLFNBQVMsRUFBQyxpQkFBaUI7Y0FBQ0ssS0FBSyxFQUFFdEQsS0FBTTtjQUFBa0QsUUFBQSxnQkFDN0MsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7Z0JBQU1GLFNBQVMsRUFBQyxPQUFPO2dCQUFBQyxRQUFBLEVBQUVsRDtjQUFLLENBQU8sQ0FBQyxlQUN0QyxJQUFBL0IsV0FBQSxDQUFBa0YsR0FBQTtnQkFBTSxlQUFZLE1BQU07Z0JBQUFELFFBQUEsRUFBRW5FLENBQUMsQ0FBQ0M7Y0FBSyxDQUFPLENBQUM7WUFBQSxDQUNyQyxDQUFDO1VBQUEsR0FSRkQsQ0FBQyxDQUFDRSxJQVNMLENBQUM7UUFFVCxDQUFDO01BQUMsQ0FDQSxDQUFDO0lBQUEsQ0FDRSxDQUNWO0VBQUEsQ0FDRSxDQUFDO0FBRVY7QUFBQ2YsRUFBQSxDQTVRdUJnQixnQkFBZ0I7RUFBQSxRQWNsQmEsaUJBQVk7QUFBQTtBQUFBNEQsRUFBQSxHQWRWekUsZ0JBQWdCO0FBQUEsSUFBQXlFLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}