var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = AgentDemo;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
require("./AgentDemo.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The embedded-agent demo (§5.5 / §5.9). Shows the app's grant-filtered method
// catalog AS the agent's tool list, lets you "run" a tool through `invoke()`, and
// proves confinement (G12/T23): a method NOT in the catalog — named directly —
// still returns `forbidden` at the host gate. A real LLM agent would be handed
// `useCatalog()` verbatim as its tools; the principle is identical.
// A method we deliberately do NOT hold (this app's grant lacks spaces:admin), to
// show the gate refusing an off-catalog call — the agent can't escape its grant.
const OFF_CATALOG = "spaces:share";

// R3-612 — the delegated file, named once: the create (capFile relPath) and the
// remove (openFs().rm) must never drift apart on a rename.
const DEMO_FILE = "demo.txt";

// §5.6 L2 inter-app messaging (T19). This app's binding declares an ipc edge to
// panel.files ONLY (`ipc.to: ["panel.files"]`). Posting there is delivered (the
// file explorer declared it `accepts` us); posting anywhere else is refused at the
// host — the same two-sided-consent confinement the catalog gate shows above.
const FILES_REGION = "panel.files";
const NO_EDGE_REGION = "panel.spaces";
function AgentDemo() {
  _s();
  const catalog = (0, _sdk.useCatalog)();
  const [log, setLog] = (0, _react.useState)([]);
  const [running, setRunning] = (0, _react.useState)(null);
  const run = async name => {
    setRunning(name);
    try {
      const value = await (0, _sdk.invoke)(name, {});
      setLog(l => [{
        name,
        result: {
          kind: "ok",
          value
        }
      }, ...l]);
    } catch (e) {
      const code = e?.code ?? "error";
      setLog(l => [{
        name,
        result: {
          kind: "err",
          code,
          message: e?.message ?? String(e)
        }
      }, ...l]);
    } finally {
      setRunning(null);
    }
  };
  const inCatalog = name => catalog.some(m => m.name === name);

  // --- inter-app messaging (§5.6) ------------------------------------------
  const [path, setPath] = (0, _react.useState)("/README.md");
  const [ipcLog, setIpcLog] = (0, _react.useState)([]);
  const [posting, setPosting] = (0, _react.useState)(null);

  // --- task invocation (§5.7): invoke another app, get a typed result back ------
  const [color, setColor] = (0, _react.useState)("#3b82f6");
  const [picking, setPicking] = (0, _react.useState)(false);
  const [pickNote, setPickNote] = (0, _react.useState)(null);
  const pickColor = async () => {
    setPicking(true);
    setPickNote(null);
    try {
      const res = await (0, _sdk.invokeTask)("pick-color", {
        initial: color
      });
      if (res?.color) setColor(res.color);
    } catch (e) {
      const code = e?.code ?? "error";
      // `cancelled` is a normal outcome (user dismissed the overlay), not an error.
      // `forbidden` is expected when this demo runs OUTSIDE the agents activity:
      // `task:invoke` is elevated and conferred by the panel.agent/stage bindings,
      // and no consent path exists yet for a plain capability on a URL-loaded app
      // (boot consent covers mounts+net:fetch; M1 pre-auth validates but does not
      // mint plain caps — R3-233). Say so instead of leaving a bare code.
      setPickNote(code === "cancelled" ? "cancelled" : code === "forbidden" ? "forbidden — task:invoke is conferred by the agents-activity bindings; the standalone copy of this demo cannot acquire it (no consent path for plain capabilities yet)" : code);
    } finally {
      setPicking(false);
    }
  };

  // --- M2 attenuated delegation (§8.15): hand a callee a CAPABILITY, narrowed ----
  // The R3-43 drill-2 fixture. `probe` is provided by an app that declares a REQUIRED
  // `net:fetch` host; the host mints it the INTERSECTION of that and what this app
  // holds, never the union. The callee then spends it and reports what it could and
  // could not reach — so a grant that was minted but not honoured, or honoured but not
  // attenuated, is distinguishable from a correct one.
  const [probing, setProbing] = (0, _react.useState)(false);
  const [probeNote, setProbeNote] = (0, _react.useState)(null);
  const runProbe = async () => {
    setProbing(true);
    setProbeNote(null);
    try {
      const res = await (0, _sdk.invokeTask)("probe", {
        label: "R3-43 drill 2"
      });
      // Report the PASS condition explicitly rather than dumping the payload: the
      // delegated host must be reachable AND the undeclared one must not be. Naming
      // which half failed is the difference between a drill and a shrug.
      const ok = res?.declaredHostOk && !res?.undeclaredHostOk;
      setProbeNote(ok ? `delegated + attenuated ✓ (declared ${res.declaredDetail}, undeclared ${res.undeclaredDetail})` : `UNEXPECTED — declared ${res?.declaredHostOk ? "reachable" : "blocked"} (${res?.declaredDetail}), ` + `undeclared ${res?.undeclaredHostOk ? "REACHABLE — not attenuated" : "blocked"} (${res?.undeclaredDetail})`);
    } catch (e) {
      const code = e?.code ?? "error";
      // `consent-required` is the NEGATIVE leg of the drill, not a failure: it is what
      // must happen when this app holds no net:fetch covering the callee's host.
      setProbeNote(code === "cancelled" ? "cancelled" : code === "consent-required" ? "consent-required — the negative leg: this app holds no net:fetch covering the callee's declared host, so nothing was minted and no overlay opened" : code === "forbidden" ? "forbidden — task:invoke is conferred by the agents-activity bindings" : code);
    } finally {
      setProbing(false);
    }
  };

  // --- file delegation (§5.7/§8.7): hand a callee a file from MY OWN space -------
  const [editing, setEditing] = (0, _react.useState)(false);
  const [editNote, setEditNote] = (0, _react.useState)(null);
  const editFile = async () => {
    setEditing(true);
    setEditNote(null);
    try {
      // Open this app's own per-user settings (a private ~/.config-style mount),
      // then delegate ONE file in it to the bound edit-file app — the host mints an
      // attenuated chroot; this app never sees the editor's code, only the typed
      // { saved } result.
      const settings = await (0, _sdk.openSettings)();
      const res = await (0, _sdk.invokeTask)("edit-file", {
        file: (0, _sdk.capFile)({
          mountId: settings.id ?? settings.path,
          relPath: DEMO_FILE
        }, {
          mode: "rw"
        })
      });
      setEditNote(res?.saved ? `saved ${DEMO_FILE} to your settings ✓` : "done");
    } catch (e) {
      const code = e?.code ?? "error";
      setEditNote(code === "cancelled" ? "cancelled" : code === "auth-required" ? "sign in to use a space" : code === "forbidden" ? "forbidden — task:invoke is conferred by the agents-activity bindings; the standalone copy of this demo cannot acquire it (no consent path for plain capabilities yet)" : code);
    } finally {
      setEditing(false);
    }
  };

  // R3-612 / R-IX-5 — where a thing can be created it can be removed: this control
  // created demo.txt in the settings mount, so the SAME mount takes it back. The
  // typed `FsError` codes surface verbatim — a read-only mount's refusal is the
  // honest answer, never a fake success.
  const [removing, setRemoving] = (0, _react.useState)(false);
  const removeDemoFile = async () => {
    setRemoving(true);
    setEditNote(null);
    try {
      const settings = await (0, _sdk.openSettings)();
      await (0, _sdk.openFs)(settings).rm(DEMO_FILE);
      setEditNote(`removed ${DEMO_FILE} from your settings`);
    } catch (e) {
      const code = e?.code ?? "error";
      setEditNote(code === "cancelled" ? "cancelled" : code === "auth-required" ? "sign in to use a space" : code === "forbidden" ? "forbidden — this app cannot remove from the settings mount" : code);
    } finally {
      setRemoving(false);
    }
  };
  const post = async (to, data) => {
    setPosting(to);
    try {
      await (0, _sdk.postToRegion)(to, data);
      setIpcLog(l => [{
        to,
        result: {
          kind: "ok",
          value: "delivered"
        }
      }, ...l]);
    } catch (e) {
      const code = e?.code ?? "error";
      setIpcLog(l => [{
        to,
        result: {
          kind: "err",
          code,
          message: e?.message ?? String(e)
        }
      }, ...l]);
    } finally {
      setPosting(null);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ad",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ad-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ad-title",
        children: "Agent tools"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "ad-sub",
        children: [catalog.length, " in this app's catalog"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ad-tools",
      children: catalog.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "ad-tool",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          className: "ad-name",
          children: m.name
        }), m.stream && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-badge",
          children: "stream"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: running === m.name || m.stream,
          title: m.stream ? "streaming — use invokeStream" : `requires ${m.capability}`,
          onClick: () => run(m.name),
          children: running === m.name ? "Running…" : "Run"
        })]
      }, m.name))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Confinement check (G12)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: OFF_CATALOG
        }), " is ", inCatalog(OFF_CATALOG) ? "in" : "NOT in", " this app's catalog. Calling it anyway should be refused by the host gate:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ad-run ad-danger",
        disabled: running === OFF_CATALOG,
        onClick: () => run(OFF_CATALOG),
        children: running === OFF_CATALOG ? "Trying…" : `Try ${OFF_CATALOG}`
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Message another panel (\xA75.6, T19)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["This app declares an ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "ipc"
        }), " edge to ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: FILES_REGION
        }), " only. Ask the file explorer to reveal a path \u2014 it\u2019ll show the message with a host-attached (unspoofable) ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "from"
        }), ":"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ad-ipc-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          className: "ad-ipc-input",
          value: path,
          onChange: e => setPath(e.target.value),
          "aria-label": "Path to reveal"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: posting === FILES_REGION,
          onClick: () => post(FILES_REGION, {
            reveal: path
          }),
          children: posting === FILES_REGION ? "Sending…" : "Reveal in Files"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["Posting to a region this app declared no edge to (", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: NO_EDGE_REGION
        }), ") is refused by the host \u2014 neither side opened it:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ad-run ad-danger",
        disabled: posting === NO_EDGE_REGION,
        onClick: () => post(NO_EDGE_REGION, {
          reveal: path
        }),
        children: posting === NO_EDGE_REGION ? "Sending…" : `Try messaging ${NO_EDGE_REGION}`
      }), ipcLog.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "ad-log",
        children: ipcLog.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
          className: `ad-logline ${e.result.kind}`,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
            children: e.to
          }), " \u2192", " ", e.result.kind === "ok" ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ad-ok",
            children: "delivered"
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ad-err",
            children: e.result.code
          })]
        }, i))
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Invoke another app (\xA75.7, task contract)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["A tool can call ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "pick-color"
        }), " and get a typed color back. The host loads the user's bound picker in an overlay, the picker returns a value, and this app never sees the picker's code or grants \u2014 just the result:"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ad-ipc-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-color-chip",
          style: {
            background: color
          },
          "aria-label": `color ${color}`
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          className: "ad-color-val",
          children: color
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: picking,
          onClick: pickColor,
          children: picking ? "Picking…" : "Pick a color"
        })]
      }), pickNote && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["invokeTask \u2192 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: pickNote
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Delegate a capability, attenuated (\xA78.15 / M2)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["Invoke an app that ", /*#__PURE__*/(0, _jsxRuntime.jsx)("em", {
          children: "requires"
        }), " a ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "net:fetch"
        }), " host. The host mints it the intersection with what this app holds \u2014 never the union \u2014 and the callee spends it, reporting what it could and could not reach. It also probes a host it never declared: ", /*#__PURE__*/(0, _jsxRuntime.jsx)("em", {
          children: "blocked"
        }), " there is the proof the grant was attenuated rather than inherited."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ad-run",
        disabled: probing,
        onClick: runProbe,
        children: probing ? "Probing…" : "Run the delegation probe"
      }), probeNote && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["invokeTask \u2192 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: probeNote
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ad-escape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ad-escape-h",
        children: "Delegate a file to another app (\xA75.7/\xA78.7)"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: ["Hand the ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "edit-file"
        }), " app ONE file from your space. The host mints an attenuated, task-scoped chroot \u2014 the editor can name nothing else, and a read-only delegation is a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: "EROFS"
        }), " wall. Your grant narrows; it never amplifies (G7):"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ad-escape-actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: editing || removing,
          onClick: editFile,
          children: editing ? "Editing…" : `Edit ${DEMO_FILE} in my space`
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ad-run",
          disabled: editing || removing,
          onClick: () => void removeDemoFile(),
          children: removing ? "Removing…" : `Remove ${DEMO_FILE}`
        })]
      }), editNote && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "ad-escape-sub",
        children: [DEMO_FILE, " \u2192 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: editNote
        })]
      })]
    }), log.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ad-log",
      children: log.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: `ad-logline ${e.result.kind}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: e.name
        }), " \u2192", " ", e.result.kind === "ok" ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-ok",
          children: "ok"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ad-err",
          children: e.result.code
        })]
      }, i))
    })]
  });
}
_s(AgentDemo, "s7BVTc50QpREhEa+YfxX0R6L+Dw=", false, function () {
  return [_sdk.useCatalog];
});
_c = AgentDemo;
var _c;
$RefreshReg$(_c, "AgentDemo");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJPRkZfQ0FUQUxPRyIsIkRFTU9fRklMRSIsIkZJTEVTX1JFR0lPTiIsIk5PX0VER0VfUkVHSU9OIiwiQWdlbnREZW1vIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJsb2ciLCJzZXRMb2ciLCJ1c2VTdGF0ZSIsInJ1bm5pbmciLCJzZXRSdW5uaW5nIiwicnVuIiwibmFtZSIsInZhbHVlIiwiaW52b2tlIiwibCIsInJlc3VsdCIsImtpbmQiLCJlIiwiY29kZSIsIm1lc3NhZ2UiLCJTdHJpbmciLCJpbkNhdGFsb2ciLCJzb21lIiwibSIsInBhdGgiLCJzZXRQYXRoIiwiaXBjTG9nIiwic2V0SXBjTG9nIiwicG9zdGluZyIsInNldFBvc3RpbmciLCJjb2xvciIsInNldENvbG9yIiwicGlja2luZyIsInNldFBpY2tpbmciLCJwaWNrTm90ZSIsInNldFBpY2tOb3RlIiwicGlja0NvbG9yIiwicmVzIiwiaW52b2tlVGFzayIsImluaXRpYWwiLCJwcm9iaW5nIiwic2V0UHJvYmluZyIsInByb2JlTm90ZSIsInNldFByb2JlTm90ZSIsInJ1blByb2JlIiwibGFiZWwiLCJvayIsImRlY2xhcmVkSG9zdE9rIiwidW5kZWNsYXJlZEhvc3RPayIsImRlY2xhcmVkRGV0YWlsIiwidW5kZWNsYXJlZERldGFpbCIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwiZWRpdE5vdGUiLCJzZXRFZGl0Tm90ZSIsImVkaXRGaWxlIiwic2V0dGluZ3MiLCJvcGVuU2V0dGluZ3MiLCJmaWxlIiwiY2FwRmlsZSIsIm1vdW50SWQiLCJpZCIsInJlbFBhdGgiLCJtb2RlIiwic2F2ZWQiLCJyZW1vdmluZyIsInNldFJlbW92aW5nIiwicmVtb3ZlRGVtb0ZpbGUiLCJvcGVuRnMiLCJybSIsInBvc3QiLCJ0byIsImRhdGEiLCJwb3N0VG9SZWdpb24iLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJsZW5ndGgiLCJtYXAiLCJzdHJlYW0iLCJ0eXBlIiwiZGlzYWJsZWQiLCJ0aXRsZSIsImNhcGFiaWxpdHkiLCJvbkNsaWNrIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJyZXZlYWwiLCJpIiwic3R5bGUiLCJiYWNrZ3JvdW5kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBZ2VudERlbW8udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlbWJlZGRlZC1hZ2VudCBkZW1vICjCpzUuNSAvIMKnNS45KS4gU2hvd3MgdGhlIGFwcCdzIGdyYW50LWZpbHRlcmVkIG1ldGhvZFxuLy8gY2F0YWxvZyBBUyB0aGUgYWdlbnQncyB0b29sIGxpc3QsIGxldHMgeW91IFwicnVuXCIgYSB0b29sIHRocm91Z2ggYGludm9rZSgpYCwgYW5kXG4vLyBwcm92ZXMgY29uZmluZW1lbnQgKEcxMi9UMjMpOiBhIG1ldGhvZCBOT1QgaW4gdGhlIGNhdGFsb2cg4oCUIG5hbWVkIGRpcmVjdGx5IOKAlFxuLy8gc3RpbGwgcmV0dXJucyBgZm9yYmlkZGVuYCBhdCB0aGUgaG9zdCBnYXRlLiBBIHJlYWwgTExNIGFnZW50IHdvdWxkIGJlIGhhbmRlZFxuLy8gYHVzZUNhdGFsb2coKWAgdmVyYmF0aW0gYXMgaXRzIHRvb2xzOyB0aGUgcHJpbmNpcGxlIGlzIGlkZW50aWNhbC5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICB1c2VDYXRhbG9nLFxuICBpbnZva2UsXG4gIHBvc3RUb1JlZ2lvbixcbiAgaW52b2tlVGFzayxcbiAgY2FwRmlsZSxcbiAgb3BlbkZzLFxuICBvcGVuU2V0dGluZ3MsXG4gIHR5cGUgQXBpTWV0aG9kLFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCBcIi4vQWdlbnREZW1vLmNzc1wiO1xuXG4vLyBBIG1ldGhvZCB3ZSBkZWxpYmVyYXRlbHkgZG8gTk9UIGhvbGQgKHRoaXMgYXBwJ3MgZ3JhbnQgbGFja3Mgc3BhY2VzOmFkbWluKSwgdG9cbi8vIHNob3cgdGhlIGdhdGUgcmVmdXNpbmcgYW4gb2ZmLWNhdGFsb2cgY2FsbCDigJQgdGhlIGFnZW50IGNhbid0IGVzY2FwZSBpdHMgZ3JhbnQuXG5jb25zdCBPRkZfQ0FUQUxPRyA9IFwic3BhY2VzOnNoYXJlXCI7XG5cbi8vIFIzLTYxMiDigJQgdGhlIGRlbGVnYXRlZCBmaWxlLCBuYW1lZCBvbmNlOiB0aGUgY3JlYXRlIChjYXBGaWxlIHJlbFBhdGgpIGFuZCB0aGVcbi8vIHJlbW92ZSAob3BlbkZzKCkucm0pIG11c3QgbmV2ZXIgZHJpZnQgYXBhcnQgb24gYSByZW5hbWUuXG5jb25zdCBERU1PX0ZJTEUgPSBcImRlbW8udHh0XCI7XG5cbi8vIMKnNS42IEwyIGludGVyLWFwcCBtZXNzYWdpbmcgKFQxOSkuIFRoaXMgYXBwJ3MgYmluZGluZyBkZWNsYXJlcyBhbiBpcGMgZWRnZSB0b1xuLy8gcGFuZWwuZmlsZXMgT05MWSAoYGlwYy50bzogW1wicGFuZWwuZmlsZXNcIl1gKS4gUG9zdGluZyB0aGVyZSBpcyBkZWxpdmVyZWQgKHRoZVxuLy8gZmlsZSBleHBsb3JlciBkZWNsYXJlZCBpdCBgYWNjZXB0c2AgdXMpOyBwb3N0aW5nIGFueXdoZXJlIGVsc2UgaXMgcmVmdXNlZCBhdCB0aGVcbi8vIGhvc3Qg4oCUIHRoZSBzYW1lIHR3by1zaWRlZC1jb25zZW50IGNvbmZpbmVtZW50IHRoZSBjYXRhbG9nIGdhdGUgc2hvd3MgYWJvdmUuXG5jb25zdCBGSUxFU19SRUdJT04gPSBcInBhbmVsLmZpbGVzXCI7XG5jb25zdCBOT19FREdFX1JFR0lPTiA9IFwicGFuZWwuc3BhY2VzXCI7XG5cbnR5cGUgUmVzdWx0ID0geyBraW5kOiBcIm9rXCI7IHZhbHVlOiB1bmtub3duIH0gfCB7IGtpbmQ6IFwiZXJyXCI7IGNvZGU6IHN0cmluZzsgbWVzc2FnZTogc3RyaW5nIH07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFnZW50RGVtbygpIHtcbiAgY29uc3QgY2F0YWxvZyA9IHVzZUNhdGFsb2coKTtcbiAgY29uc3QgW2xvZywgc2V0TG9nXSA9IHVzZVN0YXRlPEFycmF5PHsgbmFtZTogc3RyaW5nOyByZXN1bHQ6IFJlc3VsdCB9Pj4oW10pO1xuICBjb25zdCBbcnVubmluZywgc2V0UnVubmluZ10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBydW4gPSBhc3luYyAobmFtZTogc3RyaW5nKSA9PiB7XG4gICAgc2V0UnVubmluZyhuYW1lKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBpbnZva2UobmFtZSwge30pO1xuICAgICAgc2V0TG9nKChsKSA9PiBbeyBuYW1lLCByZXN1bHQ6IHsga2luZDogXCJva1wiLCB2YWx1ZSB9IH0sIC4uLmxdKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIHNldExvZygobCkgPT4gW1xuICAgICAgICB7IG5hbWUsIHJlc3VsdDogeyBraW5kOiBcImVyclwiLCBjb2RlLCBtZXNzYWdlOiAoZSBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gU3RyaW5nKGUpIH0gfSxcbiAgICAgICAgLi4ubCxcbiAgICAgIF0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRSdW5uaW5nKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBpbkNhdGFsb2cgPSAobmFtZTogc3RyaW5nKSA9PiBjYXRhbG9nLnNvbWUoKG06IEFwaU1ldGhvZCkgPT4gbS5uYW1lID09PSBuYW1lKTtcblxuICAvLyAtLS0gaW50ZXItYXBwIG1lc3NhZ2luZyAowqc1LjYpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBbcGF0aCwgc2V0UGF0aF0gPSB1c2VTdGF0ZShcIi9SRUFETUUubWRcIik7XG4gIGNvbnN0IFtpcGNMb2csIHNldElwY0xvZ10gPSB1c2VTdGF0ZTxBcnJheTx7IHRvOiBzdHJpbmc7IHJlc3VsdDogUmVzdWx0IH0+PihbXSk7XG4gIGNvbnN0IFtwb3N0aW5nLCBzZXRQb3N0aW5nXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIC0tLSB0YXNrIGludm9jYXRpb24gKMKnNS43KTogaW52b2tlIGFub3RoZXIgYXBwLCBnZXQgYSB0eXBlZCByZXN1bHQgYmFjayAtLS0tLS1cbiAgY29uc3QgW2NvbG9yLCBzZXRDb2xvcl0gPSB1c2VTdGF0ZShcIiMzYjgyZjZcIik7XG4gIGNvbnN0IFtwaWNraW5nLCBzZXRQaWNraW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BpY2tOb3RlLCBzZXRQaWNrTm90ZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBwaWNrQ29sb3IgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0UGlja2luZyh0cnVlKTtcbiAgICBzZXRQaWNrTm90ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgaW52b2tlVGFzazx7IGNvbG9yOiBzdHJpbmcgfT4oXCJwaWNrLWNvbG9yXCIsIHsgaW5pdGlhbDogY29sb3IgfSk7XG4gICAgICBpZiAocmVzPy5jb2xvcikgc2V0Q29sb3IocmVzLmNvbG9yKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIC8vIGBjYW5jZWxsZWRgIGlzIGEgbm9ybWFsIG91dGNvbWUgKHVzZXIgZGlzbWlzc2VkIHRoZSBvdmVybGF5KSwgbm90IGFuIGVycm9yLlxuICAgICAgLy8gYGZvcmJpZGRlbmAgaXMgZXhwZWN0ZWQgd2hlbiB0aGlzIGRlbW8gcnVucyBPVVRTSURFIHRoZSBhZ2VudHMgYWN0aXZpdHk6XG4gICAgICAvLyBgdGFzazppbnZva2VgIGlzIGVsZXZhdGVkIGFuZCBjb25mZXJyZWQgYnkgdGhlIHBhbmVsLmFnZW50L3N0YWdlIGJpbmRpbmdzLFxuICAgICAgLy8gYW5kIG5vIGNvbnNlbnQgcGF0aCBleGlzdHMgeWV0IGZvciBhIHBsYWluIGNhcGFiaWxpdHkgb24gYSBVUkwtbG9hZGVkIGFwcFxuICAgICAgLy8gKGJvb3QgY29uc2VudCBjb3ZlcnMgbW91bnRzK25ldDpmZXRjaDsgTTEgcHJlLWF1dGggdmFsaWRhdGVzIGJ1dCBkb2VzIG5vdFxuICAgICAgLy8gbWludCBwbGFpbiBjYXBzIOKAlCBSMy0yMzMpLiBTYXkgc28gaW5zdGVhZCBvZiBsZWF2aW5nIGEgYmFyZSBjb2RlLlxuICAgICAgc2V0UGlja05vdGUoXG4gICAgICAgIGNvZGUgPT09IFwiY2FuY2VsbGVkXCJcbiAgICAgICAgICA/IFwiY2FuY2VsbGVkXCJcbiAgICAgICAgICA6IGNvZGUgPT09IFwiZm9yYmlkZGVuXCJcbiAgICAgICAgICAgID8gXCJmb3JiaWRkZW4g4oCUIHRhc2s6aW52b2tlIGlzIGNvbmZlcnJlZCBieSB0aGUgYWdlbnRzLWFjdGl2aXR5IGJpbmRpbmdzOyB0aGUgc3RhbmRhbG9uZSBjb3B5IG9mIHRoaXMgZGVtbyBjYW5ub3QgYWNxdWlyZSBpdCAobm8gY29uc2VudCBwYXRoIGZvciBwbGFpbiBjYXBhYmlsaXRpZXMgeWV0KVwiXG4gICAgICAgICAgICA6IGNvZGUsXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRQaWNraW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tIE0yIGF0dGVudWF0ZWQgZGVsZWdhdGlvbiAowqc4LjE1KTogaGFuZCBhIGNhbGxlZSBhIENBUEFCSUxJVFksIG5hcnJvd2VkIC0tLS1cbiAgLy8gVGhlIFIzLTQzIGRyaWxsLTIgZml4dHVyZS4gYHByb2JlYCBpcyBwcm92aWRlZCBieSBhbiBhcHAgdGhhdCBkZWNsYXJlcyBhIFJFUVVJUkVEXG4gIC8vIGBuZXQ6ZmV0Y2hgIGhvc3Q7IHRoZSBob3N0IG1pbnRzIGl0IHRoZSBJTlRFUlNFQ1RJT04gb2YgdGhhdCBhbmQgd2hhdCB0aGlzIGFwcFxuICAvLyBob2xkcywgbmV2ZXIgdGhlIHVuaW9uLiBUaGUgY2FsbGVlIHRoZW4gc3BlbmRzIGl0IGFuZCByZXBvcnRzIHdoYXQgaXQgY291bGQgYW5kXG4gIC8vIGNvdWxkIG5vdCByZWFjaCDigJQgc28gYSBncmFudCB0aGF0IHdhcyBtaW50ZWQgYnV0IG5vdCBob25vdXJlZCwgb3IgaG9ub3VyZWQgYnV0IG5vdFxuICAvLyBhdHRlbnVhdGVkLCBpcyBkaXN0aW5ndWlzaGFibGUgZnJvbSBhIGNvcnJlY3Qgb25lLlxuICBjb25zdCBbcHJvYmluZywgc2V0UHJvYmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtwcm9iZU5vdGUsIHNldFByb2JlTm90ZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBydW5Qcm9iZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRQcm9iaW5nKHRydWUpO1xuICAgIHNldFByb2JlTm90ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgaW52b2tlVGFzazx7XG4gICAgICAgIHByb2JlZDogYm9vbGVhbjtcbiAgICAgICAgZGVjbGFyZWRIb3N0T2s6IGJvb2xlYW47XG4gICAgICAgIGRlY2xhcmVkRGV0YWlsOiBzdHJpbmc7XG4gICAgICAgIHVuZGVjbGFyZWRIb3N0T2s6IGJvb2xlYW47XG4gICAgICAgIHVuZGVjbGFyZWREZXRhaWw6IHN0cmluZztcbiAgICAgIH0+KFwicHJvYmVcIiwgeyBsYWJlbDogXCJSMy00MyBkcmlsbCAyXCIgfSk7XG4gICAgICAvLyBSZXBvcnQgdGhlIFBBU1MgY29uZGl0aW9uIGV4cGxpY2l0bHkgcmF0aGVyIHRoYW4gZHVtcGluZyB0aGUgcGF5bG9hZDogdGhlXG4gICAgICAvLyBkZWxlZ2F0ZWQgaG9zdCBtdXN0IGJlIHJlYWNoYWJsZSBBTkQgdGhlIHVuZGVjbGFyZWQgb25lIG11c3Qgbm90IGJlLiBOYW1pbmdcbiAgICAgIC8vIHdoaWNoIGhhbGYgZmFpbGVkIGlzIHRoZSBkaWZmZXJlbmNlIGJldHdlZW4gYSBkcmlsbCBhbmQgYSBzaHJ1Zy5cbiAgICAgIGNvbnN0IG9rID0gcmVzPy5kZWNsYXJlZEhvc3RPayAmJiAhcmVzPy51bmRlY2xhcmVkSG9zdE9rO1xuICAgICAgc2V0UHJvYmVOb3RlKFxuICAgICAgICBva1xuICAgICAgICAgID8gYGRlbGVnYXRlZCArIGF0dGVudWF0ZWQg4pyTIChkZWNsYXJlZCAke3Jlcy5kZWNsYXJlZERldGFpbH0sIHVuZGVjbGFyZWQgJHtyZXMudW5kZWNsYXJlZERldGFpbH0pYFxuICAgICAgICAgIDogYFVORVhQRUNURUQg4oCUIGRlY2xhcmVkICR7cmVzPy5kZWNsYXJlZEhvc3RPayA/IFwicmVhY2hhYmxlXCIgOiBcImJsb2NrZWRcIn0gKCR7cmVzPy5kZWNsYXJlZERldGFpbH0pLCBgICtcbiAgICAgICAgICAgIGB1bmRlY2xhcmVkICR7cmVzPy51bmRlY2xhcmVkSG9zdE9rID8gXCJSRUFDSEFCTEUg4oCUIG5vdCBhdHRlbnVhdGVkXCIgOiBcImJsb2NrZWRcIn0gKCR7cmVzPy51bmRlY2xhcmVkRGV0YWlsfSlgLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwiZXJyb3JcIjtcbiAgICAgIC8vIGBjb25zZW50LXJlcXVpcmVkYCBpcyB0aGUgTkVHQVRJVkUgbGVnIG9mIHRoZSBkcmlsbCwgbm90IGEgZmFpbHVyZTogaXQgaXMgd2hhdFxuICAgICAgLy8gbXVzdCBoYXBwZW4gd2hlbiB0aGlzIGFwcCBob2xkcyBubyBuZXQ6ZmV0Y2ggY292ZXJpbmcgdGhlIGNhbGxlZSdzIGhvc3QuXG4gICAgICBzZXRQcm9iZU5vdGUoXG4gICAgICAgIGNvZGUgPT09IFwiY2FuY2VsbGVkXCJcbiAgICAgICAgICA/IFwiY2FuY2VsbGVkXCJcbiAgICAgICAgICA6IGNvZGUgPT09IFwiY29uc2VudC1yZXF1aXJlZFwiXG4gICAgICAgICAgICA/IFwiY29uc2VudC1yZXF1aXJlZCDigJQgdGhlIG5lZ2F0aXZlIGxlZzogdGhpcyBhcHAgaG9sZHMgbm8gbmV0OmZldGNoIGNvdmVyaW5nIHRoZSBjYWxsZWUncyBkZWNsYXJlZCBob3N0LCBzbyBub3RoaW5nIHdhcyBtaW50ZWQgYW5kIG5vIG92ZXJsYXkgb3BlbmVkXCJcbiAgICAgICAgICAgIDogY29kZSA9PT0gXCJmb3JiaWRkZW5cIlxuICAgICAgICAgICAgICA/IFwiZm9yYmlkZGVuIOKAlCB0YXNrOmludm9rZSBpcyBjb25mZXJyZWQgYnkgdGhlIGFnZW50cy1hY3Rpdml0eSBiaW5kaW5nc1wiXG4gICAgICAgICAgICAgIDogY29kZSxcbiAgICAgICk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFByb2JpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyAtLS0gZmlsZSBkZWxlZ2F0aW9uICjCpzUuNy/CpzguNyk6IGhhbmQgYSBjYWxsZWUgYSBmaWxlIGZyb20gTVkgT1dOIHNwYWNlIC0tLS0tLS1cbiAgY29uc3QgW2VkaXRpbmcsIHNldEVkaXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdE5vdGUsIHNldEVkaXROb3RlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGVkaXRGaWxlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldEVkaXRpbmcodHJ1ZSk7XG4gICAgc2V0RWRpdE5vdGUobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIC8vIE9wZW4gdGhpcyBhcHAncyBvd24gcGVyLXVzZXIgc2V0dGluZ3MgKGEgcHJpdmF0ZSB+Ly5jb25maWctc3R5bGUgbW91bnQpLFxuICAgICAgLy8gdGhlbiBkZWxlZ2F0ZSBPTkUgZmlsZSBpbiBpdCB0byB0aGUgYm91bmQgZWRpdC1maWxlIGFwcCDigJQgdGhlIGhvc3QgbWludHMgYW5cbiAgICAgIC8vIGF0dGVudWF0ZWQgY2hyb290OyB0aGlzIGFwcCBuZXZlciBzZWVzIHRoZSBlZGl0b3IncyBjb2RlLCBvbmx5IHRoZSB0eXBlZFxuICAgICAgLy8geyBzYXZlZCB9IHJlc3VsdC5cbiAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgb3BlblNldHRpbmdzKCk7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBpbnZva2VUYXNrPHsgc2F2ZWQ6IGJvb2xlYW4gfT4oXCJlZGl0LWZpbGVcIiwge1xuICAgICAgICBmaWxlOiBjYXBGaWxlKHsgbW91bnRJZDogc2V0dGluZ3MuaWQgPz8gc2V0dGluZ3MucGF0aCwgcmVsUGF0aDogREVNT19GSUxFIH0sIHsgbW9kZTogXCJyd1wiIH0pLFxuICAgICAgfSk7XG4gICAgICBzZXRFZGl0Tm90ZShyZXM/LnNhdmVkID8gYHNhdmVkICR7REVNT19GSUxFfSB0byB5b3VyIHNldHRpbmdzIOKck2AgOiBcImRvbmVcIik7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZSA/PyBcImVycm9yXCI7XG4gICAgICBzZXRFZGl0Tm90ZShcbiAgICAgICAgY29kZSA9PT0gXCJjYW5jZWxsZWRcIlxuICAgICAgICAgID8gXCJjYW5jZWxsZWRcIlxuICAgICAgICAgIDogY29kZSA9PT0gXCJhdXRoLXJlcXVpcmVkXCJcbiAgICAgICAgICAgID8gXCJzaWduIGluIHRvIHVzZSBhIHNwYWNlXCJcbiAgICAgICAgICAgIDogY29kZSA9PT0gXCJmb3JiaWRkZW5cIlxuICAgICAgICAgICAgICA/IFwiZm9yYmlkZGVuIOKAlCB0YXNrOmludm9rZSBpcyBjb25mZXJyZWQgYnkgdGhlIGFnZW50cy1hY3Rpdml0eSBiaW5kaW5nczsgdGhlIHN0YW5kYWxvbmUgY29weSBvZiB0aGlzIGRlbW8gY2Fubm90IGFjcXVpcmUgaXQgKG5vIGNvbnNlbnQgcGF0aCBmb3IgcGxhaW4gY2FwYWJpbGl0aWVzIHlldClcIlxuICAgICAgICAgICAgICA6IGNvZGUsXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRFZGl0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUjMtNjEyIC8gUi1JWC01IOKAlCB3aGVyZSBhIHRoaW5nIGNhbiBiZSBjcmVhdGVkIGl0IGNhbiBiZSByZW1vdmVkOiB0aGlzIGNvbnRyb2xcbiAgLy8gY3JlYXRlZCBkZW1vLnR4dCBpbiB0aGUgc2V0dGluZ3MgbW91bnQsIHNvIHRoZSBTQU1FIG1vdW50IHRha2VzIGl0IGJhY2suIFRoZVxuICAvLyB0eXBlZCBgRnNFcnJvcmAgY29kZXMgc3VyZmFjZSB2ZXJiYXRpbSDigJQgYSByZWFkLW9ubHkgbW91bnQncyByZWZ1c2FsIGlzIHRoZVxuICAvLyBob25lc3QgYW5zd2VyLCBuZXZlciBhIGZha2Ugc3VjY2Vzcy5cbiAgY29uc3QgW3JlbW92aW5nLCBzZXRSZW1vdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgcmVtb3ZlRGVtb0ZpbGUgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0UmVtb3ZpbmcodHJ1ZSk7XG4gICAgc2V0RWRpdE5vdGUobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgb3BlblNldHRpbmdzKCk7XG4gICAgICBhd2FpdCBvcGVuRnMoc2V0dGluZ3MpLnJtKERFTU9fRklMRSk7XG4gICAgICBzZXRFZGl0Tm90ZShgcmVtb3ZlZCAke0RFTU9fRklMRX0gZnJvbSB5b3VyIHNldHRpbmdzYCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZSA/PyBcImVycm9yXCI7XG4gICAgICBzZXRFZGl0Tm90ZShcbiAgICAgICAgY29kZSA9PT0gXCJjYW5jZWxsZWRcIlxuICAgICAgICAgID8gXCJjYW5jZWxsZWRcIlxuICAgICAgICAgIDogY29kZSA9PT0gXCJhdXRoLXJlcXVpcmVkXCJcbiAgICAgICAgICAgID8gXCJzaWduIGluIHRvIHVzZSBhIHNwYWNlXCJcbiAgICAgICAgICAgIDogY29kZSA9PT0gXCJmb3JiaWRkZW5cIlxuICAgICAgICAgICAgICA/IFwiZm9yYmlkZGVuIOKAlCB0aGlzIGFwcCBjYW5ub3QgcmVtb3ZlIGZyb20gdGhlIHNldHRpbmdzIG1vdW50XCJcbiAgICAgICAgICAgICAgOiBjb2RlLFxuICAgICAgKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UmVtb3ZpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBwb3N0ID0gYXN5bmMgKHRvOiBzdHJpbmcsIGRhdGE6IHVua25vd24pID0+IHtcbiAgICBzZXRQb3N0aW5nKHRvKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcG9zdFRvUmVnaW9uKHRvLCBkYXRhKTtcbiAgICAgIHNldElwY0xvZygobCkgPT4gW3sgdG8sIHJlc3VsdDogeyBraW5kOiBcIm9rXCIsIHZhbHVlOiBcImRlbGl2ZXJlZFwiIH0gfSwgLi4ubF0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSAoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGUgPz8gXCJlcnJvclwiO1xuICAgICAgc2V0SXBjTG9nKChsKSA9PiBbXG4gICAgICAgIHsgdG8sIHJlc3VsdDogeyBraW5kOiBcImVyclwiLCBjb2RlLCBtZXNzYWdlOiAoZSBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gU3RyaW5nKGUpIH0gfSxcbiAgICAgICAgLi4ubCxcbiAgICAgIF0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRQb3N0aW5nKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYWRcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYWQtaGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWQtdGl0bGVcIj5BZ2VudCB0b29sczwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWQtc3ViXCI+e2NhdGFsb2cubGVuZ3RofSBpbiB0aGlzIGFwcCdzIGNhdGFsb2c8L3NwYW4+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPHVsIGNsYXNzTmFtZT1cImFkLXRvb2xzXCI+XG4gICAgICAgIHtjYXRhbG9nLm1hcCgobSkgPT4gKFxuICAgICAgICAgIDxsaSBrZXk9e20ubmFtZX0gY2xhc3NOYW1lPVwiYWQtdG9vbFwiPlxuICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwiYWQtbmFtZVwiPnttLm5hbWV9PC9jb2RlPlxuICAgICAgICAgICAge20uc3RyZWFtICYmIDxzcGFuIGNsYXNzTmFtZT1cImFkLWJhZGdlXCI+c3RyZWFtPC9zcGFuPn1cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFkLXJ1blwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtydW5uaW5nID09PSBtLm5hbWUgfHwgbS5zdHJlYW19XG4gICAgICAgICAgICAgIHRpdGxlPXttLnN0cmVhbSA/IFwic3RyZWFtaW5nIOKAlCB1c2UgaW52b2tlU3RyZWFtXCIgOiBgcmVxdWlyZXMgJHttLmNhcGFiaWxpdHl9YH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcnVuKG0ubmFtZSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtydW5uaW5nID09PSBtLm5hbWUgPyBcIlJ1bm5pbmfigKZcIiA6IFwiUnVuXCJ9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtZXNjYXBlXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1oXCI+Q29uZmluZW1lbnQgY2hlY2sgKEcxMik8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1zdWJcIj5cbiAgICAgICAgICA8Y29kZT57T0ZGX0NBVEFMT0d9PC9jb2RlPiBpcyB7aW5DYXRhbG9nKE9GRl9DQVRBTE9HKSA/IFwiaW5cIiA6IFwiTk9UIGluXCJ9IHRoaXMgYXBwJ3NcbiAgICAgICAgICBjYXRhbG9nLiBDYWxsaW5nIGl0IGFueXdheSBzaG91bGQgYmUgcmVmdXNlZCBieSB0aGUgaG9zdCBnYXRlOlxuICAgICAgICA8L3A+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhZC1ydW4gYWQtZGFuZ2VyXCJcbiAgICAgICAgICBkaXNhYmxlZD17cnVubmluZyA9PT0gT0ZGX0NBVEFMT0d9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gcnVuKE9GRl9DQVRBTE9HKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtydW5uaW5nID09PSBPRkZfQ0FUQUxPRyA/IFwiVHJ5aW5n4oCmXCIgOiBgVHJ5ICR7T0ZGX0NBVEFMT0d9YH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZC1lc2NhcGVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLWhcIj5NZXNzYWdlIGFub3RoZXIgcGFuZWwgKMKnNS42LCBUMTkpPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgVGhpcyBhcHAgZGVjbGFyZXMgYW4gPGNvZGU+aXBjPC9jb2RlPiBlZGdlIHRvIDxjb2RlPntGSUxFU19SRUdJT059PC9jb2RlPiBvbmx5LlxuICAgICAgICAgIEFzayB0aGUgZmlsZSBleHBsb3JlciB0byByZXZlYWwgYSBwYXRoIOKAlCBpdOKAmWxsIHNob3cgdGhlIG1lc3NhZ2Ugd2l0aCBhIGhvc3QtYXR0YWNoZWRcbiAgICAgICAgICAodW5zcG9vZmFibGUpIDxjb2RlPmZyb208L2NvZGU+OlxuICAgICAgICA8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtaXBjLXJvd1wiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWQtaXBjLWlucHV0XCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXRofVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXRoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJQYXRoIHRvIHJldmVhbFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFkLXJ1blwiXG4gICAgICAgICAgICBkaXNhYmxlZD17cG9zdGluZyA9PT0gRklMRVNfUkVHSU9OfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcG9zdChGSUxFU19SRUdJT04sIHsgcmV2ZWFsOiBwYXRoIH0pfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtwb3N0aW5nID09PSBGSUxFU19SRUdJT04gPyBcIlNlbmRpbmfigKZcIiA6IFwiUmV2ZWFsIGluIEZpbGVzXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgUG9zdGluZyB0byBhIHJlZ2lvbiB0aGlzIGFwcCBkZWNsYXJlZCBubyBlZGdlIHRvICg8Y29kZT57Tk9fRURHRV9SRUdJT059PC9jb2RlPikgaXNcbiAgICAgICAgICByZWZ1c2VkIGJ5IHRoZSBob3N0IOKAlCBuZWl0aGVyIHNpZGUgb3BlbmVkIGl0OlxuICAgICAgICA8L3A+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhZC1ydW4gYWQtZGFuZ2VyXCJcbiAgICAgICAgICBkaXNhYmxlZD17cG9zdGluZyA9PT0gTk9fRURHRV9SRUdJT059XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gcG9zdChOT19FREdFX1JFR0lPTiwgeyByZXZlYWw6IHBhdGggfSl9XG4gICAgICAgID5cbiAgICAgICAgICB7cG9zdGluZyA9PT0gTk9fRURHRV9SRUdJT04gPyBcIlNlbmRpbmfigKZcIiA6IGBUcnkgbWVzc2FnaW5nICR7Tk9fRURHRV9SRUdJT059YH1cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAge2lwY0xvZy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYWQtbG9nXCI+XG4gICAgICAgICAgICB7aXBjTG9nLm1hcCgoZSwgaSkgPT4gKFxuICAgICAgICAgICAgICA8bGkga2V5PXtpfSBjbGFzc05hbWU9e2BhZC1sb2dsaW5lICR7ZS5yZXN1bHQua2luZH1gfT5cbiAgICAgICAgICAgICAgICA8Y29kZT57ZS50b308L2NvZGU+IOKGkntcIiBcIn1cbiAgICAgICAgICAgICAgICB7ZS5yZXN1bHQua2luZCA9PT0gXCJva1wiID8gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWQtb2tcIj5kZWxpdmVyZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFkLWVyclwiPntlLnJlc3VsdC5jb2RlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkLWVzY2FwZVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtaFwiPkludm9rZSBhbm90aGVyIGFwcCAowqc1LjcsIHRhc2sgY29udHJhY3QpPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgQSB0b29sIGNhbiBjYWxsIDxjb2RlPnBpY2stY29sb3I8L2NvZGU+IGFuZCBnZXQgYSB0eXBlZCBjb2xvciBiYWNrLiBUaGUgaG9zdFxuICAgICAgICAgIGxvYWRzIHRoZSB1c2VyJ3MgYm91bmQgcGlja2VyIGluIGFuIG92ZXJsYXksIHRoZSBwaWNrZXIgcmV0dXJucyBhIHZhbHVlLCBhbmRcbiAgICAgICAgICB0aGlzIGFwcCBuZXZlciBzZWVzIHRoZSBwaWNrZXIncyBjb2RlIG9yIGdyYW50cyDigJQganVzdCB0aGUgcmVzdWx0OlxuICAgICAgICA8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtaXBjLXJvd1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFkLWNvbG9yLWNoaXBcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBjb2xvciB9fSBhcmlhLWxhYmVsPXtgY29sb3IgJHtjb2xvcn1gfSAvPlxuICAgICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cImFkLWNvbG9yLXZhbFwiPntjb2xvcn08L2NvZGU+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYWQtcnVuXCIgZGlzYWJsZWQ9e3BpY2tpbmd9IG9uQ2xpY2s9e3BpY2tDb2xvcn0+XG4gICAgICAgICAgICB7cGlja2luZyA/IFwiUGlja2luZ+KAplwiIDogXCJQaWNrIGEgY29sb3JcIn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIHtwaWNrTm90ZSAmJiAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgICAgaW52b2tlVGFzayDihpIgPHNwYW4gY2xhc3NOYW1lPVwiYWQtZXJyXCI+e3BpY2tOb3RlfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZC1lc2NhcGVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLWhcIj5EZWxlZ2F0ZSBhIGNhcGFiaWxpdHksIGF0dGVudWF0ZWQgKMKnOC4xNSAvIE0yKTwvcD5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgIEludm9rZSBhbiBhcHAgdGhhdCA8ZW0+cmVxdWlyZXM8L2VtPiBhIDxjb2RlPm5ldDpmZXRjaDwvY29kZT4gaG9zdC4gVGhlIGhvc3RcbiAgICAgICAgICBtaW50cyBpdCB0aGUgaW50ZXJzZWN0aW9uIHdpdGggd2hhdCB0aGlzIGFwcCBob2xkcyDigJQgbmV2ZXIgdGhlIHVuaW9uIOKAlCBhbmQgdGhlXG4gICAgICAgICAgY2FsbGVlIHNwZW5kcyBpdCwgcmVwb3J0aW5nIHdoYXQgaXQgY291bGQgYW5kIGNvdWxkIG5vdCByZWFjaC4gSXQgYWxzbyBwcm9iZXMgYVxuICAgICAgICAgIGhvc3QgaXQgbmV2ZXIgZGVjbGFyZWQ6IDxlbT5ibG9ja2VkPC9lbT4gdGhlcmUgaXMgdGhlIHByb29mIHRoZSBncmFudCB3YXNcbiAgICAgICAgICBhdHRlbnVhdGVkIHJhdGhlciB0aGFuIGluaGVyaXRlZC5cbiAgICAgICAgPC9wPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhZC1ydW5cIiBkaXNhYmxlZD17cHJvYmluZ30gb25DbGljaz17cnVuUHJvYmV9PlxuICAgICAgICAgIHtwcm9iaW5nID8gXCJQcm9iaW5n4oCmXCIgOiBcIlJ1biB0aGUgZGVsZWdhdGlvbiBwcm9iZVwifVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAge3Byb2JlTm90ZSAmJiAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWQtZXNjYXBlLXN1YlwiPlxuICAgICAgICAgICAgaW52b2tlVGFzayDihpIgPHNwYW4gY2xhc3NOYW1lPVwiYWQtZXJyXCI+e3Byb2JlTm90ZX08L3NwYW4+XG4gICAgICAgICAgPC9wPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWQtZXNjYXBlXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1oXCI+RGVsZWdhdGUgYSBmaWxlIHRvIGFub3RoZXIgYXBwICjCpzUuNy/CpzguNyk8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFkLWVzY2FwZS1zdWJcIj5cbiAgICAgICAgICBIYW5kIHRoZSA8Y29kZT5lZGl0LWZpbGU8L2NvZGU+IGFwcCBPTkUgZmlsZSBmcm9tIHlvdXIgc3BhY2UuIFRoZSBob3N0IG1pbnRzXG4gICAgICAgICAgYW4gYXR0ZW51YXRlZCwgdGFzay1zY29wZWQgY2hyb290IOKAlCB0aGUgZWRpdG9yIGNhbiBuYW1lIG5vdGhpbmcgZWxzZSwgYW5kIGFcbiAgICAgICAgICByZWFkLW9ubHkgZGVsZWdhdGlvbiBpcyBhIHJlYWwgPGNvZGU+RVJPRlM8L2NvZGU+IHdhbGwuIFlvdXIgZ3JhbnQgbmFycm93cztcbiAgICAgICAgICBpdCBuZXZlciBhbXBsaWZpZXMgKEc3KTpcbiAgICAgICAgPC9wPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkLWVzY2FwZS1hY3Rpb25zXCI+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYWQtcnVuXCIgZGlzYWJsZWQ9e2VkaXRpbmcgfHwgcmVtb3Zpbmd9IG9uQ2xpY2s9e2VkaXRGaWxlfT5cbiAgICAgICAgICAgIHtlZGl0aW5nID8gXCJFZGl0aW5n4oCmXCIgOiBgRWRpdCAke0RFTU9fRklMRX0gaW4gbXkgc3BhY2VgfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImFkLXJ1blwiIGRpc2FibGVkPXtlZGl0aW5nIHx8IHJlbW92aW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHJlbW92ZURlbW9GaWxlKCl9PlxuICAgICAgICAgICAge3JlbW92aW5nID8gXCJSZW1vdmluZ+KAplwiIDogYFJlbW92ZSAke0RFTU9fRklMRX1gfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2VkaXROb3RlICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJhZC1lc2NhcGUtc3ViXCI+XG4gICAgICAgICAgICB7REVNT19GSUxFfSDihpIgPHNwYW4gY2xhc3NOYW1lPVwiYWQtZXJyXCI+e2VkaXROb3RlfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2xvZy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cImFkLWxvZ1wiPlxuICAgICAgICAgIHtsb2cubWFwKChlLCBpKSA9PiAoXG4gICAgICAgICAgICA8bGkga2V5PXtpfSBjbGFzc05hbWU9e2BhZC1sb2dsaW5lICR7ZS5yZXN1bHQua2luZH1gfT5cbiAgICAgICAgICAgICAgPGNvZGU+e2UubmFtZX08L2NvZGU+IOKGkntcIiBcIn1cbiAgICAgICAgICAgICAge2UucmVzdWx0LmtpbmQgPT09IFwib2tcIiA/IChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZC1va1wiPm9rPC9zcGFuPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFkLWVyclwiPntlLnJlc3VsdC5jb2RlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdWw+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFLQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFVQUEsT0FBQTtBQUF5QixJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFBQSxJQUFBRyxFQUFBLEdBQUFDLFlBQUEsSUFoQnpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0EsTUFBTUMsV0FBVyxHQUFHLGNBQWM7O0FBRWxDO0FBQ0E7QUFDQSxNQUFNQyxTQUFTLEdBQUcsVUFBVTs7QUFFNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxZQUFZLEdBQUcsYUFBYTtBQUNsQyxNQUFNQyxjQUFjLEdBQUcsY0FBYztBQUl0QixTQUFTQyxTQUFTQSxDQUFBLEVBQUc7RUFBQU4sRUFBQTtFQUNsQyxNQUFNTyxPQUFPLEdBQUcsSUFBQUMsZUFBVSxFQUFDLENBQUM7RUFDNUIsTUFBTSxDQUFDQyxHQUFHLEVBQUVDLE1BQU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBMEMsRUFBRSxDQUFDO0VBQzNFLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUUzRCxNQUFNRyxHQUFHLEdBQUcsTUFBT0MsSUFBWSxJQUFLO0lBQ2xDRixVQUFVLENBQUNFLElBQUksQ0FBQztJQUNoQixJQUFJO01BQ0YsTUFBTUMsS0FBSyxHQUFHLE1BQU0sSUFBQUMsV0FBTSxFQUFDRixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDcENMLE1BQU0sQ0FBRVEsQ0FBQyxJQUFLLENBQUM7UUFBRUgsSUFBSTtRQUFFSSxNQUFNLEVBQUU7VUFBRUMsSUFBSSxFQUFFLElBQUk7VUFBRUo7UUFBTTtNQUFFLENBQUMsRUFBRSxHQUFHRSxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDLENBQUMsT0FBT0csQ0FBQyxFQUFFO01BQ1YsTUFBTUMsSUFBSSxHQUFJRCxDQUFDLEVBQXdCQyxJQUFJLElBQUksT0FBTztNQUN0RFosTUFBTSxDQUFFUSxDQUFDLElBQUssQ0FDWjtRQUFFSCxJQUFJO1FBQUVJLE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUUsS0FBSztVQUFFRSxJQUFJO1VBQUVDLE9BQU8sRUFBR0YsQ0FBQyxFQUFZRSxPQUFPLElBQUlDLE1BQU0sQ0FBQ0gsQ0FBQztRQUFFO01BQUUsQ0FBQyxFQUNwRixHQUFHSCxDQUFDLENBQ0wsQ0FBQztJQUNKLENBQUMsU0FBUztNQUNSTCxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2xCO0VBQ0YsQ0FBQztFQUVELE1BQU1ZLFNBQVMsR0FBSVYsSUFBWSxJQUFLUixPQUFPLENBQUNtQixJQUFJLENBQUVDLENBQVksSUFBS0EsQ0FBQyxDQUFDWixJQUFJLEtBQUtBLElBQUksQ0FBQzs7RUFFbkY7RUFDQSxNQUFNLENBQUNhLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQWxCLGVBQVEsRUFBQyxZQUFZLENBQUM7RUFDOUMsTUFBTSxDQUFDbUIsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBcEIsZUFBUSxFQUF3QyxFQUFFLENBQUM7RUFDL0UsTUFBTSxDQUFDcUIsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBdEIsZUFBUSxFQUFnQixJQUFJLENBQUM7O0VBRTNEO0VBQ0EsTUFBTSxDQUFDdUIsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBeEIsZUFBUSxFQUFDLFNBQVMsQ0FBQztFQUM3QyxNQUFNLENBQUN5QixPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUExQixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDLE1BQU0sQ0FBQzJCLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQTVCLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBRTdELE1BQU02QixTQUFTLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQzVCSCxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2hCRSxXQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2pCLElBQUk7TUFDRixNQUFNRSxHQUFHLEdBQUcsTUFBTSxJQUFBQyxlQUFVLEVBQW9CLFlBQVksRUFBRTtRQUFFQyxPQUFPLEVBQUVUO01BQU0sQ0FBQyxDQUFDO01BQ2pGLElBQUlPLEdBQUcsRUFBRVAsS0FBSyxFQUFFQyxRQUFRLENBQUNNLEdBQUcsQ0FBQ1AsS0FBSyxDQUFDO0lBQ3JDLENBQUMsQ0FBQyxPQUFPYixDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUksSUFBSSxPQUFPO01BQ3REO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBaUIsV0FBVyxDQUNUakIsSUFBSSxLQUFLLFdBQVcsR0FDaEIsV0FBVyxHQUNYQSxJQUFJLEtBQUssV0FBVyxHQUNsQix1S0FBdUssR0FDdktBLElBQ1IsQ0FBQztJQUNILENBQUMsU0FBUztNQUNSZSxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQ25CO0VBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNPLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQWxDLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDN0MsTUFBTSxDQUFDbUMsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBcEMsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFFL0QsTUFBTXFDLFFBQVEsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDM0JILFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDaEJFLFlBQVksQ0FBQyxJQUFJLENBQUM7SUFDbEIsSUFBSTtNQUNGLE1BQU1OLEdBQUcsR0FBRyxNQUFNLElBQUFDLGVBQVUsRUFNekIsT0FBTyxFQUFFO1FBQUVPLEtBQUssRUFBRTtNQUFnQixDQUFDLENBQUM7TUFDdkM7TUFDQTtNQUNBO01BQ0EsTUFBTUMsRUFBRSxHQUFHVCxHQUFHLEVBQUVVLGNBQWMsSUFBSSxDQUFDVixHQUFHLEVBQUVXLGdCQUFnQjtNQUN4REwsWUFBWSxDQUNWRyxFQUFFLEdBQ0Usc0NBQXNDVCxHQUFHLENBQUNZLGNBQWMsZ0JBQWdCWixHQUFHLENBQUNhLGdCQUFnQixHQUFHLEdBQy9GLHlCQUF5QmIsR0FBRyxFQUFFVSxjQUFjLEdBQUcsV0FBVyxHQUFHLFNBQVMsS0FBS1YsR0FBRyxFQUFFWSxjQUFjLEtBQUssR0FDbkcsY0FBY1osR0FBRyxFQUFFVyxnQkFBZ0IsR0FBRyw0QkFBNEIsR0FBRyxTQUFTLEtBQUtYLEdBQUcsRUFBRWEsZ0JBQWdCLEdBQzlHLENBQUM7SUFDSCxDQUFDLENBQUMsT0FBT2pDLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSSxJQUFJLE9BQU87TUFDdEQ7TUFDQTtNQUNBeUIsWUFBWSxDQUNWekIsSUFBSSxLQUFLLFdBQVcsR0FDaEIsV0FBVyxHQUNYQSxJQUFJLEtBQUssa0JBQWtCLEdBQ3pCLG1KQUFtSixHQUNuSkEsSUFBSSxLQUFLLFdBQVcsR0FDbEIsc0VBQXNFLEdBQ3RFQSxJQUNWLENBQUM7SUFDSCxDQUFDLFNBQVM7TUFDUnVCLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDbkI7RUFDRixDQUFDOztFQUVEO0VBQ0EsTUFBTSxDQUFDVSxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUE3QyxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDLE1BQU0sQ0FBQzhDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQS9DLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBRTdELE1BQU1nRCxRQUFRLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQzNCSCxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2hCRSxXQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2pCLElBQUk7TUFDRjtNQUNBO01BQ0E7TUFDQTtNQUNBLE1BQU1FLFFBQVEsR0FBRyxNQUFNLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztNQUNyQyxNQUFNcEIsR0FBRyxHQUFHLE1BQU0sSUFBQUMsZUFBVSxFQUFxQixXQUFXLEVBQUU7UUFDNURvQixJQUFJLEVBQUUsSUFBQUMsWUFBTyxFQUFDO1VBQUVDLE9BQU8sRUFBRUosUUFBUSxDQUFDSyxFQUFFLElBQUlMLFFBQVEsQ0FBQ2hDLElBQUk7VUFBRXNDLE9BQU8sRUFBRS9EO1FBQVUsQ0FBQyxFQUFFO1VBQUVnRSxJQUFJLEVBQUU7UUFBSyxDQUFDO01BQzdGLENBQUMsQ0FBQztNQUNGVCxXQUFXLENBQUNqQixHQUFHLEVBQUUyQixLQUFLLEdBQUcsU0FBU2pFLFNBQVMscUJBQXFCLEdBQUcsTUFBTSxDQUFDO0lBQzVFLENBQUMsQ0FBQyxPQUFPa0IsQ0FBQyxFQUFFO01BQ1YsTUFBTUMsSUFBSSxHQUFJRCxDQUFDLEVBQXdCQyxJQUFJLElBQUksT0FBTztNQUN0RG9DLFdBQVcsQ0FDVHBDLElBQUksS0FBSyxXQUFXLEdBQ2hCLFdBQVcsR0FDWEEsSUFBSSxLQUFLLGVBQWUsR0FDdEIsd0JBQXdCLEdBQ3hCQSxJQUFJLEtBQUssV0FBVyxHQUNsQix1S0FBdUssR0FDdktBLElBQ1YsQ0FBQztJQUNILENBQUMsU0FBUztNQUNSa0MsVUFBVSxDQUFDLEtBQUssQ0FBQztJQUNuQjtFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNhLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQTNELGVBQVEsRUFBQyxLQUFLLENBQUM7RUFFL0MsTUFBTTRELGNBQWMsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDakNELFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFDakJaLFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFDakIsSUFBSTtNQUNGLE1BQU1FLFFBQVEsR0FBRyxNQUFNLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztNQUNyQyxNQUFNLElBQUFXLFdBQU0sRUFBQ1osUUFBUSxDQUFDLENBQUNhLEVBQUUsQ0FBQ3RFLFNBQVMsQ0FBQztNQUNwQ3VELFdBQVcsQ0FBQyxXQUFXdkQsU0FBUyxxQkFBcUIsQ0FBQztJQUN4RCxDQUFDLENBQUMsT0FBT2tCLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSSxJQUFJLE9BQU87TUFDdERvQyxXQUFXLENBQ1RwQyxJQUFJLEtBQUssV0FBVyxHQUNoQixXQUFXLEdBQ1hBLElBQUksS0FBSyxlQUFlLEdBQ3RCLHdCQUF3QixHQUN4QkEsSUFBSSxLQUFLLFdBQVcsR0FDbEIsNERBQTRELEdBQzVEQSxJQUNWLENBQUM7SUFDSCxDQUFDLFNBQVM7TUFDUmdELFdBQVcsQ0FBQyxLQUFLLENBQUM7SUFDcEI7RUFDRixDQUFDO0VBRUQsTUFBTUksSUFBSSxHQUFHLE1BQUFBLENBQU9DLEVBQVUsRUFBRUMsSUFBYSxLQUFLO0lBQ2hEM0MsVUFBVSxDQUFDMEMsRUFBRSxDQUFDO0lBQ2QsSUFBSTtNQUNGLE1BQU0sSUFBQUUsaUJBQVksRUFBQ0YsRUFBRSxFQUFFQyxJQUFJLENBQUM7TUFDNUI3QyxTQUFTLENBQUViLENBQUMsSUFBSyxDQUFDO1FBQUV5RCxFQUFFO1FBQUV4RCxNQUFNLEVBQUU7VUFBRUMsSUFBSSxFQUFFLElBQUk7VUFBRUosS0FBSyxFQUFFO1FBQVk7TUFBRSxDQUFDLEVBQUUsR0FBR0UsQ0FBQyxDQUFDLENBQUM7SUFDOUUsQ0FBQyxDQUFDLE9BQU9HLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSSxJQUFJLE9BQU87TUFDdERTLFNBQVMsQ0FBRWIsQ0FBQyxJQUFLLENBQ2Y7UUFBRXlELEVBQUU7UUFBRXhELE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUUsS0FBSztVQUFFRSxJQUFJO1VBQUVDLE9BQU8sRUFBR0YsQ0FBQyxFQUFZRSxPQUFPLElBQUlDLE1BQU0sQ0FBQ0gsQ0FBQztRQUFFO01BQUUsQ0FBQyxFQUNsRixHQUFHSCxDQUFDLENBQ0wsQ0FBQztJQUNKLENBQUMsU0FBUztNQUNSZSxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2xCO0VBQ0YsQ0FBQztFQUVELG9CQUNFLElBQUFsQyxXQUFBLENBQUErRSxJQUFBO0lBQUtDLFNBQVMsRUFBQyxJQUFJO0lBQUFDLFFBQUEsZ0JBQ2pCLElBQUFqRixXQUFBLENBQUErRSxJQUFBO01BQVFDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ3ZCLElBQUFqRixXQUFBLENBQUFrRixHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUFXLENBQU0sQ0FBQyxlQUM3QyxJQUFBakYsV0FBQSxDQUFBK0UsSUFBQTtRQUFNQyxTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEdBQUV6RSxPQUFPLENBQUMyRSxNQUFNLEVBQUMsd0JBQXNCO01BQUEsQ0FBTSxDQUFDO0lBQUEsQ0FDaEUsQ0FBQyxlQUVULElBQUFuRixXQUFBLENBQUFrRixHQUFBO01BQUlGLFNBQVMsRUFBQyxVQUFVO01BQUFDLFFBQUEsRUFDckJ6RSxPQUFPLENBQUM0RSxHQUFHLENBQUV4RCxDQUFDLGlCQUNiLElBQUE1QixXQUFBLENBQUErRSxJQUFBO1FBQWlCQyxTQUFTLEVBQUMsU0FBUztRQUFBQyxRQUFBLGdCQUNsQyxJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFNRixTQUFTLEVBQUMsU0FBUztVQUFBQyxRQUFBLEVBQUVyRCxDQUFDLENBQUNaO1FBQUksQ0FBTyxDQUFDLEVBQ3hDWSxDQUFDLENBQUN5RCxNQUFNLGlCQUFJLElBQUFyRixXQUFBLENBQUFrRixHQUFBO1VBQU1GLFNBQVMsRUFBQyxVQUFVO1VBQUFDLFFBQUEsRUFBQztRQUFNLENBQU0sQ0FBQyxlQUNyRCxJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUNFSSxJQUFJLEVBQUMsUUFBUTtVQUNiTixTQUFTLEVBQUMsUUFBUTtVQUNsQk8sUUFBUSxFQUFFMUUsT0FBTyxLQUFLZSxDQUFDLENBQUNaLElBQUksSUFBSVksQ0FBQyxDQUFDeUQsTUFBTztVQUN6Q0csS0FBSyxFQUFFNUQsQ0FBQyxDQUFDeUQsTUFBTSxHQUFHLDhCQUE4QixHQUFHLFlBQVl6RCxDQUFDLENBQUM2RCxVQUFVLEVBQUc7VUFDOUVDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNM0UsR0FBRyxDQUFDYSxDQUFDLENBQUNaLElBQUksQ0FBRTtVQUFBaUUsUUFBQSxFQUUxQnBFLE9BQU8sS0FBS2UsQ0FBQyxDQUFDWixJQUFJLEdBQUcsVUFBVSxHQUFHO1FBQUssQ0FDbEMsQ0FBQztNQUFBLEdBWEZZLENBQUMsQ0FBQ1osSUFZUCxDQUNMO0lBQUMsQ0FDQSxDQUFDLGVBRUwsSUFBQWhCLFdBQUEsQ0FBQStFLElBQUE7TUFBS0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxnQkFDeEIsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7UUFBR0YsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQUFDO01BQXVCLENBQUcsQ0FBQyxlQUN0RCxJQUFBakYsV0FBQSxDQUFBK0UsSUFBQTtRQUFHQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLGdCQUMxQixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFBRCxRQUFBLEVBQU85RTtRQUFXLENBQU8sQ0FBQyxRQUFJLEVBQUN1QixTQUFTLENBQUN2QixXQUFXLENBQUMsR0FBRyxJQUFJLEdBQUcsUUFBUSxFQUFDLDRFQUUxRTtNQUFBLENBQUcsQ0FBQyxlQUNKLElBQUFILFdBQUEsQ0FBQWtGLEdBQUE7UUFDRUksSUFBSSxFQUFDLFFBQVE7UUFDYk4sU0FBUyxFQUFDLGtCQUFrQjtRQUM1Qk8sUUFBUSxFQUFFMUUsT0FBTyxLQUFLVixXQUFZO1FBQ2xDdUYsT0FBTyxFQUFFQSxDQUFBLEtBQU0zRSxHQUFHLENBQUNaLFdBQVcsQ0FBRTtRQUFBOEUsUUFBQSxFQUUvQnBFLE9BQU8sS0FBS1YsV0FBVyxHQUFHLFNBQVMsR0FBRyxPQUFPQSxXQUFXO01BQUUsQ0FDckQsQ0FBQztJQUFBLENBQ04sQ0FBQyxlQUVOLElBQUFILFdBQUEsQ0FBQStFLElBQUE7TUFBS0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxnQkFDeEIsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7UUFBR0YsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQUFDO01BQWlDLENBQUcsQ0FBQyxlQUNoRSxJQUFBakYsV0FBQSxDQUFBK0UsSUFBQTtRQUFHQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEdBQUMsdUJBQ04sbUJBQUFqRixXQUFBLENBQUFrRixHQUFBO1VBQUFELFFBQUEsRUFBTTtRQUFHLENBQU0sQ0FBQyxhQUFTLG1CQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFBRCxRQUFBLEVBQU81RTtRQUFZLENBQU8sQ0FBQyx3SEFFM0QsbUJBQUFMLFdBQUEsQ0FBQWtGLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQUksQ0FBTSxDQUFDLEtBQ2pDO01BQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQWpGLFdBQUEsQ0FBQStFLElBQUE7UUFBS0MsU0FBUyxFQUFDLFlBQVk7UUFBQUMsUUFBQSxnQkFDekIsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFDRUYsU0FBUyxFQUFDLGNBQWM7VUFDeEIvRCxLQUFLLEVBQUVZLElBQUs7VUFDWjhELFFBQVEsRUFBR3JFLENBQUMsSUFBS1EsT0FBTyxDQUFDUixDQUFDLENBQUNzRSxNQUFNLENBQUMzRSxLQUFLLENBQUU7VUFDekMsY0FBVztRQUFnQixDQUM1QixDQUFDLGVBQ0YsSUFBQWpCLFdBQUEsQ0FBQWtGLEdBQUE7VUFDRUksSUFBSSxFQUFDLFFBQVE7VUFDYk4sU0FBUyxFQUFDLFFBQVE7VUFDbEJPLFFBQVEsRUFBRXRELE9BQU8sS0FBSzVCLFlBQWE7VUFDbkNxRixPQUFPLEVBQUVBLENBQUEsS0FBTWYsSUFBSSxDQUFDdEUsWUFBWSxFQUFFO1lBQUV3RixNQUFNLEVBQUVoRTtVQUFLLENBQUMsQ0FBRTtVQUFBb0QsUUFBQSxFQUVuRGhELE9BQU8sS0FBSzVCLFlBQVksR0FBRyxVQUFVLEdBQUc7UUFBaUIsQ0FDcEQsQ0FBQztNQUFBLENBQ04sQ0FBQyxlQUNOLElBQUFMLFdBQUEsQ0FBQStFLElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxHQUFDLG9EQUN1QixtQkFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFBQUQsUUFBQSxFQUFPM0U7UUFBYyxDQUFPLENBQUMsMkRBRWpGO01BQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQU4sV0FBQSxDQUFBa0YsR0FBQTtRQUNFSSxJQUFJLEVBQUMsUUFBUTtRQUNiTixTQUFTLEVBQUMsa0JBQWtCO1FBQzVCTyxRQUFRLEVBQUV0RCxPQUFPLEtBQUszQixjQUFlO1FBQ3JDb0YsT0FBTyxFQUFFQSxDQUFBLEtBQU1mLElBQUksQ0FBQ3JFLGNBQWMsRUFBRTtVQUFFdUYsTUFBTSxFQUFFaEU7UUFBSyxDQUFDLENBQUU7UUFBQW9ELFFBQUEsRUFFckRoRCxPQUFPLEtBQUszQixjQUFjLEdBQUcsVUFBVSxHQUFHLGlCQUFpQkEsY0FBYztNQUFFLENBQ3RFLENBQUMsRUFFUnlCLE1BQU0sQ0FBQ29ELE1BQU0sR0FBRyxDQUFDLGlCQUNoQixJQUFBbkYsV0FBQSxDQUFBa0YsR0FBQTtRQUFJRixTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEVBQ25CbEQsTUFBTSxDQUFDcUQsR0FBRyxDQUFDLENBQUM5RCxDQUFDLEVBQUV3RSxDQUFDLGtCQUNmLElBQUE5RixXQUFBLENBQUErRSxJQUFBO1VBQVlDLFNBQVMsRUFBRSxjQUFjMUQsQ0FBQyxDQUFDRixNQUFNLENBQUNDLElBQUksRUFBRztVQUFBNEQsUUFBQSxnQkFDbkQsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7WUFBQUQsUUFBQSxFQUFPM0QsQ0FBQyxDQUFDc0Q7VUFBRSxDQUFPLENBQUMsV0FBRSxFQUFDLEdBQUcsRUFDeEJ0RCxDQUFDLENBQUNGLE1BQU0sQ0FBQ0MsSUFBSSxLQUFLLElBQUksZ0JBQ3JCLElBQUFyQixXQUFBLENBQUFrRixHQUFBO1lBQU1GLFNBQVMsRUFBQyxPQUFPO1lBQUFDLFFBQUEsRUFBQztVQUFTLENBQU0sQ0FBQyxnQkFFeEMsSUFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7WUFBTUYsU0FBUyxFQUFDLFFBQVE7WUFBQUMsUUFBQSxFQUFFM0QsQ0FBQyxDQUFDRixNQUFNLENBQUNHO1VBQUksQ0FBTyxDQUMvQztRQUFBLEdBTk11RSxDQU9MLENBQ0w7TUFBQyxDQUNBLENBQ0w7SUFBQSxDQUNFLENBQUMsZUFFTixJQUFBOUYsV0FBQSxDQUFBK0UsSUFBQTtNQUFLQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLGdCQUN4QixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtRQUFHRixTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLEVBQUM7TUFBd0MsQ0FBRyxDQUFDLGVBQ3ZFLElBQUFqRixXQUFBLENBQUErRSxJQUFBO1FBQUdDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsR0FBQyxrQkFDWCxtQkFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQVUsQ0FBTSxDQUFDLDhMQUd6QztNQUFBLENBQUcsQ0FBQyxlQUNKLElBQUFqRixXQUFBLENBQUErRSxJQUFBO1FBQUtDLFNBQVMsRUFBQyxZQUFZO1FBQUFDLFFBQUEsZ0JBQ3pCLElBQUFqRixXQUFBLENBQUFrRixHQUFBO1VBQU1GLFNBQVMsRUFBQyxlQUFlO1VBQUNlLEtBQUssRUFBRTtZQUFFQyxVQUFVLEVBQUU3RDtVQUFNLENBQUU7VUFBQyxjQUFZLFNBQVNBLEtBQUs7UUFBRyxDQUFFLENBQUMsZUFDOUYsSUFBQW5DLFdBQUEsQ0FBQWtGLEdBQUE7VUFBTUYsU0FBUyxFQUFDLGNBQWM7VUFBQUMsUUFBQSxFQUFFOUM7UUFBSyxDQUFPLENBQUMsZUFDN0MsSUFBQW5DLFdBQUEsQ0FBQWtGLEdBQUE7VUFBUUksSUFBSSxFQUFDLFFBQVE7VUFBQ04sU0FBUyxFQUFDLFFBQVE7VUFBQ08sUUFBUSxFQUFFbEQsT0FBUTtVQUFDcUQsT0FBTyxFQUFFakQsU0FBVTtVQUFBd0MsUUFBQSxFQUM1RTVDLE9BQU8sR0FBRyxVQUFVLEdBQUc7UUFBYyxDQUNoQyxDQUFDO01BQUEsQ0FDTixDQUFDLEVBQ0xFLFFBQVEsaUJBQ1AsSUFBQXZDLFdBQUEsQ0FBQStFLElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxHQUFDLG9CQUNkLG1CQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFNRixTQUFTLEVBQUMsUUFBUTtVQUFBQyxRQUFBLEVBQUUxQztRQUFRLENBQU8sQ0FBQztNQUFBLENBQ3RELENBQ0o7SUFBQSxDQUNFLENBQUMsZUFFTixJQUFBdkMsV0FBQSxDQUFBK0UsSUFBQTtNQUFLQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLGdCQUN4QixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtRQUFHRixTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLEVBQUM7TUFBOEMsQ0FBRyxDQUFDLGVBQzdFLElBQUFqRixXQUFBLENBQUErRSxJQUFBO1FBQUdDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsR0FBQyxxQkFDUixtQkFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFBQUQsUUFBQSxFQUFJO1FBQVEsQ0FBSSxDQUFDLE9BQUcsbUJBQUFqRixXQUFBLENBQUFrRixHQUFBO1VBQUFELFFBQUEsRUFBTTtRQUFTLENBQU0sQ0FBQyxxTkFHckMsbUJBQUFqRixXQUFBLENBQUFrRixHQUFBO1VBQUFELFFBQUEsRUFBSTtRQUFPLENBQUksQ0FBQyx1RUFFMUM7TUFBQSxDQUFHLENBQUMsZUFDSixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtRQUFRSSxJQUFJLEVBQUMsUUFBUTtRQUFDTixTQUFTLEVBQUMsUUFBUTtRQUFDTyxRQUFRLEVBQUUxQyxPQUFRO1FBQUM2QyxPQUFPLEVBQUV6QyxRQUFTO1FBQUFnQyxRQUFBLEVBQzNFcEMsT0FBTyxHQUFHLFVBQVUsR0FBRztNQUEwQixDQUM1QyxDQUFDLEVBQ1JFLFNBQVMsaUJBQ1IsSUFBQS9DLFdBQUEsQ0FBQStFLElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxHQUFDLG9CQUNkLG1CQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFNRixTQUFTLEVBQUMsUUFBUTtVQUFBQyxRQUFBLEVBQUVsQztRQUFTLENBQU8sQ0FBQztNQUFBLENBQ3ZELENBQ0o7SUFBQSxDQUNFLENBQUMsZUFFTixJQUFBL0MsV0FBQSxDQUFBK0UsSUFBQTtNQUFLQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLGdCQUN4QixJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtRQUFHRixTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLEVBQUM7TUFBMEMsQ0FBRyxDQUFDLGVBQ3pFLElBQUFqRixXQUFBLENBQUErRSxJQUFBO1FBQUdDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsR0FBQyxXQUNsQixtQkFBQWpGLFdBQUEsQ0FBQWtGLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQVMsQ0FBTSxDQUFDLGtLQUVBLG1CQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFBRCxRQUFBLEVBQU07UUFBSyxDQUFNLENBQUMsdURBRW5EO01BQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQWpGLFdBQUEsQ0FBQStFLElBQUE7UUFBS0MsU0FBUyxFQUFDLG1CQUFtQjtRQUFBQyxRQUFBLGdCQUNoQyxJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFRSSxJQUFJLEVBQUMsUUFBUTtVQUFDTixTQUFTLEVBQUMsUUFBUTtVQUFDTyxRQUFRLEVBQUUvQixPQUFPLElBQUljLFFBQVM7VUFBQ29CLE9BQU8sRUFBRTlCLFFBQVM7VUFBQXFCLFFBQUEsRUFDdkZ6QixPQUFPLEdBQUcsVUFBVSxHQUFHLFFBQVFwRCxTQUFTO1FBQWMsQ0FDakQsQ0FBQyxlQUNULElBQUFKLFdBQUEsQ0FBQWtGLEdBQUE7VUFBUUksSUFBSSxFQUFDLFFBQVE7VUFBQ04sU0FBUyxFQUFDLFFBQVE7VUFBQ08sUUFBUSxFQUFFL0IsT0FBTyxJQUFJYyxRQUFTO1VBQUNvQixPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLbEIsY0FBYyxDQUFDLENBQUU7VUFBQVMsUUFBQSxFQUMxR1gsUUFBUSxHQUFHLFdBQVcsR0FBRyxVQUFVbEUsU0FBUztRQUFFLENBQ3pDLENBQUM7TUFBQSxDQUNOLENBQUMsRUFDTHNELFFBQVEsaUJBQ1AsSUFBQTFELFdBQUEsQ0FBQStFLElBQUE7UUFBR0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxHQUN6QjdFLFNBQVMsRUFBQyxVQUFHLG1CQUFBSixXQUFBLENBQUFrRixHQUFBO1VBQU1GLFNBQVMsRUFBQyxRQUFRO1VBQUFDLFFBQUEsRUFBRXZCO1FBQVEsQ0FBTyxDQUFDO01BQUEsQ0FDdkQsQ0FDSjtJQUFBLENBQ0UsQ0FBQyxFQUVMaEQsR0FBRyxDQUFDeUUsTUFBTSxHQUFHLENBQUMsaUJBQ2IsSUFBQW5GLFdBQUEsQ0FBQWtGLEdBQUE7TUFBSUYsU0FBUyxFQUFDLFFBQVE7TUFBQUMsUUFBQSxFQUNuQnZFLEdBQUcsQ0FBQzBFLEdBQUcsQ0FBQyxDQUFDOUQsQ0FBQyxFQUFFd0UsQ0FBQyxrQkFDWixJQUFBOUYsV0FBQSxDQUFBK0UsSUFBQTtRQUFZQyxTQUFTLEVBQUUsY0FBYzFELENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLEVBQUc7UUFBQTRELFFBQUEsZ0JBQ25ELElBQUFqRixXQUFBLENBQUFrRixHQUFBO1VBQUFELFFBQUEsRUFBTzNELENBQUMsQ0FBQ047UUFBSSxDQUFPLENBQUMsV0FBRSxFQUFDLEdBQUcsRUFDMUJNLENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLEtBQUssSUFBSSxnQkFDckIsSUFBQXJCLFdBQUEsQ0FBQWtGLEdBQUE7VUFBTUYsU0FBUyxFQUFDLE9BQU87VUFBQUMsUUFBQSxFQUFDO1FBQUUsQ0FBTSxDQUFDLGdCQUVqQyxJQUFBakYsV0FBQSxDQUFBa0YsR0FBQTtVQUFNRixTQUFTLEVBQUMsUUFBUTtVQUFBQyxRQUFBLEVBQUUzRCxDQUFDLENBQUNGLE1BQU0sQ0FBQ0c7UUFBSSxDQUFPLENBQy9DO01BQUEsR0FOTXVFLENBT0wsQ0FDTDtJQUFDLENBQ0EsQ0FDTDtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUM3RixFQUFBLENBcld1Qk0sU0FBUztFQUFBLFFBQ2ZFLGVBQVU7QUFBQTtBQUFBd0YsRUFBQSxHQURKMUYsU0FBUztBQUFBLElBQUEwRixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}