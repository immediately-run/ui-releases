var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _sdk = require("@immediately-run/sdk");
var _ConversationList = _interopRequireDefault(require("./components/ConversationList"));
var _ConversationStage = _interopRequireDefault(require("./components/ConversationStage"));
var _CodingAgent = _interopRequireDefault(require("./components/CodingAgent"));
var _AgentDemo = _interopRequireDefault(require("./components/AgentDemo"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file.
// Agent confinement equals APP confinement (UI_AS_APPS_SPEC §5.5 / §5.9 / G12):
// an app reads its own grant-FILTERED method catalog and treats it as the agent's
// tool list; naming a method OUTSIDE it still hits the §8.4 gate and returns
// `forbidden`.
//
// The agents activity mounts this SAME app in two regions (§4.1): the panel slot
// (`panel.agent`) shows the conversation LIST, the stage slot
// (`stage.conversation`) shows the SELECTED conversation. We branch on
// `getRegion()` so one app, one conversation store, serves both. Standalone (no
// region) keeps the original combined demo.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  const region = (0, _sdk.useRegion)();
  if (region === "panel.agent") return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationList.default, {});
  if (region === "stage.conversation") return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationStage.default, {});
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_CodingAgent.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_AgentDemo.default, {})]
  });
}
_s(App, "Ppkt00pAC6N/60HFSwQrnIuv9kM=", false, function () {
  return [_sdk.useRegion];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3NkayIsIl9Db252ZXJzYXRpb25MaXN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Db252ZXJzYXRpb25TdGFnZSIsIl9Db2RpbmdBZ2VudCIsIl9BZ2VudERlbW8iLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwicmVnaW9uIiwidXNlUmVnaW9uIiwianN4IiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUm9vdCBjb21wb25lbnQg4oCUIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIHRoZSBkZWZhdWx0IGV4cG9ydCBvZiBUSElTIGZpbGUuXG4vLyBBZ2VudCBjb25maW5lbWVudCBlcXVhbHMgQVBQIGNvbmZpbmVtZW50IChVSV9BU19BUFBTX1NQRUMgwqc1LjUgLyDCpzUuOSAvIEcxMik6XG4vLyBhbiBhcHAgcmVhZHMgaXRzIG93biBncmFudC1GSUxURVJFRCBtZXRob2QgY2F0YWxvZyBhbmQgdHJlYXRzIGl0IGFzIHRoZSBhZ2VudCdzXG4vLyB0b29sIGxpc3Q7IG5hbWluZyBhIG1ldGhvZCBPVVRTSURFIGl0IHN0aWxsIGhpdHMgdGhlIMKnOC40IGdhdGUgYW5kIHJldHVybnNcbi8vIGBmb3JiaWRkZW5gLlxuLy9cbi8vIFRoZSBhZ2VudHMgYWN0aXZpdHkgbW91bnRzIHRoaXMgU0FNRSBhcHAgaW4gdHdvIHJlZ2lvbnMgKMKnNC4xKTogdGhlIHBhbmVsIHNsb3Rcbi8vIChgcGFuZWwuYWdlbnRgKSBzaG93cyB0aGUgY29udmVyc2F0aW9uIExJU1QsIHRoZSBzdGFnZSBzbG90XG4vLyAoYHN0YWdlLmNvbnZlcnNhdGlvbmApIHNob3dzIHRoZSBTRUxFQ1RFRCBjb252ZXJzYXRpb24uIFdlIGJyYW5jaCBvblxuLy8gYGdldFJlZ2lvbigpYCBzbyBvbmUgYXBwLCBvbmUgY29udmVyc2F0aW9uIHN0b3JlLCBzZXJ2ZXMgYm90aC4gU3RhbmRhbG9uZSAobm9cbi8vIHJlZ2lvbikga2VlcHMgdGhlIG9yaWdpbmFsIGNvbWJpbmVkIGRlbW8uXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IHsgdXNlUmVnaW9uIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgQ29udmVyc2F0aW9uTGlzdCBmcm9tIFwiLi9jb21wb25lbnRzL0NvbnZlcnNhdGlvbkxpc3RcIjtcbmltcG9ydCBDb252ZXJzYXRpb25TdGFnZSBmcm9tIFwiLi9jb21wb25lbnRzL0NvbnZlcnNhdGlvblN0YWdlXCI7XG5pbXBvcnQgQ29kaW5nQWdlbnQgZnJvbSBcIi4vY29tcG9uZW50cy9Db2RpbmdBZ2VudFwiO1xuaW1wb3J0IEFnZW50RGVtbyBmcm9tIFwiLi9jb21wb25lbnRzL0FnZW50RGVtb1wiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHJlZ2lvbiA9IHVzZVJlZ2lvbigpO1xuICBpZiAocmVnaW9uID09PSBcInBhbmVsLmFnZW50XCIpIHJldHVybiA8Q29udmVyc2F0aW9uTGlzdCAvPjtcbiAgaWYgKHJlZ2lvbiA9PT0gXCJzdGFnZS5jb252ZXJzYXRpb25cIikgcmV0dXJuIDxDb252ZXJzYXRpb25TdGFnZSAvPjtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPENvZGluZ0FnZW50IC8+XG4gICAgICA8QWdlbnREZW1vIC8+XG4gICAgPC8+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcblxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFXQUEsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGlCQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSSxrQkFBQSxHQUFBRCxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUssWUFBQSxHQUFBRixzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQU0sVUFBQSxHQUFBSCxzQkFBQSxDQUFBSCxPQUFBO0FBQStDLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLElBQUFRLEVBQUEsR0FBQUMsWUFBQSxJQWhCL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFOLHVCQUFBTyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUUEsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDYixNQUFNTSxNQUFNLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUM7RUFDMUIsSUFBSUQsTUFBTSxLQUFLLGFBQWEsRUFBRSxvQkFBTyxJQUFBUCxXQUFBLENBQUFTLEdBQUEsRUFBQ2QsaUJBQUEsQ0FBQVUsT0FBZ0IsSUFBRSxDQUFDO0VBQ3pELElBQUlFLE1BQU0sS0FBSyxvQkFBb0IsRUFBRSxvQkFBTyxJQUFBUCxXQUFBLENBQUFTLEdBQUEsRUFBQ1osa0JBQUEsQ0FBQVEsT0FBaUIsSUFBRSxDQUFDO0VBQ2pFLG9CQUNFLElBQUFMLFdBQUEsQ0FBQVUsSUFBQSxFQUFBVixXQUFBLENBQUFXLFFBQUE7SUFBQUMsUUFBQSxnQkFDRSxJQUFBWixXQUFBLENBQUFTLEdBQUEsRUFBQ1gsWUFBQSxDQUFBTyxPQUFXLElBQUUsQ0FBQyxlQUNmLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDVixVQUFBLENBQUFNLE9BQVMsSUFBRSxDQUFDO0VBQUEsQ0FDYixDQUFDO0FBRVA7QUFBQ0osRUFBQSxDQVZRSyxHQUFHO0VBQUEsUUFDS0UsY0FBUztBQUFBO0FBQUFLLEVBQUEsR0FEakJQLEdBQUc7QUFBQSxJQUFBUSxRQUFBLEdBQUFDLE9BQUEsQ0FBQVYsT0FBQSxHQVlHQyxHQUFHO0FBQUEsSUFBQU8sRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}