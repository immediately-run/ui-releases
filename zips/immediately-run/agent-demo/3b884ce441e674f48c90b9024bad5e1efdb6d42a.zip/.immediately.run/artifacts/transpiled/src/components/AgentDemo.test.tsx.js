var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("@testing-library/react");
var _AgentDemo = _interopRequireDefault(require("./AgentDemo"));
var _sdk = require("@immediately-run/sdk");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// @vitest-environment happy-dom
// R3-612 — the demo.txt destroy leg (R-IX-5: where a thing can be created it can
// be removed). The create control delegated into the settings mount, so the
// remove control takes it back through the SAME mount; its busy state is named
// ("Removing…"), and a mount refusal surfaces verbatim — never a fake success.

_vitest.vi.mock("@immediately-run/sdk", () => ({
  useCatalog: _vitest.vi.fn(() => []),
  invoke: _vitest.vi.fn(async () => ({})),
  postToRegion: _vitest.vi.fn(async () => {}),
  invokeTask: _vitest.vi.fn(async () => ({})),
  capFile: _vitest.vi.fn((ref, opts) => ({
    $cap: "file",
    ref,
    opts
  })),
  openSettings: _vitest.vi.fn(async () => ({
    id: "m1",
    path: "/settings"
  })),
  openFs: _vitest.vi.fn(() => {
    throw new Error("openFs not staged for this test");
  })
}));
(0, _vitest.afterEach)(() => (0, _react.cleanup)());
(0, _vitest.describe)("AgentDemo — demo.txt has a remove beside its create (R3-612 / R-IX-5)", () => {
  (0, _vitest.beforeEach)(() => {
    _vitest.vi.mocked(_sdk.openFs).mockClear();
  });
  (0, _vitest.it)("removes through the settings mount, announcing the busy state by name", async () => {
    let release;
    const rm = _vitest.vi.fn(() => new Promise(res => {
      release = res;
    }));
    _vitest.vi.mocked(_sdk.openFs).mockImplementation(() => ({
      rm
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_AgentDemo.default, {}));
    const removeBtn = _react.screen.getByRole("button", {
      name: "Remove demo.txt"
    });
    const editBtn = _react.screen.getByRole("button", {
      name: "Edit demo.txt in my space"
    });
    _react.fireEvent.click(removeBtn);

    // In flight: the busy label is the NAMED one, and BOTH controls on the row
    // are disabled (the item's busy-state contract).
    (0, _vitest.expect)(_react.screen.getByRole("button", {
      name: "Removing…"
    })).toBeTruthy();
    (0, _vitest.expect)(editBtn.hasAttribute("disabled")).toBe(true);

    // The rm call happens after openSettings() resolves (a microtask later than
    // the click), so wait for it before releasing the gate.
    await (0, _react.waitFor)(() => (0, _vitest.expect)(rm).toHaveBeenCalledWith("demo.txt"));
    release();
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("removed demo.txt from your settings")).toBeTruthy());
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByRole("button", {
      name: "Remove demo.txt"
    })).toBeTruthy());
  });
  (0, _vitest.it)("a mount refusal surfaces verbatim, never as success", async () => {
    const rm = _vitest.vi.fn(() => Promise.reject(Object.assign(new Error("EROFS: read-only file system"), {
      code: "read-only"
    })));
    _vitest.vi.mocked(_sdk.openFs).mockImplementation(() => ({
      rm
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_AgentDemo.default, {}));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Remove demo.txt"
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("read-only")).toBeTruthy());
    (0, _vitest.expect)(_react.screen.queryByText("removed demo.txt from your settings")).toBeNull();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9BZ2VudERlbW8iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX3NkayIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwidmkiLCJtb2NrIiwidXNlQ2F0YWxvZyIsImZuIiwiaW52b2tlIiwicG9zdFRvUmVnaW9uIiwiaW52b2tlVGFzayIsImNhcEZpbGUiLCJyZWYiLCJvcHRzIiwiJGNhcCIsIm9wZW5TZXR0aW5ncyIsImlkIiwicGF0aCIsIm9wZW5GcyIsIkVycm9yIiwiYWZ0ZXJFYWNoIiwiY2xlYW51cCIsImRlc2NyaWJlIiwiYmVmb3JlRWFjaCIsIm1vY2tlZCIsIm1vY2tDbGVhciIsIml0IiwicmVsZWFzZSIsInJtIiwiUHJvbWlzZSIsInJlcyIsIm1vY2tJbXBsZW1lbnRhdGlvbiIsInJlbmRlciIsImpzeCIsInJlbW92ZUJ0biIsInNjcmVlbiIsImdldEJ5Um9sZSIsIm5hbWUiLCJlZGl0QnRuIiwiZmlyZUV2ZW50IiwiY2xpY2siLCJleHBlY3QiLCJ0b0JlVHJ1dGh5IiwiaGFzQXR0cmlidXRlIiwidG9CZSIsIndhaXRGb3IiLCJ0b0hhdmVCZWVuQ2FsbGVkV2l0aCIsImdldEJ5VGV4dCIsInJlamVjdCIsIk9iamVjdCIsImFzc2lnbiIsImNvZGUiLCJxdWVyeUJ5VGV4dCIsInRvQmVOdWxsIl0sInNvdXJjZXMiOlsiQWdlbnREZW1vLnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEB2aXRlc3QtZW52aXJvbm1lbnQgaGFwcHktZG9tXG4vLyBSMy02MTIg4oCUIHRoZSBkZW1vLnR4dCBkZXN0cm95IGxlZyAoUi1JWC01OiB3aGVyZSBhIHRoaW5nIGNhbiBiZSBjcmVhdGVkIGl0IGNhblxuLy8gYmUgcmVtb3ZlZCkuIFRoZSBjcmVhdGUgY29udHJvbCBkZWxlZ2F0ZWQgaW50byB0aGUgc2V0dGluZ3MgbW91bnQsIHNvIHRoZVxuLy8gcmVtb3ZlIGNvbnRyb2wgdGFrZXMgaXQgYmFjayB0aHJvdWdoIHRoZSBTQU1FIG1vdW50OyBpdHMgYnVzeSBzdGF0ZSBpcyBuYW1lZFxuLy8gKFwiUmVtb3ZpbmfigKZcIiksIGFuZCBhIG1vdW50IHJlZnVzYWwgc3VyZmFjZXMgdmVyYmF0aW0g4oCUIG5ldmVyIGEgZmFrZSBzdWNjZXNzLlxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QsIHZpLCBiZWZvcmVFYWNoLCBhZnRlckVhY2ggfSBmcm9tIFwidml0ZXN0XCI7XG5pbXBvcnQgeyByZW5kZXIsIHNjcmVlbiwgZmlyZUV2ZW50LCB3YWl0Rm9yLCBjbGVhbnVwIH0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcblxudmkubW9jayhcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCIsICgpID0+ICh7XG4gIHVzZUNhdGFsb2c6IHZpLmZuKCgpID0+IFtdKSxcbiAgaW52b2tlOiB2aS5mbihhc3luYyAoKSA9PiAoe30pKSxcbiAgcG9zdFRvUmVnaW9uOiB2aS5mbihhc3luYyAoKSA9PiB7fSksXG4gIGludm9rZVRhc2s6IHZpLmZuKGFzeW5jICgpID0+ICh7fSkpLFxuICBjYXBGaWxlOiB2aS5mbigocmVmOiB1bmtub3duLCBvcHRzOiB1bmtub3duKSA9PiAoeyAkY2FwOiBcImZpbGVcIiwgcmVmLCBvcHRzIH0pKSxcbiAgb3BlblNldHRpbmdzOiB2aS5mbihhc3luYyAoKSA9PiAoeyBpZDogXCJtMVwiLCBwYXRoOiBcIi9zZXR0aW5nc1wiIH0pKSxcbiAgb3BlbkZzOiB2aS5mbigoKSA9PiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwib3BlbkZzIG5vdCBzdGFnZWQgZm9yIHRoaXMgdGVzdFwiKTtcbiAgfSksXG59KSk7XG5cbmltcG9ydCBBZ2VudERlbW8gZnJvbSBcIi4vQWdlbnREZW1vXCI7XG5pbXBvcnQgeyBvcGVuRnMgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcblxuYWZ0ZXJFYWNoKCgpID0+IGNsZWFudXAoKSk7XG5cbmRlc2NyaWJlKFwiQWdlbnREZW1vIOKAlCBkZW1vLnR4dCBoYXMgYSByZW1vdmUgYmVzaWRlIGl0cyBjcmVhdGUgKFIzLTYxMiAvIFItSVgtNSlcIiwgKCkgPT4ge1xuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICB2aS5tb2NrZWQob3BlbkZzKS5tb2NrQ2xlYXIoKTtcbiAgfSk7XG5cbiAgaXQoXCJyZW1vdmVzIHRocm91Z2ggdGhlIHNldHRpbmdzIG1vdW50LCBhbm5vdW5jaW5nIHRoZSBidXN5IHN0YXRlIGJ5IG5hbWVcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGxldCByZWxlYXNlITogKCkgPT4gdm9pZDtcbiAgICBjb25zdCBybSA9IHZpLmZuKFxuICAgICAgKCkgPT5cbiAgICAgICAgbmV3IFByb21pc2U8dm9pZD4oKHJlcykgPT4ge1xuICAgICAgICAgIHJlbGVhc2UgPSByZXM7XG4gICAgICAgIH0pLFxuICAgICk7XG4gICAgdmkubW9ja2VkKG9wZW5GcykubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+ICh7IHJtIH0pIGFzIG5ldmVyKTtcblxuICAgIHJlbmRlcig8QWdlbnREZW1vIC8+KTtcbiAgICBjb25zdCByZW1vdmVCdG4gPSBzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJSZW1vdmUgZGVtby50eHRcIiB9KTtcbiAgICBjb25zdCBlZGl0QnRuID0gc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiRWRpdCBkZW1vLnR4dCBpbiBteSBzcGFjZVwiIH0pO1xuICAgIGZpcmVFdmVudC5jbGljayhyZW1vdmVCdG4pO1xuXG4gICAgLy8gSW4gZmxpZ2h0OiB0aGUgYnVzeSBsYWJlbCBpcyB0aGUgTkFNRUQgb25lLCBhbmQgQk9USCBjb250cm9scyBvbiB0aGUgcm93XG4gICAgLy8gYXJlIGRpc2FibGVkICh0aGUgaXRlbSdzIGJ1c3ktc3RhdGUgY29udHJhY3QpLlxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJSZW1vdmluZ+KAplwiIH0pKS50b0JlVHJ1dGh5KCk7XG4gICAgZXhwZWN0KGVkaXRCdG4uaGFzQXR0cmlidXRlKFwiZGlzYWJsZWRcIikpLnRvQmUodHJ1ZSk7XG5cbiAgICAvLyBUaGUgcm0gY2FsbCBoYXBwZW5zIGFmdGVyIG9wZW5TZXR0aW5ncygpIHJlc29sdmVzIChhIG1pY3JvdGFzayBsYXRlciB0aGFuXG4gICAgLy8gdGhlIGNsaWNrKSwgc28gd2FpdCBmb3IgaXQgYmVmb3JlIHJlbGVhc2luZyB0aGUgZ2F0ZS5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChybSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCJkZW1vLnR4dFwiKSk7XG4gICAgcmVsZWFzZSgpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJyZW1vdmVkIGRlbW8udHh0IGZyb20geW91ciBzZXR0aW5nc1wiKSkudG9CZVRydXRoeSgpKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJSZW1vdmUgZGVtby50eHRcIiB9KSkudG9CZVRydXRoeSgpKTtcbiAgfSk7XG5cbiAgaXQoXCJhIG1vdW50IHJlZnVzYWwgc3VyZmFjZXMgdmVyYmF0aW0sIG5ldmVyIGFzIHN1Y2Nlc3NcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHJtID0gdmkuZm4oKCkgPT4gUHJvbWlzZS5yZWplY3QoT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoXCJFUk9GUzogcmVhZC1vbmx5IGZpbGUgc3lzdGVtXCIpLCB7IGNvZGU6IFwicmVhZC1vbmx5XCIgfSkpKTtcbiAgICB2aS5tb2NrZWQob3BlbkZzKS5tb2NrSW1wbGVtZW50YXRpb24oKCkgPT4gKHsgcm0gfSkgYXMgbmV2ZXIpO1xuXG4gICAgcmVuZGVyKDxBZ2VudERlbW8gLz4pO1xuICAgIGZpcmVFdmVudC5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJSZW1vdmUgZGVtby50eHRcIiB9KSk7XG5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KFwicmVhZC1vbmx5XCIpKS50b0JlVHJ1dGh5KCkpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoXCJyZW1vdmVkIGRlbW8udHh0IGZyb20geW91ciBzZXR0aW5nc1wiKSkudG9CZU51bGwoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFLQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFjQSxJQUFBRSxVQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSSxJQUFBLEdBQUFKLE9BQUE7QUFBOEMsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQUEsU0FBQUcsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFyQjlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUFHLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLHNCQUFzQixFQUFFLE9BQU87RUFDckNDLFVBQVUsRUFBRUYsVUFBRSxDQUFDRyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7RUFDM0JDLE1BQU0sRUFBRUosVUFBRSxDQUFDRyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQy9CRSxZQUFZLEVBQUVMLFVBQUUsQ0FBQ0csRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDbkNHLFVBQVUsRUFBRU4sVUFBRSxDQUFDRyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ25DSSxPQUFPLEVBQUVQLFVBQUUsQ0FBQ0csRUFBRSxDQUFDLENBQUNLLEdBQVksRUFBRUMsSUFBYSxNQUFNO0lBQUVDLElBQUksRUFBRSxNQUFNO0lBQUVGLEdBQUc7SUFBRUM7RUFBSyxDQUFDLENBQUMsQ0FBQztFQUM5RUUsWUFBWSxFQUFFWCxVQUFFLENBQUNHLEVBQUUsQ0FBQyxhQUFhO0lBQUVTLEVBQUUsRUFBRSxJQUFJO0lBQUVDLElBQUksRUFBRTtFQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ2xFQyxNQUFNLEVBQUVkLFVBQUUsQ0FBQ0csRUFBRSxDQUFDLE1BQU07SUFDbEIsTUFBTSxJQUFJWSxLQUFLLENBQUMsaUNBQWlDLENBQUM7RUFDcEQsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBS0gsSUFBQUMsaUJBQVMsRUFBQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxDQUFDLENBQUM7QUFFMUIsSUFBQUMsZ0JBQVEsRUFBQyx1RUFBdUUsRUFBRSxNQUFNO0VBQ3RGLElBQUFDLGtCQUFVLEVBQUMsTUFBTTtJQUNmbkIsVUFBRSxDQUFDb0IsTUFBTSxDQUFDTixXQUFNLENBQUMsQ0FBQ08sU0FBUyxDQUFDLENBQUM7RUFDL0IsQ0FBQyxDQUFDO0VBRUYsSUFBQUMsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEYsSUFBSUMsT0FBb0I7SUFDeEIsTUFBTUMsRUFBRSxHQUFHeEIsVUFBRSxDQUFDRyxFQUFFLENBQ2QsTUFDRSxJQUFJc0IsT0FBTyxDQUFRQyxHQUFHLElBQUs7TUFDekJILE9BQU8sR0FBR0csR0FBRztJQUNmLENBQUMsQ0FDTCxDQUFDO0lBQ0QxQixVQUFFLENBQUNvQixNQUFNLENBQUNOLFdBQU0sQ0FBQyxDQUFDYSxrQkFBa0IsQ0FBQyxPQUFPO01BQUVIO0lBQUcsQ0FBQyxDQUFVLENBQUM7SUFFN0QsSUFBQUksYUFBTSxlQUFDLElBQUFoQyxXQUFBLENBQUFpQyxHQUFBLEVBQUNwQyxVQUFBLENBQUFNLE9BQVMsSUFBRSxDQUFDLENBQUM7SUFDckIsTUFBTStCLFNBQVMsR0FBR0MsYUFBTSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFrQixDQUFDLENBQUM7SUFDekUsTUFBTUMsT0FBTyxHQUFHSCxhQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQTRCLENBQUMsQ0FBQztJQUNqRkUsZ0JBQVMsQ0FBQ0MsS0FBSyxDQUFDTixTQUFTLENBQUM7O0lBRTFCO0lBQ0E7SUFDQSxJQUFBTyxjQUFNLEVBQUNOLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDSyxVQUFVLENBQUMsQ0FBQztJQUN0RSxJQUFBRCxjQUFNLEVBQUNILE9BQU8sQ0FBQ0ssWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7O0lBRW5EO0lBQ0E7SUFDQSxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFKLGNBQU0sRUFBQ2IsRUFBRSxDQUFDLENBQUNrQixvQkFBb0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNoRW5CLE9BQU8sQ0FBQyxDQUFDO0lBQ1QsTUFBTSxJQUFBa0IsY0FBTyxFQUFDLE1BQU0sSUFBQUosY0FBTSxFQUFDTixhQUFNLENBQUNZLFNBQVMsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLENBQUNMLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDakcsTUFBTSxJQUFBRyxjQUFPLEVBQUMsTUFBTSxJQUFBSixjQUFNLEVBQUNOLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ssVUFBVSxDQUFDLENBQUMsQ0FBQztFQUNuRyxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLHFEQUFxRCxFQUFFLFlBQVk7SUFDcEUsTUFBTUUsRUFBRSxHQUFHeEIsVUFBRSxDQUFDRyxFQUFFLENBQUMsTUFBTXNCLE9BQU8sQ0FBQ21CLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSS9CLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxFQUFFO01BQUVnQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZIL0MsVUFBRSxDQUFDb0IsTUFBTSxDQUFDTixXQUFNLENBQUMsQ0FBQ2Esa0JBQWtCLENBQUMsT0FBTztNQUFFSDtJQUFHLENBQUMsQ0FBVSxDQUFDO0lBRTdELElBQUFJLGFBQU0sZUFBQyxJQUFBaEMsV0FBQSxDQUFBaUMsR0FBQSxFQUFDcEMsVUFBQSxDQUFBTSxPQUFTLElBQUUsQ0FBQyxDQUFDO0lBQ3JCb0MsZ0JBQVMsQ0FBQ0MsS0FBSyxDQUFDTCxhQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWtCLENBQUMsQ0FBQyxDQUFDO0lBRXhFLE1BQU0sSUFBQVEsY0FBTyxFQUFDLE1BQU0sSUFBQUosY0FBTSxFQUFDTixhQUFNLENBQUNZLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDTCxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLElBQUFELGNBQU0sRUFBQ04sYUFBTSxDQUFDaUIsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDOUUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}