var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ConversationStage;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _toolset = require("../lib/toolset");
var _fsTools = require("../lib/fsTools");
var _projectTools = require("../lib/projectTools");
var _diagnosticsTools = require("../lib/diagnosticsTools");
var _gitTools = require("../lib/gitTools");
var _agentPrompt = require("../lib/agentPrompt");
var _skills = require("../lib/skills");
var _chatModelClient = require("../lib/chatModelClient");
var _agentLoop = require("../lib/agentLoop");
var _runPause = require("../lib/runPause");
var _steering = require("../lib/steering");
var _resume = require("../lib/resume");
var _useLeaseRefresh = require("../hooks/useLeaseRefresh");
var _conversationStore = require("../lib/conversationStore");
var _sessionProjection = require("../lib/sessionProjection");
var _stageSelection = require("../lib/stageSelection");
var _useStickToBottom = require("../hooks/useStickToBottom");
var _transcript = require("../lib/transcript");
var _TranscriptRows = _interopRequireDefault(require("./TranscriptRows"));
var _ResumeAffordance = _interopRequireDefault(require("./ResumeAffordance"));
var _conversationIpc = require("../lib/conversationIpc");
var _storeError = require("../lib/storeError");
require("./CodingAgent.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The conversation STAGE — the stage-slot half of the agents activity (plan Phase
// 05, region `stage.conversation`). The analog of the editor: it loads the
// conversation the panel selected, shows its transcript, and runs the in-browser
// agent loop, persisting every turn. The loop, tools, streaming, and host-mediated
// BYOK are the same machinery the standalone CodingAgent uses (LLM_AND_AGENTS_SPEC
// §3.3); confinement is automatic (G12/T24): catalog ⊕ mount-chroot fs tools only.
// R-ARD-10: the copy for a dead settings store names BOTH costs — the amnesia
// (history not re-sent) and the durability consequence (a closed tab loses the
// run). One constant so a fourth call site cannot ship the old copy.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const NO_STORE_SUFFIX = ", so each message is sent without the earlier ones — and a closed tab loses the run, not just the in-flight turn";

// R-ARD-10a: the copy for a checkpoint-append refusal — the run stopped AT a
// boundary and everything checkpointed so far survives. One home, used by both
// run surfaces's journal-failure catches.
const JOURNAL_REFUSAL_SUFFIX = ", so the run stopped at its last checkpoint — nothing after it was kept";
function ConversationStage() {
  _s();
  const catalog = (0, _sdk.useCatalog)();
  const mounts = (0, _sdk.useMounts)();
  const storeRef = (0, _react.useRef)(null);
  const convRef = (0, _react.useRef)(null);
  // R3-631 — the session projection (CONTRIBUTE_TRANSCRIPT_SPEC §3): the writer and
  // the named-heartbeat publisher over it. Opened/built beside the store on the
  // SAME settings mount; a dead writer costs only the feature (the host never sees
  // a heartbeat ⇒ never offers ⇒ fail-closed), never the conversation. The trigger
  // semantics live in `sessionProjection.ts` (extracted like `stageSelection.ts`
  // so they are testable without a DOM); this component only names the moments.
  const projectionRef = (0, _react.useRef)(null);
  const publisherRef = (0, _react.useRef)(null);
  // R3-224 (§3.3): the stop button's abort controller for the in-flight run. Aborting
  // it halts the loop AND tears down the in-flight upstream LLM request (stops billing).
  const abortRef = (0, _react.useRef)(null);
  // R3-333: the mid-run steering queue. STOP (above) ends the run; STEER redirects it
  // without discarding the transcript. One controller per run, so a correction the
  // user took back never leaks into the next one.
  const steerRef = (0, _react.useRef)(null);
  const [queued, setQueued] = (0, _react.useState)([]);
  const [steerText, setSteerText] = (0, _react.useState)("");
  const [log, setLog] = (0, _react.useState)([]);
  const [prompt, setPrompt] = (0, _react.useState)("");
  const [streaming, setStreaming] = (0, _react.useState)("");
  // R3-335 — the in-flight reasoning for the current turn (cleared when the whole block
  // arrives and becomes a transcript row).
  const [thinking, setThinking] = (0, _react.useState)("");
  // R3-336 — the run's token accounting, including prompt-cache reads/writes where the
  // provider reports them. Surfacing it is what makes caching verifiable rather than
  // believed; without a number on screen the cost claim is unfalsifiable.
  const [usage, setUsage] = (0, _react.useState)(null);
  const [running, setRunning] = (0, _react.useState)(false);
  // Which conversation a run is in flight for — a ref, so the arbiter's per-id probe can
  // read it without rebuilding. Set when a run starts, cleared when it ends.
  const runningIdRef = (0, _react.useRef)(null);
  const [title, setTitle] = (0, _react.useState)("");
  // The conversation currently shown — keys the transcript scroller so a switch resets
  // its follow state (a release in one conversation must not carry into the next).
  const [convId, setConvId] = (0, _react.useState)(undefined);
  // Why persistence is unavailable, if it is. The conversation store is not a
  // nice-to-have: `run()` reads the model's HISTORY out of the persisted
  // conversation, so a dead store silently downgrades the agent to a stateless
  // chatbot that re-reads nothing between turns. That failure used to be
  // swallowed by empty `catch {}`s — surface it instead (R3-247).
  const [storeError, setStoreError] = (0, _react.useState)(null);
  /** R3-561 — another frame's run lease is live on this conversation. Renders as
   *  an OFFER to take over, never as a block (R-ARD-18a): the lease is advisory,
   *  the holder may be a window that no longer exists, and a hard block on it is a
   *  dead end the user cannot escape. Carries the action that was refused, so
   *  "take over" continues what the user asked for rather than making them ask
   *  twice. */
  const [leaseHeld, setLeaseHeld] = (0, _react.useState)(null);
  // R3-560: an interrupted run detected on this conversation — the journal says
  // a run was in flight and never reached its final `runEnd` B4. Resume is
  // ATTENDED (R-ARD-15): rendering this affordance is all the boot path does;
  // no model call, no executor, nothing until the user picks an action.
  const [pendingResume, setPendingResumeState] = (0, _react.useState)(null);
  // Ref mirror — the attended gate in run() must read the CURRENT value after
  // awaiting an in-flight replay, which a render-closed state variable cannot give.
  const pendingResumeRef = (0, _react.useRef)(null);
  const setPendingResume = v => {
    pendingResumeRef.current = v;
    setPendingResumeState(v);
  };
  // The boot replay currently in flight, if any — `run()` must not start past an
  // unresolved interruption check (the TOCTOU hole: a kickoff that slips between
  // the replay call and its result takes the restart-and-lose-tail path).
  const replayInFlightRef = (0, _react.useRef)(null);

  // R3-615 — follow the stream. The transcript and the live reasoning box each pin to
  // their newest row while the reader is at the bottom, and stop the moment they scroll
  // up — resuming only on return. Two scrollers, one hook, called twice.
  const logRef = (0, _react.useRef)(null);
  const reasoningRef = (0, _react.useRef)(null);
  // The transcript scroller follows everything that grows inside it — the settled rows,
  // the live reasoning block and the live reply — so it is keyed on all three, not just
  // the settled rows (the live rows stream without touching `log`).
  const transcriptFlow = (0, _react.useMemo)(() => [log, thinking, streaming], [log, thinking, streaming]);
  (0, _useStickToBottom.useStickToBottom)(logRef, transcriptFlow);
  (0, _useStickToBottom.useStickToBottom)(reasoningRef, thinking);

  // The STAGE app's working tree, conferred by the host as a `type:'worktree'` mount
  // (AA-23) — NOT the agent's OWN repo. If it isn't conferred (the mount hasn't arrived,
  // churned away, or no app is loaded), this is `null` and we MUST NOT fall back to the
  // agent's own repo: doing so made the workbench silently author *itself* (every
  // stage-app path read `not found`, and the model floundered). Re-derived when the
  // conferred mount changes (switching the loaded app tears down the old port, mints new).
  const stageTree = (0, _react.useMemo)(() => (0, _fsTools.findConferredWorktree)(mounts, (0, _sdk.getAppMountPath)()), [mounts]);

  // Tools given to the model. Without the stage tree the agent gets the catalog ONLY —
  // no filesystem tools — so it can never edit the wrong (its own) repo. Run is gated
  // below and a "workspace not ready" notice is shown.
  // R3-339 — does the model the user configured accept images? The tool is told, so a
  // `read_file` on a PNG can SAY the model cannot look at it instead of sending
  // something that errors upstream. Re-read when the provider changes.
  const vision = (0, _react.useMemo)(() => (0, _sdk.describeChat)()?.features.vision === true, []);
  const {
    toolset,
    skills
  } = (0, _react.useMemo)(() => {
    // No conferred stage tree ⇒ a catalog-only toolset with no authoring tools, so
    // `withSkills` offers nothing and `load_skill` is absent — the authoring skills
    // would be advice the agent cannot act on (R3-331).
    if (!stageTree) return (0, _skills.withSkills)((0, _toolset.catalogToolset)(catalog));
    const fsTools = (0, _fsTools.createFsToolset)({
      root: stageTree.root,
      readOnly: stageTree.readOnly,
      vision
    });
    const projectTools = (0, _projectTools.createProjectToolset)({
      root: stageTree.root,
      readOnly: stageTree.readOnly
    });
    const diagnosticsTools = (0, _diagnosticsTools.createDiagnosticsToolset)();
    // R3-332: git-READ over the same working tree. Empty (and therefore invisible to
    // the model) unless the app holds `vcs:read`.
    const gitTools = (0, _gitTools.createGitToolset)({
      catalog
    });
    // `withSkills` stays LAST (R3-331): which host skills are offered depends on the
    // final merged tool list, so it has to see the git tools too.
    return (0, _skills.withSkills)((0, _toolset.mergeToolsets)((0, _toolset.catalogToolset)(catalog), fsTools, projectTools, diagnosticsTools, gitTools));
  }, [catalog, stageTree, vision]);
  const append = e => setLog(l => [...l, e]);

  // R3-561 / R-ARD-18: refresh the lease on an interval while the run executes.
  // Shared with CodingAgent — the other run surface — rather than living here; see
  // `useLeaseRefresh` for why the boundary appends are not enough on their own,
  // and for why this loop does NOT raise the takeover offer (it cannot: the banner
  // renders only when the run is not running). A lost lease is surfaced by the
  // run's own catch below, from the typed code `append` rejects with.
  (0, _useLeaseRefresh.useLeaseRefresh)(storeRef, runningIdRef, running);

  /**
   * R3-561 — hand the run's lease back, from both run paths.
   *
   * ONE function because there were two copies and the second had already drifted:
   * `run`'s fired it, `resumeRun`'s awaited it, and the paragraph arguing against
   * awaiting had been dropped from the second copy. The file held the argument and
   * its violation ninety lines apart.
   *
   * It releases `runningIdRef`, NOT `convRef` — the conversation the RUN held, not
   * the one on screen. Selecting another conversation mid-run sets `convRef`
   * (`stageSelection`: "a run for a different conversation does not gate the
   * reload") while the loop keeps going, so releasing what is on screen freed
   * nothing and left the real lease to sit out its full TTL — offering a second
   * window a takeover of a run that had already finished, which is the one thing
   * this call exists to prevent. Callers invoke it BEFORE clearing `runningIdRef`.
   *
   * Fired, never awaited. Failing to run at all is already the expected case (no
   * unload handler reaches it), so making a run's promise wait on a device-local
   * read + unlink with no deadline would buy nothing and could leave it pending —
   * the argument `APPEND_TIMEOUT_MS` makes one file over. The TTL and same-tab
   * reclaim are what actually free a lease.
   */
  const releaseHeldLease = (0, _react.useCallback)(() => {
    const store = storeRef.current;
    const id = runningIdRef.current;
    if (store && id) void store.releaseRun(id).catch(() => {});
  }, []);
  const showConversation = (0, _react.useCallback)(conv => {
    convRef.current = conv;
    setConvId(conv.id);
    setTitle(conv.title);
    setLog((0, _transcript.messagesToLog)(conv.messages));
    setStreaming("");
    publisherRef.current?.onShow();
    // R3-560: is there an interrupted run on this conversation? Read the JOURNAL
    // (not warm state) and offer the attended choices if so. Read-only — the
    // boot path executes nothing (G-ARD-4). When interrupted, the transcript
    // rendered is the REPLAYED one — the record alone is folded through the last
    // run end and would show a blank/stale view over a live tail (R-ARD-15).
    setPendingResume(null);
    // R3-561: the takeover offer belongs to the conversation that raised it. Left
    // standing across a switch it would take over the NEW one — `takeOverRun`
    // deliberately consults no stored lease, so it would evict a live holder of a
    // conversation the user never asked about. Cleared here, and the render below
    // carries a `convId` guard the way `pendingResume` does.
    setLeaseHeld(null);
    const store = storeRef.current;
    if (store?.hasJournal()) {
      const promise = store.replay(conv.id).then(r => {
        if (convRef.current?.id !== conv.id || runningIdRef.current !== null) return;
        if (!(0, _resume.interrupted)(r)) return;
        setLog((0, _transcript.messagesToLog)(r.messages));
        setPendingResume({
          convId: conv.id,
          replay: r
        });
      }).catch(e => {
        // R-ARD-14 / §9: a refused journal (corrupt/schema/incoherent) means
        // the conversation is UN-RESUMABLE — say the resume was withheld,
        // never silently best-effort it. Other failures are store faults.
        if (convRef.current?.id !== conv.id) return;
        if ((0, _conversationStore.isJournalRefusal)(e)) {
          append({
            kind: "error",
            text: "This conversation's checkpoint journal can't be read, so its interrupted run can't be resumed — the saved conversation still opens."
          });
        } else {
          setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
        }
      }).finally(() => {
        // Promise-identity, not convId: a same-conversation re-select (the
        // panel's repair gesture) starts a NEWER replay whose marker the older
        // promise's finally must not clear.
        if (replayInFlightRef.current?.promise === promise) replayInFlightRef.current = null;
      });
      replayInFlightRef.current = {
        convId: conv.id,
        promise
      };
    }
  }, []);

  // One arbiter per mount (never module scope): it holds the held selection and the
  // latest-wins ticket, and is created fresh so a remount starts clean. Created in an
  // effect rather than during render — `show` = `showConversation` writes `convRef`, and
  // the React Compiler's `refs` rule forbids a ref access (or a function carrying one)
  // from reaching a render path.
  const stageSelectionRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    stageSelectionRef.current = (0, _stageSelection.createStageSelection)({
      show: showConversation,
      isRunning: id => runningIdRef.current === id
    });
    return () => {
      stageSelectionRef.current = null;
    };
  }, [showConversation]);

  // The SCOPING KEY — the repo conversations are stamped with and partitioned by.
  //
  // Read from the baseline workspace channel (R3-491), NOT from `stageTree.repo`,
  // even though both are the same string (R-UAA-16). The stamp and the panel's scope
  // have to come from ONE source: they are compared for equality, so the day the two
  // derivations diverge every existing stamp silently stops matching and every
  // conversation lands under "Other repositories" — which is the R3-475 bug, just
  // arrived by a different route. `stageTree` stays what it is actually for: the
  // filesystem root the agent authors.
  const workspaceRepo = (0, _sdk.useWorkspace)()?.label;

  // Readable from the boot effect below without re-running it when the workspace
  // arrives (the effect opens the store ONCE; the fallback simply uses whatever repo
  // is known at that moment — the panel's select corrects it).
  const stageRepoRef = (0, _react.useRef)(workspaceRepo);
  (0, _react.useEffect)(() => {
    stageRepoRef.current = workspaceRepo;
  }, [workspaceRepo]);

  // Open the store; if no selection arrives, show the newest IN SCOPE (R3-475 —
  // the same repo partition the panel applies) so the stage isn't blank and never
  // seeds itself with another repo's conversation. The arbiter owns which of the
  // held selection / newest fallback wins, so a selection that landed before the
  // store opened is not dropped.
  (0, _react.useEffect)(() => {
    let live = true;
    void (async () => {
      try {
        const store = await (0, _conversationStore.openConversationStore)();
        if (!live) return;
        storeRef.current = store;
        setStoreError(null);
        await stageSelectionRef.current.storeOpened(store, stageRepoRef.current);
      } catch (e) {
        // Signed out is the ordinary case; anything else is a real fault the user
        // must see, because it costs them conversation memory.
        if (live) setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    })();
    // R3-631 — open the projection writer on the same mount, independently: a
    // store that fails while the writer opens (or vice versa) degrades exactly one
    // of the two surfaces. The publisher is built here (not during render) so no
    // ref-carrying function reaches a render path.
    projectionRef.current = null;
    publisherRef.current = (0, _sessionProjection.createProjectionPublisher)(() => projectionRef.current, () => ({
      conv: convRef.current,
      runningId: runningIdRef.current
    }));
    void (0, _sessionProjection.openSessionProjectionWriter)().then(w => {
      if (live) {
        projectionRef.current = w;
        // Catch-up: the store's open and the writer's open are independent
        // round-trips — if the stage already showed a conversation while this
        // was in flight, that onShow found no writer and dropped its heartbeat
        // (fail-closed, but the projection should not depend on open order).
        // Re-publishes current state once; per-id running gate; a null conv
        // publishes the harmless explicit-inactive doc.
        publisherRef.current?.onShow();
      }
    }).catch(e => {
      // No projection ⇒ the host never offers a transcript ⇒ fail-closed.
      // Logged-and-dropped (R3): a persistent fault should be visible somewhere.
      console.warn('session projection writer unavailable (transcript offers stay off)', e);
    });
    return () => {
      live = false;
      // Unmount ⇒ explicit inactive doc (best-effort; if the write loses the race
      // with teardown, the host's TTL expires the last heartbeat instead).
      publisherRef.current?.onUnmount();
      publisherRef.current = null;
      projectionRef.current = null;
    };
  }, []);

  // The panel drives which conversation is shown.
  (0, _react.useEffect)(() => {
    return (0, _sdk.onRegionMessage)(m => {
      if ((0, _conversationIpc.isSelect)(m.data)) void stageSelectionRef.current.select(m.data.id);
    });
  }, []);

  // Ask the panel what it has selected, once, on mount (R3-243).
  //
  // A `select-conversation` can be sent while this region does not exist: on mobile
  // the panel and the stage are different COLUMNS, and an unvisited column renders a
  // skeleton with no iframe — so the tap that reveals this pane is also the tap whose
  // selection had nowhere to land. Without this handshake the fallback above would
  // win and show the newest conversation instead of the tapped one.
  //
  // Subscribed BEFORE the ask (the listener above is already installed by the time
  // this effect runs), so the reply cannot arrive before anyone is listening. If the
  // panel is not there — a stage mounted on its own — nothing answers and the
  // newest-conversation fallback stands, exactly as before.
  (0, _react.useEffect)(() => {
    void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
      type: "request-selection"
    }).catch(() => {});
  }, []);
  const run = async () => {
    if (!prompt.trim() || running) return;
    // R3-560 (R-ARD-15, the attended gate): an interrupted run on THIS
    // conversation demands a choice first. A fresh kickoff past it would seed
    // history from the stale record, B0-replace the journal's transcript, and
    // fold-reclaim the interrupted tail — completed tool results vanishing from
    // the transcript while their file effects stay, the exact §0 divergence
    // this item exists to remove. Refuse; the affordance is one row above.
    // The interruption check may still be IN FLIGHT (boot replay) — wait for it
    // before deciding, or the gate has a hole exactly one tick wide.
    const convForGate = convRef.current;
    const inflight = replayInFlightRef.current;
    if (convForGate && inflight && inflight.convId === convForGate.id) {
      await inflight.promise;
    }
    const pending = pendingResumeRef.current;
    if (pending && convRef.current && pending.convId === convRef.current.id) {
      append({
        kind: "error",
        text: "This run was interrupted — choose Resume run, or Keep the files and end the run, before starting a new one."
      });
      return;
    }
    setPendingResume(null);
    // Refuse rather than author the wrong tree: with no conferred stage-app working
    // tree, the agent has no filesystem tools, so a "build me X" prompt would either
    // do nothing or (pre-fix) silently edit the agent's own repo. Tell the user.
    if (!stageTree) {
      append({
        kind: "user",
        text: prompt
      });
      append({
        kind: "error",
        text: "No app workspace is connected yet. Open an app in the stage (and give it a moment to mount) before asking me to edit it — I won't touch my own files."
      });
      setPrompt("");
      return;
    }
    const store = storeRef.current;
    // Ensure a conversation exists to attach this run to, stamped with the
    // workspace repo so the panel scopes it correctly (R3-475).
    let conv = convRef.current;
    if (!conv && store) {
      try {
        conv = await store.create(undefined, workspaceRepo);
        convRef.current = conv;
        stageSelectionRef.current.adopt(conv);
        setTitle(conv.title);
        setStoreError(null);
      } catch (e) {
        // Running ephemerally is a real degradation, not a detail: `history`
        // below falls back to [], so the model sees ONLY this prompt and the
        // conversation appears to have no memory. Say so (R3-247).
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    }
    // R3-561 / R-ARD-18: take the advisory run lease before executing anything.
    // A live lease held by another frame means the conversation may be running in
    // a window this one cannot see, and driving one working tree from two loops is
    // what the lease exists to avoid. `held` is an OFFER, never a block — see
    // `leaseHeld` — because the holder may be a frame that no longer exists.
    if (store && conv) {
      try {
        if ((await store.acquireRun(conv.id)) === "held") {
          setLeaseHeld({
            convId: conv.id,
            resume: false
          });
          return;
        }
      } catch (e) {
        // Wrapped for the same reason `store.create` three lines up is (R3-247): a
        // store call that rejects must not reach the user as an unhandled rejection
        // from a bare `void run()`. A lease we cannot read is not a lease we lost —
        // say the store is degraded and run, rather than refusing on an unknown.
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    }
    // R3-559: the checkpoint journal. When the device-local tier is wired, every
    // loop boundary is appended before the loop proceeds past it (B2 intent is
    // durable BEFORE its executor runs — R-ARD-10a); an append that fails or
    // times out unwinds the run AT that boundary with the durability consequence
    // named, and the journal already written stays resumable. Journalless
    // (R-ARD-10): the run is allowed to start, save-at-end only.
    const journal = conv && store?.hasJournal() ? conv : null;
    if (store && conv && !store.hasJournal() && !storeError) {
      setStoreError("Checkpoints are off (no device-local store), so closing this tab loses the run's in-flight turn — the conversation itself still saves when the run ends.");
    }
    const history = conv?.messages ?? [];
    const kickoff = prompt;
    setPrompt("");
    setRunning(true);
    runningIdRef.current = conv?.id ?? null;
    publisherRef.current?.onRunStart(conv?.id ?? null);
    setStreaming("");
    setThinking("");
    setUsage(null);
    append({
      kind: "user",
      text: kickoff
    });
    const controller = new AbortController();
    abortRef.current = controller;
    const steering = new _steering.SteerController();
    steerRef.current = steering;
    // R3-562 (§7 R-ARD-20a): the hide→pause join for this run — seeded from the
    // visibility at kickoff, driven by the host's push for the run's life
    // (src/lib/runPause.ts, extracted so the join is testable without a DOM).
    const {
      pause,
      dispose: disposePause
    } = (0, _runPause.createRunPause)();
    setQueued([]);
    const offSteerChange = steering.onChange(pending => setQueued([...pending]));
    // R3-560 (R-ARD-17): the prompt splits at a cache breakpoint — the PINNED
    // prefix (role, rules, workflow, the date frozen at run start) is stamped
    // into B0 so a resume replays these bytes exactly; the LIVE suffix (tools,
    // skills, workspace root) is rebuilt every time and the cache break at the
    // boundary is accepted, not worked around.
    const pinnedPrefix = (0, _agentPrompt.buildPinnedPrefix)({
      today: (0, _agentPrompt.todayIso)()
    });
    try {
      const transcript = await (0, _agentLoop.runAgent)({
        client: (0, _chatModelClient.createChatModelClient)(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: (0, _agentPrompt.composeSystemPrompt)(pinnedPrefix, (0, _agentPrompt.buildLiveSuffix)({
          tools: toolset.tools,
          workspaceRoot: stageTree?.root,
          skills
        })),
        workspace: workspaceRepo ?? undefined,
        systemPrefix: pinnedPrefix,
        history,
        prompt: kickoff,
        // R3-224 (§3.3): the stop button aborts the loop AND the in-flight LLM turn.
        signal: controller.signal,
        // R3-333: the steering queue — the other verb the human has.
        steering,
        // R3-562 (§7 R-ARD-20a): pause at turn boundaries while this region is hidden.
        pause,
        // Token accounting + auto-compaction let the loop run past ~12 turns (R3-220).
        contextWindow: (0, _sdk.describeChat)()?.features.maxContextTokens,
        events: {
          // R3-559: append every boundary to the conversation's journal. The loop
          // awaits this before proceeding — the write's latency IS the
          // intent-before-execute ordering.
          ...(journal ? {
            onBoundary: async b => {
              await store.append(journal.id, b);
            }
          } : {}),
          onAssistantDelta: text => setStreaming(s => s + text),
          // R3-335 — the live thinking surface. Now that compaction lets a task run past
          // a dozen turns, the silent stretches are longer, and "is it stuck or
          // thinking?" had no answer on screen.
          onReasoningDelta: text => setThinking(t => t + text),
          onReasoning: block => {
            setThinking("");
            append(block.redactedData !== undefined ? {
              kind: "reasoning",
              text: "",
              redacted: true
            } : {
              kind: "reasoning",
              text: block.text
            });
          },
          onAssistantText: text => {
            // A turn an `interrupt` steer cut short is its own row, live and on
            // replay — not a reply the model actually wrote.
            if (text === _steering.INTERRUPTED_TURN_TEXT) append({
              kind: "interrupted"
            });else if (text.trim()) append({
              kind: "text",
              text
            });
            setStreaming("");
          },
          onToolUse: (name, input) => append({
            kind: "tool",
            name,
            input
          }),
          onToolResult: (name, r) => append({
            kind: "result",
            name,
            content: r.content,
            isError: r.isError
          }),
          onNudge: () => append({
            kind: "nudge"
          }),
          onUsage: u => setUsage({
            spentTokens: u.spentTokens,
            cacheReadTokens: u.cacheReadTokens,
            cacheWriteTokens: u.cacheWriteTokens
          }),
          onCompact: ({
            summarizedCount,
            cacheReadTokens
          }) => {
            append({
              kind: "compaction",
              // R3-336: the compaction rewrote the conversation prefix, so the next turn
              // re-warms it. The durable system+tools prefix is untouched. Recording the
              // running cache total AT the boundary is what lets the cost curve across a
              // compaction be read rather than assumed.
              summary: `${summarizedCount} earlier messages summarized` + (cacheReadTokens !== undefined ? ` · ${cacheReadTokens} cached tokens read so far` : "")
            });
            // R3-559 (R-ARD-9): compaction is a natural fold point — it rewrote the
            // transcript prefix anyway. Best-effort mid-run: a failed fold costs the
            // fold, never the run (the journal retains everything; the run-end fold
            // is the authoritative write), so it is logged-and-dropped, not thrown.
            if (journal) {
              void store.fold(journal.id).catch(e => {
                console.warn("mid-run fold at compaction failed (run-end fold still will)", e);
              });
            }
          },
          onSteer: ({
            messages
          }) => {
            for (const m of messages) append({
              kind: "steer",
              mode: m.mode,
              text: m.text
            });
          }
        }
      });
      if (conv && store) {
        const newTitle = conv.title === "New conversation" ? (0, _conversationStore.deriveTitle)(transcript) : conv.title;
        try {
          // R3-559: the run-end save is now a FOLD (R-ARD-9) — the record gets
          // the authoritative transcript (byte-true to what the model saw), the
          // fold watermark, and the carried run-state; the superseded journal
          // entries are reclaimed (R-ARD-5c).
          convRef.current = await store.fold(conv.id, {
            messages: transcript,
            title: newTitle,
            repo: conv.repo ?? workspaceRepo
          });
          setTitle(newTitle);
          setStoreError(null);
          // R3-631 — the save is the natural heartbeat: messageCount grew.
          publisherRef.current?.onSaved();
          void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
            type: "conversation-updated",
            id: conv.id
          }).catch(() => {});
        } catch (e) {
          // A failed save means `convRef.current` keeps the PRE-run messages, so the
          // next turn re-sends a stale (or empty) history — the same amnesia as a
          // dead store, one turn later. Never silent (R3-247).
          setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
        }
      }
    } catch (e) {
      // R3-561: the two lease codes are UX states, not codes to print (§9). The
      // discrimination and the copy live in `lib/storeError` — pasting them here
      // is what made the resume catch below get missed the first time.
      const lease = (0, _storeError.leaseFailure)(e);
      if (lease) {
        append({
          kind: "error",
          text: (0, _storeError.leaseFailureText)(lease, true)
        });
        if (lease === "lease-lost") {
          setLeaseHeld({
            convId: runningIdRef.current ?? convRef.current?.id ?? "",
            resume: false
          });
        }
      } else {
        append({
          kind: "error",
          text: e?.message ?? String(e)
        });
      }
      // R3-559 (R-ARD-10a): a failed checkpoint append unwinds the run here. Name
      // the durability consequence — the run stopped AT a boundary and everything
      // checkpointed so far survives (the journal stays resumable).
      if ((0, _conversationStore.isJournalRefusal)(e)) {
        setStoreError((0, _storeError.describeStoreFailure)(e, JOURNAL_REFUSAL_SUFFIX));
      }
    } finally {
      offSteerChange();
      steerRef.current = null;
      disposePause();
      setQueued([]);
      setSteerText("");
      setStreaming("");
      setThinking("");
      setRunning(false);
      releaseHeldLease(); // BEFORE runningIdRef is cleared — it is the id to release
      runningIdRef.current = null;
      abortRef.current = null;
      publisherRef.current?.onRunEnd();
    }
  };

  // R3-224 (§3.3): stop the in-flight run — aborts the loop between tool calls AND the
  // in-flight LLM request (the host tears down the upstream provider fetch, stops billing).
  const stop = (0, _react.useCallback)(() => {
    abortRef.current?.abort();
  }, []);

  // ---- R3-560: the attended-resume choices (R-ARD-15) ------------------------------
  //
  // Booting an interrupted conversation offered three spec'd choices; the third —
  // "discard the tail AND revert the run's writes" — is NOT offered here because
  // the app cannot bound which writes were the run's (the CoW layer is
  // host-side), and a discard that silently keeps the files manufactures exactly
  // the divergence this work exists to remove. The disposition is recorded in
  // AGENT_RUN_DURABILITY_SPEC §5.3; the keep-choice copy says plainly that the
  // file changes stay.

  /** Resume the interrupted run: repair the transcript, name any divergence,
   *  and continue the loop WITHOUT a new prompt turn. */
  const resumeRun = async () => {
    const store = storeRef.current;
    const pending = pendingResume;
    const conv = convRef.current;
    if (!store || !pending || !conv || running || pending.convId !== conv.id) return;
    // The same workspace-readiness gate as a fresh Run: a resume authors files
    // through the conferred stage tree, and without it the loop would run
    // catalog-only or (pre-R3-569) against the wrong tree. Refuse, say why.
    if (!stageTree) {
      append({
        kind: "error",
        text: "No app workspace is connected yet. Open an app in the stage (and give it a moment to mount) before resuming — I won't touch my own files."
      });
      return;
    }
    // R3-561: same gate as a fresh Run. A reload mid-run is a NEW frame with a new
    // tabId, so same-tab reclaim does not cover it and the dead frame's lease is
    // still live until its TTL — which is exactly the case the takeover offer is
    // for. The host cannot tell a reload from a second tab, and pretending it can
    // would be the double-drive this mechanism exists to prevent.
    try {
      if ((await store.acquireRun(conv.id)) === "held") {
        setLeaseHeld({
          convId: conv.id,
          resume: true
        });
        return;
      }
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
    }
    setPendingResume(null);
    const replay = pending.replay;
    const repaired = (0, _resume.repairTranscript)({
      messages: replay.messages,
      pendingEffects: replay.pendingEffects,
      trailingPartial: replay.trailingPartial
    });
    // R-ARD-16: say what moved, in the transcript, before the model works. An
    // UNSETTLED workspace channel (undefined) claims nothing — never fabricate
    // a divergence from an unknown.
    const divergence = (0, _resume.divergenceMessage)(replay.stampedWorkspace, workspaceRepo);
    const resumed = (0, _resume.resumedMessages)(repaired.messages, divergence);
    setLog((0, _transcript.messagesToLog)(repaired.messages));
    setRunning(true);
    runningIdRef.current = conv.id;
    publisherRef.current?.onRunStart(conv.id);
    setStreaming("");
    setThinking("");
    append({
      kind: "steer",
      mode: "queue",
      text: "Run resumed from its last checkpoint"
    });
    const controller = new AbortController();
    abortRef.current = controller;
    const steeringC = new _steering.SteerController();
    steerRef.current = steeringC;
    // R3-562: the same hide→pause join as a fresh run — a resumed run is equally
    // invisible when the region is hidden.
    const {
      pause,
      dispose: disposePause
    } = (0, _runPause.createRunPause)();
    setQueued([]);
    const offSteerChange = steeringC.onChange(q => setQueued([...q]));
    // R-ARD-17: the PINNED prefix replays byte-identically from the journal (the
    // frozen date survives midnight); the LIVE suffix is rebuilt from the
    // current catalog — a revoked tool is absent, honestly taking the cache miss.
    const pinnedPrefix = replay.systemPrefix ?? (0, _agentPrompt.buildPinnedPrefix)({
      today: (0, _agentPrompt.todayIso)()
    });
    try {
      const transcript = await (0, _agentLoop.runAgent)({
        client: (0, _chatModelClient.createChatModelClient)(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: (0, _agentPrompt.composeSystemPrompt)(pinnedPrefix, (0, _agentPrompt.buildLiveSuffix)({
          tools: toolset.tools,
          workspaceRoot: stageTree?.root,
          skills
        })),
        workspace: workspaceRepo ?? undefined,
        systemPrefix: pinnedPrefix,
        resume: {
          messages: resumed,
          ...(replay.runState !== null ? {
            runState: replay.runState
          } : {})
        },
        signal: controller.signal,
        steering: steeringC,
        pause,
        contextWindow: (0, _sdk.describeChat)()?.features.maxContextTokens,
        events: {
          onBoundary: async b => {
            await store.append(conv.id, b);
          },
          onAssistantDelta: text => setStreaming(s => s + text),
          onReasoningDelta: text => setThinking(t => t + text),
          onReasoning: block => {
            setThinking("");
            append(block.redactedData !== undefined ? {
              kind: "reasoning",
              text: "",
              redacted: true
            } : {
              kind: "reasoning",
              text: block.text
            });
          },
          onAssistantText: text => {
            if (text === _steering.INTERRUPTED_TURN_TEXT) append({
              kind: "interrupted"
            });else if (text.trim()) append({
              kind: "text",
              text
            });
            setStreaming("");
          },
          onToolUse: (name, input) => append({
            kind: "tool",
            name,
            input
          }),
          onToolResult: (name, r) => append({
            kind: "result",
            name,
            content: r.content,
            isError: r.isError
          }),
          onNudge: () => append({
            kind: "nudge"
          }),
          onUsage: u => setUsage({
            spentTokens: u.spentTokens,
            cacheReadTokens: u.cacheReadTokens,
            cacheWriteTokens: u.cacheWriteTokens
          }),
          onCompact: ({
            summarizedCount
          }) => {
            append({
              kind: "compaction",
              summary: `${summarizedCount} earlier messages summarized`
            });
            void store.fold(conv.id).catch(e => console.warn("mid-run fold at compaction failed (run-end fold still will)", e));
          },
          onSteer: ({
            messages
          }) => {
            for (const m of messages) append({
              kind: "steer",
              mode: m.mode,
              text: m.text
            });
          }
        }
      });
      try {
        convRef.current = await store.fold(conv.id, {
          messages: transcript,
          repo: conv.repo ?? workspaceRepo
        });
        setStoreError(null);
        publisherRef.current?.onSaved();
        void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
          type: "conversation-updated",
          id: conv.id
        }).catch(() => {});
      } catch (e) {
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    } catch (e) {
      // R3-561: the same mapping as `run`'s catch. This is the path the takeover
      // button itself invokes, so a user who takes over a resumable run and loses
      // the lease again lands here — it printed the raw internal string until the
      // discrimination moved into `lib/storeError`.
      const lease = (0, _storeError.leaseFailure)(e);
      if (lease) {
        append({
          kind: "error",
          text: (0, _storeError.leaseFailureText)(lease, true)
        });
        if (lease === "lease-lost") {
          setLeaseHeld({
            convId: runningIdRef.current ?? convRef.current?.id ?? "",
            resume: true
          });
        }
      } else {
        append({
          kind: "error",
          text: e?.message ?? String(e)
        });
      }
      if ((0, _conversationStore.isJournalRefusal)(e)) {
        setStoreError((0, _storeError.describeStoreFailure)(e, JOURNAL_REFUSAL_SUFFIX));
      }
    } finally {
      offSteerChange();
      steerRef.current = null;
      disposePause();
      setQueued([]);
      setSteerText("");
      setStreaming("");
      setThinking("");
      setRunning(false);
      releaseHeldLease(); // BEFORE runningIdRef is cleared — it is the id to release
      runningIdRef.current = null;
      abortRef.current = null;
      publisherRef.current?.onRunEnd();
    }
  };

  /** Keep the files, end the run: fold the repaired transcript so the journal's
   *  watermark advances and the conversation closes cleanly. The FILE CHANGES
   *  STAY — the copy says so (spec §5.3's rev-2 trap). */
  const keepAndClose = async () => {
    const store = storeRef.current;
    const pending = pendingResume;
    const conv = convRef.current;
    if (!store || !pending || !conv || pending.convId !== conv.id) return;
    setPendingResume(null);
    const repaired = (0, _resume.repairTranscript)({
      messages: pending.replay.messages,
      pendingEffects: pending.replay.pendingEffects,
      trailingPartial: pending.replay.trailingPartial
    });
    try {
      convRef.current = await store.fold(conv.id, {
        messages: repaired.messages,
        repo: conv.repo ?? workspaceRepo
      });
      setLog((0, _transcript.messagesToLog)(repaired.messages));
      setStoreError(null);
      void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
        type: "conversation-updated",
        id: conv.id
      }).catch(() => {});
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
    }
  };

  // R3-333: the OTHER verb. `queue` applies at the next turn boundary (the in-flight
  // turn finishes); `interrupt` ends the in-flight model turn now and continues with
  // the correction. Neither ends the run — that is what Stop is for.
  const steer = (0, _react.useCallback)(mode => {
    const s = steerRef.current;
    if (!s) return;
    if (s.enqueue(steerText, mode)) setSteerText("");
  }, [steerText]);
  const cancelSteer = (0, _react.useCallback)(id => {
    steerRef.current?.cancel(id);
  }, []);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ca ca--stage",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ca-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-title",
        children: title || "Conversation"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "ca-sub",
        children: [toolset.tools.length, " tools ", stageTree ? "(catalog + files)" : "(catalog only)", usage && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [" · ", usage.spentTokens.toLocaleString(), " tokens", usage.cacheReadTokens !== undefined && ` · ${usage.cacheReadTokens.toLocaleString()} cached`]
        })]
      })]
    }), !stageTree && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: "Waiting for the app's workspace to connect\u2026 file tools are unavailable until then (I won't edit my own files)."
      })
    }), storeError && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: storeError
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      className: "ca-log",
      "aria-live": "polite",
      ref: logRef,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TranscriptRows.default, {
        log: log
      }), thinking && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
          className: "ca-reasoning",
          open: true,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("summary", {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "ca-thinking-dot",
              "aria-hidden": "true"
            }), "thinking\u2026"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ca-reasoning-body",
            ref: reasoningRef,
            children: thinking
          })]
        })
      }), streaming && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-text ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-text",
          children: streaming
        })
      })]
    }, convId ?? "none"), queued.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ca-queued",
      "aria-label": "Queued corrections",
      children: queued.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "ca-queued-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-queued-mode",
          children: m.mode === "interrupt" ? "now" : "next step"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-queued-text",
          children: m.text
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-queued-cancel",
          "aria-label": `Cancel queued correction: ${m.text}`,
          onClick: () => cancelSteer(m.id),
          children: "\xD7"
        })]
      }, m.id))
    }), pendingResume && !running && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ResumeAffordance.default, {
      journalDepth: pendingResume.replay.journalDepth,
      onResume: () => void resumeRun(),
      onKeepAndEnd: () => void keepAndClose()
    }), leaseHeld && !running && leaseHeld.convId === convId && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: (0, _storeError.leaseHeldText)(true)
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ca-resume-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-run",
          onClick: () => {
            const {
              resume: wasResume,
              convId: forConv
            } = leaseHeld;
            void (async () => {
              try {
                const store = storeRef.current;
                // The offer stays up until the takeover actually lands. An
                // earlier version dismissed it first, so a rejected write left
                // the user with no offer, no run and no message.
                if (store) await store.takeOverRun(forConv);
                setLeaseHeld(null);
              } catch (e) {
                setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
                return;
              }
              await (wasResume ? resumeRun() : run());
            })();
          },
          children: "Take over"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn",
          onClick: () => setLeaseHeld(null),
          children: "Leave it alone"
        })]
      })]
    }), running && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "ca-steer-hint",
      role: "status",
      children: steerText.trim() ? "The agent is working. Type here to redirect it." : "Type a message to steer"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-prompt-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "ca-prompt",
        placeholder: running ? "Steer the agent — say what to do differently…" : "Ask the agent to read, search, or edit your app…",
        value: running ? steerText : prompt,
        onChange: e => running ? setSteerText(e.target.value) : setPrompt(e.target.value),
        onKeyDown: e => {
          if (e.key !== "Enter") return;
          if (running) steer("queue");else void run();
        },
        "aria-label": running ? "Steer the agent" : "Prompt"
      }), running && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn",
          disabled: !steerText.trim(),
          onClick: () => steer("queue"),
          children: "Send after this step"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn ca-steer-now",
          disabled: !steerText.trim(),
          onClick: () => steer("interrupt"),
          children: "Send now"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-run"
        // While running, the button becomes a live Stop control (R3-224): it must
        // stay enabled so the user can abort the in-flight turn and stop billing.
        ,
        disabled: running ? false : !stageTree,
        title: running ? "End the run and abort the in-flight request" : !stageTree ? "Waiting for the app's workspace to connect" : undefined,
        onClick: () => running ? stop() : void run(),
        children: running ? "Stop" : "Run"
      })]
    })]
  });
}
_s(ConversationStage, "asCt5ZTu4NBYQx/m+V9Kq7zLOtA=", false, function () {
  return [_sdk.useCatalog, _sdk.useMounts, _useStickToBottom.useStickToBottom, _useStickToBottom.useStickToBottom, _useLeaseRefresh.useLeaseRefresh, _sdk.useWorkspace];
});
_c = ConversationStage;
var _c;
$RefreshReg$(_c, "ConversationStage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl90b29sc2V0IiwiX2ZzVG9vbHMiLCJfcHJvamVjdFRvb2xzIiwiX2RpYWdub3N0aWNzVG9vbHMiLCJfZ2l0VG9vbHMiLCJfYWdlbnRQcm9tcHQiLCJfc2tpbGxzIiwiX2NoYXRNb2RlbENsaWVudCIsIl9hZ2VudExvb3AiLCJfcnVuUGF1c2UiLCJfc3RlZXJpbmciLCJfcmVzdW1lIiwiX3VzZUxlYXNlUmVmcmVzaCIsIl9jb252ZXJzYXRpb25TdG9yZSIsIl9zZXNzaW9uUHJvamVjdGlvbiIsIl9zdGFnZVNlbGVjdGlvbiIsIl91c2VTdGlja1RvQm90dG9tIiwiX3RyYW5zY3JpcHQiLCJfVHJhbnNjcmlwdFJvd3MiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1Jlc3VtZUFmZm9yZGFuY2UiLCJfY29udmVyc2F0aW9uSXBjIiwiX3N0b3JlRXJyb3IiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiTk9fU1RPUkVfU1VGRklYIiwiSk9VUk5BTF9SRUZVU0FMX1NVRkZJWCIsIkNvbnZlcnNhdGlvblN0YWdlIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJzdG9yZVJlZiIsInVzZVJlZiIsImNvbnZSZWYiLCJwcm9qZWN0aW9uUmVmIiwicHVibGlzaGVyUmVmIiwiYWJvcnRSZWYiLCJzdGVlclJlZiIsInF1ZXVlZCIsInNldFF1ZXVlZCIsInVzZVN0YXRlIiwic3RlZXJUZXh0Iiwic2V0U3RlZXJUZXh0IiwibG9nIiwic2V0TG9nIiwicHJvbXB0Iiwic2V0UHJvbXB0Iiwic3RyZWFtaW5nIiwic2V0U3RyZWFtaW5nIiwidGhpbmtpbmciLCJzZXRUaGlua2luZyIsInVzYWdlIiwic2V0VXNhZ2UiLCJydW5uaW5nIiwic2V0UnVubmluZyIsInJ1bm5pbmdJZFJlZiIsInRpdGxlIiwic2V0VGl0bGUiLCJjb252SWQiLCJzZXRDb252SWQiLCJ1bmRlZmluZWQiLCJzdG9yZUVycm9yIiwic2V0U3RvcmVFcnJvciIsImxlYXNlSGVsZCIsInNldExlYXNlSGVsZCIsInBlbmRpbmdSZXN1bWUiLCJzZXRQZW5kaW5nUmVzdW1lU3RhdGUiLCJwZW5kaW5nUmVzdW1lUmVmIiwic2V0UGVuZGluZ1Jlc3VtZSIsInYiLCJjdXJyZW50IiwicmVwbGF5SW5GbGlnaHRSZWYiLCJsb2dSZWYiLCJyZWFzb25pbmdSZWYiLCJ0cmFuc2NyaXB0RmxvdyIsInVzZU1lbW8iLCJ1c2VTdGlja1RvQm90dG9tIiwic3RhZ2VUcmVlIiwiZmluZENvbmZlcnJlZFdvcmt0cmVlIiwiZ2V0QXBwTW91bnRQYXRoIiwidmlzaW9uIiwiZGVzY3JpYmVDaGF0IiwiZmVhdHVyZXMiLCJ0b29sc2V0Iiwic2tpbGxzIiwid2l0aFNraWxscyIsImNhdGFsb2dUb29sc2V0IiwiZnNUb29scyIsImNyZWF0ZUZzVG9vbHNldCIsInJvb3QiLCJyZWFkT25seSIsInByb2plY3RUb29scyIsImNyZWF0ZVByb2plY3RUb29sc2V0IiwiZGlhZ25vc3RpY3NUb29scyIsImNyZWF0ZURpYWdub3N0aWNzVG9vbHNldCIsImdpdFRvb2xzIiwiY3JlYXRlR2l0VG9vbHNldCIsIm1lcmdlVG9vbHNldHMiLCJhcHBlbmQiLCJsIiwidXNlTGVhc2VSZWZyZXNoIiwicmVsZWFzZUhlbGRMZWFzZSIsInVzZUNhbGxiYWNrIiwic3RvcmUiLCJpZCIsInJlbGVhc2VSdW4iLCJjYXRjaCIsInNob3dDb252ZXJzYXRpb24iLCJjb252IiwibWVzc2FnZXNUb0xvZyIsIm1lc3NhZ2VzIiwib25TaG93IiwiaGFzSm91cm5hbCIsInByb21pc2UiLCJyZXBsYXkiLCJ0aGVuIiwiciIsImludGVycnVwdGVkIiwiaXNKb3VybmFsUmVmdXNhbCIsImtpbmQiLCJ0ZXh0IiwiZGVzY3JpYmUiLCJmaW5hbGx5Iiwic3RhZ2VTZWxlY3Rpb25SZWYiLCJ1c2VFZmZlY3QiLCJjcmVhdGVTdGFnZVNlbGVjdGlvbiIsInNob3ciLCJpc1J1bm5pbmciLCJ3b3Jrc3BhY2VSZXBvIiwidXNlV29ya3NwYWNlIiwibGFiZWwiLCJzdGFnZVJlcG9SZWYiLCJsaXZlIiwib3BlbkNvbnZlcnNhdGlvblN0b3JlIiwic3RvcmVPcGVuZWQiLCJjcmVhdGVQcm9qZWN0aW9uUHVibGlzaGVyIiwicnVubmluZ0lkIiwib3BlblNlc3Npb25Qcm9qZWN0aW9uV3JpdGVyIiwidyIsImNvbnNvbGUiLCJ3YXJuIiwib25Vbm1vdW50Iiwib25SZWdpb25NZXNzYWdlIiwibSIsImlzU2VsZWN0IiwiZGF0YSIsInNlbGVjdCIsInBvc3RUb1JlZ2lvbiIsIlBBTkVMX1JFR0lPTiIsInR5cGUiLCJydW4iLCJ0cmltIiwiY29udkZvckdhdGUiLCJpbmZsaWdodCIsInBlbmRpbmciLCJjcmVhdGUiLCJhZG9wdCIsImFjcXVpcmVSdW4iLCJyZXN1bWUiLCJqb3VybmFsIiwiaGlzdG9yeSIsImtpY2tvZmYiLCJvblJ1blN0YXJ0IiwiY29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsInN0ZWVyaW5nIiwiU3RlZXJDb250cm9sbGVyIiwicGF1c2UiLCJkaXNwb3NlIiwiZGlzcG9zZVBhdXNlIiwiY3JlYXRlUnVuUGF1c2UiLCJvZmZTdGVlckNoYW5nZSIsIm9uQ2hhbmdlIiwicGlubmVkUHJlZml4IiwiYnVpbGRQaW5uZWRQcmVmaXgiLCJ0b2RheSIsInRvZGF5SXNvIiwidHJhbnNjcmlwdCIsInJ1bkFnZW50IiwiY2xpZW50IiwiY3JlYXRlQ2hhdE1vZGVsQ2xpZW50IiwidG9vbHMiLCJleGVjdXRlIiwic3lzdGVtIiwiY29tcG9zZVN5c3RlbVByb21wdCIsImJ1aWxkTGl2ZVN1ZmZpeCIsIndvcmtzcGFjZVJvb3QiLCJ3b3Jrc3BhY2UiLCJzeXN0ZW1QcmVmaXgiLCJzaWduYWwiLCJjb250ZXh0V2luZG93IiwibWF4Q29udGV4dFRva2VucyIsImV2ZW50cyIsIm9uQm91bmRhcnkiLCJiIiwib25Bc3Npc3RhbnREZWx0YSIsInMiLCJvblJlYXNvbmluZ0RlbHRhIiwidCIsIm9uUmVhc29uaW5nIiwiYmxvY2siLCJyZWRhY3RlZERhdGEiLCJyZWRhY3RlZCIsIm9uQXNzaXN0YW50VGV4dCIsIklOVEVSUlVQVEVEX1RVUk5fVEVYVCIsIm9uVG9vbFVzZSIsIm5hbWUiLCJpbnB1dCIsIm9uVG9vbFJlc3VsdCIsImNvbnRlbnQiLCJpc0Vycm9yIiwib25OdWRnZSIsIm9uVXNhZ2UiLCJ1Iiwic3BlbnRUb2tlbnMiLCJjYWNoZVJlYWRUb2tlbnMiLCJjYWNoZVdyaXRlVG9rZW5zIiwib25Db21wYWN0Iiwic3VtbWFyaXplZENvdW50Iiwic3VtbWFyeSIsImZvbGQiLCJvblN0ZWVyIiwibW9kZSIsIm5ld1RpdGxlIiwiZGVyaXZlVGl0bGUiLCJyZXBvIiwib25TYXZlZCIsImxlYXNlIiwibGVhc2VGYWlsdXJlIiwibGVhc2VGYWlsdXJlVGV4dCIsIm1lc3NhZ2UiLCJTdHJpbmciLCJvblJ1bkVuZCIsInN0b3AiLCJhYm9ydCIsInJlc3VtZVJ1biIsInJlcGFpcmVkIiwicmVwYWlyVHJhbnNjcmlwdCIsInBlbmRpbmdFZmZlY3RzIiwidHJhaWxpbmdQYXJ0aWFsIiwiZGl2ZXJnZW5jZSIsImRpdmVyZ2VuY2VNZXNzYWdlIiwic3RhbXBlZFdvcmtzcGFjZSIsInJlc3VtZWQiLCJyZXN1bWVkTWVzc2FnZXMiLCJzdGVlcmluZ0MiLCJxIiwicnVuU3RhdGUiLCJrZWVwQW5kQ2xvc2UiLCJzdGVlciIsImVucXVldWUiLCJjYW5jZWxTdGVlciIsImNhbmNlbCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsImxlbmd0aCIsIkZyYWdtZW50IiwidG9Mb2NhbGVTdHJpbmciLCJyb2xlIiwicmVmIiwib3BlbiIsIm1hcCIsIm9uQ2xpY2siLCJqb3VybmFsRGVwdGgiLCJvblJlc3VtZSIsIm9uS2VlcEFuZEVuZCIsImxlYXNlSGVsZFRleHQiLCJ3YXNSZXN1bWUiLCJmb3JDb252IiwidGFrZU92ZXJSdW4iLCJwbGFjZWhvbGRlciIsInZhbHVlIiwidGFyZ2V0Iiwib25LZXlEb3duIiwia2V5IiwiZGlzYWJsZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnZlcnNhdGlvblN0YWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgY29udmVyc2F0aW9uIFNUQUdFIOKAlCB0aGUgc3RhZ2Utc2xvdCBoYWxmIG9mIHRoZSBhZ2VudHMgYWN0aXZpdHkgKHBsYW4gUGhhc2Vcbi8vIDA1LCByZWdpb24gYHN0YWdlLmNvbnZlcnNhdGlvbmApLiBUaGUgYW5hbG9nIG9mIHRoZSBlZGl0b3I6IGl0IGxvYWRzIHRoZVxuLy8gY29udmVyc2F0aW9uIHRoZSBwYW5lbCBzZWxlY3RlZCwgc2hvd3MgaXRzIHRyYW5zY3JpcHQsIGFuZCBydW5zIHRoZSBpbi1icm93c2VyXG4vLyBhZ2VudCBsb29wLCBwZXJzaXN0aW5nIGV2ZXJ5IHR1cm4uIFRoZSBsb29wLCB0b29scywgc3RyZWFtaW5nLCBhbmQgaG9zdC1tZWRpYXRlZFxuLy8gQllPSyBhcmUgdGhlIHNhbWUgbWFjaGluZXJ5IHRoZSBzdGFuZGFsb25lIENvZGluZ0FnZW50IHVzZXMgKExMTV9BTkRfQUdFTlRTX1NQRUNcbi8vIMKnMy4zKTsgY29uZmluZW1lbnQgaXMgYXV0b21hdGljIChHMTIvVDI0KTogY2F0YWxvZyDiipUgbW91bnQtY2hyb290IGZzIHRvb2xzIG9ubHkuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICB1c2VDYXRhbG9nLFxuICB1c2VNb3VudHMsXG4gIGdldEFwcE1vdW50UGF0aCxcbiAgdXNlV29ya3NwYWNlLFxuICBwb3N0VG9SZWdpb24sXG4gIG9uUmVnaW9uTWVzc2FnZSxcbiAgZGVzY3JpYmVDaGF0LFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCB7IGNhdGFsb2dUb29sc2V0LCBtZXJnZVRvb2xzZXRzIH0gZnJvbSBcIi4uL2xpYi90b29sc2V0XCI7XG5pbXBvcnQgeyBjcmVhdGVGc1Rvb2xzZXQsIGZpbmRDb25mZXJyZWRXb3JrdHJlZSB9IGZyb20gXCIuLi9saWIvZnNUb29sc1wiO1xuaW1wb3J0IHsgY3JlYXRlUHJvamVjdFRvb2xzZXQgfSBmcm9tIFwiLi4vbGliL3Byb2plY3RUb29sc1wiO1xuaW1wb3J0IHsgY3JlYXRlRGlhZ25vc3RpY3NUb29sc2V0IH0gZnJvbSBcIi4uL2xpYi9kaWFnbm9zdGljc1Rvb2xzXCI7XG5pbXBvcnQgeyBjcmVhdGVHaXRUb29sc2V0IH0gZnJvbSBcIi4uL2xpYi9naXRUb29sc1wiO1xuaW1wb3J0IHsgYnVpbGRQaW5uZWRQcmVmaXgsIGJ1aWxkTGl2ZVN1ZmZpeCwgY29tcG9zZVN5c3RlbVByb21wdCwgdG9kYXlJc28gfSBmcm9tIFwiLi4vbGliL2FnZW50UHJvbXB0XCI7XG5pbXBvcnQgeyB3aXRoU2tpbGxzIH0gZnJvbSBcIi4uL2xpYi9za2lsbHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYXRNb2RlbENsaWVudCB9IGZyb20gXCIuLi9saWIvY2hhdE1vZGVsQ2xpZW50XCI7XG5pbXBvcnQgeyBydW5BZ2VudCwgdHlwZSBSdW5TdGF0ZSB9IGZyb20gXCIuLi9saWIvYWdlbnRMb29wXCI7XG5pbXBvcnQgeyBjcmVhdGVSdW5QYXVzZSB9IGZyb20gXCIuLi9saWIvcnVuUGF1c2VcIjtcbmltcG9ydCB7IFN0ZWVyQ29udHJvbGxlciwgSU5URVJSVVBURURfVFVSTl9URVhULCB0eXBlIFN0ZWVyTWVzc2FnZSwgdHlwZSBTdGVlck1vZGUgfSBmcm9tIFwiLi4vbGliL3N0ZWVyaW5nXCI7XG5pbXBvcnQgeyByZXBhaXJUcmFuc2NyaXB0LCBpbnRlcnJ1cHRlZCwgZGl2ZXJnZW5jZU1lc3NhZ2UsIHJlc3VtZWRNZXNzYWdlcyB9IGZyb20gXCIuLi9saWIvcmVzdW1lXCI7XG5pbXBvcnQgeyB1c2VMZWFzZVJlZnJlc2ggfSBmcm9tIFwiLi4vaG9va3MvdXNlTGVhc2VSZWZyZXNoXCI7XG5pbXBvcnQgeyBvcGVuQ29udmVyc2F0aW9uU3RvcmUsIGRlcml2ZVRpdGxlLCBpc0pvdXJuYWxSZWZ1c2FsLCB0eXBlIENvbnZlcnNhdGlvblN0b3JlLCB0eXBlIFJlcGxheVJlc3VsdCB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uU3RvcmVcIjtcbmltcG9ydCB7XG4gIG9wZW5TZXNzaW9uUHJvamVjdGlvbldyaXRlcixcbiAgY3JlYXRlUHJvamVjdGlvblB1Ymxpc2hlcixcbiAgdHlwZSBTZXNzaW9uUHJvamVjdGlvbldyaXRlcixcbiAgdHlwZSBQcm9qZWN0aW9uUHVibGlzaGVyLFxufSBmcm9tIFwiLi4vbGliL3Nlc3Npb25Qcm9qZWN0aW9uXCI7XG5pbXBvcnQgeyBjcmVhdGVTdGFnZVNlbGVjdGlvbiwgdHlwZSBTdGFnZVNlbGVjdGlvbiB9IGZyb20gXCIuLi9saWIvc3RhZ2VTZWxlY3Rpb25cIjtcbmltcG9ydCB7IHVzZVN0aWNrVG9Cb3R0b20gfSBmcm9tIFwiLi4vaG9va3MvdXNlU3RpY2tUb0JvdHRvbVwiO1xuaW1wb3J0IHR5cGUgeyBDb252ZXJzYXRpb24gfSBmcm9tIFwiLi4vbGliL2NvbnZlcnNhdGlvbk1vZGVsXCI7XG5pbXBvcnQgeyBtZXNzYWdlc1RvTG9nLCB0eXBlIExvZ0VudHJ5IH0gZnJvbSBcIi4uL2xpYi90cmFuc2NyaXB0XCI7XG5pbXBvcnQgVHJhbnNjcmlwdFJvd3MgZnJvbSBcIi4vVHJhbnNjcmlwdFJvd3NcIjtcbmltcG9ydCBSZXN1bWVBZmZvcmRhbmNlIGZyb20gXCIuL1Jlc3VtZUFmZm9yZGFuY2VcIjtcbmltcG9ydCB7IFBBTkVMX1JFR0lPTiwgaXNTZWxlY3QgfSBmcm9tIFwiLi4vbGliL2NvbnZlcnNhdGlvbklwY1wiO1xuaW1wb3J0IHsgZGVzY3JpYmVTdG9yZUZhaWx1cmUgYXMgZGVzY3JpYmUsIGxlYXNlRmFpbHVyZSwgbGVhc2VGYWlsdXJlVGV4dCwgbGVhc2VIZWxkVGV4dCB9IGZyb20gXCIuLi9saWIvc3RvcmVFcnJvclwiO1xuaW1wb3J0IFwiLi9Db2RpbmdBZ2VudC5jc3NcIjtcblxuLy8gUi1BUkQtMTA6IHRoZSBjb3B5IGZvciBhIGRlYWQgc2V0dGluZ3Mgc3RvcmUgbmFtZXMgQk9USCBjb3N0cyDigJQgdGhlIGFtbmVzaWFcbi8vIChoaXN0b3J5IG5vdCByZS1zZW50KSBhbmQgdGhlIGR1cmFiaWxpdHkgY29uc2VxdWVuY2UgKGEgY2xvc2VkIHRhYiBsb3NlcyB0aGVcbi8vIHJ1bikuIE9uZSBjb25zdGFudCBzbyBhIGZvdXJ0aCBjYWxsIHNpdGUgY2Fubm90IHNoaXAgdGhlIG9sZCBjb3B5LlxuY29uc3QgTk9fU1RPUkVfU1VGRklYID1cbiAgXCIsIHNvIGVhY2ggbWVzc2FnZSBpcyBzZW50IHdpdGhvdXQgdGhlIGVhcmxpZXIgb25lcyDigJQgYW5kIGEgY2xvc2VkIHRhYiBsb3NlcyB0aGUgcnVuLCBub3QganVzdCB0aGUgaW4tZmxpZ2h0IHR1cm5cIjtcblxuLy8gUi1BUkQtMTBhOiB0aGUgY29weSBmb3IgYSBjaGVja3BvaW50LWFwcGVuZCByZWZ1c2FsIOKAlCB0aGUgcnVuIHN0b3BwZWQgQVQgYVxuLy8gYm91bmRhcnkgYW5kIGV2ZXJ5dGhpbmcgY2hlY2twb2ludGVkIHNvIGZhciBzdXJ2aXZlcy4gT25lIGhvbWUsIHVzZWQgYnkgYm90aFxuLy8gcnVuIHN1cmZhY2VzJ3Mgam91cm5hbC1mYWlsdXJlIGNhdGNoZXMuXG5jb25zdCBKT1VSTkFMX1JFRlVTQUxfU1VGRklYID1cbiAgXCIsIHNvIHRoZSBydW4gc3RvcHBlZCBhdCBpdHMgbGFzdCBjaGVja3BvaW50IOKAlCBub3RoaW5nIGFmdGVyIGl0IHdhcyBrZXB0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnZlcnNhdGlvblN0YWdlKCkge1xuICBjb25zdCBjYXRhbG9nID0gdXNlQ2F0YWxvZygpO1xuICBjb25zdCBtb3VudHMgPSB1c2VNb3VudHMoKTtcbiAgY29uc3Qgc3RvcmVSZWYgPSB1c2VSZWY8Q29udmVyc2F0aW9uU3RvcmUgfCBudWxsPihudWxsKTtcbiAgY29uc3QgY29udlJlZiA9IHVzZVJlZjxDb252ZXJzYXRpb24gfCBudWxsPihudWxsKTtcbiAgLy8gUjMtNjMxIOKAlCB0aGUgc2Vzc2lvbiBwcm9qZWN0aW9uIChDT05UUklCVVRFX1RSQU5TQ1JJUFRfU1BFQyDCpzMpOiB0aGUgd3JpdGVyIGFuZFxuICAvLyB0aGUgbmFtZWQtaGVhcnRiZWF0IHB1Ymxpc2hlciBvdmVyIGl0LiBPcGVuZWQvYnVpbHQgYmVzaWRlIHRoZSBzdG9yZSBvbiB0aGVcbiAgLy8gU0FNRSBzZXR0aW5ncyBtb3VudDsgYSBkZWFkIHdyaXRlciBjb3N0cyBvbmx5IHRoZSBmZWF0dXJlICh0aGUgaG9zdCBuZXZlciBzZWVzXG4gIC8vIGEgaGVhcnRiZWF0IOKHkiBuZXZlciBvZmZlcnMg4oeSIGZhaWwtY2xvc2VkKSwgbmV2ZXIgdGhlIGNvbnZlcnNhdGlvbi4gVGhlIHRyaWdnZXJcbiAgLy8gc2VtYW50aWNzIGxpdmUgaW4gYHNlc3Npb25Qcm9qZWN0aW9uLnRzYCAoZXh0cmFjdGVkIGxpa2UgYHN0YWdlU2VsZWN0aW9uLnRzYFxuICAvLyBzbyB0aGV5IGFyZSB0ZXN0YWJsZSB3aXRob3V0IGEgRE9NKTsgdGhpcyBjb21wb25lbnQgb25seSBuYW1lcyB0aGUgbW9tZW50cy5cbiAgY29uc3QgcHJvamVjdGlvblJlZiA9IHVzZVJlZjxTZXNzaW9uUHJvamVjdGlvbldyaXRlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBwdWJsaXNoZXJSZWYgPSB1c2VSZWY8UHJvamVjdGlvblB1Ymxpc2hlciB8IG51bGw+KG51bGwpO1xuICAvLyBSMy0yMjQgKMKnMy4zKTogdGhlIHN0b3AgYnV0dG9uJ3MgYWJvcnQgY29udHJvbGxlciBmb3IgdGhlIGluLWZsaWdodCBydW4uIEFib3J0aW5nXG4gIC8vIGl0IGhhbHRzIHRoZSBsb29wIEFORCB0ZWFycyBkb3duIHRoZSBpbi1mbGlnaHQgdXBzdHJlYW0gTExNIHJlcXVlc3QgKHN0b3BzIGJpbGxpbmcpLlxuICBjb25zdCBhYm9ydFJlZiA9IHVzZVJlZjxBYm9ydENvbnRyb2xsZXIgfCBudWxsPihudWxsKTtcbiAgLy8gUjMtMzMzOiB0aGUgbWlkLXJ1biBzdGVlcmluZyBxdWV1ZS4gU1RPUCAoYWJvdmUpIGVuZHMgdGhlIHJ1bjsgU1RFRVIgcmVkaXJlY3RzIGl0XG4gIC8vIHdpdGhvdXQgZGlzY2FyZGluZyB0aGUgdHJhbnNjcmlwdC4gT25lIGNvbnRyb2xsZXIgcGVyIHJ1biwgc28gYSBjb3JyZWN0aW9uIHRoZVxuICAvLyB1c2VyIHRvb2sgYmFjayBuZXZlciBsZWFrcyBpbnRvIHRoZSBuZXh0IG9uZS5cbiAgY29uc3Qgc3RlZXJSZWYgPSB1c2VSZWY8U3RlZXJDb250cm9sbGVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtxdWV1ZWQsIHNldFF1ZXVlZF0gPSB1c2VTdGF0ZTxyZWFkb25seSBTdGVlck1lc3NhZ2VbXT4oW10pO1xuICBjb25zdCBbc3RlZXJUZXh0LCBzZXRTdGVlclRleHRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsb2csIHNldExvZ10gPSB1c2VTdGF0ZTxMb2dFbnRyeVtdPihbXSk7XG4gIGNvbnN0IFtwcm9tcHQsIHNldFByb21wdF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0cmVhbWluZywgc2V0U3RyZWFtaW5nXSA9IHVzZVN0YXRlKFwiXCIpO1xuICAvLyBSMy0zMzUg4oCUIHRoZSBpbi1mbGlnaHQgcmVhc29uaW5nIGZvciB0aGUgY3VycmVudCB0dXJuIChjbGVhcmVkIHdoZW4gdGhlIHdob2xlIGJsb2NrXG4gIC8vIGFycml2ZXMgYW5kIGJlY29tZXMgYSB0cmFuc2NyaXB0IHJvdykuXG4gIGNvbnN0IFt0aGlua2luZywgc2V0VGhpbmtpbmddID0gdXNlU3RhdGUoXCJcIik7XG4gIC8vIFIzLTMzNiDigJQgdGhlIHJ1bidzIHRva2VuIGFjY291bnRpbmcsIGluY2x1ZGluZyBwcm9tcHQtY2FjaGUgcmVhZHMvd3JpdGVzIHdoZXJlIHRoZVxuICAvLyBwcm92aWRlciByZXBvcnRzIHRoZW0uIFN1cmZhY2luZyBpdCBpcyB3aGF0IG1ha2VzIGNhY2hpbmcgdmVyaWZpYWJsZSByYXRoZXIgdGhhblxuICAvLyBiZWxpZXZlZDsgd2l0aG91dCBhIG51bWJlciBvbiBzY3JlZW4gdGhlIGNvc3QgY2xhaW0gaXMgdW5mYWxzaWZpYWJsZS5cbiAgY29uc3QgW3VzYWdlLCBzZXRVc2FnZV0gPSB1c2VTdGF0ZTx7XG4gICAgc3BlbnRUb2tlbnM6IG51bWJlcjtcbiAgICBjYWNoZVJlYWRUb2tlbnM/OiBudW1iZXI7XG4gICAgY2FjaGVXcml0ZVRva2Vucz86IG51bWJlcjtcbiAgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcnVubmluZywgc2V0UnVubmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIC8vIFdoaWNoIGNvbnZlcnNhdGlvbiBhIHJ1biBpcyBpbiBmbGlnaHQgZm9yIOKAlCBhIHJlZiwgc28gdGhlIGFyYml0ZXIncyBwZXItaWQgcHJvYmUgY2FuXG4gIC8vIHJlYWQgaXQgd2l0aG91dCByZWJ1aWxkaW5nLiBTZXQgd2hlbiBhIHJ1biBzdGFydHMsIGNsZWFyZWQgd2hlbiBpdCBlbmRzLlxuICBjb25zdCBydW5uaW5nSWRSZWYgPSB1c2VSZWY8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgLy8gVGhlIGNvbnZlcnNhdGlvbiBjdXJyZW50bHkgc2hvd24g4oCUIGtleXMgdGhlIHRyYW5zY3JpcHQgc2Nyb2xsZXIgc28gYSBzd2l0Y2ggcmVzZXRzXG4gIC8vIGl0cyBmb2xsb3cgc3RhdGUgKGEgcmVsZWFzZSBpbiBvbmUgY29udmVyc2F0aW9uIG11c3Qgbm90IGNhcnJ5IGludG8gdGhlIG5leHQpLlxuICBjb25zdCBbY29udklkLCBzZXRDb252SWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuICAvLyBXaHkgcGVyc2lzdGVuY2UgaXMgdW5hdmFpbGFibGUsIGlmIGl0IGlzLiBUaGUgY29udmVyc2F0aW9uIHN0b3JlIGlzIG5vdCBhXG4gIC8vIG5pY2UtdG8taGF2ZTogYHJ1bigpYCByZWFkcyB0aGUgbW9kZWwncyBISVNUT1JZIG91dCBvZiB0aGUgcGVyc2lzdGVkXG4gIC8vIGNvbnZlcnNhdGlvbiwgc28gYSBkZWFkIHN0b3JlIHNpbGVudGx5IGRvd25ncmFkZXMgdGhlIGFnZW50IHRvIGEgc3RhdGVsZXNzXG4gIC8vIGNoYXRib3QgdGhhdCByZS1yZWFkcyBub3RoaW5nIGJldHdlZW4gdHVybnMuIFRoYXQgZmFpbHVyZSB1c2VkIHRvIGJlXG4gIC8vIHN3YWxsb3dlZCBieSBlbXB0eSBgY2F0Y2gge31gcyDigJQgc3VyZmFjZSBpdCBpbnN0ZWFkIChSMy0yNDcpLlxuICBjb25zdCBbc3RvcmVFcnJvciwgc2V0U3RvcmVFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgLyoqIFIzLTU2MSDigJQgYW5vdGhlciBmcmFtZSdzIHJ1biBsZWFzZSBpcyBsaXZlIG9uIHRoaXMgY29udmVyc2F0aW9uLiBSZW5kZXJzIGFzXG4gICAqICBhbiBPRkZFUiB0byB0YWtlIG92ZXIsIG5ldmVyIGFzIGEgYmxvY2sgKFItQVJELTE4YSk6IHRoZSBsZWFzZSBpcyBhZHZpc29yeSxcbiAgICogIHRoZSBob2xkZXIgbWF5IGJlIGEgd2luZG93IHRoYXQgbm8gbG9uZ2VyIGV4aXN0cywgYW5kIGEgaGFyZCBibG9jayBvbiBpdCBpcyBhXG4gICAqICBkZWFkIGVuZCB0aGUgdXNlciBjYW5ub3QgZXNjYXBlLiBDYXJyaWVzIHRoZSBhY3Rpb24gdGhhdCB3YXMgcmVmdXNlZCwgc29cbiAgICogIFwidGFrZSBvdmVyXCIgY29udGludWVzIHdoYXQgdGhlIHVzZXIgYXNrZWQgZm9yIHJhdGhlciB0aGFuIG1ha2luZyB0aGVtIGFza1xuICAgKiAgdHdpY2UuICovXG4gIGNvbnN0IFtsZWFzZUhlbGQsIHNldExlYXNlSGVsZF0gPSB1c2VTdGF0ZTxudWxsIHwgeyBjb252SWQ6IHN0cmluZzsgcmVzdW1lOiBib29sZWFuIH0+KG51bGwpO1xuICAvLyBSMy01NjA6IGFuIGludGVycnVwdGVkIHJ1biBkZXRlY3RlZCBvbiB0aGlzIGNvbnZlcnNhdGlvbiDigJQgdGhlIGpvdXJuYWwgc2F5c1xuICAvLyBhIHJ1biB3YXMgaW4gZmxpZ2h0IGFuZCBuZXZlciByZWFjaGVkIGl0cyBmaW5hbCBgcnVuRW5kYCBCNC4gUmVzdW1lIGlzXG4gIC8vIEFUVEVOREVEIChSLUFSRC0xNSk6IHJlbmRlcmluZyB0aGlzIGFmZm9yZGFuY2UgaXMgYWxsIHRoZSBib290IHBhdGggZG9lcztcbiAgLy8gbm8gbW9kZWwgY2FsbCwgbm8gZXhlY3V0b3IsIG5vdGhpbmcgdW50aWwgdGhlIHVzZXIgcGlja3MgYW4gYWN0aW9uLlxuICBjb25zdCBbcGVuZGluZ1Jlc3VtZSwgc2V0UGVuZGluZ1Jlc3VtZVN0YXRlXSA9IHVzZVN0YXRlPHsgY29udklkOiBzdHJpbmc7IHJlcGxheTogUmVwbGF5UmVzdWx0IH0gfCBudWxsPihudWxsKTtcbiAgLy8gUmVmIG1pcnJvciDigJQgdGhlIGF0dGVuZGVkIGdhdGUgaW4gcnVuKCkgbXVzdCByZWFkIHRoZSBDVVJSRU5UIHZhbHVlIGFmdGVyXG4gIC8vIGF3YWl0aW5nIGFuIGluLWZsaWdodCByZXBsYXksIHdoaWNoIGEgcmVuZGVyLWNsb3NlZCBzdGF0ZSB2YXJpYWJsZSBjYW5ub3QgZ2l2ZS5cbiAgY29uc3QgcGVuZGluZ1Jlc3VtZVJlZiA9IHVzZVJlZjx7IGNvbnZJZDogc3RyaW5nOyByZXBsYXk6IFJlcGxheVJlc3VsdCB9IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNldFBlbmRpbmdSZXN1bWUgPSAodjogeyBjb252SWQ6IHN0cmluZzsgcmVwbGF5OiBSZXBsYXlSZXN1bHQgfSB8IG51bGwpOiB2b2lkID0+IHtcbiAgICBwZW5kaW5nUmVzdW1lUmVmLmN1cnJlbnQgPSB2O1xuICAgIHNldFBlbmRpbmdSZXN1bWVTdGF0ZSh2KTtcbiAgfTtcbiAgLy8gVGhlIGJvb3QgcmVwbGF5IGN1cnJlbnRseSBpbiBmbGlnaHQsIGlmIGFueSDigJQgYHJ1bigpYCBtdXN0IG5vdCBzdGFydCBwYXN0IGFuXG4gIC8vIHVucmVzb2x2ZWQgaW50ZXJydXB0aW9uIGNoZWNrICh0aGUgVE9DVE9VIGhvbGU6IGEga2lja29mZiB0aGF0IHNsaXBzIGJldHdlZW5cbiAgLy8gdGhlIHJlcGxheSBjYWxsIGFuZCBpdHMgcmVzdWx0IHRha2VzIHRoZSByZXN0YXJ0LWFuZC1sb3NlLXRhaWwgcGF0aCkuXG4gIGNvbnN0IHJlcGxheUluRmxpZ2h0UmVmID0gdXNlUmVmPHsgY29udklkOiBzdHJpbmc7IHByb21pc2U6IFByb21pc2U8dm9pZD4gfSB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFIzLTYxNSDigJQgZm9sbG93IHRoZSBzdHJlYW0uIFRoZSB0cmFuc2NyaXB0IGFuZCB0aGUgbGl2ZSByZWFzb25pbmcgYm94IGVhY2ggcGluIHRvXG4gIC8vIHRoZWlyIG5ld2VzdCByb3cgd2hpbGUgdGhlIHJlYWRlciBpcyBhdCB0aGUgYm90dG9tLCBhbmQgc3RvcCB0aGUgbW9tZW50IHRoZXkgc2Nyb2xsXG4gIC8vIHVwIOKAlCByZXN1bWluZyBvbmx5IG9uIHJldHVybi4gVHdvIHNjcm9sbGVycywgb25lIGhvb2ssIGNhbGxlZCB0d2ljZS5cbiAgY29uc3QgbG9nUmVmID0gdXNlUmVmPEhUTUxVTGlzdEVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCByZWFzb25pbmdSZWYgPSB1c2VSZWY8SFRNTFNwYW5FbGVtZW50PihudWxsKTtcbiAgLy8gVGhlIHRyYW5zY3JpcHQgc2Nyb2xsZXIgZm9sbG93cyBldmVyeXRoaW5nIHRoYXQgZ3Jvd3MgaW5zaWRlIGl0IOKAlCB0aGUgc2V0dGxlZCByb3dzLFxuICAvLyB0aGUgbGl2ZSByZWFzb25pbmcgYmxvY2sgYW5kIHRoZSBsaXZlIHJlcGx5IOKAlCBzbyBpdCBpcyBrZXllZCBvbiBhbGwgdGhyZWUsIG5vdCBqdXN0XG4gIC8vIHRoZSBzZXR0bGVkIHJvd3MgKHRoZSBsaXZlIHJvd3Mgc3RyZWFtIHdpdGhvdXQgdG91Y2hpbmcgYGxvZ2ApLlxuICBjb25zdCB0cmFuc2NyaXB0RmxvdyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gW2xvZywgdGhpbmtpbmcsIHN0cmVhbWluZ10sXG4gICAgW2xvZywgdGhpbmtpbmcsIHN0cmVhbWluZ10sXG4gICk7XG4gIHVzZVN0aWNrVG9Cb3R0b20obG9nUmVmLCB0cmFuc2NyaXB0Rmxvdyk7XG4gIHVzZVN0aWNrVG9Cb3R0b20ocmVhc29uaW5nUmVmLCB0aGlua2luZyk7XG5cbiAgLy8gVGhlIFNUQUdFIGFwcCdzIHdvcmtpbmcgdHJlZSwgY29uZmVycmVkIGJ5IHRoZSBob3N0IGFzIGEgYHR5cGU6J3dvcmt0cmVlJ2AgbW91bnRcbiAgLy8gKEFBLTIzKSDigJQgTk9UIHRoZSBhZ2VudCdzIE9XTiByZXBvLiBJZiBpdCBpc24ndCBjb25mZXJyZWQgKHRoZSBtb3VudCBoYXNuJ3QgYXJyaXZlZCxcbiAgLy8gY2h1cm5lZCBhd2F5LCBvciBubyBhcHAgaXMgbG9hZGVkKSwgdGhpcyBpcyBgbnVsbGAgYW5kIHdlIE1VU1QgTk9UIGZhbGwgYmFjayB0byB0aGVcbiAgLy8gYWdlbnQncyBvd24gcmVwbzogZG9pbmcgc28gbWFkZSB0aGUgd29ya2JlbmNoIHNpbGVudGx5IGF1dGhvciAqaXRzZWxmKiAoZXZlcnlcbiAgLy8gc3RhZ2UtYXBwIHBhdGggcmVhZCBgbm90IGZvdW5kYCwgYW5kIHRoZSBtb2RlbCBmbG91bmRlcmVkKS4gUmUtZGVyaXZlZCB3aGVuIHRoZVxuICAvLyBjb25mZXJyZWQgbW91bnQgY2hhbmdlcyAoc3dpdGNoaW5nIHRoZSBsb2FkZWQgYXBwIHRlYXJzIGRvd24gdGhlIG9sZCBwb3J0LCBtaW50cyBuZXcpLlxuICBjb25zdCBzdGFnZVRyZWUgPSB1c2VNZW1vKCgpID0+IGZpbmRDb25mZXJyZWRXb3JrdHJlZShtb3VudHMsIGdldEFwcE1vdW50UGF0aCgpKSwgW21vdW50c10pO1xuXG4gIC8vIFRvb2xzIGdpdmVuIHRvIHRoZSBtb2RlbC4gV2l0aG91dCB0aGUgc3RhZ2UgdHJlZSB0aGUgYWdlbnQgZ2V0cyB0aGUgY2F0YWxvZyBPTkxZIOKAlFxuICAvLyBubyBmaWxlc3lzdGVtIHRvb2xzIOKAlCBzbyBpdCBjYW4gbmV2ZXIgZWRpdCB0aGUgd3JvbmcgKGl0cyBvd24pIHJlcG8uIFJ1biBpcyBnYXRlZFxuICAvLyBiZWxvdyBhbmQgYSBcIndvcmtzcGFjZSBub3QgcmVhZHlcIiBub3RpY2UgaXMgc2hvd24uXG4gIC8vIFIzLTMzOSDigJQgZG9lcyB0aGUgbW9kZWwgdGhlIHVzZXIgY29uZmlndXJlZCBhY2NlcHQgaW1hZ2VzPyBUaGUgdG9vbCBpcyB0b2xkLCBzbyBhXG4gIC8vIGByZWFkX2ZpbGVgIG9uIGEgUE5HIGNhbiBTQVkgdGhlIG1vZGVsIGNhbm5vdCBsb29rIGF0IGl0IGluc3RlYWQgb2Ygc2VuZGluZ1xuICAvLyBzb21ldGhpbmcgdGhhdCBlcnJvcnMgdXBzdHJlYW0uIFJlLXJlYWQgd2hlbiB0aGUgcHJvdmlkZXIgY2hhbmdlcy5cbiAgY29uc3QgdmlzaW9uID0gdXNlTWVtbygoKSA9PiBkZXNjcmliZUNoYXQoKT8uZmVhdHVyZXMudmlzaW9uID09PSB0cnVlLCBbXSk7XG5cbiAgY29uc3QgeyB0b29sc2V0LCBza2lsbHMgfSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIC8vIE5vIGNvbmZlcnJlZCBzdGFnZSB0cmVlIOKHkiBhIGNhdGFsb2ctb25seSB0b29sc2V0IHdpdGggbm8gYXV0aG9yaW5nIHRvb2xzLCBzb1xuICAgIC8vIGB3aXRoU2tpbGxzYCBvZmZlcnMgbm90aGluZyBhbmQgYGxvYWRfc2tpbGxgIGlzIGFic2VudCDigJQgdGhlIGF1dGhvcmluZyBza2lsbHNcbiAgICAvLyB3b3VsZCBiZSBhZHZpY2UgdGhlIGFnZW50IGNhbm5vdCBhY3Qgb24gKFIzLTMzMSkuXG4gICAgaWYgKCFzdGFnZVRyZWUpIHJldHVybiB3aXRoU2tpbGxzKGNhdGFsb2dUb29sc2V0KGNhdGFsb2cpKTtcbiAgICBjb25zdCBmc1Rvb2xzID0gY3JlYXRlRnNUb29sc2V0KHsgcm9vdDogc3RhZ2VUcmVlLnJvb3QsIHJlYWRPbmx5OiBzdGFnZVRyZWUucmVhZE9ubHksIHZpc2lvbiB9KTtcbiAgICBjb25zdCBwcm9qZWN0VG9vbHMgPSBjcmVhdGVQcm9qZWN0VG9vbHNldCh7IHJvb3Q6IHN0YWdlVHJlZS5yb290LCByZWFkT25seTogc3RhZ2VUcmVlLnJlYWRPbmx5IH0pO1xuICAgIGNvbnN0IGRpYWdub3N0aWNzVG9vbHMgPSBjcmVhdGVEaWFnbm9zdGljc1Rvb2xzZXQoKTtcbiAgICAvLyBSMy0zMzI6IGdpdC1SRUFEIG92ZXIgdGhlIHNhbWUgd29ya2luZyB0cmVlLiBFbXB0eSAoYW5kIHRoZXJlZm9yZSBpbnZpc2libGUgdG9cbiAgICAvLyB0aGUgbW9kZWwpIHVubGVzcyB0aGUgYXBwIGhvbGRzIGB2Y3M6cmVhZGAuXG4gICAgY29uc3QgZ2l0VG9vbHMgPSBjcmVhdGVHaXRUb29sc2V0KHsgY2F0YWxvZyB9KTtcbiAgICAvLyBgd2l0aFNraWxsc2Agc3RheXMgTEFTVCAoUjMtMzMxKTogd2hpY2ggaG9zdCBza2lsbHMgYXJlIG9mZmVyZWQgZGVwZW5kcyBvbiB0aGVcbiAgICAvLyBmaW5hbCBtZXJnZWQgdG9vbCBsaXN0LCBzbyBpdCBoYXMgdG8gc2VlIHRoZSBnaXQgdG9vbHMgdG9vLlxuICAgIHJldHVybiB3aXRoU2tpbGxzKG1lcmdlVG9vbHNldHMoY2F0YWxvZ1Rvb2xzZXQoY2F0YWxvZyksIGZzVG9vbHMsIHByb2plY3RUb29scywgZGlhZ25vc3RpY3NUb29scywgZ2l0VG9vbHMpKTtcbiAgfSwgW2NhdGFsb2csIHN0YWdlVHJlZSwgdmlzaW9uXSk7XG5cbiAgY29uc3QgYXBwZW5kID0gKGU6IExvZ0VudHJ5KSA9PiBzZXRMb2coKGwpID0+IFsuLi5sLCBlXSk7XG5cbiAgLy8gUjMtNTYxIC8gUi1BUkQtMTg6IHJlZnJlc2ggdGhlIGxlYXNlIG9uIGFuIGludGVydmFsIHdoaWxlIHRoZSBydW4gZXhlY3V0ZXMuXG4gIC8vIFNoYXJlZCB3aXRoIENvZGluZ0FnZW50IOKAlCB0aGUgb3RoZXIgcnVuIHN1cmZhY2Ug4oCUIHJhdGhlciB0aGFuIGxpdmluZyBoZXJlOyBzZWVcbiAgLy8gYHVzZUxlYXNlUmVmcmVzaGAgZm9yIHdoeSB0aGUgYm91bmRhcnkgYXBwZW5kcyBhcmUgbm90IGVub3VnaCBvbiB0aGVpciBvd24sXG4gIC8vIGFuZCBmb3Igd2h5IHRoaXMgbG9vcCBkb2VzIE5PVCByYWlzZSB0aGUgdGFrZW92ZXIgb2ZmZXIgKGl0IGNhbm5vdDogdGhlIGJhbm5lclxuICAvLyByZW5kZXJzIG9ubHkgd2hlbiB0aGUgcnVuIGlzIG5vdCBydW5uaW5nKS4gQSBsb3N0IGxlYXNlIGlzIHN1cmZhY2VkIGJ5IHRoZVxuICAvLyBydW4ncyBvd24gY2F0Y2ggYmVsb3csIGZyb20gdGhlIHR5cGVkIGNvZGUgYGFwcGVuZGAgcmVqZWN0cyB3aXRoLlxuICB1c2VMZWFzZVJlZnJlc2goc3RvcmVSZWYsIHJ1bm5pbmdJZFJlZiwgcnVubmluZyk7XG5cbiAgLyoqXG4gICAqIFIzLTU2MSDigJQgaGFuZCB0aGUgcnVuJ3MgbGVhc2UgYmFjaywgZnJvbSBib3RoIHJ1biBwYXRocy5cbiAgICpcbiAgICogT05FIGZ1bmN0aW9uIGJlY2F1c2UgdGhlcmUgd2VyZSB0d28gY29waWVzIGFuZCB0aGUgc2Vjb25kIGhhZCBhbHJlYWR5IGRyaWZ0ZWQ6XG4gICAqIGBydW5gJ3MgZmlyZWQgaXQsIGByZXN1bWVSdW5gJ3MgYXdhaXRlZCBpdCwgYW5kIHRoZSBwYXJhZ3JhcGggYXJndWluZyBhZ2FpbnN0XG4gICAqIGF3YWl0aW5nIGhhZCBiZWVuIGRyb3BwZWQgZnJvbSB0aGUgc2Vjb25kIGNvcHkuIFRoZSBmaWxlIGhlbGQgdGhlIGFyZ3VtZW50IGFuZFxuICAgKiBpdHMgdmlvbGF0aW9uIG5pbmV0eSBsaW5lcyBhcGFydC5cbiAgICpcbiAgICogSXQgcmVsZWFzZXMgYHJ1bm5pbmdJZFJlZmAsIE5PVCBgY29udlJlZmAg4oCUIHRoZSBjb252ZXJzYXRpb24gdGhlIFJVTiBoZWxkLCBub3RcbiAgICogdGhlIG9uZSBvbiBzY3JlZW4uIFNlbGVjdGluZyBhbm90aGVyIGNvbnZlcnNhdGlvbiBtaWQtcnVuIHNldHMgYGNvbnZSZWZgXG4gICAqIChgc3RhZ2VTZWxlY3Rpb25gOiBcImEgcnVuIGZvciBhIGRpZmZlcmVudCBjb252ZXJzYXRpb24gZG9lcyBub3QgZ2F0ZSB0aGVcbiAgICogcmVsb2FkXCIpIHdoaWxlIHRoZSBsb29wIGtlZXBzIGdvaW5nLCBzbyByZWxlYXNpbmcgd2hhdCBpcyBvbiBzY3JlZW4gZnJlZWRcbiAgICogbm90aGluZyBhbmQgbGVmdCB0aGUgcmVhbCBsZWFzZSB0byBzaXQgb3V0IGl0cyBmdWxsIFRUTCDigJQgb2ZmZXJpbmcgYSBzZWNvbmRcbiAgICogd2luZG93IGEgdGFrZW92ZXIgb2YgYSBydW4gdGhhdCBoYWQgYWxyZWFkeSBmaW5pc2hlZCwgd2hpY2ggaXMgdGhlIG9uZSB0aGluZ1xuICAgKiB0aGlzIGNhbGwgZXhpc3RzIHRvIHByZXZlbnQuIENhbGxlcnMgaW52b2tlIGl0IEJFRk9SRSBjbGVhcmluZyBgcnVubmluZ0lkUmVmYC5cbiAgICpcbiAgICogRmlyZWQsIG5ldmVyIGF3YWl0ZWQuIEZhaWxpbmcgdG8gcnVuIGF0IGFsbCBpcyBhbHJlYWR5IHRoZSBleHBlY3RlZCBjYXNlIChub1xuICAgKiB1bmxvYWQgaGFuZGxlciByZWFjaGVzIGl0KSwgc28gbWFraW5nIGEgcnVuJ3MgcHJvbWlzZSB3YWl0IG9uIGEgZGV2aWNlLWxvY2FsXG4gICAqIHJlYWQgKyB1bmxpbmsgd2l0aCBubyBkZWFkbGluZSB3b3VsZCBidXkgbm90aGluZyBhbmQgY291bGQgbGVhdmUgaXQgcGVuZGluZyDigJRcbiAgICogdGhlIGFyZ3VtZW50IGBBUFBFTkRfVElNRU9VVF9NU2AgbWFrZXMgb25lIGZpbGUgb3Zlci4gVGhlIFRUTCBhbmQgc2FtZS10YWJcbiAgICogcmVjbGFpbSBhcmUgd2hhdCBhY3R1YWxseSBmcmVlIGEgbGVhc2UuXG4gICAqL1xuICBjb25zdCByZWxlYXNlSGVsZExlYXNlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBjb25zdCBpZCA9IHJ1bm5pbmdJZFJlZi5jdXJyZW50O1xuICAgIGlmIChzdG9yZSAmJiBpZCkgdm9pZCBzdG9yZS5yZWxlYXNlUnVuKGlkKS5jYXRjaCgoKSA9PiB7fSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBzaG93Q29udmVyc2F0aW9uID0gdXNlQ2FsbGJhY2soKGNvbnY6IENvbnZlcnNhdGlvbikgPT4ge1xuICAgIGNvbnZSZWYuY3VycmVudCA9IGNvbnY7XG4gICAgc2V0Q29udklkKGNvbnYuaWQpO1xuICAgIHNldFRpdGxlKGNvbnYudGl0bGUpO1xuICAgIHNldExvZyhtZXNzYWdlc1RvTG9nKGNvbnYubWVzc2FnZXMpKTtcbiAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgcHVibGlzaGVyUmVmLmN1cnJlbnQ/Lm9uU2hvdygpO1xuICAgIC8vIFIzLTU2MDogaXMgdGhlcmUgYW4gaW50ZXJydXB0ZWQgcnVuIG9uIHRoaXMgY29udmVyc2F0aW9uPyBSZWFkIHRoZSBKT1VSTkFMXG4gICAgLy8gKG5vdCB3YXJtIHN0YXRlKSBhbmQgb2ZmZXIgdGhlIGF0dGVuZGVkIGNob2ljZXMgaWYgc28uIFJlYWQtb25seSDigJQgdGhlXG4gICAgLy8gYm9vdCBwYXRoIGV4ZWN1dGVzIG5vdGhpbmcgKEctQVJELTQpLiBXaGVuIGludGVycnVwdGVkLCB0aGUgdHJhbnNjcmlwdFxuICAgIC8vIHJlbmRlcmVkIGlzIHRoZSBSRVBMQVlFRCBvbmUg4oCUIHRoZSByZWNvcmQgYWxvbmUgaXMgZm9sZGVkIHRocm91Z2ggdGhlIGxhc3RcbiAgICAvLyBydW4gZW5kIGFuZCB3b3VsZCBzaG93IGEgYmxhbmsvc3RhbGUgdmlldyBvdmVyIGEgbGl2ZSB0YWlsIChSLUFSRC0xNSkuXG4gICAgc2V0UGVuZGluZ1Jlc3VtZShudWxsKTtcbiAgICAvLyBSMy01NjE6IHRoZSB0YWtlb3ZlciBvZmZlciBiZWxvbmdzIHRvIHRoZSBjb252ZXJzYXRpb24gdGhhdCByYWlzZWQgaXQuIExlZnRcbiAgICAvLyBzdGFuZGluZyBhY3Jvc3MgYSBzd2l0Y2ggaXQgd291bGQgdGFrZSBvdmVyIHRoZSBORVcgb25lIOKAlCBgdGFrZU92ZXJSdW5gXG4gICAgLy8gZGVsaWJlcmF0ZWx5IGNvbnN1bHRzIG5vIHN0b3JlZCBsZWFzZSwgc28gaXQgd291bGQgZXZpY3QgYSBsaXZlIGhvbGRlciBvZiBhXG4gICAgLy8gY29udmVyc2F0aW9uIHRoZSB1c2VyIG5ldmVyIGFza2VkIGFib3V0LiBDbGVhcmVkIGhlcmUsIGFuZCB0aGUgcmVuZGVyIGJlbG93XG4gICAgLy8gY2FycmllcyBhIGBjb252SWRgIGd1YXJkIHRoZSB3YXkgYHBlbmRpbmdSZXN1bWVgIGRvZXMuXG4gICAgc2V0TGVhc2VIZWxkKG51bGwpO1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBpZiAoc3RvcmU/Lmhhc0pvdXJuYWwoKSkge1xuICAgICAgY29uc3QgcHJvbWlzZSA9IHN0b3JlXG4gICAgICAgIC5yZXBsYXkoY29udi5pZClcbiAgICAgICAgLnRoZW4oKHIpID0+IHtcbiAgICAgICAgICBpZiAoY29udlJlZi5jdXJyZW50Py5pZCAhPT0gY29udi5pZCB8fCBydW5uaW5nSWRSZWYuY3VycmVudCAhPT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICAgIGlmICghaW50ZXJydXB0ZWQocikpIHJldHVybjtcbiAgICAgICAgICBzZXRMb2cobWVzc2FnZXNUb0xvZyhyLm1lc3NhZ2VzKSk7XG4gICAgICAgICAgc2V0UGVuZGluZ1Jlc3VtZSh7IGNvbnZJZDogY29udi5pZCwgcmVwbGF5OiByIH0pO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICAvLyBSLUFSRC0xNCAvIMKnOTogYSByZWZ1c2VkIGpvdXJuYWwgKGNvcnJ1cHQvc2NoZW1hL2luY29oZXJlbnQpIG1lYW5zXG4gICAgICAgICAgLy8gdGhlIGNvbnZlcnNhdGlvbiBpcyBVTi1SRVNVTUFCTEUg4oCUIHNheSB0aGUgcmVzdW1lIHdhcyB3aXRoaGVsZCxcbiAgICAgICAgICAvLyBuZXZlciBzaWxlbnRseSBiZXN0LWVmZm9ydCBpdC4gT3RoZXIgZmFpbHVyZXMgYXJlIHN0b3JlIGZhdWx0cy5cbiAgICAgICAgICBpZiAoY29udlJlZi5jdXJyZW50Py5pZCAhPT0gY29udi5pZCkgcmV0dXJuO1xuICAgICAgICAgIGlmIChpc0pvdXJuYWxSZWZ1c2FsKGUpKSB7XG4gICAgICAgICAgICBhcHBlbmQoe1xuICAgICAgICAgICAgICBraW5kOiBcImVycm9yXCIsXG4gICAgICAgICAgICAgIHRleHQ6IFwiVGhpcyBjb252ZXJzYXRpb24ncyBjaGVja3BvaW50IGpvdXJuYWwgY2FuJ3QgYmUgcmVhZCwgc28gaXRzIGludGVycnVwdGVkIHJ1biBjYW4ndCBiZSByZXN1bWVkIOKAlCB0aGUgc2F2ZWQgY29udmVyc2F0aW9uIHN0aWxsIG9wZW5zLlwiLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgLy8gUHJvbWlzZS1pZGVudGl0eSwgbm90IGNvbnZJZDogYSBzYW1lLWNvbnZlcnNhdGlvbiByZS1zZWxlY3QgKHRoZVxuICAgICAgICAgIC8vIHBhbmVsJ3MgcmVwYWlyIGdlc3R1cmUpIHN0YXJ0cyBhIE5FV0VSIHJlcGxheSB3aG9zZSBtYXJrZXIgdGhlIG9sZGVyXG4gICAgICAgICAgLy8gcHJvbWlzZSdzIGZpbmFsbHkgbXVzdCBub3QgY2xlYXIuXG4gICAgICAgICAgaWYgKHJlcGxheUluRmxpZ2h0UmVmLmN1cnJlbnQ/LnByb21pc2UgPT09IHByb21pc2UpIHJlcGxheUluRmxpZ2h0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9KTtcbiAgICAgIHJlcGxheUluRmxpZ2h0UmVmLmN1cnJlbnQgPSB7IGNvbnZJZDogY29udi5pZCwgcHJvbWlzZSB9O1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIC8vIE9uZSBhcmJpdGVyIHBlciBtb3VudCAobmV2ZXIgbW9kdWxlIHNjb3BlKTogaXQgaG9sZHMgdGhlIGhlbGQgc2VsZWN0aW9uIGFuZCB0aGVcbiAgLy8gbGF0ZXN0LXdpbnMgdGlja2V0LCBhbmQgaXMgY3JlYXRlZCBmcmVzaCBzbyBhIHJlbW91bnQgc3RhcnRzIGNsZWFuLiBDcmVhdGVkIGluIGFuXG4gIC8vIGVmZmVjdCByYXRoZXIgdGhhbiBkdXJpbmcgcmVuZGVyIOKAlCBgc2hvd2AgPSBgc2hvd0NvbnZlcnNhdGlvbmAgd3JpdGVzIGBjb252UmVmYCwgYW5kXG4gIC8vIHRoZSBSZWFjdCBDb21waWxlcidzIGByZWZzYCBydWxlIGZvcmJpZHMgYSByZWYgYWNjZXNzIChvciBhIGZ1bmN0aW9uIGNhcnJ5aW5nIG9uZSlcbiAgLy8gZnJvbSByZWFjaGluZyBhIHJlbmRlciBwYXRoLlxuICBjb25zdCBzdGFnZVNlbGVjdGlvblJlZiA9IHVzZVJlZjxTdGFnZVNlbGVjdGlvbiB8IG51bGw+KG51bGwpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0YWdlU2VsZWN0aW9uUmVmLmN1cnJlbnQgPSBjcmVhdGVTdGFnZVNlbGVjdGlvbih7XG4gICAgICBzaG93OiBzaG93Q29udmVyc2F0aW9uLFxuICAgICAgaXNSdW5uaW5nOiAoaWQpID0+IHJ1bm5pbmdJZFJlZi5jdXJyZW50ID09PSBpZCxcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RhZ2VTZWxlY3Rpb25SZWYuY3VycmVudCA9IG51bGw7XG4gICAgfTtcbiAgfSwgW3Nob3dDb252ZXJzYXRpb25dKTtcblxuICAvLyBUaGUgU0NPUElORyBLRVkg4oCUIHRoZSByZXBvIGNvbnZlcnNhdGlvbnMgYXJlIHN0YW1wZWQgd2l0aCBhbmQgcGFydGl0aW9uZWQgYnkuXG4gIC8vXG4gIC8vIFJlYWQgZnJvbSB0aGUgYmFzZWxpbmUgd29ya3NwYWNlIGNoYW5uZWwgKFIzLTQ5MSksIE5PVCBmcm9tIGBzdGFnZVRyZWUucmVwb2AsXG4gIC8vIGV2ZW4gdGhvdWdoIGJvdGggYXJlIHRoZSBzYW1lIHN0cmluZyAoUi1VQUEtMTYpLiBUaGUgc3RhbXAgYW5kIHRoZSBwYW5lbCdzIHNjb3BlXG4gIC8vIGhhdmUgdG8gY29tZSBmcm9tIE9ORSBzb3VyY2U6IHRoZXkgYXJlIGNvbXBhcmVkIGZvciBlcXVhbGl0eSwgc28gdGhlIGRheSB0aGUgdHdvXG4gIC8vIGRlcml2YXRpb25zIGRpdmVyZ2UgZXZlcnkgZXhpc3Rpbmcgc3RhbXAgc2lsZW50bHkgc3RvcHMgbWF0Y2hpbmcgYW5kIGV2ZXJ5XG4gIC8vIGNvbnZlcnNhdGlvbiBsYW5kcyB1bmRlciBcIk90aGVyIHJlcG9zaXRvcmllc1wiIOKAlCB3aGljaCBpcyB0aGUgUjMtNDc1IGJ1ZywganVzdFxuICAvLyBhcnJpdmVkIGJ5IGEgZGlmZmVyZW50IHJvdXRlLiBgc3RhZ2VUcmVlYCBzdGF5cyB3aGF0IGl0IGlzIGFjdHVhbGx5IGZvcjogdGhlXG4gIC8vIGZpbGVzeXN0ZW0gcm9vdCB0aGUgYWdlbnQgYXV0aG9ycy5cbiAgY29uc3Qgd29ya3NwYWNlUmVwbyA9IHVzZVdvcmtzcGFjZSgpPy5sYWJlbDtcblxuICAvLyBSZWFkYWJsZSBmcm9tIHRoZSBib290IGVmZmVjdCBiZWxvdyB3aXRob3V0IHJlLXJ1bm5pbmcgaXQgd2hlbiB0aGUgd29ya3NwYWNlXG4gIC8vIGFycml2ZXMgKHRoZSBlZmZlY3Qgb3BlbnMgdGhlIHN0b3JlIE9OQ0U7IHRoZSBmYWxsYmFjayBzaW1wbHkgdXNlcyB3aGF0ZXZlciByZXBvXG4gIC8vIGlzIGtub3duIGF0IHRoYXQgbW9tZW50IOKAlCB0aGUgcGFuZWwncyBzZWxlY3QgY29ycmVjdHMgaXQpLlxuICBjb25zdCBzdGFnZVJlcG9SZWYgPSB1c2VSZWYod29ya3NwYWNlUmVwbyk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc3RhZ2VSZXBvUmVmLmN1cnJlbnQgPSB3b3Jrc3BhY2VSZXBvO1xuICB9LCBbd29ya3NwYWNlUmVwb10pO1xuXG4gIC8vIE9wZW4gdGhlIHN0b3JlOyBpZiBubyBzZWxlY3Rpb24gYXJyaXZlcywgc2hvdyB0aGUgbmV3ZXN0IElOIFNDT1BFIChSMy00NzUg4oCUXG4gIC8vIHRoZSBzYW1lIHJlcG8gcGFydGl0aW9uIHRoZSBwYW5lbCBhcHBsaWVzKSBzbyB0aGUgc3RhZ2UgaXNuJ3QgYmxhbmsgYW5kIG5ldmVyXG4gIC8vIHNlZWRzIGl0c2VsZiB3aXRoIGFub3RoZXIgcmVwbydzIGNvbnZlcnNhdGlvbi4gVGhlIGFyYml0ZXIgb3ducyB3aGljaCBvZiB0aGVcbiAgLy8gaGVsZCBzZWxlY3Rpb24gLyBuZXdlc3QgZmFsbGJhY2sgd2lucywgc28gYSBzZWxlY3Rpb24gdGhhdCBsYW5kZWQgYmVmb3JlIHRoZVxuICAvLyBzdG9yZSBvcGVuZWQgaXMgbm90IGRyb3BwZWQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGxpdmUgPSB0cnVlO1xuICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXdhaXQgb3BlbkNvbnZlcnNhdGlvblN0b3JlKCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzdG9yZVJlZi5jdXJyZW50ID0gc3RvcmU7XG4gICAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICAgIGF3YWl0IHN0YWdlU2VsZWN0aW9uUmVmLmN1cnJlbnQhLnN0b3JlT3BlbmVkKHN0b3JlLCBzdGFnZVJlcG9SZWYuY3VycmVudCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIFNpZ25lZCBvdXQgaXMgdGhlIG9yZGluYXJ5IGNhc2U7IGFueXRoaW5nIGVsc2UgaXMgYSByZWFsIGZhdWx0IHRoZSB1c2VyXG4gICAgICAgIC8vIG11c3Qgc2VlLCBiZWNhdXNlIGl0IGNvc3RzIHRoZW0gY29udmVyc2F0aW9uIG1lbW9yeS5cbiAgICAgICAgaWYgKGxpdmUpIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICAvLyBSMy02MzEg4oCUIG9wZW4gdGhlIHByb2plY3Rpb24gd3JpdGVyIG9uIHRoZSBzYW1lIG1vdW50LCBpbmRlcGVuZGVudGx5OiBhXG4gICAgLy8gc3RvcmUgdGhhdCBmYWlscyB3aGlsZSB0aGUgd3JpdGVyIG9wZW5zIChvciB2aWNlIHZlcnNhKSBkZWdyYWRlcyBleGFjdGx5IG9uZVxuICAgIC8vIG9mIHRoZSB0d28gc3VyZmFjZXMuIFRoZSBwdWJsaXNoZXIgaXMgYnVpbHQgaGVyZSAobm90IGR1cmluZyByZW5kZXIpIHNvIG5vXG4gICAgLy8gcmVmLWNhcnJ5aW5nIGZ1bmN0aW9uIHJlYWNoZXMgYSByZW5kZXIgcGF0aC5cbiAgICBwcm9qZWN0aW9uUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50ID0gY3JlYXRlUHJvamVjdGlvblB1Ymxpc2hlcihcbiAgICAgICgpID0+IHByb2plY3Rpb25SZWYuY3VycmVudCxcbiAgICAgICgpID0+ICh7IGNvbnY6IGNvbnZSZWYuY3VycmVudCwgcnVubmluZ0lkOiBydW5uaW5nSWRSZWYuY3VycmVudCB9KSxcbiAgICApO1xuICAgIHZvaWQgb3BlblNlc3Npb25Qcm9qZWN0aW9uV3JpdGVyKClcbiAgICAgIC50aGVuKCh3KSA9PiB7XG4gICAgICAgIGlmIChsaXZlKSB7XG4gICAgICAgICAgcHJvamVjdGlvblJlZi5jdXJyZW50ID0gdztcbiAgICAgICAgICAvLyBDYXRjaC11cDogdGhlIHN0b3JlJ3Mgb3BlbiBhbmQgdGhlIHdyaXRlcidzIG9wZW4gYXJlIGluZGVwZW5kZW50XG4gICAgICAgICAgLy8gcm91bmQtdHJpcHMg4oCUIGlmIHRoZSBzdGFnZSBhbHJlYWR5IHNob3dlZCBhIGNvbnZlcnNhdGlvbiB3aGlsZSB0aGlzXG4gICAgICAgICAgLy8gd2FzIGluIGZsaWdodCwgdGhhdCBvblNob3cgZm91bmQgbm8gd3JpdGVyIGFuZCBkcm9wcGVkIGl0cyBoZWFydGJlYXRcbiAgICAgICAgICAvLyAoZmFpbC1jbG9zZWQsIGJ1dCB0aGUgcHJvamVjdGlvbiBzaG91bGQgbm90IGRlcGVuZCBvbiBvcGVuIG9yZGVyKS5cbiAgICAgICAgICAvLyBSZS1wdWJsaXNoZXMgY3VycmVudCBzdGF0ZSBvbmNlOyBwZXItaWQgcnVubmluZyBnYXRlOyBhIG51bGwgY29udlxuICAgICAgICAgIC8vIHB1Ymxpc2hlcyB0aGUgaGFybWxlc3MgZXhwbGljaXQtaW5hY3RpdmUgZG9jLlxuICAgICAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblNob3coKTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICAvLyBObyBwcm9qZWN0aW9uIOKHkiB0aGUgaG9zdCBuZXZlciBvZmZlcnMgYSB0cmFuc2NyaXB0IOKHkiBmYWlsLWNsb3NlZC5cbiAgICAgICAgLy8gTG9nZ2VkLWFuZC1kcm9wcGVkIChSMyk6IGEgcGVyc2lzdGVudCBmYXVsdCBzaG91bGQgYmUgdmlzaWJsZSBzb21ld2hlcmUuXG4gICAgICAgIGNvbnNvbGUud2Fybignc2Vzc2lvbiBwcm9qZWN0aW9uIHdyaXRlciB1bmF2YWlsYWJsZSAodHJhbnNjcmlwdCBvZmZlcnMgc3RheSBvZmYpJywgZSk7XG4gICAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgbGl2ZSA9IGZhbHNlO1xuICAgICAgLy8gVW5tb3VudCDih5IgZXhwbGljaXQgaW5hY3RpdmUgZG9jIChiZXN0LWVmZm9ydDsgaWYgdGhlIHdyaXRlIGxvc2VzIHRoZSByYWNlXG4gICAgICAvLyB3aXRoIHRlYXJkb3duLCB0aGUgaG9zdCdzIFRUTCBleHBpcmVzIHRoZSBsYXN0IGhlYXJ0YmVhdCBpbnN0ZWFkKS5cbiAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblVubW91bnQoKTtcbiAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHByb2plY3Rpb25SZWYuY3VycmVudCA9IG51bGw7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vIFRoZSBwYW5lbCBkcml2ZXMgd2hpY2ggY29udmVyc2F0aW9uIGlzIHNob3duLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiBvblJlZ2lvbk1lc3NhZ2UoKG0pID0+IHtcbiAgICAgIGlmIChpc1NlbGVjdChtLmRhdGEpKSB2b2lkIHN0YWdlU2VsZWN0aW9uUmVmLmN1cnJlbnQhLnNlbGVjdChtLmRhdGEuaWQpO1xuICAgIH0pO1xuICB9LCBbXSk7XG5cbiAgLy8gQXNrIHRoZSBwYW5lbCB3aGF0IGl0IGhhcyBzZWxlY3RlZCwgb25jZSwgb24gbW91bnQgKFIzLTI0MykuXG4gIC8vXG4gIC8vIEEgYHNlbGVjdC1jb252ZXJzYXRpb25gIGNhbiBiZSBzZW50IHdoaWxlIHRoaXMgcmVnaW9uIGRvZXMgbm90IGV4aXN0OiBvbiBtb2JpbGVcbiAgLy8gdGhlIHBhbmVsIGFuZCB0aGUgc3RhZ2UgYXJlIGRpZmZlcmVudCBDT0xVTU5TLCBhbmQgYW4gdW52aXNpdGVkIGNvbHVtbiByZW5kZXJzIGFcbiAgLy8gc2tlbGV0b24gd2l0aCBubyBpZnJhbWUg4oCUIHNvIHRoZSB0YXAgdGhhdCByZXZlYWxzIHRoaXMgcGFuZSBpcyBhbHNvIHRoZSB0YXAgd2hvc2VcbiAgLy8gc2VsZWN0aW9uIGhhZCBub3doZXJlIHRvIGxhbmQuIFdpdGhvdXQgdGhpcyBoYW5kc2hha2UgdGhlIGZhbGxiYWNrIGFib3ZlIHdvdWxkXG4gIC8vIHdpbiBhbmQgc2hvdyB0aGUgbmV3ZXN0IGNvbnZlcnNhdGlvbiBpbnN0ZWFkIG9mIHRoZSB0YXBwZWQgb25lLlxuICAvL1xuICAvLyBTdWJzY3JpYmVkIEJFRk9SRSB0aGUgYXNrICh0aGUgbGlzdGVuZXIgYWJvdmUgaXMgYWxyZWFkeSBpbnN0YWxsZWQgYnkgdGhlIHRpbWVcbiAgLy8gdGhpcyBlZmZlY3QgcnVucyksIHNvIHRoZSByZXBseSBjYW5ub3QgYXJyaXZlIGJlZm9yZSBhbnlvbmUgaXMgbGlzdGVuaW5nLiBJZiB0aGVcbiAgLy8gcGFuZWwgaXMgbm90IHRoZXJlIOKAlCBhIHN0YWdlIG1vdW50ZWQgb24gaXRzIG93biDigJQgbm90aGluZyBhbnN3ZXJzIGFuZCB0aGVcbiAgLy8gbmV3ZXN0LWNvbnZlcnNhdGlvbiBmYWxsYmFjayBzdGFuZHMsIGV4YWN0bHkgYXMgYmVmb3JlLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZvaWQgcG9zdFRvUmVnaW9uKFBBTkVMX1JFR0lPTiwgeyB0eXBlOiBcInJlcXVlc3Qtc2VsZWN0aW9uXCIgfSkuY2F0Y2goKCkgPT4ge30pO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgcnVuID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghcHJvbXB0LnRyaW0oKSB8fCBydW5uaW5nKSByZXR1cm47XG4gICAgLy8gUjMtNTYwIChSLUFSRC0xNSwgdGhlIGF0dGVuZGVkIGdhdGUpOiBhbiBpbnRlcnJ1cHRlZCBydW4gb24gVEhJU1xuICAgIC8vIGNvbnZlcnNhdGlvbiBkZW1hbmRzIGEgY2hvaWNlIGZpcnN0LiBBIGZyZXNoIGtpY2tvZmYgcGFzdCBpdCB3b3VsZCBzZWVkXG4gICAgLy8gaGlzdG9yeSBmcm9tIHRoZSBzdGFsZSByZWNvcmQsIEIwLXJlcGxhY2UgdGhlIGpvdXJuYWwncyB0cmFuc2NyaXB0LCBhbmRcbiAgICAvLyBmb2xkLXJlY2xhaW0gdGhlIGludGVycnVwdGVkIHRhaWwg4oCUIGNvbXBsZXRlZCB0b29sIHJlc3VsdHMgdmFuaXNoaW5nIGZyb21cbiAgICAvLyB0aGUgdHJhbnNjcmlwdCB3aGlsZSB0aGVpciBmaWxlIGVmZmVjdHMgc3RheSwgdGhlIGV4YWN0IMKnMCBkaXZlcmdlbmNlXG4gICAgLy8gdGhpcyBpdGVtIGV4aXN0cyB0byByZW1vdmUuIFJlZnVzZTsgdGhlIGFmZm9yZGFuY2UgaXMgb25lIHJvdyBhYm92ZS5cbiAgICAvLyBUaGUgaW50ZXJydXB0aW9uIGNoZWNrIG1heSBzdGlsbCBiZSBJTiBGTElHSFQgKGJvb3QgcmVwbGF5KSDigJQgd2FpdCBmb3IgaXRcbiAgICAvLyBiZWZvcmUgZGVjaWRpbmcsIG9yIHRoZSBnYXRlIGhhcyBhIGhvbGUgZXhhY3RseSBvbmUgdGljayB3aWRlLlxuICAgIGNvbnN0IGNvbnZGb3JHYXRlID0gY29udlJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGluZmxpZ2h0ID0gcmVwbGF5SW5GbGlnaHRSZWYuY3VycmVudDtcbiAgICBpZiAoY29udkZvckdhdGUgJiYgaW5mbGlnaHQgJiYgaW5mbGlnaHQuY29udklkID09PSBjb252Rm9yR2F0ZS5pZCkge1xuICAgICAgYXdhaXQgaW5mbGlnaHQucHJvbWlzZTtcbiAgICB9XG4gICAgY29uc3QgcGVuZGluZyA9IHBlbmRpbmdSZXN1bWVSZWYuY3VycmVudDtcbiAgICBpZiAocGVuZGluZyAmJiBjb252UmVmLmN1cnJlbnQgJiYgcGVuZGluZy5jb252SWQgPT09IGNvbnZSZWYuY3VycmVudC5pZCkge1xuICAgICAgYXBwZW5kKHtcbiAgICAgICAga2luZDogXCJlcnJvclwiLFxuICAgICAgICB0ZXh0OiBcIlRoaXMgcnVuIHdhcyBpbnRlcnJ1cHRlZCDigJQgY2hvb3NlIFJlc3VtZSBydW4sIG9yIEtlZXAgdGhlIGZpbGVzIGFuZCBlbmQgdGhlIHJ1biwgYmVmb3JlIHN0YXJ0aW5nIGEgbmV3IG9uZS5cIixcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRQZW5kaW5nUmVzdW1lKG51bGwpO1xuICAgIC8vIFJlZnVzZSByYXRoZXIgdGhhbiBhdXRob3IgdGhlIHdyb25nIHRyZWU6IHdpdGggbm8gY29uZmVycmVkIHN0YWdlLWFwcCB3b3JraW5nXG4gICAgLy8gdHJlZSwgdGhlIGFnZW50IGhhcyBubyBmaWxlc3lzdGVtIHRvb2xzLCBzbyBhIFwiYnVpbGQgbWUgWFwiIHByb21wdCB3b3VsZCBlaXRoZXJcbiAgICAvLyBkbyBub3RoaW5nIG9yIChwcmUtZml4KSBzaWxlbnRseSBlZGl0IHRoZSBhZ2VudCdzIG93biByZXBvLiBUZWxsIHRoZSB1c2VyLlxuICAgIGlmICghc3RhZ2VUcmVlKSB7XG4gICAgICBhcHBlbmQoeyBraW5kOiBcInVzZXJcIiwgdGV4dDogcHJvbXB0IH0pO1xuICAgICAgYXBwZW5kKHtcbiAgICAgICAga2luZDogXCJlcnJvclwiLFxuICAgICAgICB0ZXh0OiBcIk5vIGFwcCB3b3Jrc3BhY2UgaXMgY29ubmVjdGVkIHlldC4gT3BlbiBhbiBhcHAgaW4gdGhlIHN0YWdlIChhbmQgZ2l2ZSBpdCBhIG1vbWVudCB0byBtb3VudCkgYmVmb3JlIGFza2luZyBtZSB0byBlZGl0IGl0IOKAlCBJIHdvbid0IHRvdWNoIG15IG93biBmaWxlcy5cIixcbiAgICAgIH0pO1xuICAgICAgc2V0UHJvbXB0KFwiXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgLy8gRW5zdXJlIGEgY29udmVyc2F0aW9uIGV4aXN0cyB0byBhdHRhY2ggdGhpcyBydW4gdG8sIHN0YW1wZWQgd2l0aCB0aGVcbiAgICAvLyB3b3Jrc3BhY2UgcmVwbyBzbyB0aGUgcGFuZWwgc2NvcGVzIGl0IGNvcnJlY3RseSAoUjMtNDc1KS5cbiAgICBsZXQgY29udiA9IGNvbnZSZWYuY3VycmVudDtcbiAgICBpZiAoIWNvbnYgJiYgc3RvcmUpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnYgPSBhd2FpdCBzdG9yZS5jcmVhdGUodW5kZWZpbmVkLCB3b3Jrc3BhY2VSZXBvKTtcbiAgICAgICAgY29udlJlZi5jdXJyZW50ID0gY29udjtcbiAgICAgICAgc3RhZ2VTZWxlY3Rpb25SZWYuY3VycmVudCEuYWRvcHQoY29udik7XG4gICAgICAgIHNldFRpdGxlKGNvbnYudGl0bGUpO1xuICAgICAgICBzZXRTdG9yZUVycm9yKG51bGwpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBSdW5uaW5nIGVwaGVtZXJhbGx5IGlzIGEgcmVhbCBkZWdyYWRhdGlvbiwgbm90IGEgZGV0YWlsOiBgaGlzdG9yeWBcbiAgICAgICAgLy8gYmVsb3cgZmFsbHMgYmFjayB0byBbXSwgc28gdGhlIG1vZGVsIHNlZXMgT05MWSB0aGlzIHByb21wdCBhbmQgdGhlXG4gICAgICAgIC8vIGNvbnZlcnNhdGlvbiBhcHBlYXJzIHRvIGhhdmUgbm8gbWVtb3J5LiBTYXkgc28gKFIzLTI0NykuXG4gICAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFIzLTU2MSAvIFItQVJELTE4OiB0YWtlIHRoZSBhZHZpc29yeSBydW4gbGVhc2UgYmVmb3JlIGV4ZWN1dGluZyBhbnl0aGluZy5cbiAgICAvLyBBIGxpdmUgbGVhc2UgaGVsZCBieSBhbm90aGVyIGZyYW1lIG1lYW5zIHRoZSBjb252ZXJzYXRpb24gbWF5IGJlIHJ1bm5pbmcgaW5cbiAgICAvLyBhIHdpbmRvdyB0aGlzIG9uZSBjYW5ub3Qgc2VlLCBhbmQgZHJpdmluZyBvbmUgd29ya2luZyB0cmVlIGZyb20gdHdvIGxvb3BzIGlzXG4gICAgLy8gd2hhdCB0aGUgbGVhc2UgZXhpc3RzIHRvIGF2b2lkLiBgaGVsZGAgaXMgYW4gT0ZGRVIsIG5ldmVyIGEgYmxvY2sg4oCUIHNlZVxuICAgIC8vIGBsZWFzZUhlbGRgIOKAlCBiZWNhdXNlIHRoZSBob2xkZXIgbWF5IGJlIGEgZnJhbWUgdGhhdCBubyBsb25nZXIgZXhpc3RzLlxuICAgIGlmIChzdG9yZSAmJiBjb252KSB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoKGF3YWl0IHN0b3JlLmFjcXVpcmVSdW4oY29udi5pZCkpID09PSBcImhlbGRcIikge1xuICAgICAgICAgIHNldExlYXNlSGVsZCh7IGNvbnZJZDogY29udi5pZCwgcmVzdW1lOiBmYWxzZSB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gV3JhcHBlZCBmb3IgdGhlIHNhbWUgcmVhc29uIGBzdG9yZS5jcmVhdGVgIHRocmVlIGxpbmVzIHVwIGlzIChSMy0yNDcpOiBhXG4gICAgICAgIC8vIHN0b3JlIGNhbGwgdGhhdCByZWplY3RzIG11c3Qgbm90IHJlYWNoIHRoZSB1c2VyIGFzIGFuIHVuaGFuZGxlZCByZWplY3Rpb25cbiAgICAgICAgLy8gZnJvbSBhIGJhcmUgYHZvaWQgcnVuKClgLiBBIGxlYXNlIHdlIGNhbm5vdCByZWFkIGlzIG5vdCBhIGxlYXNlIHdlIGxvc3Qg4oCUXG4gICAgICAgIC8vIHNheSB0aGUgc3RvcmUgaXMgZGVncmFkZWQgYW5kIHJ1biwgcmF0aGVyIHRoYW4gcmVmdXNpbmcgb24gYW4gdW5rbm93bi5cbiAgICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gUjMtNTU5OiB0aGUgY2hlY2twb2ludCBqb3VybmFsLiBXaGVuIHRoZSBkZXZpY2UtbG9jYWwgdGllciBpcyB3aXJlZCwgZXZlcnlcbiAgICAvLyBsb29wIGJvdW5kYXJ5IGlzIGFwcGVuZGVkIGJlZm9yZSB0aGUgbG9vcCBwcm9jZWVkcyBwYXN0IGl0IChCMiBpbnRlbnQgaXNcbiAgICAvLyBkdXJhYmxlIEJFRk9SRSBpdHMgZXhlY3V0b3IgcnVucyDigJQgUi1BUkQtMTBhKTsgYW4gYXBwZW5kIHRoYXQgZmFpbHMgb3JcbiAgICAvLyB0aW1lcyBvdXQgdW53aW5kcyB0aGUgcnVuIEFUIHRoYXQgYm91bmRhcnkgd2l0aCB0aGUgZHVyYWJpbGl0eSBjb25zZXF1ZW5jZVxuICAgIC8vIG5hbWVkLCBhbmQgdGhlIGpvdXJuYWwgYWxyZWFkeSB3cml0dGVuIHN0YXlzIHJlc3VtYWJsZS4gSm91cm5hbGxlc3NcbiAgICAvLyAoUi1BUkQtMTApOiB0aGUgcnVuIGlzIGFsbG93ZWQgdG8gc3RhcnQsIHNhdmUtYXQtZW5kIG9ubHkuXG4gICAgY29uc3Qgam91cm5hbCA9IGNvbnYgJiYgc3RvcmU/Lmhhc0pvdXJuYWwoKSA/IGNvbnYgOiBudWxsO1xuICAgIGlmIChzdG9yZSAmJiBjb252ICYmICFzdG9yZS5oYXNKb3VybmFsKCkgJiYgIXN0b3JlRXJyb3IpIHtcbiAgICAgIHNldFN0b3JlRXJyb3IoXG4gICAgICAgIFwiQ2hlY2twb2ludHMgYXJlIG9mZiAobm8gZGV2aWNlLWxvY2FsIHN0b3JlKSwgc28gY2xvc2luZyB0aGlzIHRhYiBsb3NlcyB0aGUgcnVuJ3MgaW4tZmxpZ2h0IHR1cm4g4oCUIHRoZSBjb252ZXJzYXRpb24gaXRzZWxmIHN0aWxsIHNhdmVzIHdoZW4gdGhlIHJ1biBlbmRzLlwiLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgaGlzdG9yeSA9IGNvbnY/Lm1lc3NhZ2VzID8/IFtdO1xuICAgIGNvbnN0IGtpY2tvZmYgPSBwcm9tcHQ7XG4gICAgc2V0UHJvbXB0KFwiXCIpO1xuICAgIHNldFJ1bm5pbmcodHJ1ZSk7XG4gICAgcnVubmluZ0lkUmVmLmN1cnJlbnQgPSBjb252Py5pZCA/PyBudWxsO1xuICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblJ1blN0YXJ0KGNvbnY/LmlkID8/IG51bGwpO1xuICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICBzZXRVc2FnZShudWxsKTtcbiAgICBhcHBlbmQoeyBraW5kOiBcInVzZXJcIiwgdGV4dDoga2lja29mZiB9KTtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGFib3J0UmVmLmN1cnJlbnQgPSBjb250cm9sbGVyO1xuICAgIGNvbnN0IHN0ZWVyaW5nID0gbmV3IFN0ZWVyQ29udHJvbGxlcigpO1xuICAgIHN0ZWVyUmVmLmN1cnJlbnQgPSBzdGVlcmluZztcbiAgICAvLyBSMy01NjIgKMKnNyBSLUFSRC0yMGEpOiB0aGUgaGlkZeKGknBhdXNlIGpvaW4gZm9yIHRoaXMgcnVuIOKAlCBzZWVkZWQgZnJvbSB0aGVcbiAgICAvLyB2aXNpYmlsaXR5IGF0IGtpY2tvZmYsIGRyaXZlbiBieSB0aGUgaG9zdCdzIHB1c2ggZm9yIHRoZSBydW4ncyBsaWZlXG4gICAgLy8gKHNyYy9saWIvcnVuUGF1c2UudHMsIGV4dHJhY3RlZCBzbyB0aGUgam9pbiBpcyB0ZXN0YWJsZSB3aXRob3V0IGEgRE9NKS5cbiAgICBjb25zdCB7IHBhdXNlLCBkaXNwb3NlOiBkaXNwb3NlUGF1c2UgfSA9IGNyZWF0ZVJ1blBhdXNlKCk7XG4gICAgc2V0UXVldWVkKFtdKTtcbiAgICBjb25zdCBvZmZTdGVlckNoYW5nZSA9IHN0ZWVyaW5nLm9uQ2hhbmdlKChwZW5kaW5nKSA9PiBzZXRRdWV1ZWQoWy4uLnBlbmRpbmddKSk7XG4gICAgLy8gUjMtNTYwIChSLUFSRC0xNyk6IHRoZSBwcm9tcHQgc3BsaXRzIGF0IGEgY2FjaGUgYnJlYWtwb2ludCDigJQgdGhlIFBJTk5FRFxuICAgIC8vIHByZWZpeCAocm9sZSwgcnVsZXMsIHdvcmtmbG93LCB0aGUgZGF0ZSBmcm96ZW4gYXQgcnVuIHN0YXJ0KSBpcyBzdGFtcGVkXG4gICAgLy8gaW50byBCMCBzbyBhIHJlc3VtZSByZXBsYXlzIHRoZXNlIGJ5dGVzIGV4YWN0bHk7IHRoZSBMSVZFIHN1ZmZpeCAodG9vbHMsXG4gICAgLy8gc2tpbGxzLCB3b3Jrc3BhY2Ugcm9vdCkgaXMgcmVidWlsdCBldmVyeSB0aW1lIGFuZCB0aGUgY2FjaGUgYnJlYWsgYXQgdGhlXG4gICAgLy8gYm91bmRhcnkgaXMgYWNjZXB0ZWQsIG5vdCB3b3JrZWQgYXJvdW5kLlxuICAgIGNvbnN0IHBpbm5lZFByZWZpeCA9IGJ1aWxkUGlubmVkUHJlZml4KHsgdG9kYXk6IHRvZGF5SXNvKCkgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRyYW5zY3JpcHQgPSBhd2FpdCBydW5BZ2VudCh7XG4gICAgICAgIGNsaWVudDogY3JlYXRlQ2hhdE1vZGVsQ2xpZW50KCksXG4gICAgICAgIHRvb2xzOiB0b29sc2V0LnRvb2xzLFxuICAgICAgICBleGVjdXRlOiB0b29sc2V0LmV4ZWN1dGUsXG4gICAgICAgIHN5c3RlbTogY29tcG9zZVN5c3RlbVByb21wdChwaW5uZWRQcmVmaXgsIGJ1aWxkTGl2ZVN1ZmZpeCh7IHRvb2xzOiB0b29sc2V0LnRvb2xzLCB3b3Jrc3BhY2VSb290OiBzdGFnZVRyZWU/LnJvb3QsIHNraWxscyB9KSksXG4gICAgICAgIHdvcmtzcGFjZTogd29ya3NwYWNlUmVwbyA/PyB1bmRlZmluZWQsXG4gICAgICAgIHN5c3RlbVByZWZpeDogcGlubmVkUHJlZml4LFxuICAgICAgICBoaXN0b3J5LFxuICAgICAgICBwcm9tcHQ6IGtpY2tvZmYsXG4gICAgICAgIC8vIFIzLTIyNCAowqczLjMpOiB0aGUgc3RvcCBidXR0b24gYWJvcnRzIHRoZSBsb29wIEFORCB0aGUgaW4tZmxpZ2h0IExMTSB0dXJuLlxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAvLyBSMy0zMzM6IHRoZSBzdGVlcmluZyBxdWV1ZSDigJQgdGhlIG90aGVyIHZlcmIgdGhlIGh1bWFuIGhhcy5cbiAgICAgICAgc3RlZXJpbmcsXG4gICAgICAgIC8vIFIzLTU2MiAowqc3IFItQVJELTIwYSk6IHBhdXNlIGF0IHR1cm4gYm91bmRhcmllcyB3aGlsZSB0aGlzIHJlZ2lvbiBpcyBoaWRkZW4uXG4gICAgICAgIHBhdXNlLFxuICAgICAgICAvLyBUb2tlbiBhY2NvdW50aW5nICsgYXV0by1jb21wYWN0aW9uIGxldCB0aGUgbG9vcCBydW4gcGFzdCB+MTIgdHVybnMgKFIzLTIyMCkuXG4gICAgICAgIGNvbnRleHRXaW5kb3c6IGRlc2NyaWJlQ2hhdCgpPy5mZWF0dXJlcy5tYXhDb250ZXh0VG9rZW5zLFxuICAgICAgICBldmVudHM6IHtcbiAgICAgICAgICAvLyBSMy01NTk6IGFwcGVuZCBldmVyeSBib3VuZGFyeSB0byB0aGUgY29udmVyc2F0aW9uJ3Mgam91cm5hbC4gVGhlIGxvb3BcbiAgICAgICAgICAvLyBhd2FpdHMgdGhpcyBiZWZvcmUgcHJvY2VlZGluZyDigJQgdGhlIHdyaXRlJ3MgbGF0ZW5jeSBJUyB0aGVcbiAgICAgICAgICAvLyBpbnRlbnQtYmVmb3JlLWV4ZWN1dGUgb3JkZXJpbmcuXG4gICAgICAgICAgLi4uKGpvdXJuYWxcbiAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgIG9uQm91bmRhcnk6IGFzeW5jIChiKSA9PiB7XG4gICAgICAgICAgICAgICAgICBhd2FpdCBzdG9yZSEuYXBwZW5kKGpvdXJuYWwuaWQsIGIpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgIG9uQXNzaXN0YW50RGVsdGE6ICh0ZXh0KSA9PiBzZXRTdHJlYW1pbmcoKHMpID0+IHMgKyB0ZXh0KSxcbiAgICAgICAgICAvLyBSMy0zMzUg4oCUIHRoZSBsaXZlIHRoaW5raW5nIHN1cmZhY2UuIE5vdyB0aGF0IGNvbXBhY3Rpb24gbGV0cyBhIHRhc2sgcnVuIHBhc3RcbiAgICAgICAgICAvLyBhIGRvemVuIHR1cm5zLCB0aGUgc2lsZW50IHN0cmV0Y2hlcyBhcmUgbG9uZ2VyLCBhbmQgXCJpcyBpdCBzdHVjayBvclxuICAgICAgICAgIC8vIHRoaW5raW5nP1wiIGhhZCBubyBhbnN3ZXIgb24gc2NyZWVuLlxuICAgICAgICAgIG9uUmVhc29uaW5nRGVsdGE6ICh0ZXh0KSA9PiBzZXRUaGlua2luZygodCkgPT4gdCArIHRleHQpLFxuICAgICAgICAgIG9uUmVhc29uaW5nOiAoYmxvY2spID0+IHtcbiAgICAgICAgICAgIHNldFRoaW5raW5nKFwiXCIpO1xuICAgICAgICAgICAgYXBwZW5kKFxuICAgICAgICAgICAgICBibG9jay5yZWRhY3RlZERhdGEgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgID8geyBraW5kOiBcInJlYXNvbmluZ1wiLCB0ZXh0OiBcIlwiLCByZWRhY3RlZDogdHJ1ZSB9XG4gICAgICAgICAgICAgICAgOiB7IGtpbmQ6IFwicmVhc29uaW5nXCIsIHRleHQ6IGJsb2NrLnRleHQgfSxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvbkFzc2lzdGFudFRleHQ6ICh0ZXh0KSA9PiB7XG4gICAgICAgICAgICAvLyBBIHR1cm4gYW4gYGludGVycnVwdGAgc3RlZXIgY3V0IHNob3J0IGlzIGl0cyBvd24gcm93LCBsaXZlIGFuZCBvblxuICAgICAgICAgICAgLy8gcmVwbGF5IOKAlCBub3QgYSByZXBseSB0aGUgbW9kZWwgYWN0dWFsbHkgd3JvdGUuXG4gICAgICAgICAgICBpZiAodGV4dCA9PT0gSU5URVJSVVBURURfVFVSTl9URVhUKSBhcHBlbmQoeyBraW5kOiBcImludGVycnVwdGVkXCIgfSk7XG4gICAgICAgICAgICBlbHNlIGlmICh0ZXh0LnRyaW0oKSkgYXBwZW5kKHsga2luZDogXCJ0ZXh0XCIsIHRleHQgfSk7XG4gICAgICAgICAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvblRvb2xVc2U6IChuYW1lLCBpbnB1dCkgPT4gYXBwZW5kKHsga2luZDogXCJ0b29sXCIsIG5hbWUsIGlucHV0IH0pLFxuICAgICAgICAgIG9uVG9vbFJlc3VsdDogKG5hbWUsIHIpID0+IGFwcGVuZCh7IGtpbmQ6IFwicmVzdWx0XCIsIG5hbWUsIGNvbnRlbnQ6IHIuY29udGVudCwgaXNFcnJvcjogci5pc0Vycm9yIH0pLFxuICAgICAgICAgIG9uTnVkZ2U6ICgpID0+IGFwcGVuZCh7IGtpbmQ6IFwibnVkZ2VcIiB9KSxcbiAgICAgICAgICBvblVzYWdlOiAodSkgPT5cbiAgICAgICAgICAgIHNldFVzYWdlKHtcbiAgICAgICAgICAgICAgc3BlbnRUb2tlbnM6IHUuc3BlbnRUb2tlbnMsXG4gICAgICAgICAgICAgIGNhY2hlUmVhZFRva2VuczogdS5jYWNoZVJlYWRUb2tlbnMsXG4gICAgICAgICAgICAgIGNhY2hlV3JpdGVUb2tlbnM6IHUuY2FjaGVXcml0ZVRva2VucyxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIG9uQ29tcGFjdDogKHsgc3VtbWFyaXplZENvdW50LCBjYWNoZVJlYWRUb2tlbnMgfSkgPT4ge1xuICAgICAgICAgICAgYXBwZW5kKHtcbiAgICAgICAgICAgICAga2luZDogXCJjb21wYWN0aW9uXCIsXG4gICAgICAgICAgICAgIC8vIFIzLTMzNjogdGhlIGNvbXBhY3Rpb24gcmV3cm90ZSB0aGUgY29udmVyc2F0aW9uIHByZWZpeCwgc28gdGhlIG5leHQgdHVyblxuICAgICAgICAgICAgICAvLyByZS13YXJtcyBpdC4gVGhlIGR1cmFibGUgc3lzdGVtK3Rvb2xzIHByZWZpeCBpcyB1bnRvdWNoZWQuIFJlY29yZGluZyB0aGVcbiAgICAgICAgICAgICAgLy8gcnVubmluZyBjYWNoZSB0b3RhbCBBVCB0aGUgYm91bmRhcnkgaXMgd2hhdCBsZXRzIHRoZSBjb3N0IGN1cnZlIGFjcm9zcyBhXG4gICAgICAgICAgICAgIC8vIGNvbXBhY3Rpb24gYmUgcmVhZCByYXRoZXIgdGhhbiBhc3N1bWVkLlxuICAgICAgICAgICAgICBzdW1tYXJ5OlxuICAgICAgICAgICAgICAgIGAke3N1bW1hcml6ZWRDb3VudH0gZWFybGllciBtZXNzYWdlcyBzdW1tYXJpemVkYCArXG4gICAgICAgICAgICAgICAgKGNhY2hlUmVhZFRva2VucyAhPT0gdW5kZWZpbmVkID8gYCDCtyAke2NhY2hlUmVhZFRva2Vuc30gY2FjaGVkIHRva2VucyByZWFkIHNvIGZhcmAgOiBcIlwiKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLy8gUjMtNTU5IChSLUFSRC05KTogY29tcGFjdGlvbiBpcyBhIG5hdHVyYWwgZm9sZCBwb2ludCDigJQgaXQgcmV3cm90ZSB0aGVcbiAgICAgICAgICAgIC8vIHRyYW5zY3JpcHQgcHJlZml4IGFueXdheS4gQmVzdC1lZmZvcnQgbWlkLXJ1bjogYSBmYWlsZWQgZm9sZCBjb3N0cyB0aGVcbiAgICAgICAgICAgIC8vIGZvbGQsIG5ldmVyIHRoZSBydW4gKHRoZSBqb3VybmFsIHJldGFpbnMgZXZlcnl0aGluZzsgdGhlIHJ1bi1lbmQgZm9sZFxuICAgICAgICAgICAgLy8gaXMgdGhlIGF1dGhvcml0YXRpdmUgd3JpdGUpLCBzbyBpdCBpcyBsb2dnZWQtYW5kLWRyb3BwZWQsIG5vdCB0aHJvd24uXG4gICAgICAgICAgICBpZiAoam91cm5hbCkge1xuICAgICAgICAgICAgICB2b2lkIHN0b3JlIS5mb2xkKGpvdXJuYWwuaWQpLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFwibWlkLXJ1biBmb2xkIGF0IGNvbXBhY3Rpb24gZmFpbGVkIChydW4tZW5kIGZvbGQgc3RpbGwgd2lsbClcIiwgZSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgb25TdGVlcjogKHsgbWVzc2FnZXMgfSkgPT4ge1xuICAgICAgICAgICAgZm9yIChjb25zdCBtIG9mIG1lc3NhZ2VzKSBhcHBlbmQoeyBraW5kOiBcInN0ZWVyXCIsIG1vZGU6IG0ubW9kZSwgdGV4dDogbS50ZXh0IH0pO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIGlmIChjb252ICYmIHN0b3JlKSB7XG4gICAgICAgIGNvbnN0IG5ld1RpdGxlID0gY29udi50aXRsZSA9PT0gXCJOZXcgY29udmVyc2F0aW9uXCIgPyBkZXJpdmVUaXRsZSh0cmFuc2NyaXB0KSA6IGNvbnYudGl0bGU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gUjMtNTU5OiB0aGUgcnVuLWVuZCBzYXZlIGlzIG5vdyBhIEZPTEQgKFItQVJELTkpIOKAlCB0aGUgcmVjb3JkIGdldHNcbiAgICAgICAgICAvLyB0aGUgYXV0aG9yaXRhdGl2ZSB0cmFuc2NyaXB0IChieXRlLXRydWUgdG8gd2hhdCB0aGUgbW9kZWwgc2F3KSwgdGhlXG4gICAgICAgICAgLy8gZm9sZCB3YXRlcm1hcmssIGFuZCB0aGUgY2FycmllZCBydW4tc3RhdGU7IHRoZSBzdXBlcnNlZGVkIGpvdXJuYWxcbiAgICAgICAgICAvLyBlbnRyaWVzIGFyZSByZWNsYWltZWQgKFItQVJELTVjKS5cbiAgICAgICAgICBjb252UmVmLmN1cnJlbnQgPSBhd2FpdCBzdG9yZS5mb2xkKGNvbnYuaWQsIHtcbiAgICAgICAgICAgIG1lc3NhZ2VzOiB0cmFuc2NyaXB0LFxuICAgICAgICAgICAgdGl0bGU6IG5ld1RpdGxlLFxuICAgICAgICAgICAgcmVwbzogY29udi5yZXBvID8/IHdvcmtzcGFjZVJlcG8sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgc2V0VGl0bGUobmV3VGl0bGUpO1xuICAgICAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICAgICAgLy8gUjMtNjMxIOKAlCB0aGUgc2F2ZSBpcyB0aGUgbmF0dXJhbCBoZWFydGJlYXQ6IG1lc3NhZ2VDb3VudCBncmV3LlxuICAgICAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblNhdmVkKCk7XG4gICAgICAgICAgdm9pZCBwb3N0VG9SZWdpb24oUEFORUxfUkVHSU9OLCB7IHR5cGU6IFwiY29udmVyc2F0aW9uLXVwZGF0ZWRcIiwgaWQ6IGNvbnYuaWQgfSkuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gQSBmYWlsZWQgc2F2ZSBtZWFucyBgY29udlJlZi5jdXJyZW50YCBrZWVwcyB0aGUgUFJFLXJ1biBtZXNzYWdlcywgc28gdGhlXG4gICAgICAgICAgLy8gbmV4dCB0dXJuIHJlLXNlbmRzIGEgc3RhbGUgKG9yIGVtcHR5KSBoaXN0b3J5IOKAlCB0aGUgc2FtZSBhbW5lc2lhIGFzIGFcbiAgICAgICAgICAvLyBkZWFkIHN0b3JlLCBvbmUgdHVybiBsYXRlci4gTmV2ZXIgc2lsZW50IChSMy0yNDcpLlxuICAgICAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBSMy01NjE6IHRoZSB0d28gbGVhc2UgY29kZXMgYXJlIFVYIHN0YXRlcywgbm90IGNvZGVzIHRvIHByaW50ICjCpzkpLiBUaGVcbiAgICAgIC8vIGRpc2NyaW1pbmF0aW9uIGFuZCB0aGUgY29weSBsaXZlIGluIGBsaWIvc3RvcmVFcnJvcmAg4oCUIHBhc3RpbmcgdGhlbSBoZXJlXG4gICAgICAvLyBpcyB3aGF0IG1hZGUgdGhlIHJlc3VtZSBjYXRjaCBiZWxvdyBnZXQgbWlzc2VkIHRoZSBmaXJzdCB0aW1lLlxuICAgICAgY29uc3QgbGVhc2UgPSBsZWFzZUZhaWx1cmUoZSk7XG4gICAgICBpZiAobGVhc2UpIHtcbiAgICAgICAgYXBwZW5kKHsga2luZDogXCJlcnJvclwiLCB0ZXh0OiBsZWFzZUZhaWx1cmVUZXh0KGxlYXNlLCB0cnVlKSB9KTtcbiAgICAgICAgaWYgKGxlYXNlID09PSBcImxlYXNlLWxvc3RcIikge1xuICAgICAgICAgIHNldExlYXNlSGVsZCh7IGNvbnZJZDogcnVubmluZ0lkUmVmLmN1cnJlbnQgPz8gY29udlJlZi5jdXJyZW50Py5pZCA/PyBcIlwiLCByZXN1bWU6IGZhbHNlIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcHBlbmQoeyBraW5kOiBcImVycm9yXCIsIHRleHQ6IChlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBTdHJpbmcoZSkgfSk7XG4gICAgICB9XG4gICAgICAvLyBSMy01NTkgKFItQVJELTEwYSk6IGEgZmFpbGVkIGNoZWNrcG9pbnQgYXBwZW5kIHVud2luZHMgdGhlIHJ1biBoZXJlLiBOYW1lXG4gICAgICAvLyB0aGUgZHVyYWJpbGl0eSBjb25zZXF1ZW5jZSDigJQgdGhlIHJ1biBzdG9wcGVkIEFUIGEgYm91bmRhcnkgYW5kIGV2ZXJ5dGhpbmdcbiAgICAgIC8vIGNoZWNrcG9pbnRlZCBzbyBmYXIgc3Vydml2ZXMgKHRoZSBqb3VybmFsIHN0YXlzIHJlc3VtYWJsZSkuXG4gICAgICBpZiAoaXNKb3VybmFsUmVmdXNhbChlKSkge1xuICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIEpPVVJOQUxfUkVGVVNBTF9TVUZGSVgpKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgb2ZmU3RlZXJDaGFuZ2UoKTtcbiAgICAgIHN0ZWVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgZGlzcG9zZVBhdXNlKCk7XG4gICAgICBzZXRRdWV1ZWQoW10pO1xuICAgICAgc2V0U3RlZXJUZXh0KFwiXCIpO1xuICAgICAgc2V0U3RyZWFtaW5nKFwiXCIpO1xuICAgICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgICBzZXRSdW5uaW5nKGZhbHNlKTtcbiAgICAgIHJlbGVhc2VIZWxkTGVhc2UoKTsgLy8gQkVGT1JFIHJ1bm5pbmdJZFJlZiBpcyBjbGVhcmVkIOKAlCBpdCBpcyB0aGUgaWQgdG8gcmVsZWFzZVxuICAgICAgcnVubmluZ0lkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgYWJvcnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25SdW5FbmQoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUjMtMjI0ICjCpzMuMyk6IHN0b3AgdGhlIGluLWZsaWdodCBydW4g4oCUIGFib3J0cyB0aGUgbG9vcCBiZXR3ZWVuIHRvb2wgY2FsbHMgQU5EIHRoZVxuICAvLyBpbi1mbGlnaHQgTExNIHJlcXVlc3QgKHRoZSBob3N0IHRlYXJzIGRvd24gdGhlIHVwc3RyZWFtIHByb3ZpZGVyIGZldGNoLCBzdG9wcyBiaWxsaW5nKS5cbiAgY29uc3Qgc3RvcCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBhYm9ydFJlZi5jdXJyZW50Py5hYm9ydCgpO1xuICB9LCBbXSk7XG5cbiAgLy8gLS0tLSBSMy01NjA6IHRoZSBhdHRlbmRlZC1yZXN1bWUgY2hvaWNlcyAoUi1BUkQtMTUpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvL1xuICAvLyBCb290aW5nIGFuIGludGVycnVwdGVkIGNvbnZlcnNhdGlvbiBvZmZlcmVkIHRocmVlIHNwZWMnZCBjaG9pY2VzOyB0aGUgdGhpcmQg4oCUXG4gIC8vIFwiZGlzY2FyZCB0aGUgdGFpbCBBTkQgcmV2ZXJ0IHRoZSBydW4ncyB3cml0ZXNcIiDigJQgaXMgTk9UIG9mZmVyZWQgaGVyZSBiZWNhdXNlXG4gIC8vIHRoZSBhcHAgY2Fubm90IGJvdW5kIHdoaWNoIHdyaXRlcyB3ZXJlIHRoZSBydW4ncyAodGhlIENvVyBsYXllciBpc1xuICAvLyBob3N0LXNpZGUpLCBhbmQgYSBkaXNjYXJkIHRoYXQgc2lsZW50bHkga2VlcHMgdGhlIGZpbGVzIG1hbnVmYWN0dXJlcyBleGFjdGx5XG4gIC8vIHRoZSBkaXZlcmdlbmNlIHRoaXMgd29yayBleGlzdHMgdG8gcmVtb3ZlLiBUaGUgZGlzcG9zaXRpb24gaXMgcmVjb3JkZWQgaW5cbiAgLy8gQUdFTlRfUlVOX0RVUkFCSUxJVFlfU1BFQyDCpzUuMzsgdGhlIGtlZXAtY2hvaWNlIGNvcHkgc2F5cyBwbGFpbmx5IHRoYXQgdGhlXG4gIC8vIGZpbGUgY2hhbmdlcyBzdGF5LlxuXG4gIC8qKiBSZXN1bWUgdGhlIGludGVycnVwdGVkIHJ1bjogcmVwYWlyIHRoZSB0cmFuc2NyaXB0LCBuYW1lIGFueSBkaXZlcmdlbmNlLFxuICAgKiAgYW5kIGNvbnRpbnVlIHRoZSBsb29wIFdJVEhPVVQgYSBuZXcgcHJvbXB0IHR1cm4uICovXG4gIGNvbnN0IHJlc3VtZVJ1biA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgcGVuZGluZyA9IHBlbmRpbmdSZXN1bWU7XG4gICAgY29uc3QgY29udiA9IGNvbnZSZWYuY3VycmVudDtcbiAgICBpZiAoIXN0b3JlIHx8ICFwZW5kaW5nIHx8ICFjb252IHx8IHJ1bm5pbmcgfHwgcGVuZGluZy5jb252SWQgIT09IGNvbnYuaWQpIHJldHVybjtcbiAgICAvLyBUaGUgc2FtZSB3b3Jrc3BhY2UtcmVhZGluZXNzIGdhdGUgYXMgYSBmcmVzaCBSdW46IGEgcmVzdW1lIGF1dGhvcnMgZmlsZXNcbiAgICAvLyB0aHJvdWdoIHRoZSBjb25mZXJyZWQgc3RhZ2UgdHJlZSwgYW5kIHdpdGhvdXQgaXQgdGhlIGxvb3Agd291bGQgcnVuXG4gICAgLy8gY2F0YWxvZy1vbmx5IG9yIChwcmUtUjMtNTY5KSBhZ2FpbnN0IHRoZSB3cm9uZyB0cmVlLiBSZWZ1c2UsIHNheSB3aHkuXG4gICAgaWYgKCFzdGFnZVRyZWUpIHtcbiAgICAgIGFwcGVuZCh7XG4gICAgICAgIGtpbmQ6IFwiZXJyb3JcIixcbiAgICAgICAgdGV4dDogXCJObyBhcHAgd29ya3NwYWNlIGlzIGNvbm5lY3RlZCB5ZXQuIE9wZW4gYW4gYXBwIGluIHRoZSBzdGFnZSAoYW5kIGdpdmUgaXQgYSBtb21lbnQgdG8gbW91bnQpIGJlZm9yZSByZXN1bWluZyDigJQgSSB3b24ndCB0b3VjaCBteSBvd24gZmlsZXMuXCIsXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gUjMtNTYxOiBzYW1lIGdhdGUgYXMgYSBmcmVzaCBSdW4uIEEgcmVsb2FkIG1pZC1ydW4gaXMgYSBORVcgZnJhbWUgd2l0aCBhIG5ld1xuICAgIC8vIHRhYklkLCBzbyBzYW1lLXRhYiByZWNsYWltIGRvZXMgbm90IGNvdmVyIGl0IGFuZCB0aGUgZGVhZCBmcmFtZSdzIGxlYXNlIGlzXG4gICAgLy8gc3RpbGwgbGl2ZSB1bnRpbCBpdHMgVFRMIOKAlCB3aGljaCBpcyBleGFjdGx5IHRoZSBjYXNlIHRoZSB0YWtlb3ZlciBvZmZlciBpc1xuICAgIC8vIGZvci4gVGhlIGhvc3QgY2Fubm90IHRlbGwgYSByZWxvYWQgZnJvbSBhIHNlY29uZCB0YWIsIGFuZCBwcmV0ZW5kaW5nIGl0IGNhblxuICAgIC8vIHdvdWxkIGJlIHRoZSBkb3VibGUtZHJpdmUgdGhpcyBtZWNoYW5pc20gZXhpc3RzIHRvIHByZXZlbnQuXG4gICAgdHJ5IHtcbiAgICAgIGlmICgoYXdhaXQgc3RvcmUuYWNxdWlyZVJ1bihjb252LmlkKSkgPT09IFwiaGVsZFwiKSB7XG4gICAgICAgIHNldExlYXNlSGVsZCh7IGNvbnZJZDogY29udi5pZCwgcmVzdW1lOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICB9XG4gICAgc2V0UGVuZGluZ1Jlc3VtZShudWxsKTtcbiAgICBjb25zdCByZXBsYXkgPSBwZW5kaW5nLnJlcGxheTtcbiAgICBjb25zdCByZXBhaXJlZCA9IHJlcGFpclRyYW5zY3JpcHQoe1xuICAgICAgbWVzc2FnZXM6IHJlcGxheS5tZXNzYWdlcyxcbiAgICAgIHBlbmRpbmdFZmZlY3RzOiByZXBsYXkucGVuZGluZ0VmZmVjdHMsXG4gICAgICB0cmFpbGluZ1BhcnRpYWw6IHJlcGxheS50cmFpbGluZ1BhcnRpYWwsXG4gICAgfSk7XG4gICAgLy8gUi1BUkQtMTY6IHNheSB3aGF0IG1vdmVkLCBpbiB0aGUgdHJhbnNjcmlwdCwgYmVmb3JlIHRoZSBtb2RlbCB3b3Jrcy4gQW5cbiAgICAvLyBVTlNFVFRMRUQgd29ya3NwYWNlIGNoYW5uZWwgKHVuZGVmaW5lZCkgY2xhaW1zIG5vdGhpbmcg4oCUIG5ldmVyIGZhYnJpY2F0ZVxuICAgIC8vIGEgZGl2ZXJnZW5jZSBmcm9tIGFuIHVua25vd24uXG4gICAgY29uc3QgZGl2ZXJnZW5jZSA9IGRpdmVyZ2VuY2VNZXNzYWdlKHJlcGxheS5zdGFtcGVkV29ya3NwYWNlLCB3b3Jrc3BhY2VSZXBvKTtcbiAgICBjb25zdCByZXN1bWVkID0gcmVzdW1lZE1lc3NhZ2VzKHJlcGFpcmVkLm1lc3NhZ2VzLCBkaXZlcmdlbmNlKTtcbiAgICBzZXRMb2cobWVzc2FnZXNUb0xvZyhyZXBhaXJlZC5tZXNzYWdlcykpO1xuICAgIHNldFJ1bm5pbmcodHJ1ZSk7XG4gICAgcnVubmluZ0lkUmVmLmN1cnJlbnQgPSBjb252LmlkO1xuICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblJ1blN0YXJ0KGNvbnYuaWQpO1xuICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICBhcHBlbmQoeyBraW5kOiBcInN0ZWVyXCIsIG1vZGU6IFwicXVldWVcIiwgdGV4dDogXCJSdW4gcmVzdW1lZCBmcm9tIGl0cyBsYXN0IGNoZWNrcG9pbnRcIiB9KTtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGFib3J0UmVmLmN1cnJlbnQgPSBjb250cm9sbGVyO1xuICAgIGNvbnN0IHN0ZWVyaW5nQyA9IG5ldyBTdGVlckNvbnRyb2xsZXIoKTtcbiAgICBzdGVlclJlZi5jdXJyZW50ID0gc3RlZXJpbmdDO1xuICAgIC8vIFIzLTU2MjogdGhlIHNhbWUgaGlkZeKGknBhdXNlIGpvaW4gYXMgYSBmcmVzaCBydW4g4oCUIGEgcmVzdW1lZCBydW4gaXMgZXF1YWxseVxuICAgIC8vIGludmlzaWJsZSB3aGVuIHRoZSByZWdpb24gaXMgaGlkZGVuLlxuICAgIGNvbnN0IHsgcGF1c2UsIGRpc3Bvc2U6IGRpc3Bvc2VQYXVzZSB9ID0gY3JlYXRlUnVuUGF1c2UoKTtcbiAgICBzZXRRdWV1ZWQoW10pO1xuICAgIGNvbnN0IG9mZlN0ZWVyQ2hhbmdlID0gc3RlZXJpbmdDLm9uQ2hhbmdlKChxKSA9PiBzZXRRdWV1ZWQoWy4uLnFdKSk7XG4gICAgLy8gUi1BUkQtMTc6IHRoZSBQSU5ORUQgcHJlZml4IHJlcGxheXMgYnl0ZS1pZGVudGljYWxseSBmcm9tIHRoZSBqb3VybmFsICh0aGVcbiAgICAvLyBmcm96ZW4gZGF0ZSBzdXJ2aXZlcyBtaWRuaWdodCk7IHRoZSBMSVZFIHN1ZmZpeCBpcyByZWJ1aWx0IGZyb20gdGhlXG4gICAgLy8gY3VycmVudCBjYXRhbG9nIOKAlCBhIHJldm9rZWQgdG9vbCBpcyBhYnNlbnQsIGhvbmVzdGx5IHRha2luZyB0aGUgY2FjaGUgbWlzcy5cbiAgICBjb25zdCBwaW5uZWRQcmVmaXggPSByZXBsYXkuc3lzdGVtUHJlZml4ID8/IGJ1aWxkUGlubmVkUHJlZml4KHsgdG9kYXk6IHRvZGF5SXNvKCkgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRyYW5zY3JpcHQgPSBhd2FpdCBydW5BZ2VudCh7XG4gICAgICAgIGNsaWVudDogY3JlYXRlQ2hhdE1vZGVsQ2xpZW50KCksXG4gICAgICAgIHRvb2xzOiB0b29sc2V0LnRvb2xzLFxuICAgICAgICBleGVjdXRlOiB0b29sc2V0LmV4ZWN1dGUsXG4gICAgICAgIHN5c3RlbTogY29tcG9zZVN5c3RlbVByb21wdChwaW5uZWRQcmVmaXgsIGJ1aWxkTGl2ZVN1ZmZpeCh7IHRvb2xzOiB0b29sc2V0LnRvb2xzLCB3b3Jrc3BhY2VSb290OiBzdGFnZVRyZWU/LnJvb3QsIHNraWxscyB9KSksXG4gICAgICAgIHdvcmtzcGFjZTogd29ya3NwYWNlUmVwbyA/PyB1bmRlZmluZWQsXG4gICAgICAgIHN5c3RlbVByZWZpeDogcGlubmVkUHJlZml4LFxuICAgICAgICByZXN1bWU6IHtcbiAgICAgICAgICBtZXNzYWdlczogcmVzdW1lZCxcbiAgICAgICAgICAuLi4ocmVwbGF5LnJ1blN0YXRlICE9PSBudWxsID8geyBydW5TdGF0ZTogcmVwbGF5LnJ1blN0YXRlIGFzIFJ1blN0YXRlIH0gOiB7fSksXG4gICAgICAgIH0sXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIHN0ZWVyaW5nOiBzdGVlcmluZ0MsXG4gICAgICAgIHBhdXNlLFxuICAgICAgICBjb250ZXh0V2luZG93OiBkZXNjcmliZUNoYXQoKT8uZmVhdHVyZXMubWF4Q29udGV4dFRva2VucyxcbiAgICAgICAgZXZlbnRzOiB7XG4gICAgICAgICAgb25Cb3VuZGFyeTogYXN5bmMgKGIpID0+IHtcbiAgICAgICAgICAgIGF3YWl0IHN0b3JlLmFwcGVuZChjb252LmlkLCBiKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uQXNzaXN0YW50RGVsdGE6ICh0ZXh0KSA9PiBzZXRTdHJlYW1pbmcoKHMpID0+IHMgKyB0ZXh0KSxcbiAgICAgICAgICBvblJlYXNvbmluZ0RlbHRhOiAodGV4dCkgPT4gc2V0VGhpbmtpbmcoKHQpID0+IHQgKyB0ZXh0KSxcbiAgICAgICAgICBvblJlYXNvbmluZzogKGJsb2NrKSA9PiB7XG4gICAgICAgICAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICAgICAgICAgIGFwcGVuZChcbiAgICAgICAgICAgICAgYmxvY2sucmVkYWN0ZWREYXRhICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICA/IHsga2luZDogXCJyZWFzb25pbmdcIiwgdGV4dDogXCJcIiwgcmVkYWN0ZWQ6IHRydWUgfVxuICAgICAgICAgICAgICAgIDogeyBraW5kOiBcInJlYXNvbmluZ1wiLCB0ZXh0OiBibG9jay50ZXh0IH0sXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgb25Bc3Npc3RhbnRUZXh0OiAodGV4dCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRleHQgPT09IElOVEVSUlVQVEVEX1RVUk5fVEVYVCkgYXBwZW5kKHsga2luZDogXCJpbnRlcnJ1cHRlZFwiIH0pO1xuICAgICAgICAgICAgZWxzZSBpZiAodGV4dC50cmltKCkpIGFwcGVuZCh7IGtpbmQ6IFwidGV4dFwiLCB0ZXh0IH0pO1xuICAgICAgICAgICAgc2V0U3RyZWFtaW5nKFwiXCIpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgb25Ub29sVXNlOiAobmFtZSwgaW5wdXQpID0+IGFwcGVuZCh7IGtpbmQ6IFwidG9vbFwiLCBuYW1lLCBpbnB1dCB9KSxcbiAgICAgICAgICBvblRvb2xSZXN1bHQ6IChuYW1lLCByKSA9PiBhcHBlbmQoeyBraW5kOiBcInJlc3VsdFwiLCBuYW1lLCBjb250ZW50OiByLmNvbnRlbnQsIGlzRXJyb3I6IHIuaXNFcnJvciB9KSxcbiAgICAgICAgICBvbk51ZGdlOiAoKSA9PiBhcHBlbmQoeyBraW5kOiBcIm51ZGdlXCIgfSksXG4gICAgICAgICAgb25Vc2FnZTogKHUpID0+XG4gICAgICAgICAgICBzZXRVc2FnZSh7XG4gICAgICAgICAgICAgIHNwZW50VG9rZW5zOiB1LnNwZW50VG9rZW5zLFxuICAgICAgICAgICAgICBjYWNoZVJlYWRUb2tlbnM6IHUuY2FjaGVSZWFkVG9rZW5zLFxuICAgICAgICAgICAgICBjYWNoZVdyaXRlVG9rZW5zOiB1LmNhY2hlV3JpdGVUb2tlbnMsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICBvbkNvbXBhY3Q6ICh7IHN1bW1hcml6ZWRDb3VudCB9KSA9PiB7XG4gICAgICAgICAgICBhcHBlbmQoeyBraW5kOiBcImNvbXBhY3Rpb25cIiwgc3VtbWFyeTogYCR7c3VtbWFyaXplZENvdW50fSBlYXJsaWVyIG1lc3NhZ2VzIHN1bW1hcml6ZWRgIH0pO1xuICAgICAgICAgICAgdm9pZCBzdG9yZVxuICAgICAgICAgICAgICAuZm9sZChjb252LmlkKVxuICAgICAgICAgICAgICAuY2F0Y2goKGUpID0+IGNvbnNvbGUud2FybihcIm1pZC1ydW4gZm9sZCBhdCBjb21wYWN0aW9uIGZhaWxlZCAocnVuLWVuZCBmb2xkIHN0aWxsIHdpbGwpXCIsIGUpKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uU3RlZXI6ICh7IG1lc3NhZ2VzIH0pID0+IHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbSBvZiBtZXNzYWdlcykgYXBwZW5kKHsga2luZDogXCJzdGVlclwiLCBtb2RlOiBtLm1vZGUsIHRleHQ6IG0udGV4dCB9KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb252UmVmLmN1cnJlbnQgPSBhd2FpdCBzdG9yZS5mb2xkKGNvbnYuaWQsIHtcbiAgICAgICAgICBtZXNzYWdlczogdHJhbnNjcmlwdCxcbiAgICAgICAgICByZXBvOiBjb252LnJlcG8gPz8gd29ya3NwYWNlUmVwbyxcbiAgICAgICAgfSk7XG4gICAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblNhdmVkKCk7XG4gICAgICAgIHZvaWQgcG9zdFRvUmVnaW9uKFBBTkVMX1JFR0lPTiwgeyB0eXBlOiBcImNvbnZlcnNhdGlvbi11cGRhdGVkXCIsIGlkOiBjb252LmlkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBSMy01NjE6IHRoZSBzYW1lIG1hcHBpbmcgYXMgYHJ1bmAncyBjYXRjaC4gVGhpcyBpcyB0aGUgcGF0aCB0aGUgdGFrZW92ZXJcbiAgICAgIC8vIGJ1dHRvbiBpdHNlbGYgaW52b2tlcywgc28gYSB1c2VyIHdobyB0YWtlcyBvdmVyIGEgcmVzdW1hYmxlIHJ1biBhbmQgbG9zZXNcbiAgICAgIC8vIHRoZSBsZWFzZSBhZ2FpbiBsYW5kcyBoZXJlIOKAlCBpdCBwcmludGVkIHRoZSByYXcgaW50ZXJuYWwgc3RyaW5nIHVudGlsIHRoZVxuICAgICAgLy8gZGlzY3JpbWluYXRpb24gbW92ZWQgaW50byBgbGliL3N0b3JlRXJyb3JgLlxuICAgICAgY29uc3QgbGVhc2UgPSBsZWFzZUZhaWx1cmUoZSk7XG4gICAgICBpZiAobGVhc2UpIHtcbiAgICAgICAgYXBwZW5kKHsga2luZDogXCJlcnJvclwiLCB0ZXh0OiBsZWFzZUZhaWx1cmVUZXh0KGxlYXNlLCB0cnVlKSB9KTtcbiAgICAgICAgaWYgKGxlYXNlID09PSBcImxlYXNlLWxvc3RcIikge1xuICAgICAgICAgIHNldExlYXNlSGVsZCh7IGNvbnZJZDogcnVubmluZ0lkUmVmLmN1cnJlbnQgPz8gY29udlJlZi5jdXJyZW50Py5pZCA/PyBcIlwiLCByZXN1bWU6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFwcGVuZCh7IGtpbmQ6IFwiZXJyb3JcIiwgdGV4dDogKGUgYXMgRXJyb3IpPy5tZXNzYWdlID8/IFN0cmluZyhlKSB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChpc0pvdXJuYWxSZWZ1c2FsKGUpKSB7XG4gICAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgSk9VUk5BTF9SRUZVU0FMX1NVRkZJWCkpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBvZmZTdGVlckNoYW5nZSgpO1xuICAgICAgc3RlZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBkaXNwb3NlUGF1c2UoKTtcbiAgICAgIHNldFF1ZXVlZChbXSk7XG4gICAgICBzZXRTdGVlclRleHQoXCJcIik7XG4gICAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICAgIHNldFJ1bm5pbmcoZmFsc2UpO1xuICAgICAgcmVsZWFzZUhlbGRMZWFzZSgpOyAvLyBCRUZPUkUgcnVubmluZ0lkUmVmIGlzIGNsZWFyZWQg4oCUIGl0IGlzIHRoZSBpZCB0byByZWxlYXNlXG4gICAgICBydW5uaW5nSWRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBhYm9ydFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblJ1bkVuZCgpO1xuICAgIH1cbiAgfTtcblxuICAvKiogS2VlcCB0aGUgZmlsZXMsIGVuZCB0aGUgcnVuOiBmb2xkIHRoZSByZXBhaXJlZCB0cmFuc2NyaXB0IHNvIHRoZSBqb3VybmFsJ3NcbiAgICogIHdhdGVybWFyayBhZHZhbmNlcyBhbmQgdGhlIGNvbnZlcnNhdGlvbiBjbG9zZXMgY2xlYW5seS4gVGhlIEZJTEUgQ0hBTkdFU1xuICAgKiAgU1RBWSDigJQgdGhlIGNvcHkgc2F5cyBzbyAoc3BlYyDCpzUuMydzIHJldi0yIHRyYXApLiAqL1xuICBjb25zdCBrZWVwQW5kQ2xvc2UgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIGNvbnN0IHBlbmRpbmcgPSBwZW5kaW5nUmVzdW1lO1xuICAgIGNvbnN0IGNvbnYgPSBjb252UmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzdG9yZSB8fCAhcGVuZGluZyB8fCAhY29udiB8fCBwZW5kaW5nLmNvbnZJZCAhPT0gY29udi5pZCkgcmV0dXJuO1xuICAgIHNldFBlbmRpbmdSZXN1bWUobnVsbCk7XG4gICAgY29uc3QgcmVwYWlyZWQgPSByZXBhaXJUcmFuc2NyaXB0KHtcbiAgICAgIG1lc3NhZ2VzOiBwZW5kaW5nLnJlcGxheS5tZXNzYWdlcyxcbiAgICAgIHBlbmRpbmdFZmZlY3RzOiBwZW5kaW5nLnJlcGxheS5wZW5kaW5nRWZmZWN0cyxcbiAgICAgIHRyYWlsaW5nUGFydGlhbDogcGVuZGluZy5yZXBsYXkudHJhaWxpbmdQYXJ0aWFsLFxuICAgIH0pO1xuICAgIHRyeSB7XG4gICAgICBjb252UmVmLmN1cnJlbnQgPSBhd2FpdCBzdG9yZS5mb2xkKGNvbnYuaWQsIHtcbiAgICAgICAgbWVzc2FnZXM6IHJlcGFpcmVkLm1lc3NhZ2VzLFxuICAgICAgICByZXBvOiBjb252LnJlcG8gPz8gd29ya3NwYWNlUmVwbyxcbiAgICAgIH0pO1xuICAgICAgc2V0TG9nKG1lc3NhZ2VzVG9Mb2cocmVwYWlyZWQubWVzc2FnZXMpKTtcbiAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICB2b2lkIHBvc3RUb1JlZ2lvbihQQU5FTF9SRUdJT04sIHsgdHlwZTogXCJjb252ZXJzYXRpb24tdXBkYXRlZFwiLCBpZDogY29udi5pZCB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUjMtMzMzOiB0aGUgT1RIRVIgdmVyYi4gYHF1ZXVlYCBhcHBsaWVzIGF0IHRoZSBuZXh0IHR1cm4gYm91bmRhcnkgKHRoZSBpbi1mbGlnaHRcbiAgLy8gdHVybiBmaW5pc2hlcyk7IGBpbnRlcnJ1cHRgIGVuZHMgdGhlIGluLWZsaWdodCBtb2RlbCB0dXJuIG5vdyBhbmQgY29udGludWVzIHdpdGhcbiAgLy8gdGhlIGNvcnJlY3Rpb24uIE5laXRoZXIgZW5kcyB0aGUgcnVuIOKAlCB0aGF0IGlzIHdoYXQgU3RvcCBpcyBmb3IuXG4gIGNvbnN0IHN0ZWVyID0gdXNlQ2FsbGJhY2soKG1vZGU6IFN0ZWVyTW9kZSkgPT4ge1xuICAgIGNvbnN0IHMgPSBzdGVlclJlZi5jdXJyZW50O1xuICAgIGlmICghcykgcmV0dXJuO1xuICAgIGlmIChzLmVucXVldWUoc3RlZXJUZXh0LCBtb2RlKSkgc2V0U3RlZXJUZXh0KFwiXCIpO1xuICB9LCBbc3RlZXJUZXh0XSk7XG5cbiAgY29uc3QgY2FuY2VsU3RlZXIgPSB1c2VDYWxsYmFjaygoaWQ6IHN0cmluZykgPT4ge1xuICAgIHN0ZWVyUmVmLmN1cnJlbnQ/LmNhbmNlbChpZCk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EgY2EtLXN0YWdlXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImNhLWhkXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXRpdGxlXCI+e3RpdGxlIHx8IFwiQ29udmVyc2F0aW9uXCJ9PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYS1zdWJcIj5cbiAgICAgICAgICB7dG9vbHNldC50b29scy5sZW5ndGh9IHRvb2xzIHtzdGFnZVRyZWUgPyBcIihjYXRhbG9nICsgZmlsZXMpXCIgOiBcIihjYXRhbG9nIG9ubHkpXCJ9XG4gICAgICAgICAge3VzYWdlICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtcIiDCtyBcIn1cbiAgICAgICAgICAgICAge3VzYWdlLnNwZW50VG9rZW5zLnRvTG9jYWxlU3RyaW5nKCl9IHRva2Vuc1xuICAgICAgICAgICAgICB7LyogU2hvd24gb25seSB3aGVuIHRoZSBwcm92aWRlciBhY3R1YWxseSByZXBvcnRzIGNhY2hpbmcg4oCUIGFuIGFic2VudFxuICAgICAgICAgICAgICAgICAgY291bnRlciBpcyBub3QgYSB6ZXJvLCBhbmQgYSBcIjAgY2FjaGVkXCIgYmFkZ2Ugb24gYSBwcm92aWRlciB0aGF0IHNheXNcbiAgICAgICAgICAgICAgICAgIG5vdGhpbmcgd291bGQgYmUgYSBmYWJyaWNhdGVkIG1lYXN1cmVtZW50LiAqL31cbiAgICAgICAgICAgICAge3VzYWdlLmNhY2hlUmVhZFRva2VucyAhPT0gdW5kZWZpbmVkICYmIGAgwrcgJHt1c2FnZS5jYWNoZVJlYWRUb2tlbnMudG9Mb2NhbGVTdHJpbmcoKX0gY2FjaGVkYH1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7IXN0YWdlVHJlZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EtbGluZSBjYS1lcnJvclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYS1lcnJcIj5cbiAgICAgICAgICAgIFdhaXRpbmcgZm9yIHRoZSBhcHAncyB3b3Jrc3BhY2UgdG8gY29ubmVjdOKApiBmaWxlIHRvb2xzIGFyZSB1bmF2YWlsYWJsZSB1bnRpbCB0aGVuXG4gICAgICAgICAgICAoSSB3b24ndCBlZGl0IG15IG93biBmaWxlcykuXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtzdG9yZUVycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYS1saW5lIGNhLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLWVyclwiPntzdG9yZUVycm9yfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiY2EtbG9nXCIgYXJpYS1saXZlPVwicG9saXRlXCIgcmVmPXtsb2dSZWZ9IGtleT17Y29udklkID8/IFwibm9uZVwifT5cbiAgICAgICAgey8qIEZvbGRlZCB0b29sIGNhbGxzICsgbWFya2Rvd24gcmVwbGllcyAoUjMtNDczL1IzLTQ3NCkg4oCUIHNoYXJlZCB3aXRoIHRoZVxuICAgICAgICAgICAgc3RhbmRhbG9uZSBDb2RpbmdBZ2VudCBzbyBib3RoIHRyYW5zY3JpcHRzIHJlYWQgaWRlbnRpY2FsbHkuICovfVxuICAgICAgICA8VHJhbnNjcmlwdFJvd3MgbG9nPXtsb2d9IC8+XG4gICAgICAgIHsvKiBUaGUgbGl2ZSBzdHJlYW1pbmcgcm93IHN0YXlzIFBMQUlOIHRleHQgKFIzLTQ3NCk6IHJlLXBhcnNpbmcgYW5cbiAgICAgICAgICAgIGluY29tcGxldGUgbWFya2Rvd24gZG9jdW1lbnQgcGVyIGRlbHRhIGZsaWNrZXJzIChhbiB1bmNsb3NlZCBjb2RlIGZlbmNlXG4gICAgICAgICAgICBzd2FsbG93cyB0aGUgdGFpbCk7IHRoZSByb3cgc3dhcHMgdG8gcmVuZGVyZWQgbWFya2Rvd24gd2hlbiB0aGUgdHVyblxuICAgICAgICAgICAgY29tcGxldGVzIGludG8gYSB0cmFuc2NyaXB0IGVudHJ5IGFib3ZlLiAqL31cbiAgICAgICAge3RoaW5raW5nICYmIChcbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiY2EtbGluZSBjYS1saXZlXCI+XG4gICAgICAgICAgICB7LyogT3BlbiB3aGlsZSBpdCBzdHJlYW1zIOKAlCB0aGUgcG9pbnQgaXMgdG8gU0hPVyB0aGF0IHdvcmsgaXMgaGFwcGVuaW5nIOKAlFxuICAgICAgICAgICAgICAgIHRoZW4gY29sbGFwc2VkIG9uY2UgaXQgYmVjb21lcyBhIHRyYW5zY3JpcHQgcm93LiAqL31cbiAgICAgICAgICAgIDxkZXRhaWxzIGNsYXNzTmFtZT1cImNhLXJlYXNvbmluZ1wiIG9wZW4+XG4gICAgICAgICAgICAgIDxzdW1tYXJ5PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXRoaW5raW5nLWRvdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgdGhpbmtpbmfigKZcbiAgICAgICAgICAgICAgPC9zdW1tYXJ5PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYS1yZWFzb25pbmctYm9keVwiIHJlZj17cmVhc29uaW5nUmVmfT5cbiAgICAgICAgICAgICAgICB7dGhpbmtpbmd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApfVxuICAgICAgICB7c3RyZWFtaW5nICYmIChcbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiY2EtbGluZSBjYS10ZXh0IGNhLWxpdmVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXRleHRcIj57c3RyZWFtaW5nfTwvc3Bhbj5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApfVxuICAgICAgPC91bD5cblxuICAgICAgey8qIFIzLTMzMzogd2hhdCBpcyB3YWl0aW5nIHRvIGJlIGFwcGxpZWQsIGFuZCBhIHdheSB0byB0YWtlIGl0IGJhY2suIEEgcXVldWVkXG4gICAgICAgICAgZm9sbG93LXVwIHRoZSB1c2VyIGNhbm5vdCBzZWUgb3IgY2FuY2VsIGlzIHdvcnNlIHRoYW4gbm8gcXVldWUgYXQgYWxsLiAqL31cbiAgICAgIHtxdWV1ZWQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJjYS1xdWV1ZWRcIiBhcmlhLWxhYmVsPVwiUXVldWVkIGNvcnJlY3Rpb25zXCI+XG4gICAgICAgICAge3F1ZXVlZC5tYXAoKG0pID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e20uaWR9IGNsYXNzTmFtZT1cImNhLXF1ZXVlZC1pdGVtXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXF1ZXVlZC1tb2RlXCI+e20ubW9kZSA9PT0gXCJpbnRlcnJ1cHRcIiA/IFwibm93XCIgOiBcIm5leHQgc3RlcFwifTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtcXVldWVkLXRleHRcIj57bS50ZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhLXF1ZXVlZC1jYW5jZWxcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BDYW5jZWwgcXVldWVkIGNvcnJlY3Rpb246ICR7bS50ZXh0fWB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2FuY2VsU3RlZXIobS5pZCl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDDl1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdWw+XG4gICAgICApfVxuXG4gICAgICB7LyogUjMtNTYwIOKAlCB0aGUgYXR0ZW5kZWQtcmVzdW1lIGFmZm9yZGFuY2UgKFItQVJELTE1KSwgZXh0cmFjdGVkIChSMy02OTUpXG4gICAgICAgICAgc28gdGhlIHR3by1jaG9pY2Ugc2hhcGUgaXMgcGlubmVkIGJ5IGl0cyBvd24gdGVzdC4gU2VlXG4gICAgICAgICAgUmVzdW1lQWZmb3JkYW5jZS50c3ggYW5kIHRoZSBjb21tZW50IGFib3ZlIGByZXN1bWVSdW5gLiAqL31cbiAgICAgIHtwZW5kaW5nUmVzdW1lICYmICFydW5uaW5nICYmIChcbiAgICAgICAgPFJlc3VtZUFmZm9yZGFuY2VcbiAgICAgICAgICBqb3VybmFsRGVwdGg9e3BlbmRpbmdSZXN1bWUucmVwbGF5LmpvdXJuYWxEZXB0aH1cbiAgICAgICAgICBvblJlc3VtZT17KCkgPT4gdm9pZCByZXN1bWVSdW4oKX1cbiAgICAgICAgICBvbktlZXBBbmRFbmQ9eygpID0+IHZvaWQga2VlcEFuZENsb3NlKCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogUjMtNTYxIC8gUi1BUkQtMThhIOKAlCB0aGUgbGVhc2UgcmVuZGVycyBhcyBhbiBPRkZFUi4gVGhlIGNvcHkgc2F5cyBcIm1heSBiZVwiLFxuICAgICAgICAgIG5vdCBcImlzXCIsIGJlY2F1c2UgdGhhdCBpcyB0aGUgaG9uZXN0IHN0cmVuZ3RoIG9mIGFuIGFkdmlzb3J5IGxlYXNlOiB0aGVcbiAgICAgICAgICBob2xkZXIgY291bGQgYmUgYSBsaXZlIHdpbmRvdywgb3IgYSBmcmFtZSB0aGF0IHdhcyB0b3JuIGRvd24gd2l0aG91dCBhblxuICAgICAgICAgIHVubG9hZCBoYW5kbGVyIGFuZCB3aG9zZSBsZWFzZSBpcyBzaW1wbHkgd2FpdGluZyBvdXQgaXRzIFRUTC4gVGFraW5nIG92ZXJcbiAgICAgICAgICBjb250aW51ZXMgdGhlIGFjdGlvbiB0aGF0IHdhcyByZWZ1c2VkLCBzbyB0aGUgdXNlciBkb2VzIG5vdCBoYXZlIHRvIGFza1xuICAgICAgICAgIHR3aWNlLiAqL31cbiAgICAgIHtsZWFzZUhlbGQgJiYgIXJ1bm5pbmcgJiYgbGVhc2VIZWxkLmNvbnZJZCA9PT0gY29udklkICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYS1saW5lIGNhLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLWVyclwiPntsZWFzZUhlbGRUZXh0KHRydWUpfTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhLXJlc3VtZS1yb3dcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhLXJ1blwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IHJlc3VtZTogd2FzUmVzdW1lLCBjb252SWQ6IGZvckNvbnYgfSA9IGxlYXNlSGVsZDtcbiAgICAgICAgICAgICAgICB2b2lkIChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRoZSBvZmZlciBzdGF5cyB1cCB1bnRpbCB0aGUgdGFrZW92ZXIgYWN0dWFsbHkgbGFuZHMuIEFuXG4gICAgICAgICAgICAgICAgICAgIC8vIGVhcmxpZXIgdmVyc2lvbiBkaXNtaXNzZWQgaXQgZmlyc3QsIHNvIGEgcmVqZWN0ZWQgd3JpdGUgbGVmdFxuICAgICAgICAgICAgICAgICAgICAvLyB0aGUgdXNlciB3aXRoIG5vIG9mZmVyLCBubyBydW4gYW5kIG5vIG1lc3NhZ2UuXG4gICAgICAgICAgICAgICAgICAgIGlmIChzdG9yZSkgYXdhaXQgc3RvcmUudGFrZU92ZXJSdW4oZm9yQ29udik7XG4gICAgICAgICAgICAgICAgICAgIHNldExlYXNlSGVsZChudWxsKTtcbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgYXdhaXQgKHdhc1Jlc3VtZSA/IHJlc3VtZVJ1bigpIDogcnVuKCkpO1xuICAgICAgICAgICAgICAgIH0pKCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFRha2Ugb3ZlclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjYS1zdGVlci1idG5cIiBvbkNsaWNrPXsoKSA9PiBzZXRMZWFzZUhlbGQobnVsbCl9PlxuICAgICAgICAgICAgICBMZWF2ZSBpdCBhbG9uZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE9uZSByb3csIHR3byBtb2Rlcy4gTm90IHJ1bm5pbmc6IHR5cGUgYSBwcm9tcHQgYW5kIFJ1bi4gUnVubmluZzogdGhlIHNhbWVcbiAgICAgICAgICBmaWVsZCBTVEVFUlMg4oCUIFwiU2VuZCBhZnRlciB0aGlzIHN0ZXBcIiBxdWV1ZXMgZm9yIHRoZSB0dXJuIGJvdW5kYXJ5LCBcIlNlbmQgbm93XCJcbiAgICAgICAgICBpbnRlcnJ1cHRzIHRoZSBpbi1mbGlnaHQgdHVybiDigJQgYW5kIFN0b3Agc3RpbGwgZW5kcyB0aGUgcnVuLiBUaGUgdGhyZWUgdmVyYnNcbiAgICAgICAgICBzdGF5IHZpc2libHkgZGlzdGluY3QgKGV4aXQgMykgYW5kIHdyYXAgb24gYSBwaG9uZSAodmFsdWUgOCkuICovfVxuICAgICAge3J1bm5pbmcgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJjYS1zdGVlci1oaW50XCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgIHtzdGVlclRleHQudHJpbSgpXG4gICAgICAgICAgICA/IFwiVGhlIGFnZW50IGlzIHdvcmtpbmcuIFR5cGUgaGVyZSB0byByZWRpcmVjdCBpdC5cIlxuICAgICAgICAgICAgOiBcIlR5cGUgYSBtZXNzYWdlIHRvIHN0ZWVyXCJ9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhLXByb21wdC1yb3dcIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgY2xhc3NOYW1lPVwiY2EtcHJvbXB0XCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICBydW5uaW5nXG4gICAgICAgICAgICAgID8gXCJTdGVlciB0aGUgYWdlbnQg4oCUIHNheSB3aGF0IHRvIGRvIGRpZmZlcmVudGx54oCmXCJcbiAgICAgICAgICAgICAgOiBcIkFzayB0aGUgYWdlbnQgdG8gcmVhZCwgc2VhcmNoLCBvciBlZGl0IHlvdXIgYXBw4oCmXCJcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFsdWU9e3J1bm5pbmcgPyBzdGVlclRleHQgOiBwcm9tcHR9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiAocnVubmluZyA/IHNldFN0ZWVyVGV4dChlLnRhcmdldC52YWx1ZSkgOiBzZXRQcm9tcHQoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgICBpZiAoZS5rZXkgIT09IFwiRW50ZXJcIikgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKHJ1bm5pbmcpIHN0ZWVyKFwicXVldWVcIik7XG4gICAgICAgICAgICBlbHNlIHZvaWQgcnVuKCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBhcmlhLWxhYmVsPXtydW5uaW5nID8gXCJTdGVlciB0aGUgYWdlbnRcIiA6IFwiUHJvbXB0XCJ9XG4gICAgICAgIC8+XG4gICAgICAgIHtydW5uaW5nICYmIChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2Etc3RlZXItYnRuXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzdGVlclRleHQudHJpbSgpfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzdGVlcihcInF1ZXVlXCIpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBTZW5kIGFmdGVyIHRoaXMgc3RlcFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYS1zdGVlci1idG4gY2Etc3RlZXItbm93XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzdGVlclRleHQudHJpbSgpfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzdGVlcihcImludGVycnVwdFwiKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgU2VuZCBub3dcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY2EtcnVuXCJcbiAgICAgICAgICAvLyBXaGlsZSBydW5uaW5nLCB0aGUgYnV0dG9uIGJlY29tZXMgYSBsaXZlIFN0b3AgY29udHJvbCAoUjMtMjI0KTogaXQgbXVzdFxuICAgICAgICAgIC8vIHN0YXkgZW5hYmxlZCBzbyB0aGUgdXNlciBjYW4gYWJvcnQgdGhlIGluLWZsaWdodCB0dXJuIGFuZCBzdG9wIGJpbGxpbmcuXG4gICAgICAgICAgZGlzYWJsZWQ9e3J1bm5pbmcgPyBmYWxzZSA6ICFzdGFnZVRyZWV9XG4gICAgICAgICAgdGl0bGU9e1xuICAgICAgICAgICAgcnVubmluZ1xuICAgICAgICAgICAgICA/IFwiRW5kIHRoZSBydW4gYW5kIGFib3J0IHRoZSBpbi1mbGlnaHQgcmVxdWVzdFwiXG4gICAgICAgICAgICAgIDogIXN0YWdlVHJlZVxuICAgICAgICAgICAgICAgID8gXCJXYWl0aW5nIGZvciB0aGUgYXBwJ3Mgd29ya3NwYWNlIHRvIGNvbm5lY3RcIlxuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXG4gICAgICAgICAgfVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IChydW5uaW5nID8gc3RvcCgpIDogdm9pZCBydW4oKSl9XG4gICAgICAgID5cbiAgICAgICAgICB7cnVubmluZyA/IFwiU3RvcFwiIDogXCJSdW5cIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFNQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFTQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxRQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxhQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxpQkFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sU0FBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8sWUFBQSxHQUFBUCxPQUFBO0FBQ0EsSUFBQVEsT0FBQSxHQUFBUixPQUFBO0FBQ0EsSUFBQVMsZ0JBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLFVBQUEsR0FBQVYsT0FBQTtBQUNBLElBQUFXLFNBQUEsR0FBQVgsT0FBQTtBQUNBLElBQUFZLFNBQUEsR0FBQVosT0FBQTtBQUNBLElBQUFhLE9BQUEsR0FBQWIsT0FBQTtBQUNBLElBQUFjLGdCQUFBLEdBQUFkLE9BQUE7QUFDQSxJQUFBZSxrQkFBQSxHQUFBZixPQUFBO0FBQ0EsSUFBQWdCLGtCQUFBLEdBQUFoQixPQUFBO0FBTUEsSUFBQWlCLGVBQUEsR0FBQWpCLE9BQUE7QUFDQSxJQUFBa0IsaUJBQUEsR0FBQWxCLE9BQUE7QUFFQSxJQUFBbUIsV0FBQSxHQUFBbkIsT0FBQTtBQUNBLElBQUFvQixlQUFBLEdBQUFDLHNCQUFBLENBQUFyQixPQUFBO0FBQ0EsSUFBQXNCLGlCQUFBLEdBQUFELHNCQUFBLENBQUFyQixPQUFBO0FBQ0EsSUFBQXVCLGdCQUFBLEdBQUF2QixPQUFBO0FBQ0EsSUFBQXdCLFdBQUEsR0FBQXhCLE9BQUE7QUFDQUEsT0FBQTtBQUEyQixJQUFBeUIsV0FBQSxHQUFBekIsT0FBQTtBQUFBLElBQUEwQixFQUFBLEdBQUFDLFlBQUEsSUE1QzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXlDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBTix1QkFBQU8sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNBLE1BQU1HLGVBQWUsR0FDbkIsa0hBQWtIOztBQUVwSDtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxzQkFBc0IsR0FDMUIseUVBQXlFO0FBRTVELFNBQVNDLGlCQUFpQkEsQ0FBQSxFQUFHO0VBQUFQLEVBQUE7RUFDMUMsTUFBTVEsT0FBTyxHQUFHLElBQUFDLGVBQVUsRUFBQyxDQUFDO0VBQzVCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyxjQUFTLEVBQUMsQ0FBQztFQUMxQixNQUFNQyxRQUFRLEdBQUcsSUFBQUMsYUFBTSxFQUEyQixJQUFJLENBQUM7RUFDdkQsTUFBTUMsT0FBTyxHQUFHLElBQUFELGFBQU0sRUFBc0IsSUFBSSxDQUFDO0VBQ2pEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1FLGFBQWEsR0FBRyxJQUFBRixhQUFNLEVBQWlDLElBQUksQ0FBQztFQUNsRSxNQUFNRyxZQUFZLEdBQUcsSUFBQUgsYUFBTSxFQUE2QixJQUFJLENBQUM7RUFDN0Q7RUFDQTtFQUNBLE1BQU1JLFFBQVEsR0FBRyxJQUFBSixhQUFNLEVBQXlCLElBQUksQ0FBQztFQUNyRDtFQUNBO0VBQ0E7RUFDQSxNQUFNSyxRQUFRLEdBQUcsSUFBQUwsYUFBTSxFQUF5QixJQUFJLENBQUM7RUFDckQsTUFBTSxDQUFDTSxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBMEIsRUFBRSxDQUFDO0VBQ2pFLE1BQU0sQ0FBQ0MsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQzlDLE1BQU0sQ0FBQ0csR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQWEsRUFBRSxDQUFDO0VBQzlDLE1BQU0sQ0FBQ0ssTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBTixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQ3hDLE1BQU0sQ0FBQ08sU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBUixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQzlDO0VBQ0E7RUFDQSxNQUFNLENBQUNTLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQVYsZUFBUSxFQUFDLEVBQUUsQ0FBQztFQUM1QztFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNXLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQVosZUFBUSxFQUl4QixJQUFJLENBQUM7RUFDZixNQUFNLENBQUNhLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQWQsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUM3QztFQUNBO0VBQ0EsTUFBTWUsWUFBWSxHQUFHLElBQUF2QixhQUFNLEVBQWdCLElBQUksQ0FBQztFQUNoRCxNQUFNLENBQUN3QixLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFqQixlQUFRLEVBQVMsRUFBRSxDQUFDO0VBQzlDO0VBQ0E7RUFDQSxNQUFNLENBQUNrQixNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFuQixlQUFRLEVBQXFCb0IsU0FBUyxDQUFDO0VBQ25FO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNDLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQXRCLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ2pFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU0sQ0FBQ3VCLFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUcsSUFBQXhCLGVBQVEsRUFBNkMsSUFBSSxDQUFDO0VBQzVGO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDeUIsYUFBYSxFQUFFQyxxQkFBcUIsQ0FBQyxHQUFHLElBQUExQixlQUFRLEVBQWtELElBQUksQ0FBQztFQUM5RztFQUNBO0VBQ0EsTUFBTTJCLGdCQUFnQixHQUFHLElBQUFuQyxhQUFNLEVBQWtELElBQUksQ0FBQztFQUN0RixNQUFNb0MsZ0JBQWdCLEdBQUlDLENBQWtELElBQVc7SUFDckZGLGdCQUFnQixDQUFDRyxPQUFPLEdBQUdELENBQUM7SUFDNUJILHFCQUFxQixDQUFDRyxDQUFDLENBQUM7RUFDMUIsQ0FBQztFQUNEO0VBQ0E7RUFDQTtFQUNBLE1BQU1FLGlCQUFpQixHQUFHLElBQUF2QyxhQUFNLEVBQW9ELElBQUksQ0FBQzs7RUFFekY7RUFDQTtFQUNBO0VBQ0EsTUFBTXdDLE1BQU0sR0FBRyxJQUFBeEMsYUFBTSxFQUFtQixJQUFJLENBQUM7RUFDN0MsTUFBTXlDLFlBQVksR0FBRyxJQUFBekMsYUFBTSxFQUFrQixJQUFJLENBQUM7RUFDbEQ7RUFDQTtFQUNBO0VBQ0EsTUFBTTBDLGNBQWMsR0FBRyxJQUFBQyxjQUFPLEVBQzVCLE1BQU0sQ0FBQ2hDLEdBQUcsRUFBRU0sUUFBUSxFQUFFRixTQUFTLENBQUMsRUFDaEMsQ0FBQ0osR0FBRyxFQUFFTSxRQUFRLEVBQUVGLFNBQVMsQ0FDM0IsQ0FBQztFQUNELElBQUE2QixrQ0FBZ0IsRUFBQ0osTUFBTSxFQUFFRSxjQUFjLENBQUM7RUFDeEMsSUFBQUUsa0NBQWdCLEVBQUNILFlBQVksRUFBRXhCLFFBQVEsQ0FBQzs7RUFFeEM7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTRCLFNBQVMsR0FBRyxJQUFBRixjQUFPLEVBQUMsTUFBTSxJQUFBRyw4QkFBcUIsRUFBQ2pELE1BQU0sRUFBRSxJQUFBa0Qsb0JBQWUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDbEQsTUFBTSxDQUFDLENBQUM7O0VBRTNGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1tRCxNQUFNLEdBQUcsSUFBQUwsY0FBTyxFQUFDLE1BQU0sSUFBQU0saUJBQVksRUFBQyxDQUFDLEVBQUVDLFFBQVEsQ0FBQ0YsTUFBTSxLQUFLLElBQUksRUFBRSxFQUFFLENBQUM7RUFFMUUsTUFBTTtJQUFFRyxPQUFPO0lBQUVDO0VBQU8sQ0FBQyxHQUFHLElBQUFULGNBQU8sRUFBQyxNQUFNO0lBQ3hDO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQ0UsU0FBUyxFQUFFLE9BQU8sSUFBQVEsa0JBQVUsRUFBQyxJQUFBQyx1QkFBYyxFQUFDM0QsT0FBTyxDQUFDLENBQUM7SUFDMUQsTUFBTTRELE9BQU8sR0FBRyxJQUFBQyx3QkFBZSxFQUFDO01BQUVDLElBQUksRUFBRVosU0FBUyxDQUFDWSxJQUFJO01BQUVDLFFBQVEsRUFBRWIsU0FBUyxDQUFDYSxRQUFRO01BQUVWO0lBQU8sQ0FBQyxDQUFDO0lBQy9GLE1BQU1XLFlBQVksR0FBRyxJQUFBQyxrQ0FBb0IsRUFBQztNQUFFSCxJQUFJLEVBQUVaLFNBQVMsQ0FBQ1ksSUFBSTtNQUFFQyxRQUFRLEVBQUViLFNBQVMsQ0FBQ2E7SUFBUyxDQUFDLENBQUM7SUFDakcsTUFBTUcsZ0JBQWdCLEdBQUcsSUFBQUMsMENBQXdCLEVBQUMsQ0FBQztJQUNuRDtJQUNBO0lBQ0EsTUFBTUMsUUFBUSxHQUFHLElBQUFDLDBCQUFnQixFQUFDO01BQUVyRTtJQUFRLENBQUMsQ0FBQztJQUM5QztJQUNBO0lBQ0EsT0FBTyxJQUFBMEQsa0JBQVUsRUFBQyxJQUFBWSxzQkFBYSxFQUFDLElBQUFYLHVCQUFjLEVBQUMzRCxPQUFPLENBQUMsRUFBRTRELE9BQU8sRUFBRUksWUFBWSxFQUFFRSxnQkFBZ0IsRUFBRUUsUUFBUSxDQUFDLENBQUM7RUFDOUcsQ0FBQyxFQUFFLENBQUNwRSxPQUFPLEVBQUVrRCxTQUFTLEVBQUVHLE1BQU0sQ0FBQyxDQUFDO0VBRWhDLE1BQU1rQixNQUFNLEdBQUk3RSxDQUFXLElBQUt1QixNQUFNLENBQUV1RCxDQUFDLElBQUssQ0FBQyxHQUFHQSxDQUFDLEVBQUU5RSxDQUFDLENBQUMsQ0FBQzs7RUFFeEQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQStFLGdDQUFlLEVBQUNyRSxRQUFRLEVBQUV3QixZQUFZLEVBQUVGLE9BQU8sQ0FBQzs7RUFFaEQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNZ0QsZ0JBQWdCLEdBQUcsSUFBQUMsa0JBQVcsRUFBQyxNQUFNO0lBQ3pDLE1BQU1DLEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87SUFDOUIsTUFBTWtDLEVBQUUsR0FBR2pELFlBQVksQ0FBQ2UsT0FBTztJQUMvQixJQUFJaUMsS0FBSyxJQUFJQyxFQUFFLEVBQUUsS0FBS0QsS0FBSyxDQUFDRSxVQUFVLENBQUNELEVBQUUsQ0FBQyxDQUFDRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUM1RCxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTUMsZ0JBQWdCLEdBQUcsSUFBQUwsa0JBQVcsRUFBRU0sSUFBa0IsSUFBSztJQUMzRDNFLE9BQU8sQ0FBQ3FDLE9BQU8sR0FBR3NDLElBQUk7SUFDdEJqRCxTQUFTLENBQUNpRCxJQUFJLENBQUNKLEVBQUUsQ0FBQztJQUNsQi9DLFFBQVEsQ0FBQ21ELElBQUksQ0FBQ3BELEtBQUssQ0FBQztJQUNwQlosTUFBTSxDQUFDLElBQUFpRSx5QkFBYSxFQUFDRCxJQUFJLENBQUNFLFFBQVEsQ0FBQyxDQUFDO0lBQ3BDOUQsWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUNoQmIsWUFBWSxDQUFDbUMsT0FBTyxFQUFFeUMsTUFBTSxDQUFDLENBQUM7SUFDOUI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBM0MsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0lBQ3RCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQUosWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQixNQUFNdUMsS0FBSyxHQUFHeEUsUUFBUSxDQUFDdUMsT0FBTztJQUM5QixJQUFJaUMsS0FBSyxFQUFFUyxVQUFVLENBQUMsQ0FBQyxFQUFFO01BQ3ZCLE1BQU1DLE9BQU8sR0FBR1YsS0FBSyxDQUNsQlcsTUFBTSxDQUFDTixJQUFJLENBQUNKLEVBQUUsQ0FBQyxDQUNmVyxJQUFJLENBQUVDLENBQUMsSUFBSztRQUNYLElBQUluRixPQUFPLENBQUNxQyxPQUFPLEVBQUVrQyxFQUFFLEtBQUtJLElBQUksQ0FBQ0osRUFBRSxJQUFJakQsWUFBWSxDQUFDZSxPQUFPLEtBQUssSUFBSSxFQUFFO1FBQ3RFLElBQUksQ0FBQyxJQUFBK0MsbUJBQVcsRUFBQ0QsQ0FBQyxDQUFDLEVBQUU7UUFDckJ4RSxNQUFNLENBQUMsSUFBQWlFLHlCQUFhLEVBQUNPLENBQUMsQ0FBQ04sUUFBUSxDQUFDLENBQUM7UUFDakMxQyxnQkFBZ0IsQ0FBQztVQUFFVixNQUFNLEVBQUVrRCxJQUFJLENBQUNKLEVBQUU7VUFBRVUsTUFBTSxFQUFFRTtRQUFFLENBQUMsQ0FBQztNQUNsRCxDQUFDLENBQUMsQ0FDRFYsS0FBSyxDQUFFckYsQ0FBQyxJQUFLO1FBQ1o7UUFDQTtRQUNBO1FBQ0EsSUFBSVksT0FBTyxDQUFDcUMsT0FBTyxFQUFFa0MsRUFBRSxLQUFLSSxJQUFJLENBQUNKLEVBQUUsRUFBRTtRQUNyQyxJQUFJLElBQUFjLG1DQUFnQixFQUFDakcsQ0FBQyxDQUFDLEVBQUU7VUFDdkI2RSxNQUFNLENBQUM7WUFDTHFCLElBQUksRUFBRSxPQUFPO1lBQ2JDLElBQUksRUFBRTtVQUNSLENBQUMsQ0FBQztRQUNKLENBQUMsTUFBTTtVQUNMMUQsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztRQUM3QztNQUNGLENBQUMsQ0FBQyxDQUNEa0csT0FBTyxDQUFDLE1BQU07UUFDYjtRQUNBO1FBQ0E7UUFDQSxJQUFJbkQsaUJBQWlCLENBQUNELE9BQU8sRUFBRTJDLE9BQU8sS0FBS0EsT0FBTyxFQUFFMUMsaUJBQWlCLENBQUNELE9BQU8sR0FBRyxJQUFJO01BQ3RGLENBQUMsQ0FBQztNQUNKQyxpQkFBaUIsQ0FBQ0QsT0FBTyxHQUFHO1FBQUVaLE1BQU0sRUFBRWtELElBQUksQ0FBQ0osRUFBRTtRQUFFUztNQUFRLENBQUM7SUFDMUQ7RUFDRixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNVSxpQkFBaUIsR0FBRyxJQUFBM0YsYUFBTSxFQUF3QixJQUFJLENBQUM7RUFDN0QsSUFBQTRGLGdCQUFTLEVBQUMsTUFBTTtJQUNkRCxpQkFBaUIsQ0FBQ3JELE9BQU8sR0FBRyxJQUFBdUQsb0NBQW9CLEVBQUM7TUFDL0NDLElBQUksRUFBRW5CLGdCQUFnQjtNQUN0Qm9CLFNBQVMsRUFBR3ZCLEVBQUUsSUFBS2pELFlBQVksQ0FBQ2UsT0FBTyxLQUFLa0M7SUFDOUMsQ0FBQyxDQUFDO0lBQ0YsT0FBTyxNQUFNO01BQ1htQixpQkFBaUIsQ0FBQ3JELE9BQU8sR0FBRyxJQUFJO0lBQ2xDLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ3FDLGdCQUFnQixDQUFDLENBQUM7O0VBRXRCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1xQixhQUFhLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDLEVBQUVDLEtBQUs7O0VBRTNDO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFlBQVksR0FBRyxJQUFBbkcsYUFBTSxFQUFDZ0csYUFBYSxDQUFDO0VBQzFDLElBQUFKLGdCQUFTLEVBQUMsTUFBTTtJQUNkTyxZQUFZLENBQUM3RCxPQUFPLEdBQUcwRCxhQUFhO0VBQ3RDLENBQUMsRUFBRSxDQUFDQSxhQUFhLENBQUMsQ0FBQzs7RUFFbkI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUFKLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlRLElBQUksR0FBRyxJQUFJO0lBQ2YsS0FBSyxDQUFDLFlBQVk7TUFDaEIsSUFBSTtRQUNGLE1BQU03QixLQUFLLEdBQUcsTUFBTSxJQUFBOEIsd0NBQXFCLEVBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUNELElBQUksRUFBRTtRQUNYckcsUUFBUSxDQUFDdUMsT0FBTyxHQUFHaUMsS0FBSztRQUN4QnpDLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDbkIsTUFBTTZELGlCQUFpQixDQUFDckQsT0FBTyxDQUFFZ0UsV0FBVyxDQUFDL0IsS0FBSyxFQUFFNEIsWUFBWSxDQUFDN0QsT0FBTyxDQUFDO01BQzNFLENBQUMsQ0FBQyxPQUFPakQsQ0FBQyxFQUFFO1FBQ1Y7UUFDQTtRQUNBLElBQUkrRyxJQUFJLEVBQUV0RSxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO01BQ3ZEO0lBQ0YsQ0FBQyxFQUFFLENBQUM7SUFDSjtJQUNBO0lBQ0E7SUFDQTtJQUNBVSxhQUFhLENBQUNvQyxPQUFPLEdBQUcsSUFBSTtJQUM1Qm5DLFlBQVksQ0FBQ21DLE9BQU8sR0FBRyxJQUFBaUUsNENBQXlCLEVBQzlDLE1BQU1yRyxhQUFhLENBQUNvQyxPQUFPLEVBQzNCLE9BQU87TUFBRXNDLElBQUksRUFBRTNFLE9BQU8sQ0FBQ3FDLE9BQU87TUFBRWtFLFNBQVMsRUFBRWpGLFlBQVksQ0FBQ2U7SUFBUSxDQUFDLENBQ25FLENBQUM7SUFDRCxLQUFLLElBQUFtRSw4Q0FBMkIsRUFBQyxDQUFDLENBQy9CdEIsSUFBSSxDQUFFdUIsQ0FBQyxJQUFLO01BQ1gsSUFBSU4sSUFBSSxFQUFFO1FBQ1JsRyxhQUFhLENBQUNvQyxPQUFPLEdBQUdvRSxDQUFDO1FBQ3pCO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBdkcsWUFBWSxDQUFDbUMsT0FBTyxFQUFFeUMsTUFBTSxDQUFDLENBQUM7TUFDaEM7SUFDRixDQUFDLENBQUMsQ0FDREwsS0FBSyxDQUFFckYsQ0FBQyxJQUFLO01BQ1o7TUFDQTtNQUNBc0gsT0FBTyxDQUFDQyxJQUFJLENBQUMsb0VBQW9FLEVBQUV2SCxDQUFDLENBQUM7SUFDdkYsQ0FBQyxDQUFDO0lBQ0osT0FBTyxNQUFNO01BQ1grRyxJQUFJLEdBQUcsS0FBSztNQUNaO01BQ0E7TUFDQWpHLFlBQVksQ0FBQ21DLE9BQU8sRUFBRXVFLFNBQVMsQ0FBQyxDQUFDO01BQ2pDMUcsWUFBWSxDQUFDbUMsT0FBTyxHQUFHLElBQUk7TUFDM0JwQyxhQUFhLENBQUNvQyxPQUFPLEdBQUcsSUFBSTtJQUM5QixDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBLElBQUFzRCxnQkFBUyxFQUFDLE1BQU07SUFDZCxPQUFPLElBQUFrQixvQkFBZSxFQUFFQyxDQUFDLElBQUs7TUFDNUIsSUFBSSxJQUFBQyx5QkFBUSxFQUFDRCxDQUFDLENBQUNFLElBQUksQ0FBQyxFQUFFLEtBQUt0QixpQkFBaUIsQ0FBQ3JELE9BQU8sQ0FBRTRFLE1BQU0sQ0FBQ0gsQ0FBQyxDQUFDRSxJQUFJLENBQUN6QyxFQUFFLENBQUM7SUFDekUsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBb0IsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsS0FBSyxJQUFBdUIsaUJBQVksRUFBQ0MsNkJBQVksRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBb0IsQ0FBQyxDQUFDLENBQUMzQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNoRixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTTRDLEdBQUcsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDdEIsSUFBSSxDQUFDekcsTUFBTSxDQUFDMEcsSUFBSSxDQUFDLENBQUMsSUFBSWxHLE9BQU8sRUFBRTtJQUMvQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTW1HLFdBQVcsR0FBR3ZILE9BQU8sQ0FBQ3FDLE9BQU87SUFDbkMsTUFBTW1GLFFBQVEsR0FBR2xGLGlCQUFpQixDQUFDRCxPQUFPO0lBQzFDLElBQUlrRixXQUFXLElBQUlDLFFBQVEsSUFBSUEsUUFBUSxDQUFDL0YsTUFBTSxLQUFLOEYsV0FBVyxDQUFDaEQsRUFBRSxFQUFFO01BQ2pFLE1BQU1pRCxRQUFRLENBQUN4QyxPQUFPO0lBQ3hCO0lBQ0EsTUFBTXlDLE9BQU8sR0FBR3ZGLGdCQUFnQixDQUFDRyxPQUFPO0lBQ3hDLElBQUlvRixPQUFPLElBQUl6SCxPQUFPLENBQUNxQyxPQUFPLElBQUlvRixPQUFPLENBQUNoRyxNQUFNLEtBQUt6QixPQUFPLENBQUNxQyxPQUFPLENBQUNrQyxFQUFFLEVBQUU7TUFDdkVOLE1BQU0sQ0FBQztRQUNMcUIsSUFBSSxFQUFFLE9BQU87UUFDYkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO01BQ0Y7SUFDRjtJQUNBcEQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0lBQ3RCO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQ1MsU0FBUyxFQUFFO01BQ2RxQixNQUFNLENBQUM7UUFBRXFCLElBQUksRUFBRSxNQUFNO1FBQUVDLElBQUksRUFBRTNFO01BQU8sQ0FBQyxDQUFDO01BQ3RDcUQsTUFBTSxDQUFDO1FBQ0xxQixJQUFJLEVBQUUsT0FBTztRQUNiQyxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUM7TUFDRjFFLFNBQVMsQ0FBQyxFQUFFLENBQUM7TUFDYjtJQUNGO0lBQ0EsTUFBTXlELEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87SUFDOUI7SUFDQTtJQUNBLElBQUlzQyxJQUFJLEdBQUczRSxPQUFPLENBQUNxQyxPQUFPO0lBQzFCLElBQUksQ0FBQ3NDLElBQUksSUFBSUwsS0FBSyxFQUFFO01BQ2xCLElBQUk7UUFDRkssSUFBSSxHQUFHLE1BQU1MLEtBQUssQ0FBQ29ELE1BQU0sQ0FBQy9GLFNBQVMsRUFBRW9FLGFBQWEsQ0FBQztRQUNuRC9GLE9BQU8sQ0FBQ3FDLE9BQU8sR0FBR3NDLElBQUk7UUFDdEJlLGlCQUFpQixDQUFDckQsT0FBTyxDQUFFc0YsS0FBSyxDQUFDaEQsSUFBSSxDQUFDO1FBQ3RDbkQsUUFBUSxDQUFDbUQsSUFBSSxDQUFDcEQsS0FBSyxDQUFDO1FBQ3BCTSxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3JCLENBQUMsQ0FBQyxPQUFPekMsQ0FBQyxFQUFFO1FBQ1Y7UUFDQTtRQUNBO1FBQ0F5QyxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO01BQzdDO0lBQ0Y7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSStFLEtBQUssSUFBSUssSUFBSSxFQUFFO01BQ2pCLElBQUk7UUFDRixJQUFJLENBQUMsTUFBTUwsS0FBSyxDQUFDc0QsVUFBVSxDQUFDakQsSUFBSSxDQUFDSixFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7VUFDaER4QyxZQUFZLENBQUM7WUFBRU4sTUFBTSxFQUFFa0QsSUFBSSxDQUFDSixFQUFFO1lBQUVzRCxNQUFNLEVBQUU7VUFBTSxDQUFDLENBQUM7VUFDaEQ7UUFDRjtNQUNGLENBQUMsQ0FBQyxPQUFPekksQ0FBQyxFQUFFO1FBQ1Y7UUFDQTtRQUNBO1FBQ0E7UUFDQXlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUcsZUFBZSxDQUFDLENBQUM7TUFDN0M7SUFDRjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU11SSxPQUFPLEdBQUduRCxJQUFJLElBQUlMLEtBQUssRUFBRVMsVUFBVSxDQUFDLENBQUMsR0FBR0osSUFBSSxHQUFHLElBQUk7SUFDekQsSUFBSUwsS0FBSyxJQUFJSyxJQUFJLElBQUksQ0FBQ0wsS0FBSyxDQUFDUyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUNuRCxVQUFVLEVBQUU7TUFDdkRDLGFBQWEsQ0FDWCwwSkFDRixDQUFDO0lBQ0g7SUFDQSxNQUFNa0csT0FBTyxHQUFHcEQsSUFBSSxFQUFFRSxRQUFRLElBQUksRUFBRTtJQUNwQyxNQUFNbUQsT0FBTyxHQUFHcEgsTUFBTTtJQUN0QkMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUNiUSxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2hCQyxZQUFZLENBQUNlLE9BQU8sR0FBR3NDLElBQUksRUFBRUosRUFBRSxJQUFJLElBQUk7SUFDdkNyRSxZQUFZLENBQUNtQyxPQUFPLEVBQUU0RixVQUFVLENBQUN0RCxJQUFJLEVBQUVKLEVBQUUsSUFBSSxJQUFJLENBQUM7SUFDbER4RCxZQUFZLENBQUMsRUFBRSxDQUFDO0lBQ2hCRSxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQ2ZFLFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDZDhDLE1BQU0sQ0FBQztNQUFFcUIsSUFBSSxFQUFFLE1BQU07TUFBRUMsSUFBSSxFQUFFeUM7SUFBUSxDQUFDLENBQUM7SUFDdkMsTUFBTUUsVUFBVSxHQUFHLElBQUlDLGVBQWUsQ0FBQyxDQUFDO0lBQ3hDaEksUUFBUSxDQUFDa0MsT0FBTyxHQUFHNkYsVUFBVTtJQUM3QixNQUFNRSxRQUFRLEdBQUcsSUFBSUMseUJBQWUsQ0FBQyxDQUFDO0lBQ3RDakksUUFBUSxDQUFDaUMsT0FBTyxHQUFHK0YsUUFBUTtJQUMzQjtJQUNBO0lBQ0E7SUFDQSxNQUFNO01BQUVFLEtBQUs7TUFBRUMsT0FBTyxFQUFFQztJQUFhLENBQUMsR0FBRyxJQUFBQyx3QkFBYyxFQUFDLENBQUM7SUFDekRuSSxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQ2IsTUFBTW9JLGNBQWMsR0FBR04sUUFBUSxDQUFDTyxRQUFRLENBQUVsQixPQUFPLElBQUtuSCxTQUFTLENBQUMsQ0FBQyxHQUFHbUgsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUM5RTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTW1CLFlBQVksR0FBRyxJQUFBQyw4QkFBaUIsRUFBQztNQUFFQyxLQUFLLEVBQUUsSUFBQUMscUJBQVEsRUFBQztJQUFFLENBQUMsQ0FBQztJQUM3RCxJQUFJO01BQ0YsTUFBTUMsVUFBVSxHQUFHLE1BQU0sSUFBQUMsbUJBQVEsRUFBQztRQUNoQ0MsTUFBTSxFQUFFLElBQUFDLHNDQUFxQixFQUFDLENBQUM7UUFDL0JDLEtBQUssRUFBRWxHLE9BQU8sQ0FBQ2tHLEtBQUs7UUFDcEJDLE9BQU8sRUFBRW5HLE9BQU8sQ0FBQ21HLE9BQU87UUFDeEJDLE1BQU0sRUFBRSxJQUFBQyxnQ0FBbUIsRUFBQ1gsWUFBWSxFQUFFLElBQUFZLDRCQUFlLEVBQUM7VUFBRUosS0FBSyxFQUFFbEcsT0FBTyxDQUFDa0csS0FBSztVQUFFSyxhQUFhLEVBQUU3RyxTQUFTLEVBQUVZLElBQUk7VUFBRUw7UUFBTyxDQUFDLENBQUMsQ0FBQztRQUM1SHVHLFNBQVMsRUFBRTNELGFBQWEsSUFBSXBFLFNBQVM7UUFDckNnSSxZQUFZLEVBQUVmLFlBQVk7UUFDMUJiLE9BQU87UUFDUG5ILE1BQU0sRUFBRW9ILE9BQU87UUFDZjtRQUNBNEIsTUFBTSxFQUFFMUIsVUFBVSxDQUFDMEIsTUFBTTtRQUN6QjtRQUNBeEIsUUFBUTtRQUNSO1FBQ0FFLEtBQUs7UUFDTDtRQUNBdUIsYUFBYSxFQUFFLElBQUE3RyxpQkFBWSxFQUFDLENBQUMsRUFBRUMsUUFBUSxDQUFDNkcsZ0JBQWdCO1FBQ3hEQyxNQUFNLEVBQUU7VUFDTjtVQUNBO1VBQ0E7VUFDQSxJQUFJakMsT0FBTyxHQUNQO1lBQ0VrQyxVQUFVLEVBQUUsTUFBT0MsQ0FBQyxJQUFLO2NBQ3ZCLE1BQU0zRixLQUFLLENBQUVMLE1BQU0sQ0FBQzZELE9BQU8sQ0FBQ3ZELEVBQUUsRUFBRTBGLENBQUMsQ0FBQztZQUNwQztVQUNGLENBQUMsR0FDRCxDQUFDLENBQUMsQ0FBQztVQUNQQyxnQkFBZ0IsRUFBRzNFLElBQUksSUFBS3hFLFlBQVksQ0FBRW9KLENBQUMsSUFBS0EsQ0FBQyxHQUFHNUUsSUFBSSxDQUFDO1VBQ3pEO1VBQ0E7VUFDQTtVQUNBNkUsZ0JBQWdCLEVBQUc3RSxJQUFJLElBQUt0RSxXQUFXLENBQUVvSixDQUFDLElBQUtBLENBQUMsR0FBRzlFLElBQUksQ0FBQztVQUN4RCtFLFdBQVcsRUFBR0MsS0FBSyxJQUFLO1lBQ3RCdEosV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUNmZ0QsTUFBTSxDQUNKc0csS0FBSyxDQUFDQyxZQUFZLEtBQUs3SSxTQUFTLEdBQzVCO2NBQUUyRCxJQUFJLEVBQUUsV0FBVztjQUFFQyxJQUFJLEVBQUUsRUFBRTtjQUFFa0YsUUFBUSxFQUFFO1lBQUssQ0FBQyxHQUMvQztjQUFFbkYsSUFBSSxFQUFFLFdBQVc7Y0FBRUMsSUFBSSxFQUFFZ0YsS0FBSyxDQUFDaEY7WUFBSyxDQUM1QyxDQUFDO1VBQ0gsQ0FBQztVQUNEbUYsZUFBZSxFQUFHbkYsSUFBSSxJQUFLO1lBQ3pCO1lBQ0E7WUFDQSxJQUFJQSxJQUFJLEtBQUtvRiwrQkFBcUIsRUFBRTFHLE1BQU0sQ0FBQztjQUFFcUIsSUFBSSxFQUFFO1lBQWMsQ0FBQyxDQUFDLENBQUMsS0FDL0QsSUFBSUMsSUFBSSxDQUFDK0IsSUFBSSxDQUFDLENBQUMsRUFBRXJELE1BQU0sQ0FBQztjQUFFcUIsSUFBSSxFQUFFLE1BQU07Y0FBRUM7WUFBSyxDQUFDLENBQUM7WUFDcER4RSxZQUFZLENBQUMsRUFBRSxDQUFDO1VBQ2xCLENBQUM7VUFDRDZKLFNBQVMsRUFBRUEsQ0FBQ0MsSUFBSSxFQUFFQyxLQUFLLEtBQUs3RyxNQUFNLENBQUM7WUFBRXFCLElBQUksRUFBRSxNQUFNO1lBQUV1RixJQUFJO1lBQUVDO1VBQU0sQ0FBQyxDQUFDO1VBQ2pFQyxZQUFZLEVBQUVBLENBQUNGLElBQUksRUFBRTFGLENBQUMsS0FBS2xCLE1BQU0sQ0FBQztZQUFFcUIsSUFBSSxFQUFFLFFBQVE7WUFBRXVGLElBQUk7WUFBRUcsT0FBTyxFQUFFN0YsQ0FBQyxDQUFDNkYsT0FBTztZQUFFQyxPQUFPLEVBQUU5RixDQUFDLENBQUM4RjtVQUFRLENBQUMsQ0FBQztVQUNuR0MsT0FBTyxFQUFFQSxDQUFBLEtBQU1qSCxNQUFNLENBQUM7WUFBRXFCLElBQUksRUFBRTtVQUFRLENBQUMsQ0FBQztVQUN4QzZGLE9BQU8sRUFBR0MsQ0FBQyxJQUNUakssUUFBUSxDQUFDO1lBQ1BrSyxXQUFXLEVBQUVELENBQUMsQ0FBQ0MsV0FBVztZQUMxQkMsZUFBZSxFQUFFRixDQUFDLENBQUNFLGVBQWU7WUFDbENDLGdCQUFnQixFQUFFSCxDQUFDLENBQUNHO1VBQ3RCLENBQUMsQ0FBQztVQUNKQyxTQUFTLEVBQUVBLENBQUM7WUFBRUMsZUFBZTtZQUFFSDtVQUFnQixDQUFDLEtBQUs7WUFDbkRySCxNQUFNLENBQUM7Y0FDTHFCLElBQUksRUFBRSxZQUFZO2NBQ2xCO2NBQ0E7Y0FDQTtjQUNBO2NBQ0FvRyxPQUFPLEVBQ0wsR0FBR0QsZUFBZSw4QkFBOEIsSUFDL0NILGVBQWUsS0FBSzNKLFNBQVMsR0FBRyxNQUFNMkosZUFBZSw0QkFBNEIsR0FBRyxFQUFFO1lBQzNGLENBQUMsQ0FBQztZQUNGO1lBQ0E7WUFDQTtZQUNBO1lBQ0EsSUFBSXhELE9BQU8sRUFBRTtjQUNYLEtBQUt4RCxLQUFLLENBQUVxSCxJQUFJLENBQUM3RCxPQUFPLENBQUN2RCxFQUFFLENBQUMsQ0FBQ0UsS0FBSyxDQUFFckYsQ0FBQyxJQUFLO2dCQUN4Q3NILE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLDZEQUE2RCxFQUFFdkgsQ0FBQyxDQUFDO2NBQ2hGLENBQUMsQ0FBQztZQUNKO1VBQ0YsQ0FBQztVQUNEd00sT0FBTyxFQUFFQSxDQUFDO1lBQUUvRztVQUFTLENBQUMsS0FBSztZQUN6QixLQUFLLE1BQU1pQyxDQUFDLElBQUlqQyxRQUFRLEVBQUVaLE1BQU0sQ0FBQztjQUFFcUIsSUFBSSxFQUFFLE9BQU87Y0FBRXVHLElBQUksRUFBRS9FLENBQUMsQ0FBQytFLElBQUk7Y0FBRXRHLElBQUksRUFBRXVCLENBQUMsQ0FBQ3ZCO1lBQUssQ0FBQyxDQUFDO1VBQ2pGO1FBQ0Y7TUFDRixDQUFDLENBQUM7TUFDRixJQUFJWixJQUFJLElBQUlMLEtBQUssRUFBRTtRQUNqQixNQUFNd0gsUUFBUSxHQUFHbkgsSUFBSSxDQUFDcEQsS0FBSyxLQUFLLGtCQUFrQixHQUFHLElBQUF3Syw4QkFBVyxFQUFDL0MsVUFBVSxDQUFDLEdBQUdyRSxJQUFJLENBQUNwRCxLQUFLO1FBQ3pGLElBQUk7VUFDRjtVQUNBO1VBQ0E7VUFDQTtVQUNBdkIsT0FBTyxDQUFDcUMsT0FBTyxHQUFHLE1BQU1pQyxLQUFLLENBQUNxSCxJQUFJLENBQUNoSCxJQUFJLENBQUNKLEVBQUUsRUFBRTtZQUMxQ00sUUFBUSxFQUFFbUUsVUFBVTtZQUNwQnpILEtBQUssRUFBRXVLLFFBQVE7WUFDZkUsSUFBSSxFQUFFckgsSUFBSSxDQUFDcUgsSUFBSSxJQUFJakc7VUFDckIsQ0FBQyxDQUFDO1VBQ0Z2RSxRQUFRLENBQUNzSyxRQUFRLENBQUM7VUFDbEJqSyxhQUFhLENBQUMsSUFBSSxDQUFDO1VBQ25CO1VBQ0EzQixZQUFZLENBQUNtQyxPQUFPLEVBQUU0SixPQUFPLENBQUMsQ0FBQztVQUMvQixLQUFLLElBQUEvRSxpQkFBWSxFQUFDQyw2QkFBWSxFQUFFO1lBQUVDLElBQUksRUFBRSxzQkFBc0I7WUFBRTdDLEVBQUUsRUFBRUksSUFBSSxDQUFDSjtVQUFHLENBQUMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNoRyxDQUFDLENBQUMsT0FBT3JGLENBQUMsRUFBRTtVQUNWO1VBQ0E7VUFDQTtVQUNBeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztRQUM3QztNQUNGO0lBQ0YsQ0FBQyxDQUFDLE9BQU9ILENBQUMsRUFBRTtNQUNWO01BQ0E7TUFDQTtNQUNBLE1BQU04TSxLQUFLLEdBQUcsSUFBQUMsd0JBQVksRUFBQy9NLENBQUMsQ0FBQztNQUM3QixJQUFJOE0sS0FBSyxFQUFFO1FBQ1RqSSxNQUFNLENBQUM7VUFBRXFCLElBQUksRUFBRSxPQUFPO1VBQUVDLElBQUksRUFBRSxJQUFBNkcsNEJBQWdCLEVBQUNGLEtBQUssRUFBRSxJQUFJO1FBQUUsQ0FBQyxDQUFDO1FBQzlELElBQUlBLEtBQUssS0FBSyxZQUFZLEVBQUU7VUFDMUJuSyxZQUFZLENBQUM7WUFBRU4sTUFBTSxFQUFFSCxZQUFZLENBQUNlLE9BQU8sSUFBSXJDLE9BQU8sQ0FBQ3FDLE9BQU8sRUFBRWtDLEVBQUUsSUFBSSxFQUFFO1lBQUVzRCxNQUFNLEVBQUU7VUFBTSxDQUFDLENBQUM7UUFDNUY7TUFDRixDQUFDLE1BQU07UUFDTDVELE1BQU0sQ0FBQztVQUFFcUIsSUFBSSxFQUFFLE9BQU87VUFBRUMsSUFBSSxFQUFHbkcsQ0FBQyxFQUFZaU4sT0FBTyxJQUFJQyxNQUFNLENBQUNsTixDQUFDO1FBQUUsQ0FBQyxDQUFDO01BQ3JFO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSSxJQUFBaUcsbUNBQWdCLEVBQUNqRyxDQUFDLENBQUMsRUFBRTtRQUN2QnlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUksc0JBQXNCLENBQUMsQ0FBQztNQUNwRDtJQUNGLENBQUMsU0FBUztNQUNSa0osY0FBYyxDQUFDLENBQUM7TUFDaEJ0SSxRQUFRLENBQUNpQyxPQUFPLEdBQUcsSUFBSTtNQUN2Qm1HLFlBQVksQ0FBQyxDQUFDO01BQ2RsSSxTQUFTLENBQUMsRUFBRSxDQUFDO01BQ2JHLFlBQVksQ0FBQyxFQUFFLENBQUM7TUFDaEJNLFlBQVksQ0FBQyxFQUFFLENBQUM7TUFDaEJFLFdBQVcsQ0FBQyxFQUFFLENBQUM7TUFDZkksVUFBVSxDQUFDLEtBQUssQ0FBQztNQUNqQitDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ3BCOUMsWUFBWSxDQUFDZSxPQUFPLEdBQUcsSUFBSTtNQUMzQmxDLFFBQVEsQ0FBQ2tDLE9BQU8sR0FBRyxJQUFJO01BQ3ZCbkMsWUFBWSxDQUFDbUMsT0FBTyxFQUFFa0ssUUFBUSxDQUFDLENBQUM7SUFDbEM7RUFDRixDQUFDOztFQUVEO0VBQ0E7RUFDQSxNQUFNQyxJQUFJLEdBQUcsSUFBQW5JLGtCQUFXLEVBQUMsTUFBTTtJQUM3QmxFLFFBQVEsQ0FBQ2tDLE9BQU8sRUFBRW9LLEtBQUssQ0FBQyxDQUFDO0VBQzNCLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7RUFDRSxNQUFNQyxTQUFTLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQzVCLE1BQU1wSSxLQUFLLEdBQUd4RSxRQUFRLENBQUN1QyxPQUFPO0lBQzlCLE1BQU1vRixPQUFPLEdBQUd6RixhQUFhO0lBQzdCLE1BQU0yQyxJQUFJLEdBQUczRSxPQUFPLENBQUNxQyxPQUFPO0lBQzVCLElBQUksQ0FBQ2lDLEtBQUssSUFBSSxDQUFDbUQsT0FBTyxJQUFJLENBQUM5QyxJQUFJLElBQUl2RCxPQUFPLElBQUlxRyxPQUFPLENBQUNoRyxNQUFNLEtBQUtrRCxJQUFJLENBQUNKLEVBQUUsRUFBRTtJQUMxRTtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUMzQixTQUFTLEVBQUU7TUFDZHFCLE1BQU0sQ0FBQztRQUNMcUIsSUFBSSxFQUFFLE9BQU87UUFDYkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO01BQ0Y7SUFDRjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJO01BQ0YsSUFBSSxDQUFDLE1BQU1qQixLQUFLLENBQUNzRCxVQUFVLENBQUNqRCxJQUFJLENBQUNKLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtRQUNoRHhDLFlBQVksQ0FBQztVQUFFTixNQUFNLEVBQUVrRCxJQUFJLENBQUNKLEVBQUU7VUFBRXNELE1BQU0sRUFBRTtRQUFLLENBQUMsQ0FBQztRQUMvQztNQUNGO0lBQ0YsQ0FBQyxDQUFDLE9BQU96SSxDQUFDLEVBQUU7TUFDVnlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUcsZUFBZSxDQUFDLENBQUM7SUFDN0M7SUFDQTRDLGdCQUFnQixDQUFDLElBQUksQ0FBQztJQUN0QixNQUFNOEMsTUFBTSxHQUFHd0MsT0FBTyxDQUFDeEMsTUFBTTtJQUM3QixNQUFNMEgsUUFBUSxHQUFHLElBQUFDLHdCQUFnQixFQUFDO01BQ2hDL0gsUUFBUSxFQUFFSSxNQUFNLENBQUNKLFFBQVE7TUFDekJnSSxjQUFjLEVBQUU1SCxNQUFNLENBQUM0SCxjQUFjO01BQ3JDQyxlQUFlLEVBQUU3SCxNQUFNLENBQUM2SDtJQUMxQixDQUFDLENBQUM7SUFDRjtJQUNBO0lBQ0E7SUFDQSxNQUFNQyxVQUFVLEdBQUcsSUFBQUMseUJBQWlCLEVBQUMvSCxNQUFNLENBQUNnSSxnQkFBZ0IsRUFBRWxILGFBQWEsQ0FBQztJQUM1RSxNQUFNbUgsT0FBTyxHQUFHLElBQUFDLHVCQUFlLEVBQUNSLFFBQVEsQ0FBQzlILFFBQVEsRUFBRWtJLFVBQVUsQ0FBQztJQUM5RHBNLE1BQU0sQ0FBQyxJQUFBaUUseUJBQWEsRUFBQytILFFBQVEsQ0FBQzlILFFBQVEsQ0FBQyxDQUFDO0lBQ3hDeEQsVUFBVSxDQUFDLElBQUksQ0FBQztJQUNoQkMsWUFBWSxDQUFDZSxPQUFPLEdBQUdzQyxJQUFJLENBQUNKLEVBQUU7SUFDOUJyRSxZQUFZLENBQUNtQyxPQUFPLEVBQUU0RixVQUFVLENBQUN0RCxJQUFJLENBQUNKLEVBQUUsQ0FBQztJQUN6Q3hELFlBQVksQ0FBQyxFQUFFLENBQUM7SUFDaEJFLFdBQVcsQ0FBQyxFQUFFLENBQUM7SUFDZmdELE1BQU0sQ0FBQztNQUFFcUIsSUFBSSxFQUFFLE9BQU87TUFBRXVHLElBQUksRUFBRSxPQUFPO01BQUV0RyxJQUFJLEVBQUU7SUFBdUMsQ0FBQyxDQUFDO0lBQ3RGLE1BQU0yQyxVQUFVLEdBQUcsSUFBSUMsZUFBZSxDQUFDLENBQUM7SUFDeENoSSxRQUFRLENBQUNrQyxPQUFPLEdBQUc2RixVQUFVO0lBQzdCLE1BQU1rRixTQUFTLEdBQUcsSUFBSS9FLHlCQUFlLENBQUMsQ0FBQztJQUN2Q2pJLFFBQVEsQ0FBQ2lDLE9BQU8sR0FBRytLLFNBQVM7SUFDNUI7SUFDQTtJQUNBLE1BQU07TUFBRTlFLEtBQUs7TUFBRUMsT0FBTyxFQUFFQztJQUFhLENBQUMsR0FBRyxJQUFBQyx3QkFBYyxFQUFDLENBQUM7SUFDekRuSSxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQ2IsTUFBTW9JLGNBQWMsR0FBRzBFLFNBQVMsQ0FBQ3pFLFFBQVEsQ0FBRTBFLENBQUMsSUFBSy9NLFNBQVMsQ0FBQyxDQUFDLEdBQUcrTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25FO0lBQ0E7SUFDQTtJQUNBLE1BQU16RSxZQUFZLEdBQUczRCxNQUFNLENBQUMwRSxZQUFZLElBQUksSUFBQWQsOEJBQWlCLEVBQUM7TUFBRUMsS0FBSyxFQUFFLElBQUFDLHFCQUFRLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFDcEYsSUFBSTtNQUNGLE1BQU1DLFVBQVUsR0FBRyxNQUFNLElBQUFDLG1CQUFRLEVBQUM7UUFDaENDLE1BQU0sRUFBRSxJQUFBQyxzQ0FBcUIsRUFBQyxDQUFDO1FBQy9CQyxLQUFLLEVBQUVsRyxPQUFPLENBQUNrRyxLQUFLO1FBQ3BCQyxPQUFPLEVBQUVuRyxPQUFPLENBQUNtRyxPQUFPO1FBQ3hCQyxNQUFNLEVBQUUsSUFBQUMsZ0NBQW1CLEVBQUNYLFlBQVksRUFBRSxJQUFBWSw0QkFBZSxFQUFDO1VBQUVKLEtBQUssRUFBRWxHLE9BQU8sQ0FBQ2tHLEtBQUs7VUFBRUssYUFBYSxFQUFFN0csU0FBUyxFQUFFWSxJQUFJO1VBQUVMO1FBQU8sQ0FBQyxDQUFDLENBQUM7UUFDNUh1RyxTQUFTLEVBQUUzRCxhQUFhLElBQUlwRSxTQUFTO1FBQ3JDZ0ksWUFBWSxFQUFFZixZQUFZO1FBQzFCZixNQUFNLEVBQUU7VUFDTmhELFFBQVEsRUFBRXFJLE9BQU87VUFDakIsSUFBSWpJLE1BQU0sQ0FBQ3FJLFFBQVEsS0FBSyxJQUFJLEdBQUc7WUFBRUEsUUFBUSxFQUFFckksTUFBTSxDQUFDcUk7VUFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMvRSxDQUFDO1FBQ0QxRCxNQUFNLEVBQUUxQixVQUFVLENBQUMwQixNQUFNO1FBQ3pCeEIsUUFBUSxFQUFFZ0YsU0FBUztRQUNuQjlFLEtBQUs7UUFDTHVCLGFBQWEsRUFBRSxJQUFBN0csaUJBQVksRUFBQyxDQUFDLEVBQUVDLFFBQVEsQ0FBQzZHLGdCQUFnQjtRQUN4REMsTUFBTSxFQUFFO1VBQ05DLFVBQVUsRUFBRSxNQUFPQyxDQUFDLElBQUs7WUFDdkIsTUFBTTNGLEtBQUssQ0FBQ0wsTUFBTSxDQUFDVSxJQUFJLENBQUNKLEVBQUUsRUFBRTBGLENBQUMsQ0FBQztVQUNoQyxDQUFDO1VBQ0RDLGdCQUFnQixFQUFHM0UsSUFBSSxJQUFLeEUsWUFBWSxDQUFFb0osQ0FBQyxJQUFLQSxDQUFDLEdBQUc1RSxJQUFJLENBQUM7VUFDekQ2RSxnQkFBZ0IsRUFBRzdFLElBQUksSUFBS3RFLFdBQVcsQ0FBRW9KLENBQUMsSUFBS0EsQ0FBQyxHQUFHOUUsSUFBSSxDQUFDO1VBQ3hEK0UsV0FBVyxFQUFHQyxLQUFLLElBQUs7WUFDdEJ0SixXQUFXLENBQUMsRUFBRSxDQUFDO1lBQ2ZnRCxNQUFNLENBQ0pzRyxLQUFLLENBQUNDLFlBQVksS0FBSzdJLFNBQVMsR0FDNUI7Y0FBRTJELElBQUksRUFBRSxXQUFXO2NBQUVDLElBQUksRUFBRSxFQUFFO2NBQUVrRixRQUFRLEVBQUU7WUFBSyxDQUFDLEdBQy9DO2NBQUVuRixJQUFJLEVBQUUsV0FBVztjQUFFQyxJQUFJLEVBQUVnRixLQUFLLENBQUNoRjtZQUFLLENBQzVDLENBQUM7VUFDSCxDQUFDO1VBQ0RtRixlQUFlLEVBQUduRixJQUFJLElBQUs7WUFDekIsSUFBSUEsSUFBSSxLQUFLb0YsK0JBQXFCLEVBQUUxRyxNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRTtZQUFjLENBQUMsQ0FBQyxDQUFDLEtBQy9ELElBQUlDLElBQUksQ0FBQytCLElBQUksQ0FBQyxDQUFDLEVBQUVyRCxNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRSxNQUFNO2NBQUVDO1lBQUssQ0FBQyxDQUFDO1lBQ3BEeEUsWUFBWSxDQUFDLEVBQUUsQ0FBQztVQUNsQixDQUFDO1VBQ0Q2SixTQUFTLEVBQUVBLENBQUNDLElBQUksRUFBRUMsS0FBSyxLQUFLN0csTUFBTSxDQUFDO1lBQUVxQixJQUFJLEVBQUUsTUFBTTtZQUFFdUYsSUFBSTtZQUFFQztVQUFNLENBQUMsQ0FBQztVQUNqRUMsWUFBWSxFQUFFQSxDQUFDRixJQUFJLEVBQUUxRixDQUFDLEtBQUtsQixNQUFNLENBQUM7WUFBRXFCLElBQUksRUFBRSxRQUFRO1lBQUV1RixJQUFJO1lBQUVHLE9BQU8sRUFBRTdGLENBQUMsQ0FBQzZGLE9BQU87WUFBRUMsT0FBTyxFQUFFOUYsQ0FBQyxDQUFDOEY7VUFBUSxDQUFDLENBQUM7VUFDbkdDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNakgsTUFBTSxDQUFDO1lBQUVxQixJQUFJLEVBQUU7VUFBUSxDQUFDLENBQUM7VUFDeEM2RixPQUFPLEVBQUdDLENBQUMsSUFDVGpLLFFBQVEsQ0FBQztZQUNQa0ssV0FBVyxFQUFFRCxDQUFDLENBQUNDLFdBQVc7WUFDMUJDLGVBQWUsRUFBRUYsQ0FBQyxDQUFDRSxlQUFlO1lBQ2xDQyxnQkFBZ0IsRUFBRUgsQ0FBQyxDQUFDRztVQUN0QixDQUFDLENBQUM7VUFDSkMsU0FBUyxFQUFFQSxDQUFDO1lBQUVDO1VBQWdCLENBQUMsS0FBSztZQUNsQ3hILE1BQU0sQ0FBQztjQUFFcUIsSUFBSSxFQUFFLFlBQVk7Y0FBRW9HLE9BQU8sRUFBRSxHQUFHRCxlQUFlO1lBQStCLENBQUMsQ0FBQztZQUN6RixLQUFLbkgsS0FBSyxDQUNQcUgsSUFBSSxDQUFDaEgsSUFBSSxDQUFDSixFQUFFLENBQUMsQ0FDYkUsS0FBSyxDQUFFckYsQ0FBQyxJQUFLc0gsT0FBTyxDQUFDQyxJQUFJLENBQUMsNkRBQTZELEVBQUV2SCxDQUFDLENBQUMsQ0FBQztVQUNqRyxDQUFDO1VBQ0R3TSxPQUFPLEVBQUVBLENBQUM7WUFBRS9HO1VBQVMsQ0FBQyxLQUFLO1lBQ3pCLEtBQUssTUFBTWlDLENBQUMsSUFBSWpDLFFBQVEsRUFBRVosTUFBTSxDQUFDO2NBQUVxQixJQUFJLEVBQUUsT0FBTztjQUFFdUcsSUFBSSxFQUFFL0UsQ0FBQyxDQUFDK0UsSUFBSTtjQUFFdEcsSUFBSSxFQUFFdUIsQ0FBQyxDQUFDdkI7WUFBSyxDQUFDLENBQUM7VUFDakY7UUFDRjtNQUNGLENBQUMsQ0FBQztNQUNGLElBQUk7UUFDRnZGLE9BQU8sQ0FBQ3FDLE9BQU8sR0FBRyxNQUFNaUMsS0FBSyxDQUFDcUgsSUFBSSxDQUFDaEgsSUFBSSxDQUFDSixFQUFFLEVBQUU7VUFDMUNNLFFBQVEsRUFBRW1FLFVBQVU7VUFDcEJnRCxJQUFJLEVBQUVySCxJQUFJLENBQUNxSCxJQUFJLElBQUlqRztRQUNyQixDQUFDLENBQUM7UUFDRmxFLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDbkIzQixZQUFZLENBQUNtQyxPQUFPLEVBQUU0SixPQUFPLENBQUMsQ0FBQztRQUMvQixLQUFLLElBQUEvRSxpQkFBWSxFQUFDQyw2QkFBWSxFQUFFO1VBQUVDLElBQUksRUFBRSxzQkFBc0I7VUFBRTdDLEVBQUUsRUFBRUksSUFBSSxDQUFDSjtRQUFHLENBQUMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztNQUNoRyxDQUFDLENBQUMsT0FBT3JGLENBQUMsRUFBRTtRQUNWeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztNQUM3QztJQUNGLENBQUMsQ0FBQyxPQUFPSCxDQUFDLEVBQUU7TUFDVjtNQUNBO01BQ0E7TUFDQTtNQUNBLE1BQU04TSxLQUFLLEdBQUcsSUFBQUMsd0JBQVksRUFBQy9NLENBQUMsQ0FBQztNQUM3QixJQUFJOE0sS0FBSyxFQUFFO1FBQ1RqSSxNQUFNLENBQUM7VUFBRXFCLElBQUksRUFBRSxPQUFPO1VBQUVDLElBQUksRUFBRSxJQUFBNkcsNEJBQWdCLEVBQUNGLEtBQUssRUFBRSxJQUFJO1FBQUUsQ0FBQyxDQUFDO1FBQzlELElBQUlBLEtBQUssS0FBSyxZQUFZLEVBQUU7VUFDMUJuSyxZQUFZLENBQUM7WUFBRU4sTUFBTSxFQUFFSCxZQUFZLENBQUNlLE9BQU8sSUFBSXJDLE9BQU8sQ0FBQ3FDLE9BQU8sRUFBRWtDLEVBQUUsSUFBSSxFQUFFO1lBQUVzRCxNQUFNLEVBQUU7VUFBSyxDQUFDLENBQUM7UUFDM0Y7TUFDRixDQUFDLE1BQU07UUFDTDVELE1BQU0sQ0FBQztVQUFFcUIsSUFBSSxFQUFFLE9BQU87VUFBRUMsSUFBSSxFQUFHbkcsQ0FBQyxFQUFZaU4sT0FBTyxJQUFJQyxNQUFNLENBQUNsTixDQUFDO1FBQUUsQ0FBQyxDQUFDO01BQ3JFO01BQ0EsSUFBSSxJQUFBaUcsbUNBQWdCLEVBQUNqRyxDQUFDLENBQUMsRUFBRTtRQUN2QnlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUksc0JBQXNCLENBQUMsQ0FBQztNQUNwRDtJQUNGLENBQUMsU0FBUztNQUNSa0osY0FBYyxDQUFDLENBQUM7TUFDaEJ0SSxRQUFRLENBQUNpQyxPQUFPLEdBQUcsSUFBSTtNQUN2Qm1HLFlBQVksQ0FBQyxDQUFDO01BQ2RsSSxTQUFTLENBQUMsRUFBRSxDQUFDO01BQ2JHLFlBQVksQ0FBQyxFQUFFLENBQUM7TUFDaEJNLFlBQVksQ0FBQyxFQUFFLENBQUM7TUFDaEJFLFdBQVcsQ0FBQyxFQUFFLENBQUM7TUFDZkksVUFBVSxDQUFDLEtBQUssQ0FBQztNQUNqQitDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ3BCOUMsWUFBWSxDQUFDZSxPQUFPLEdBQUcsSUFBSTtNQUMzQmxDLFFBQVEsQ0FBQ2tDLE9BQU8sR0FBRyxJQUFJO01BQ3ZCbkMsWUFBWSxDQUFDbUMsT0FBTyxFQUFFa0ssUUFBUSxDQUFDLENBQUM7SUFDbEM7RUFDRixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtFQUNFLE1BQU1nQixZQUFZLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQy9CLE1BQU1qSixLQUFLLEdBQUd4RSxRQUFRLENBQUN1QyxPQUFPO0lBQzlCLE1BQU1vRixPQUFPLEdBQUd6RixhQUFhO0lBQzdCLE1BQU0yQyxJQUFJLEdBQUczRSxPQUFPLENBQUNxQyxPQUFPO0lBQzVCLElBQUksQ0FBQ2lDLEtBQUssSUFBSSxDQUFDbUQsT0FBTyxJQUFJLENBQUM5QyxJQUFJLElBQUk4QyxPQUFPLENBQUNoRyxNQUFNLEtBQUtrRCxJQUFJLENBQUNKLEVBQUUsRUFBRTtJQUMvRHBDLGdCQUFnQixDQUFDLElBQUksQ0FBQztJQUN0QixNQUFNd0ssUUFBUSxHQUFHLElBQUFDLHdCQUFnQixFQUFDO01BQ2hDL0gsUUFBUSxFQUFFNEMsT0FBTyxDQUFDeEMsTUFBTSxDQUFDSixRQUFRO01BQ2pDZ0ksY0FBYyxFQUFFcEYsT0FBTyxDQUFDeEMsTUFBTSxDQUFDNEgsY0FBYztNQUM3Q0MsZUFBZSxFQUFFckYsT0FBTyxDQUFDeEMsTUFBTSxDQUFDNkg7SUFDbEMsQ0FBQyxDQUFDO0lBQ0YsSUFBSTtNQUNGOU0sT0FBTyxDQUFDcUMsT0FBTyxHQUFHLE1BQU1pQyxLQUFLLENBQUNxSCxJQUFJLENBQUNoSCxJQUFJLENBQUNKLEVBQUUsRUFBRTtRQUMxQ00sUUFBUSxFQUFFOEgsUUFBUSxDQUFDOUgsUUFBUTtRQUMzQm1ILElBQUksRUFBRXJILElBQUksQ0FBQ3FILElBQUksSUFBSWpHO01BQ3JCLENBQUMsQ0FBQztNQUNGcEYsTUFBTSxDQUFDLElBQUFpRSx5QkFBYSxFQUFDK0gsUUFBUSxDQUFDOUgsUUFBUSxDQUFDLENBQUM7TUFDeENoRCxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ25CLEtBQUssSUFBQXFGLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUU7UUFBRUMsSUFBSSxFQUFFLHNCQUFzQjtRQUFFN0MsRUFBRSxFQUFFSSxJQUFJLENBQUNKO01BQUcsQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ2hHLENBQUMsQ0FBQyxPQUFPckYsQ0FBQyxFQUFFO01BQ1Z5QyxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO0lBQzdDO0VBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQSxNQUFNaU8sS0FBSyxHQUFHLElBQUFuSixrQkFBVyxFQUFFd0gsSUFBZSxJQUFLO0lBQzdDLE1BQU0xQixDQUFDLEdBQUcvSixRQUFRLENBQUNpQyxPQUFPO0lBQzFCLElBQUksQ0FBQzhILENBQUMsRUFBRTtJQUNSLElBQUlBLENBQUMsQ0FBQ3NELE9BQU8sQ0FBQ2pOLFNBQVMsRUFBRXFMLElBQUksQ0FBQyxFQUFFcEwsWUFBWSxDQUFDLEVBQUUsQ0FBQztFQUNsRCxDQUFDLEVBQUUsQ0FBQ0QsU0FBUyxDQUFDLENBQUM7RUFFZixNQUFNa04sV0FBVyxHQUFHLElBQUFySixrQkFBVyxFQUFFRSxFQUFVLElBQUs7SUFDOUNuRSxRQUFRLENBQUNpQyxPQUFPLEVBQUVzTCxNQUFNLENBQUNwSixFQUFFLENBQUM7RUFDOUIsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLG9CQUNFLElBQUF0RixXQUFBLENBQUEyTyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxjQUFjO0lBQUFDLFFBQUEsZ0JBQzNCLElBQUE3TyxXQUFBLENBQUEyTyxJQUFBO01BQVFDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ3ZCLElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBRXZNLEtBQUssSUFBSTtNQUFjLENBQU8sQ0FBQyxlQUMzRCxJQUFBdEMsV0FBQSxDQUFBMk8sSUFBQTtRQUFNQyxTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEdBQ3JCNUssT0FBTyxDQUFDa0csS0FBSyxDQUFDNEUsTUFBTSxFQUFDLFNBQU8sRUFBQ3BMLFNBQVMsR0FBRyxtQkFBbUIsR0FBRyxnQkFBZ0IsRUFDL0UxQixLQUFLLGlCQUNKLElBQUFqQyxXQUFBLENBQUEyTyxJQUFBLEVBQUEzTyxXQUFBLENBQUFnUCxRQUFBO1VBQUFILFFBQUEsR0FDRyxLQUFLLEVBQ0w1TSxLQUFLLENBQUNtSyxXQUFXLENBQUM2QyxjQUFjLENBQUMsQ0FBQyxFQUFDLFNBQ3BDLEVBR0NoTixLQUFLLENBQUNvSyxlQUFlLEtBQUszSixTQUFTLElBQUksTUFBTVQsS0FBSyxDQUFDb0ssZUFBZSxDQUFDNEMsY0FBYyxDQUFDLENBQUMsU0FBUztRQUFBLENBQzdGLENBQ0g7TUFBQSxDQUNHLENBQUM7SUFBQSxDQUNELENBQUMsRUFFUixDQUFDdEwsU0FBUyxpQkFDVCxJQUFBM0QsV0FBQSxDQUFBOE8sR0FBQTtNQUFLRixTQUFTLEVBQUMsa0JBQWtCO01BQUNNLElBQUksRUFBQyxRQUFRO01BQUFMLFFBQUEsZUFDN0MsSUFBQTdPLFdBQUEsQ0FBQThPLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFFBQVE7UUFBQUMsUUFBQSxFQUFDO01BR3pCLENBQU07SUFBQyxDQUNKLENBQ04sRUFFQWxNLFVBQVUsaUJBQ1QsSUFBQTNDLFdBQUEsQ0FBQThPLEdBQUE7TUFBS0YsU0FBUyxFQUFDLGtCQUFrQjtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLGVBQzdDLElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxRQUFRO1FBQUFDLFFBQUEsRUFBRWxNO01BQVUsQ0FBTztJQUFDLENBQ3pDLENBQ04sZUFFRCxJQUFBM0MsV0FBQSxDQUFBMk8sSUFBQTtNQUFJQyxTQUFTLEVBQUMsUUFBUTtNQUFDLGFBQVUsUUFBUTtNQUFDTyxHQUFHLEVBQUU3TCxNQUFPO01BQUF1TCxRQUFBLGdCQUdwRCxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQSxFQUFDblAsZUFBQSxDQUFBVSxPQUFjO1FBQUNvQixHQUFHLEVBQUVBO01BQUksQ0FBRSxDQUFDLEVBSzNCTSxRQUFRLGlCQUNQLElBQUEvQixXQUFBLENBQUE4TyxHQUFBO1FBQUlGLFNBQVMsRUFBQyxpQkFBaUI7UUFBQUMsUUFBQSxlQUc3QixJQUFBN08sV0FBQSxDQUFBMk8sSUFBQTtVQUFTQyxTQUFTLEVBQUMsY0FBYztVQUFDUSxJQUFJO1VBQUFQLFFBQUEsZ0JBQ3BDLElBQUE3TyxXQUFBLENBQUEyTyxJQUFBO1lBQUFFLFFBQUEsZ0JBQ0UsSUFBQTdPLFdBQUEsQ0FBQThPLEdBQUE7Y0FBTUYsU0FBUyxFQUFDLGlCQUFpQjtjQUFDLGVBQVk7WUFBTSxDQUFFLENBQUMsa0JBRXpEO1VBQUEsQ0FBUyxDQUFDLGVBQ1YsSUFBQTVPLFdBQUEsQ0FBQThPLEdBQUE7WUFBTUYsU0FBUyxFQUFDLG1CQUFtQjtZQUFDTyxHQUFHLEVBQUU1TCxZQUFhO1lBQUFzTCxRQUFBLEVBQ25EOU07VUFBUSxDQUNMLENBQUM7UUFBQSxDQUNBO01BQUMsQ0FDUixDQUNMLEVBQ0FGLFNBQVMsaUJBQ1IsSUFBQTdCLFdBQUEsQ0FBQThPLEdBQUE7UUFBSUYsU0FBUyxFQUFDLHlCQUF5QjtRQUFBQyxRQUFBLGVBQ3JDLElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1VBQU1GLFNBQVMsRUFBQyxTQUFTO1VBQUFDLFFBQUEsRUFBRWhOO1FBQVMsQ0FBTztNQUFDLENBQzFDLENBQ0w7SUFBQSxHQTNCeURXLE1BQU0sSUFBSSxNQTRCbEUsQ0FBQyxFQUlKcEIsTUFBTSxDQUFDMk4sTUFBTSxHQUFHLENBQUMsaUJBQ2hCLElBQUEvTyxXQUFBLENBQUE4TyxHQUFBO01BQUlGLFNBQVMsRUFBQyxXQUFXO01BQUMsY0FBVyxvQkFBb0I7TUFBQUMsUUFBQSxFQUN0RHpOLE1BQU0sQ0FBQ2lPLEdBQUcsQ0FBRXhILENBQUMsaUJBQ1osSUFBQTdILFdBQUEsQ0FBQTJPLElBQUE7UUFBZUMsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLGdCQUN2QyxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQTtVQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1VBQUFDLFFBQUEsRUFBRWhILENBQUMsQ0FBQytFLElBQUksS0FBSyxXQUFXLEdBQUcsS0FBSyxHQUFHO1FBQVcsQ0FBTyxDQUFDLGVBQ3RGLElBQUE1TSxXQUFBLENBQUE4TyxHQUFBO1VBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUMsUUFBQSxFQUFFaEgsQ0FBQyxDQUFDdkI7UUFBSSxDQUFPLENBQUMsZUFDaEQsSUFBQXRHLFdBQUEsQ0FBQThPLEdBQUE7VUFDRTNHLElBQUksRUFBQyxRQUFRO1VBQ2J5RyxTQUFTLEVBQUMsa0JBQWtCO1VBQzVCLGNBQVksNkJBQTZCL0csQ0FBQyxDQUFDdkIsSUFBSSxFQUFHO1VBQ2xEZ0osT0FBTyxFQUFFQSxDQUFBLEtBQU1iLFdBQVcsQ0FBQzVHLENBQUMsQ0FBQ3ZDLEVBQUUsQ0FBRTtVQUFBdUosUUFBQSxFQUNsQztRQUVELENBQVEsQ0FBQztNQUFBLEdBVkZoSCxDQUFDLENBQUN2QyxFQVdQLENBQ0w7SUFBQyxDQUNBLENBQ0wsRUFLQXZDLGFBQWEsSUFBSSxDQUFDWixPQUFPLGlCQUN4QixJQUFBbkMsV0FBQSxDQUFBOE8sR0FBQSxFQUFDalAsaUJBQUEsQ0FBQVEsT0FBZ0I7TUFDZmtQLFlBQVksRUFBRXhNLGFBQWEsQ0FBQ2lELE1BQU0sQ0FBQ3VKLFlBQWE7TUFDaERDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLEtBQUsvQixTQUFTLENBQUMsQ0FBRTtNQUNqQ2dDLFlBQVksRUFBRUEsQ0FBQSxLQUFNLEtBQUtuQixZQUFZLENBQUM7SUFBRSxDQUN6QyxDQUNGLEVBUUF6TCxTQUFTLElBQUksQ0FBQ1YsT0FBTyxJQUFJVSxTQUFTLENBQUNMLE1BQU0sS0FBS0EsTUFBTSxpQkFDbkQsSUFBQXhDLFdBQUEsQ0FBQTJPLElBQUE7TUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLGdCQUM3QyxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQTtRQUFNRixTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEVBQUUsSUFBQWEseUJBQWEsRUFBQyxJQUFJO01BQUMsQ0FBTyxDQUFDLGVBQ3JELElBQUExUCxXQUFBLENBQUEyTyxJQUFBO1FBQUtDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsZ0JBQzVCLElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1VBQ0UzRyxJQUFJLEVBQUMsUUFBUTtVQUNieUcsU0FBUyxFQUFDLFFBQVE7VUFDbEJVLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO1lBQ2IsTUFBTTtjQUFFMUcsTUFBTSxFQUFFK0csU0FBUztjQUFFbk4sTUFBTSxFQUFFb047WUFBUSxDQUFDLEdBQUcvTSxTQUFTO1lBQ3hELEtBQUssQ0FBQyxZQUFZO2NBQ2hCLElBQUk7Z0JBQ0YsTUFBTXdDLEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87Z0JBQzlCO2dCQUNBO2dCQUNBO2dCQUNBLElBQUlpQyxLQUFLLEVBQUUsTUFBTUEsS0FBSyxDQUFDd0ssV0FBVyxDQUFDRCxPQUFPLENBQUM7Z0JBQzNDOU0sWUFBWSxDQUFDLElBQUksQ0FBQztjQUNwQixDQUFDLENBQUMsT0FBTzNDLENBQUMsRUFBRTtnQkFDVnlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUcsZUFBZSxDQUFDLENBQUM7Z0JBQzNDO2NBQ0Y7Y0FDQSxPQUFPcVAsU0FBUyxHQUFHbEMsU0FBUyxDQUFDLENBQUMsR0FBR3JGLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDekMsQ0FBQyxFQUFFLENBQUM7VUFDTixDQUFFO1VBQUF5RyxRQUFBLEVBQ0g7UUFFRCxDQUFRLENBQUMsZUFDVCxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQTtVQUFRM0csSUFBSSxFQUFDLFFBQVE7VUFBQ3lHLFNBQVMsRUFBQyxjQUFjO1VBQUNVLE9BQU8sRUFBRUEsQ0FBQSxLQUFNeE0sWUFBWSxDQUFDLElBQUksQ0FBRTtVQUFBK0wsUUFBQSxFQUFDO1FBRWxGLENBQVEsQ0FBQztNQUFBLENBQ04sQ0FBQztJQUFBLENBQ0gsQ0FDTixFQU1BMU0sT0FBTyxpQkFDTixJQUFBbkMsV0FBQSxDQUFBOE8sR0FBQTtNQUFHRixTQUFTLEVBQUMsZUFBZTtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLEVBQ3ZDdE4sU0FBUyxDQUFDOEcsSUFBSSxDQUFDLENBQUMsR0FDYixpREFBaUQsR0FDakQ7SUFBeUIsQ0FDNUIsQ0FDSixlQUNELElBQUFySSxXQUFBLENBQUEyTyxJQUFBO01BQUtDLFNBQVMsRUFBQyxlQUFlO01BQUFDLFFBQUEsZ0JBQzVCLElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1FBQ0VGLFNBQVMsRUFBQyxXQUFXO1FBQ3JCa0IsV0FBVyxFQUNUM04sT0FBTyxHQUNILCtDQUErQyxHQUMvQyxrREFDTDtRQUNENE4sS0FBSyxFQUFFNU4sT0FBTyxHQUFHWixTQUFTLEdBQUdJLE1BQU87UUFDcEMrSCxRQUFRLEVBQUd2SixDQUFDLElBQU1nQyxPQUFPLEdBQUdYLFlBQVksQ0FBQ3JCLENBQUMsQ0FBQzZQLE1BQU0sQ0FBQ0QsS0FBSyxDQUFDLEdBQUduTyxTQUFTLENBQUN6QixDQUFDLENBQUM2UCxNQUFNLENBQUNELEtBQUssQ0FBRztRQUN0RkUsU0FBUyxFQUFHOVAsQ0FBQyxJQUFLO1VBQ2hCLElBQUlBLENBQUMsQ0FBQytQLEdBQUcsS0FBSyxPQUFPLEVBQUU7VUFDdkIsSUFBSS9OLE9BQU8sRUFBRW9NLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUN2QixLQUFLbkcsR0FBRyxDQUFDLENBQUM7UUFDakIsQ0FBRTtRQUNGLGNBQVlqRyxPQUFPLEdBQUcsaUJBQWlCLEdBQUc7TUFBUyxDQUNwRCxDQUFDLEVBQ0RBLE9BQU8saUJBQ04sSUFBQW5DLFdBQUEsQ0FBQTJPLElBQUEsRUFBQTNPLFdBQUEsQ0FBQWdQLFFBQUE7UUFBQUgsUUFBQSxnQkFDRSxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQTtVQUNFM0csSUFBSSxFQUFDLFFBQVE7VUFDYnlHLFNBQVMsRUFBQyxjQUFjO1VBQ3hCdUIsUUFBUSxFQUFFLENBQUM1TyxTQUFTLENBQUM4RyxJQUFJLENBQUMsQ0FBRTtVQUM1QmlILE9BQU8sRUFBRUEsQ0FBQSxLQUFNZixLQUFLLENBQUMsT0FBTyxDQUFFO1VBQUFNLFFBQUEsRUFDL0I7UUFFRCxDQUFRLENBQUMsZUFDVCxJQUFBN08sV0FBQSxDQUFBOE8sR0FBQTtVQUNFM0csSUFBSSxFQUFDLFFBQVE7VUFDYnlHLFNBQVMsRUFBQywyQkFBMkI7VUFDckN1QixRQUFRLEVBQUUsQ0FBQzVPLFNBQVMsQ0FBQzhHLElBQUksQ0FBQyxDQUFFO1VBQzVCaUgsT0FBTyxFQUFFQSxDQUFBLEtBQU1mLEtBQUssQ0FBQyxXQUFXLENBQUU7VUFBQU0sUUFBQSxFQUNuQztRQUVELENBQVEsQ0FBQztNQUFBLENBQ1QsQ0FDSCxlQUNELElBQUE3TyxXQUFBLENBQUE4TyxHQUFBO1FBQ0UzRyxJQUFJLEVBQUMsUUFBUTtRQUNieUcsU0FBUyxFQUFDO1FBQ1Y7UUFDQTtRQUFBO1FBQ0F1QixRQUFRLEVBQUVoTyxPQUFPLEdBQUcsS0FBSyxHQUFHLENBQUN3QixTQUFVO1FBQ3ZDckIsS0FBSyxFQUNISCxPQUFPLEdBQ0gsNkNBQTZDLEdBQzdDLENBQUN3QixTQUFTLEdBQ1IsNENBQTRDLEdBQzVDakIsU0FDUDtRQUNENE0sT0FBTyxFQUFFQSxDQUFBLEtBQU9uTixPQUFPLEdBQUdvTCxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUtuRixHQUFHLENBQUMsQ0FBRztRQUFBeUcsUUFBQSxFQUU5QzFNLE9BQU8sR0FBRyxNQUFNLEdBQUc7TUFBSyxDQUNuQixDQUFDO0lBQUEsQ0FDTixDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ2xDLEVBQUEsQ0ExK0J1Qk8saUJBQWlCO0VBQUEsUUFDdkJFLGVBQVUsRUFDWEUsY0FBUyxFQW9GeEI4QyxrQ0FBZ0IsRUFDaEJBLGtDQUFnQixFQTBDaEJ3QixnQ0FBZSxFQTRHTzZCLGlCQUFZO0FBQUE7QUFBQXFKLEVBQUEsR0E3T1o1UCxpQkFBaUI7QUFBQSxJQUFBNFAsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}