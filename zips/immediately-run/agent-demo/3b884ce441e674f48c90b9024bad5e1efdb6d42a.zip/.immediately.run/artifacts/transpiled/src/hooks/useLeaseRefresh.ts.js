"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useLeaseRefresh = useLeaseRefresh;
var _react = require("react");
var _lease = require("../lib/lease");
// R3-561 / R-ARD-18 — "the lease is refreshed on an interval WHILE THE RUN
// EXECUTES". This is that interval, extracted rather than lived in one component.
//
// WHY A HOOK AND NOT A `useEffect` IN THE STAGE. There are TWO run surfaces —
// `ConversationStage` and `CodingAgent` — and both acquire the lease, append every
// boundary and release at the end. The first version put the interval in the stage
// only, and the review gate's answer was the right one: nothing about the argument
// for it is specific to that component. `CodingAgent` adopts the NEWEST
// conversation at mount, which is the one the stage is most likely driving, so it
// is if anything the surface where a second frame is most reachable.
//
// WHY AN INTERVAL AT ALL, when `append` already refreshes. Because `append` only
// runs at a loop boundary, and the loop reaches a boundary only after the model
// turn returns. One long turn outlasts `LEASE_TTL_MS`, the running frame's own
// lease expires under it, and a second frame reads `free` — the double-drive the
// lease exists to prevent, arriving through the mechanism meant to prevent it.
//
// WHAT IT DELIBERATELY DOES NOT DO. It does not surface the loss. An earlier
// version set a "held" banner from here and claimed to "raise the offer
// immediately"; it could not, because the banner renders only when the run is NOT
// running and this timer exists only while it is. The honest stopping point for a
// lost lease is the next `append`, which rejects with a typed code its caller's
// catch renders. So this loop refreshes, and stops once there is nothing left to
// refresh — no second opinion about the UI.

/** The one method this needs, so a caller can pass a store or a stub. */

/**
 * While `running`, refresh the run's lease every `LEASE_HEARTBEAT_MS`.
 *
 * There is no `onLost` callback, deliberately. An earlier version had one and
 * nothing passed it — and a callback is exactly the seam a later surface would
 * reach for to put a banner back here, which is the opinion the header above says
 * this loop does not get to have. Losing the lease stops the loop and nothing
 * else; the append that follows carries the typed code its caller renders.
 *
 * A refresh that THROWS is not a loss either: the mount could not answer, which is
 * no evidence either way. `checkHold` takes the same position, bounded by the
 * lease's own expiry.
 */
function useLeaseRefresh(
/** The store, by REF. Both callers hold theirs in one, and
 *  `eslint-plugin-react-hooks` v7 makes reading `.current` during render a hard
 *  error — so the ref crosses the boundary and the effect dereferences it. */
storeRef,
/** The conversation this run holds, by ref for the same reason. Read at each
 *  TICK rather than captured once, so a run that changes conversation under the
 *  hook refreshes the right lease instead of a stale one. */
convIdRef, running) {
  (0, _react.useEffect)(() => {
    if (!running) return;
    let live = true;
    const timer = setInterval(() => {
      const store = storeRef.current;
      const convId = convIdRef.current;
      if (!store || !convId) return; // nothing to refresh yet; try again next tick
      void store.holdsRun(convId).then(still => {
        if (!live || still) return;
        live = false; // nothing left to refresh — stop asking
        clearInterval(timer);
      }).catch(() => {
        /* a refresh that cannot run is not a loss — the TTL decides */
      });
    }, _lease.LEASE_HEARTBEAT_MS);
    return () => {
      live = false;
      clearInterval(timer);
    };
    // The refs are stable, so `running` is the whole dependency set — and it has to
    // stay that way: a value dependency that changed per render would tear down and
    // re-arm the interval each time, which is how a heartbeat silently never fires.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2xlYXNlIiwidXNlTGVhc2VSZWZyZXNoIiwic3RvcmVSZWYiLCJjb252SWRSZWYiLCJydW5uaW5nIiwidXNlRWZmZWN0IiwibGl2ZSIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJzdG9yZSIsImN1cnJlbnQiLCJjb252SWQiLCJob2xkc1J1biIsInRoZW4iLCJzdGlsbCIsImNsZWFySW50ZXJ2YWwiLCJjYXRjaCIsIkxFQVNFX0hFQVJUQkVBVF9NUyJdLCJzb3VyY2VzIjpbInVzZUxlYXNlUmVmcmVzaC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy01NjEgLyBSLUFSRC0xOCDigJQgXCJ0aGUgbGVhc2UgaXMgcmVmcmVzaGVkIG9uIGFuIGludGVydmFsIFdISUxFIFRIRSBSVU5cbi8vIEVYRUNVVEVTXCIuIFRoaXMgaXMgdGhhdCBpbnRlcnZhbCwgZXh0cmFjdGVkIHJhdGhlciB0aGFuIGxpdmVkIGluIG9uZSBjb21wb25lbnQuXG4vL1xuLy8gV0hZIEEgSE9PSyBBTkQgTk9UIEEgYHVzZUVmZmVjdGAgSU4gVEhFIFNUQUdFLiBUaGVyZSBhcmUgVFdPIHJ1biBzdXJmYWNlcyDigJRcbi8vIGBDb252ZXJzYXRpb25TdGFnZWAgYW5kIGBDb2RpbmdBZ2VudGAg4oCUIGFuZCBib3RoIGFjcXVpcmUgdGhlIGxlYXNlLCBhcHBlbmQgZXZlcnlcbi8vIGJvdW5kYXJ5IGFuZCByZWxlYXNlIGF0IHRoZSBlbmQuIFRoZSBmaXJzdCB2ZXJzaW9uIHB1dCB0aGUgaW50ZXJ2YWwgaW4gdGhlIHN0YWdlXG4vLyBvbmx5LCBhbmQgdGhlIHJldmlldyBnYXRlJ3MgYW5zd2VyIHdhcyB0aGUgcmlnaHQgb25lOiBub3RoaW5nIGFib3V0IHRoZSBhcmd1bWVudFxuLy8gZm9yIGl0IGlzIHNwZWNpZmljIHRvIHRoYXQgY29tcG9uZW50LiBgQ29kaW5nQWdlbnRgIGFkb3B0cyB0aGUgTkVXRVNUXG4vLyBjb252ZXJzYXRpb24gYXQgbW91bnQsIHdoaWNoIGlzIHRoZSBvbmUgdGhlIHN0YWdlIGlzIG1vc3QgbGlrZWx5IGRyaXZpbmcsIHNvIGl0XG4vLyBpcyBpZiBhbnl0aGluZyB0aGUgc3VyZmFjZSB3aGVyZSBhIHNlY29uZCBmcmFtZSBpcyBtb3N0IHJlYWNoYWJsZS5cbi8vXG4vLyBXSFkgQU4gSU5URVJWQUwgQVQgQUxMLCB3aGVuIGBhcHBlbmRgIGFscmVhZHkgcmVmcmVzaGVzLiBCZWNhdXNlIGBhcHBlbmRgIG9ubHlcbi8vIHJ1bnMgYXQgYSBsb29wIGJvdW5kYXJ5LCBhbmQgdGhlIGxvb3AgcmVhY2hlcyBhIGJvdW5kYXJ5IG9ubHkgYWZ0ZXIgdGhlIG1vZGVsXG4vLyB0dXJuIHJldHVybnMuIE9uZSBsb25nIHR1cm4gb3V0bGFzdHMgYExFQVNFX1RUTF9NU2AsIHRoZSBydW5uaW5nIGZyYW1lJ3Mgb3duXG4vLyBsZWFzZSBleHBpcmVzIHVuZGVyIGl0LCBhbmQgYSBzZWNvbmQgZnJhbWUgcmVhZHMgYGZyZWVgIOKAlCB0aGUgZG91YmxlLWRyaXZlIHRoZVxuLy8gbGVhc2UgZXhpc3RzIHRvIHByZXZlbnQsIGFycml2aW5nIHRocm91Z2ggdGhlIG1lY2hhbmlzbSBtZWFudCB0byBwcmV2ZW50IGl0LlxuLy9cbi8vIFdIQVQgSVQgREVMSUJFUkFURUxZIERPRVMgTk9UIERPLiBJdCBkb2VzIG5vdCBzdXJmYWNlIHRoZSBsb3NzLiBBbiBlYXJsaWVyXG4vLyB2ZXJzaW9uIHNldCBhIFwiaGVsZFwiIGJhbm5lciBmcm9tIGhlcmUgYW5kIGNsYWltZWQgdG8gXCJyYWlzZSB0aGUgb2ZmZXJcbi8vIGltbWVkaWF0ZWx5XCI7IGl0IGNvdWxkIG5vdCwgYmVjYXVzZSB0aGUgYmFubmVyIHJlbmRlcnMgb25seSB3aGVuIHRoZSBydW4gaXMgTk9UXG4vLyBydW5uaW5nIGFuZCB0aGlzIHRpbWVyIGV4aXN0cyBvbmx5IHdoaWxlIGl0IGlzLiBUaGUgaG9uZXN0IHN0b3BwaW5nIHBvaW50IGZvciBhXG4vLyBsb3N0IGxlYXNlIGlzIHRoZSBuZXh0IGBhcHBlbmRgLCB3aGljaCByZWplY3RzIHdpdGggYSB0eXBlZCBjb2RlIGl0cyBjYWxsZXInc1xuLy8gY2F0Y2ggcmVuZGVycy4gU28gdGhpcyBsb29wIHJlZnJlc2hlcywgYW5kIHN0b3BzIG9uY2UgdGhlcmUgaXMgbm90aGluZyBsZWZ0IHRvXG4vLyByZWZyZXNoIOKAlCBubyBzZWNvbmQgb3BpbmlvbiBhYm91dCB0aGUgVUkuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHR5cGUgUmVmT2JqZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTEVBU0VfSEVBUlRCRUFUX01TIH0gZnJvbSAnLi4vbGliL2xlYXNlJztcblxuLyoqIFRoZSBvbmUgbWV0aG9kIHRoaXMgbmVlZHMsIHNvIGEgY2FsbGVyIGNhbiBwYXNzIGEgc3RvcmUgb3IgYSBzdHViLiAqL1xuZXhwb3J0IGludGVyZmFjZSBMZWFzZVJlZnJlc2hUYXJnZXQge1xuICBob2xkc1J1bihjb252SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj47XG59XG5cbi8qKlxuICogV2hpbGUgYHJ1bm5pbmdgLCByZWZyZXNoIHRoZSBydW4ncyBsZWFzZSBldmVyeSBgTEVBU0VfSEVBUlRCRUFUX01TYC5cbiAqXG4gKiBUaGVyZSBpcyBubyBgb25Mb3N0YCBjYWxsYmFjaywgZGVsaWJlcmF0ZWx5LiBBbiBlYXJsaWVyIHZlcnNpb24gaGFkIG9uZSBhbmRcbiAqIG5vdGhpbmcgcGFzc2VkIGl0IOKAlCBhbmQgYSBjYWxsYmFjayBpcyBleGFjdGx5IHRoZSBzZWFtIGEgbGF0ZXIgc3VyZmFjZSB3b3VsZFxuICogcmVhY2ggZm9yIHRvIHB1dCBhIGJhbm5lciBiYWNrIGhlcmUsIHdoaWNoIGlzIHRoZSBvcGluaW9uIHRoZSBoZWFkZXIgYWJvdmUgc2F5c1xuICogdGhpcyBsb29wIGRvZXMgbm90IGdldCB0byBoYXZlLiBMb3NpbmcgdGhlIGxlYXNlIHN0b3BzIHRoZSBsb29wIGFuZCBub3RoaW5nXG4gKiBlbHNlOyB0aGUgYXBwZW5kIHRoYXQgZm9sbG93cyBjYXJyaWVzIHRoZSB0eXBlZCBjb2RlIGl0cyBjYWxsZXIgcmVuZGVycy5cbiAqXG4gKiBBIHJlZnJlc2ggdGhhdCBUSFJPV1MgaXMgbm90IGEgbG9zcyBlaXRoZXI6IHRoZSBtb3VudCBjb3VsZCBub3QgYW5zd2VyLCB3aGljaCBpc1xuICogbm8gZXZpZGVuY2UgZWl0aGVyIHdheS4gYGNoZWNrSG9sZGAgdGFrZXMgdGhlIHNhbWUgcG9zaXRpb24sIGJvdW5kZWQgYnkgdGhlXG4gKiBsZWFzZSdzIG93biBleHBpcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VMZWFzZVJlZnJlc2goXG4gIC8qKiBUaGUgc3RvcmUsIGJ5IFJFRi4gQm90aCBjYWxsZXJzIGhvbGQgdGhlaXJzIGluIG9uZSwgYW5kXG4gICAqICBgZXNsaW50LXBsdWdpbi1yZWFjdC1ob29rc2AgdjcgbWFrZXMgcmVhZGluZyBgLmN1cnJlbnRgIGR1cmluZyByZW5kZXIgYSBoYXJkXG4gICAqICBlcnJvciDigJQgc28gdGhlIHJlZiBjcm9zc2VzIHRoZSBib3VuZGFyeSBhbmQgdGhlIGVmZmVjdCBkZXJlZmVyZW5jZXMgaXQuICovXG4gIHN0b3JlUmVmOiBSZWZPYmplY3Q8TGVhc2VSZWZyZXNoVGFyZ2V0IHwgbnVsbD4sXG4gIC8qKiBUaGUgY29udmVyc2F0aW9uIHRoaXMgcnVuIGhvbGRzLCBieSByZWYgZm9yIHRoZSBzYW1lIHJlYXNvbi4gUmVhZCBhdCBlYWNoXG4gICAqICBUSUNLIHJhdGhlciB0aGFuIGNhcHR1cmVkIG9uY2UsIHNvIGEgcnVuIHRoYXQgY2hhbmdlcyBjb252ZXJzYXRpb24gdW5kZXIgdGhlXG4gICAqICBob29rIHJlZnJlc2hlcyB0aGUgcmlnaHQgbGVhc2UgaW5zdGVhZCBvZiBhIHN0YWxlIG9uZS4gKi9cbiAgY29udklkUmVmOiBSZWZPYmplY3Q8c3RyaW5nIHwgbnVsbD4sXG4gIHJ1bm5pbmc6IGJvb2xlYW4sXG4pOiB2b2lkIHtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXJ1bm5pbmcpIHJldHVybjtcbiAgICBsZXQgbGl2ZSA9IHRydWU7XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCBjb252SWQgPSBjb252SWRSZWYuY3VycmVudDtcbiAgICAgIGlmICghc3RvcmUgfHwgIWNvbnZJZCkgcmV0dXJuOyAvLyBub3RoaW5nIHRvIHJlZnJlc2ggeWV0OyB0cnkgYWdhaW4gbmV4dCB0aWNrXG4gICAgICB2b2lkIHN0b3JlXG4gICAgICAgIC5ob2xkc1J1bihjb252SWQpXG4gICAgICAgIC50aGVuKChzdGlsbCkgPT4ge1xuICAgICAgICAgIGlmICghbGl2ZSB8fCBzdGlsbCkgcmV0dXJuO1xuICAgICAgICAgIGxpdmUgPSBmYWxzZTsgLy8gbm90aGluZyBsZWZ0IHRvIHJlZnJlc2gg4oCUIHN0b3AgYXNraW5nXG4gICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgLyogYSByZWZyZXNoIHRoYXQgY2Fubm90IHJ1biBpcyBub3QgYSBsb3NzIOKAlCB0aGUgVFRMIGRlY2lkZXMgKi9cbiAgICAgICAgfSk7XG4gICAgfSwgTEVBU0VfSEVBUlRCRUFUX01TKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgbGl2ZSA9IGZhbHNlO1xuICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gICAgfTtcbiAgICAvLyBUaGUgcmVmcyBhcmUgc3RhYmxlLCBzbyBgcnVubmluZ2AgaXMgdGhlIHdob2xlIGRlcGVuZGVuY3kgc2V0IOKAlCBhbmQgaXQgaGFzIHRvXG4gICAgLy8gc3RheSB0aGF0IHdheTogYSB2YWx1ZSBkZXBlbmRlbmN5IHRoYXQgY2hhbmdlZCBwZXIgcmVuZGVyIHdvdWxkIHRlYXIgZG93biBhbmRcbiAgICAvLyByZS1hcm0gdGhlIGludGVydmFsIGVhY2ggdGltZSwgd2hpY2ggaXMgaG93IGEgaGVhcnRiZWF0IHNpbGVudGx5IG5ldmVyIGZpcmVzLlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW3J1bm5pbmddKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBd0JBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQXpCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUE7O0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTRSxlQUFlQTtBQUM3QjtBQUNGO0FBQ0E7QUFDRUMsUUFBOEM7QUFDOUM7QUFDRjtBQUNBO0FBQ0VDLFNBQW1DLEVBQ25DQyxPQUFnQixFQUNWO0VBQ04sSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDRCxPQUFPLEVBQUU7SUFDZCxJQUFJRSxJQUFJLEdBQUcsSUFBSTtJQUNmLE1BQU1DLEtBQUssR0FBR0MsV0FBVyxDQUFDLE1BQU07TUFDOUIsTUFBTUMsS0FBSyxHQUFHUCxRQUFRLENBQUNRLE9BQU87TUFDOUIsTUFBTUMsTUFBTSxHQUFHUixTQUFTLENBQUNPLE9BQU87TUFDaEMsSUFBSSxDQUFDRCxLQUFLLElBQUksQ0FBQ0UsTUFBTSxFQUFFLE9BQU8sQ0FBQztNQUMvQixLQUFLRixLQUFLLENBQ1BHLFFBQVEsQ0FBQ0QsTUFBTSxDQUFDLENBQ2hCRSxJQUFJLENBQUVDLEtBQUssSUFBSztRQUNmLElBQUksQ0FBQ1IsSUFBSSxJQUFJUSxLQUFLLEVBQUU7UUFDcEJSLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQztRQUNkUyxhQUFhLENBQUNSLEtBQUssQ0FBQztNQUN0QixDQUFDLENBQUMsQ0FDRFMsS0FBSyxDQUFDLE1BQU07UUFDWDtNQUFBLENBQ0QsQ0FBQztJQUNOLENBQUMsRUFBRUMseUJBQWtCLENBQUM7SUFDdEIsT0FBTyxNQUFNO01BQ1hYLElBQUksR0FBRyxLQUFLO01BQ1pTLGFBQWEsQ0FBQ1IsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFDRDtJQUNBO0lBQ0E7SUFDQTtFQUNGLENBQUMsRUFBRSxDQUFDSCxPQUFPLENBQUMsQ0FBQztBQUNmIiwiaWdub3JlTGlzdCI6W119