var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = CodingAgent;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _toolset = require("../lib/toolset");
var _fsTools = require("../lib/fsTools");
var _projectTools = require("../lib/projectTools");
var _diagnosticsTools = require("../lib/diagnosticsTools");
var _gitTools = require("../lib/gitTools");
var _agentPrompt = require("../lib/agentPrompt");
var _skills = require("../lib/skills");
var _chatModelClient = require("../lib/chatModelClient");
var _agentLoop = require("../lib/agentLoop");
var _conversationStore = require("../lib/conversationStore");
var _transcript = require("../lib/transcript");
var _TranscriptRows = _interopRequireDefault(require("./TranscriptRows"));
var _storeError = require("../lib/storeError");
var _useLeaseRefresh = require("../hooks/useLeaseRefresh");
require("./CodingAgent.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // A real in-browser coding-agent loop (LLM_AND_AGENTS_SPEC §3.3). It hands the
// model two tool sources merged into one list: the app's grant-filtered §5.5
// catalog (driven through the host's gated `invoke()`) and mount-scoped
// filesystem tools (read/write/list/stat/glob/grep/delete over the app's working
// tree). Confinement is automatic (G12/T24): the model can only drive methods in
// this app's catalog or files inside its mount chroot; anything else returns
// `forbidden`/`not found`.
//
// Inference goes through the platform `llm.chat` service (SDK `chat()`): the app
// names no vendor and no model and holds no key — the host injects the user's key and
// resolves the user's preferred provider/model (AGENT_AUTHORING_ARCHITECTURE §3; H2
// favours chat() over net:fetch+secrets). Needs only the `llm:chat` capability.
/** R-ARD-10: the row for a run that cannot be persisted at all (no store — no
 *  host / signed out / settings mount dead). One copy: the mount effect and the
 *  run-start re-check both use it, so the copy cannot drift. */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const noStoreRow = e => ({
  kind: "error",
  text: `This run can't be saved (${e?.message ?? String(e)}) — closing the tab loses it.`
});
function CodingAgent() {
  _s();
  const catalog = (0, _sdk.useCatalog)();
  const mounts = (0, _sdk.useMounts)();
  const [prompt, setPrompt] = (0, _react.useState)("");
  const [log, setLog] = (0, _react.useState)([]);
  const [streaming, setStreaming] = (0, _react.useState)("");
  // R3-335 — the in-flight reasoning for the current block (cleared when the whole block
  // arrives and becomes a transcript row).
  const [thinking, setThinking] = (0, _react.useState)("");
  const [running, setRunning] = (0, _react.useState)(false);
  /** R3-561: which conversation this run holds the lease on, for the refresh
   *  interval below (a ref, so arming it does not wait for a render). */
  const runningIdRef = (0, _react.useRef)(null);

  // Persistence (Phase 01): keep this run in a durable conversation so it survives
  // reload. Best-effort — `openSettings()` is inert in local dev / signed out, so a
  // failure degrades to today's ephemeral behavior rather than crashing.
  const storeRef = (0, _react.useRef)(null);
  const convRef = (0, _react.useRef)(null);
  // R-ARD-10: why the store is absent, when it is — the run-start re-check needs
  // it after `setLog([])` wipes the mount-time row.
  const storeOpenErrorRef = (0, _react.useRef)(null);
  // R3-224 (§3.3): the stop button's abort controller for the in-flight run.
  const abortRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    let live = true;
    void (async () => {
      try {
        const store = await (0, _conversationStore.openConversationStore)();
        if (!live) return;
        storeRef.current = store;
        const [newest] = await store.list();
        const conv = newest ? await store.load(newest.id) : await store.create();
        if (!live || !conv) return;
        convRef.current = conv;
        if (conv.messages.length) setLog((0, _transcript.messagesToLog)(conv.messages));
      } catch (e) {
        // R-ARD-10: no store at all (no host / signed out / settings mount dead)
        // means a fully ephemeral run — allowed, but never a silent downgrade.
        if (live) {
          storeOpenErrorRef.current = e;
          setLog(l => [...l, noStoreRow(e)]);
        }
      }
    })();
    return () => {
      live = false;
    };
  }, []);

  // Merge the platform catalog with filesystem + project tools chrooted to the working
  // tree. When a stage app's tree is conferred (`type:'worktree'`, AA-23) author THAT;
  // otherwise (standalone agent) fall back to this app's own repo. Re-derived when the
  // conferred mount or its writability changes.
  // R3-339 — does the model the user configured accept images? The tool is told, so a
  // `read_file` on a PNG can SAY the model cannot look at it instead of sending
  // something that errors upstream. Re-read when the provider changes.
  const vision = (0, _react.useMemo)(() => (0, _sdk.describeChat)()?.features.vision === true, []);

  // `withSkills` runs LAST (R3-331): which host skills are offered depends on which
  // tools this run actually got, so selection needs the merged list.
  const {
    toolset,
    skills
  } = (0, _react.useMemo)(() => {
    const {
      root,
      readOnly
    } = (0, _fsTools.resolveWorkingTreeMount)(mounts, (0, _sdk.getAppMountPath)());
    const fsTools = (0, _fsTools.createFsToolset)({
      root,
      readOnly,
      vision
    });
    const projectTools = (0, _projectTools.createProjectToolset)({
      root,
      readOnly
    });
    const diagnosticsTools = (0, _diagnosticsTools.createDiagnosticsToolset)();
    // R3-332: git-READ over the same working tree. Empty (and therefore invisible to
    // the model) unless the app holds `vcs:read`.
    const gitTools = (0, _gitTools.createGitToolset)({
      catalog
    });
    // `withSkills` stays LAST (R3-331): which host skills are offered depends on the
    // final merged tool list, so it has to see the git tools too.
    return (0, _skills.withSkills)((0, _toolset.mergeToolsets)((0, _toolset.catalogToolset)(catalog), fsTools, projectTools, diagnosticsTools, gitTools));
  }, [catalog, mounts, vision]);

  // The workspace root the fs tools are chrooted to — env grounding for the prompt.
  const workspaceRoot = (0, _react.useMemo)(() => (0, _fsTools.resolveWorkingTreeMount)(mounts, (0, _sdk.getAppMountPath)()).root, [mounts]);
  const append = e => setLog(l => [...l, e]);

  // R3-561 / R-ARD-18: this surface runs and appends exactly as ConversationStage
  // does, so it refreshes the lease on the same interval. Round 1 fixed the stage
  // only; the argument — a model turn outlasts the TTL and boundary appends cannot
  // cover it — was never specific to that component, and this is the surface where
  // a second frame is most reachable, since it adopts the newest conversation.
  (0, _useLeaseRefresh.useLeaseRefresh)(storeRef, runningIdRef, running);
  const run = async () => {
    if (!prompt.trim() || running) return;
    setRunning(true);
    setLog([]);
    // R-ARD-10: the mount-time no-store row was just wiped by setLog([]) above —
    // an ephemeral run must SAY it is ephemeral on every run, not only at mount.
    if (!storeRef.current && storeOpenErrorRef.current !== null) {
      append(noStoreRow(storeOpenErrorRef.current));
    }
    setStreaming("");
    setThinking("");
    append({
      kind: "user",
      text: prompt
    });
    const controller = new AbortController();
    abortRef.current = controller;
    // R3-559: the conversation must exist BEFORE the run starts — the checkpoint
    // journal appends into it from the first boundary (B0), so a fresh run creates
    // its record up-front rather than at persist time.
    const store = storeRef.current;
    if (store && !convRef.current) {
      try {
        convRef.current = await store.create();
      } catch (e) {
        // R-ARD-10: an un-checkpointable run is allowed to start, and SAYS SO —
        // never a silent downgrade to ephemeral. The run proceeds exactly as the
        // pre-journal agent did; the user is told what that costs.
        append(noStoreRow(e));
      }
    }
    // Same rule for the journal tier: journalless is a degradation the user can
    // see (the conversation still saves at run end; the checkpoint floor is gone).
    if (store && convRef.current && !store.hasJournal()) {
      append({
        kind: "error",
        text: "Checkpoints are off (no device-local store) — closing this tab loses the in-flight turn; the conversation itself still saves when the run ends."
      });
    }
    // R3-561 / R-ARD-18: take the advisory run lease. This demo is the THIRD opener
    // of the same store — the panel and the stage are the other two — and it adopts
    // the NEWEST conversation at mount, so "the agents activity and this tab, same
    // conversation" is reachable rather than theoretical. Without this the first
    // append would throw and print internal copy about a lease the user never saw.
    //
    // No takeover BUTTON here, deliberately: this surface's whole UI is a prompt
    // and a Run/Stop control, and inventing an affordance row for a demo would be
    // the bespoke UI the run-mode rule warns against. R-ARD-18a still forbids a
    // DEAD END, so the copy names what genuinely frees the lease — its TTL — and
    // not an action this component does not have. (An earlier version said "start
    // a new conversation here", which is an instruction the user cannot follow:
    // there is no such control, and the mount effect re-adopts the newest
    // conversation, so a reload lands on the same refusal.)
    //
    // The REFRESH, unlike the button, is not optional here — this surface runs and
    // appends exactly as the stage does, so it gets the same `useLeaseRefresh`.
    if (store && convRef.current) {
      try {
        if ((await store.acquireRun(convRef.current.id)) === "held") {
          append({
            kind: "error",
            text: (0, _storeError.leaseHeldText)(false)
          });
          setRunning(false);
          abortRef.current = null;
          return;
        }
      } catch (e) {
        // A lease we cannot read is not a lease we lost. Say the store is degraded
        // and run, rather than refusing on an unknown.
        append(noStoreRow(e));
      }
    }
    runningIdRef.current = convRef.current?.id ?? null;
    const journalConv = store?.hasJournal() ? convRef.current : null;
    try {
      const transcript = await (0, _agentLoop.runAgent)({
        client: (0, _chatModelClient.createChatModelClient)(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: (0, _agentPrompt.buildSystemPrompt)({
          tools: toolset.tools,
          skills,
          workspaceRoot,
          today: (0, _agentPrompt.todayIso)()
        }),
        prompt,
        // R3-224 (§3.3): the stop button aborts the loop AND the in-flight LLM turn.
        signal: controller.signal,
        // Token accounting + auto-compaction let the loop run past ~12 turns
        // (R3-220): the resolved provider's window drives when to compact.
        contextWindow: (0, _sdk.describeChat)()?.features.maxContextTokens,
        events: {
          // R3-559: append every boundary to the conversation's journal (B2
          // intent is durable before its executor runs — R-ARD-10a). The loop
          // awaits this; a failed append unwinds the run at that boundary.
          ...(journalConv ? {
            onBoundary: async b => {
              await store.append(journalConv.id, b);
            }
          } : {}),
          onAssistantDelta: text => setStreaming(s => s + text),
          // R3-335 — the live thinking surface. Now that compaction lets a task run past
          // a dozen turns, the silent stretches are longer, and "is it stuck or
          // thinking?" had no answer on screen.
          onReasoningDelta: text => setThinking(t => t + text),
          onReasoning: block => {
            setThinking("");
            append(block.redactedData !== undefined ? {
              kind: "reasoning",
              text: "",
              redacted: true
            } : {
              kind: "reasoning",
              text: block.text
            });
          },
          onAssistantText: text => {
            if (text.trim()) append({
              kind: "text",
              text
            });
            setStreaming("");
          },
          onToolUse: (name, input) => append({
            kind: "tool",
            name,
            input
          }),
          onToolResult: (name, r) => append({
            kind: "result",
            name,
            content: r.content,
            isError: r.isError
          }),
          onNudge: () => append({
            kind: "nudge"
          }),
          onCompact: ({
            summarizedCount
          }) => {
            append({
              kind: "compaction",
              summary: `${summarizedCount} earlier messages summarized`
            });
            // R3-559 (R-ARD-9): fold at the compaction boundary, best-effort — the
            // run-end fold is the authoritative write (see ConversationStage).
            if (journalConv) {
              void store.fold(journalConv.id).catch(e => {
                console.warn("mid-run fold at compaction failed (run-end fold still will)", e);
              });
            }
          }
        }
      });
      await persist(transcript);
    } catch (e) {
      // R3-561: the two lease codes are UX states, not codes to print (§9). Same
      // mapping as the stage's two catches, `canTakeOver: false` — this surface
      // has no affordance row, so the copy names the TTL, which actually frees the
      // lease, rather than a button it does not ship.
      const lease = (0, _storeError.leaseFailure)(e);
      append(lease ? {
        kind: "error",
        text: (0, _storeError.leaseFailureText)(lease, false)
      } : {
        kind: "error",
        text: e?.message ?? String(e)
      });
    } finally {
      setStreaming("");
      setThinking("");
      setRunning(false);
      abortRef.current = null;
      // R3-561: hand the lease back — the id the RUN held, read before it is
      // cleared, not whatever is on screen. Fired, not awaited; see
      // `releaseHeldLease` in ConversationStage for the argument.
      {
        const store = storeRef.current;
        const id = runningIdRef.current;
        if (store && id) void store.releaseRun(id).catch(() => {});
      }
      runningIdRef.current = null;
    }
  };

  // R3-224 (§3.3): abort the in-flight run — the loop AND the upstream LLM request.
  const stop = () => abortRef.current?.abort();

  // Save the run into its conversation — a FOLD when the journal tier is wired
  // (R3-559: stamps the fold watermark + carried run-state, reclaims the
  // superseded entries), a plain save otherwise. Best-effort; no-op without a store.
  const persist = async messages => {
    const store = storeRef.current;
    if (!store) return;
    try {
      const conv = convRef.current ?? (await store.create());
      const title = conv.title === "New conversation" ? (0, _conversationStore.deriveTitle)(messages) : conv.title;
      convRef.current = store.hasJournal() ? await store.fold(conv.id, {
        messages,
        title
      }) : await store.save({
        ...conv,
        title,
        messages
      });
    } catch {
      /* persistence is best-effort — never break the run on a write failure */
    }
  };

  // R3-612 / R-IX-5 — every run lands in a durable conversation, so this surface
  // must offer a fresh start and name where the runs go. The Conversations list
  // is where they accumulate and where one can be removed; this surface names
  // that place rather than growing its own browser.
  const newConversation = async () => {
    const store = storeRef.current;
    if (!store || running) return;
    try {
      const conv = await store.create();
      convRef.current = conv;
      setLog([]);
      setStreaming("");
      setThinking("");
    } catch (e) {
      setLog(l => [...l, {
        kind: "error",
        text: `Could not start a new conversation (${e?.message ?? String(e)})`
      }]);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ca",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ca-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-title",
        children: "Coding agent"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "ca-sub",
        children: [toolset.tools.length, " tools (catalog + files + project + diagnostics)"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-new",
        disabled: running,
        onClick: () => void newConversation(),
        children: "New conversation"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-prompt-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "ca-prompt",
        placeholder: "Ask the agent to read, search, or edit your app\u2026",
        value: prompt,
        onChange: e => setPrompt(e.target.value),
        onKeyDown: e => {
          if (e.key === "Enter") void run();
        },
        "aria-label": "Prompt"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-run"
        // While running, this is a live Stop control (R3-224) — abort the in-flight turn.
        ,
        onClick: () => running ? stop() : void run(),
        children: running ? "Stop" : "Run"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      className: "ca-log",
      "aria-live": "polite",
      children: [!log.length && !thinking && !streaming && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-empty",
        children: "Runs are saved to your Conversations list."
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_TranscriptRows.default, {
        log: log
      }), thinking && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
          className: "ca-reasoning",
          open: true,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
            children: "thinking\u2026"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ca-reasoning-body",
            children: thinking
          })]
        })
      }), streaming && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-text ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-text",
          children: streaming
        })
      })]
    })]
  });
}
_s(CodingAgent, "17b5ez9QKYJcR3mHE4ma1KEns+s=", false, function () {
  return [_sdk.useCatalog, _sdk.useMounts, _useLeaseRefresh.useLeaseRefresh];
});
_c = CodingAgent;
var _c;
$RefreshReg$(_c, "CodingAgent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl90b29sc2V0IiwiX2ZzVG9vbHMiLCJfcHJvamVjdFRvb2xzIiwiX2RpYWdub3N0aWNzVG9vbHMiLCJfZ2l0VG9vbHMiLCJfYWdlbnRQcm9tcHQiLCJfc2tpbGxzIiwiX2NoYXRNb2RlbENsaWVudCIsIl9hZ2VudExvb3AiLCJfY29udmVyc2F0aW9uU3RvcmUiLCJfdHJhbnNjcmlwdCIsIl9UcmFuc2NyaXB0Um93cyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfc3RvcmVFcnJvciIsIl91c2VMZWFzZVJlZnJlc2giLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0Iiwibm9TdG9yZVJvdyIsImtpbmQiLCJ0ZXh0IiwibWVzc2FnZSIsIlN0cmluZyIsIkNvZGluZ0FnZW50IiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJwcm9tcHQiLCJzZXRQcm9tcHQiLCJ1c2VTdGF0ZSIsImxvZyIsInNldExvZyIsInN0cmVhbWluZyIsInNldFN0cmVhbWluZyIsInRoaW5raW5nIiwic2V0VGhpbmtpbmciLCJydW5uaW5nIiwic2V0UnVubmluZyIsInJ1bm5pbmdJZFJlZiIsInVzZVJlZiIsInN0b3JlUmVmIiwiY29udlJlZiIsInN0b3JlT3BlbkVycm9yUmVmIiwiYWJvcnRSZWYiLCJ1c2VFZmZlY3QiLCJsaXZlIiwic3RvcmUiLCJvcGVuQ29udmVyc2F0aW9uU3RvcmUiLCJjdXJyZW50IiwibmV3ZXN0IiwibGlzdCIsImNvbnYiLCJsb2FkIiwiaWQiLCJjcmVhdGUiLCJtZXNzYWdlcyIsImxlbmd0aCIsIm1lc3NhZ2VzVG9Mb2ciLCJsIiwidmlzaW9uIiwidXNlTWVtbyIsImRlc2NyaWJlQ2hhdCIsImZlYXR1cmVzIiwidG9vbHNldCIsInNraWxscyIsInJvb3QiLCJyZWFkT25seSIsInJlc29sdmVXb3JraW5nVHJlZU1vdW50IiwiZ2V0QXBwTW91bnRQYXRoIiwiZnNUb29scyIsImNyZWF0ZUZzVG9vbHNldCIsInByb2plY3RUb29scyIsImNyZWF0ZVByb2plY3RUb29sc2V0IiwiZGlhZ25vc3RpY3NUb29scyIsImNyZWF0ZURpYWdub3N0aWNzVG9vbHNldCIsImdpdFRvb2xzIiwiY3JlYXRlR2l0VG9vbHNldCIsIndpdGhTa2lsbHMiLCJtZXJnZVRvb2xzZXRzIiwiY2F0YWxvZ1Rvb2xzZXQiLCJ3b3Jrc3BhY2VSb290IiwiYXBwZW5kIiwidXNlTGVhc2VSZWZyZXNoIiwicnVuIiwidHJpbSIsImNvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJoYXNKb3VybmFsIiwiYWNxdWlyZVJ1biIsImxlYXNlSGVsZFRleHQiLCJqb3VybmFsQ29udiIsInRyYW5zY3JpcHQiLCJydW5BZ2VudCIsImNsaWVudCIsImNyZWF0ZUNoYXRNb2RlbENsaWVudCIsInRvb2xzIiwiZXhlY3V0ZSIsInN5c3RlbSIsImJ1aWxkU3lzdGVtUHJvbXB0IiwidG9kYXkiLCJ0b2RheUlzbyIsInNpZ25hbCIsImNvbnRleHRXaW5kb3ciLCJtYXhDb250ZXh0VG9rZW5zIiwiZXZlbnRzIiwib25Cb3VuZGFyeSIsImIiLCJvbkFzc2lzdGFudERlbHRhIiwicyIsIm9uUmVhc29uaW5nRGVsdGEiLCJ0Iiwib25SZWFzb25pbmciLCJibG9jayIsInJlZGFjdGVkRGF0YSIsInVuZGVmaW5lZCIsInJlZGFjdGVkIiwib25Bc3Npc3RhbnRUZXh0Iiwib25Ub29sVXNlIiwibmFtZSIsImlucHV0Iiwib25Ub29sUmVzdWx0IiwiciIsImNvbnRlbnQiLCJpc0Vycm9yIiwib25OdWRnZSIsIm9uQ29tcGFjdCIsInN1bW1hcml6ZWRDb3VudCIsInN1bW1hcnkiLCJmb2xkIiwiY2F0Y2giLCJjb25zb2xlIiwid2FybiIsInBlcnNpc3QiLCJsZWFzZSIsImxlYXNlRmFpbHVyZSIsImxlYXNlRmFpbHVyZVRleHQiLCJyZWxlYXNlUnVuIiwic3RvcCIsImFib3J0IiwidGl0bGUiLCJkZXJpdmVUaXRsZSIsInNhdmUiLCJuZXdDb252ZXJzYXRpb24iLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwiZGlzYWJsZWQiLCJvbkNsaWNrIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwidGFyZ2V0Iiwib25LZXlEb3duIiwia2V5Iiwib3BlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29kaW5nQWdlbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEEgcmVhbCBpbi1icm93c2VyIGNvZGluZy1hZ2VudCBsb29wIChMTE1fQU5EX0FHRU5UU19TUEVDIMKnMy4zKS4gSXQgaGFuZHMgdGhlXG4vLyBtb2RlbCB0d28gdG9vbCBzb3VyY2VzIG1lcmdlZCBpbnRvIG9uZSBsaXN0OiB0aGUgYXBwJ3MgZ3JhbnQtZmlsdGVyZWQgwqc1LjVcbi8vIGNhdGFsb2cgKGRyaXZlbiB0aHJvdWdoIHRoZSBob3N0J3MgZ2F0ZWQgYGludm9rZSgpYCkgYW5kIG1vdW50LXNjb3BlZFxuLy8gZmlsZXN5c3RlbSB0b29scyAocmVhZC93cml0ZS9saXN0L3N0YXQvZ2xvYi9ncmVwL2RlbGV0ZSBvdmVyIHRoZSBhcHAncyB3b3JraW5nXG4vLyB0cmVlKS4gQ29uZmluZW1lbnQgaXMgYXV0b21hdGljIChHMTIvVDI0KTogdGhlIG1vZGVsIGNhbiBvbmx5IGRyaXZlIG1ldGhvZHMgaW5cbi8vIHRoaXMgYXBwJ3MgY2F0YWxvZyBvciBmaWxlcyBpbnNpZGUgaXRzIG1vdW50IGNocm9vdDsgYW55dGhpbmcgZWxzZSByZXR1cm5zXG4vLyBgZm9yYmlkZGVuYC9gbm90IGZvdW5kYC5cbi8vXG4vLyBJbmZlcmVuY2UgZ29lcyB0aHJvdWdoIHRoZSBwbGF0Zm9ybSBgbGxtLmNoYXRgIHNlcnZpY2UgKFNESyBgY2hhdCgpYCk6IHRoZSBhcHBcbi8vIG5hbWVzIG5vIHZlbmRvciBhbmQgbm8gbW9kZWwgYW5kIGhvbGRzIG5vIGtleSDigJQgdGhlIGhvc3QgaW5qZWN0cyB0aGUgdXNlcidzIGtleSBhbmRcbi8vIHJlc29sdmVzIHRoZSB1c2VyJ3MgcHJlZmVycmVkIHByb3ZpZGVyL21vZGVsIChBR0VOVF9BVVRIT1JJTkdfQVJDSElURUNUVVJFIMKnMzsgSDJcbi8vIGZhdm91cnMgY2hhdCgpIG92ZXIgbmV0OmZldGNoK3NlY3JldHMpLiBOZWVkcyBvbmx5IHRoZSBgbGxtOmNoYXRgIGNhcGFiaWxpdHkuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUNhdGFsb2csIHVzZU1vdW50cywgZ2V0QXBwTW91bnRQYXRoLCBkZXNjcmliZUNoYXQgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCB7IGNhdGFsb2dUb29sc2V0LCBtZXJnZVRvb2xzZXRzIH0gZnJvbSBcIi4uL2xpYi90b29sc2V0XCI7XG5pbXBvcnQgeyBjcmVhdGVGc1Rvb2xzZXQsIHJlc29sdmVXb3JraW5nVHJlZU1vdW50IH0gZnJvbSBcIi4uL2xpYi9mc1Rvb2xzXCI7XG5pbXBvcnQgeyBjcmVhdGVQcm9qZWN0VG9vbHNldCB9IGZyb20gXCIuLi9saWIvcHJvamVjdFRvb2xzXCI7XG5pbXBvcnQgeyBjcmVhdGVEaWFnbm9zdGljc1Rvb2xzZXQgfSBmcm9tIFwiLi4vbGliL2RpYWdub3N0aWNzVG9vbHNcIjtcbmltcG9ydCB7IGNyZWF0ZUdpdFRvb2xzZXQgfSBmcm9tIFwiLi4vbGliL2dpdFRvb2xzXCI7XG5pbXBvcnQgeyBidWlsZFN5c3RlbVByb21wdCwgdG9kYXlJc28gfSBmcm9tIFwiLi4vbGliL2FnZW50UHJvbXB0XCI7XG5pbXBvcnQgeyB3aXRoU2tpbGxzIH0gZnJvbSBcIi4uL2xpYi9za2lsbHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYXRNb2RlbENsaWVudCB9IGZyb20gXCIuLi9saWIvY2hhdE1vZGVsQ2xpZW50XCI7XG5pbXBvcnQgeyBydW5BZ2VudCwgdHlwZSBMb29wQm91bmRhcnkgfSBmcm9tIFwiLi4vbGliL2FnZW50TG9vcFwiO1xuaW1wb3J0IHsgb3BlbkNvbnZlcnNhdGlvblN0b3JlLCBkZXJpdmVUaXRsZSwgdHlwZSBDb252ZXJzYXRpb25TdG9yZSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uU3RvcmVcIjtcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uIH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25Nb2RlbFwiO1xuaW1wb3J0IHsgbWVzc2FnZXNUb0xvZywgdHlwZSBMb2dFbnRyeSB9IGZyb20gXCIuLi9saWIvdHJhbnNjcmlwdFwiO1xuaW1wb3J0IFRyYW5zY3JpcHRSb3dzIGZyb20gXCIuL1RyYW5zY3JpcHRSb3dzXCI7XG5pbXBvcnQgeyBsZWFzZUZhaWx1cmUsIGxlYXNlRmFpbHVyZVRleHQsIGxlYXNlSGVsZFRleHQgfSBmcm9tIFwiLi4vbGliL3N0b3JlRXJyb3JcIjtcbmltcG9ydCB7IHVzZUxlYXNlUmVmcmVzaCB9IGZyb20gXCIuLi9ob29rcy91c2VMZWFzZVJlZnJlc2hcIjtcbmltcG9ydCBcIi4vQ29kaW5nQWdlbnQuY3NzXCI7XG5cbi8qKiBSLUFSRC0xMDogdGhlIHJvdyBmb3IgYSBydW4gdGhhdCBjYW5ub3QgYmUgcGVyc2lzdGVkIGF0IGFsbCAobm8gc3RvcmUg4oCUIG5vXG4gKiAgaG9zdCAvIHNpZ25lZCBvdXQgLyBzZXR0aW5ncyBtb3VudCBkZWFkKS4gT25lIGNvcHk6IHRoZSBtb3VudCBlZmZlY3QgYW5kIHRoZVxuICogIHJ1bi1zdGFydCByZS1jaGVjayBib3RoIHVzZSBpdCwgc28gdGhlIGNvcHkgY2Fubm90IGRyaWZ0LiAqL1xuY29uc3Qgbm9TdG9yZVJvdyA9IChlOiB1bmtub3duKTogTG9nRW50cnkgPT4gKHtcbiAga2luZDogXCJlcnJvclwiLFxuICB0ZXh0OiBgVGhpcyBydW4gY2FuJ3QgYmUgc2F2ZWQgKCR7KGUgYXMgRXJyb3IpPy5tZXNzYWdlID8/IFN0cmluZyhlKX0pIOKAlCBjbG9zaW5nIHRoZSB0YWIgbG9zZXMgaXQuYCxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb2RpbmdBZ2VudCgpIHtcbiAgY29uc3QgY2F0YWxvZyA9IHVzZUNhdGFsb2coKTtcbiAgY29uc3QgbW91bnRzID0gdXNlTW91bnRzKCk7XG4gIGNvbnN0IFtwcm9tcHQsIHNldFByb21wdF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvZywgc2V0TG9nXSA9IHVzZVN0YXRlPExvZ0VudHJ5W10+KFtdKTtcbiAgY29uc3QgW3N0cmVhbWluZywgc2V0U3RyZWFtaW5nXSA9IHVzZVN0YXRlKFwiXCIpO1xuICAvLyBSMy0zMzUg4oCUIHRoZSBpbi1mbGlnaHQgcmVhc29uaW5nIGZvciB0aGUgY3VycmVudCBibG9jayAoY2xlYXJlZCB3aGVuIHRoZSB3aG9sZSBibG9ja1xuICAvLyBhcnJpdmVzIGFuZCBiZWNvbWVzIGEgdHJhbnNjcmlwdCByb3cpLlxuICBjb25zdCBbdGhpbmtpbmcsIHNldFRoaW5raW5nXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcnVubmluZywgc2V0UnVubmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIC8qKiBSMy01NjE6IHdoaWNoIGNvbnZlcnNhdGlvbiB0aGlzIHJ1biBob2xkcyB0aGUgbGVhc2Ugb24sIGZvciB0aGUgcmVmcmVzaFxuICAgKiAgaW50ZXJ2YWwgYmVsb3cgKGEgcmVmLCBzbyBhcm1pbmcgaXQgZG9lcyBub3Qgd2FpdCBmb3IgYSByZW5kZXIpLiAqL1xuICBjb25zdCBydW5uaW5nSWRSZWYgPSB1c2VSZWY8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gUGVyc2lzdGVuY2UgKFBoYXNlIDAxKToga2VlcCB0aGlzIHJ1biBpbiBhIGR1cmFibGUgY29udmVyc2F0aW9uIHNvIGl0IHN1cnZpdmVzXG4gIC8vIHJlbG9hZC4gQmVzdC1lZmZvcnQg4oCUIGBvcGVuU2V0dGluZ3MoKWAgaXMgaW5lcnQgaW4gbG9jYWwgZGV2IC8gc2lnbmVkIG91dCwgc28gYVxuICAvLyBmYWlsdXJlIGRlZ3JhZGVzIHRvIHRvZGF5J3MgZXBoZW1lcmFsIGJlaGF2aW9yIHJhdGhlciB0aGFuIGNyYXNoaW5nLlxuICBjb25zdCBzdG9yZVJlZiA9IHVzZVJlZjxDb252ZXJzYXRpb25TdG9yZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBjb252UmVmID0gdXNlUmVmPENvbnZlcnNhdGlvbiB8IG51bGw+KG51bGwpO1xuICAvLyBSLUFSRC0xMDogd2h5IHRoZSBzdG9yZSBpcyBhYnNlbnQsIHdoZW4gaXQgaXMg4oCUIHRoZSBydW4tc3RhcnQgcmUtY2hlY2sgbmVlZHNcbiAgLy8gaXQgYWZ0ZXIgYHNldExvZyhbXSlgIHdpcGVzIHRoZSBtb3VudC10aW1lIHJvdy5cbiAgY29uc3Qgc3RvcmVPcGVuRXJyb3JSZWYgPSB1c2VSZWY8dW5rbm93bj4obnVsbCk7XG4gIC8vIFIzLTIyNCAowqczLjMpOiB0aGUgc3RvcCBidXR0b24ncyBhYm9ydCBjb250cm9sbGVyIGZvciB0aGUgaW4tZmxpZ2h0IHJ1bi5cbiAgY29uc3QgYWJvcnRSZWYgPSB1c2VSZWY8QWJvcnRDb250cm9sbGVyIHwgbnVsbD4obnVsbCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGxpdmUgPSB0cnVlO1xuICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXdhaXQgb3BlbkNvbnZlcnNhdGlvblN0b3JlKCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzdG9yZVJlZi5jdXJyZW50ID0gc3RvcmU7XG4gICAgICAgIGNvbnN0IFtuZXdlc3RdID0gYXdhaXQgc3RvcmUubGlzdCgpO1xuICAgICAgICBjb25zdCBjb252ID0gbmV3ZXN0ID8gYXdhaXQgc3RvcmUubG9hZChuZXdlc3QuaWQpIDogYXdhaXQgc3RvcmUuY3JlYXRlKCk7XG4gICAgICAgIGlmICghbGl2ZSB8fCAhY29udikgcmV0dXJuO1xuICAgICAgICBjb252UmVmLmN1cnJlbnQgPSBjb252O1xuICAgICAgICBpZiAoY29udi5tZXNzYWdlcy5sZW5ndGgpIHNldExvZyhtZXNzYWdlc1RvTG9nKGNvbnYubWVzc2FnZXMpKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gUi1BUkQtMTA6IG5vIHN0b3JlIGF0IGFsbCAobm8gaG9zdCAvIHNpZ25lZCBvdXQgLyBzZXR0aW5ncyBtb3VudCBkZWFkKVxuICAgICAgICAvLyBtZWFucyBhIGZ1bGx5IGVwaGVtZXJhbCBydW4g4oCUIGFsbG93ZWQsIGJ1dCBuZXZlciBhIHNpbGVudCBkb3duZ3JhZGUuXG4gICAgICAgIGlmIChsaXZlKSB7XG4gICAgICAgICAgc3RvcmVPcGVuRXJyb3JSZWYuY3VycmVudCA9IGU7XG4gICAgICAgICAgc2V0TG9nKChsKSA9PiBbLi4ubCwgbm9TdG9yZVJvdyhlKV0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgbGl2ZSA9IGZhbHNlO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICAvLyBNZXJnZSB0aGUgcGxhdGZvcm0gY2F0YWxvZyB3aXRoIGZpbGVzeXN0ZW0gKyBwcm9qZWN0IHRvb2xzIGNocm9vdGVkIHRvIHRoZSB3b3JraW5nXG4gIC8vIHRyZWUuIFdoZW4gYSBzdGFnZSBhcHAncyB0cmVlIGlzIGNvbmZlcnJlZCAoYHR5cGU6J3dvcmt0cmVlJ2AsIEFBLTIzKSBhdXRob3IgVEhBVDtcbiAgLy8gb3RoZXJ3aXNlIChzdGFuZGFsb25lIGFnZW50KSBmYWxsIGJhY2sgdG8gdGhpcyBhcHAncyBvd24gcmVwby4gUmUtZGVyaXZlZCB3aGVuIHRoZVxuICAvLyBjb25mZXJyZWQgbW91bnQgb3IgaXRzIHdyaXRhYmlsaXR5IGNoYW5nZXMuXG4gIC8vIFIzLTMzOSDigJQgZG9lcyB0aGUgbW9kZWwgdGhlIHVzZXIgY29uZmlndXJlZCBhY2NlcHQgaW1hZ2VzPyBUaGUgdG9vbCBpcyB0b2xkLCBzbyBhXG4gIC8vIGByZWFkX2ZpbGVgIG9uIGEgUE5HIGNhbiBTQVkgdGhlIG1vZGVsIGNhbm5vdCBsb29rIGF0IGl0IGluc3RlYWQgb2Ygc2VuZGluZ1xuICAvLyBzb21ldGhpbmcgdGhhdCBlcnJvcnMgdXBzdHJlYW0uIFJlLXJlYWQgd2hlbiB0aGUgcHJvdmlkZXIgY2hhbmdlcy5cbiAgY29uc3QgdmlzaW9uID0gdXNlTWVtbygoKSA9PiBkZXNjcmliZUNoYXQoKT8uZmVhdHVyZXMudmlzaW9uID09PSB0cnVlLCBbXSk7XG5cbiAgLy8gYHdpdGhTa2lsbHNgIHJ1bnMgTEFTVCAoUjMtMzMxKTogd2hpY2ggaG9zdCBza2lsbHMgYXJlIG9mZmVyZWQgZGVwZW5kcyBvbiB3aGljaFxuICAvLyB0b29scyB0aGlzIHJ1biBhY3R1YWxseSBnb3QsIHNvIHNlbGVjdGlvbiBuZWVkcyB0aGUgbWVyZ2VkIGxpc3QuXG4gIGNvbnN0IHsgdG9vbHNldCwgc2tpbGxzIH0gPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCB7IHJvb3QsIHJlYWRPbmx5IH0gPSByZXNvbHZlV29ya2luZ1RyZWVNb3VudChtb3VudHMsIGdldEFwcE1vdW50UGF0aCgpKTtcbiAgICBjb25zdCBmc1Rvb2xzID0gY3JlYXRlRnNUb29sc2V0KHsgcm9vdCwgcmVhZE9ubHksIHZpc2lvbiB9KTtcbiAgICBjb25zdCBwcm9qZWN0VG9vbHMgPSBjcmVhdGVQcm9qZWN0VG9vbHNldCh7IHJvb3QsIHJlYWRPbmx5IH0pO1xuICAgIGNvbnN0IGRpYWdub3N0aWNzVG9vbHMgPSBjcmVhdGVEaWFnbm9zdGljc1Rvb2xzZXQoKTtcbiAgICAvLyBSMy0zMzI6IGdpdC1SRUFEIG92ZXIgdGhlIHNhbWUgd29ya2luZyB0cmVlLiBFbXB0eSAoYW5kIHRoZXJlZm9yZSBpbnZpc2libGUgdG9cbiAgICAvLyB0aGUgbW9kZWwpIHVubGVzcyB0aGUgYXBwIGhvbGRzIGB2Y3M6cmVhZGAuXG4gICAgY29uc3QgZ2l0VG9vbHMgPSBjcmVhdGVHaXRUb29sc2V0KHsgY2F0YWxvZyB9KTtcbiAgICAvLyBgd2l0aFNraWxsc2Agc3RheXMgTEFTVCAoUjMtMzMxKTogd2hpY2ggaG9zdCBza2lsbHMgYXJlIG9mZmVyZWQgZGVwZW5kcyBvbiB0aGVcbiAgICAvLyBmaW5hbCBtZXJnZWQgdG9vbCBsaXN0LCBzbyBpdCBoYXMgdG8gc2VlIHRoZSBnaXQgdG9vbHMgdG9vLlxuICAgIHJldHVybiB3aXRoU2tpbGxzKG1lcmdlVG9vbHNldHMoY2F0YWxvZ1Rvb2xzZXQoY2F0YWxvZyksIGZzVG9vbHMsIHByb2plY3RUb29scywgZGlhZ25vc3RpY3NUb29scywgZ2l0VG9vbHMpKTtcbiAgfSwgW2NhdGFsb2csIG1vdW50cywgdmlzaW9uXSk7XG5cbiAgLy8gVGhlIHdvcmtzcGFjZSByb290IHRoZSBmcyB0b29scyBhcmUgY2hyb290ZWQgdG8g4oCUIGVudiBncm91bmRpbmcgZm9yIHRoZSBwcm9tcHQuXG4gIGNvbnN0IHdvcmtzcGFjZVJvb3QgPSB1c2VNZW1vKFxuICAgICgpID0+IHJlc29sdmVXb3JraW5nVHJlZU1vdW50KG1vdW50cywgZ2V0QXBwTW91bnRQYXRoKCkpLnJvb3QsXG4gICAgW21vdW50c10sXG4gICk7XG5cbiAgY29uc3QgYXBwZW5kID0gKGU6IExvZ0VudHJ5KSA9PiBzZXRMb2coKGwpID0+IFsuLi5sLCBlXSk7XG5cbiAgLy8gUjMtNTYxIC8gUi1BUkQtMTg6IHRoaXMgc3VyZmFjZSBydW5zIGFuZCBhcHBlbmRzIGV4YWN0bHkgYXMgQ29udmVyc2F0aW9uU3RhZ2VcbiAgLy8gZG9lcywgc28gaXQgcmVmcmVzaGVzIHRoZSBsZWFzZSBvbiB0aGUgc2FtZSBpbnRlcnZhbC4gUm91bmQgMSBmaXhlZCB0aGUgc3RhZ2VcbiAgLy8gb25seTsgdGhlIGFyZ3VtZW50IOKAlCBhIG1vZGVsIHR1cm4gb3V0bGFzdHMgdGhlIFRUTCBhbmQgYm91bmRhcnkgYXBwZW5kcyBjYW5ub3RcbiAgLy8gY292ZXIgaXQg4oCUIHdhcyBuZXZlciBzcGVjaWZpYyB0byB0aGF0IGNvbXBvbmVudCwgYW5kIHRoaXMgaXMgdGhlIHN1cmZhY2Ugd2hlcmVcbiAgLy8gYSBzZWNvbmQgZnJhbWUgaXMgbW9zdCByZWFjaGFibGUsIHNpbmNlIGl0IGFkb3B0cyB0aGUgbmV3ZXN0IGNvbnZlcnNhdGlvbi5cbiAgdXNlTGVhc2VSZWZyZXNoKHN0b3JlUmVmLCBydW5uaW5nSWRSZWYsIHJ1bm5pbmcpO1xuXG4gIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXByb21wdC50cmltKCkgfHwgcnVubmluZykgcmV0dXJuO1xuICAgIHNldFJ1bm5pbmcodHJ1ZSk7XG4gICAgc2V0TG9nKFtdKTtcbiAgICAvLyBSLUFSRC0xMDogdGhlIG1vdW50LXRpbWUgbm8tc3RvcmUgcm93IHdhcyBqdXN0IHdpcGVkIGJ5IHNldExvZyhbXSkgYWJvdmUg4oCUXG4gICAgLy8gYW4gZXBoZW1lcmFsIHJ1biBtdXN0IFNBWSBpdCBpcyBlcGhlbWVyYWwgb24gZXZlcnkgcnVuLCBub3Qgb25seSBhdCBtb3VudC5cbiAgICBpZiAoIXN0b3JlUmVmLmN1cnJlbnQgJiYgc3RvcmVPcGVuRXJyb3JSZWYuY3VycmVudCAhPT0gbnVsbCkge1xuICAgICAgYXBwZW5kKG5vU3RvcmVSb3coc3RvcmVPcGVuRXJyb3JSZWYuY3VycmVudCkpO1xuICAgIH1cbiAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgYXBwZW5kKHsga2luZDogXCJ1c2VyXCIsIHRleHQ6IHByb21wdCB9KTtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGFib3J0UmVmLmN1cnJlbnQgPSBjb250cm9sbGVyO1xuICAgIC8vIFIzLTU1OTogdGhlIGNvbnZlcnNhdGlvbiBtdXN0IGV4aXN0IEJFRk9SRSB0aGUgcnVuIHN0YXJ0cyDigJQgdGhlIGNoZWNrcG9pbnRcbiAgICAvLyBqb3VybmFsIGFwcGVuZHMgaW50byBpdCBmcm9tIHRoZSBmaXJzdCBib3VuZGFyeSAoQjApLCBzbyBhIGZyZXNoIHJ1biBjcmVhdGVzXG4gICAgLy8gaXRzIHJlY29yZCB1cC1mcm9udCByYXRoZXIgdGhhbiBhdCBwZXJzaXN0IHRpbWUuXG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIGlmIChzdG9yZSAmJiAhY29udlJlZi5jdXJyZW50KSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb252UmVmLmN1cnJlbnQgPSBhd2FpdCBzdG9yZS5jcmVhdGUoKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gUi1BUkQtMTA6IGFuIHVuLWNoZWNrcG9pbnRhYmxlIHJ1biBpcyBhbGxvd2VkIHRvIHN0YXJ0LCBhbmQgU0FZUyBTTyDigJRcbiAgICAgICAgLy8gbmV2ZXIgYSBzaWxlbnQgZG93bmdyYWRlIHRvIGVwaGVtZXJhbC4gVGhlIHJ1biBwcm9jZWVkcyBleGFjdGx5IGFzIHRoZVxuICAgICAgICAvLyBwcmUtam91cm5hbCBhZ2VudCBkaWQ7IHRoZSB1c2VyIGlzIHRvbGQgd2hhdCB0aGF0IGNvc3RzLlxuICAgICAgICBhcHBlbmQobm9TdG9yZVJvdyhlKSk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFNhbWUgcnVsZSBmb3IgdGhlIGpvdXJuYWwgdGllcjogam91cm5hbGxlc3MgaXMgYSBkZWdyYWRhdGlvbiB0aGUgdXNlciBjYW5cbiAgICAvLyBzZWUgKHRoZSBjb252ZXJzYXRpb24gc3RpbGwgc2F2ZXMgYXQgcnVuIGVuZDsgdGhlIGNoZWNrcG9pbnQgZmxvb3IgaXMgZ29uZSkuXG4gICAgaWYgKHN0b3JlICYmIGNvbnZSZWYuY3VycmVudCAmJiAhc3RvcmUuaGFzSm91cm5hbCgpKSB7XG4gICAgICBhcHBlbmQoe1xuICAgICAgICBraW5kOiBcImVycm9yXCIsXG4gICAgICAgIHRleHQ6IFwiQ2hlY2twb2ludHMgYXJlIG9mZiAobm8gZGV2aWNlLWxvY2FsIHN0b3JlKSDigJQgY2xvc2luZyB0aGlzIHRhYiBsb3NlcyB0aGUgaW4tZmxpZ2h0IHR1cm47IHRoZSBjb252ZXJzYXRpb24gaXRzZWxmIHN0aWxsIHNhdmVzIHdoZW4gdGhlIHJ1biBlbmRzLlwiLFxuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIFIzLTU2MSAvIFItQVJELTE4OiB0YWtlIHRoZSBhZHZpc29yeSBydW4gbGVhc2UuIFRoaXMgZGVtbyBpcyB0aGUgVEhJUkQgb3BlbmVyXG4gICAgLy8gb2YgdGhlIHNhbWUgc3RvcmUg4oCUIHRoZSBwYW5lbCBhbmQgdGhlIHN0YWdlIGFyZSB0aGUgb3RoZXIgdHdvIOKAlCBhbmQgaXQgYWRvcHRzXG4gICAgLy8gdGhlIE5FV0VTVCBjb252ZXJzYXRpb24gYXQgbW91bnQsIHNvIFwidGhlIGFnZW50cyBhY3Rpdml0eSBhbmQgdGhpcyB0YWIsIHNhbWVcbiAgICAvLyBjb252ZXJzYXRpb25cIiBpcyByZWFjaGFibGUgcmF0aGVyIHRoYW4gdGhlb3JldGljYWwuIFdpdGhvdXQgdGhpcyB0aGUgZmlyc3RcbiAgICAvLyBhcHBlbmQgd291bGQgdGhyb3cgYW5kIHByaW50IGludGVybmFsIGNvcHkgYWJvdXQgYSBsZWFzZSB0aGUgdXNlciBuZXZlciBzYXcuXG4gICAgLy9cbiAgICAvLyBObyB0YWtlb3ZlciBCVVRUT04gaGVyZSwgZGVsaWJlcmF0ZWx5OiB0aGlzIHN1cmZhY2UncyB3aG9sZSBVSSBpcyBhIHByb21wdFxuICAgIC8vIGFuZCBhIFJ1bi9TdG9wIGNvbnRyb2wsIGFuZCBpbnZlbnRpbmcgYW4gYWZmb3JkYW5jZSByb3cgZm9yIGEgZGVtbyB3b3VsZCBiZVxuICAgIC8vIHRoZSBiZXNwb2tlIFVJIHRoZSBydW4tbW9kZSBydWxlIHdhcm5zIGFnYWluc3QuIFItQVJELTE4YSBzdGlsbCBmb3JiaWRzIGFcbiAgICAvLyBERUFEIEVORCwgc28gdGhlIGNvcHkgbmFtZXMgd2hhdCBnZW51aW5lbHkgZnJlZXMgdGhlIGxlYXNlIOKAlCBpdHMgVFRMIOKAlCBhbmRcbiAgICAvLyBub3QgYW4gYWN0aW9uIHRoaXMgY29tcG9uZW50IGRvZXMgbm90IGhhdmUuIChBbiBlYXJsaWVyIHZlcnNpb24gc2FpZCBcInN0YXJ0XG4gICAgLy8gYSBuZXcgY29udmVyc2F0aW9uIGhlcmVcIiwgd2hpY2ggaXMgYW4gaW5zdHJ1Y3Rpb24gdGhlIHVzZXIgY2Fubm90IGZvbGxvdzpcbiAgICAvLyB0aGVyZSBpcyBubyBzdWNoIGNvbnRyb2wsIGFuZCB0aGUgbW91bnQgZWZmZWN0IHJlLWFkb3B0cyB0aGUgbmV3ZXN0XG4gICAgLy8gY29udmVyc2F0aW9uLCBzbyBhIHJlbG9hZCBsYW5kcyBvbiB0aGUgc2FtZSByZWZ1c2FsLilcbiAgICAvL1xuICAgIC8vIFRoZSBSRUZSRVNILCB1bmxpa2UgdGhlIGJ1dHRvbiwgaXMgbm90IG9wdGlvbmFsIGhlcmUg4oCUIHRoaXMgc3VyZmFjZSBydW5zIGFuZFxuICAgIC8vIGFwcGVuZHMgZXhhY3RseSBhcyB0aGUgc3RhZ2UgZG9lcywgc28gaXQgZ2V0cyB0aGUgc2FtZSBgdXNlTGVhc2VSZWZyZXNoYC5cbiAgICBpZiAoc3RvcmUgJiYgY29udlJlZi5jdXJyZW50KSB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoKGF3YWl0IHN0b3JlLmFjcXVpcmVSdW4oY29udlJlZi5jdXJyZW50LmlkKSkgPT09IFwiaGVsZFwiKSB7XG4gICAgICAgICAgYXBwZW5kKHsga2luZDogXCJlcnJvclwiLCB0ZXh0OiBsZWFzZUhlbGRUZXh0KGZhbHNlKSB9KTtcbiAgICAgICAgICBzZXRSdW5uaW5nKGZhbHNlKTtcbiAgICAgICAgICBhYm9ydFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gQSBsZWFzZSB3ZSBjYW5ub3QgcmVhZCBpcyBub3QgYSBsZWFzZSB3ZSBsb3N0LiBTYXkgdGhlIHN0b3JlIGlzIGRlZ3JhZGVkXG4gICAgICAgIC8vIGFuZCBydW4sIHJhdGhlciB0aGFuIHJlZnVzaW5nIG9uIGFuIHVua25vd24uXG4gICAgICAgIGFwcGVuZChub1N0b3JlUm93KGUpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcnVubmluZ0lkUmVmLmN1cnJlbnQgPSBjb252UmVmLmN1cnJlbnQ/LmlkID8/IG51bGw7XG4gICAgY29uc3Qgam91cm5hbENvbnYgPSBzdG9yZT8uaGFzSm91cm5hbCgpID8gY29udlJlZi5jdXJyZW50IDogbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdHJhbnNjcmlwdCA9IGF3YWl0IHJ1bkFnZW50KHtcbiAgICAgICAgY2xpZW50OiBjcmVhdGVDaGF0TW9kZWxDbGllbnQoKSxcbiAgICAgICAgdG9vbHM6IHRvb2xzZXQudG9vbHMsXG4gICAgICAgIGV4ZWN1dGU6IHRvb2xzZXQuZXhlY3V0ZSxcbiAgICAgICAgc3lzdGVtOiBidWlsZFN5c3RlbVByb21wdCh7IHRvb2xzOiB0b29sc2V0LnRvb2xzLCBza2lsbHMsIHdvcmtzcGFjZVJvb3QsIHRvZGF5OiB0b2RheUlzbygpIH0pLFxuICAgICAgICBwcm9tcHQsXG4gICAgICAgIC8vIFIzLTIyNCAowqczLjMpOiB0aGUgc3RvcCBidXR0b24gYWJvcnRzIHRoZSBsb29wIEFORCB0aGUgaW4tZmxpZ2h0IExMTSB0dXJuLlxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAvLyBUb2tlbiBhY2NvdW50aW5nICsgYXV0by1jb21wYWN0aW9uIGxldCB0aGUgbG9vcCBydW4gcGFzdCB+MTIgdHVybnNcbiAgICAgICAgLy8gKFIzLTIyMCk6IHRoZSByZXNvbHZlZCBwcm92aWRlcidzIHdpbmRvdyBkcml2ZXMgd2hlbiB0byBjb21wYWN0LlxuICAgICAgICBjb250ZXh0V2luZG93OiBkZXNjcmliZUNoYXQoKT8uZmVhdHVyZXMubWF4Q29udGV4dFRva2VucyxcbiAgICAgICAgZXZlbnRzOiB7XG4gICAgICAgICAgLy8gUjMtNTU5OiBhcHBlbmQgZXZlcnkgYm91bmRhcnkgdG8gdGhlIGNvbnZlcnNhdGlvbidzIGpvdXJuYWwgKEIyXG4gICAgICAgICAgLy8gaW50ZW50IGlzIGR1cmFibGUgYmVmb3JlIGl0cyBleGVjdXRvciBydW5zIOKAlCBSLUFSRC0xMGEpLiBUaGUgbG9vcFxuICAgICAgICAgIC8vIGF3YWl0cyB0aGlzOyBhIGZhaWxlZCBhcHBlbmQgdW53aW5kcyB0aGUgcnVuIGF0IHRoYXQgYm91bmRhcnkuXG4gICAgICAgICAgLi4uKGpvdXJuYWxDb252XG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICBvbkJvdW5kYXJ5OiBhc3luYyAoYjogTG9vcEJvdW5kYXJ5KSA9PiB7XG4gICAgICAgICAgICAgICAgICBhd2FpdCBzdG9yZSEuYXBwZW5kKGpvdXJuYWxDb252LmlkLCBiKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICBvbkFzc2lzdGFudERlbHRhOiAodGV4dCkgPT4gc2V0U3RyZWFtaW5nKChzKSA9PiBzICsgdGV4dCksXG4gICAgICAgICAgLy8gUjMtMzM1IOKAlCB0aGUgbGl2ZSB0aGlua2luZyBzdXJmYWNlLiBOb3cgdGhhdCBjb21wYWN0aW9uIGxldHMgYSB0YXNrIHJ1biBwYXN0XG4gICAgICAgICAgLy8gYSBkb3plbiB0dXJucywgdGhlIHNpbGVudCBzdHJldGNoZXMgYXJlIGxvbmdlciwgYW5kIFwiaXMgaXQgc3R1Y2sgb3JcbiAgICAgICAgICAvLyB0aGlua2luZz9cIiBoYWQgbm8gYW5zd2VyIG9uIHNjcmVlbi5cbiAgICAgICAgICBvblJlYXNvbmluZ0RlbHRhOiAodGV4dCkgPT4gc2V0VGhpbmtpbmcoKHQpID0+IHQgKyB0ZXh0KSxcbiAgICAgICAgICBvblJlYXNvbmluZzogKGJsb2NrKSA9PiB7XG4gICAgICAgICAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICAgICAgICAgIGFwcGVuZChcbiAgICAgICAgICAgICAgYmxvY2sucmVkYWN0ZWREYXRhICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICA/IHsga2luZDogXCJyZWFzb25pbmdcIiwgdGV4dDogXCJcIiwgcmVkYWN0ZWQ6IHRydWUgfVxuICAgICAgICAgICAgICAgIDogeyBraW5kOiBcInJlYXNvbmluZ1wiLCB0ZXh0OiBibG9jay50ZXh0IH0sXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgb25Bc3Npc3RhbnRUZXh0OiAodGV4dCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRleHQudHJpbSgpKSBhcHBlbmQoeyBraW5kOiBcInRleHRcIiwgdGV4dCB9KTtcbiAgICAgICAgICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uVG9vbFVzZTogKG5hbWUsIGlucHV0KSA9PiBhcHBlbmQoeyBraW5kOiBcInRvb2xcIiwgbmFtZSwgaW5wdXQgfSksXG4gICAgICAgICAgb25Ub29sUmVzdWx0OiAobmFtZSwgcikgPT5cbiAgICAgICAgICAgIGFwcGVuZCh7IGtpbmQ6IFwicmVzdWx0XCIsIG5hbWUsIGNvbnRlbnQ6IHIuY29udGVudCwgaXNFcnJvcjogci5pc0Vycm9yIH0pLFxuICAgICAgICAgIG9uTnVkZ2U6ICgpID0+IGFwcGVuZCh7IGtpbmQ6IFwibnVkZ2VcIiB9KSxcbiAgICAgICAgICBvbkNvbXBhY3Q6ICh7IHN1bW1hcml6ZWRDb3VudCB9KSA9PiB7XG4gICAgICAgICAgICBhcHBlbmQoeyBraW5kOiBcImNvbXBhY3Rpb25cIiwgc3VtbWFyeTogYCR7c3VtbWFyaXplZENvdW50fSBlYXJsaWVyIG1lc3NhZ2VzIHN1bW1hcml6ZWRgIH0pO1xuICAgICAgICAgICAgLy8gUjMtNTU5IChSLUFSRC05KTogZm9sZCBhdCB0aGUgY29tcGFjdGlvbiBib3VuZGFyeSwgYmVzdC1lZmZvcnQg4oCUIHRoZVxuICAgICAgICAgICAgLy8gcnVuLWVuZCBmb2xkIGlzIHRoZSBhdXRob3JpdGF0aXZlIHdyaXRlIChzZWUgQ29udmVyc2F0aW9uU3RhZ2UpLlxuICAgICAgICAgICAgaWYgKGpvdXJuYWxDb252KSB7XG4gICAgICAgICAgICAgIHZvaWQgc3RvcmUhLmZvbGQoam91cm5hbENvbnYuaWQpLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFwibWlkLXJ1biBmb2xkIGF0IGNvbXBhY3Rpb24gZmFpbGVkIChydW4tZW5kIGZvbGQgc3RpbGwgd2lsbClcIiwgZSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IHBlcnNpc3QodHJhbnNjcmlwdCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gUjMtNTYxOiB0aGUgdHdvIGxlYXNlIGNvZGVzIGFyZSBVWCBzdGF0ZXMsIG5vdCBjb2RlcyB0byBwcmludCAowqc5KS4gU2FtZVxuICAgICAgLy8gbWFwcGluZyBhcyB0aGUgc3RhZ2UncyB0d28gY2F0Y2hlcywgYGNhblRha2VPdmVyOiBmYWxzZWAg4oCUIHRoaXMgc3VyZmFjZVxuICAgICAgLy8gaGFzIG5vIGFmZm9yZGFuY2Ugcm93LCBzbyB0aGUgY29weSBuYW1lcyB0aGUgVFRMLCB3aGljaCBhY3R1YWxseSBmcmVlcyB0aGVcbiAgICAgIC8vIGxlYXNlLCByYXRoZXIgdGhhbiBhIGJ1dHRvbiBpdCBkb2VzIG5vdCBzaGlwLlxuICAgICAgY29uc3QgbGVhc2UgPSBsZWFzZUZhaWx1cmUoZSk7XG4gICAgICBhcHBlbmQoXG4gICAgICAgIGxlYXNlXG4gICAgICAgICAgPyB7IGtpbmQ6IFwiZXJyb3JcIiwgdGV4dDogbGVhc2VGYWlsdXJlVGV4dChsZWFzZSwgZmFsc2UpIH1cbiAgICAgICAgICA6IHsga2luZDogXCJlcnJvclwiLCB0ZXh0OiAoZSBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gU3RyaW5nKGUpIH0sXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICAgIHNldFJ1bm5pbmcoZmFsc2UpO1xuICAgICAgYWJvcnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAvLyBSMy01NjE6IGhhbmQgdGhlIGxlYXNlIGJhY2sg4oCUIHRoZSBpZCB0aGUgUlVOIGhlbGQsIHJlYWQgYmVmb3JlIGl0IGlzXG4gICAgICAvLyBjbGVhcmVkLCBub3Qgd2hhdGV2ZXIgaXMgb24gc2NyZWVuLiBGaXJlZCwgbm90IGF3YWl0ZWQ7IHNlZVxuICAgICAgLy8gYHJlbGVhc2VIZWxkTGVhc2VgIGluIENvbnZlcnNhdGlvblN0YWdlIGZvciB0aGUgYXJndW1lbnQuXG4gICAgICB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgaWQgPSBydW5uaW5nSWRSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKHN0b3JlICYmIGlkKSB2b2lkIHN0b3JlLnJlbGVhc2VSdW4oaWQpLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgIH1cbiAgICAgIHJ1bm5pbmdJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gIH07XG5cbiAgLy8gUjMtMjI0ICjCpzMuMyk6IGFib3J0IHRoZSBpbi1mbGlnaHQgcnVuIOKAlCB0aGUgbG9vcCBBTkQgdGhlIHVwc3RyZWFtIExMTSByZXF1ZXN0LlxuICBjb25zdCBzdG9wID0gKCkgPT4gYWJvcnRSZWYuY3VycmVudD8uYWJvcnQoKTtcblxuICAvLyBTYXZlIHRoZSBydW4gaW50byBpdHMgY29udmVyc2F0aW9uIOKAlCBhIEZPTEQgd2hlbiB0aGUgam91cm5hbCB0aWVyIGlzIHdpcmVkXG4gIC8vIChSMy01NTk6IHN0YW1wcyB0aGUgZm9sZCB3YXRlcm1hcmsgKyBjYXJyaWVkIHJ1bi1zdGF0ZSwgcmVjbGFpbXMgdGhlXG4gIC8vIHN1cGVyc2VkZWQgZW50cmllcyksIGEgcGxhaW4gc2F2ZSBvdGhlcndpc2UuIEJlc3QtZWZmb3J0OyBuby1vcCB3aXRob3V0IGEgc3RvcmUuXG4gIGNvbnN0IHBlcnNpc3QgPSBhc3luYyAobWVzc2FnZXM6IENvbnZlcnNhdGlvbltcIm1lc3NhZ2VzXCJdKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIGlmICghc3RvcmUpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udiA9IGNvbnZSZWYuY3VycmVudCA/PyAoYXdhaXQgc3RvcmUuY3JlYXRlKCkpO1xuICAgICAgY29uc3QgdGl0bGUgPSBjb252LnRpdGxlID09PSBcIk5ldyBjb252ZXJzYXRpb25cIiA/IGRlcml2ZVRpdGxlKG1lc3NhZ2VzKSA6IGNvbnYudGl0bGU7XG4gICAgICBjb252UmVmLmN1cnJlbnQgPSBzdG9yZS5oYXNKb3VybmFsKClcbiAgICAgICAgPyBhd2FpdCBzdG9yZS5mb2xkKGNvbnYuaWQsIHsgbWVzc2FnZXMsIHRpdGxlIH0pXG4gICAgICAgIDogYXdhaXQgc3RvcmUuc2F2ZSh7IC4uLmNvbnYsIHRpdGxlLCBtZXNzYWdlcyB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIHBlcnNpc3RlbmNlIGlzIGJlc3QtZWZmb3J0IOKAlCBuZXZlciBicmVhayB0aGUgcnVuIG9uIGEgd3JpdGUgZmFpbHVyZSAqL1xuICAgIH1cbiAgfTtcblxuICAvLyBSMy02MTIgLyBSLUlYLTUg4oCUIGV2ZXJ5IHJ1biBsYW5kcyBpbiBhIGR1cmFibGUgY29udmVyc2F0aW9uLCBzbyB0aGlzIHN1cmZhY2VcbiAgLy8gbXVzdCBvZmZlciBhIGZyZXNoIHN0YXJ0IGFuZCBuYW1lIHdoZXJlIHRoZSBydW5zIGdvLiBUaGUgQ29udmVyc2F0aW9ucyBsaXN0XG4gIC8vIGlzIHdoZXJlIHRoZXkgYWNjdW11bGF0ZSBhbmQgd2hlcmUgb25lIGNhbiBiZSByZW1vdmVkOyB0aGlzIHN1cmZhY2UgbmFtZXNcbiAgLy8gdGhhdCBwbGFjZSByYXRoZXIgdGhhbiBncm93aW5nIGl0cyBvd24gYnJvd3Nlci5cbiAgY29uc3QgbmV3Q29udmVyc2F0aW9uID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBpZiAoIXN0b3JlIHx8IHJ1bm5pbmcpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udiA9IGF3YWl0IHN0b3JlLmNyZWF0ZSgpO1xuICAgICAgY29udlJlZi5jdXJyZW50ID0gY29udjtcbiAgICAgIHNldExvZyhbXSk7XG4gICAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgICBzZXRUaGlua2luZyhcIlwiKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRMb2coKGwpID0+IFtcbiAgICAgICAgLi4ubCxcbiAgICAgICAgeyBraW5kOiBcImVycm9yXCIsIHRleHQ6IGBDb3VsZCBub3Qgc3RhcnQgYSBuZXcgY29udmVyc2F0aW9uICgkeyhlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBTdHJpbmcoZSl9KWAgfSxcbiAgICAgIF0pO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiY2EtaGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtdGl0bGVcIj5Db2RpbmcgYWdlbnQ8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXN1YlwiPnt0b29sc2V0LnRvb2xzLmxlbmd0aH0gdG9vbHMgKGNhdGFsb2cgKyBmaWxlcyArIHByb2plY3QgKyBkaWFnbm9zdGljcyk8L3NwYW4+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNhLW5ld1wiIGRpc2FibGVkPXtydW5uaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIG5ld0NvbnZlcnNhdGlvbigpfT5cbiAgICAgICAgICBOZXcgY29udmVyc2F0aW9uXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EtcHJvbXB0LXJvd1wiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBjbGFzc05hbWU9XCJjYS1wcm9tcHRcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXNrIHRoZSBhZ2VudCB0byByZWFkLCBzZWFyY2gsIG9yIGVkaXQgeW91ciBhcHDigKZcIlxuICAgICAgICAgIHZhbHVlPXtwcm9tcHR9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9tcHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB2b2lkIHJ1bigpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgYXJpYS1sYWJlbD1cIlByb21wdFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJjYS1ydW5cIlxuICAgICAgICAgIC8vIFdoaWxlIHJ1bm5pbmcsIHRoaXMgaXMgYSBsaXZlIFN0b3AgY29udHJvbCAoUjMtMjI0KSDigJQgYWJvcnQgdGhlIGluLWZsaWdodCB0dXJuLlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IChydW5uaW5nID8gc3RvcCgpIDogdm9pZCBydW4oKSl9XG4gICAgICAgID5cbiAgICAgICAgICB7cnVubmluZyA/IFwiU3RvcFwiIDogXCJSdW5cIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIGFyaWEtbGl2ZSBtYXRjaGVzIHRoZSBjb252ZXJzYXRpb24gc3RhZ2UncyB0cmFuc2NyaXB0IChDb252ZXJzYXRpb25TdGFnZSksXG4gICAgICAgICAgIHNvIHNjcmVlbiByZWFkZXJzIGhlYXIgdHVybnMgbGFuZCBoZXJlIHRvby4gKi99XG4gICAgICA8dWwgY2xhc3NOYW1lPVwiY2EtbG9nXCIgYXJpYS1saXZlPVwicG9saXRlXCI+XG4gICAgICAgIHsvKiBSMy02MTIgLyBSLUlYLTUg4oCUIHRoZSBlbXB0eSBzdGF0ZSBuYW1lcyB3aGVyZSBydW5zIGFyZSBrZXB0OiB0aGlzXG4gICAgICAgICAgICBzdXJmYWNlIHBlcnNpc3RzIHNpbGVudGx5IG90aGVyd2lzZSwgYW5kIHRoZSBsaXN0ICh3aGljaCByZW1vdmVzKVxuICAgICAgICAgICAgaXMgdGhlIG9ubHkgcGxhY2UgdGhhdCBzaG93cyB0aGUgYWNjdW11bGF0aW9uLiAqL31cbiAgICAgICAgeyFsb2cubGVuZ3RoICYmICF0aGlua2luZyAmJiAhc3RyZWFtaW5nICYmIChcbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiY2EtbGluZSBjYS1lbXB0eVwiPlJ1bnMgYXJlIHNhdmVkIHRvIHlvdXIgQ29udmVyc2F0aW9ucyBsaXN0LjwvbGk+XG4gICAgICAgICl9XG4gICAgICAgIHsvKiBGb2xkZWQgdG9vbCBjYWxscyArIG1hcmtkb3duIHJlcGxpZXMgKFIzLTQ3My9SMy00NzQpIOKAlCBzaGFyZWQgd2l0aCB0aGVcbiAgICAgICAgICAgIGNvbnZlcnNhdGlvbiBzdGFnZSBzbyBib3RoIHRyYW5zY3JpcHRzIHJlYWQgaWRlbnRpY2FsbHkuICovfVxuICAgICAgICA8VHJhbnNjcmlwdFJvd3MgbG9nPXtsb2d9IC8+XG4gICAgICAgIHt0aGlua2luZyAmJiAoXG4gICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImNhLWxpbmUgY2EtbGl2ZVwiPlxuICAgICAgICAgICAgey8qIE9wZW4gd2hpbGUgaXQgc3RyZWFtcyDigJQgdGhlIHBvaW50IGlzIHRvIFNIT1cgdGhhdCB3b3JrIGlzIGhhcHBlbmluZyDigJRcbiAgICAgICAgICAgICAgICB0aGVuIGNvbGxhcHNlZCBvbmNlIGl0IGJlY29tZXMgYSB0cmFuc2NyaXB0IHJvdy4gKi99XG4gICAgICAgICAgICA8ZGV0YWlscyBjbGFzc05hbWU9XCJjYS1yZWFzb25pbmdcIiBvcGVuPlxuICAgICAgICAgICAgICA8c3VtbWFyeT50aGlua2luZ+KApjwvc3VtbWFyeT5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtcmVhc29uaW5nLWJvZHlcIj57dGhpbmtpbmd9PC9zcGFuPlxuICAgICAgICAgICAgPC9kZXRhaWxzPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICl9XG4gICAgICAgIHtzdHJlYW1pbmcgJiYgKFxuICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJjYS1saW5lIGNhLXRleHQgY2EtbGl2ZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtdGV4dFwiPntzdHJlYW1pbmd9PC9zcGFuPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICl9XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFZQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxRQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxhQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxpQkFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sU0FBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8sWUFBQSxHQUFBUCxPQUFBO0FBQ0EsSUFBQVEsT0FBQSxHQUFBUixPQUFBO0FBQ0EsSUFBQVMsZ0JBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLFVBQUEsR0FBQVYsT0FBQTtBQUNBLElBQUFXLGtCQUFBLEdBQUFYLE9BQUE7QUFFQSxJQUFBWSxXQUFBLEdBQUFaLE9BQUE7QUFDQSxJQUFBYSxlQUFBLEdBQUFDLHNCQUFBLENBQUFkLE9BQUE7QUFDQSxJQUFBZSxXQUFBLEdBQUFmLE9BQUE7QUFDQSxJQUFBZ0IsZ0JBQUEsR0FBQWhCLE9BQUE7QUFDQUEsT0FBQTtBQUEyQixJQUFBaUIsV0FBQSxHQUFBakIsT0FBQTtBQUFBLElBQUFrQixFQUFBLEdBQUFDLFlBQUEsSUE3QjNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQW9CQTtBQUNBO0FBQ0E7QUFGQSxTQUFBTCx1QkFBQU0sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUdBLE1BQU1HLFVBQVUsR0FBSUgsQ0FBVSxLQUFnQjtFQUM1Q0ksSUFBSSxFQUFFLE9BQU87RUFDYkMsSUFBSSxFQUFFLDRCQUE2QkwsQ0FBQyxFQUFZTSxPQUFPLElBQUlDLE1BQU0sQ0FBQ1AsQ0FBQyxDQUFDO0FBQ3RFLENBQUMsQ0FBQztBQUVhLFNBQVNRLFdBQVdBLENBQUEsRUFBRztFQUFBVixFQUFBO0VBQ3BDLE1BQU1XLE9BQU8sR0FBRyxJQUFBQyxlQUFVLEVBQUMsQ0FBQztFQUM1QixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUM7RUFDMUIsTUFBTSxDQUFDQyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDeEMsTUFBTSxDQUFDQyxHQUFHLEVBQUVDLE1BQU0sQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBYSxFQUFFLENBQUM7RUFDOUMsTUFBTSxDQUFDRyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDOUM7RUFDQTtFQUNBLE1BQU0sQ0FBQ0ssUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBTixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQzVDLE1BQU0sQ0FBQ08sT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBUixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDO0FBQ0Y7RUFDRSxNQUFNUyxZQUFZLEdBQUcsSUFBQUMsYUFBTSxFQUFnQixJQUFJLENBQUM7O0VBRWhEO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFFBQVEsR0FBRyxJQUFBRCxhQUFNLEVBQTJCLElBQUksQ0FBQztFQUN2RCxNQUFNRSxPQUFPLEdBQUcsSUFBQUYsYUFBTSxFQUFzQixJQUFJLENBQUM7RUFDakQ7RUFDQTtFQUNBLE1BQU1HLGlCQUFpQixHQUFHLElBQUFILGFBQU0sRUFBVSxJQUFJLENBQUM7RUFDL0M7RUFDQSxNQUFNSSxRQUFRLEdBQUcsSUFBQUosYUFBTSxFQUF5QixJQUFJLENBQUM7RUFDckQsSUFBQUssZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUMsSUFBSSxHQUFHLElBQUk7SUFDZixLQUFLLENBQUMsWUFBWTtNQUNoQixJQUFJO1FBQ0YsTUFBTUMsS0FBSyxHQUFHLE1BQU0sSUFBQUMsd0NBQXFCLEVBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUNGLElBQUksRUFBRTtRQUNYTCxRQUFRLENBQUNRLE9BQU8sR0FBR0YsS0FBSztRQUN4QixNQUFNLENBQUNHLE1BQU0sQ0FBQyxHQUFHLE1BQU1ILEtBQUssQ0FBQ0ksSUFBSSxDQUFDLENBQUM7UUFDbkMsTUFBTUMsSUFBSSxHQUFHRixNQUFNLEdBQUcsTUFBTUgsS0FBSyxDQUFDTSxJQUFJLENBQUNILE1BQU0sQ0FBQ0ksRUFBRSxDQUFDLEdBQUcsTUFBTVAsS0FBSyxDQUFDUSxNQUFNLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUNULElBQUksSUFBSSxDQUFDTSxJQUFJLEVBQUU7UUFDcEJWLE9BQU8sQ0FBQ08sT0FBTyxHQUFHRyxJQUFJO1FBQ3RCLElBQUlBLElBQUksQ0FBQ0ksUUFBUSxDQUFDQyxNQUFNLEVBQUV6QixNQUFNLENBQUMsSUFBQTBCLHlCQUFhLEVBQUNOLElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUM7TUFDaEUsQ0FBQyxDQUFDLE9BQU96QyxDQUFDLEVBQUU7UUFDVjtRQUNBO1FBQ0EsSUFBSStCLElBQUksRUFBRTtVQUNSSCxpQkFBaUIsQ0FBQ00sT0FBTyxHQUFHbEMsQ0FBQztVQUM3QmlCLE1BQU0sQ0FBRTJCLENBQUMsSUFBSyxDQUFDLEdBQUdBLENBQUMsRUFBRXpDLFVBQVUsQ0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QztNQUNGO0lBQ0YsQ0FBQyxFQUFFLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWCtCLElBQUksR0FBRyxLQUFLO0lBQ2QsQ0FBQztFQUNILENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNYyxNQUFNLEdBQUcsSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsaUJBQVksRUFBQyxDQUFDLEVBQUVDLFFBQVEsQ0FBQ0gsTUFBTSxLQUFLLElBQUksRUFBRSxFQUFFLENBQUM7O0VBRTFFO0VBQ0E7RUFDQSxNQUFNO0lBQUVJLE9BQU87SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQUosY0FBTyxFQUFDLE1BQU07SUFDeEMsTUFBTTtNQUFFSyxJQUFJO01BQUVDO0lBQVMsQ0FBQyxHQUFHLElBQUFDLGdDQUF1QixFQUFDMUMsTUFBTSxFQUFFLElBQUEyQyxvQkFBZSxFQUFDLENBQUMsQ0FBQztJQUM3RSxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsd0JBQWUsRUFBQztNQUFFTCxJQUFJO01BQUVDLFFBQVE7TUFBRVA7SUFBTyxDQUFDLENBQUM7SUFDM0QsTUFBTVksWUFBWSxHQUFHLElBQUFDLGtDQUFvQixFQUFDO01BQUVQLElBQUk7TUFBRUM7SUFBUyxDQUFDLENBQUM7SUFDN0QsTUFBTU8sZ0JBQWdCLEdBQUcsSUFBQUMsMENBQXdCLEVBQUMsQ0FBQztJQUNuRDtJQUNBO0lBQ0EsTUFBTUMsUUFBUSxHQUFHLElBQUFDLDBCQUFnQixFQUFDO01BQUVyRDtJQUFRLENBQUMsQ0FBQztJQUM5QztJQUNBO0lBQ0EsT0FBTyxJQUFBc0Qsa0JBQVUsRUFBQyxJQUFBQyxzQkFBYSxFQUFDLElBQUFDLHVCQUFjLEVBQUN4RCxPQUFPLENBQUMsRUFBRThDLE9BQU8sRUFBRUUsWUFBWSxFQUFFRSxnQkFBZ0IsRUFBRUUsUUFBUSxDQUFDLENBQUM7RUFDOUcsQ0FBQyxFQUFFLENBQUNwRCxPQUFPLEVBQUVFLE1BQU0sRUFBRWtDLE1BQU0sQ0FBQyxDQUFDOztFQUU3QjtFQUNBLE1BQU1xQixhQUFhLEdBQUcsSUFBQXBCLGNBQU8sRUFDM0IsTUFBTSxJQUFBTyxnQ0FBdUIsRUFBQzFDLE1BQU0sRUFBRSxJQUFBMkMsb0JBQWUsRUFBQyxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxFQUM3RCxDQUFDeEMsTUFBTSxDQUNULENBQUM7RUFFRCxNQUFNd0QsTUFBTSxHQUFJbkUsQ0FBVyxJQUFLaUIsTUFBTSxDQUFFMkIsQ0FBQyxJQUFLLENBQUMsR0FBR0EsQ0FBQyxFQUFFNUMsQ0FBQyxDQUFDLENBQUM7O0VBRXhEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBb0UsZ0NBQWUsRUFBQzFDLFFBQVEsRUFBRUYsWUFBWSxFQUFFRixPQUFPLENBQUM7RUFFaEQsTUFBTStDLEdBQUcsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDdEIsSUFBSSxDQUFDeEQsTUFBTSxDQUFDeUQsSUFBSSxDQUFDLENBQUMsSUFBSWhELE9BQU8sRUFBRTtJQUMvQkMsVUFBVSxDQUFDLElBQUksQ0FBQztJQUNoQk4sTUFBTSxDQUFDLEVBQUUsQ0FBQztJQUNWO0lBQ0E7SUFDQSxJQUFJLENBQUNTLFFBQVEsQ0FBQ1EsT0FBTyxJQUFJTixpQkFBaUIsQ0FBQ00sT0FBTyxLQUFLLElBQUksRUFBRTtNQUMzRGlDLE1BQU0sQ0FBQ2hFLFVBQVUsQ0FBQ3lCLGlCQUFpQixDQUFDTSxPQUFPLENBQUMsQ0FBQztJQUMvQztJQUNBZixZQUFZLENBQUMsRUFBRSxDQUFDO0lBQ2hCRSxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQ2Y4QyxNQUFNLENBQUM7TUFBRS9ELElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRVE7SUFBTyxDQUFDLENBQUM7SUFDdEMsTUFBTTBELFVBQVUsR0FBRyxJQUFJQyxlQUFlLENBQUMsQ0FBQztJQUN4QzNDLFFBQVEsQ0FBQ0ssT0FBTyxHQUFHcUMsVUFBVTtJQUM3QjtJQUNBO0lBQ0E7SUFDQSxNQUFNdkMsS0FBSyxHQUFHTixRQUFRLENBQUNRLE9BQU87SUFDOUIsSUFBSUYsS0FBSyxJQUFJLENBQUNMLE9BQU8sQ0FBQ08sT0FBTyxFQUFFO01BQzdCLElBQUk7UUFDRlAsT0FBTyxDQUFDTyxPQUFPLEdBQUcsTUFBTUYsS0FBSyxDQUFDUSxNQUFNLENBQUMsQ0FBQztNQUN4QyxDQUFDLENBQUMsT0FBT3hDLENBQUMsRUFBRTtRQUNWO1FBQ0E7UUFDQTtRQUNBbUUsTUFBTSxDQUFDaEUsVUFBVSxDQUFDSCxDQUFDLENBQUMsQ0FBQztNQUN2QjtJQUNGO0lBQ0E7SUFDQTtJQUNBLElBQUlnQyxLQUFLLElBQUlMLE9BQU8sQ0FBQ08sT0FBTyxJQUFJLENBQUNGLEtBQUssQ0FBQ3lDLFVBQVUsQ0FBQyxDQUFDLEVBQUU7TUFDbkROLE1BQU0sQ0FBQztRQUNML0QsSUFBSSxFQUFFLE9BQU87UUFDYkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSTJCLEtBQUssSUFBSUwsT0FBTyxDQUFDTyxPQUFPLEVBQUU7TUFDNUIsSUFBSTtRQUNGLElBQUksQ0FBQyxNQUFNRixLQUFLLENBQUMwQyxVQUFVLENBQUMvQyxPQUFPLENBQUNPLE9BQU8sQ0FBQ0ssRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO1VBQzNENEIsTUFBTSxDQUFDO1lBQUUvRCxJQUFJLEVBQUUsT0FBTztZQUFFQyxJQUFJLEVBQUUsSUFBQXNFLHlCQUFhLEVBQUMsS0FBSztVQUFFLENBQUMsQ0FBQztVQUNyRHBELFVBQVUsQ0FBQyxLQUFLLENBQUM7VUFDakJNLFFBQVEsQ0FBQ0ssT0FBTyxHQUFHLElBQUk7VUFDdkI7UUFDRjtNQUNGLENBQUMsQ0FBQyxPQUFPbEMsQ0FBQyxFQUFFO1FBQ1Y7UUFDQTtRQUNBbUUsTUFBTSxDQUFDaEUsVUFBVSxDQUFDSCxDQUFDLENBQUMsQ0FBQztNQUN2QjtJQUNGO0lBQ0F3QixZQUFZLENBQUNVLE9BQU8sR0FBR1AsT0FBTyxDQUFDTyxPQUFPLEVBQUVLLEVBQUUsSUFBSSxJQUFJO0lBQ2xELE1BQU1xQyxXQUFXLEdBQUc1QyxLQUFLLEVBQUV5QyxVQUFVLENBQUMsQ0FBQyxHQUFHOUMsT0FBTyxDQUFDTyxPQUFPLEdBQUcsSUFBSTtJQUNoRSxJQUFJO01BQ0YsTUFBTTJDLFVBQVUsR0FBRyxNQUFNLElBQUFDLG1CQUFRLEVBQUM7UUFDaENDLE1BQU0sRUFBRSxJQUFBQyxzQ0FBcUIsRUFBQyxDQUFDO1FBQy9CQyxLQUFLLEVBQUVoQyxPQUFPLENBQUNnQyxLQUFLO1FBQ3BCQyxPQUFPLEVBQUVqQyxPQUFPLENBQUNpQyxPQUFPO1FBQ3hCQyxNQUFNLEVBQUUsSUFBQUMsOEJBQWlCLEVBQUM7VUFBRUgsS0FBSyxFQUFFaEMsT0FBTyxDQUFDZ0MsS0FBSztVQUFFL0IsTUFBTTtVQUFFZ0IsYUFBYTtVQUFFbUIsS0FBSyxFQUFFLElBQUFDLHFCQUFRLEVBQUM7UUFBRSxDQUFDLENBQUM7UUFDN0Z6RSxNQUFNO1FBQ047UUFDQTBFLE1BQU0sRUFBRWhCLFVBQVUsQ0FBQ2dCLE1BQU07UUFDekI7UUFDQTtRQUNBQyxhQUFhLEVBQUUsSUFBQXpDLGlCQUFZLEVBQUMsQ0FBQyxFQUFFQyxRQUFRLENBQUN5QyxnQkFBZ0I7UUFDeERDLE1BQU0sRUFBRTtVQUNOO1VBQ0E7VUFDQTtVQUNBLElBQUlkLFdBQVcsR0FDWDtZQUNFZSxVQUFVLEVBQUUsTUFBT0MsQ0FBZSxJQUFLO2NBQ3JDLE1BQU01RCxLQUFLLENBQUVtQyxNQUFNLENBQUNTLFdBQVcsQ0FBQ3JDLEVBQUUsRUFBRXFELENBQUMsQ0FBQztZQUN4QztVQUNGLENBQUMsR0FDRCxDQUFDLENBQUMsQ0FBQztVQUNQQyxnQkFBZ0IsRUFBR3hGLElBQUksSUFBS2MsWUFBWSxDQUFFMkUsQ0FBQyxJQUFLQSxDQUFDLEdBQUd6RixJQUFJLENBQUM7VUFDekQ7VUFDQTtVQUNBO1VBQ0EwRixnQkFBZ0IsRUFBRzFGLElBQUksSUFBS2dCLFdBQVcsQ0FBRTJFLENBQUMsSUFBS0EsQ0FBQyxHQUFHM0YsSUFBSSxDQUFDO1VBQ3hENEYsV0FBVyxFQUFHQyxLQUFLLElBQUs7WUFDdEI3RSxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQ2Y4QyxNQUFNLENBQ0orQixLQUFLLENBQUNDLFlBQVksS0FBS0MsU0FBUyxHQUM1QjtjQUFFaEcsSUFBSSxFQUFFLFdBQVc7Y0FBRUMsSUFBSSxFQUFFLEVBQUU7Y0FBRWdHLFFBQVEsRUFBRTtZQUFLLENBQUMsR0FDL0M7Y0FBRWpHLElBQUksRUFBRSxXQUFXO2NBQUVDLElBQUksRUFBRTZGLEtBQUssQ0FBQzdGO1lBQUssQ0FDNUMsQ0FBQztVQUNILENBQUM7VUFDRGlHLGVBQWUsRUFBR2pHLElBQUksSUFBSztZQUN6QixJQUFJQSxJQUFJLENBQUNpRSxJQUFJLENBQUMsQ0FBQyxFQUFFSCxNQUFNLENBQUM7Y0FBRS9ELElBQUksRUFBRSxNQUFNO2NBQUVDO1lBQUssQ0FBQyxDQUFDO1lBQy9DYyxZQUFZLENBQUMsRUFBRSxDQUFDO1VBQ2xCLENBQUM7VUFDRG9GLFNBQVMsRUFBRUEsQ0FBQ0MsSUFBSSxFQUFFQyxLQUFLLEtBQUt0QyxNQUFNLENBQUM7WUFBRS9ELElBQUksRUFBRSxNQUFNO1lBQUVvRyxJQUFJO1lBQUVDO1VBQU0sQ0FBQyxDQUFDO1VBQ2pFQyxZQUFZLEVBQUVBLENBQUNGLElBQUksRUFBRUcsQ0FBQyxLQUNwQnhDLE1BQU0sQ0FBQztZQUFFL0QsSUFBSSxFQUFFLFFBQVE7WUFBRW9HLElBQUk7WUFBRUksT0FBTyxFQUFFRCxDQUFDLENBQUNDLE9BQU87WUFBRUMsT0FBTyxFQUFFRixDQUFDLENBQUNFO1VBQVEsQ0FBQyxDQUFDO1VBQzFFQyxPQUFPLEVBQUVBLENBQUEsS0FBTTNDLE1BQU0sQ0FBQztZQUFFL0QsSUFBSSxFQUFFO1VBQVEsQ0FBQyxDQUFDO1VBQ3hDMkcsU0FBUyxFQUFFQSxDQUFDO1lBQUVDO1VBQWdCLENBQUMsS0FBSztZQUNsQzdDLE1BQU0sQ0FBQztjQUFFL0QsSUFBSSxFQUFFLFlBQVk7Y0FBRTZHLE9BQU8sRUFBRSxHQUFHRCxlQUFlO1lBQStCLENBQUMsQ0FBQztZQUN6RjtZQUNBO1lBQ0EsSUFBSXBDLFdBQVcsRUFBRTtjQUNmLEtBQUs1QyxLQUFLLENBQUVrRixJQUFJLENBQUN0QyxXQUFXLENBQUNyQyxFQUFFLENBQUMsQ0FBQzRFLEtBQUssQ0FBRW5ILENBQUMsSUFBSztnQkFDNUNvSCxPQUFPLENBQUNDLElBQUksQ0FBQyw2REFBNkQsRUFBRXJILENBQUMsQ0FBQztjQUNoRixDQUFDLENBQUM7WUFDSjtVQUNGO1FBQ0Y7TUFDRixDQUFDLENBQUM7TUFDRixNQUFNc0gsT0FBTyxDQUFDekMsVUFBVSxDQUFDO0lBQzNCLENBQUMsQ0FBQyxPQUFPN0UsQ0FBQyxFQUFFO01BQ1Y7TUFDQTtNQUNBO01BQ0E7TUFDQSxNQUFNdUgsS0FBSyxHQUFHLElBQUFDLHdCQUFZLEVBQUN4SCxDQUFDLENBQUM7TUFDN0JtRSxNQUFNLENBQ0pvRCxLQUFLLEdBQ0Q7UUFBRW5ILElBQUksRUFBRSxPQUFPO1FBQUVDLElBQUksRUFBRSxJQUFBb0gsNEJBQWdCLEVBQUNGLEtBQUssRUFBRSxLQUFLO01BQUUsQ0FBQyxHQUN2RDtRQUFFbkgsSUFBSSxFQUFFLE9BQU87UUFBRUMsSUFBSSxFQUFHTCxDQUFDLEVBQVlNLE9BQU8sSUFBSUMsTUFBTSxDQUFDUCxDQUFDO01BQUUsQ0FDaEUsQ0FBQztJQUNILENBQUMsU0FBUztNQUNSbUIsWUFBWSxDQUFDLEVBQUUsQ0FBQztNQUNoQkUsV0FBVyxDQUFDLEVBQUUsQ0FBQztNQUNmRSxVQUFVLENBQUMsS0FBSyxDQUFDO01BQ2pCTSxRQUFRLENBQUNLLE9BQU8sR0FBRyxJQUFJO01BQ3ZCO01BQ0E7TUFDQTtNQUNBO1FBQ0UsTUFBTUYsS0FBSyxHQUFHTixRQUFRLENBQUNRLE9BQU87UUFDOUIsTUFBTUssRUFBRSxHQUFHZixZQUFZLENBQUNVLE9BQU87UUFDL0IsSUFBSUYsS0FBSyxJQUFJTyxFQUFFLEVBQUUsS0FBS1AsS0FBSyxDQUFDMEYsVUFBVSxDQUFDbkYsRUFBRSxDQUFDLENBQUM0RSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztNQUM1RDtNQUNBM0YsWUFBWSxDQUFDVSxPQUFPLEdBQUcsSUFBSTtJQUM3QjtFQUNGLENBQUM7O0VBRUQ7RUFDQSxNQUFNeUYsSUFBSSxHQUFHQSxDQUFBLEtBQU05RixRQUFRLENBQUNLLE9BQU8sRUFBRTBGLEtBQUssQ0FBQyxDQUFDOztFQUU1QztFQUNBO0VBQ0E7RUFDQSxNQUFNTixPQUFPLEdBQUcsTUFBTzdFLFFBQWtDLElBQUs7SUFDNUQsTUFBTVQsS0FBSyxHQUFHTixRQUFRLENBQUNRLE9BQU87SUFDOUIsSUFBSSxDQUFDRixLQUFLLEVBQUU7SUFDWixJQUFJO01BQ0YsTUFBTUssSUFBSSxHQUFHVixPQUFPLENBQUNPLE9BQU8sS0FBSyxNQUFNRixLQUFLLENBQUNRLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDdEQsTUFBTXFGLEtBQUssR0FBR3hGLElBQUksQ0FBQ3dGLEtBQUssS0FBSyxrQkFBa0IsR0FBRyxJQUFBQyw4QkFBVyxFQUFDckYsUUFBUSxDQUFDLEdBQUdKLElBQUksQ0FBQ3dGLEtBQUs7TUFDcEZsRyxPQUFPLENBQUNPLE9BQU8sR0FBR0YsS0FBSyxDQUFDeUMsVUFBVSxDQUFDLENBQUMsR0FDaEMsTUFBTXpDLEtBQUssQ0FBQ2tGLElBQUksQ0FBQzdFLElBQUksQ0FBQ0UsRUFBRSxFQUFFO1FBQUVFLFFBQVE7UUFBRW9GO01BQU0sQ0FBQyxDQUFDLEdBQzlDLE1BQU03RixLQUFLLENBQUMrRixJQUFJLENBQUM7UUFBRSxHQUFHMUYsSUFBSTtRQUFFd0YsS0FBSztRQUFFcEY7TUFBUyxDQUFDLENBQUM7SUFDcEQsQ0FBQyxDQUFDLE1BQU07TUFDTjtJQUFBO0VBRUosQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU11RixlQUFlLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQ2xDLE1BQU1oRyxLQUFLLEdBQUdOLFFBQVEsQ0FBQ1EsT0FBTztJQUM5QixJQUFJLENBQUNGLEtBQUssSUFBSVYsT0FBTyxFQUFFO0lBQ3ZCLElBQUk7TUFDRixNQUFNZSxJQUFJLEdBQUcsTUFBTUwsS0FBSyxDQUFDUSxNQUFNLENBQUMsQ0FBQztNQUNqQ2IsT0FBTyxDQUFDTyxPQUFPLEdBQUdHLElBQUk7TUFDdEJwQixNQUFNLENBQUMsRUFBRSxDQUFDO01BQ1ZFLFlBQVksQ0FBQyxFQUFFLENBQUM7TUFDaEJFLFdBQVcsQ0FBQyxFQUFFLENBQUM7SUFDakIsQ0FBQyxDQUFDLE9BQU9yQixDQUFDLEVBQUU7TUFDVmlCLE1BQU0sQ0FBRTJCLENBQUMsSUFBSyxDQUNaLEdBQUdBLENBQUMsRUFDSjtRQUFFeEMsSUFBSSxFQUFFLE9BQU87UUFBRUMsSUFBSSxFQUFFLHVDQUF3Q0wsQ0FBQyxFQUFZTSxPQUFPLElBQUlDLE1BQU0sQ0FBQ1AsQ0FBQyxDQUFDO01BQUksQ0FBQyxDQUN0RyxDQUFDO0lBQ0o7RUFDRixDQUFDO0VBRUQsb0JBQ0UsSUFBQUgsV0FBQSxDQUFBb0ksSUFBQTtJQUFLQyxTQUFTLEVBQUMsSUFBSTtJQUFBQyxRQUFBLGdCQUNqQixJQUFBdEksV0FBQSxDQUFBb0ksSUFBQTtNQUFRQyxTQUFTLEVBQUMsT0FBTztNQUFBQyxRQUFBLGdCQUN2QixJQUFBdEksV0FBQSxDQUFBdUksR0FBQTtRQUFNRixTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLEVBQUM7TUFBWSxDQUFNLENBQUMsZUFDOUMsSUFBQXRJLFdBQUEsQ0FBQW9JLElBQUE7UUFBTUMsU0FBUyxFQUFDLFFBQVE7UUFBQUMsUUFBQSxHQUFFbEYsT0FBTyxDQUFDZ0MsS0FBSyxDQUFDdkMsTUFBTSxFQUFDLGtEQUFnRDtNQUFBLENBQU0sQ0FBQyxlQUN0RyxJQUFBN0MsV0FBQSxDQUFBdUksR0FBQTtRQUFRQyxJQUFJLEVBQUMsUUFBUTtRQUFDSCxTQUFTLEVBQUMsUUFBUTtRQUFDSSxRQUFRLEVBQUVoSCxPQUFRO1FBQUNpSCxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLUCxlQUFlLENBQUMsQ0FBRTtRQUFBRyxRQUFBLEVBQUM7TUFFbkcsQ0FBUSxDQUFDO0lBQUEsQ0FDSCxDQUFDLGVBRVQsSUFBQXRJLFdBQUEsQ0FBQW9JLElBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQUMsUUFBQSxnQkFDNUIsSUFBQXRJLFdBQUEsQ0FBQXVJLEdBQUE7UUFDRUYsU0FBUyxFQUFDLFdBQVc7UUFDckJNLFdBQVcsRUFBQyx1REFBa0Q7UUFDOURDLEtBQUssRUFBRTVILE1BQU87UUFDZDZILFFBQVEsRUFBRzFJLENBQUMsSUFBS2MsU0FBUyxDQUFDZCxDQUFDLENBQUMySSxNQUFNLENBQUNGLEtBQUssQ0FBRTtRQUMzQ0csU0FBUyxFQUFHNUksQ0FBQyxJQUFLO1VBQ2hCLElBQUlBLENBQUMsQ0FBQzZJLEdBQUcsS0FBSyxPQUFPLEVBQUUsS0FBS3hFLEdBQUcsQ0FBQyxDQUFDO1FBQ25DLENBQUU7UUFDRixjQUFXO01BQVEsQ0FDcEIsQ0FBQyxlQUNGLElBQUF4RSxXQUFBLENBQUF1SSxHQUFBO1FBQ0VDLElBQUksRUFBQyxRQUFRO1FBQ2JILFNBQVMsRUFBQztRQUNWO1FBQUE7UUFDQUssT0FBTyxFQUFFQSxDQUFBLEtBQU9qSCxPQUFPLEdBQUdxRyxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUt0RCxHQUFHLENBQUMsQ0FBRztRQUFBOEQsUUFBQSxFQUU5QzdHLE9BQU8sR0FBRyxNQUFNLEdBQUc7TUFBSyxDQUNuQixDQUFDO0lBQUEsQ0FDTixDQUFDLGVBSU4sSUFBQXpCLFdBQUEsQ0FBQW9JLElBQUE7TUFBSUMsU0FBUyxFQUFDLFFBQVE7TUFBQyxhQUFVLFFBQVE7TUFBQUMsUUFBQSxHQUl0QyxDQUFDbkgsR0FBRyxDQUFDMEIsTUFBTSxJQUFJLENBQUN0QixRQUFRLElBQUksQ0FBQ0YsU0FBUyxpQkFDckMsSUFBQXJCLFdBQUEsQ0FBQXVJLEdBQUE7UUFBSUYsU0FBUyxFQUFDLGtCQUFrQjtRQUFBQyxRQUFBLEVBQUM7TUFBMEMsQ0FBSSxDQUNoRixlQUdELElBQUF0SSxXQUFBLENBQUF1SSxHQUFBLEVBQUMzSSxlQUFBLENBQUFTLE9BQWM7UUFBQ2MsR0FBRyxFQUFFQTtNQUFJLENBQUUsQ0FBQyxFQUMzQkksUUFBUSxpQkFDUCxJQUFBdkIsV0FBQSxDQUFBdUksR0FBQTtRQUFJRixTQUFTLEVBQUMsaUJBQWlCO1FBQUFDLFFBQUEsZUFHN0IsSUFBQXRJLFdBQUEsQ0FBQW9JLElBQUE7VUFBU0MsU0FBUyxFQUFDLGNBQWM7VUFBQ1ksSUFBSTtVQUFBWCxRQUFBLGdCQUNwQyxJQUFBdEksV0FBQSxDQUFBdUksR0FBQTtZQUFBRCxRQUFBLEVBQVM7VUFBUyxDQUFTLENBQUMsZUFDNUIsSUFBQXRJLFdBQUEsQ0FBQXVJLEdBQUE7WUFBTUYsU0FBUyxFQUFDLG1CQUFtQjtZQUFBQyxRQUFBLEVBQUUvRztVQUFRLENBQU8sQ0FBQztRQUFBLENBQzlDO01BQUMsQ0FDUixDQUNMLEVBQ0FGLFNBQVMsaUJBQ1IsSUFBQXJCLFdBQUEsQ0FBQXVJLEdBQUE7UUFBSUYsU0FBUyxFQUFDLHlCQUF5QjtRQUFBQyxRQUFBLGVBQ3JDLElBQUF0SSxXQUFBLENBQUF1SSxHQUFBO1VBQU1GLFNBQVMsRUFBQyxTQUFTO1VBQUFDLFFBQUEsRUFBRWpIO1FBQVMsQ0FBTztNQUFDLENBQzFDLENBQ0w7SUFBQSxDQUNDLENBQUM7RUFBQSxDQUNGLENBQUM7QUFFVjtBQUFDcEIsRUFBQSxDQXpWdUJVLFdBQVc7RUFBQSxRQUNqQkUsZUFBVSxFQUNYRSxjQUFTLEVBcUZ4QndELGdDQUFlO0FBQUE7QUFBQTJFLEVBQUEsR0F2Rk92SSxXQUFXO0FBQUEsSUFBQXVJLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}