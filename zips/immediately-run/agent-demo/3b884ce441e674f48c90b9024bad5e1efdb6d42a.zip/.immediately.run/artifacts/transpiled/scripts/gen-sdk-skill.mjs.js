var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _nodeFs = require("node:fs");
var _nodeUrl = require("node:url");
var _nodePath = require("node:path");
// Generate the SDK API-map skill body from the INSTALLED @immediately-run/sdk
// package's type declarations (R3-331).
//
// Why generated and not hand-written (the item's maintenance question, answered):
// a hand-written API map drifts silently against the SDK, and "a stale API map the
// model trusts absolutely is a worse failure than no map at all". agent-demo pins
// the SDK version in package.json, so deriving the map from `node_modules/
// @immediately-run/sdk/dist/*.d.ts` makes the skill exactly as current as the pin —
// it CANNOT drift, and `skills.sdkApiMap.test.ts` fails the build when the checked-in
// artifact and the installed SDK disagree.
//
// It reads only the package's own published .d.ts files — no network, no mount, no
// app-controlled path. The output is host bytes committed to this repo.
//
//   node scripts/gen-sdk-skill.mjs            # write src/lib/skills/sdkApiMap.generated.ts
//   node scripts/gen-sdk-skill.mjs --check    # exit 1 if the checked-in file is stale

const here = (0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url));
const repoRoot = (0, _nodePath.join)(here, '..');
const sdkRoot = (0, _nodePath.join)(repoRoot, 'node_modules', '@immediately-run', 'sdk');
const outFile = (0, _nodePath.join)(repoRoot, 'src', 'lib', 'skills', 'sdkApiMap.generated.ts');

/** Modules whose exports are internal plumbing rather than app-author API. */
const SKIP_MODULES = new Set(['runtime', 'protocolStream', 'injectedBundler', 'hostRuntime', 'irMarkers']);
/** Exports an app author should not reach for (test seams, internals). */
const SKIP_EXPORTS = /^(__|SDK_PROTOCOL_VERSION$)/;
/** Cap on how many members of one interface the map spells out. */
const MAX_INTERFACE_MEMBERS = 24;

/** `export { A, B } from './mod.js';` → { module: 'mod', names: ['A','B'] } */
function parseBarrel(text) {
  const out = [];
  const re = /export\s*\{([^}]*)\}\s*from\s*'\.\/(.+?)\.js';/g;
  for (let m; m = re.exec(text);) {
    const names = m[1].split(',').map(s => s.trim()).filter(s => s && !SKIP_EXPORTS.test(s));
    const module = m[2];
    if (!names.length || SKIP_MODULES.has(module)) continue;
    out.push({
      module,
      names
    });
  }
  return out;
}

/** Join a declaration that TS wrapped over several lines into one line. */
function collapse(sig) {
  return sig.replace(/\s*\n\s*/g, ' ').replace(/\s{2,}/g, ' ').trim();
}

/**
 * Pull the one-line signature of each named value declaration out of a module's
 * `.d.ts`. Handles both `declare function f(...): T;` and `declare const f: (...) => T;`,
 * including declarations TS emitted across several lines.
 */
function signaturesFor(moduleFile) {
  const path = (0, _nodePath.join)(sdkRoot, 'dist', `${moduleFile}.d.ts`);
  if (!(0, _nodeFs.existsSync)(path)) return new Map();
  const text = (0, _nodeFs.readFileSync)(path, 'utf8');
  const sigs = new Map();
  const lines = text.split('\n');
  const start = /^declare (?:function|const) ([A-Za-z_$][\w$]*)\b/;
  for (let i = 0; i < lines.length; i++) {
    const head = start.exec(lines[i]);
    if (!head) continue;
    // Accumulate until the declaration is BALANCED and terminated. A `;` inside an
    // inline object/return type (`useRoute: () => { name: string; … }`) is not the end
    // of the declaration — depth-tracking is what keeps such a signature whole.
    let depth = 0;
    const buf = [];
    for (let j = i; j < lines.length; j++) {
      const ln = lines[j];
      buf.push(ln);
      for (const ch of ln) {
        // Only bracket pairs — NOT `<`/`>`, because `=>` appears in almost every
        // signature and would close a depth that was never opened.
        if (ch === '(' || ch === '{' || ch === '[') depth++;else if (ch === ')' || ch === '}' || ch === ']') depth--;
      }
      if (depth <= 0 && ln.trimEnd().endsWith(';')) {
        i = j;
        break;
      }
      if (j - i > 60) {
        i = j;
        break;
      } // pathological — give up on this decl
    }
    sigs.set(head[1], collapse(buf.join('\n')).replace(/^declare (?:function|const) /, ''));
  }
  return sigs;
}

/**
 * Type-only exports (interface/type/enum/class). Interfaces are EXPANDED to their
 * member list, aliases are only named: an interface is usually the thing an author
 * has to get right (`MountFs`, `ChatRequest`, `SandboxMount` — the shapes a call
 * takes or returns), while a union alias adds nothing a signature did not already say.
 */
function typesFor(moduleFile) {
  const path = (0, _nodePath.join)(sdkRoot, 'dist', `${moduleFile}.d.ts`);
  if (!(0, _nodeFs.existsSync)(path)) return {
    names: new Set(),
    members: new Map()
  };
  const text = (0, _nodeFs.readFileSync)(path, 'utf8');
  const lines = text.split('\n');
  const names = new Set();
  const members = new Map();
  const decl = /^(?:declare )?(?:interface|type|enum|class) ([A-Za-z_$][\w$]*)\b/;
  const iface = /^(?:declare )?interface ([A-Za-z_$][\w$]*)\b[^{]*\{$/;
  for (let i = 0; i < lines.length; i++) {
    const d = decl.exec(lines[i]);
    if (!d) continue;
    names.add(d[1]);
    const isIface = iface.exec(lines[i]);
    if (!isIface) continue;
    const body = [];
    let depth = 1;
    for (let j = i + 1; j < lines.length && depth > 0; j++) {
      for (const ch of lines[j]) {
        if (ch === '{' || ch === '(' || ch === '[') depth++;else if (ch === '}' || ch === ')' || ch === ']') depth--;
      }
      if (depth <= 0) {
        i = j;
        break;
      }
      const t = lines[j].trim();
      // Members only — drop the doc-comment lines TS emits between them.
      if (!t || t.startsWith('/*') || t.startsWith('*') || t.startsWith('//')) continue;
      body.push(t);
    }
    if (body.length) members.set(d[1], body.slice(0, MAX_INTERFACE_MEMBERS));
  }
  return {
    names,
    members
  };
}
function build() {
  const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(sdkRoot, 'package.json'), 'utf8'));
  const barrel = (0, _nodeFs.readFileSync)((0, _nodePath.join)(sdkRoot, 'dist', 'index.d.ts'), 'utf8');
  const groups = parseBarrel(barrel);
  const lines = [];
  lines.push(`# @immediately-run/sdk ${pkg.version} — API map`);
  lines.push('');
  lines.push('Everything below is exported from the package root: `import { chat, openFs } from "@immediately-run/sdk"`. ' + 'Grouped by area. Signatures are the SDK\'s own published types for the exact version this app depends on — ' + 'prefer them over anything you remember. A name that is not in this list does not exist.');
  for (const {
    module,
    names
  } of groups) {
    const sigs = signaturesFor(module);
    const {
      names: typeNames,
      members
    } = typesFor(module);
    const values = [];
    const typeOnly = [];
    const expanded = [];
    for (const n of names) {
      if (sigs.has(n)) values.push(`  ${sigs.get(n)}`);else if (members.has(n)) expanded.push([n, members.get(n)]);else if (typeNames.has(n)) typeOnly.push(n);else values.push(`  ${n}`);
    }
    if (!values.length && !typeOnly.length && !expanded.length) continue;
    lines.push('');
    lines.push(`## ${module}`);
    if (values.length) lines.push(...values);
    for (const [n, body] of expanded) {
      lines.push(`  interface ${n} { ${collapse(body.join(' '))} }`);
    }
    if (typeOnly.length) lines.push(`  types: ${typeOnly.join(', ')}`);
  }
  lines.push('');
  const body = lines.join('\n');
  const banner = '// GENERATED by scripts/gen-sdk-skill.mjs from the installed @immediately-run/sdk\n' + '// type declarations — DO NOT EDIT. Regenerate with `npm run gen:sdk-skill`.\n' + '// `sdkApiMap.test.ts` fails when this file and the installed SDK disagree, so the\n' + '// map cannot drift away from the version this app pins (R3-331).\n';
  return banner + `\n/** The SDK version this map was generated from. */\nexport const SDK_API_MAP_VERSION = ${JSON.stringify(pkg.version)};\n` + `\n/** Host-authored (machine-derived) SDK API map — the body of the \`sdk\` skill. */\nexport const SDK_API_MAP = ${JSON.stringify(body)};\n`;
}
const next = build();
if (process.argv.includes('--check')) {
  const current = (0, _nodeFs.existsSync)(outFile) ? (0, _nodeFs.readFileSync)(outFile, 'utf8') : '';
  if (current !== next) {
    console.error('sdkApiMap.generated.ts is STALE — run `npm run gen:sdk-skill`.');
    process.exit(1);
  }
  console.log('sdkApiMap.generated.ts is current.');
} else {
  (0, _nodeFs.writeFileSync)(outFile, next);
  console.log(`wrote ${outFile} (${next.length} bytes)`);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUZzIiwicmVxdWlyZSIsIl9ub2RlVXJsIiwiX25vZGVQYXRoIiwiaGVyZSIsImRpcm5hbWUiLCJmaWxlVVJMVG9QYXRoIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwicmVwb1Jvb3QiLCJqb2luIiwic2RrUm9vdCIsIm91dEZpbGUiLCJTS0lQX01PRFVMRVMiLCJTZXQiLCJTS0lQX0VYUE9SVFMiLCJNQVhfSU5URVJGQUNFX01FTUJFUlMiLCJwYXJzZUJhcnJlbCIsInRleHQiLCJvdXQiLCJyZSIsIm0iLCJleGVjIiwibmFtZXMiLCJzcGxpdCIsIm1hcCIsInMiLCJ0cmltIiwiZmlsdGVyIiwidGVzdCIsIm1vZHVsZSIsImxlbmd0aCIsImhhcyIsInB1c2giLCJjb2xsYXBzZSIsInNpZyIsInJlcGxhY2UiLCJzaWduYXR1cmVzRm9yIiwibW9kdWxlRmlsZSIsInBhdGgiLCJleGlzdHNTeW5jIiwiTWFwIiwicmVhZEZpbGVTeW5jIiwic2lncyIsImxpbmVzIiwic3RhcnQiLCJpIiwiaGVhZCIsImRlcHRoIiwiYnVmIiwiaiIsImxuIiwiY2giLCJ0cmltRW5kIiwiZW5kc1dpdGgiLCJzZXQiLCJ0eXBlc0ZvciIsIm1lbWJlcnMiLCJkZWNsIiwiaWZhY2UiLCJkIiwiYWRkIiwiaXNJZmFjZSIsImJvZHkiLCJ0Iiwic3RhcnRzV2l0aCIsInNsaWNlIiwiYnVpbGQiLCJwa2ciLCJKU09OIiwicGFyc2UiLCJiYXJyZWwiLCJncm91cHMiLCJ2ZXJzaW9uIiwidHlwZU5hbWVzIiwidmFsdWVzIiwidHlwZU9ubHkiLCJleHBhbmRlZCIsIm4iLCJnZXQiLCJiYW5uZXIiLCJzdHJpbmdpZnkiLCJuZXh0IiwicHJvY2VzcyIsImFyZ3YiLCJpbmNsdWRlcyIsImN1cnJlbnQiLCJjb25zb2xlIiwiZXJyb3IiLCJleGl0IiwibG9nIiwid3JpdGVGaWxlU3luYyJdLCJzb3VyY2VzIjpbImdlbi1zZGstc2tpbGwubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEdlbmVyYXRlIHRoZSBTREsgQVBJLW1hcCBza2lsbCBib2R5IGZyb20gdGhlIElOU1RBTExFRCBAaW1tZWRpYXRlbHktcnVuL3Nka1xuLy8gcGFja2FnZSdzIHR5cGUgZGVjbGFyYXRpb25zIChSMy0zMzEpLlxuLy9cbi8vIFdoeSBnZW5lcmF0ZWQgYW5kIG5vdCBoYW5kLXdyaXR0ZW4gKHRoZSBpdGVtJ3MgbWFpbnRlbmFuY2UgcXVlc3Rpb24sIGFuc3dlcmVkKTpcbi8vIGEgaGFuZC13cml0dGVuIEFQSSBtYXAgZHJpZnRzIHNpbGVudGx5IGFnYWluc3QgdGhlIFNESywgYW5kIFwiYSBzdGFsZSBBUEkgbWFwIHRoZVxuLy8gbW9kZWwgdHJ1c3RzIGFic29sdXRlbHkgaXMgYSB3b3JzZSBmYWlsdXJlIHRoYW4gbm8gbWFwIGF0IGFsbFwiLiBhZ2VudC1kZW1vIHBpbnNcbi8vIHRoZSBTREsgdmVyc2lvbiBpbiBwYWNrYWdlLmpzb24sIHNvIGRlcml2aW5nIHRoZSBtYXAgZnJvbSBgbm9kZV9tb2R1bGVzL1xuLy8gQGltbWVkaWF0ZWx5LXJ1bi9zZGsvZGlzdC8qLmQudHNgIG1ha2VzIHRoZSBza2lsbCBleGFjdGx5IGFzIGN1cnJlbnQgYXMgdGhlIHBpbiDigJRcbi8vIGl0IENBTk5PVCBkcmlmdCwgYW5kIGBza2lsbHMuc2RrQXBpTWFwLnRlc3QudHNgIGZhaWxzIHRoZSBidWlsZCB3aGVuIHRoZSBjaGVja2VkLWluXG4vLyBhcnRpZmFjdCBhbmQgdGhlIGluc3RhbGxlZCBTREsgZGlzYWdyZWUuXG4vL1xuLy8gSXQgcmVhZHMgb25seSB0aGUgcGFja2FnZSdzIG93biBwdWJsaXNoZWQgLmQudHMgZmlsZXMg4oCUIG5vIG5ldHdvcmssIG5vIG1vdW50LCBub1xuLy8gYXBwLWNvbnRyb2xsZWQgcGF0aC4gVGhlIG91dHB1dCBpcyBob3N0IGJ5dGVzIGNvbW1pdHRlZCB0byB0aGlzIHJlcG8uXG4vL1xuLy8gICBub2RlIHNjcmlwdHMvZ2VuLXNkay1za2lsbC5tanMgICAgICAgICAgICAjIHdyaXRlIHNyYy9saWIvc2tpbGxzL3Nka0FwaU1hcC5nZW5lcmF0ZWQudHNcbi8vICAgbm9kZSBzY3JpcHRzL2dlbi1zZGstc2tpbGwubWpzIC0tY2hlY2sgICAgIyBleGl0IDEgaWYgdGhlIGNoZWNrZWQtaW4gZmlsZSBpcyBzdGFsZVxuXG5pbXBvcnQgeyByZWFkRmlsZVN5bmMsIHdyaXRlRmlsZVN5bmMsIGV4aXN0c1N5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGZpbGVVUkxUb1BhdGggfSBmcm9tICdub2RlOnVybCc7XG5pbXBvcnQgeyBkaXJuYW1lLCBqb2luIH0gZnJvbSAnbm9kZTpwYXRoJztcblxuY29uc3QgaGVyZSA9IGRpcm5hbWUoZmlsZVVSTFRvUGF0aChpbXBvcnQubWV0YS51cmwpKTtcbmNvbnN0IHJlcG9Sb290ID0gam9pbihoZXJlLCAnLi4nKTtcbmNvbnN0IHNka1Jvb3QgPSBqb2luKHJlcG9Sb290LCAnbm9kZV9tb2R1bGVzJywgJ0BpbW1lZGlhdGVseS1ydW4nLCAnc2RrJyk7XG5jb25zdCBvdXRGaWxlID0gam9pbihyZXBvUm9vdCwgJ3NyYycsICdsaWInLCAnc2tpbGxzJywgJ3Nka0FwaU1hcC5nZW5lcmF0ZWQudHMnKTtcblxuLyoqIE1vZHVsZXMgd2hvc2UgZXhwb3J0cyBhcmUgaW50ZXJuYWwgcGx1bWJpbmcgcmF0aGVyIHRoYW4gYXBwLWF1dGhvciBBUEkuICovXG5jb25zdCBTS0lQX01PRFVMRVMgPSBuZXcgU2V0KFsncnVudGltZScsICdwcm90b2NvbFN0cmVhbScsICdpbmplY3RlZEJ1bmRsZXInLCAnaG9zdFJ1bnRpbWUnLCAnaXJNYXJrZXJzJ10pO1xuLyoqIEV4cG9ydHMgYW4gYXBwIGF1dGhvciBzaG91bGQgbm90IHJlYWNoIGZvciAodGVzdCBzZWFtcywgaW50ZXJuYWxzKS4gKi9cbmNvbnN0IFNLSVBfRVhQT1JUUyA9IC9eKF9ffFNES19QUk9UT0NPTF9WRVJTSU9OJCkvO1xuLyoqIENhcCBvbiBob3cgbWFueSBtZW1iZXJzIG9mIG9uZSBpbnRlcmZhY2UgdGhlIG1hcCBzcGVsbHMgb3V0LiAqL1xuY29uc3QgTUFYX0lOVEVSRkFDRV9NRU1CRVJTID0gMjQ7XG5cbi8qKiBgZXhwb3J0IHsgQSwgQiB9IGZyb20gJy4vbW9kLmpzJztgIOKGkiB7IG1vZHVsZTogJ21vZCcsIG5hbWVzOiBbJ0EnLCdCJ10gfSAqL1xuZnVuY3Rpb24gcGFyc2VCYXJyZWwodGV4dCkge1xuICBjb25zdCBvdXQgPSBbXTtcbiAgY29uc3QgcmUgPSAvZXhwb3J0XFxzKlxceyhbXn1dKilcXH1cXHMqZnJvbVxccyonXFwuXFwvKC4rPylcXC5qcyc7L2c7XG4gIGZvciAobGV0IG07IChtID0gcmUuZXhlYyh0ZXh0KSk7ICkge1xuICAgIGNvbnN0IG5hbWVzID0gbVsxXVxuICAgICAgLnNwbGl0KCcsJylcbiAgICAgIC5tYXAoKHMpID0+IHMudHJpbSgpKVxuICAgICAgLmZpbHRlcigocykgPT4gcyAmJiAhU0tJUF9FWFBPUlRTLnRlc3QocykpO1xuICAgIGNvbnN0IG1vZHVsZSA9IG1bMl07XG4gICAgaWYgKCFuYW1lcy5sZW5ndGggfHwgU0tJUF9NT0RVTEVTLmhhcyhtb2R1bGUpKSBjb250aW51ZTtcbiAgICBvdXQucHVzaCh7IG1vZHVsZSwgbmFtZXMgfSk7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuLyoqIEpvaW4gYSBkZWNsYXJhdGlvbiB0aGF0IFRTIHdyYXBwZWQgb3ZlciBzZXZlcmFsIGxpbmVzIGludG8gb25lIGxpbmUuICovXG5mdW5jdGlvbiBjb2xsYXBzZShzaWcpIHtcbiAgcmV0dXJuIHNpZy5yZXBsYWNlKC9cXHMqXFxuXFxzKi9nLCAnICcpLnJlcGxhY2UoL1xcc3syLH0vZywgJyAnKS50cmltKCk7XG59XG5cbi8qKlxuICogUHVsbCB0aGUgb25lLWxpbmUgc2lnbmF0dXJlIG9mIGVhY2ggbmFtZWQgdmFsdWUgZGVjbGFyYXRpb24gb3V0IG9mIGEgbW9kdWxlJ3NcbiAqIGAuZC50c2AuIEhhbmRsZXMgYm90aCBgZGVjbGFyZSBmdW5jdGlvbiBmKC4uLik6IFQ7YCBhbmQgYGRlY2xhcmUgY29uc3QgZjogKC4uLikgPT4gVDtgLFxuICogaW5jbHVkaW5nIGRlY2xhcmF0aW9ucyBUUyBlbWl0dGVkIGFjcm9zcyBzZXZlcmFsIGxpbmVzLlxuICovXG5mdW5jdGlvbiBzaWduYXR1cmVzRm9yKG1vZHVsZUZpbGUpIHtcbiAgY29uc3QgcGF0aCA9IGpvaW4oc2RrUm9vdCwgJ2Rpc3QnLCBgJHttb2R1bGVGaWxlfS5kLnRzYCk7XG4gIGlmICghZXhpc3RzU3luYyhwYXRoKSkgcmV0dXJuIG5ldyBNYXAoKTtcbiAgY29uc3QgdGV4dCA9IHJlYWRGaWxlU3luYyhwYXRoLCAndXRmOCcpO1xuICBjb25zdCBzaWdzID0gbmV3IE1hcCgpO1xuICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoJ1xcbicpO1xuICBjb25zdCBzdGFydCA9IC9eZGVjbGFyZSAoPzpmdW5jdGlvbnxjb25zdCkgKFtBLVphLXpfJF1bXFx3JF0qKVxcYi87XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBoZWFkID0gc3RhcnQuZXhlYyhsaW5lc1tpXSk7XG4gICAgaWYgKCFoZWFkKSBjb250aW51ZTtcbiAgICAvLyBBY2N1bXVsYXRlIHVudGlsIHRoZSBkZWNsYXJhdGlvbiBpcyBCQUxBTkNFRCBhbmQgdGVybWluYXRlZC4gQSBgO2AgaW5zaWRlIGFuXG4gICAgLy8gaW5saW5lIG9iamVjdC9yZXR1cm4gdHlwZSAoYHVzZVJvdXRlOiAoKSA9PiB7IG5hbWU6IHN0cmluZzsg4oCmIH1gKSBpcyBub3QgdGhlIGVuZFxuICAgIC8vIG9mIHRoZSBkZWNsYXJhdGlvbiDigJQgZGVwdGgtdHJhY2tpbmcgaXMgd2hhdCBrZWVwcyBzdWNoIGEgc2lnbmF0dXJlIHdob2xlLlxuICAgIGxldCBkZXB0aCA9IDA7XG4gICAgY29uc3QgYnVmID0gW107XG4gICAgZm9yIChsZXQgaiA9IGk7IGogPCBsaW5lcy5sZW5ndGg7IGorKykge1xuICAgICAgY29uc3QgbG4gPSBsaW5lc1tqXTtcbiAgICAgIGJ1Zi5wdXNoKGxuKTtcbiAgICAgIGZvciAoY29uc3QgY2ggb2YgbG4pIHtcbiAgICAgICAgLy8gT25seSBicmFja2V0IHBhaXJzIOKAlCBOT1QgYDxgL2A+YCwgYmVjYXVzZSBgPT5gIGFwcGVhcnMgaW4gYWxtb3N0IGV2ZXJ5XG4gICAgICAgIC8vIHNpZ25hdHVyZSBhbmQgd291bGQgY2xvc2UgYSBkZXB0aCB0aGF0IHdhcyBuZXZlciBvcGVuZWQuXG4gICAgICAgIGlmIChjaCA9PT0gJygnIHx8IGNoID09PSAneycgfHwgY2ggPT09ICdbJykgZGVwdGgrKztcbiAgICAgICAgZWxzZSBpZiAoY2ggPT09ICcpJyB8fCBjaCA9PT0gJ30nIHx8IGNoID09PSAnXScpIGRlcHRoLS07XG4gICAgICB9XG4gICAgICBpZiAoZGVwdGggPD0gMCAmJiBsbi50cmltRW5kKCkuZW5kc1dpdGgoJzsnKSkgeyBpID0gajsgYnJlYWs7IH1cbiAgICAgIGlmIChqIC0gaSA+IDYwKSB7IGkgPSBqOyBicmVhazsgfSAvLyBwYXRob2xvZ2ljYWwg4oCUIGdpdmUgdXAgb24gdGhpcyBkZWNsXG4gICAgfVxuICAgIHNpZ3Muc2V0KGhlYWRbMV0sIGNvbGxhcHNlKGJ1Zi5qb2luKCdcXG4nKSkucmVwbGFjZSgvXmRlY2xhcmUgKD86ZnVuY3Rpb258Y29uc3QpIC8sICcnKSk7XG4gIH1cbiAgcmV0dXJuIHNpZ3M7XG59XG5cbi8qKlxuICogVHlwZS1vbmx5IGV4cG9ydHMgKGludGVyZmFjZS90eXBlL2VudW0vY2xhc3MpLiBJbnRlcmZhY2VzIGFyZSBFWFBBTkRFRCB0byB0aGVpclxuICogbWVtYmVyIGxpc3QsIGFsaWFzZXMgYXJlIG9ubHkgbmFtZWQ6IGFuIGludGVyZmFjZSBpcyB1c3VhbGx5IHRoZSB0aGluZyBhbiBhdXRob3JcbiAqIGhhcyB0byBnZXQgcmlnaHQgKGBNb3VudEZzYCwgYENoYXRSZXF1ZXN0YCwgYFNhbmRib3hNb3VudGAg4oCUIHRoZSBzaGFwZXMgYSBjYWxsXG4gKiB0YWtlcyBvciByZXR1cm5zKSwgd2hpbGUgYSB1bmlvbiBhbGlhcyBhZGRzIG5vdGhpbmcgYSBzaWduYXR1cmUgZGlkIG5vdCBhbHJlYWR5IHNheS5cbiAqL1xuZnVuY3Rpb24gdHlwZXNGb3IobW9kdWxlRmlsZSkge1xuICBjb25zdCBwYXRoID0gam9pbihzZGtSb290LCAnZGlzdCcsIGAke21vZHVsZUZpbGV9LmQudHNgKTtcbiAgaWYgKCFleGlzdHNTeW5jKHBhdGgpKSByZXR1cm4geyBuYW1lczogbmV3IFNldCgpLCBtZW1iZXJzOiBuZXcgTWFwKCkgfTtcbiAgY29uc3QgdGV4dCA9IHJlYWRGaWxlU3luYyhwYXRoLCAndXRmOCcpO1xuICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoJ1xcbicpO1xuICBjb25zdCBuYW1lcyA9IG5ldyBTZXQoKTtcbiAgY29uc3QgbWVtYmVycyA9IG5ldyBNYXAoKTtcbiAgY29uc3QgZGVjbCA9IC9eKD86ZGVjbGFyZSApPyg/OmludGVyZmFjZXx0eXBlfGVudW18Y2xhc3MpIChbQS1aYS16XyRdW1xcdyRdKilcXGIvO1xuICBjb25zdCBpZmFjZSA9IC9eKD86ZGVjbGFyZSApP2ludGVyZmFjZSAoW0EtWmEtel8kXVtcXHckXSopXFxiW157XSpcXHskLztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGQgPSBkZWNsLmV4ZWMobGluZXNbaV0pO1xuICAgIGlmICghZCkgY29udGludWU7XG4gICAgbmFtZXMuYWRkKGRbMV0pO1xuICAgIGNvbnN0IGlzSWZhY2UgPSBpZmFjZS5leGVjKGxpbmVzW2ldKTtcbiAgICBpZiAoIWlzSWZhY2UpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGJvZHkgPSBbXTtcbiAgICBsZXQgZGVwdGggPSAxO1xuICAgIGZvciAobGV0IGogPSBpICsgMTsgaiA8IGxpbmVzLmxlbmd0aCAmJiBkZXB0aCA+IDA7IGorKykge1xuICAgICAgZm9yIChjb25zdCBjaCBvZiBsaW5lc1tqXSkge1xuICAgICAgICBpZiAoY2ggPT09ICd7JyB8fCBjaCA9PT0gJygnIHx8IGNoID09PSAnWycpIGRlcHRoKys7XG4gICAgICAgIGVsc2UgaWYgKGNoID09PSAnfScgfHwgY2ggPT09ICcpJyB8fCBjaCA9PT0gJ10nKSBkZXB0aC0tO1xuICAgICAgfVxuICAgICAgaWYgKGRlcHRoIDw9IDApIHsgaSA9IGo7IGJyZWFrOyB9XG4gICAgICBjb25zdCB0ID0gbGluZXNbal0udHJpbSgpO1xuICAgICAgLy8gTWVtYmVycyBvbmx5IOKAlCBkcm9wIHRoZSBkb2MtY29tbWVudCBsaW5lcyBUUyBlbWl0cyBiZXR3ZWVuIHRoZW0uXG4gICAgICBpZiAoIXQgfHwgdC5zdGFydHNXaXRoKCcvKicpIHx8IHQuc3RhcnRzV2l0aCgnKicpIHx8IHQuc3RhcnRzV2l0aCgnLy8nKSkgY29udGludWU7XG4gICAgICBib2R5LnB1c2godCk7XG4gICAgfVxuICAgIGlmIChib2R5Lmxlbmd0aCkgbWVtYmVycy5zZXQoZFsxXSwgYm9keS5zbGljZSgwLCBNQVhfSU5URVJGQUNFX01FTUJFUlMpKTtcbiAgfVxuICByZXR1cm4geyBuYW1lcywgbWVtYmVycyB9O1xufVxuXG5mdW5jdGlvbiBidWlsZCgpIHtcbiAgY29uc3QgcGtnID0gSlNPTi5wYXJzZShyZWFkRmlsZVN5bmMoam9pbihzZGtSb290LCAncGFja2FnZS5qc29uJyksICd1dGY4JykpO1xuICBjb25zdCBiYXJyZWwgPSByZWFkRmlsZVN5bmMoam9pbihzZGtSb290LCAnZGlzdCcsICdpbmRleC5kLnRzJyksICd1dGY4Jyk7XG4gIGNvbnN0IGdyb3VwcyA9IHBhcnNlQmFycmVsKGJhcnJlbCk7XG5cbiAgY29uc3QgbGluZXMgPSBbXTtcbiAgbGluZXMucHVzaChgIyBAaW1tZWRpYXRlbHktcnVuL3NkayAke3BrZy52ZXJzaW9ufSDigJQgQVBJIG1hcGApO1xuICBsaW5lcy5wdXNoKCcnKTtcbiAgbGluZXMucHVzaChcbiAgICAnRXZlcnl0aGluZyBiZWxvdyBpcyBleHBvcnRlZCBmcm9tIHRoZSBwYWNrYWdlIHJvb3Q6IGBpbXBvcnQgeyBjaGF0LCBvcGVuRnMgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcImAuICcgK1xuICAgICAgJ0dyb3VwZWQgYnkgYXJlYS4gU2lnbmF0dXJlcyBhcmUgdGhlIFNES1xcJ3Mgb3duIHB1Ymxpc2hlZCB0eXBlcyBmb3IgdGhlIGV4YWN0IHZlcnNpb24gdGhpcyBhcHAgZGVwZW5kcyBvbiDigJQgJyArXG4gICAgICAncHJlZmVyIHRoZW0gb3ZlciBhbnl0aGluZyB5b3UgcmVtZW1iZXIuIEEgbmFtZSB0aGF0IGlzIG5vdCBpbiB0aGlzIGxpc3QgZG9lcyBub3QgZXhpc3QuJyxcbiAgKTtcbiAgZm9yIChjb25zdCB7IG1vZHVsZSwgbmFtZXMgfSBvZiBncm91cHMpIHtcbiAgICBjb25zdCBzaWdzID0gc2lnbmF0dXJlc0Zvcihtb2R1bGUpO1xuICAgIGNvbnN0IHsgbmFtZXM6IHR5cGVOYW1lcywgbWVtYmVycyB9ID0gdHlwZXNGb3IobW9kdWxlKTtcbiAgICBjb25zdCB2YWx1ZXMgPSBbXTtcbiAgICBjb25zdCB0eXBlT25seSA9IFtdO1xuICAgIGNvbnN0IGV4cGFuZGVkID0gW107XG4gICAgZm9yIChjb25zdCBuIG9mIG5hbWVzKSB7XG4gICAgICBpZiAoc2lncy5oYXMobikpIHZhbHVlcy5wdXNoKGAgICR7c2lncy5nZXQobil9YCk7XG4gICAgICBlbHNlIGlmIChtZW1iZXJzLmhhcyhuKSkgZXhwYW5kZWQucHVzaChbbiwgbWVtYmVycy5nZXQobildKTtcbiAgICAgIGVsc2UgaWYgKHR5cGVOYW1lcy5oYXMobikpIHR5cGVPbmx5LnB1c2gobik7XG4gICAgICBlbHNlIHZhbHVlcy5wdXNoKGAgICR7bn1gKTtcbiAgICB9XG4gICAgaWYgKCF2YWx1ZXMubGVuZ3RoICYmICF0eXBlT25seS5sZW5ndGggJiYgIWV4cGFuZGVkLmxlbmd0aCkgY29udGludWU7XG4gICAgbGluZXMucHVzaCgnJyk7XG4gICAgbGluZXMucHVzaChgIyMgJHttb2R1bGV9YCk7XG4gICAgaWYgKHZhbHVlcy5sZW5ndGgpIGxpbmVzLnB1c2goLi4udmFsdWVzKTtcbiAgICBmb3IgKGNvbnN0IFtuLCBib2R5XSBvZiBleHBhbmRlZCkge1xuICAgICAgbGluZXMucHVzaChgICBpbnRlcmZhY2UgJHtufSB7ICR7Y29sbGFwc2UoYm9keS5qb2luKCcgJykpfSB9YCk7XG4gICAgfVxuICAgIGlmICh0eXBlT25seS5sZW5ndGgpIGxpbmVzLnB1c2goYCAgdHlwZXM6ICR7dHlwZU9ubHkuam9pbignLCAnKX1gKTtcbiAgfVxuICBsaW5lcy5wdXNoKCcnKTtcblxuICBjb25zdCBib2R5ID0gbGluZXMuam9pbignXFxuJyk7XG4gIGNvbnN0IGJhbm5lciA9XG4gICAgJy8vIEdFTkVSQVRFRCBieSBzY3JpcHRzL2dlbi1zZGstc2tpbGwubWpzIGZyb20gdGhlIGluc3RhbGxlZCBAaW1tZWRpYXRlbHktcnVuL3Nka1xcbicgK1xuICAgICcvLyB0eXBlIGRlY2xhcmF0aW9ucyDigJQgRE8gTk9UIEVESVQuIFJlZ2VuZXJhdGUgd2l0aCBgbnBtIHJ1biBnZW46c2RrLXNraWxsYC5cXG4nICtcbiAgICAnLy8gYHNka0FwaU1hcC50ZXN0LnRzYCBmYWlscyB3aGVuIHRoaXMgZmlsZSBhbmQgdGhlIGluc3RhbGxlZCBTREsgZGlzYWdyZWUsIHNvIHRoZVxcbicgK1xuICAgICcvLyBtYXAgY2Fubm90IGRyaWZ0IGF3YXkgZnJvbSB0aGUgdmVyc2lvbiB0aGlzIGFwcCBwaW5zIChSMy0zMzEpLlxcbic7XG4gIHJldHVybiAoXG4gICAgYmFubmVyICtcbiAgICBgXFxuLyoqIFRoZSBTREsgdmVyc2lvbiB0aGlzIG1hcCB3YXMgZ2VuZXJhdGVkIGZyb20uICovXFxuZXhwb3J0IGNvbnN0IFNES19BUElfTUFQX1ZFUlNJT04gPSAke0pTT04uc3RyaW5naWZ5KHBrZy52ZXJzaW9uKX07XFxuYCArXG4gICAgYFxcbi8qKiBIb3N0LWF1dGhvcmVkIChtYWNoaW5lLWRlcml2ZWQpIFNESyBBUEkgbWFwIOKAlCB0aGUgYm9keSBvZiB0aGUgXFxgc2RrXFxgIHNraWxsLiAqL1xcbmV4cG9ydCBjb25zdCBTREtfQVBJX01BUCA9ICR7SlNPTi5zdHJpbmdpZnkoYm9keSl9O1xcbmBcbiAgKTtcbn1cblxuY29uc3QgbmV4dCA9IGJ1aWxkKCk7XG5pZiAocHJvY2Vzcy5hcmd2LmluY2x1ZGVzKCctLWNoZWNrJykpIHtcbiAgY29uc3QgY3VycmVudCA9IGV4aXN0c1N5bmMob3V0RmlsZSkgPyByZWFkRmlsZVN5bmMob3V0RmlsZSwgJ3V0ZjgnKSA6ICcnO1xuICBpZiAoY3VycmVudCAhPT0gbmV4dCkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ3Nka0FwaU1hcC5nZW5lcmF0ZWQudHMgaXMgU1RBTEUg4oCUIHJ1biBgbnBtIHJ1biBnZW46c2RrLXNraWxsYC4nKTtcbiAgICBwcm9jZXNzLmV4aXQoMSk7XG4gIH1cbiAgY29uc29sZS5sb2coJ3Nka0FwaU1hcC5nZW5lcmF0ZWQudHMgaXMgY3VycmVudC4nKTtcbn0gZWxzZSB7XG4gIHdyaXRlRmlsZVN5bmMob3V0RmlsZSwgbmV4dCk7XG4gIGNvbnNvbGUubG9nKGB3cm90ZSAke291dEZpbGV9ICgke25leHQubGVuZ3RofSBieXRlcylgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFpQkEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsUUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBbkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BLE1BQU1HLElBQUksR0FBRyxJQUFBQyxpQkFBTyxFQUFDLElBQUFDLHNCQUFhLEVBQUNDLGVBQUEsQ0FBWUMsR0FBRyxDQUFDLENBQUM7QUFDcEQsTUFBTUMsUUFBUSxHQUFHLElBQUFDLGNBQUksRUFBQ04sSUFBSSxFQUFFLElBQUksQ0FBQztBQUNqQyxNQUFNTyxPQUFPLEdBQUcsSUFBQUQsY0FBSSxFQUFDRCxRQUFRLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFLEtBQUssQ0FBQztBQUN6RSxNQUFNRyxPQUFPLEdBQUcsSUFBQUYsY0FBSSxFQUFDRCxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsd0JBQXdCLENBQUM7O0FBRWhGO0FBQ0EsTUFBTUksWUFBWSxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFDMUc7QUFDQSxNQUFNQyxZQUFZLEdBQUcsNkJBQTZCO0FBQ2xEO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUcsRUFBRTs7QUFFaEM7QUFDQSxTQUFTQyxXQUFXQSxDQUFDQyxJQUFJLEVBQUU7RUFDekIsTUFBTUMsR0FBRyxHQUFHLEVBQUU7RUFDZCxNQUFNQyxFQUFFLEdBQUcsaURBQWlEO0VBQzVELEtBQUssSUFBSUMsQ0FBQyxFQUFHQSxDQUFDLEdBQUdELEVBQUUsQ0FBQ0UsSUFBSSxDQUFDSixJQUFJLENBQUMsR0FBSztJQUNqQyxNQUFNSyxLQUFLLEdBQUdGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDZkcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUNWQyxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQ3BCQyxNQUFNLENBQUVGLENBQUMsSUFBS0EsQ0FBQyxJQUFJLENBQUNYLFlBQVksQ0FBQ2MsSUFBSSxDQUFDSCxDQUFDLENBQUMsQ0FBQztJQUM1QyxNQUFNSSxNQUFNLEdBQUdULENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkIsSUFBSSxDQUFDRSxLQUFLLENBQUNRLE1BQU0sSUFBSWxCLFlBQVksQ0FBQ21CLEdBQUcsQ0FBQ0YsTUFBTSxDQUFDLEVBQUU7SUFDL0NYLEdBQUcsQ0FBQ2MsSUFBSSxDQUFDO01BQUVILE1BQU07TUFBRVA7SUFBTSxDQUFDLENBQUM7RUFDN0I7RUFDQSxPQUFPSixHQUFHO0FBQ1o7O0FBRUE7QUFDQSxTQUFTZSxRQUFRQSxDQUFDQyxHQUFHLEVBQUU7RUFDckIsT0FBT0EsR0FBRyxDQUFDQyxPQUFPLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDQSxPQUFPLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDVCxJQUFJLENBQUMsQ0FBQztBQUNyRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU1UsYUFBYUEsQ0FBQ0MsVUFBVSxFQUFFO0VBQ2pDLE1BQU1DLElBQUksR0FBRyxJQUFBN0IsY0FBSSxFQUFDQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEdBQUcyQixVQUFVLE9BQU8sQ0FBQztFQUN4RCxJQUFJLENBQUMsSUFBQUUsa0JBQVUsRUFBQ0QsSUFBSSxDQUFDLEVBQUUsT0FBTyxJQUFJRSxHQUFHLENBQUMsQ0FBQztFQUN2QyxNQUFNdkIsSUFBSSxHQUFHLElBQUF3QixvQkFBWSxFQUFDSCxJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQ3ZDLE1BQU1JLElBQUksR0FBRyxJQUFJRixHQUFHLENBQUMsQ0FBQztFQUN0QixNQUFNRyxLQUFLLEdBQUcxQixJQUFJLENBQUNNLEtBQUssQ0FBQyxJQUFJLENBQUM7RUFDOUIsTUFBTXFCLEtBQUssR0FBRyxrREFBa0Q7RUFDaEUsS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdGLEtBQUssQ0FBQ2IsTUFBTSxFQUFFZSxDQUFDLEVBQUUsRUFBRTtJQUNyQyxNQUFNQyxJQUFJLEdBQUdGLEtBQUssQ0FBQ3ZCLElBQUksQ0FBQ3NCLEtBQUssQ0FBQ0UsQ0FBQyxDQUFDLENBQUM7SUFDakMsSUFBSSxDQUFDQyxJQUFJLEVBQUU7SUFDWDtJQUNBO0lBQ0E7SUFDQSxJQUFJQyxLQUFLLEdBQUcsQ0FBQztJQUNiLE1BQU1DLEdBQUcsR0FBRyxFQUFFO0lBQ2QsS0FBSyxJQUFJQyxDQUFDLEdBQUdKLENBQUMsRUFBRUksQ0FBQyxHQUFHTixLQUFLLENBQUNiLE1BQU0sRUFBRW1CLENBQUMsRUFBRSxFQUFFO01BQ3JDLE1BQU1DLEVBQUUsR0FBR1AsS0FBSyxDQUFDTSxDQUFDLENBQUM7TUFDbkJELEdBQUcsQ0FBQ2hCLElBQUksQ0FBQ2tCLEVBQUUsQ0FBQztNQUNaLEtBQUssTUFBTUMsRUFBRSxJQUFJRCxFQUFFLEVBQUU7UUFDbkI7UUFDQTtRQUNBLElBQUlDLEVBQUUsS0FBSyxHQUFHLElBQUlBLEVBQUUsS0FBSyxHQUFHLElBQUlBLEVBQUUsS0FBSyxHQUFHLEVBQUVKLEtBQUssRUFBRSxDQUFDLEtBQy9DLElBQUlJLEVBQUUsS0FBSyxHQUFHLElBQUlBLEVBQUUsS0FBSyxHQUFHLElBQUlBLEVBQUUsS0FBSyxHQUFHLEVBQUVKLEtBQUssRUFBRTtNQUMxRDtNQUNBLElBQUlBLEtBQUssSUFBSSxDQUFDLElBQUlHLEVBQUUsQ0FBQ0UsT0FBTyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQUVSLENBQUMsR0FBR0ksQ0FBQztRQUFFO01BQU87TUFDOUQsSUFBSUEsQ0FBQyxHQUFHSixDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQUVBLENBQUMsR0FBR0ksQ0FBQztRQUFFO01BQU8sQ0FBQyxDQUFDO0lBQ3BDO0lBQ0FQLElBQUksQ0FBQ1ksR0FBRyxDQUFDUixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUViLFFBQVEsQ0FBQ2UsR0FBRyxDQUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMwQixPQUFPLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFDekY7RUFDQSxPQUFPTyxJQUFJO0FBQ2I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU2EsUUFBUUEsQ0FBQ2xCLFVBQVUsRUFBRTtFQUM1QixNQUFNQyxJQUFJLEdBQUcsSUFBQTdCLGNBQUksRUFBQ0MsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHMkIsVUFBVSxPQUFPLENBQUM7RUFDeEQsSUFBSSxDQUFDLElBQUFFLGtCQUFVLEVBQUNELElBQUksQ0FBQyxFQUFFLE9BQU87SUFBRWhCLEtBQUssRUFBRSxJQUFJVCxHQUFHLENBQUMsQ0FBQztJQUFFMkMsT0FBTyxFQUFFLElBQUloQixHQUFHLENBQUM7RUFBRSxDQUFDO0VBQ3RFLE1BQU12QixJQUFJLEdBQUcsSUFBQXdCLG9CQUFZLEVBQUNILElBQUksRUFBRSxNQUFNLENBQUM7RUFDdkMsTUFBTUssS0FBSyxHQUFHMUIsSUFBSSxDQUFDTSxLQUFLLENBQUMsSUFBSSxDQUFDO0VBQzlCLE1BQU1ELEtBQUssR0FBRyxJQUFJVCxHQUFHLENBQUMsQ0FBQztFQUN2QixNQUFNMkMsT0FBTyxHQUFHLElBQUloQixHQUFHLENBQUMsQ0FBQztFQUN6QixNQUFNaUIsSUFBSSxHQUFHLGtFQUFrRTtFQUMvRSxNQUFNQyxLQUFLLEdBQUcsc0RBQXNEO0VBQ3BFLEtBQUssSUFBSWIsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHRixLQUFLLENBQUNiLE1BQU0sRUFBRWUsQ0FBQyxFQUFFLEVBQUU7SUFDckMsTUFBTWMsQ0FBQyxHQUFHRixJQUFJLENBQUNwQyxJQUFJLENBQUNzQixLQUFLLENBQUNFLENBQUMsQ0FBQyxDQUFDO0lBQzdCLElBQUksQ0FBQ2MsQ0FBQyxFQUFFO0lBQ1JyQyxLQUFLLENBQUNzQyxHQUFHLENBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNmLE1BQU1FLE9BQU8sR0FBR0gsS0FBSyxDQUFDckMsSUFBSSxDQUFDc0IsS0FBSyxDQUFDRSxDQUFDLENBQUMsQ0FBQztJQUNwQyxJQUFJLENBQUNnQixPQUFPLEVBQUU7SUFDZCxNQUFNQyxJQUFJLEdBQUcsRUFBRTtJQUNmLElBQUlmLEtBQUssR0FBRyxDQUFDO0lBQ2IsS0FBSyxJQUFJRSxDQUFDLEdBQUdKLENBQUMsR0FBRyxDQUFDLEVBQUVJLENBQUMsR0FBR04sS0FBSyxDQUFDYixNQUFNLElBQUlpQixLQUFLLEdBQUcsQ0FBQyxFQUFFRSxDQUFDLEVBQUUsRUFBRTtNQUN0RCxLQUFLLE1BQU1FLEVBQUUsSUFBSVIsS0FBSyxDQUFDTSxDQUFDLENBQUMsRUFBRTtRQUN6QixJQUFJRSxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxFQUFFSixLQUFLLEVBQUUsQ0FBQyxLQUMvQyxJQUFJSSxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxFQUFFSixLQUFLLEVBQUU7TUFDMUQ7TUFDQSxJQUFJQSxLQUFLLElBQUksQ0FBQyxFQUFFO1FBQUVGLENBQUMsR0FBR0ksQ0FBQztRQUFFO01BQU87TUFDaEMsTUFBTWMsQ0FBQyxHQUFHcEIsS0FBSyxDQUFDTSxDQUFDLENBQUMsQ0FBQ3ZCLElBQUksQ0FBQyxDQUFDO01BQ3pCO01BQ0EsSUFBSSxDQUFDcUMsQ0FBQyxJQUFJQSxDQUFDLENBQUNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSUQsQ0FBQyxDQUFDQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUlELENBQUMsQ0FBQ0MsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ3pFRixJQUFJLENBQUM5QixJQUFJLENBQUMrQixDQUFDLENBQUM7SUFDZDtJQUNBLElBQUlELElBQUksQ0FBQ2hDLE1BQU0sRUFBRTBCLE9BQU8sQ0FBQ0YsR0FBRyxDQUFDSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVHLElBQUksQ0FBQ0csS0FBSyxDQUFDLENBQUMsRUFBRWxELHFCQUFxQixDQUFDLENBQUM7RUFDMUU7RUFDQSxPQUFPO0lBQUVPLEtBQUs7SUFBRWtDO0VBQVEsQ0FBQztBQUMzQjtBQUVBLFNBQVNVLEtBQUtBLENBQUEsRUFBRztFQUNmLE1BQU1DLEdBQUcsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQTVCLG9CQUFZLEVBQUMsSUFBQWhDLGNBQUksRUFBQ0MsT0FBTyxFQUFFLGNBQWMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0VBQzNFLE1BQU00RCxNQUFNLEdBQUcsSUFBQTdCLG9CQUFZLEVBQUMsSUFBQWhDLGNBQUksRUFBQ0MsT0FBTyxFQUFFLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxNQUFNLENBQUM7RUFDeEUsTUFBTTZELE1BQU0sR0FBR3ZELFdBQVcsQ0FBQ3NELE1BQU0sQ0FBQztFQUVsQyxNQUFNM0IsS0FBSyxHQUFHLEVBQUU7RUFDaEJBLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLDBCQUEwQm1DLEdBQUcsQ0FBQ0ssT0FBTyxZQUFZLENBQUM7RUFDN0Q3QixLQUFLLENBQUNYLElBQUksQ0FBQyxFQUFFLENBQUM7RUFDZFcsS0FBSyxDQUFDWCxJQUFJLENBQ1IsNkdBQTZHLEdBQzNHLDZHQUE2RyxHQUM3Ryx5RkFDSixDQUFDO0VBQ0QsS0FBSyxNQUFNO0lBQUVILE1BQU07SUFBRVA7RUFBTSxDQUFDLElBQUlpRCxNQUFNLEVBQUU7SUFDdEMsTUFBTTdCLElBQUksR0FBR04sYUFBYSxDQUFDUCxNQUFNLENBQUM7SUFDbEMsTUFBTTtNQUFFUCxLQUFLLEVBQUVtRCxTQUFTO01BQUVqQjtJQUFRLENBQUMsR0FBR0QsUUFBUSxDQUFDMUIsTUFBTSxDQUFDO0lBQ3RELE1BQU02QyxNQUFNLEdBQUcsRUFBRTtJQUNqQixNQUFNQyxRQUFRLEdBQUcsRUFBRTtJQUNuQixNQUFNQyxRQUFRLEdBQUcsRUFBRTtJQUNuQixLQUFLLE1BQU1DLENBQUMsSUFBSXZELEtBQUssRUFBRTtNQUNyQixJQUFJb0IsSUFBSSxDQUFDWCxHQUFHLENBQUM4QyxDQUFDLENBQUMsRUFBRUgsTUFBTSxDQUFDMUMsSUFBSSxDQUFDLEtBQUtVLElBQUksQ0FBQ29DLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQzVDLElBQUlyQixPQUFPLENBQUN6QixHQUFHLENBQUM4QyxDQUFDLENBQUMsRUFBRUQsUUFBUSxDQUFDNUMsSUFBSSxDQUFDLENBQUM2QyxDQUFDLEVBQUVyQixPQUFPLENBQUNzQixHQUFHLENBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUN2RCxJQUFJSixTQUFTLENBQUMxQyxHQUFHLENBQUM4QyxDQUFDLENBQUMsRUFBRUYsUUFBUSxDQUFDM0MsSUFBSSxDQUFDNkMsQ0FBQyxDQUFDLENBQUMsS0FDdkNILE1BQU0sQ0FBQzFDLElBQUksQ0FBQyxLQUFLNkMsQ0FBQyxFQUFFLENBQUM7SUFDNUI7SUFDQSxJQUFJLENBQUNILE1BQU0sQ0FBQzVDLE1BQU0sSUFBSSxDQUFDNkMsUUFBUSxDQUFDN0MsTUFBTSxJQUFJLENBQUM4QyxRQUFRLENBQUM5QyxNQUFNLEVBQUU7SUFDNURhLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLEVBQUUsQ0FBQztJQUNkVyxLQUFLLENBQUNYLElBQUksQ0FBQyxNQUFNSCxNQUFNLEVBQUUsQ0FBQztJQUMxQixJQUFJNkMsTUFBTSxDQUFDNUMsTUFBTSxFQUFFYSxLQUFLLENBQUNYLElBQUksQ0FBQyxHQUFHMEMsTUFBTSxDQUFDO0lBQ3hDLEtBQUssTUFBTSxDQUFDRyxDQUFDLEVBQUVmLElBQUksQ0FBQyxJQUFJYyxRQUFRLEVBQUU7TUFDaENqQyxLQUFLLENBQUNYLElBQUksQ0FBQyxlQUFlNkMsQ0FBQyxNQUFNNUMsUUFBUSxDQUFDNkIsSUFBSSxDQUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUNoRTtJQUNBLElBQUlrRSxRQUFRLENBQUM3QyxNQUFNLEVBQUVhLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLFlBQVkyQyxRQUFRLENBQUNsRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUNwRTtFQUNBa0MsS0FBSyxDQUFDWCxJQUFJLENBQUMsRUFBRSxDQUFDO0VBRWQsTUFBTThCLElBQUksR0FBR25CLEtBQUssQ0FBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDN0IsTUFBTXNFLE1BQU0sR0FDVixxRkFBcUYsR0FDckYsZ0ZBQWdGLEdBQ2hGLHNGQUFzRixHQUN0RixxRUFBcUU7RUFDdkUsT0FDRUEsTUFBTSxHQUNOLDZGQUE2RlgsSUFBSSxDQUFDWSxTQUFTLENBQUNiLEdBQUcsQ0FBQ0ssT0FBTyxDQUFDLEtBQUssR0FDN0gscUhBQXFISixJQUFJLENBQUNZLFNBQVMsQ0FBQ2xCLElBQUksQ0FBQyxLQUFLO0FBRWxKO0FBRUEsTUFBTW1CLElBQUksR0FBR2YsS0FBSyxDQUFDLENBQUM7QUFDcEIsSUFBSWdCLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7RUFDcEMsTUFBTUMsT0FBTyxHQUFHLElBQUE5QyxrQkFBVSxFQUFDNUIsT0FBTyxDQUFDLEdBQUcsSUFBQThCLG9CQUFZLEVBQUM5QixPQUFPLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRTtFQUN4RSxJQUFJMEUsT0FBTyxLQUFLSixJQUFJLEVBQUU7SUFDcEJLLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLGdFQUFnRSxDQUFDO0lBQy9FTCxPQUFPLENBQUNNLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDakI7RUFDQUYsT0FBTyxDQUFDRyxHQUFHLENBQUMsb0NBQW9DLENBQUM7QUFDbkQsQ0FBQyxNQUFNO0VBQ0wsSUFBQUMscUJBQWEsRUFBQy9FLE9BQU8sRUFBRXNFLElBQUksQ0FBQztFQUM1QkssT0FBTyxDQUFDRyxHQUFHLENBQUMsU0FBUzlFLE9BQU8sS0FBS3NFLElBQUksQ0FBQ25ELE1BQU0sU0FBUyxDQUFDO0FBQ3hEIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}