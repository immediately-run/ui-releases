"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
var _devFs = require("@immediately-run/dev-fs");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The agent's filesystem tools (src/lib/fsTools.ts) `import fs from 'fs'`. That
// `fs` is host-provided at runtime (ZenFS in the sandbox); devFs() backs it with
// the local disk under `vite dev`, and we externalize `fs`/`node:fs` from the
// production build so immediately.run resolves it from its runtime instead of
// Vite trying to bundle a Node builtin. https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)({
  plugins: [(0, _pluginReact.default)(), (0, _devFs.devFs)()],
  build: {
    rollupOptions: {
      external: ['fs', 'node:fs']
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2RldkZzIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwicGx1Z2lucyIsInJlYWN0IiwiZGV2RnMiLCJidWlsZCIsInJvbGx1cE9wdGlvbnMiLCJleHRlcm5hbCJdLCJzb3VyY2VzIjpbInZpdGUuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gJ3ZpdGUnO1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0JztcbmltcG9ydCB7IGRldkZzIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9kZXYtZnMnO1xuXG4vLyBUaGUgYWdlbnQncyBmaWxlc3lzdGVtIHRvb2xzIChzcmMvbGliL2ZzVG9vbHMudHMpIGBpbXBvcnQgZnMgZnJvbSAnZnMnYC4gVGhhdFxuLy8gYGZzYCBpcyBob3N0LXByb3ZpZGVkIGF0IHJ1bnRpbWUgKFplbkZTIGluIHRoZSBzYW5kYm94KTsgZGV2RnMoKSBiYWNrcyBpdCB3aXRoXG4vLyB0aGUgbG9jYWwgZGlzayB1bmRlciBgdml0ZSBkZXZgLCBhbmQgd2UgZXh0ZXJuYWxpemUgYGZzYC9gbm9kZTpmc2AgZnJvbSB0aGVcbi8vIHByb2R1Y3Rpb24gYnVpbGQgc28gaW1tZWRpYXRlbHkucnVuIHJlc29sdmVzIGl0IGZyb20gaXRzIHJ1bnRpbWUgaW5zdGVhZCBvZlxuLy8gVml0ZSB0cnlpbmcgdG8gYnVuZGxlIGEgTm9kZSBidWlsdGluLiBodHRwczovL3ZpdGUuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtyZWFjdCgpLCBkZXZGcygpXSxcbiAgYnVpbGQ6IHtcbiAgICByb2xsdXBPcHRpb25zOiB7IGV4dGVybmFsOiBbJ2ZzJywgJ25vZGU6ZnMnXSB9LFxuICB9LFxufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLEtBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLE1BQUEsR0FBQUgsT0FBQTtBQUFnRCxTQUFBRSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUVoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFGLE9BQUEsR0FDZSxJQUFBRyxrQkFBWSxFQUFDO0VBQzFCQyxPQUFPLEVBQUUsQ0FBQyxJQUFBQyxvQkFBSyxFQUFDLENBQUMsRUFBRSxJQUFBQyxZQUFLLEVBQUMsQ0FBQyxDQUFDO0VBQzNCQyxLQUFLLEVBQUU7SUFDTEMsYUFBYSxFQUFFO01BQUVDLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBRSxTQUFTO0lBQUU7RUFDL0M7QUFDRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=