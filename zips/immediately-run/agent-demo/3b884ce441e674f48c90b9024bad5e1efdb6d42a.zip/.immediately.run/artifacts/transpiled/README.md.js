var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "agent-demo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "agent-demo"
      }), "agent-demo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "embedded-agent demo"
      }), " as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), " app\n(UI_AS_APPS_SPEC §5.5 / §5.9, guarantee G12). It reads this app's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "grant-filtered\nmethod catalog"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useCatalog()"
      }), ") and treats it as an agent's tool list — then runs\na tool via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invoke()"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The point is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "confinement"
      }), ": an LLM agent handed only this catalog can drive only\nwhat the app may already do. A method ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "outside"
      }), " the catalog, named directly, still\nhits the host's §8.4 gate and returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "forbidden"
      }), " — so agent sandboxing falls out\nof the capability model, with no separate agent jail. The \"Try spaces:share\" button\ndemonstrates this (the app holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spaces:app"
      }), ", not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spaces:admin"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm install && npm run dev\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsInAiLCJwcmUiLCJzdHJvbmciLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJhZ2VudC1kZW1vXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhZ2VudC1kZW1vXCIgLz57XCJhZ2VudC1kZW1vXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbWJlZGRlZC1hZ2VudCBkZW1vXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFzIGFuIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCIgYXBwXFxuKFVJX0FTX0FQUFNfU1BFQyDCpzUuNSAvIMKnNS45LCBndWFyYW50ZWUgRzEyKS4gSXQgcmVhZHMgdGhpcyBhcHAncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdyYW50LWZpbHRlcmVkXFxubWV0aG9kIGNhdGFsb2dcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZUNhdGFsb2coKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCB0cmVhdHMgaXQgYXMgYW4gYWdlbnQncyB0b29sIGxpc3Qg4oCUIHRoZW4gcnVuc1xcbmEgdG9vbCB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcG9pbnQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25maW5lbWVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogYW4gTExNIGFnZW50IGhhbmRlZCBvbmx5IHRoaXMgY2F0YWxvZyBjYW4gZHJpdmUgb25seVxcbndoYXQgdGhlIGFwcCBtYXkgYWxyZWFkeSBkby4gQSBtZXRob2QgXCJ9PF9jb21wb25lbnRzLmVtPntcIm91dHNpZGVcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgY2F0YWxvZywgbmFtZWQgZGlyZWN0bHksIHN0aWxsXFxuaGl0cyB0aGUgaG9zdCdzIMKnOC40IGdhdGUgYW5kIHJldHVybnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgc28gYWdlbnQgc2FuZGJveGluZyBmYWxscyBvdXRcXG5vZiB0aGUgY2FwYWJpbGl0eSBtb2RlbCwgd2l0aCBubyBzZXBhcmF0ZSBhZ2VudCBqYWlsLiBUaGUgXFxcIlRyeSBzcGFjZXM6c2hhcmVcXFwiIGJ1dHRvblxcbmRlbW9uc3RyYXRlcyB0aGlzICh0aGUgYXBwIGhvbGRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYWNlczphcHBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BhY2VzOmFkbWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cImRldmVsb3BcIiAvPntcIkRldmVsb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2Utc2hcIj57XCJucG0gaW5zdGFsbCAmJiBucG0gcnVuIGRldlxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1YsS0FBSyxDQUFDVztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1gsV0FBVztFQUNoQyxJQUFJLENBQUNXLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBZixXQUFBLENBQUFnQixJQUFBLEVBQUFoQixXQUFBLENBQUFpQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO01BQUNZLEVBQUUsRUFBQyxZQUFZO01BQUFELFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBWSxDQUFFLENBQUMsRUFBQyxZQUFZO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDUSxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLENBQUM7UUFBQ2lCLElBQUksRUFBQyx5QkFBeUI7UUFBQUgsUUFBQSxFQUFFO01BQWlCLENBQWdCLENBQUMsRUFBQywwRUFBMEUsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDUSxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFnQyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ00sQ0FBQztNQUFBUyxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNRLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLGdHQUFnRyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNHLEVBQUU7UUFBQVksUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLDZFQUE2RSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLEVBQUU7TUFBQ1csRUFBRSxFQUFDLFNBQVM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLEdBQUc7TUFBQVEsUUFBQSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQ2lCLFNBQVMsRUFBQyxhQUFhO1FBQUFKLFFBQUEsRUFBRTtNQUE4QixDQUFtQjtJQUFDLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDei9DO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ3JCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNzQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHVixLQUFLLENBQUNXO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQXpCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUt2QixLQUFLO0lBQUFnQixRQUFBLGVBQUUsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ25CLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN3QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}