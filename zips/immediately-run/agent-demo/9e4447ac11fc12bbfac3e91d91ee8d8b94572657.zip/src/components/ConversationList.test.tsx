// @vitest-environment happy-dom
// R3-612 — the first component tests in this repo (the item's harness: happy-dom +
// @testing-library/react, the SDK barrel mocked exactly as the lib tests mock it).
//
// What is under test is the ACCESSIBLE shape, not the pixels: the row is a plain
// <li> whose open control is a real button (WCAG 4.1.2 — two controls, two names),
// delete removes through the store, and a `conversation-updated` message patches
// the ONE row it names without re-listing the store (R-IX-4). Rows come from the
// REAL fs-injected store over MemFs — never a hand-typed array (R2).
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from "@testing-library/react";

vi.mock("@immediately-run/sdk", () => ({
  postToRegion: vi.fn(async () => {}),
  revealRegion: vi.fn(async () => {}),
  // R3-848: the host-mediated verb, spied from the click handler.
  openRepository: vi.fn(async () => {}),
  useWorkspace: vi.fn(() => null),
  onRegionMessage: vi.fn(
    (listener: (m: { from: string; data: unknown }) => void) => {
      regionListeners.push(listener);
      return () => {
        const i = regionListeners.indexOf(listener);
        if (i >= 0) regionListeners.splice(i, 1);
      };
    },
  ),
}));

// The store is REAL (fs-injected core over MemFs); only its mount resolution is
// replaced, so list/load/save/remove run the shipped code. One seeded row per
// store, created through the store itself — the list test fixture is store output,
// not a literal. (The vi.mock factory below is hoisted, so it reaches the impl
// through this holder rather than a top-level const.)
const storeHolder = vi.hoisted(() => ({
  make: null as null | (() => Promise<unknown>),
}));

vi.mock("../lib/conversationStore", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("../lib/conversationStore")>();
  return { ...actual, openConversationStore: () => storeHolder.make!() };
});

type SpiedStore = import("../lib/conversationStore").ConversationStore & {
  list: ReturnType<typeof vi.fn>;
  load: ReturnType<typeof vi.fn>;
  save: ReturnType<typeof vi.fn>;
  remove: ReturnType<typeof vi.fn>;
};
let lastStore: SpiedStore | null = null;

/** The one seeded-store builder: a REAL fs-injected store over MemFs, seeded
 *  through the store itself, then spy-wrapped. Both describes ride it. */
const makeSeededStore = async (
  seed: (store: import("../lib/conversationStore").ConversationStore) => Promise<void>,
): Promise<SpiedStore> => {
  const { createConversationStore } = await import("../lib/conversationStore");
  const { MemFs } = await import("../lib/testing/memStoreFs");
  const base = createConversationStore({
    recordRoot: "/settings",
    fs: new MemFs(),
    tabId: "tab-conversation-list",
  });
  await seed(base);
  const wrapped = {
    ...base,
    list: vi.fn(base.list.bind(base)),
    load: vi.fn(base.load.bind(base)),
    save: vi.fn(base.save.bind(base)),
    remove: vi.fn(base.remove.bind(base)),
  };
  lastStore = wrapped;
  return wrapped;
};

const makeStore = () => makeSeededStore(async (s) => {
  await s.create("notes");
});

import ConversationList from "./ConversationList";
import { STAGE_REGION } from "../lib/conversationIpc";
import { openRepository } from "@immediately-run/sdk";

const regionListeners: Array<(m: { from: string; data: unknown }) => void> = [];

beforeEach(() => {
  regionListeners.length = 0;
  lastStore = null;
  vi.mocked(openRepository).mockClear();
  vi.mocked(openRepository).mockImplementation(async () => {});
  // Restore the default factory — a describe that re-seeds `storeHolder.make`
  // must never leak its fixture into describes that run after it.
  storeHolder.make = makeStore;
});

afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

const postFromStage = (data: unknown): void => {
  for (const l of [...regionListeners]) l({ from: STAGE_REGION, data });
};

const renderWithNotesRow = async () => {
  render(<ConversationList />);
  await waitFor(() => expect(screen.getByText("notes")).toBeTruthy());
};

describe("ConversationList — the row is two controls, two names (R3-612 / WCAG 4.1.2)", () => {
  it("the open control is a real button named by its content, and never absorbs the delete label", async () => {
    await renderWithNotesRow();

    // The open control's accessible name is its content ("notes just now") — the
    // delete label ("Delete notes") must not be absorbed into it. (A regex /notes/
    // here would match BOTH controls — the delete row's name legitimately contains
    // the title; the defect under test is the OPEN control carrying "Delete …".)
    const open = screen.getByRole("button", { name: "notes just now" });
    expect(open.getAttribute("aria-label")).toBeNull();
    expect(open.textContent).not.toContain("Delete");
    expect(screen.getByRole("button", { name: "Delete notes" })).not.toBe(open);

    // The <li> itself is not interactive: no button role, no tabindex.
    const row = open.closest("li")!;
    expect(row.getAttribute("role")).toBeNull();
    expect(row.getAttribute("tabindex")).toBeNull();
  });

  it("delete removes through the store and the row goes", async () => {
    await renderWithNotesRow();
    const id = (await lastStore!.list())[0].id;

    fireEvent.click(screen.getByRole("button", { name: "Delete notes" }));

    await waitFor(() => expect(screen.queryByText("notes")).toBeNull());
    await waitFor(() => expect(lastStore!.remove).toHaveBeenCalledWith(id));
  });

  it("a conversation-updated message patches the ONE row it names and never calls list() again (R-IX-4)", async () => {
    await renderWithNotesRow();

    // The stage saved the conversation (retitled) and posted the id. Apply the
    // save through the SAME real store, then replay the message the stage posts.
    const id = (await lastStore!.list())[0].id;
    const saved = await lastStore!.load(id);
    expect(saved).toBeTruthy();
    await lastStore!.save({ ...saved!, title: "notes, renamed" });
    const listCalls = lastStore!.list.mock.calls.length;

    postFromStage({ type: "conversation-updated", id });

    await waitFor(() =>
      expect(screen.getByText("notes, renamed")).toBeTruthy(),
    );
    expect(lastStore!.list.mock.calls.length).toBe(listCalls);
    expect(lastStore!.load).toHaveBeenCalledWith(id);
  });

  it("the message for a row deleted elsewhere removes that row", async () => {
    await renderWithNotesRow();
    const id = (await lastStore!.list())[0].id;
    await lastStore!.remove(id);

    postFromStage({ type: "conversation-updated", id });

    await waitFor(() => expect(screen.queryByText("notes")).toBeNull());
  });
});

describe("ConversationList — the other-repositories count names what it counts (R3-475)", () => {
  // Two stamped repos ride the REAL store (one with two members, one with one), so
  // the group counts are the producer's own arithmetic; the workspace mock stays
  // null, so every stamped repo groups under "other repositories" by rule. The
  // factory swap is restored by the shared beforeEach, which resets it to makeStore.
  const seedWithOthers = () => {
    storeHolder.make = () =>
      makeSeededStore(async (s) => {
        await s.create("notes");
        await s.create("recipe plan", "other/repo");
        await s.create("recipe followup", "other/repo");
        await s.create("solo elsewhere", "third/repo");
      });
  };

  it("the count carries a hover label and an accessible text — singular and plural", async () => {
    seedWithOthers();
    render(<ConversationList />);
    await waitFor(() => expect(screen.getByText("Other repositories")).toBeTruthy());

    // The accessible form is REAL (visually hidden) text; the visible digit is
    // aria-hidden so the number is never announced as a bare "2".
    const pluralLabel = screen.getByText("2 conversations in other/repo");
    expect(pluralLabel.classList.contains("cl-vh")).toBe(true);
    const pluralDigit = screen.getByText("2");
    expect(pluralDigit.getAttribute("aria-hidden")).toBe("true");
    expect(pluralDigit.parentElement!.getAttribute("title")).toBe("2 conversations in other/repo");

    const singularLabel = screen.getByText("1 conversation in third/repo");
    expect(singularLabel.classList.contains("cl-vh")).toBe(true);
    const singularDigit = screen.getByText("1");
    expect(singularDigit.getAttribute("aria-hidden")).toBe("true");
    expect(singularDigit.parentElement!.getAttribute("title")).toBe("1 conversation in third/repo");
  });
});

// ── R3-848 — the other-repositories rows open their repository ───────────────
// Each row is a real button that calls the host-mediated openRepository() with
// the row's coordinates, synchronously from the click handler (an await before
// the call would lose the host's transient activation), and a refusal lands
// its code ON the row. Rows come from the REAL fs-injected store.
describe("ConversationList — other-repositories rows open the repository (R3-848)", () => {
  const makeOtherRepoStore = () =>
    makeSeededStore(async (s) => {
      await s.create("mine", "owner/current");
      // Stamped for ANOTHER repo, with its provider stamp.
      await s.create("elsewhere", "other/repo", "github");
    });

  const renderWithOthers = async () => {
    storeHolder.make = makeOtherRepoStore;
    render(<ConversationList />);
    // No workspace mocked ⇒ every stamped conversation groups under "other"
    // — which is exactly this fixture's shape. The rows render the GROUP's
    // repo label, never the conversation titles.
    await waitFor(() => expect(screen.getByText("other/repo")).toBeTruthy());
    // Open the <details> so the rows render.
    fireEvent.click(screen.getByText("Other repositories"));
  };

  it("a row is a real button whose click calls openRepository once, with the row's coordinates", async () => {
    await renderWithOthers();
    const row = screen.getByRole("button", { name: /other\/repo/ });
    fireEvent.click(row);
    expect(openRepository).toHaveBeenCalledTimes(1);
    expect(openRepository).toHaveBeenCalledWith({
      provider: "github",
      namespace: "other",
      repository: "repo",
    });
  });

  it("the call happens synchronously inside the handler — no await can slip in front of it", async () => {
    await renderWithOthers();
    // A pending promise: the handler cannot have awaited anything before the
    // call and still see the host's transient activation (an await before it is
    // the no-activation refusal this guard exists to prevent).
    let settle!: () => void;
    vi.mocked(openRepository).mockImplementation(
      () => new Promise<void>((res) => { settle = res; }),
    );
    const row = screen.getByRole("button", { name: /other\/repo/ });
    fireEvent.click(row);
    // Called IMMEDIATELY after the dispatch — before anything asynchronous ran.
    expect(openRepository).toHaveBeenCalledTimes(1);
    settle();
    await waitFor(() => expect(screen.queryByRole("status")).toBeNull());
  });

  it("a refusal lands its code on the row that asked", async () => {
    await renderWithOthers();
    vi.mocked(openRepository).mockRejectedValueOnce(
      Object.assign(new Error("repository open refused"), { code: "forbidden" }),
    );
    const row = screen.getByRole("button", { name: /other\/repo/ });
    fireEvent.click(row);
    await waitFor(() => expect(screen.getByRole("status").textContent).toBe("forbidden"));
  });

  it("a legacy group (no provider stamp) is REFUSED on the row, never opened under a guessed provider", async () => {
    // Round-1 review: the SDK's workspace can carry a `local` provider, so a
    // github default is the guess the item said not to make. The row refuses.
    storeHolder.make = () => makeSeededStore(async (s) => {
      await s.create("mine", "owner/current");
      await s.create("legacy", "old/repo"); // stamped before R3-848: no provider
    });
    render(<ConversationList />);
    await waitFor(() => expect(screen.getByText("old/repo")).toBeTruthy());
    fireEvent.click(screen.getByText("Other repositories"));
    fireEvent.click(screen.getByRole("button", { name: /old\/repo/ }));
    expect(openRepository).not.toHaveBeenCalled();
    await waitFor(() =>
      expect(screen.getByRole("status").textContent).toContain("no provider stamp"),
    );
  });

  it("a successful open clears the row's earlier refusal", async () => {
    await renderWithOthers();
    const row = screen.getByRole("button", { name: /other\/repo/ });
    vi.mocked(openRepository).mockRejectedValueOnce(
      Object.assign(new Error("repository open refused"), { code: "forbidden" }),
    );
    fireEvent.click(row);
    await waitFor(() => expect(screen.getByRole("status").textContent).toBe("forbidden"));
    vi.mocked(openRepository).mockResolvedValueOnce(undefined as never);
    fireEvent.click(row);
    await waitFor(() => expect(screen.queryByRole("status")).toBeNull());
  });
});
