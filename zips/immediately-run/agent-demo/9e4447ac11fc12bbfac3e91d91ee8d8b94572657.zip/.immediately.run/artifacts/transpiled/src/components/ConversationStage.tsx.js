var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ConversationStage;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _toolset = require("../lib/toolset");
var _fsTools = require("../lib/fsTools");
var _projectTools = require("../lib/projectTools");
var _diagnosticsTools = require("../lib/diagnosticsTools");
var _gitTools = require("../lib/gitTools");
var _agentPrompt = require("../lib/agentPrompt");
var _skills = require("../lib/skills");
var _chatModelClient = require("../lib/chatModelClient");
var _agentLoop = require("../lib/agentLoop");
var _runPause = require("../lib/runPause");
var _steering = require("../lib/steering");
var _resume = require("../lib/resume");
var _useLeaseRefresh = require("../hooks/useLeaseRefresh");
var _conversationStore = require("../lib/conversationStore");
var _sessionProjection = require("../lib/sessionProjection");
var _stageSelection = require("../lib/stageSelection");
var _useStickToBottom = require("../hooks/useStickToBottom");
var _transcript = require("../lib/transcript");
var _TranscriptRows = _interopRequireDefault(require("./TranscriptRows"));
var _ResumeAffordance = _interopRequireDefault(require("./ResumeAffordance"));
var _conversationIpc = require("../lib/conversationIpc");
var _storeError = require("../lib/storeError");
require("./CodingAgent.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The conversation STAGE — the stage-slot half of the agents activity (plan Phase
// 05, region `stage.conversation`). The analog of the editor: it loads the
// conversation the panel selected, shows its transcript, and runs the in-browser
// agent loop, persisting every turn. The loop, tools, streaming, and host-mediated
// BYOK are the same machinery the standalone CodingAgent uses (LLM_AND_AGENTS_SPEC
// §3.3); confinement is automatic (G12/T24): catalog ⊕ mount-chroot fs tools only.
// R-ARD-10: the copy for a dead settings store names BOTH costs — the amnesia
// (history not re-sent) and the durability consequence (a closed tab loses the
// run). One constant so a fourth call site cannot ship the old copy.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const NO_STORE_SUFFIX = ", so each message is sent without the earlier ones — and a closed tab loses the run, not just the in-flight turn";

// R-ARD-10a: the copy for a checkpoint-append refusal — the run stopped AT a
// boundary and everything checkpointed so far survives. One home, used by both
// run surfaces's journal-failure catches.
const JOURNAL_REFUSAL_SUFFIX = ", so the run stopped at its last checkpoint — nothing after it was kept";
function ConversationStage() {
  _s();
  const catalog = (0, _sdk.useCatalog)();
  const mounts = (0, _sdk.useMounts)();
  const storeRef = (0, _react.useRef)(null);
  const convRef = (0, _react.useRef)(null);
  // R3-631 — the session projection (CONTRIBUTE_TRANSCRIPT_SPEC §3): the writer and
  // the named-heartbeat publisher over it. Opened/built beside the store on the
  // SAME settings mount; a dead writer costs only the feature (the host never sees
  // a heartbeat ⇒ never offers ⇒ fail-closed), never the conversation. The trigger
  // semantics live in `sessionProjection.ts` (extracted like `stageSelection.ts`
  // so they are testable without a DOM); this component only names the moments.
  const projectionRef = (0, _react.useRef)(null);
  const publisherRef = (0, _react.useRef)(null);
  // R3-224 (§3.3): the stop button's abort controller for the in-flight run. Aborting
  // it halts the loop AND tears down the in-flight upstream LLM request (stops billing).
  const abortRef = (0, _react.useRef)(null);
  // R3-333: the mid-run steering queue. STOP (above) ends the run; STEER redirects it
  // without discarding the transcript. One controller per run, so a correction the
  // user took back never leaks into the next one.
  const steerRef = (0, _react.useRef)(null);
  const [queued, setQueued] = (0, _react.useState)([]);
  const [steerText, setSteerText] = (0, _react.useState)("");
  const [log, setLog] = (0, _react.useState)([]);
  const [prompt, setPrompt] = (0, _react.useState)("");
  const [streaming, setStreaming] = (0, _react.useState)("");
  // R3-335 — the in-flight reasoning for the current turn (cleared when the whole block
  // arrives and becomes a transcript row).
  const [thinking, setThinking] = (0, _react.useState)("");
  // R3-336 — the run's token accounting, including prompt-cache reads/writes where the
  // provider reports them. Surfacing it is what makes caching verifiable rather than
  // believed; without a number on screen the cost claim is unfalsifiable.
  const [usage, setUsage] = (0, _react.useState)(null);
  const [running, setRunning] = (0, _react.useState)(false);
  // Which conversation a run is in flight for — a ref, so the arbiter's per-id probe can
  // read it without rebuilding. Set when a run starts, cleared when it ends.
  const runningIdRef = (0, _react.useRef)(null);
  const [title, setTitle] = (0, _react.useState)("");
  // The conversation currently shown — keys the transcript scroller so a switch resets
  // its follow state (a release in one conversation must not carry into the next).
  const [convId, setConvId] = (0, _react.useState)(undefined);
  // Why persistence is unavailable, if it is. The conversation store is not a
  // nice-to-have: `run()` reads the model's HISTORY out of the persisted
  // conversation, so a dead store silently downgrades the agent to a stateless
  // chatbot that re-reads nothing between turns. That failure used to be
  // swallowed by empty `catch {}`s — surface it instead (R3-247).
  const [storeError, setStoreError] = (0, _react.useState)(null);
  /** R3-561 — another frame's run lease is live on this conversation. Renders as
   *  an OFFER to take over, never as a block (R-ARD-18a): the lease is advisory,
   *  the holder may be a window that no longer exists, and a hard block on it is a
   *  dead end the user cannot escape. Carries the action that was refused, so
   *  "take over" continues what the user asked for rather than making them ask
   *  twice. */
  const [leaseHeld, setLeaseHeld] = (0, _react.useState)(null);
  // R3-560: an interrupted run detected on this conversation — the journal says
  // a run was in flight and never reached its final `runEnd` B4. Resume is
  // ATTENDED (R-ARD-15): rendering this affordance is all the boot path does;
  // no model call, no executor, nothing until the user picks an action.
  const [pendingResume, setPendingResumeState] = (0, _react.useState)(null);
  // Ref mirror — the attended gate in run() must read the CURRENT value after
  // awaiting an in-flight replay, which a render-closed state variable cannot give.
  const pendingResumeRef = (0, _react.useRef)(null);
  const setPendingResume = v => {
    pendingResumeRef.current = v;
    setPendingResumeState(v);
  };
  // The boot replay currently in flight, if any — `run()` must not start past an
  // unresolved interruption check (the TOCTOU hole: a kickoff that slips between
  // the replay call and its result takes the restart-and-lose-tail path).
  const replayInFlightRef = (0, _react.useRef)(null);

  // R3-615 — follow the stream. The transcript and the live reasoning box each pin to
  // their newest row while the reader is at the bottom, and stop the moment they scroll
  // up — resuming only on return. Two scrollers, one hook, called twice.
  const logRef = (0, _react.useRef)(null);
  const reasoningRef = (0, _react.useRef)(null);
  // The transcript scroller follows everything that grows inside it — the settled rows,
  // the live reasoning block and the live reply — so it is keyed on all three, not just
  // the settled rows (the live rows stream without touching `log`).
  const transcriptFlow = (0, _react.useMemo)(() => [log, thinking, streaming], [log, thinking, streaming]);
  (0, _useStickToBottom.useStickToBottom)(logRef, transcriptFlow);
  (0, _useStickToBottom.useStickToBottom)(reasoningRef, thinking);

  // The STAGE app's working tree, conferred by the host as a `type:'worktree'` mount
  // (AA-23) — NOT the agent's OWN repo. If it isn't conferred (the mount hasn't arrived,
  // churned away, or no app is loaded), this is `null` and we MUST NOT fall back to the
  // agent's own repo: doing so made the workbench silently author *itself* (every
  // stage-app path read `not found`, and the model floundered). Re-derived when the
  // conferred mount changes (switching the loaded app tears down the old port, mints new).
  const stageTree = (0, _react.useMemo)(() => (0, _fsTools.findConferredWorktree)(mounts, (0, _sdk.getAppMountPath)()), [mounts]);

  // Tools given to the model. Without the stage tree the agent gets the catalog ONLY —
  // no filesystem tools — so it can never edit the wrong (its own) repo. Run is gated
  // below and a "workspace not ready" notice is shown.
  // R3-339 — does the model the user configured accept images? The tool is told, so a
  // `read_file` on a PNG can SAY the model cannot look at it instead of sending
  // something that errors upstream. Re-read when the provider changes.
  const vision = (0, _react.useMemo)(() => (0, _sdk.describeChat)()?.features.vision === true, []);
  const {
    toolset,
    skills
  } = (0, _react.useMemo)(() => {
    // No conferred stage tree ⇒ a catalog-only toolset with no authoring tools, so
    // `withSkills` offers nothing and `load_skill` is absent — the authoring skills
    // would be advice the agent cannot act on (R3-331).
    if (!stageTree) return (0, _skills.withSkills)((0, _toolset.catalogToolset)(catalog));
    const fsTools = (0, _fsTools.createFsToolset)({
      root: stageTree.root,
      readOnly: stageTree.readOnly,
      vision
    });
    const projectTools = (0, _projectTools.createProjectToolset)({
      root: stageTree.root,
      readOnly: stageTree.readOnly
    });
    const diagnosticsTools = (0, _diagnosticsTools.createDiagnosticsToolset)();
    // R3-332: git-READ over the same working tree. Empty (and therefore invisible to
    // the model) unless the app holds `vcs:read`.
    const gitTools = (0, _gitTools.createGitToolset)({
      catalog
    });
    // `withSkills` stays LAST (R3-331): which host skills are offered depends on the
    // final merged tool list, so it has to see the git tools too.
    return (0, _skills.withSkills)((0, _toolset.mergeToolsets)((0, _toolset.catalogToolset)(catalog), fsTools, projectTools, diagnosticsTools, gitTools));
  }, [catalog, stageTree, vision]);
  const append = e => setLog(l => [...l, e]);

  // R3-561 / R-ARD-18: refresh the lease on an interval while the run executes.
  // Shared with CodingAgent — the other run surface — rather than living here; see
  // `useLeaseRefresh` for why the boundary appends are not enough on their own,
  // and for why this loop does NOT raise the takeover offer (it cannot: the banner
  // renders only when the run is not running). A lost lease is surfaced by the
  // run's own catch below, from the typed code `append` rejects with.
  (0, _useLeaseRefresh.useLeaseRefresh)(storeRef, runningIdRef, running);

  /**
   * R3-561 — hand the run's lease back, from both run paths.
   *
   * ONE function because there were two copies and the second had already drifted:
   * `run`'s fired it, `resumeRun`'s awaited it, and the paragraph arguing against
   * awaiting had been dropped from the second copy. The file held the argument and
   * its violation ninety lines apart.
   *
   * It releases `runningIdRef`, NOT `convRef` — the conversation the RUN held, not
   * the one on screen. Selecting another conversation mid-run sets `convRef`
   * (`stageSelection`: "a run for a different conversation does not gate the
   * reload") while the loop keeps going, so releasing what is on screen freed
   * nothing and left the real lease to sit out its full TTL — offering a second
   * window a takeover of a run that had already finished, which is the one thing
   * this call exists to prevent. Callers invoke it BEFORE clearing `runningIdRef`.
   *
   * Fired, never awaited. Failing to run at all is already the expected case (no
   * unload handler reaches it), so making a run's promise wait on a device-local
   * read + unlink with no deadline would buy nothing and could leave it pending —
   * the argument `APPEND_TIMEOUT_MS` makes one file over. The TTL and same-tab
   * reclaim are what actually free a lease.
   */
  const releaseHeldLease = (0, _react.useCallback)(() => {
    const store = storeRef.current;
    const id = runningIdRef.current;
    if (store && id) void store.releaseRun(id).catch(() => {});
  }, []);
  const showConversation = (0, _react.useCallback)(conv => {
    convRef.current = conv;
    setConvId(conv.id);
    setTitle(conv.title);
    setLog((0, _transcript.messagesToLog)(conv.messages));
    setStreaming("");
    publisherRef.current?.onShow();
    // R3-560: is there an interrupted run on this conversation? Read the JOURNAL
    // (not warm state) and offer the attended choices if so. Read-only — the
    // boot path executes nothing (G-ARD-4). When interrupted, the transcript
    // rendered is the REPLAYED one — the record alone is folded through the last
    // run end and would show a blank/stale view over a live tail (R-ARD-15).
    setPendingResume(null);
    // R3-561: the takeover offer belongs to the conversation that raised it. Left
    // standing across a switch it would take over the NEW one — `takeOverRun`
    // deliberately consults no stored lease, so it would evict a live holder of a
    // conversation the user never asked about. Cleared here, and the render below
    // carries a `convId` guard the way `pendingResume` does.
    setLeaseHeld(null);
    const store = storeRef.current;
    if (store?.hasJournal()) {
      const promise = store.replay(conv.id).then(r => {
        if (convRef.current?.id !== conv.id || runningIdRef.current !== null) return;
        if (!(0, _resume.interrupted)(r)) return;
        setLog((0, _transcript.messagesToLog)(r.messages));
        setPendingResume({
          convId: conv.id,
          replay: r
        });
      }).catch(e => {
        // R-ARD-14 / §9: a refused journal (corrupt/schema/incoherent) means
        // the conversation is UN-RESUMABLE — say the resume was withheld,
        // never silently best-effort it. Other failures are store faults.
        if (convRef.current?.id !== conv.id) return;
        if ((0, _conversationStore.isJournalRefusal)(e)) {
          append({
            kind: "error",
            text: "This conversation's checkpoint journal can't be read, so its interrupted run can't be resumed — the saved conversation still opens."
          });
        } else {
          setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
        }
      }).finally(() => {
        // Promise-identity, not convId: a same-conversation re-select (the
        // panel's repair gesture) starts a NEWER replay whose marker the older
        // promise's finally must not clear.
        if (replayInFlightRef.current?.promise === promise) replayInFlightRef.current = null;
      });
      replayInFlightRef.current = {
        convId: conv.id,
        promise
      };
    }
  }, []);

  // One arbiter per mount (never module scope): it holds the held selection and the
  // latest-wins ticket, and is created fresh so a remount starts clean. Created in an
  // effect rather than during render — `show` = `showConversation` writes `convRef`, and
  // the React Compiler's `refs` rule forbids a ref access (or a function carrying one)
  // from reaching a render path.
  const stageSelectionRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    stageSelectionRef.current = (0, _stageSelection.createStageSelection)({
      show: showConversation,
      isRunning: id => runningIdRef.current === id
    });
    return () => {
      stageSelectionRef.current = null;
    };
  }, [showConversation]);

  // The SCOPING KEY — the repo conversations are stamped with and partitioned by.
  //
  // Read from the baseline workspace channel (R3-491), NOT from `stageTree.repo`,
  // even though both are the same string (R-UAA-16). The stamp and the panel's scope
  // have to come from ONE source: they are compared for equality, so the day the two
  // derivations diverge every existing stamp silently stops matching and every
  // conversation lands under "Other repositories" — which is the R3-475 bug, just
  // arrived by a different route. `stageTree` stays what it is actually for: the
  // filesystem root the agent authors.
  const workspace = (0, _sdk.useWorkspace)();
  const workspaceRepo = workspace?.label;
  // The stamp's PROVIDER half (R3-848): the label alone cannot say which
  // provider the repo lives under, and the other-repositories row that opens a
  // repo passes coordinates, never a guess. Stamped beside the label at every
  // site the label is stamped.
  const workspaceProvider = workspace?.provider;

  // Readable from the boot effect below without re-running it when the workspace
  // arrives (the effect opens the store ONCE; the fallback simply uses whatever repo
  // is known at that moment — the panel's select corrects it).
  const stageRepoRef = (0, _react.useRef)(workspaceRepo);
  (0, _react.useEffect)(() => {
    stageRepoRef.current = workspaceRepo;
  }, [workspaceRepo]);

  // Open the store; if no selection arrives, show the newest IN SCOPE (R3-475 —
  // the same repo partition the panel applies) so the stage isn't blank and never
  // seeds itself with another repo's conversation. The arbiter owns which of the
  // held selection / newest fallback wins, so a selection that landed before the
  // store opened is not dropped.
  (0, _react.useEffect)(() => {
    let live = true;
    void (async () => {
      try {
        const store = await (0, _conversationStore.openConversationStore)();
        if (!live) return;
        storeRef.current = store;
        setStoreError(null);
        await stageSelectionRef.current.storeOpened(store, stageRepoRef.current);
      } catch (e) {
        // Signed out is the ordinary case; anything else is a real fault the user
        // must see, because it costs them conversation memory.
        if (live) setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    })();
    // R3-631 — open the projection writer on the same mount, independently: a
    // store that fails while the writer opens (or vice versa) degrades exactly one
    // of the two surfaces. The publisher is built here (not during render) so no
    // ref-carrying function reaches a render path.
    projectionRef.current = null;
    publisherRef.current = (0, _sessionProjection.createProjectionPublisher)(() => projectionRef.current, () => ({
      conv: convRef.current,
      runningId: runningIdRef.current
    }));
    void (0, _sessionProjection.openSessionProjectionWriter)().then(w => {
      if (live) {
        projectionRef.current = w;
        // Catch-up: the store's open and the writer's open are independent
        // round-trips — if the stage already showed a conversation while this
        // was in flight, that onShow found no writer and dropped its heartbeat
        // (fail-closed, but the projection should not depend on open order).
        // Re-publishes current state once; per-id running gate; a null conv
        // publishes the harmless explicit-inactive doc.
        publisherRef.current?.onShow();
      }
    }).catch(e => {
      // No projection ⇒ the host never offers a transcript ⇒ fail-closed.
      // Logged-and-dropped (R3): a persistent fault should be visible somewhere.
      console.warn('session projection writer unavailable (transcript offers stay off)', e);
    });
    return () => {
      live = false;
      // Unmount ⇒ explicit inactive doc (best-effort; if the write loses the race
      // with teardown, the host's TTL expires the last heartbeat instead).
      publisherRef.current?.onUnmount();
      publisherRef.current = null;
      projectionRef.current = null;
    };
  }, []);

  // The panel drives which conversation is shown.
  (0, _react.useEffect)(() => {
    return (0, _sdk.onRegionMessage)(m => {
      if ((0, _conversationIpc.isSelect)(m.data)) void stageSelectionRef.current.select(m.data.id);
    });
  }, []);

  // Ask the panel what it has selected, once, on mount (R3-243).
  //
  // A `select-conversation` can be sent while this region does not exist: on mobile
  // the panel and the stage are different COLUMNS, and an unvisited column renders a
  // skeleton with no iframe — so the tap that reveals this pane is also the tap whose
  // selection had nowhere to land. Without this handshake the fallback above would
  // win and show the newest conversation instead of the tapped one.
  //
  // Subscribed BEFORE the ask (the listener above is already installed by the time
  // this effect runs), so the reply cannot arrive before anyone is listening. If the
  // panel is not there — a stage mounted on its own — nothing answers and the
  // newest-conversation fallback stands, exactly as before.
  (0, _react.useEffect)(() => {
    void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
      type: "request-selection"
    }).catch(() => {});
  }, []);
  const run = async () => {
    if (!prompt.trim() || running) return;
    // R3-560 (R-ARD-15, the attended gate): an interrupted run on THIS
    // conversation demands a choice first. A fresh kickoff past it would seed
    // history from the stale record, B0-replace the journal's transcript, and
    // fold-reclaim the interrupted tail — completed tool results vanishing from
    // the transcript while their file effects stay, the exact §0 divergence
    // this item exists to remove. Refuse; the affordance is one row above.
    // The interruption check may still be IN FLIGHT (boot replay) — wait for it
    // before deciding, or the gate has a hole exactly one tick wide.
    const convForGate = convRef.current;
    const inflight = replayInFlightRef.current;
    if (convForGate && inflight && inflight.convId === convForGate.id) {
      await inflight.promise;
    }
    const pending = pendingResumeRef.current;
    if (pending && convRef.current && pending.convId === convRef.current.id) {
      append({
        kind: "error",
        text: "This run was interrupted — choose Resume run, or Keep the files and end the run, before starting a new one."
      });
      return;
    }
    setPendingResume(null);
    // Refuse rather than author the wrong tree: with no conferred stage-app working
    // tree, the agent has no filesystem tools, so a "build me X" prompt would either
    // do nothing or (pre-fix) silently edit the agent's own repo. Tell the user.
    if (!stageTree) {
      append({
        kind: "user",
        text: prompt
      });
      append({
        kind: "error",
        text: "No app workspace is connected yet. Open an app in the stage (and give it a moment to mount) before asking me to edit it — I won't touch my own files."
      });
      setPrompt("");
      return;
    }
    const store = storeRef.current;
    // Ensure a conversation exists to attach this run to, stamped with the
    // workspace repo so the panel scopes it correctly (R3-475).
    let conv = convRef.current;
    if (!conv && store) {
      try {
        conv = await store.create(undefined, workspaceRepo, workspaceProvider);
        convRef.current = conv;
        stageSelectionRef.current.adopt(conv);
        setTitle(conv.title);
        setStoreError(null);
      } catch (e) {
        // Running ephemerally is a real degradation, not a detail: `history`
        // below falls back to [], so the model sees ONLY this prompt and the
        // conversation appears to have no memory. Say so (R3-247).
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    }
    // R3-561 / R-ARD-18: take the advisory run lease before executing anything.
    // A live lease held by another frame means the conversation may be running in
    // a window this one cannot see, and driving one working tree from two loops is
    // what the lease exists to avoid. `held` is an OFFER, never a block — see
    // `leaseHeld` — because the holder may be a frame that no longer exists.
    if (store && conv) {
      try {
        if ((await store.acquireRun(conv.id)) === "held") {
          setLeaseHeld({
            convId: conv.id,
            resume: false
          });
          return;
        }
      } catch (e) {
        // Wrapped for the same reason `store.create` three lines up is (R3-247): a
        // store call that rejects must not reach the user as an unhandled rejection
        // from a bare `void run()`. A lease we cannot read is not a lease we lost —
        // say the store is degraded and run, rather than refusing on an unknown.
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    }
    // R3-559: the checkpoint journal. When the device-local tier is wired, every
    // loop boundary is appended before the loop proceeds past it (B2 intent is
    // durable BEFORE its executor runs — R-ARD-10a); an append that fails or
    // times out unwinds the run AT that boundary with the durability consequence
    // named, and the journal already written stays resumable. Journalless
    // (R-ARD-10): the run is allowed to start, save-at-end only.
    const journal = conv && store?.hasJournal() ? conv : null;
    if (store && conv && !store.hasJournal() && !storeError) {
      setStoreError("Checkpoints are off (no device-local store), so closing this tab loses the run's in-flight turn — the conversation itself still saves when the run ends.");
    }
    const history = conv?.messages ?? [];
    const kickoff = prompt;
    setPrompt("");
    setRunning(true);
    runningIdRef.current = conv?.id ?? null;
    publisherRef.current?.onRunStart(conv?.id ?? null);
    setStreaming("");
    setThinking("");
    setUsage(null);
    append({
      kind: "user",
      text: kickoff
    });
    const controller = new AbortController();
    abortRef.current = controller;
    const steering = new _steering.SteerController();
    steerRef.current = steering;
    // R3-562 (§7 R-ARD-20a): the hide→pause join for this run — seeded from the
    // visibility at kickoff, driven by the host's push for the run's life
    // (src/lib/runPause.ts, extracted so the join is testable without a DOM).
    const {
      pause,
      dispose: disposePause
    } = (0, _runPause.createRunPause)();
    setQueued([]);
    const offSteerChange = steering.onChange(pending => setQueued([...pending]));
    // R3-560 (R-ARD-17): the prompt splits at a cache breakpoint — the PINNED
    // prefix (role, rules, workflow, the date frozen at run start) is stamped
    // into B0 so a resume replays these bytes exactly; the LIVE suffix (tools,
    // skills, workspace root) is rebuilt every time and the cache break at the
    // boundary is accepted, not worked around.
    const pinnedPrefix = (0, _agentPrompt.buildPinnedPrefix)({
      today: (0, _agentPrompt.todayIso)()
    });
    try {
      const transcript = await (0, _agentLoop.runAgent)({
        client: (0, _chatModelClient.createChatModelClient)(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: (0, _agentPrompt.composeSystemPrompt)(pinnedPrefix, (0, _agentPrompt.buildLiveSuffix)({
          tools: toolset.tools,
          workspaceRoot: stageTree?.root,
          skills
        })),
        workspace: workspaceRepo ?? undefined,
        systemPrefix: pinnedPrefix,
        history,
        prompt: kickoff,
        // R3-224 (§3.3): the stop button aborts the loop AND the in-flight LLM turn.
        signal: controller.signal,
        // R3-333: the steering queue — the other verb the human has.
        steering,
        // R3-562 (§7 R-ARD-20a): pause at turn boundaries while this region is hidden.
        pause,
        // Token accounting + auto-compaction let the loop run past ~12 turns (R3-220).
        contextWindow: (0, _sdk.describeChat)()?.features.maxContextTokens,
        events: {
          // R3-559: append every boundary to the conversation's journal. The loop
          // awaits this before proceeding — the write's latency IS the
          // intent-before-execute ordering.
          ...(journal ? {
            onBoundary: async b => {
              await store.append(journal.id, b);
            }
          } : {}),
          onAssistantDelta: text => setStreaming(s => s + text),
          // R3-335 — the live thinking surface. Now that compaction lets a task run past
          // a dozen turns, the silent stretches are longer, and "is it stuck or
          // thinking?" had no answer on screen.
          onReasoningDelta: text => setThinking(t => t + text),
          onReasoning: block => {
            setThinking("");
            append(block.redactedData !== undefined ? {
              kind: "reasoning",
              text: "",
              redacted: true
            } : {
              kind: "reasoning",
              text: block.text
            });
          },
          onAssistantText: text => {
            // A turn an `interrupt` steer cut short is its own row, live and on
            // replay — not a reply the model actually wrote.
            if (text === _steering.INTERRUPTED_TURN_TEXT) append({
              kind: "interrupted"
            });else if (text.trim()) append({
              kind: "text",
              text
            });
            setStreaming("");
          },
          onToolUse: (name, input) => append({
            kind: "tool",
            name,
            input
          }),
          onToolResult: (name, r) => append({
            kind: "result",
            name,
            content: r.content,
            isError: r.isError
          }),
          onNudge: () => append({
            kind: "nudge"
          }),
          onUsage: u => setUsage({
            spentTokens: u.spentTokens,
            cacheReadTokens: u.cacheReadTokens,
            cacheWriteTokens: u.cacheWriteTokens
          }),
          onCompact: ({
            summarizedCount,
            cacheReadTokens
          }) => {
            append({
              kind: "compaction",
              // R3-336: the compaction rewrote the conversation prefix, so the next turn
              // re-warms it. The durable system+tools prefix is untouched. Recording the
              // running cache total AT the boundary is what lets the cost curve across a
              // compaction be read rather than assumed.
              summary: `${summarizedCount} earlier messages summarized` + (cacheReadTokens !== undefined ? ` · ${cacheReadTokens} cached tokens read so far` : "")
            });
            // R3-559 (R-ARD-9): compaction is a natural fold point — it rewrote the
            // transcript prefix anyway. Best-effort mid-run: a failed fold costs the
            // fold, never the run (the journal retains everything; the run-end fold
            // is the authoritative write), so it is logged-and-dropped, not thrown.
            if (journal) {
              void store.fold(journal.id).catch(e => {
                console.warn("mid-run fold at compaction failed (run-end fold still will)", e);
              });
            }
          },
          onSteer: ({
            messages
          }) => {
            for (const m of messages) append({
              kind: "steer",
              mode: m.mode,
              text: m.text
            });
          }
        }
      });
      if (conv && store) {
        const newTitle = conv.title === "New conversation" ? (0, _conversationStore.deriveTitle)(transcript) : conv.title;
        try {
          // R3-559: the run-end save is now a FOLD (R-ARD-9) — the record gets
          // the authoritative transcript (byte-true to what the model saw), the
          // fold watermark, and the carried run-state; the superseded journal
          // entries are reclaimed (R-ARD-5c).
          convRef.current = await store.fold(conv.id, {
            messages: transcript,
            title: newTitle,
            repo: conv.repo ?? workspaceRepo,
            ...(conv.repo === undefined ? {
              repoProvider: workspaceProvider
            } : {})
          });
          setTitle(newTitle);
          setStoreError(null);
          // R3-631 — the save is the natural heartbeat: messageCount grew.
          publisherRef.current?.onSaved();
          void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
            type: "conversation-updated",
            id: conv.id
          }).catch(() => {});
        } catch (e) {
          // A failed save means `convRef.current` keeps the PRE-run messages, so the
          // next turn re-sends a stale (or empty) history — the same amnesia as a
          // dead store, one turn later. Never silent (R3-247).
          setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
        }
      }
    } catch (e) {
      // R3-561: the two lease codes are UX states, not codes to print (§9). The
      // discrimination and the copy live in `lib/storeError` — pasting them here
      // is what made the resume catch below get missed the first time.
      const lease = (0, _storeError.leaseFailure)(e);
      if (lease) {
        append({
          kind: "error",
          text: (0, _storeError.leaseFailureText)(lease, true)
        });
        if (lease === "lease-lost") {
          setLeaseHeld({
            convId: runningIdRef.current ?? convRef.current?.id ?? "",
            resume: false
          });
        }
      } else {
        append({
          kind: "error",
          text: e?.message ?? String(e)
        });
      }
      // R3-559 (R-ARD-10a): a failed checkpoint append unwinds the run here. Name
      // the durability consequence — the run stopped AT a boundary and everything
      // checkpointed so far survives (the journal stays resumable).
      if ((0, _conversationStore.isJournalRefusal)(e)) {
        setStoreError((0, _storeError.describeStoreFailure)(e, JOURNAL_REFUSAL_SUFFIX));
      }
    } finally {
      offSteerChange();
      steerRef.current = null;
      disposePause();
      setQueued([]);
      setSteerText("");
      setStreaming("");
      setThinking("");
      setRunning(false);
      releaseHeldLease(); // BEFORE runningIdRef is cleared — it is the id to release
      runningIdRef.current = null;
      abortRef.current = null;
      publisherRef.current?.onRunEnd();
    }
  };

  // R3-224 (§3.3): stop the in-flight run — aborts the loop between tool calls AND the
  // in-flight LLM request (the host tears down the upstream provider fetch, stops billing).
  const stop = (0, _react.useCallback)(() => {
    abortRef.current?.abort();
  }, []);

  // ---- R3-560: the attended-resume choices (R-ARD-15) ------------------------------
  //
  // Booting an interrupted conversation offered three spec'd choices; the third —
  // "discard the tail AND revert the run's writes" — is NOT offered here because
  // the app cannot bound which writes were the run's (the CoW layer is
  // host-side), and a discard that silently keeps the files manufactures exactly
  // the divergence this work exists to remove. The disposition is recorded in
  // AGENT_RUN_DURABILITY_SPEC §5.3; the keep-choice copy says plainly that the
  // file changes stay.

  /** Resume the interrupted run: repair the transcript, name any divergence,
   *  and continue the loop WITHOUT a new prompt turn. */
  const resumeRun = async () => {
    const store = storeRef.current;
    const pending = pendingResume;
    const conv = convRef.current;
    if (!store || !pending || !conv || running || pending.convId !== conv.id) return;
    // The same workspace-readiness gate as a fresh Run: a resume authors files
    // through the conferred stage tree, and without it the loop would run
    // catalog-only or (pre-R3-569) against the wrong tree. Refuse, say why.
    if (!stageTree) {
      append({
        kind: "error",
        text: "No app workspace is connected yet. Open an app in the stage (and give it a moment to mount) before resuming — I won't touch my own files."
      });
      return;
    }
    // R3-561: same gate as a fresh Run. A reload mid-run is a NEW frame with a new
    // tabId, so same-tab reclaim does not cover it and the dead frame's lease is
    // still live until its TTL — which is exactly the case the takeover offer is
    // for. The host cannot tell a reload from a second tab, and pretending it can
    // would be the double-drive this mechanism exists to prevent.
    try {
      if ((await store.acquireRun(conv.id)) === "held") {
        setLeaseHeld({
          convId: conv.id,
          resume: true
        });
        return;
      }
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
    }
    setPendingResume(null);
    const replay = pending.replay;
    const repaired = (0, _resume.repairTranscript)({
      messages: replay.messages,
      pendingEffects: replay.pendingEffects,
      trailingPartial: replay.trailingPartial
    });
    // R-ARD-16: say what moved, in the transcript, before the model works. An
    // UNSETTLED workspace channel (undefined) claims nothing — never fabricate
    // a divergence from an unknown.
    const divergence = (0, _resume.divergenceMessage)(replay.stampedWorkspace, workspaceRepo);
    const resumed = (0, _resume.resumedMessages)(repaired.messages, divergence);
    setLog((0, _transcript.messagesToLog)(repaired.messages));
    setRunning(true);
    runningIdRef.current = conv.id;
    publisherRef.current?.onRunStart(conv.id);
    setStreaming("");
    setThinking("");
    append({
      kind: "steer",
      mode: "queue",
      text: "Run resumed from its last checkpoint"
    });
    const controller = new AbortController();
    abortRef.current = controller;
    const steeringC = new _steering.SteerController();
    steerRef.current = steeringC;
    // R3-562: the same hide→pause join as a fresh run — a resumed run is equally
    // invisible when the region is hidden.
    const {
      pause,
      dispose: disposePause
    } = (0, _runPause.createRunPause)();
    setQueued([]);
    const offSteerChange = steeringC.onChange(q => setQueued([...q]));
    // R-ARD-17: the PINNED prefix replays byte-identically from the journal (the
    // frozen date survives midnight); the LIVE suffix is rebuilt from the
    // current catalog — a revoked tool is absent, honestly taking the cache miss.
    const pinnedPrefix = replay.systemPrefix ?? (0, _agentPrompt.buildPinnedPrefix)({
      today: (0, _agentPrompt.todayIso)()
    });
    try {
      const transcript = await (0, _agentLoop.runAgent)({
        client: (0, _chatModelClient.createChatModelClient)(),
        tools: toolset.tools,
        execute: toolset.execute,
        system: (0, _agentPrompt.composeSystemPrompt)(pinnedPrefix, (0, _agentPrompt.buildLiveSuffix)({
          tools: toolset.tools,
          workspaceRoot: stageTree?.root,
          skills
        })),
        workspace: workspaceRepo ?? undefined,
        systemPrefix: pinnedPrefix,
        resume: {
          messages: resumed,
          ...(replay.runState !== null ? {
            runState: replay.runState
          } : {})
        },
        signal: controller.signal,
        steering: steeringC,
        pause,
        contextWindow: (0, _sdk.describeChat)()?.features.maxContextTokens,
        events: {
          onBoundary: async b => {
            await store.append(conv.id, b);
          },
          onAssistantDelta: text => setStreaming(s => s + text),
          onReasoningDelta: text => setThinking(t => t + text),
          onReasoning: block => {
            setThinking("");
            append(block.redactedData !== undefined ? {
              kind: "reasoning",
              text: "",
              redacted: true
            } : {
              kind: "reasoning",
              text: block.text
            });
          },
          onAssistantText: text => {
            if (text === _steering.INTERRUPTED_TURN_TEXT) append({
              kind: "interrupted"
            });else if (text.trim()) append({
              kind: "text",
              text
            });
            setStreaming("");
          },
          onToolUse: (name, input) => append({
            kind: "tool",
            name,
            input
          }),
          onToolResult: (name, r) => append({
            kind: "result",
            name,
            content: r.content,
            isError: r.isError
          }),
          onNudge: () => append({
            kind: "nudge"
          }),
          onUsage: u => setUsage({
            spentTokens: u.spentTokens,
            cacheReadTokens: u.cacheReadTokens,
            cacheWriteTokens: u.cacheWriteTokens
          }),
          onCompact: ({
            summarizedCount
          }) => {
            append({
              kind: "compaction",
              summary: `${summarizedCount} earlier messages summarized`
            });
            void store.fold(conv.id).catch(e => console.warn("mid-run fold at compaction failed (run-end fold still will)", e));
          },
          onSteer: ({
            messages
          }) => {
            for (const m of messages) append({
              kind: "steer",
              mode: m.mode,
              text: m.text
            });
          }
        }
      });
      try {
        convRef.current = await store.fold(conv.id, {
          messages: transcript,
          repo: conv.repo ?? workspaceRepo,
          ...(conv.repo === undefined ? {
            repoProvider: workspaceProvider
          } : {})
        });
        setStoreError(null);
        publisherRef.current?.onSaved();
        void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
          type: "conversation-updated",
          id: conv.id
        }).catch(() => {});
      } catch (e) {
        setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
      }
    } catch (e) {
      // R3-561: the same mapping as `run`'s catch. This is the path the takeover
      // button itself invokes, so a user who takes over a resumable run and loses
      // the lease again lands here — it printed the raw internal string until the
      // discrimination moved into `lib/storeError`.
      const lease = (0, _storeError.leaseFailure)(e);
      if (lease) {
        append({
          kind: "error",
          text: (0, _storeError.leaseFailureText)(lease, true)
        });
        if (lease === "lease-lost") {
          setLeaseHeld({
            convId: runningIdRef.current ?? convRef.current?.id ?? "",
            resume: true
          });
        }
      } else {
        append({
          kind: "error",
          text: e?.message ?? String(e)
        });
      }
      if ((0, _conversationStore.isJournalRefusal)(e)) {
        setStoreError((0, _storeError.describeStoreFailure)(e, JOURNAL_REFUSAL_SUFFIX));
      }
    } finally {
      offSteerChange();
      steerRef.current = null;
      disposePause();
      setQueued([]);
      setSteerText("");
      setStreaming("");
      setThinking("");
      setRunning(false);
      releaseHeldLease(); // BEFORE runningIdRef is cleared — it is the id to release
      runningIdRef.current = null;
      abortRef.current = null;
      publisherRef.current?.onRunEnd();
    }
  };

  /** Keep the files, end the run: fold the repaired transcript so the journal's
   *  watermark advances and the conversation closes cleanly. The FILE CHANGES
   *  STAY — the copy says so (spec §5.3's rev-2 trap). */
  const keepAndClose = async () => {
    const store = storeRef.current;
    const pending = pendingResume;
    const conv = convRef.current;
    if (!store || !pending || !conv || pending.convId !== conv.id) return;
    setPendingResume(null);
    const repaired = (0, _resume.repairTranscript)({
      messages: pending.replay.messages,
      pendingEffects: pending.replay.pendingEffects,
      trailingPartial: pending.replay.trailingPartial
    });
    try {
      convRef.current = await store.fold(conv.id, {
        messages: repaired.messages,
        repo: conv.repo ?? workspaceRepo,
        ...(conv.repo === undefined ? {
          repoProvider: workspaceProvider
        } : {})
      });
      setLog((0, _transcript.messagesToLog)(repaired.messages));
      setStoreError(null);
      void (0, _sdk.postToRegion)(_conversationIpc.PANEL_REGION, {
        type: "conversation-updated",
        id: conv.id
      }).catch(() => {});
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
    }
  };

  // R3-333: the OTHER verb. `queue` applies at the next turn boundary (the in-flight
  // turn finishes); `interrupt` ends the in-flight model turn now and continues with
  // the correction. Neither ends the run — that is what Stop is for.
  const steer = (0, _react.useCallback)(mode => {
    const s = steerRef.current;
    if (!s) return;
    if (s.enqueue(steerText, mode)) setSteerText("");
  }, [steerText]);
  const cancelSteer = (0, _react.useCallback)(id => {
    steerRef.current?.cancel(id);
  }, []);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ca ca--stage",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ca-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-title",
        children: title || "Conversation"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "ca-sub",
        children: [toolset.tools.length, " tools ", stageTree ? "(catalog + files)" : "(catalog only)", usage && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [" · ", usage.spentTokens.toLocaleString(), " tokens", usage.cacheReadTokens !== undefined && ` · ${usage.cacheReadTokens.toLocaleString()} cached`]
        })]
      })]
    }), !stageTree && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: "Waiting for the app's workspace to connect\u2026 file tools are unavailable until then (I won't edit my own files)."
      })
    }), storeError && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: storeError
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      className: "ca-log",
      "aria-live": "polite",
      ref: logRef,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_TranscriptRows.default, {
        log: log
      }), thinking && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
          className: "ca-reasoning",
          open: true,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("summary", {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "ca-thinking-dot",
              "aria-hidden": "true"
            }), "thinking\u2026"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "ca-reasoning-body",
            ref: reasoningRef,
            children: thinking
          })]
        })
      }), streaming && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "ca-line ca-text ca-live",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-text",
          children: streaming
        })
      })]
    }, convId ?? "none"), queued.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "ca-queued",
      "aria-label": "Queued corrections",
      children: queued.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "ca-queued-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-queued-mode",
          children: m.mode === "interrupt" ? "now" : "next step"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ca-queued-text",
          children: m.text
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-queued-cancel",
          "aria-label": `Cancel queued correction: ${m.text}`,
          onClick: () => cancelSteer(m.id),
          children: "\xD7"
        })]
      }, m.id))
    }), pendingResume && !running && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ResumeAffordance.default, {
      journalDepth: pendingResume.replay.journalDepth,
      onResume: () => void resumeRun(),
      onKeepAndEnd: () => void keepAndClose()
    }), leaseHeld && !running && leaseHeld.convId === convId && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-line ca-error",
      role: "status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ca-err",
        children: (0, _storeError.leaseHeldText)(true)
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "ca-resume-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-run",
          onClick: () => {
            const {
              resume: wasResume,
              convId: forConv
            } = leaseHeld;
            void (async () => {
              try {
                const store = storeRef.current;
                // The offer stays up until the takeover actually lands. An
                // earlier version dismissed it first, so a rejected write left
                // the user with no offer, no run and no message.
                if (store) await store.takeOverRun(forConv);
                setLeaseHeld(null);
              } catch (e) {
                setStoreError((0, _storeError.describeStoreFailure)(e, NO_STORE_SUFFIX));
                return;
              }
              await (wasResume ? resumeRun() : run());
            })();
          },
          children: "Take over"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn",
          onClick: () => setLeaseHeld(null),
          children: "Leave it alone"
        })]
      })]
    }), running && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "ca-steer-hint",
      role: "status",
      children: steerText.trim() ? "The agent is working. Type here to redirect it." : "Type a message to steer"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ca-prompt-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "ca-prompt",
        placeholder: running ? "Steer the agent — say what to do differently…" : "Ask the agent to read, search, or edit your app…",
        value: running ? steerText : prompt,
        onChange: e => running ? setSteerText(e.target.value) : setPrompt(e.target.value),
        onKeyDown: e => {
          if (e.key !== "Enter") return;
          if (running) steer("queue");else void run();
        },
        "aria-label": running ? "Steer the agent" : "Prompt"
      }), running && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn",
          disabled: !steerText.trim(),
          onClick: () => steer("queue"),
          children: "Send after this step"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "ca-steer-btn ca-steer-now",
          disabled: !steerText.trim(),
          onClick: () => steer("interrupt"),
          children: "Send now"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ca-run"
        // While running, the button becomes a live Stop control (R3-224): it must
        // stay enabled so the user can abort the in-flight turn and stop billing.
        ,
        disabled: running ? false : !stageTree,
        title: running ? "End the run and abort the in-flight request" : !stageTree ? "Waiting for the app's workspace to connect" : undefined,
        onClick: () => running ? stop() : void run(),
        children: running ? "Stop" : "Run"
      })]
    })]
  });
}
_s(ConversationStage, "xLvYY7rzmZU7SJI2X+JTxhu+uz4=", false, function () {
  return [_sdk.useCatalog, _sdk.useMounts, _useStickToBottom.useStickToBottom, _useStickToBottom.useStickToBottom, _useLeaseRefresh.useLeaseRefresh, _sdk.useWorkspace];
});
_c = ConversationStage;
var _c;
$RefreshReg$(_c, "ConversationStage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl90b29sc2V0IiwiX2ZzVG9vbHMiLCJfcHJvamVjdFRvb2xzIiwiX2RpYWdub3N0aWNzVG9vbHMiLCJfZ2l0VG9vbHMiLCJfYWdlbnRQcm9tcHQiLCJfc2tpbGxzIiwiX2NoYXRNb2RlbENsaWVudCIsIl9hZ2VudExvb3AiLCJfcnVuUGF1c2UiLCJfc3RlZXJpbmciLCJfcmVzdW1lIiwiX3VzZUxlYXNlUmVmcmVzaCIsIl9jb252ZXJzYXRpb25TdG9yZSIsIl9zZXNzaW9uUHJvamVjdGlvbiIsIl9zdGFnZVNlbGVjdGlvbiIsIl91c2VTdGlja1RvQm90dG9tIiwiX3RyYW5zY3JpcHQiLCJfVHJhbnNjcmlwdFJvd3MiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1Jlc3VtZUFmZm9yZGFuY2UiLCJfY29udmVyc2F0aW9uSXBjIiwiX3N0b3JlRXJyb3IiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiTk9fU1RPUkVfU1VGRklYIiwiSk9VUk5BTF9SRUZVU0FMX1NVRkZJWCIsIkNvbnZlcnNhdGlvblN0YWdlIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJzdG9yZVJlZiIsInVzZVJlZiIsImNvbnZSZWYiLCJwcm9qZWN0aW9uUmVmIiwicHVibGlzaGVyUmVmIiwiYWJvcnRSZWYiLCJzdGVlclJlZiIsInF1ZXVlZCIsInNldFF1ZXVlZCIsInVzZVN0YXRlIiwic3RlZXJUZXh0Iiwic2V0U3RlZXJUZXh0IiwibG9nIiwic2V0TG9nIiwicHJvbXB0Iiwic2V0UHJvbXB0Iiwic3RyZWFtaW5nIiwic2V0U3RyZWFtaW5nIiwidGhpbmtpbmciLCJzZXRUaGlua2luZyIsInVzYWdlIiwic2V0VXNhZ2UiLCJydW5uaW5nIiwic2V0UnVubmluZyIsInJ1bm5pbmdJZFJlZiIsInRpdGxlIiwic2V0VGl0bGUiLCJjb252SWQiLCJzZXRDb252SWQiLCJ1bmRlZmluZWQiLCJzdG9yZUVycm9yIiwic2V0U3RvcmVFcnJvciIsImxlYXNlSGVsZCIsInNldExlYXNlSGVsZCIsInBlbmRpbmdSZXN1bWUiLCJzZXRQZW5kaW5nUmVzdW1lU3RhdGUiLCJwZW5kaW5nUmVzdW1lUmVmIiwic2V0UGVuZGluZ1Jlc3VtZSIsInYiLCJjdXJyZW50IiwicmVwbGF5SW5GbGlnaHRSZWYiLCJsb2dSZWYiLCJyZWFzb25pbmdSZWYiLCJ0cmFuc2NyaXB0RmxvdyIsInVzZU1lbW8iLCJ1c2VTdGlja1RvQm90dG9tIiwic3RhZ2VUcmVlIiwiZmluZENvbmZlcnJlZFdvcmt0cmVlIiwiZ2V0QXBwTW91bnRQYXRoIiwidmlzaW9uIiwiZGVzY3JpYmVDaGF0IiwiZmVhdHVyZXMiLCJ0b29sc2V0Iiwic2tpbGxzIiwid2l0aFNraWxscyIsImNhdGFsb2dUb29sc2V0IiwiZnNUb29scyIsImNyZWF0ZUZzVG9vbHNldCIsInJvb3QiLCJyZWFkT25seSIsInByb2plY3RUb29scyIsImNyZWF0ZVByb2plY3RUb29sc2V0IiwiZGlhZ25vc3RpY3NUb29scyIsImNyZWF0ZURpYWdub3N0aWNzVG9vbHNldCIsImdpdFRvb2xzIiwiY3JlYXRlR2l0VG9vbHNldCIsIm1lcmdlVG9vbHNldHMiLCJhcHBlbmQiLCJsIiwidXNlTGVhc2VSZWZyZXNoIiwicmVsZWFzZUhlbGRMZWFzZSIsInVzZUNhbGxiYWNrIiwic3RvcmUiLCJpZCIsInJlbGVhc2VSdW4iLCJjYXRjaCIsInNob3dDb252ZXJzYXRpb24iLCJjb252IiwibWVzc2FnZXNUb0xvZyIsIm1lc3NhZ2VzIiwib25TaG93IiwiaGFzSm91cm5hbCIsInByb21pc2UiLCJyZXBsYXkiLCJ0aGVuIiwiciIsImludGVycnVwdGVkIiwiaXNKb3VybmFsUmVmdXNhbCIsImtpbmQiLCJ0ZXh0IiwiZGVzY3JpYmUiLCJmaW5hbGx5Iiwic3RhZ2VTZWxlY3Rpb25SZWYiLCJ1c2VFZmZlY3QiLCJjcmVhdGVTdGFnZVNlbGVjdGlvbiIsInNob3ciLCJpc1J1bm5pbmciLCJ3b3Jrc3BhY2UiLCJ1c2VXb3Jrc3BhY2UiLCJ3b3Jrc3BhY2VSZXBvIiwibGFiZWwiLCJ3b3Jrc3BhY2VQcm92aWRlciIsInByb3ZpZGVyIiwic3RhZ2VSZXBvUmVmIiwibGl2ZSIsIm9wZW5Db252ZXJzYXRpb25TdG9yZSIsInN0b3JlT3BlbmVkIiwiY3JlYXRlUHJvamVjdGlvblB1Ymxpc2hlciIsInJ1bm5pbmdJZCIsIm9wZW5TZXNzaW9uUHJvamVjdGlvbldyaXRlciIsInciLCJjb25zb2xlIiwid2FybiIsIm9uVW5tb3VudCIsIm9uUmVnaW9uTWVzc2FnZSIsIm0iLCJpc1NlbGVjdCIsImRhdGEiLCJzZWxlY3QiLCJwb3N0VG9SZWdpb24iLCJQQU5FTF9SRUdJT04iLCJ0eXBlIiwicnVuIiwidHJpbSIsImNvbnZGb3JHYXRlIiwiaW5mbGlnaHQiLCJwZW5kaW5nIiwiY3JlYXRlIiwiYWRvcHQiLCJhY3F1aXJlUnVuIiwicmVzdW1lIiwiam91cm5hbCIsImhpc3RvcnkiLCJraWNrb2ZmIiwib25SdW5TdGFydCIsImNvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJzdGVlcmluZyIsIlN0ZWVyQ29udHJvbGxlciIsInBhdXNlIiwiZGlzcG9zZSIsImRpc3Bvc2VQYXVzZSIsImNyZWF0ZVJ1blBhdXNlIiwib2ZmU3RlZXJDaGFuZ2UiLCJvbkNoYW5nZSIsInBpbm5lZFByZWZpeCIsImJ1aWxkUGlubmVkUHJlZml4IiwidG9kYXkiLCJ0b2RheUlzbyIsInRyYW5zY3JpcHQiLCJydW5BZ2VudCIsImNsaWVudCIsImNyZWF0ZUNoYXRNb2RlbENsaWVudCIsInRvb2xzIiwiZXhlY3V0ZSIsInN5c3RlbSIsImNvbXBvc2VTeXN0ZW1Qcm9tcHQiLCJidWlsZExpdmVTdWZmaXgiLCJ3b3Jrc3BhY2VSb290Iiwic3lzdGVtUHJlZml4Iiwic2lnbmFsIiwiY29udGV4dFdpbmRvdyIsIm1heENvbnRleHRUb2tlbnMiLCJldmVudHMiLCJvbkJvdW5kYXJ5IiwiYiIsIm9uQXNzaXN0YW50RGVsdGEiLCJzIiwib25SZWFzb25pbmdEZWx0YSIsInQiLCJvblJlYXNvbmluZyIsImJsb2NrIiwicmVkYWN0ZWREYXRhIiwicmVkYWN0ZWQiLCJvbkFzc2lzdGFudFRleHQiLCJJTlRFUlJVUFRFRF9UVVJOX1RFWFQiLCJvblRvb2xVc2UiLCJuYW1lIiwiaW5wdXQiLCJvblRvb2xSZXN1bHQiLCJjb250ZW50IiwiaXNFcnJvciIsIm9uTnVkZ2UiLCJvblVzYWdlIiwidSIsInNwZW50VG9rZW5zIiwiY2FjaGVSZWFkVG9rZW5zIiwiY2FjaGVXcml0ZVRva2VucyIsIm9uQ29tcGFjdCIsInN1bW1hcml6ZWRDb3VudCIsInN1bW1hcnkiLCJmb2xkIiwib25TdGVlciIsIm1vZGUiLCJuZXdUaXRsZSIsImRlcml2ZVRpdGxlIiwicmVwbyIsInJlcG9Qcm92aWRlciIsIm9uU2F2ZWQiLCJsZWFzZSIsImxlYXNlRmFpbHVyZSIsImxlYXNlRmFpbHVyZVRleHQiLCJtZXNzYWdlIiwiU3RyaW5nIiwib25SdW5FbmQiLCJzdG9wIiwiYWJvcnQiLCJyZXN1bWVSdW4iLCJyZXBhaXJlZCIsInJlcGFpclRyYW5zY3JpcHQiLCJwZW5kaW5nRWZmZWN0cyIsInRyYWlsaW5nUGFydGlhbCIsImRpdmVyZ2VuY2UiLCJkaXZlcmdlbmNlTWVzc2FnZSIsInN0YW1wZWRXb3Jrc3BhY2UiLCJyZXN1bWVkIiwicmVzdW1lZE1lc3NhZ2VzIiwic3RlZXJpbmdDIiwicSIsInJ1blN0YXRlIiwia2VlcEFuZENsb3NlIiwic3RlZXIiLCJlbnF1ZXVlIiwiY2FuY2VsU3RlZXIiLCJjYW5jZWwiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJsZW5ndGgiLCJGcmFnbWVudCIsInRvTG9jYWxlU3RyaW5nIiwicm9sZSIsInJlZiIsIm9wZW4iLCJtYXAiLCJvbkNsaWNrIiwiam91cm5hbERlcHRoIiwib25SZXN1bWUiLCJvbktlZXBBbmRFbmQiLCJsZWFzZUhlbGRUZXh0Iiwid2FzUmVzdW1lIiwiZm9yQ29udiIsInRha2VPdmVyUnVuIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsInRhcmdldCIsIm9uS2V5RG93biIsImtleSIsImRpc2FibGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb252ZXJzYXRpb25TdGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGNvbnZlcnNhdGlvbiBTVEFHRSDigJQgdGhlIHN0YWdlLXNsb3QgaGFsZiBvZiB0aGUgYWdlbnRzIGFjdGl2aXR5IChwbGFuIFBoYXNlXG4vLyAwNSwgcmVnaW9uIGBzdGFnZS5jb252ZXJzYXRpb25gKS4gVGhlIGFuYWxvZyBvZiB0aGUgZWRpdG9yOiBpdCBsb2FkcyB0aGVcbi8vIGNvbnZlcnNhdGlvbiB0aGUgcGFuZWwgc2VsZWN0ZWQsIHNob3dzIGl0cyB0cmFuc2NyaXB0LCBhbmQgcnVucyB0aGUgaW4tYnJvd3NlclxuLy8gYWdlbnQgbG9vcCwgcGVyc2lzdGluZyBldmVyeSB0dXJuLiBUaGUgbG9vcCwgdG9vbHMsIHN0cmVhbWluZywgYW5kIGhvc3QtbWVkaWF0ZWRcbi8vIEJZT0sgYXJlIHRoZSBzYW1lIG1hY2hpbmVyeSB0aGUgc3RhbmRhbG9uZSBDb2RpbmdBZ2VudCB1c2VzIChMTE1fQU5EX0FHRU5UU19TUEVDXG4vLyDCpzMuMyk7IGNvbmZpbmVtZW50IGlzIGF1dG9tYXRpYyAoRzEyL1QyNCk6IGNhdGFsb2cg4oqVIG1vdW50LWNocm9vdCBmcyB0b29scyBvbmx5LlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgdXNlQ2F0YWxvZyxcbiAgdXNlTW91bnRzLFxuICBnZXRBcHBNb3VudFBhdGgsXG4gIHVzZVdvcmtzcGFjZSxcbiAgcG9zdFRvUmVnaW9uLFxuICBvblJlZ2lvbk1lc3NhZ2UsXG4gIGRlc2NyaWJlQ2hhdCxcbn0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyBjYXRhbG9nVG9vbHNldCwgbWVyZ2VUb29sc2V0cyB9IGZyb20gXCIuLi9saWIvdG9vbHNldFwiO1xuaW1wb3J0IHsgY3JlYXRlRnNUb29sc2V0LCBmaW5kQ29uZmVycmVkV29ya3RyZWUgfSBmcm9tIFwiLi4vbGliL2ZzVG9vbHNcIjtcbmltcG9ydCB7IGNyZWF0ZVByb2plY3RUb29sc2V0IH0gZnJvbSBcIi4uL2xpYi9wcm9qZWN0VG9vbHNcIjtcbmltcG9ydCB7IGNyZWF0ZURpYWdub3N0aWNzVG9vbHNldCB9IGZyb20gXCIuLi9saWIvZGlhZ25vc3RpY3NUb29sc1wiO1xuaW1wb3J0IHsgY3JlYXRlR2l0VG9vbHNldCB9IGZyb20gXCIuLi9saWIvZ2l0VG9vbHNcIjtcbmltcG9ydCB7IGJ1aWxkUGlubmVkUHJlZml4LCBidWlsZExpdmVTdWZmaXgsIGNvbXBvc2VTeXN0ZW1Qcm9tcHQsIHRvZGF5SXNvIH0gZnJvbSBcIi4uL2xpYi9hZ2VudFByb21wdFwiO1xuaW1wb3J0IHsgd2l0aFNraWxscyB9IGZyb20gXCIuLi9saWIvc2tpbGxzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGF0TW9kZWxDbGllbnQgfSBmcm9tIFwiLi4vbGliL2NoYXRNb2RlbENsaWVudFwiO1xuaW1wb3J0IHsgcnVuQWdlbnQsIHR5cGUgUnVuU3RhdGUgfSBmcm9tIFwiLi4vbGliL2FnZW50TG9vcFwiO1xuaW1wb3J0IHsgY3JlYXRlUnVuUGF1c2UgfSBmcm9tIFwiLi4vbGliL3J1blBhdXNlXCI7XG5pbXBvcnQgeyBTdGVlckNvbnRyb2xsZXIsIElOVEVSUlVQVEVEX1RVUk5fVEVYVCwgdHlwZSBTdGVlck1lc3NhZ2UsIHR5cGUgU3RlZXJNb2RlIH0gZnJvbSBcIi4uL2xpYi9zdGVlcmluZ1wiO1xuaW1wb3J0IHsgcmVwYWlyVHJhbnNjcmlwdCwgaW50ZXJydXB0ZWQsIGRpdmVyZ2VuY2VNZXNzYWdlLCByZXN1bWVkTWVzc2FnZXMgfSBmcm9tIFwiLi4vbGliL3Jlc3VtZVwiO1xuaW1wb3J0IHsgdXNlTGVhc2VSZWZyZXNoIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUxlYXNlUmVmcmVzaFwiO1xuaW1wb3J0IHsgb3BlbkNvbnZlcnNhdGlvblN0b3JlLCBkZXJpdmVUaXRsZSwgaXNKb3VybmFsUmVmdXNhbCwgdHlwZSBDb252ZXJzYXRpb25TdG9yZSwgdHlwZSBSZXBsYXlSZXN1bHQgfSBmcm9tIFwiLi4vbGliL2NvbnZlcnNhdGlvblN0b3JlXCI7XG5pbXBvcnQge1xuICBvcGVuU2Vzc2lvblByb2plY3Rpb25Xcml0ZXIsXG4gIGNyZWF0ZVByb2plY3Rpb25QdWJsaXNoZXIsXG4gIHR5cGUgU2Vzc2lvblByb2plY3Rpb25Xcml0ZXIsXG4gIHR5cGUgUHJvamVjdGlvblB1Ymxpc2hlcixcbn0gZnJvbSBcIi4uL2xpYi9zZXNzaW9uUHJvamVjdGlvblwiO1xuaW1wb3J0IHsgY3JlYXRlU3RhZ2VTZWxlY3Rpb24sIHR5cGUgU3RhZ2VTZWxlY3Rpb24gfSBmcm9tIFwiLi4vbGliL3N0YWdlU2VsZWN0aW9uXCI7XG5pbXBvcnQgeyB1c2VTdGlja1RvQm90dG9tIH0gZnJvbSBcIi4uL2hvb2tzL3VzZVN0aWNrVG9Cb3R0b21cIjtcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uIH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25Nb2RlbFwiO1xuaW1wb3J0IHsgbWVzc2FnZXNUb0xvZywgdHlwZSBMb2dFbnRyeSB9IGZyb20gXCIuLi9saWIvdHJhbnNjcmlwdFwiO1xuaW1wb3J0IFRyYW5zY3JpcHRSb3dzIGZyb20gXCIuL1RyYW5zY3JpcHRSb3dzXCI7XG5pbXBvcnQgUmVzdW1lQWZmb3JkYW5jZSBmcm9tIFwiLi9SZXN1bWVBZmZvcmRhbmNlXCI7XG5pbXBvcnQgeyBQQU5FTF9SRUdJT04sIGlzU2VsZWN0IH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25JcGNcIjtcbmltcG9ydCB7IGRlc2NyaWJlU3RvcmVGYWlsdXJlIGFzIGRlc2NyaWJlLCBsZWFzZUZhaWx1cmUsIGxlYXNlRmFpbHVyZVRleHQsIGxlYXNlSGVsZFRleHQgfSBmcm9tIFwiLi4vbGliL3N0b3JlRXJyb3JcIjtcbmltcG9ydCBcIi4vQ29kaW5nQWdlbnQuY3NzXCI7XG5cbi8vIFItQVJELTEwOiB0aGUgY29weSBmb3IgYSBkZWFkIHNldHRpbmdzIHN0b3JlIG5hbWVzIEJPVEggY29zdHMg4oCUIHRoZSBhbW5lc2lhXG4vLyAoaGlzdG9yeSBub3QgcmUtc2VudCkgYW5kIHRoZSBkdXJhYmlsaXR5IGNvbnNlcXVlbmNlIChhIGNsb3NlZCB0YWIgbG9zZXMgdGhlXG4vLyBydW4pLiBPbmUgY29uc3RhbnQgc28gYSBmb3VydGggY2FsbCBzaXRlIGNhbm5vdCBzaGlwIHRoZSBvbGQgY29weS5cbmNvbnN0IE5PX1NUT1JFX1NVRkZJWCA9XG4gIFwiLCBzbyBlYWNoIG1lc3NhZ2UgaXMgc2VudCB3aXRob3V0IHRoZSBlYXJsaWVyIG9uZXMg4oCUIGFuZCBhIGNsb3NlZCB0YWIgbG9zZXMgdGhlIHJ1biwgbm90IGp1c3QgdGhlIGluLWZsaWdodCB0dXJuXCI7XG5cbi8vIFItQVJELTEwYTogdGhlIGNvcHkgZm9yIGEgY2hlY2twb2ludC1hcHBlbmQgcmVmdXNhbCDigJQgdGhlIHJ1biBzdG9wcGVkIEFUIGFcbi8vIGJvdW5kYXJ5IGFuZCBldmVyeXRoaW5nIGNoZWNrcG9pbnRlZCBzbyBmYXIgc3Vydml2ZXMuIE9uZSBob21lLCB1c2VkIGJ5IGJvdGhcbi8vIHJ1biBzdXJmYWNlcydzIGpvdXJuYWwtZmFpbHVyZSBjYXRjaGVzLlxuY29uc3QgSk9VUk5BTF9SRUZVU0FMX1NVRkZJWCA9XG4gIFwiLCBzbyB0aGUgcnVuIHN0b3BwZWQgYXQgaXRzIGxhc3QgY2hlY2twb2ludCDigJQgbm90aGluZyBhZnRlciBpdCB3YXMga2VwdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb252ZXJzYXRpb25TdGFnZSgpIHtcbiAgY29uc3QgY2F0YWxvZyA9IHVzZUNhdGFsb2coKTtcbiAgY29uc3QgbW91bnRzID0gdXNlTW91bnRzKCk7XG4gIGNvbnN0IHN0b3JlUmVmID0gdXNlUmVmPENvbnZlcnNhdGlvblN0b3JlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGNvbnZSZWYgPSB1c2VSZWY8Q29udmVyc2F0aW9uIHwgbnVsbD4obnVsbCk7XG4gIC8vIFIzLTYzMSDigJQgdGhlIHNlc3Npb24gcHJvamVjdGlvbiAoQ09OVFJJQlVURV9UUkFOU0NSSVBUX1NQRUMgwqczKTogdGhlIHdyaXRlciBhbmRcbiAgLy8gdGhlIG5hbWVkLWhlYXJ0YmVhdCBwdWJsaXNoZXIgb3ZlciBpdC4gT3BlbmVkL2J1aWx0IGJlc2lkZSB0aGUgc3RvcmUgb24gdGhlXG4gIC8vIFNBTUUgc2V0dGluZ3MgbW91bnQ7IGEgZGVhZCB3cml0ZXIgY29zdHMgb25seSB0aGUgZmVhdHVyZSAodGhlIGhvc3QgbmV2ZXIgc2Vlc1xuICAvLyBhIGhlYXJ0YmVhdCDih5IgbmV2ZXIgb2ZmZXJzIOKHkiBmYWlsLWNsb3NlZCksIG5ldmVyIHRoZSBjb252ZXJzYXRpb24uIFRoZSB0cmlnZ2VyXG4gIC8vIHNlbWFudGljcyBsaXZlIGluIGBzZXNzaW9uUHJvamVjdGlvbi50c2AgKGV4dHJhY3RlZCBsaWtlIGBzdGFnZVNlbGVjdGlvbi50c2BcbiAgLy8gc28gdGhleSBhcmUgdGVzdGFibGUgd2l0aG91dCBhIERPTSk7IHRoaXMgY29tcG9uZW50IG9ubHkgbmFtZXMgdGhlIG1vbWVudHMuXG4gIGNvbnN0IHByb2plY3Rpb25SZWYgPSB1c2VSZWY8U2Vzc2lvblByb2plY3Rpb25Xcml0ZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgcHVibGlzaGVyUmVmID0gdXNlUmVmPFByb2plY3Rpb25QdWJsaXNoZXIgfCBudWxsPihudWxsKTtcbiAgLy8gUjMtMjI0ICjCpzMuMyk6IHRoZSBzdG9wIGJ1dHRvbidzIGFib3J0IGNvbnRyb2xsZXIgZm9yIHRoZSBpbi1mbGlnaHQgcnVuLiBBYm9ydGluZ1xuICAvLyBpdCBoYWx0cyB0aGUgbG9vcCBBTkQgdGVhcnMgZG93biB0aGUgaW4tZmxpZ2h0IHVwc3RyZWFtIExMTSByZXF1ZXN0IChzdG9wcyBiaWxsaW5nKS5cbiAgY29uc3QgYWJvcnRSZWYgPSB1c2VSZWY8QWJvcnRDb250cm9sbGVyIHwgbnVsbD4obnVsbCk7XG4gIC8vIFIzLTMzMzogdGhlIG1pZC1ydW4gc3RlZXJpbmcgcXVldWUuIFNUT1AgKGFib3ZlKSBlbmRzIHRoZSBydW47IFNURUVSIHJlZGlyZWN0cyBpdFxuICAvLyB3aXRob3V0IGRpc2NhcmRpbmcgdGhlIHRyYW5zY3JpcHQuIE9uZSBjb250cm9sbGVyIHBlciBydW4sIHNvIGEgY29ycmVjdGlvbiB0aGVcbiAgLy8gdXNlciB0b29rIGJhY2sgbmV2ZXIgbGVha3MgaW50byB0aGUgbmV4dCBvbmUuXG4gIGNvbnN0IHN0ZWVyUmVmID0gdXNlUmVmPFN0ZWVyQ29udHJvbGxlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcXVldWVkLCBzZXRRdWV1ZWRdID0gdXNlU3RhdGU8cmVhZG9ubHkgU3RlZXJNZXNzYWdlW10+KFtdKTtcbiAgY29uc3QgW3N0ZWVyVGV4dCwgc2V0U3RlZXJUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbG9nLCBzZXRMb2ddID0gdXNlU3RhdGU8TG9nRW50cnlbXT4oW10pO1xuICBjb25zdCBbcHJvbXB0LCBzZXRQcm9tcHRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzdHJlYW1pbmcsIHNldFN0cmVhbWluZ10gPSB1c2VTdGF0ZShcIlwiKTtcbiAgLy8gUjMtMzM1IOKAlCB0aGUgaW4tZmxpZ2h0IHJlYXNvbmluZyBmb3IgdGhlIGN1cnJlbnQgdHVybiAoY2xlYXJlZCB3aGVuIHRoZSB3aG9sZSBibG9ja1xuICAvLyBhcnJpdmVzIGFuZCBiZWNvbWVzIGEgdHJhbnNjcmlwdCByb3cpLlxuICBjb25zdCBbdGhpbmtpbmcsIHNldFRoaW5raW5nXSA9IHVzZVN0YXRlKFwiXCIpO1xuICAvLyBSMy0zMzYg4oCUIHRoZSBydW4ncyB0b2tlbiBhY2NvdW50aW5nLCBpbmNsdWRpbmcgcHJvbXB0LWNhY2hlIHJlYWRzL3dyaXRlcyB3aGVyZSB0aGVcbiAgLy8gcHJvdmlkZXIgcmVwb3J0cyB0aGVtLiBTdXJmYWNpbmcgaXQgaXMgd2hhdCBtYWtlcyBjYWNoaW5nIHZlcmlmaWFibGUgcmF0aGVyIHRoYW5cbiAgLy8gYmVsaWV2ZWQ7IHdpdGhvdXQgYSBudW1iZXIgb24gc2NyZWVuIHRoZSBjb3N0IGNsYWltIGlzIHVuZmFsc2lmaWFibGUuXG4gIGNvbnN0IFt1c2FnZSwgc2V0VXNhZ2VdID0gdXNlU3RhdGU8e1xuICAgIHNwZW50VG9rZW5zOiBudW1iZXI7XG4gICAgY2FjaGVSZWFkVG9rZW5zPzogbnVtYmVyO1xuICAgIGNhY2hlV3JpdGVUb2tlbnM/OiBudW1iZXI7XG4gIH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3J1bm5pbmcsIHNldFJ1bm5pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAvLyBXaGljaCBjb252ZXJzYXRpb24gYSBydW4gaXMgaW4gZmxpZ2h0IGZvciDigJQgYSByZWYsIHNvIHRoZSBhcmJpdGVyJ3MgcGVyLWlkIHByb2JlIGNhblxuICAvLyByZWFkIGl0IHdpdGhvdXQgcmVidWlsZGluZy4gU2V0IHdoZW4gYSBydW4gc3RhcnRzLCBjbGVhcmVkIHdoZW4gaXQgZW5kcy5cbiAgY29uc3QgcnVubmluZ0lkUmVmID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIC8vIFRoZSBjb252ZXJzYXRpb24gY3VycmVudGx5IHNob3duIOKAlCBrZXlzIHRoZSB0cmFuc2NyaXB0IHNjcm9sbGVyIHNvIGEgc3dpdGNoIHJlc2V0c1xuICAvLyBpdHMgZm9sbG93IHN0YXRlIChhIHJlbGVhc2UgaW4gb25lIGNvbnZlcnNhdGlvbiBtdXN0IG5vdCBjYXJyeSBpbnRvIHRoZSBuZXh0KS5cbiAgY29uc3QgW2NvbnZJZCwgc2V0Q29udklkXSA9IHVzZVN0YXRlPHN0cmluZyB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcbiAgLy8gV2h5IHBlcnNpc3RlbmNlIGlzIHVuYXZhaWxhYmxlLCBpZiBpdCBpcy4gVGhlIGNvbnZlcnNhdGlvbiBzdG9yZSBpcyBub3QgYVxuICAvLyBuaWNlLXRvLWhhdmU6IGBydW4oKWAgcmVhZHMgdGhlIG1vZGVsJ3MgSElTVE9SWSBvdXQgb2YgdGhlIHBlcnNpc3RlZFxuICAvLyBjb252ZXJzYXRpb24sIHNvIGEgZGVhZCBzdG9yZSBzaWxlbnRseSBkb3duZ3JhZGVzIHRoZSBhZ2VudCB0byBhIHN0YXRlbGVzc1xuICAvLyBjaGF0Ym90IHRoYXQgcmUtcmVhZHMgbm90aGluZyBiZXR3ZWVuIHR1cm5zLiBUaGF0IGZhaWx1cmUgdXNlZCB0byBiZVxuICAvLyBzd2FsbG93ZWQgYnkgZW1wdHkgYGNhdGNoIHt9YHMg4oCUIHN1cmZhY2UgaXQgaW5zdGVhZCAoUjMtMjQ3KS5cbiAgY29uc3QgW3N0b3JlRXJyb3IsIHNldFN0b3JlRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIC8qKiBSMy01NjEg4oCUIGFub3RoZXIgZnJhbWUncyBydW4gbGVhc2UgaXMgbGl2ZSBvbiB0aGlzIGNvbnZlcnNhdGlvbi4gUmVuZGVycyBhc1xuICAgKiAgYW4gT0ZGRVIgdG8gdGFrZSBvdmVyLCBuZXZlciBhcyBhIGJsb2NrIChSLUFSRC0xOGEpOiB0aGUgbGVhc2UgaXMgYWR2aXNvcnksXG4gICAqICB0aGUgaG9sZGVyIG1heSBiZSBhIHdpbmRvdyB0aGF0IG5vIGxvbmdlciBleGlzdHMsIGFuZCBhIGhhcmQgYmxvY2sgb24gaXQgaXMgYVxuICAgKiAgZGVhZCBlbmQgdGhlIHVzZXIgY2Fubm90IGVzY2FwZS4gQ2FycmllcyB0aGUgYWN0aW9uIHRoYXQgd2FzIHJlZnVzZWQsIHNvXG4gICAqICBcInRha2Ugb3ZlclwiIGNvbnRpbnVlcyB3aGF0IHRoZSB1c2VyIGFza2VkIGZvciByYXRoZXIgdGhhbiBtYWtpbmcgdGhlbSBhc2tcbiAgICogIHR3aWNlLiAqL1xuICBjb25zdCBbbGVhc2VIZWxkLCBzZXRMZWFzZUhlbGRdID0gdXNlU3RhdGU8bnVsbCB8IHsgY29udklkOiBzdHJpbmc7IHJlc3VtZTogYm9vbGVhbiB9PihudWxsKTtcbiAgLy8gUjMtNTYwOiBhbiBpbnRlcnJ1cHRlZCBydW4gZGV0ZWN0ZWQgb24gdGhpcyBjb252ZXJzYXRpb24g4oCUIHRoZSBqb3VybmFsIHNheXNcbiAgLy8gYSBydW4gd2FzIGluIGZsaWdodCBhbmQgbmV2ZXIgcmVhY2hlZCBpdHMgZmluYWwgYHJ1bkVuZGAgQjQuIFJlc3VtZSBpc1xuICAvLyBBVFRFTkRFRCAoUi1BUkQtMTUpOiByZW5kZXJpbmcgdGhpcyBhZmZvcmRhbmNlIGlzIGFsbCB0aGUgYm9vdCBwYXRoIGRvZXM7XG4gIC8vIG5vIG1vZGVsIGNhbGwsIG5vIGV4ZWN1dG9yLCBub3RoaW5nIHVudGlsIHRoZSB1c2VyIHBpY2tzIGFuIGFjdGlvbi5cbiAgY29uc3QgW3BlbmRpbmdSZXN1bWUsIHNldFBlbmRpbmdSZXN1bWVTdGF0ZV0gPSB1c2VTdGF0ZTx7IGNvbnZJZDogc3RyaW5nOyByZXBsYXk6IFJlcGxheVJlc3VsdCB9IHwgbnVsbD4obnVsbCk7XG4gIC8vIFJlZiBtaXJyb3Ig4oCUIHRoZSBhdHRlbmRlZCBnYXRlIGluIHJ1bigpIG11c3QgcmVhZCB0aGUgQ1VSUkVOVCB2YWx1ZSBhZnRlclxuICAvLyBhd2FpdGluZyBhbiBpbi1mbGlnaHQgcmVwbGF5LCB3aGljaCBhIHJlbmRlci1jbG9zZWQgc3RhdGUgdmFyaWFibGUgY2Fubm90IGdpdmUuXG4gIGNvbnN0IHBlbmRpbmdSZXN1bWVSZWYgPSB1c2VSZWY8eyBjb252SWQ6IHN0cmluZzsgcmVwbGF5OiBSZXBsYXlSZXN1bHQgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzZXRQZW5kaW5nUmVzdW1lID0gKHY6IHsgY29udklkOiBzdHJpbmc7IHJlcGxheTogUmVwbGF5UmVzdWx0IH0gfCBudWxsKTogdm9pZCA9PiB7XG4gICAgcGVuZGluZ1Jlc3VtZVJlZi5jdXJyZW50ID0gdjtcbiAgICBzZXRQZW5kaW5nUmVzdW1lU3RhdGUodik7XG4gIH07XG4gIC8vIFRoZSBib290IHJlcGxheSBjdXJyZW50bHkgaW4gZmxpZ2h0LCBpZiBhbnkg4oCUIGBydW4oKWAgbXVzdCBub3Qgc3RhcnQgcGFzdCBhblxuICAvLyB1bnJlc29sdmVkIGludGVycnVwdGlvbiBjaGVjayAodGhlIFRPQ1RPVSBob2xlOiBhIGtpY2tvZmYgdGhhdCBzbGlwcyBiZXR3ZWVuXG4gIC8vIHRoZSByZXBsYXkgY2FsbCBhbmQgaXRzIHJlc3VsdCB0YWtlcyB0aGUgcmVzdGFydC1hbmQtbG9zZS10YWlsIHBhdGgpLlxuICBjb25zdCByZXBsYXlJbkZsaWdodFJlZiA9IHVzZVJlZjx7IGNvbnZJZDogc3RyaW5nOyBwcm9taXNlOiBQcm9taXNlPHZvaWQ+IH0gfCBudWxsPihudWxsKTtcblxuICAvLyBSMy02MTUg4oCUIGZvbGxvdyB0aGUgc3RyZWFtLiBUaGUgdHJhbnNjcmlwdCBhbmQgdGhlIGxpdmUgcmVhc29uaW5nIGJveCBlYWNoIHBpbiB0b1xuICAvLyB0aGVpciBuZXdlc3Qgcm93IHdoaWxlIHRoZSByZWFkZXIgaXMgYXQgdGhlIGJvdHRvbSwgYW5kIHN0b3AgdGhlIG1vbWVudCB0aGV5IHNjcm9sbFxuICAvLyB1cCDigJQgcmVzdW1pbmcgb25seSBvbiByZXR1cm4uIFR3byBzY3JvbGxlcnMsIG9uZSBob29rLCBjYWxsZWQgdHdpY2UuXG4gIGNvbnN0IGxvZ1JlZiA9IHVzZVJlZjxIVE1MVUxpc3RFbGVtZW50PihudWxsKTtcbiAgY29uc3QgcmVhc29uaW5nUmVmID0gdXNlUmVmPEhUTUxTcGFuRWxlbWVudD4obnVsbCk7XG4gIC8vIFRoZSB0cmFuc2NyaXB0IHNjcm9sbGVyIGZvbGxvd3MgZXZlcnl0aGluZyB0aGF0IGdyb3dzIGluc2lkZSBpdCDigJQgdGhlIHNldHRsZWQgcm93cyxcbiAgLy8gdGhlIGxpdmUgcmVhc29uaW5nIGJsb2NrIGFuZCB0aGUgbGl2ZSByZXBseSDigJQgc28gaXQgaXMga2V5ZWQgb24gYWxsIHRocmVlLCBub3QganVzdFxuICAvLyB0aGUgc2V0dGxlZCByb3dzICh0aGUgbGl2ZSByb3dzIHN0cmVhbSB3aXRob3V0IHRvdWNoaW5nIGBsb2dgKS5cbiAgY29uc3QgdHJhbnNjcmlwdEZsb3cgPSB1c2VNZW1vKFxuICAgICgpID0+IFtsb2csIHRoaW5raW5nLCBzdHJlYW1pbmddLFxuICAgIFtsb2csIHRoaW5raW5nLCBzdHJlYW1pbmddLFxuICApO1xuICB1c2VTdGlja1RvQm90dG9tKGxvZ1JlZiwgdHJhbnNjcmlwdEZsb3cpO1xuICB1c2VTdGlja1RvQm90dG9tKHJlYXNvbmluZ1JlZiwgdGhpbmtpbmcpO1xuXG4gIC8vIFRoZSBTVEFHRSBhcHAncyB3b3JraW5nIHRyZWUsIGNvbmZlcnJlZCBieSB0aGUgaG9zdCBhcyBhIGB0eXBlOid3b3JrdHJlZSdgIG1vdW50XG4gIC8vIChBQS0yMykg4oCUIE5PVCB0aGUgYWdlbnQncyBPV04gcmVwby4gSWYgaXQgaXNuJ3QgY29uZmVycmVkICh0aGUgbW91bnQgaGFzbid0IGFycml2ZWQsXG4gIC8vIGNodXJuZWQgYXdheSwgb3Igbm8gYXBwIGlzIGxvYWRlZCksIHRoaXMgaXMgYG51bGxgIGFuZCB3ZSBNVVNUIE5PVCBmYWxsIGJhY2sgdG8gdGhlXG4gIC8vIGFnZW50J3Mgb3duIHJlcG86IGRvaW5nIHNvIG1hZGUgdGhlIHdvcmtiZW5jaCBzaWxlbnRseSBhdXRob3IgKml0c2VsZiogKGV2ZXJ5XG4gIC8vIHN0YWdlLWFwcCBwYXRoIHJlYWQgYG5vdCBmb3VuZGAsIGFuZCB0aGUgbW9kZWwgZmxvdW5kZXJlZCkuIFJlLWRlcml2ZWQgd2hlbiB0aGVcbiAgLy8gY29uZmVycmVkIG1vdW50IGNoYW5nZXMgKHN3aXRjaGluZyB0aGUgbG9hZGVkIGFwcCB0ZWFycyBkb3duIHRoZSBvbGQgcG9ydCwgbWludHMgbmV3KS5cbiAgY29uc3Qgc3RhZ2VUcmVlID0gdXNlTWVtbygoKSA9PiBmaW5kQ29uZmVycmVkV29ya3RyZWUobW91bnRzLCBnZXRBcHBNb3VudFBhdGgoKSksIFttb3VudHNdKTtcblxuICAvLyBUb29scyBnaXZlbiB0byB0aGUgbW9kZWwuIFdpdGhvdXQgdGhlIHN0YWdlIHRyZWUgdGhlIGFnZW50IGdldHMgdGhlIGNhdGFsb2cgT05MWSDigJRcbiAgLy8gbm8gZmlsZXN5c3RlbSB0b29scyDigJQgc28gaXQgY2FuIG5ldmVyIGVkaXQgdGhlIHdyb25nIChpdHMgb3duKSByZXBvLiBSdW4gaXMgZ2F0ZWRcbiAgLy8gYmVsb3cgYW5kIGEgXCJ3b3Jrc3BhY2Ugbm90IHJlYWR5XCIgbm90aWNlIGlzIHNob3duLlxuICAvLyBSMy0zMzkg4oCUIGRvZXMgdGhlIG1vZGVsIHRoZSB1c2VyIGNvbmZpZ3VyZWQgYWNjZXB0IGltYWdlcz8gVGhlIHRvb2wgaXMgdG9sZCwgc28gYVxuICAvLyBgcmVhZF9maWxlYCBvbiBhIFBORyBjYW4gU0FZIHRoZSBtb2RlbCBjYW5ub3QgbG9vayBhdCBpdCBpbnN0ZWFkIG9mIHNlbmRpbmdcbiAgLy8gc29tZXRoaW5nIHRoYXQgZXJyb3JzIHVwc3RyZWFtLiBSZS1yZWFkIHdoZW4gdGhlIHByb3ZpZGVyIGNoYW5nZXMuXG4gIGNvbnN0IHZpc2lvbiA9IHVzZU1lbW8oKCkgPT4gZGVzY3JpYmVDaGF0KCk/LmZlYXR1cmVzLnZpc2lvbiA9PT0gdHJ1ZSwgW10pO1xuXG4gIGNvbnN0IHsgdG9vbHNldCwgc2tpbGxzIH0gPSB1c2VNZW1vKCgpID0+IHtcbiAgICAvLyBObyBjb25mZXJyZWQgc3RhZ2UgdHJlZSDih5IgYSBjYXRhbG9nLW9ubHkgdG9vbHNldCB3aXRoIG5vIGF1dGhvcmluZyB0b29scywgc29cbiAgICAvLyBgd2l0aFNraWxsc2Agb2ZmZXJzIG5vdGhpbmcgYW5kIGBsb2FkX3NraWxsYCBpcyBhYnNlbnQg4oCUIHRoZSBhdXRob3Jpbmcgc2tpbGxzXG4gICAgLy8gd291bGQgYmUgYWR2aWNlIHRoZSBhZ2VudCBjYW5ub3QgYWN0IG9uIChSMy0zMzEpLlxuICAgIGlmICghc3RhZ2VUcmVlKSByZXR1cm4gd2l0aFNraWxscyhjYXRhbG9nVG9vbHNldChjYXRhbG9nKSk7XG4gICAgY29uc3QgZnNUb29scyA9IGNyZWF0ZUZzVG9vbHNldCh7IHJvb3Q6IHN0YWdlVHJlZS5yb290LCByZWFkT25seTogc3RhZ2VUcmVlLnJlYWRPbmx5LCB2aXNpb24gfSk7XG4gICAgY29uc3QgcHJvamVjdFRvb2xzID0gY3JlYXRlUHJvamVjdFRvb2xzZXQoeyByb290OiBzdGFnZVRyZWUucm9vdCwgcmVhZE9ubHk6IHN0YWdlVHJlZS5yZWFkT25seSB9KTtcbiAgICBjb25zdCBkaWFnbm9zdGljc1Rvb2xzID0gY3JlYXRlRGlhZ25vc3RpY3NUb29sc2V0KCk7XG4gICAgLy8gUjMtMzMyOiBnaXQtUkVBRCBvdmVyIHRoZSBzYW1lIHdvcmtpbmcgdHJlZS4gRW1wdHkgKGFuZCB0aGVyZWZvcmUgaW52aXNpYmxlIHRvXG4gICAgLy8gdGhlIG1vZGVsKSB1bmxlc3MgdGhlIGFwcCBob2xkcyBgdmNzOnJlYWRgLlxuICAgIGNvbnN0IGdpdFRvb2xzID0gY3JlYXRlR2l0VG9vbHNldCh7IGNhdGFsb2cgfSk7XG4gICAgLy8gYHdpdGhTa2lsbHNgIHN0YXlzIExBU1QgKFIzLTMzMSk6IHdoaWNoIGhvc3Qgc2tpbGxzIGFyZSBvZmZlcmVkIGRlcGVuZHMgb24gdGhlXG4gICAgLy8gZmluYWwgbWVyZ2VkIHRvb2wgbGlzdCwgc28gaXQgaGFzIHRvIHNlZSB0aGUgZ2l0IHRvb2xzIHRvby5cbiAgICByZXR1cm4gd2l0aFNraWxscyhtZXJnZVRvb2xzZXRzKGNhdGFsb2dUb29sc2V0KGNhdGFsb2cpLCBmc1Rvb2xzLCBwcm9qZWN0VG9vbHMsIGRpYWdub3N0aWNzVG9vbHMsIGdpdFRvb2xzKSk7XG4gIH0sIFtjYXRhbG9nLCBzdGFnZVRyZWUsIHZpc2lvbl0pO1xuXG4gIGNvbnN0IGFwcGVuZCA9IChlOiBMb2dFbnRyeSkgPT4gc2V0TG9nKChsKSA9PiBbLi4ubCwgZV0pO1xuXG4gIC8vIFIzLTU2MSAvIFItQVJELTE4OiByZWZyZXNoIHRoZSBsZWFzZSBvbiBhbiBpbnRlcnZhbCB3aGlsZSB0aGUgcnVuIGV4ZWN1dGVzLlxuICAvLyBTaGFyZWQgd2l0aCBDb2RpbmdBZ2VudCDigJQgdGhlIG90aGVyIHJ1biBzdXJmYWNlIOKAlCByYXRoZXIgdGhhbiBsaXZpbmcgaGVyZTsgc2VlXG4gIC8vIGB1c2VMZWFzZVJlZnJlc2hgIGZvciB3aHkgdGhlIGJvdW5kYXJ5IGFwcGVuZHMgYXJlIG5vdCBlbm91Z2ggb24gdGhlaXIgb3duLFxuICAvLyBhbmQgZm9yIHdoeSB0aGlzIGxvb3AgZG9lcyBOT1QgcmFpc2UgdGhlIHRha2VvdmVyIG9mZmVyIChpdCBjYW5ub3Q6IHRoZSBiYW5uZXJcbiAgLy8gcmVuZGVycyBvbmx5IHdoZW4gdGhlIHJ1biBpcyBub3QgcnVubmluZykuIEEgbG9zdCBsZWFzZSBpcyBzdXJmYWNlZCBieSB0aGVcbiAgLy8gcnVuJ3Mgb3duIGNhdGNoIGJlbG93LCBmcm9tIHRoZSB0eXBlZCBjb2RlIGBhcHBlbmRgIHJlamVjdHMgd2l0aC5cbiAgdXNlTGVhc2VSZWZyZXNoKHN0b3JlUmVmLCBydW5uaW5nSWRSZWYsIHJ1bm5pbmcpO1xuXG4gIC8qKlxuICAgKiBSMy01NjEg4oCUIGhhbmQgdGhlIHJ1bidzIGxlYXNlIGJhY2ssIGZyb20gYm90aCBydW4gcGF0aHMuXG4gICAqXG4gICAqIE9ORSBmdW5jdGlvbiBiZWNhdXNlIHRoZXJlIHdlcmUgdHdvIGNvcGllcyBhbmQgdGhlIHNlY29uZCBoYWQgYWxyZWFkeSBkcmlmdGVkOlxuICAgKiBgcnVuYCdzIGZpcmVkIGl0LCBgcmVzdW1lUnVuYCdzIGF3YWl0ZWQgaXQsIGFuZCB0aGUgcGFyYWdyYXBoIGFyZ3VpbmcgYWdhaW5zdFxuICAgKiBhd2FpdGluZyBoYWQgYmVlbiBkcm9wcGVkIGZyb20gdGhlIHNlY29uZCBjb3B5LiBUaGUgZmlsZSBoZWxkIHRoZSBhcmd1bWVudCBhbmRcbiAgICogaXRzIHZpb2xhdGlvbiBuaW5ldHkgbGluZXMgYXBhcnQuXG4gICAqXG4gICAqIEl0IHJlbGVhc2VzIGBydW5uaW5nSWRSZWZgLCBOT1QgYGNvbnZSZWZgIOKAlCB0aGUgY29udmVyc2F0aW9uIHRoZSBSVU4gaGVsZCwgbm90XG4gICAqIHRoZSBvbmUgb24gc2NyZWVuLiBTZWxlY3RpbmcgYW5vdGhlciBjb252ZXJzYXRpb24gbWlkLXJ1biBzZXRzIGBjb252UmVmYFxuICAgKiAoYHN0YWdlU2VsZWN0aW9uYDogXCJhIHJ1biBmb3IgYSBkaWZmZXJlbnQgY29udmVyc2F0aW9uIGRvZXMgbm90IGdhdGUgdGhlXG4gICAqIHJlbG9hZFwiKSB3aGlsZSB0aGUgbG9vcCBrZWVwcyBnb2luZywgc28gcmVsZWFzaW5nIHdoYXQgaXMgb24gc2NyZWVuIGZyZWVkXG4gICAqIG5vdGhpbmcgYW5kIGxlZnQgdGhlIHJlYWwgbGVhc2UgdG8gc2l0IG91dCBpdHMgZnVsbCBUVEwg4oCUIG9mZmVyaW5nIGEgc2Vjb25kXG4gICAqIHdpbmRvdyBhIHRha2VvdmVyIG9mIGEgcnVuIHRoYXQgaGFkIGFscmVhZHkgZmluaXNoZWQsIHdoaWNoIGlzIHRoZSBvbmUgdGhpbmdcbiAgICogdGhpcyBjYWxsIGV4aXN0cyB0byBwcmV2ZW50LiBDYWxsZXJzIGludm9rZSBpdCBCRUZPUkUgY2xlYXJpbmcgYHJ1bm5pbmdJZFJlZmAuXG4gICAqXG4gICAqIEZpcmVkLCBuZXZlciBhd2FpdGVkLiBGYWlsaW5nIHRvIHJ1biBhdCBhbGwgaXMgYWxyZWFkeSB0aGUgZXhwZWN0ZWQgY2FzZSAobm9cbiAgICogdW5sb2FkIGhhbmRsZXIgcmVhY2hlcyBpdCksIHNvIG1ha2luZyBhIHJ1bidzIHByb21pc2Ugd2FpdCBvbiBhIGRldmljZS1sb2NhbFxuICAgKiByZWFkICsgdW5saW5rIHdpdGggbm8gZGVhZGxpbmUgd291bGQgYnV5IG5vdGhpbmcgYW5kIGNvdWxkIGxlYXZlIGl0IHBlbmRpbmcg4oCUXG4gICAqIHRoZSBhcmd1bWVudCBgQVBQRU5EX1RJTUVPVVRfTVNgIG1ha2VzIG9uZSBmaWxlIG92ZXIuIFRoZSBUVEwgYW5kIHNhbWUtdGFiXG4gICAqIHJlY2xhaW0gYXJlIHdoYXQgYWN0dWFsbHkgZnJlZSBhIGxlYXNlLlxuICAgKi9cbiAgY29uc3QgcmVsZWFzZUhlbGRMZWFzZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaWQgPSBydW5uaW5nSWRSZWYuY3VycmVudDtcbiAgICBpZiAoc3RvcmUgJiYgaWQpIHZvaWQgc3RvcmUucmVsZWFzZVJ1bihpZCkuY2F0Y2goKCkgPT4ge30pO1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc2hvd0NvbnZlcnNhdGlvbiA9IHVzZUNhbGxiYWNrKChjb252OiBDb252ZXJzYXRpb24pID0+IHtcbiAgICBjb252UmVmLmN1cnJlbnQgPSBjb252O1xuICAgIHNldENvbnZJZChjb252LmlkKTtcbiAgICBzZXRUaXRsZShjb252LnRpdGxlKTtcbiAgICBzZXRMb2cobWVzc2FnZXNUb0xvZyhjb252Lm1lc3NhZ2VzKSk7XG4gICAgc2V0U3RyZWFtaW5nKFwiXCIpO1xuICAgIHB1Ymxpc2hlclJlZi5jdXJyZW50Py5vblNob3coKTtcbiAgICAvLyBSMy01NjA6IGlzIHRoZXJlIGFuIGludGVycnVwdGVkIHJ1biBvbiB0aGlzIGNvbnZlcnNhdGlvbj8gUmVhZCB0aGUgSk9VUk5BTFxuICAgIC8vIChub3Qgd2FybSBzdGF0ZSkgYW5kIG9mZmVyIHRoZSBhdHRlbmRlZCBjaG9pY2VzIGlmIHNvLiBSZWFkLW9ubHkg4oCUIHRoZVxuICAgIC8vIGJvb3QgcGF0aCBleGVjdXRlcyBub3RoaW5nIChHLUFSRC00KS4gV2hlbiBpbnRlcnJ1cHRlZCwgdGhlIHRyYW5zY3JpcHRcbiAgICAvLyByZW5kZXJlZCBpcyB0aGUgUkVQTEFZRUQgb25lIOKAlCB0aGUgcmVjb3JkIGFsb25lIGlzIGZvbGRlZCB0aHJvdWdoIHRoZSBsYXN0XG4gICAgLy8gcnVuIGVuZCBhbmQgd291bGQgc2hvdyBhIGJsYW5rL3N0YWxlIHZpZXcgb3ZlciBhIGxpdmUgdGFpbCAoUi1BUkQtMTUpLlxuICAgIHNldFBlbmRpbmdSZXN1bWUobnVsbCk7XG4gICAgLy8gUjMtNTYxOiB0aGUgdGFrZW92ZXIgb2ZmZXIgYmVsb25ncyB0byB0aGUgY29udmVyc2F0aW9uIHRoYXQgcmFpc2VkIGl0LiBMZWZ0XG4gICAgLy8gc3RhbmRpbmcgYWNyb3NzIGEgc3dpdGNoIGl0IHdvdWxkIHRha2Ugb3ZlciB0aGUgTkVXIG9uZSDigJQgYHRha2VPdmVyUnVuYFxuICAgIC8vIGRlbGliZXJhdGVseSBjb25zdWx0cyBubyBzdG9yZWQgbGVhc2UsIHNvIGl0IHdvdWxkIGV2aWN0IGEgbGl2ZSBob2xkZXIgb2YgYVxuICAgIC8vIGNvbnZlcnNhdGlvbiB0aGUgdXNlciBuZXZlciBhc2tlZCBhYm91dC4gQ2xlYXJlZCBoZXJlLCBhbmQgdGhlIHJlbmRlciBiZWxvd1xuICAgIC8vIGNhcnJpZXMgYSBgY29udklkYCBndWFyZCB0aGUgd2F5IGBwZW5kaW5nUmVzdW1lYCBkb2VzLlxuICAgIHNldExlYXNlSGVsZChudWxsKTtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHN0b3JlPy5oYXNKb3VybmFsKCkpIHtcbiAgICAgIGNvbnN0IHByb21pc2UgPSBzdG9yZVxuICAgICAgICAucmVwbGF5KGNvbnYuaWQpXG4gICAgICAgIC50aGVuKChyKSA9PiB7XG4gICAgICAgICAgaWYgKGNvbnZSZWYuY3VycmVudD8uaWQgIT09IGNvbnYuaWQgfHwgcnVubmluZ0lkUmVmLmN1cnJlbnQgIT09IG51bGwpIHJldHVybjtcbiAgICAgICAgICBpZiAoIWludGVycnVwdGVkKHIpKSByZXR1cm47XG4gICAgICAgICAgc2V0TG9nKG1lc3NhZ2VzVG9Mb2coci5tZXNzYWdlcykpO1xuICAgICAgICAgIHNldFBlbmRpbmdSZXN1bWUoeyBjb252SWQ6IGNvbnYuaWQsIHJlcGxheTogciB9KTtcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgLy8gUi1BUkQtMTQgLyDCpzk6IGEgcmVmdXNlZCBqb3VybmFsIChjb3JydXB0L3NjaGVtYS9pbmNvaGVyZW50KSBtZWFuc1xuICAgICAgICAgIC8vIHRoZSBjb252ZXJzYXRpb24gaXMgVU4tUkVTVU1BQkxFIOKAlCBzYXkgdGhlIHJlc3VtZSB3YXMgd2l0aGhlbGQsXG4gICAgICAgICAgLy8gbmV2ZXIgc2lsZW50bHkgYmVzdC1lZmZvcnQgaXQuIE90aGVyIGZhaWx1cmVzIGFyZSBzdG9yZSBmYXVsdHMuXG4gICAgICAgICAgaWYgKGNvbnZSZWYuY3VycmVudD8uaWQgIT09IGNvbnYuaWQpIHJldHVybjtcbiAgICAgICAgICBpZiAoaXNKb3VybmFsUmVmdXNhbChlKSkge1xuICAgICAgICAgICAgYXBwZW5kKHtcbiAgICAgICAgICAgICAga2luZDogXCJlcnJvclwiLFxuICAgICAgICAgICAgICB0ZXh0OiBcIlRoaXMgY29udmVyc2F0aW9uJ3MgY2hlY2twb2ludCBqb3VybmFsIGNhbid0IGJlIHJlYWQsIHNvIGl0cyBpbnRlcnJ1cHRlZCBydW4gY2FuJ3QgYmUgcmVzdW1lZCDigJQgdGhlIHNhdmVkIGNvbnZlcnNhdGlvbiBzdGlsbCBvcGVucy5cIixcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICAgIC8vIFByb21pc2UtaWRlbnRpdHksIG5vdCBjb252SWQ6IGEgc2FtZS1jb252ZXJzYXRpb24gcmUtc2VsZWN0ICh0aGVcbiAgICAgICAgICAvLyBwYW5lbCdzIHJlcGFpciBnZXN0dXJlKSBzdGFydHMgYSBORVdFUiByZXBsYXkgd2hvc2UgbWFya2VyIHRoZSBvbGRlclxuICAgICAgICAgIC8vIHByb21pc2UncyBmaW5hbGx5IG11c3Qgbm90IGNsZWFyLlxuICAgICAgICAgIGlmIChyZXBsYXlJbkZsaWdodFJlZi5jdXJyZW50Py5wcm9taXNlID09PSBwcm9taXNlKSByZXBsYXlJbkZsaWdodFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgfSk7XG4gICAgICByZXBsYXlJbkZsaWdodFJlZi5jdXJyZW50ID0geyBjb252SWQ6IGNvbnYuaWQsIHByb21pc2UgfTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICAvLyBPbmUgYXJiaXRlciBwZXIgbW91bnQgKG5ldmVyIG1vZHVsZSBzY29wZSk6IGl0IGhvbGRzIHRoZSBoZWxkIHNlbGVjdGlvbiBhbmQgdGhlXG4gIC8vIGxhdGVzdC13aW5zIHRpY2tldCwgYW5kIGlzIGNyZWF0ZWQgZnJlc2ggc28gYSByZW1vdW50IHN0YXJ0cyBjbGVhbi4gQ3JlYXRlZCBpbiBhblxuICAvLyBlZmZlY3QgcmF0aGVyIHRoYW4gZHVyaW5nIHJlbmRlciDigJQgYHNob3dgID0gYHNob3dDb252ZXJzYXRpb25gIHdyaXRlcyBgY29udlJlZmAsIGFuZFxuICAvLyB0aGUgUmVhY3QgQ29tcGlsZXIncyBgcmVmc2AgcnVsZSBmb3JiaWRzIGEgcmVmIGFjY2VzcyAob3IgYSBmdW5jdGlvbiBjYXJyeWluZyBvbmUpXG4gIC8vIGZyb20gcmVhY2hpbmcgYSByZW5kZXIgcGF0aC5cbiAgY29uc3Qgc3RhZ2VTZWxlY3Rpb25SZWYgPSB1c2VSZWY8U3RhZ2VTZWxlY3Rpb24gfCBudWxsPihudWxsKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzdGFnZVNlbGVjdGlvblJlZi5jdXJyZW50ID0gY3JlYXRlU3RhZ2VTZWxlY3Rpb24oe1xuICAgICAgc2hvdzogc2hvd0NvbnZlcnNhdGlvbixcbiAgICAgIGlzUnVubmluZzogKGlkKSA9PiBydW5uaW5nSWRSZWYuY3VycmVudCA9PT0gaWQsXG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHN0YWdlU2VsZWN0aW9uUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gIH0sIFtzaG93Q29udmVyc2F0aW9uXSk7XG5cbiAgLy8gVGhlIFNDT1BJTkcgS0VZIOKAlCB0aGUgcmVwbyBjb252ZXJzYXRpb25zIGFyZSBzdGFtcGVkIHdpdGggYW5kIHBhcnRpdGlvbmVkIGJ5LlxuICAvL1xuICAvLyBSZWFkIGZyb20gdGhlIGJhc2VsaW5lIHdvcmtzcGFjZSBjaGFubmVsIChSMy00OTEpLCBOT1QgZnJvbSBgc3RhZ2VUcmVlLnJlcG9gLFxuICAvLyBldmVuIHRob3VnaCBib3RoIGFyZSB0aGUgc2FtZSBzdHJpbmcgKFItVUFBLTE2KS4gVGhlIHN0YW1wIGFuZCB0aGUgcGFuZWwncyBzY29wZVxuICAvLyBoYXZlIHRvIGNvbWUgZnJvbSBPTkUgc291cmNlOiB0aGV5IGFyZSBjb21wYXJlZCBmb3IgZXF1YWxpdHksIHNvIHRoZSBkYXkgdGhlIHR3b1xuICAvLyBkZXJpdmF0aW9ucyBkaXZlcmdlIGV2ZXJ5IGV4aXN0aW5nIHN0YW1wIHNpbGVudGx5IHN0b3BzIG1hdGNoaW5nIGFuZCBldmVyeVxuICAvLyBjb252ZXJzYXRpb24gbGFuZHMgdW5kZXIgXCJPdGhlciByZXBvc2l0b3JpZXNcIiDigJQgd2hpY2ggaXMgdGhlIFIzLTQ3NSBidWcsIGp1c3RcbiAgLy8gYXJyaXZlZCBieSBhIGRpZmZlcmVudCByb3V0ZS4gYHN0YWdlVHJlZWAgc3RheXMgd2hhdCBpdCBpcyBhY3R1YWxseSBmb3I6IHRoZVxuICAvLyBmaWxlc3lzdGVtIHJvb3QgdGhlIGFnZW50IGF1dGhvcnMuXG4gIGNvbnN0IHdvcmtzcGFjZSA9IHVzZVdvcmtzcGFjZSgpO1xuICBjb25zdCB3b3Jrc3BhY2VSZXBvID0gd29ya3NwYWNlPy5sYWJlbDtcbiAgLy8gVGhlIHN0YW1wJ3MgUFJPVklERVIgaGFsZiAoUjMtODQ4KTogdGhlIGxhYmVsIGFsb25lIGNhbm5vdCBzYXkgd2hpY2hcbiAgLy8gcHJvdmlkZXIgdGhlIHJlcG8gbGl2ZXMgdW5kZXIsIGFuZCB0aGUgb3RoZXItcmVwb3NpdG9yaWVzIHJvdyB0aGF0IG9wZW5zIGFcbiAgLy8gcmVwbyBwYXNzZXMgY29vcmRpbmF0ZXMsIG5ldmVyIGEgZ3Vlc3MuIFN0YW1wZWQgYmVzaWRlIHRoZSBsYWJlbCBhdCBldmVyeVxuICAvLyBzaXRlIHRoZSBsYWJlbCBpcyBzdGFtcGVkLlxuICBjb25zdCB3b3Jrc3BhY2VQcm92aWRlciA9IHdvcmtzcGFjZT8ucHJvdmlkZXI7XG5cbiAgLy8gUmVhZGFibGUgZnJvbSB0aGUgYm9vdCBlZmZlY3QgYmVsb3cgd2l0aG91dCByZS1ydW5uaW5nIGl0IHdoZW4gdGhlIHdvcmtzcGFjZVxuICAvLyBhcnJpdmVzICh0aGUgZWZmZWN0IG9wZW5zIHRoZSBzdG9yZSBPTkNFOyB0aGUgZmFsbGJhY2sgc2ltcGx5IHVzZXMgd2hhdGV2ZXIgcmVwb1xuICAvLyBpcyBrbm93biBhdCB0aGF0IG1vbWVudCDigJQgdGhlIHBhbmVsJ3Mgc2VsZWN0IGNvcnJlY3RzIGl0KS5cbiAgY29uc3Qgc3RhZ2VSZXBvUmVmID0gdXNlUmVmKHdvcmtzcGFjZVJlcG8pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0YWdlUmVwb1JlZi5jdXJyZW50ID0gd29ya3NwYWNlUmVwbztcbiAgfSwgW3dvcmtzcGFjZVJlcG9dKTtcblxuICAvLyBPcGVuIHRoZSBzdG9yZTsgaWYgbm8gc2VsZWN0aW9uIGFycml2ZXMsIHNob3cgdGhlIG5ld2VzdCBJTiBTQ09QRSAoUjMtNDc1IOKAlFxuICAvLyB0aGUgc2FtZSByZXBvIHBhcnRpdGlvbiB0aGUgcGFuZWwgYXBwbGllcykgc28gdGhlIHN0YWdlIGlzbid0IGJsYW5rIGFuZCBuZXZlclxuICAvLyBzZWVkcyBpdHNlbGYgd2l0aCBhbm90aGVyIHJlcG8ncyBjb252ZXJzYXRpb24uIFRoZSBhcmJpdGVyIG93bnMgd2hpY2ggb2YgdGhlXG4gIC8vIGhlbGQgc2VsZWN0aW9uIC8gbmV3ZXN0IGZhbGxiYWNrIHdpbnMsIHNvIGEgc2VsZWN0aW9uIHRoYXQgbGFuZGVkIGJlZm9yZSB0aGVcbiAgLy8gc3RvcmUgb3BlbmVkIGlzIG5vdCBkcm9wcGVkLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBsaXZlID0gdHJ1ZTtcbiAgICB2b2lkIChhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBzdG9yZSA9IGF3YWl0IG9wZW5Db252ZXJzYXRpb25TdG9yZSgpO1xuICAgICAgICBpZiAoIWxpdmUpIHJldHVybjtcbiAgICAgICAgc3RvcmVSZWYuY3VycmVudCA9IHN0b3JlO1xuICAgICAgICBzZXRTdG9yZUVycm9yKG51bGwpO1xuICAgICAgICBhd2FpdCBzdGFnZVNlbGVjdGlvblJlZi5jdXJyZW50IS5zdG9yZU9wZW5lZChzdG9yZSwgc3RhZ2VSZXBvUmVmLmN1cnJlbnQpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBTaWduZWQgb3V0IGlzIHRoZSBvcmRpbmFyeSBjYXNlOyBhbnl0aGluZyBlbHNlIGlzIGEgcmVhbCBmYXVsdCB0aGUgdXNlclxuICAgICAgICAvLyBtdXN0IHNlZSwgYmVjYXVzZSBpdCBjb3N0cyB0aGVtIGNvbnZlcnNhdGlvbiBtZW1vcnkuXG4gICAgICAgIGlmIChsaXZlKSBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgICAgfVxuICAgIH0pKCk7XG4gICAgLy8gUjMtNjMxIOKAlCBvcGVuIHRoZSBwcm9qZWN0aW9uIHdyaXRlciBvbiB0aGUgc2FtZSBtb3VudCwgaW5kZXBlbmRlbnRseTogYVxuICAgIC8vIHN0b3JlIHRoYXQgZmFpbHMgd2hpbGUgdGhlIHdyaXRlciBvcGVucyAob3IgdmljZSB2ZXJzYSkgZGVncmFkZXMgZXhhY3RseSBvbmVcbiAgICAvLyBvZiB0aGUgdHdvIHN1cmZhY2VzLiBUaGUgcHVibGlzaGVyIGlzIGJ1aWx0IGhlcmUgKG5vdCBkdXJpbmcgcmVuZGVyKSBzbyBub1xuICAgIC8vIHJlZi1jYXJyeWluZyBmdW5jdGlvbiByZWFjaGVzIGEgcmVuZGVyIHBhdGguXG4gICAgcHJvamVjdGlvblJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICBwdWJsaXNoZXJSZWYuY3VycmVudCA9IGNyZWF0ZVByb2plY3Rpb25QdWJsaXNoZXIoXG4gICAgICAoKSA9PiBwcm9qZWN0aW9uUmVmLmN1cnJlbnQsXG4gICAgICAoKSA9PiAoeyBjb252OiBjb252UmVmLmN1cnJlbnQsIHJ1bm5pbmdJZDogcnVubmluZ0lkUmVmLmN1cnJlbnQgfSksXG4gICAgKTtcbiAgICB2b2lkIG9wZW5TZXNzaW9uUHJvamVjdGlvbldyaXRlcigpXG4gICAgICAudGhlbigodykgPT4ge1xuICAgICAgICBpZiAobGl2ZSkge1xuICAgICAgICAgIHByb2plY3Rpb25SZWYuY3VycmVudCA9IHc7XG4gICAgICAgICAgLy8gQ2F0Y2gtdXA6IHRoZSBzdG9yZSdzIG9wZW4gYW5kIHRoZSB3cml0ZXIncyBvcGVuIGFyZSBpbmRlcGVuZGVudFxuICAgICAgICAgIC8vIHJvdW5kLXRyaXBzIOKAlCBpZiB0aGUgc3RhZ2UgYWxyZWFkeSBzaG93ZWQgYSBjb252ZXJzYXRpb24gd2hpbGUgdGhpc1xuICAgICAgICAgIC8vIHdhcyBpbiBmbGlnaHQsIHRoYXQgb25TaG93IGZvdW5kIG5vIHdyaXRlciBhbmQgZHJvcHBlZCBpdHMgaGVhcnRiZWF0XG4gICAgICAgICAgLy8gKGZhaWwtY2xvc2VkLCBidXQgdGhlIHByb2plY3Rpb24gc2hvdWxkIG5vdCBkZXBlbmQgb24gb3BlbiBvcmRlcikuXG4gICAgICAgICAgLy8gUmUtcHVibGlzaGVzIGN1cnJlbnQgc3RhdGUgb25jZTsgcGVyLWlkIHJ1bm5pbmcgZ2F0ZTsgYSBudWxsIGNvbnZcbiAgICAgICAgICAvLyBwdWJsaXNoZXMgdGhlIGhhcm1sZXNzIGV4cGxpY2l0LWluYWN0aXZlIGRvYy5cbiAgICAgICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25TaG93KCk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgLy8gTm8gcHJvamVjdGlvbiDih5IgdGhlIGhvc3QgbmV2ZXIgb2ZmZXJzIGEgdHJhbnNjcmlwdCDih5IgZmFpbC1jbG9zZWQuXG4gICAgICAgIC8vIExvZ2dlZC1hbmQtZHJvcHBlZCAoUjMpOiBhIHBlcnNpc3RlbnQgZmF1bHQgc2hvdWxkIGJlIHZpc2libGUgc29tZXdoZXJlLlxuICAgICAgICBjb25zb2xlLndhcm4oJ3Nlc3Npb24gcHJvamVjdGlvbiB3cml0ZXIgdW5hdmFpbGFibGUgKHRyYW5zY3JpcHQgb2ZmZXJzIHN0YXkgb2ZmKScsIGUpO1xuICAgICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGxpdmUgPSBmYWxzZTtcbiAgICAgIC8vIFVubW91bnQg4oeSIGV4cGxpY2l0IGluYWN0aXZlIGRvYyAoYmVzdC1lZmZvcnQ7IGlmIHRoZSB3cml0ZSBsb3NlcyB0aGUgcmFjZVxuICAgICAgLy8gd2l0aCB0ZWFyZG93biwgdGhlIGhvc3QncyBUVEwgZXhwaXJlcyB0aGUgbGFzdCBoZWFydGJlYXQgaW5zdGVhZCkuXG4gICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25Vbm1vdW50KCk7XG4gICAgICBwdWJsaXNoZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBwcm9qZWN0aW9uUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICAvLyBUaGUgcGFuZWwgZHJpdmVzIHdoaWNoIGNvbnZlcnNhdGlvbiBpcyBzaG93bi5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXR1cm4gb25SZWdpb25NZXNzYWdlKChtKSA9PiB7XG4gICAgICBpZiAoaXNTZWxlY3QobS5kYXRhKSkgdm9pZCBzdGFnZVNlbGVjdGlvblJlZi5jdXJyZW50IS5zZWxlY3QobS5kYXRhLmlkKTtcbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIC8vIEFzayB0aGUgcGFuZWwgd2hhdCBpdCBoYXMgc2VsZWN0ZWQsIG9uY2UsIG9uIG1vdW50IChSMy0yNDMpLlxuICAvL1xuICAvLyBBIGBzZWxlY3QtY29udmVyc2F0aW9uYCBjYW4gYmUgc2VudCB3aGlsZSB0aGlzIHJlZ2lvbiBkb2VzIG5vdCBleGlzdDogb24gbW9iaWxlXG4gIC8vIHRoZSBwYW5lbCBhbmQgdGhlIHN0YWdlIGFyZSBkaWZmZXJlbnQgQ09MVU1OUywgYW5kIGFuIHVudmlzaXRlZCBjb2x1bW4gcmVuZGVycyBhXG4gIC8vIHNrZWxldG9uIHdpdGggbm8gaWZyYW1lIOKAlCBzbyB0aGUgdGFwIHRoYXQgcmV2ZWFscyB0aGlzIHBhbmUgaXMgYWxzbyB0aGUgdGFwIHdob3NlXG4gIC8vIHNlbGVjdGlvbiBoYWQgbm93aGVyZSB0byBsYW5kLiBXaXRob3V0IHRoaXMgaGFuZHNoYWtlIHRoZSBmYWxsYmFjayBhYm92ZSB3b3VsZFxuICAvLyB3aW4gYW5kIHNob3cgdGhlIG5ld2VzdCBjb252ZXJzYXRpb24gaW5zdGVhZCBvZiB0aGUgdGFwcGVkIG9uZS5cbiAgLy9cbiAgLy8gU3Vic2NyaWJlZCBCRUZPUkUgdGhlIGFzayAodGhlIGxpc3RlbmVyIGFib3ZlIGlzIGFscmVhZHkgaW5zdGFsbGVkIGJ5IHRoZSB0aW1lXG4gIC8vIHRoaXMgZWZmZWN0IHJ1bnMpLCBzbyB0aGUgcmVwbHkgY2Fubm90IGFycml2ZSBiZWZvcmUgYW55b25lIGlzIGxpc3RlbmluZy4gSWYgdGhlXG4gIC8vIHBhbmVsIGlzIG5vdCB0aGVyZSDigJQgYSBzdGFnZSBtb3VudGVkIG9uIGl0cyBvd24g4oCUIG5vdGhpbmcgYW5zd2VycyBhbmQgdGhlXG4gIC8vIG5ld2VzdC1jb252ZXJzYXRpb24gZmFsbGJhY2sgc3RhbmRzLCBleGFjdGx5IGFzIGJlZm9yZS5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIHBvc3RUb1JlZ2lvbihQQU5FTF9SRUdJT04sIHsgdHlwZTogXCJyZXF1ZXN0LXNlbGVjdGlvblwiIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXByb21wdC50cmltKCkgfHwgcnVubmluZykgcmV0dXJuO1xuICAgIC8vIFIzLTU2MCAoUi1BUkQtMTUsIHRoZSBhdHRlbmRlZCBnYXRlKTogYW4gaW50ZXJydXB0ZWQgcnVuIG9uIFRISVNcbiAgICAvLyBjb252ZXJzYXRpb24gZGVtYW5kcyBhIGNob2ljZSBmaXJzdC4gQSBmcmVzaCBraWNrb2ZmIHBhc3QgaXQgd291bGQgc2VlZFxuICAgIC8vIGhpc3RvcnkgZnJvbSB0aGUgc3RhbGUgcmVjb3JkLCBCMC1yZXBsYWNlIHRoZSBqb3VybmFsJ3MgdHJhbnNjcmlwdCwgYW5kXG4gICAgLy8gZm9sZC1yZWNsYWltIHRoZSBpbnRlcnJ1cHRlZCB0YWlsIOKAlCBjb21wbGV0ZWQgdG9vbCByZXN1bHRzIHZhbmlzaGluZyBmcm9tXG4gICAgLy8gdGhlIHRyYW5zY3JpcHQgd2hpbGUgdGhlaXIgZmlsZSBlZmZlY3RzIHN0YXksIHRoZSBleGFjdCDCpzAgZGl2ZXJnZW5jZVxuICAgIC8vIHRoaXMgaXRlbSBleGlzdHMgdG8gcmVtb3ZlLiBSZWZ1c2U7IHRoZSBhZmZvcmRhbmNlIGlzIG9uZSByb3cgYWJvdmUuXG4gICAgLy8gVGhlIGludGVycnVwdGlvbiBjaGVjayBtYXkgc3RpbGwgYmUgSU4gRkxJR0hUIChib290IHJlcGxheSkg4oCUIHdhaXQgZm9yIGl0XG4gICAgLy8gYmVmb3JlIGRlY2lkaW5nLCBvciB0aGUgZ2F0ZSBoYXMgYSBob2xlIGV4YWN0bHkgb25lIHRpY2sgd2lkZS5cbiAgICBjb25zdCBjb252Rm9yR2F0ZSA9IGNvbnZSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbmZsaWdodCA9IHJlcGxheUluRmxpZ2h0UmVmLmN1cnJlbnQ7XG4gICAgaWYgKGNvbnZGb3JHYXRlICYmIGluZmxpZ2h0ICYmIGluZmxpZ2h0LmNvbnZJZCA9PT0gY29udkZvckdhdGUuaWQpIHtcbiAgICAgIGF3YWl0IGluZmxpZ2h0LnByb21pc2U7XG4gICAgfVxuICAgIGNvbnN0IHBlbmRpbmcgPSBwZW5kaW5nUmVzdW1lUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHBlbmRpbmcgJiYgY29udlJlZi5jdXJyZW50ICYmIHBlbmRpbmcuY29udklkID09PSBjb252UmVmLmN1cnJlbnQuaWQpIHtcbiAgICAgIGFwcGVuZCh7XG4gICAgICAgIGtpbmQ6IFwiZXJyb3JcIixcbiAgICAgICAgdGV4dDogXCJUaGlzIHJ1biB3YXMgaW50ZXJydXB0ZWQg4oCUIGNob29zZSBSZXN1bWUgcnVuLCBvciBLZWVwIHRoZSBmaWxlcyBhbmQgZW5kIHRoZSBydW4sIGJlZm9yZSBzdGFydGluZyBhIG5ldyBvbmUuXCIsXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0UGVuZGluZ1Jlc3VtZShudWxsKTtcbiAgICAvLyBSZWZ1c2UgcmF0aGVyIHRoYW4gYXV0aG9yIHRoZSB3cm9uZyB0cmVlOiB3aXRoIG5vIGNvbmZlcnJlZCBzdGFnZS1hcHAgd29ya2luZ1xuICAgIC8vIHRyZWUsIHRoZSBhZ2VudCBoYXMgbm8gZmlsZXN5c3RlbSB0b29scywgc28gYSBcImJ1aWxkIG1lIFhcIiBwcm9tcHQgd291bGQgZWl0aGVyXG4gICAgLy8gZG8gbm90aGluZyBvciAocHJlLWZpeCkgc2lsZW50bHkgZWRpdCB0aGUgYWdlbnQncyBvd24gcmVwby4gVGVsbCB0aGUgdXNlci5cbiAgICBpZiAoIXN0YWdlVHJlZSkge1xuICAgICAgYXBwZW5kKHsga2luZDogXCJ1c2VyXCIsIHRleHQ6IHByb21wdCB9KTtcbiAgICAgIGFwcGVuZCh7XG4gICAgICAgIGtpbmQ6IFwiZXJyb3JcIixcbiAgICAgICAgdGV4dDogXCJObyBhcHAgd29ya3NwYWNlIGlzIGNvbm5lY3RlZCB5ZXQuIE9wZW4gYW4gYXBwIGluIHRoZSBzdGFnZSAoYW5kIGdpdmUgaXQgYSBtb21lbnQgdG8gbW91bnQpIGJlZm9yZSBhc2tpbmcgbWUgdG8gZWRpdCBpdCDigJQgSSB3b24ndCB0b3VjaCBteSBvd24gZmlsZXMuXCIsXG4gICAgICB9KTtcbiAgICAgIHNldFByb21wdChcIlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIC8vIEVuc3VyZSBhIGNvbnZlcnNhdGlvbiBleGlzdHMgdG8gYXR0YWNoIHRoaXMgcnVuIHRvLCBzdGFtcGVkIHdpdGggdGhlXG4gICAgLy8gd29ya3NwYWNlIHJlcG8gc28gdGhlIHBhbmVsIHNjb3BlcyBpdCBjb3JyZWN0bHkgKFIzLTQ3NSkuXG4gICAgbGV0IGNvbnYgPSBjb252UmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjb252ICYmIHN0b3JlKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb252ID0gYXdhaXQgc3RvcmUuY3JlYXRlKHVuZGVmaW5lZCwgd29ya3NwYWNlUmVwbywgd29ya3NwYWNlUHJvdmlkZXIpO1xuICAgICAgICBjb252UmVmLmN1cnJlbnQgPSBjb252O1xuICAgICAgICBzdGFnZVNlbGVjdGlvblJlZi5jdXJyZW50IS5hZG9wdChjb252KTtcbiAgICAgICAgc2V0VGl0bGUoY29udi50aXRsZSk7XG4gICAgICAgIHNldFN0b3JlRXJyb3IobnVsbCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIFJ1bm5pbmcgZXBoZW1lcmFsbHkgaXMgYSByZWFsIGRlZ3JhZGF0aW9uLCBub3QgYSBkZXRhaWw6IGBoaXN0b3J5YFxuICAgICAgICAvLyBiZWxvdyBmYWxscyBiYWNrIHRvIFtdLCBzbyB0aGUgbW9kZWwgc2VlcyBPTkxZIHRoaXMgcHJvbXB0IGFuZCB0aGVcbiAgICAgICAgLy8gY29udmVyc2F0aW9uIGFwcGVhcnMgdG8gaGF2ZSBubyBtZW1vcnkuIFNheSBzbyAoUjMtMjQ3KS5cbiAgICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBOT19TVE9SRV9TVUZGSVgpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gUjMtNTYxIC8gUi1BUkQtMTg6IHRha2UgdGhlIGFkdmlzb3J5IHJ1biBsZWFzZSBiZWZvcmUgZXhlY3V0aW5nIGFueXRoaW5nLlxuICAgIC8vIEEgbGl2ZSBsZWFzZSBoZWxkIGJ5IGFub3RoZXIgZnJhbWUgbWVhbnMgdGhlIGNvbnZlcnNhdGlvbiBtYXkgYmUgcnVubmluZyBpblxuICAgIC8vIGEgd2luZG93IHRoaXMgb25lIGNhbm5vdCBzZWUsIGFuZCBkcml2aW5nIG9uZSB3b3JraW5nIHRyZWUgZnJvbSB0d28gbG9vcHMgaXNcbiAgICAvLyB3aGF0IHRoZSBsZWFzZSBleGlzdHMgdG8gYXZvaWQuIGBoZWxkYCBpcyBhbiBPRkZFUiwgbmV2ZXIgYSBibG9jayDigJQgc2VlXG4gICAgLy8gYGxlYXNlSGVsZGAg4oCUIGJlY2F1c2UgdGhlIGhvbGRlciBtYXkgYmUgYSBmcmFtZSB0aGF0IG5vIGxvbmdlciBleGlzdHMuXG4gICAgaWYgKHN0b3JlICYmIGNvbnYpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmICgoYXdhaXQgc3RvcmUuYWNxdWlyZVJ1bihjb252LmlkKSkgPT09IFwiaGVsZFwiKSB7XG4gICAgICAgICAgc2V0TGVhc2VIZWxkKHsgY29udklkOiBjb252LmlkLCByZXN1bWU6IGZhbHNlIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBXcmFwcGVkIGZvciB0aGUgc2FtZSByZWFzb24gYHN0b3JlLmNyZWF0ZWAgdGhyZWUgbGluZXMgdXAgaXMgKFIzLTI0Nyk6IGFcbiAgICAgICAgLy8gc3RvcmUgY2FsbCB0aGF0IHJlamVjdHMgbXVzdCBub3QgcmVhY2ggdGhlIHVzZXIgYXMgYW4gdW5oYW5kbGVkIHJlamVjdGlvblxuICAgICAgICAvLyBmcm9tIGEgYmFyZSBgdm9pZCBydW4oKWAuIEEgbGVhc2Ugd2UgY2Fubm90IHJlYWQgaXMgbm90IGEgbGVhc2Ugd2UgbG9zdCDigJRcbiAgICAgICAgLy8gc2F5IHRoZSBzdG9yZSBpcyBkZWdyYWRlZCBhbmQgcnVuLCByYXRoZXIgdGhhbiByZWZ1c2luZyBvbiBhbiB1bmtub3duLlxuICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBSMy01NTk6IHRoZSBjaGVja3BvaW50IGpvdXJuYWwuIFdoZW4gdGhlIGRldmljZS1sb2NhbCB0aWVyIGlzIHdpcmVkLCBldmVyeVxuICAgIC8vIGxvb3AgYm91bmRhcnkgaXMgYXBwZW5kZWQgYmVmb3JlIHRoZSBsb29wIHByb2NlZWRzIHBhc3QgaXQgKEIyIGludGVudCBpc1xuICAgIC8vIGR1cmFibGUgQkVGT1JFIGl0cyBleGVjdXRvciBydW5zIOKAlCBSLUFSRC0xMGEpOyBhbiBhcHBlbmQgdGhhdCBmYWlscyBvclxuICAgIC8vIHRpbWVzIG91dCB1bndpbmRzIHRoZSBydW4gQVQgdGhhdCBib3VuZGFyeSB3aXRoIHRoZSBkdXJhYmlsaXR5IGNvbnNlcXVlbmNlXG4gICAgLy8gbmFtZWQsIGFuZCB0aGUgam91cm5hbCBhbHJlYWR5IHdyaXR0ZW4gc3RheXMgcmVzdW1hYmxlLiBKb3VybmFsbGVzc1xuICAgIC8vIChSLUFSRC0xMCk6IHRoZSBydW4gaXMgYWxsb3dlZCB0byBzdGFydCwgc2F2ZS1hdC1lbmQgb25seS5cbiAgICBjb25zdCBqb3VybmFsID0gY29udiAmJiBzdG9yZT8uaGFzSm91cm5hbCgpID8gY29udiA6IG51bGw7XG4gICAgaWYgKHN0b3JlICYmIGNvbnYgJiYgIXN0b3JlLmhhc0pvdXJuYWwoKSAmJiAhc3RvcmVFcnJvcikge1xuICAgICAgc2V0U3RvcmVFcnJvcihcbiAgICAgICAgXCJDaGVja3BvaW50cyBhcmUgb2ZmIChubyBkZXZpY2UtbG9jYWwgc3RvcmUpLCBzbyBjbG9zaW5nIHRoaXMgdGFiIGxvc2VzIHRoZSBydW4ncyBpbi1mbGlnaHQgdHVybiDigJQgdGhlIGNvbnZlcnNhdGlvbiBpdHNlbGYgc3RpbGwgc2F2ZXMgd2hlbiB0aGUgcnVuIGVuZHMuXCIsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBoaXN0b3J5ID0gY29udj8ubWVzc2FnZXMgPz8gW107XG4gICAgY29uc3Qga2lja29mZiA9IHByb21wdDtcbiAgICBzZXRQcm9tcHQoXCJcIik7XG4gICAgc2V0UnVubmluZyh0cnVlKTtcbiAgICBydW5uaW5nSWRSZWYuY3VycmVudCA9IGNvbnY/LmlkID8/IG51bGw7XG4gICAgcHVibGlzaGVyUmVmLmN1cnJlbnQ/Lm9uUnVuU3RhcnQoY29udj8uaWQgPz8gbnVsbCk7XG4gICAgc2V0U3RyZWFtaW5nKFwiXCIpO1xuICAgIHNldFRoaW5raW5nKFwiXCIpO1xuICAgIHNldFVzYWdlKG51bGwpO1xuICAgIGFwcGVuZCh7IGtpbmQ6IFwidXNlclwiLCB0ZXh0OiBraWNrb2ZmIH0pO1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgYWJvcnRSZWYuY3VycmVudCA9IGNvbnRyb2xsZXI7XG4gICAgY29uc3Qgc3RlZXJpbmcgPSBuZXcgU3RlZXJDb250cm9sbGVyKCk7XG4gICAgc3RlZXJSZWYuY3VycmVudCA9IHN0ZWVyaW5nO1xuICAgIC8vIFIzLTU2MiAowqc3IFItQVJELTIwYSk6IHRoZSBoaWRl4oaScGF1c2Ugam9pbiBmb3IgdGhpcyBydW4g4oCUIHNlZWRlZCBmcm9tIHRoZVxuICAgIC8vIHZpc2liaWxpdHkgYXQga2lja29mZiwgZHJpdmVuIGJ5IHRoZSBob3N0J3MgcHVzaCBmb3IgdGhlIHJ1bidzIGxpZmVcbiAgICAvLyAoc3JjL2xpYi9ydW5QYXVzZS50cywgZXh0cmFjdGVkIHNvIHRoZSBqb2luIGlzIHRlc3RhYmxlIHdpdGhvdXQgYSBET00pLlxuICAgIGNvbnN0IHsgcGF1c2UsIGRpc3Bvc2U6IGRpc3Bvc2VQYXVzZSB9ID0gY3JlYXRlUnVuUGF1c2UoKTtcbiAgICBzZXRRdWV1ZWQoW10pO1xuICAgIGNvbnN0IG9mZlN0ZWVyQ2hhbmdlID0gc3RlZXJpbmcub25DaGFuZ2UoKHBlbmRpbmcpID0+IHNldFF1ZXVlZChbLi4ucGVuZGluZ10pKTtcbiAgICAvLyBSMy01NjAgKFItQVJELTE3KTogdGhlIHByb21wdCBzcGxpdHMgYXQgYSBjYWNoZSBicmVha3BvaW50IOKAlCB0aGUgUElOTkVEXG4gICAgLy8gcHJlZml4IChyb2xlLCBydWxlcywgd29ya2Zsb3csIHRoZSBkYXRlIGZyb3plbiBhdCBydW4gc3RhcnQpIGlzIHN0YW1wZWRcbiAgICAvLyBpbnRvIEIwIHNvIGEgcmVzdW1lIHJlcGxheXMgdGhlc2UgYnl0ZXMgZXhhY3RseTsgdGhlIExJVkUgc3VmZml4ICh0b29scyxcbiAgICAvLyBza2lsbHMsIHdvcmtzcGFjZSByb290KSBpcyByZWJ1aWx0IGV2ZXJ5IHRpbWUgYW5kIHRoZSBjYWNoZSBicmVhayBhdCB0aGVcbiAgICAvLyBib3VuZGFyeSBpcyBhY2NlcHRlZCwgbm90IHdvcmtlZCBhcm91bmQuXG4gICAgY29uc3QgcGlubmVkUHJlZml4ID0gYnVpbGRQaW5uZWRQcmVmaXgoeyB0b2RheTogdG9kYXlJc28oKSB9KTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdHJhbnNjcmlwdCA9IGF3YWl0IHJ1bkFnZW50KHtcbiAgICAgICAgY2xpZW50OiBjcmVhdGVDaGF0TW9kZWxDbGllbnQoKSxcbiAgICAgICAgdG9vbHM6IHRvb2xzZXQudG9vbHMsXG4gICAgICAgIGV4ZWN1dGU6IHRvb2xzZXQuZXhlY3V0ZSxcbiAgICAgICAgc3lzdGVtOiBjb21wb3NlU3lzdGVtUHJvbXB0KHBpbm5lZFByZWZpeCwgYnVpbGRMaXZlU3VmZml4KHsgdG9vbHM6IHRvb2xzZXQudG9vbHMsIHdvcmtzcGFjZVJvb3Q6IHN0YWdlVHJlZT8ucm9vdCwgc2tpbGxzIH0pKSxcbiAgICAgICAgd29ya3NwYWNlOiB3b3Jrc3BhY2VSZXBvID8/IHVuZGVmaW5lZCxcbiAgICAgICAgc3lzdGVtUHJlZml4OiBwaW5uZWRQcmVmaXgsXG4gICAgICAgIGhpc3RvcnksXG4gICAgICAgIHByb21wdDoga2lja29mZixcbiAgICAgICAgLy8gUjMtMjI0ICjCpzMuMyk6IHRoZSBzdG9wIGJ1dHRvbiBhYm9ydHMgdGhlIGxvb3AgQU5EIHRoZSBpbi1mbGlnaHQgTExNIHR1cm4uXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIC8vIFIzLTMzMzogdGhlIHN0ZWVyaW5nIHF1ZXVlIOKAlCB0aGUgb3RoZXIgdmVyYiB0aGUgaHVtYW4gaGFzLlxuICAgICAgICBzdGVlcmluZyxcbiAgICAgICAgLy8gUjMtNTYyICjCpzcgUi1BUkQtMjBhKTogcGF1c2UgYXQgdHVybiBib3VuZGFyaWVzIHdoaWxlIHRoaXMgcmVnaW9uIGlzIGhpZGRlbi5cbiAgICAgICAgcGF1c2UsXG4gICAgICAgIC8vIFRva2VuIGFjY291bnRpbmcgKyBhdXRvLWNvbXBhY3Rpb24gbGV0IHRoZSBsb29wIHJ1biBwYXN0IH4xMiB0dXJucyAoUjMtMjIwKS5cbiAgICAgICAgY29udGV4dFdpbmRvdzogZGVzY3JpYmVDaGF0KCk/LmZlYXR1cmVzLm1heENvbnRleHRUb2tlbnMsXG4gICAgICAgIGV2ZW50czoge1xuICAgICAgICAgIC8vIFIzLTU1OTogYXBwZW5kIGV2ZXJ5IGJvdW5kYXJ5IHRvIHRoZSBjb252ZXJzYXRpb24ncyBqb3VybmFsLiBUaGUgbG9vcFxuICAgICAgICAgIC8vIGF3YWl0cyB0aGlzIGJlZm9yZSBwcm9jZWVkaW5nIOKAlCB0aGUgd3JpdGUncyBsYXRlbmN5IElTIHRoZVxuICAgICAgICAgIC8vIGludGVudC1iZWZvcmUtZXhlY3V0ZSBvcmRlcmluZy5cbiAgICAgICAgICAuLi4oam91cm5hbFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgb25Cb3VuZGFyeTogYXN5bmMgKGIpID0+IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IHN0b3JlIS5hcHBlbmQoam91cm5hbC5pZCwgYik7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgb25Bc3Npc3RhbnREZWx0YTogKHRleHQpID0+IHNldFN0cmVhbWluZygocykgPT4gcyArIHRleHQpLFxuICAgICAgICAgIC8vIFIzLTMzNSDigJQgdGhlIGxpdmUgdGhpbmtpbmcgc3VyZmFjZS4gTm93IHRoYXQgY29tcGFjdGlvbiBsZXRzIGEgdGFzayBydW4gcGFzdFxuICAgICAgICAgIC8vIGEgZG96ZW4gdHVybnMsIHRoZSBzaWxlbnQgc3RyZXRjaGVzIGFyZSBsb25nZXIsIGFuZCBcImlzIGl0IHN0dWNrIG9yXG4gICAgICAgICAgLy8gdGhpbmtpbmc/XCIgaGFkIG5vIGFuc3dlciBvbiBzY3JlZW4uXG4gICAgICAgICAgb25SZWFzb25pbmdEZWx0YTogKHRleHQpID0+IHNldFRoaW5raW5nKCh0KSA9PiB0ICsgdGV4dCksXG4gICAgICAgICAgb25SZWFzb25pbmc6IChibG9jaykgPT4ge1xuICAgICAgICAgICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgICAgICAgICBhcHBlbmQoXG4gICAgICAgICAgICAgIGJsb2NrLnJlZGFjdGVkRGF0YSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgPyB7IGtpbmQ6IFwicmVhc29uaW5nXCIsIHRleHQ6IFwiXCIsIHJlZGFjdGVkOiB0cnVlIH1cbiAgICAgICAgICAgICAgICA6IHsga2luZDogXCJyZWFzb25pbmdcIiwgdGV4dDogYmxvY2sudGV4dCB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uQXNzaXN0YW50VGV4dDogKHRleHQpID0+IHtcbiAgICAgICAgICAgIC8vIEEgdHVybiBhbiBgaW50ZXJydXB0YCBzdGVlciBjdXQgc2hvcnQgaXMgaXRzIG93biByb3csIGxpdmUgYW5kIG9uXG4gICAgICAgICAgICAvLyByZXBsYXkg4oCUIG5vdCBhIHJlcGx5IHRoZSBtb2RlbCBhY3R1YWxseSB3cm90ZS5cbiAgICAgICAgICAgIGlmICh0ZXh0ID09PSBJTlRFUlJVUFRFRF9UVVJOX1RFWFQpIGFwcGVuZCh7IGtpbmQ6IFwiaW50ZXJydXB0ZWRcIiB9KTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHRleHQudHJpbSgpKSBhcHBlbmQoeyBraW5kOiBcInRleHRcIiwgdGV4dCB9KTtcbiAgICAgICAgICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uVG9vbFVzZTogKG5hbWUsIGlucHV0KSA9PiBhcHBlbmQoeyBraW5kOiBcInRvb2xcIiwgbmFtZSwgaW5wdXQgfSksXG4gICAgICAgICAgb25Ub29sUmVzdWx0OiAobmFtZSwgcikgPT4gYXBwZW5kKHsga2luZDogXCJyZXN1bHRcIiwgbmFtZSwgY29udGVudDogci5jb250ZW50LCBpc0Vycm9yOiByLmlzRXJyb3IgfSksXG4gICAgICAgICAgb25OdWRnZTogKCkgPT4gYXBwZW5kKHsga2luZDogXCJudWRnZVwiIH0pLFxuICAgICAgICAgIG9uVXNhZ2U6ICh1KSA9PlxuICAgICAgICAgICAgc2V0VXNhZ2Uoe1xuICAgICAgICAgICAgICBzcGVudFRva2VuczogdS5zcGVudFRva2VucyxcbiAgICAgICAgICAgICAgY2FjaGVSZWFkVG9rZW5zOiB1LmNhY2hlUmVhZFRva2VucyxcbiAgICAgICAgICAgICAgY2FjaGVXcml0ZVRva2VuczogdS5jYWNoZVdyaXRlVG9rZW5zLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgb25Db21wYWN0OiAoeyBzdW1tYXJpemVkQ291bnQsIGNhY2hlUmVhZFRva2VucyB9KSA9PiB7XG4gICAgICAgICAgICBhcHBlbmQoe1xuICAgICAgICAgICAgICBraW5kOiBcImNvbXBhY3Rpb25cIixcbiAgICAgICAgICAgICAgLy8gUjMtMzM2OiB0aGUgY29tcGFjdGlvbiByZXdyb3RlIHRoZSBjb252ZXJzYXRpb24gcHJlZml4LCBzbyB0aGUgbmV4dCB0dXJuXG4gICAgICAgICAgICAgIC8vIHJlLXdhcm1zIGl0LiBUaGUgZHVyYWJsZSBzeXN0ZW0rdG9vbHMgcHJlZml4IGlzIHVudG91Y2hlZC4gUmVjb3JkaW5nIHRoZVxuICAgICAgICAgICAgICAvLyBydW5uaW5nIGNhY2hlIHRvdGFsIEFUIHRoZSBib3VuZGFyeSBpcyB3aGF0IGxldHMgdGhlIGNvc3QgY3VydmUgYWNyb3NzIGFcbiAgICAgICAgICAgICAgLy8gY29tcGFjdGlvbiBiZSByZWFkIHJhdGhlciB0aGFuIGFzc3VtZWQuXG4gICAgICAgICAgICAgIHN1bW1hcnk6XG4gICAgICAgICAgICAgICAgYCR7c3VtbWFyaXplZENvdW50fSBlYXJsaWVyIG1lc3NhZ2VzIHN1bW1hcml6ZWRgICtcbiAgICAgICAgICAgICAgICAoY2FjaGVSZWFkVG9rZW5zICE9PSB1bmRlZmluZWQgPyBgIMK3ICR7Y2FjaGVSZWFkVG9rZW5zfSBjYWNoZWQgdG9rZW5zIHJlYWQgc28gZmFyYCA6IFwiXCIpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAvLyBSMy01NTkgKFItQVJELTkpOiBjb21wYWN0aW9uIGlzIGEgbmF0dXJhbCBmb2xkIHBvaW50IOKAlCBpdCByZXdyb3RlIHRoZVxuICAgICAgICAgICAgLy8gdHJhbnNjcmlwdCBwcmVmaXggYW55d2F5LiBCZXN0LWVmZm9ydCBtaWQtcnVuOiBhIGZhaWxlZCBmb2xkIGNvc3RzIHRoZVxuICAgICAgICAgICAgLy8gZm9sZCwgbmV2ZXIgdGhlIHJ1biAodGhlIGpvdXJuYWwgcmV0YWlucyBldmVyeXRoaW5nOyB0aGUgcnVuLWVuZCBmb2xkXG4gICAgICAgICAgICAvLyBpcyB0aGUgYXV0aG9yaXRhdGl2ZSB3cml0ZSksIHNvIGl0IGlzIGxvZ2dlZC1hbmQtZHJvcHBlZCwgbm90IHRocm93bi5cbiAgICAgICAgICAgIGlmIChqb3VybmFsKSB7XG4gICAgICAgICAgICAgIHZvaWQgc3RvcmUhLmZvbGQoam91cm5hbC5pZCkuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJtaWQtcnVuIGZvbGQgYXQgY29tcGFjdGlvbiBmYWlsZWQgKHJ1bi1lbmQgZm9sZCBzdGlsbCB3aWxsKVwiLCBlKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvblN0ZWVyOiAoeyBtZXNzYWdlcyB9KSA9PiB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG0gb2YgbWVzc2FnZXMpIGFwcGVuZCh7IGtpbmQ6IFwic3RlZXJcIiwgbW9kZTogbS5tb2RlLCB0ZXh0OiBtLnRleHQgfSk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgaWYgKGNvbnYgJiYgc3RvcmUpIHtcbiAgICAgICAgY29uc3QgbmV3VGl0bGUgPSBjb252LnRpdGxlID09PSBcIk5ldyBjb252ZXJzYXRpb25cIiA/IGRlcml2ZVRpdGxlKHRyYW5zY3JpcHQpIDogY29udi50aXRsZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBSMy01NTk6IHRoZSBydW4tZW5kIHNhdmUgaXMgbm93IGEgRk9MRCAoUi1BUkQtOSkg4oCUIHRoZSByZWNvcmQgZ2V0c1xuICAgICAgICAgIC8vIHRoZSBhdXRob3JpdGF0aXZlIHRyYW5zY3JpcHQgKGJ5dGUtdHJ1ZSB0byB3aGF0IHRoZSBtb2RlbCBzYXcpLCB0aGVcbiAgICAgICAgICAvLyBmb2xkIHdhdGVybWFyaywgYW5kIHRoZSBjYXJyaWVkIHJ1bi1zdGF0ZTsgdGhlIHN1cGVyc2VkZWQgam91cm5hbFxuICAgICAgICAgIC8vIGVudHJpZXMgYXJlIHJlY2xhaW1lZCAoUi1BUkQtNWMpLlxuICAgICAgICAgIGNvbnZSZWYuY3VycmVudCA9IGF3YWl0IHN0b3JlLmZvbGQoY29udi5pZCwge1xuICAgICAgICAgICAgbWVzc2FnZXM6IHRyYW5zY3JpcHQsXG4gICAgICAgICAgICB0aXRsZTogbmV3VGl0bGUsXG4gICAgICAgICAgICByZXBvOiBjb252LnJlcG8gPz8gd29ya3NwYWNlUmVwbyxcbiAgICAgICAgICAgIC4uLihjb252LnJlcG8gPT09IHVuZGVmaW5lZCA/IHsgcmVwb1Byb3ZpZGVyOiB3b3Jrc3BhY2VQcm92aWRlciB9IDoge30pLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHNldFRpdGxlKG5ld1RpdGxlKTtcbiAgICAgICAgICBzZXRTdG9yZUVycm9yKG51bGwpO1xuICAgICAgICAgIC8vIFIzLTYzMSDigJQgdGhlIHNhdmUgaXMgdGhlIG5hdHVyYWwgaGVhcnRiZWF0OiBtZXNzYWdlQ291bnQgZ3Jldy5cbiAgICAgICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25TYXZlZCgpO1xuICAgICAgICAgIHZvaWQgcG9zdFRvUmVnaW9uKFBBTkVMX1JFR0lPTiwgeyB0eXBlOiBcImNvbnZlcnNhdGlvbi11cGRhdGVkXCIsIGlkOiBjb252LmlkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIEEgZmFpbGVkIHNhdmUgbWVhbnMgYGNvbnZSZWYuY3VycmVudGAga2VlcHMgdGhlIFBSRS1ydW4gbWVzc2FnZXMsIHNvIHRoZVxuICAgICAgICAgIC8vIG5leHQgdHVybiByZS1zZW5kcyBhIHN0YWxlIChvciBlbXB0eSkgaGlzdG9yeSDigJQgdGhlIHNhbWUgYW1uZXNpYSBhcyBhXG4gICAgICAgICAgLy8gZGVhZCBzdG9yZSwgb25lIHR1cm4gbGF0ZXIuIE5ldmVyIHNpbGVudCAoUjMtMjQ3KS5cbiAgICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gUjMtNTYxOiB0aGUgdHdvIGxlYXNlIGNvZGVzIGFyZSBVWCBzdGF0ZXMsIG5vdCBjb2RlcyB0byBwcmludCAowqc5KS4gVGhlXG4gICAgICAvLyBkaXNjcmltaW5hdGlvbiBhbmQgdGhlIGNvcHkgbGl2ZSBpbiBgbGliL3N0b3JlRXJyb3JgIOKAlCBwYXN0aW5nIHRoZW0gaGVyZVxuICAgICAgLy8gaXMgd2hhdCBtYWRlIHRoZSByZXN1bWUgY2F0Y2ggYmVsb3cgZ2V0IG1pc3NlZCB0aGUgZmlyc3QgdGltZS5cbiAgICAgIGNvbnN0IGxlYXNlID0gbGVhc2VGYWlsdXJlKGUpO1xuICAgICAgaWYgKGxlYXNlKSB7XG4gICAgICAgIGFwcGVuZCh7IGtpbmQ6IFwiZXJyb3JcIiwgdGV4dDogbGVhc2VGYWlsdXJlVGV4dChsZWFzZSwgdHJ1ZSkgfSk7XG4gICAgICAgIGlmIChsZWFzZSA9PT0gXCJsZWFzZS1sb3N0XCIpIHtcbiAgICAgICAgICBzZXRMZWFzZUhlbGQoeyBjb252SWQ6IHJ1bm5pbmdJZFJlZi5jdXJyZW50ID8/IGNvbnZSZWYuY3VycmVudD8uaWQgPz8gXCJcIiwgcmVzdW1lOiBmYWxzZSB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXBwZW5kKHsga2luZDogXCJlcnJvclwiLCB0ZXh0OiAoZSBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gU3RyaW5nKGUpIH0pO1xuICAgICAgfVxuICAgICAgLy8gUjMtNTU5IChSLUFSRC0xMGEpOiBhIGZhaWxlZCBjaGVja3BvaW50IGFwcGVuZCB1bndpbmRzIHRoZSBydW4gaGVyZS4gTmFtZVxuICAgICAgLy8gdGhlIGR1cmFiaWxpdHkgY29uc2VxdWVuY2Ug4oCUIHRoZSBydW4gc3RvcHBlZCBBVCBhIGJvdW5kYXJ5IGFuZCBldmVyeXRoaW5nXG4gICAgICAvLyBjaGVja3BvaW50ZWQgc28gZmFyIHN1cnZpdmVzICh0aGUgam91cm5hbCBzdGF5cyByZXN1bWFibGUpLlxuICAgICAgaWYgKGlzSm91cm5hbFJlZnVzYWwoZSkpIHtcbiAgICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZShlLCBKT1VSTkFMX1JFRlVTQUxfU1VGRklYKSk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIG9mZlN0ZWVyQ2hhbmdlKCk7XG4gICAgICBzdGVlclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIGRpc3Bvc2VQYXVzZSgpO1xuICAgICAgc2V0UXVldWVkKFtdKTtcbiAgICAgIHNldFN0ZWVyVGV4dChcIlwiKTtcbiAgICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICAgIHNldFRoaW5raW5nKFwiXCIpO1xuICAgICAgc2V0UnVubmluZyhmYWxzZSk7XG4gICAgICByZWxlYXNlSGVsZExlYXNlKCk7IC8vIEJFRk9SRSBydW5uaW5nSWRSZWYgaXMgY2xlYXJlZCDigJQgaXQgaXMgdGhlIGlkIHRvIHJlbGVhc2VcbiAgICAgIHJ1bm5pbmdJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIGFib3J0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcHVibGlzaGVyUmVmLmN1cnJlbnQ/Lm9uUnVuRW5kKCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFIzLTIyNCAowqczLjMpOiBzdG9wIHRoZSBpbi1mbGlnaHQgcnVuIOKAlCBhYm9ydHMgdGhlIGxvb3AgYmV0d2VlbiB0b29sIGNhbGxzIEFORCB0aGVcbiAgLy8gaW4tZmxpZ2h0IExMTSByZXF1ZXN0ICh0aGUgaG9zdCB0ZWFycyBkb3duIHRoZSB1cHN0cmVhbSBwcm92aWRlciBmZXRjaCwgc3RvcHMgYmlsbGluZykuXG4gIGNvbnN0IHN0b3AgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgYWJvcnRSZWYuY3VycmVudD8uYWJvcnQoKTtcbiAgfSwgW10pO1xuXG4gIC8vIC0tLS0gUjMtNTYwOiB0aGUgYXR0ZW5kZWQtcmVzdW1lIGNob2ljZXMgKFItQVJELTE1KSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy9cbiAgLy8gQm9vdGluZyBhbiBpbnRlcnJ1cHRlZCBjb252ZXJzYXRpb24gb2ZmZXJlZCB0aHJlZSBzcGVjJ2QgY2hvaWNlczsgdGhlIHRoaXJkIOKAlFxuICAvLyBcImRpc2NhcmQgdGhlIHRhaWwgQU5EIHJldmVydCB0aGUgcnVuJ3Mgd3JpdGVzXCIg4oCUIGlzIE5PVCBvZmZlcmVkIGhlcmUgYmVjYXVzZVxuICAvLyB0aGUgYXBwIGNhbm5vdCBib3VuZCB3aGljaCB3cml0ZXMgd2VyZSB0aGUgcnVuJ3MgKHRoZSBDb1cgbGF5ZXIgaXNcbiAgLy8gaG9zdC1zaWRlKSwgYW5kIGEgZGlzY2FyZCB0aGF0IHNpbGVudGx5IGtlZXBzIHRoZSBmaWxlcyBtYW51ZmFjdHVyZXMgZXhhY3RseVxuICAvLyB0aGUgZGl2ZXJnZW5jZSB0aGlzIHdvcmsgZXhpc3RzIHRvIHJlbW92ZS4gVGhlIGRpc3Bvc2l0aW9uIGlzIHJlY29yZGVkIGluXG4gIC8vIEFHRU5UX1JVTl9EVVJBQklMSVRZX1NQRUMgwqc1LjM7IHRoZSBrZWVwLWNob2ljZSBjb3B5IHNheXMgcGxhaW5seSB0aGF0IHRoZVxuICAvLyBmaWxlIGNoYW5nZXMgc3RheS5cblxuICAvKiogUmVzdW1lIHRoZSBpbnRlcnJ1cHRlZCBydW46IHJlcGFpciB0aGUgdHJhbnNjcmlwdCwgbmFtZSBhbnkgZGl2ZXJnZW5jZSxcbiAgICogIGFuZCBjb250aW51ZSB0aGUgbG9vcCBXSVRIT1VUIGEgbmV3IHByb21wdCB0dXJuLiAqL1xuICBjb25zdCByZXN1bWVSdW4gPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIGNvbnN0IHBlbmRpbmcgPSBwZW5kaW5nUmVzdW1lO1xuICAgIGNvbnN0IGNvbnYgPSBjb252UmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzdG9yZSB8fCAhcGVuZGluZyB8fCAhY29udiB8fCBydW5uaW5nIHx8IHBlbmRpbmcuY29udklkICE9PSBjb252LmlkKSByZXR1cm47XG4gICAgLy8gVGhlIHNhbWUgd29ya3NwYWNlLXJlYWRpbmVzcyBnYXRlIGFzIGEgZnJlc2ggUnVuOiBhIHJlc3VtZSBhdXRob3JzIGZpbGVzXG4gICAgLy8gdGhyb3VnaCB0aGUgY29uZmVycmVkIHN0YWdlIHRyZWUsIGFuZCB3aXRob3V0IGl0IHRoZSBsb29wIHdvdWxkIHJ1blxuICAgIC8vIGNhdGFsb2ctb25seSBvciAocHJlLVIzLTU2OSkgYWdhaW5zdCB0aGUgd3JvbmcgdHJlZS4gUmVmdXNlLCBzYXkgd2h5LlxuICAgIGlmICghc3RhZ2VUcmVlKSB7XG4gICAgICBhcHBlbmQoe1xuICAgICAgICBraW5kOiBcImVycm9yXCIsXG4gICAgICAgIHRleHQ6IFwiTm8gYXBwIHdvcmtzcGFjZSBpcyBjb25uZWN0ZWQgeWV0LiBPcGVuIGFuIGFwcCBpbiB0aGUgc3RhZ2UgKGFuZCBnaXZlIGl0IGEgbW9tZW50IHRvIG1vdW50KSBiZWZvcmUgcmVzdW1pbmcg4oCUIEkgd29uJ3QgdG91Y2ggbXkgb3duIGZpbGVzLlwiLFxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIFIzLTU2MTogc2FtZSBnYXRlIGFzIGEgZnJlc2ggUnVuLiBBIHJlbG9hZCBtaWQtcnVuIGlzIGEgTkVXIGZyYW1lIHdpdGggYSBuZXdcbiAgICAvLyB0YWJJZCwgc28gc2FtZS10YWIgcmVjbGFpbSBkb2VzIG5vdCBjb3ZlciBpdCBhbmQgdGhlIGRlYWQgZnJhbWUncyBsZWFzZSBpc1xuICAgIC8vIHN0aWxsIGxpdmUgdW50aWwgaXRzIFRUTCDigJQgd2hpY2ggaXMgZXhhY3RseSB0aGUgY2FzZSB0aGUgdGFrZW92ZXIgb2ZmZXIgaXNcbiAgICAvLyBmb3IuIFRoZSBob3N0IGNhbm5vdCB0ZWxsIGEgcmVsb2FkIGZyb20gYSBzZWNvbmQgdGFiLCBhbmQgcHJldGVuZGluZyBpdCBjYW5cbiAgICAvLyB3b3VsZCBiZSB0aGUgZG91YmxlLWRyaXZlIHRoaXMgbWVjaGFuaXNtIGV4aXN0cyB0byBwcmV2ZW50LlxuICAgIHRyeSB7XG4gICAgICBpZiAoKGF3YWl0IHN0b3JlLmFjcXVpcmVSdW4oY29udi5pZCkpID09PSBcImhlbGRcIikge1xuICAgICAgICBzZXRMZWFzZUhlbGQoeyBjb252SWQ6IGNvbnYuaWQsIHJlc3VtZTogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgfVxuICAgIHNldFBlbmRpbmdSZXN1bWUobnVsbCk7XG4gICAgY29uc3QgcmVwbGF5ID0gcGVuZGluZy5yZXBsYXk7XG4gICAgY29uc3QgcmVwYWlyZWQgPSByZXBhaXJUcmFuc2NyaXB0KHtcbiAgICAgIG1lc3NhZ2VzOiByZXBsYXkubWVzc2FnZXMsXG4gICAgICBwZW5kaW5nRWZmZWN0czogcmVwbGF5LnBlbmRpbmdFZmZlY3RzLFxuICAgICAgdHJhaWxpbmdQYXJ0aWFsOiByZXBsYXkudHJhaWxpbmdQYXJ0aWFsLFxuICAgIH0pO1xuICAgIC8vIFItQVJELTE2OiBzYXkgd2hhdCBtb3ZlZCwgaW4gdGhlIHRyYW5zY3JpcHQsIGJlZm9yZSB0aGUgbW9kZWwgd29ya3MuIEFuXG4gICAgLy8gVU5TRVRUTEVEIHdvcmtzcGFjZSBjaGFubmVsICh1bmRlZmluZWQpIGNsYWltcyBub3RoaW5nIOKAlCBuZXZlciBmYWJyaWNhdGVcbiAgICAvLyBhIGRpdmVyZ2VuY2UgZnJvbSBhbiB1bmtub3duLlxuICAgIGNvbnN0IGRpdmVyZ2VuY2UgPSBkaXZlcmdlbmNlTWVzc2FnZShyZXBsYXkuc3RhbXBlZFdvcmtzcGFjZSwgd29ya3NwYWNlUmVwbyk7XG4gICAgY29uc3QgcmVzdW1lZCA9IHJlc3VtZWRNZXNzYWdlcyhyZXBhaXJlZC5tZXNzYWdlcywgZGl2ZXJnZW5jZSk7XG4gICAgc2V0TG9nKG1lc3NhZ2VzVG9Mb2cocmVwYWlyZWQubWVzc2FnZXMpKTtcbiAgICBzZXRSdW5uaW5nKHRydWUpO1xuICAgIHJ1bm5pbmdJZFJlZi5jdXJyZW50ID0gY29udi5pZDtcbiAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25SdW5TdGFydChjb252LmlkKTtcbiAgICBzZXRTdHJlYW1pbmcoXCJcIik7XG4gICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgYXBwZW5kKHsga2luZDogXCJzdGVlclwiLCBtb2RlOiBcInF1ZXVlXCIsIHRleHQ6IFwiUnVuIHJlc3VtZWQgZnJvbSBpdHMgbGFzdCBjaGVja3BvaW50XCIgfSk7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBhYm9ydFJlZi5jdXJyZW50ID0gY29udHJvbGxlcjtcbiAgICBjb25zdCBzdGVlcmluZ0MgPSBuZXcgU3RlZXJDb250cm9sbGVyKCk7XG4gICAgc3RlZXJSZWYuY3VycmVudCA9IHN0ZWVyaW5nQztcbiAgICAvLyBSMy01NjI6IHRoZSBzYW1lIGhpZGXihpJwYXVzZSBqb2luIGFzIGEgZnJlc2ggcnVuIOKAlCBhIHJlc3VtZWQgcnVuIGlzIGVxdWFsbHlcbiAgICAvLyBpbnZpc2libGUgd2hlbiB0aGUgcmVnaW9uIGlzIGhpZGRlbi5cbiAgICBjb25zdCB7IHBhdXNlLCBkaXNwb3NlOiBkaXNwb3NlUGF1c2UgfSA9IGNyZWF0ZVJ1blBhdXNlKCk7XG4gICAgc2V0UXVldWVkKFtdKTtcbiAgICBjb25zdCBvZmZTdGVlckNoYW5nZSA9IHN0ZWVyaW5nQy5vbkNoYW5nZSgocSkgPT4gc2V0UXVldWVkKFsuLi5xXSkpO1xuICAgIC8vIFItQVJELTE3OiB0aGUgUElOTkVEIHByZWZpeCByZXBsYXlzIGJ5dGUtaWRlbnRpY2FsbHkgZnJvbSB0aGUgam91cm5hbCAodGhlXG4gICAgLy8gZnJvemVuIGRhdGUgc3Vydml2ZXMgbWlkbmlnaHQpOyB0aGUgTElWRSBzdWZmaXggaXMgcmVidWlsdCBmcm9tIHRoZVxuICAgIC8vIGN1cnJlbnQgY2F0YWxvZyDigJQgYSByZXZva2VkIHRvb2wgaXMgYWJzZW50LCBob25lc3RseSB0YWtpbmcgdGhlIGNhY2hlIG1pc3MuXG4gICAgY29uc3QgcGlubmVkUHJlZml4ID0gcmVwbGF5LnN5c3RlbVByZWZpeCA/PyBidWlsZFBpbm5lZFByZWZpeCh7IHRvZGF5OiB0b2RheUlzbygpIH0pO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0cmFuc2NyaXB0ID0gYXdhaXQgcnVuQWdlbnQoe1xuICAgICAgICBjbGllbnQ6IGNyZWF0ZUNoYXRNb2RlbENsaWVudCgpLFxuICAgICAgICB0b29sczogdG9vbHNldC50b29scyxcbiAgICAgICAgZXhlY3V0ZTogdG9vbHNldC5leGVjdXRlLFxuICAgICAgICBzeXN0ZW06IGNvbXBvc2VTeXN0ZW1Qcm9tcHQocGlubmVkUHJlZml4LCBidWlsZExpdmVTdWZmaXgoeyB0b29sczogdG9vbHNldC50b29scywgd29ya3NwYWNlUm9vdDogc3RhZ2VUcmVlPy5yb290LCBza2lsbHMgfSkpLFxuICAgICAgICB3b3Jrc3BhY2U6IHdvcmtzcGFjZVJlcG8gPz8gdW5kZWZpbmVkLFxuICAgICAgICBzeXN0ZW1QcmVmaXg6IHBpbm5lZFByZWZpeCxcbiAgICAgICAgcmVzdW1lOiB7XG4gICAgICAgICAgbWVzc2FnZXM6IHJlc3VtZWQsXG4gICAgICAgICAgLi4uKHJlcGxheS5ydW5TdGF0ZSAhPT0gbnVsbCA/IHsgcnVuU3RhdGU6IHJlcGxheS5ydW5TdGF0ZSBhcyBSdW5TdGF0ZSB9IDoge30pLFxuICAgICAgICB9LFxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICBzdGVlcmluZzogc3RlZXJpbmdDLFxuICAgICAgICBwYXVzZSxcbiAgICAgICAgY29udGV4dFdpbmRvdzogZGVzY3JpYmVDaGF0KCk/LmZlYXR1cmVzLm1heENvbnRleHRUb2tlbnMsXG4gICAgICAgIGV2ZW50czoge1xuICAgICAgICAgIG9uQm91bmRhcnk6IGFzeW5jIChiKSA9PiB7XG4gICAgICAgICAgICBhd2FpdCBzdG9yZS5hcHBlbmQoY29udi5pZCwgYik7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvbkFzc2lzdGFudERlbHRhOiAodGV4dCkgPT4gc2V0U3RyZWFtaW5nKChzKSA9PiBzICsgdGV4dCksXG4gICAgICAgICAgb25SZWFzb25pbmdEZWx0YTogKHRleHQpID0+IHNldFRoaW5raW5nKCh0KSA9PiB0ICsgdGV4dCksXG4gICAgICAgICAgb25SZWFzb25pbmc6IChibG9jaykgPT4ge1xuICAgICAgICAgICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgICAgICAgICBhcHBlbmQoXG4gICAgICAgICAgICAgIGJsb2NrLnJlZGFjdGVkRGF0YSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgPyB7IGtpbmQ6IFwicmVhc29uaW5nXCIsIHRleHQ6IFwiXCIsIHJlZGFjdGVkOiB0cnVlIH1cbiAgICAgICAgICAgICAgICA6IHsga2luZDogXCJyZWFzb25pbmdcIiwgdGV4dDogYmxvY2sudGV4dCB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uQXNzaXN0YW50VGV4dDogKHRleHQpID0+IHtcbiAgICAgICAgICAgIGlmICh0ZXh0ID09PSBJTlRFUlJVUFRFRF9UVVJOX1RFWFQpIGFwcGVuZCh7IGtpbmQ6IFwiaW50ZXJydXB0ZWRcIiB9KTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHRleHQudHJpbSgpKSBhcHBlbmQoeyBraW5kOiBcInRleHRcIiwgdGV4dCB9KTtcbiAgICAgICAgICAgIHNldFN0cmVhbWluZyhcIlwiKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uVG9vbFVzZTogKG5hbWUsIGlucHV0KSA9PiBhcHBlbmQoeyBraW5kOiBcInRvb2xcIiwgbmFtZSwgaW5wdXQgfSksXG4gICAgICAgICAgb25Ub29sUmVzdWx0OiAobmFtZSwgcikgPT4gYXBwZW5kKHsga2luZDogXCJyZXN1bHRcIiwgbmFtZSwgY29udGVudDogci5jb250ZW50LCBpc0Vycm9yOiByLmlzRXJyb3IgfSksXG4gICAgICAgICAgb25OdWRnZTogKCkgPT4gYXBwZW5kKHsga2luZDogXCJudWRnZVwiIH0pLFxuICAgICAgICAgIG9uVXNhZ2U6ICh1KSA9PlxuICAgICAgICAgICAgc2V0VXNhZ2Uoe1xuICAgICAgICAgICAgICBzcGVudFRva2VuczogdS5zcGVudFRva2VucyxcbiAgICAgICAgICAgICAgY2FjaGVSZWFkVG9rZW5zOiB1LmNhY2hlUmVhZFRva2VucyxcbiAgICAgICAgICAgICAgY2FjaGVXcml0ZVRva2VuczogdS5jYWNoZVdyaXRlVG9rZW5zLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgb25Db21wYWN0OiAoeyBzdW1tYXJpemVkQ291bnQgfSkgPT4ge1xuICAgICAgICAgICAgYXBwZW5kKHsga2luZDogXCJjb21wYWN0aW9uXCIsIHN1bW1hcnk6IGAke3N1bW1hcml6ZWRDb3VudH0gZWFybGllciBtZXNzYWdlcyBzdW1tYXJpemVkYCB9KTtcbiAgICAgICAgICAgIHZvaWQgc3RvcmVcbiAgICAgICAgICAgICAgLmZvbGQoY29udi5pZClcbiAgICAgICAgICAgICAgLmNhdGNoKChlKSA9PiBjb25zb2xlLndhcm4oXCJtaWQtcnVuIGZvbGQgYXQgY29tcGFjdGlvbiBmYWlsZWQgKHJ1bi1lbmQgZm9sZCBzdGlsbCB3aWxsKVwiLCBlKSk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvblN0ZWVyOiAoeyBtZXNzYWdlcyB9KSA9PiB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG0gb2YgbWVzc2FnZXMpIGFwcGVuZCh7IGtpbmQ6IFwic3RlZXJcIiwgbW9kZTogbS5tb2RlLCB0ZXh0OiBtLnRleHQgfSk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29udlJlZi5jdXJyZW50ID0gYXdhaXQgc3RvcmUuZm9sZChjb252LmlkLCB7XG4gICAgICAgICAgbWVzc2FnZXM6IHRyYW5zY3JpcHQsXG4gICAgICAgICAgcmVwbzogY29udi5yZXBvID8/IHdvcmtzcGFjZVJlcG8sXG4gICAgICAgICAgLi4uKGNvbnYucmVwbyA9PT0gdW5kZWZpbmVkID8geyByZXBvUHJvdmlkZXI6IHdvcmtzcGFjZVByb3ZpZGVyIH0gOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRTdG9yZUVycm9yKG51bGwpO1xuICAgICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25TYXZlZCgpO1xuICAgICAgICB2b2lkIHBvc3RUb1JlZ2lvbihQQU5FTF9SRUdJT04sIHsgdHlwZTogXCJjb252ZXJzYXRpb24tdXBkYXRlZFwiLCBpZDogY29udi5pZCB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmUoZSwgTk9fU1RPUkVfU1VGRklYKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gUjMtNTYxOiB0aGUgc2FtZSBtYXBwaW5nIGFzIGBydW5gJ3MgY2F0Y2guIFRoaXMgaXMgdGhlIHBhdGggdGhlIHRha2VvdmVyXG4gICAgICAvLyBidXR0b24gaXRzZWxmIGludm9rZXMsIHNvIGEgdXNlciB3aG8gdGFrZXMgb3ZlciBhIHJlc3VtYWJsZSBydW4gYW5kIGxvc2VzXG4gICAgICAvLyB0aGUgbGVhc2UgYWdhaW4gbGFuZHMgaGVyZSDigJQgaXQgcHJpbnRlZCB0aGUgcmF3IGludGVybmFsIHN0cmluZyB1bnRpbCB0aGVcbiAgICAgIC8vIGRpc2NyaW1pbmF0aW9uIG1vdmVkIGludG8gYGxpYi9zdG9yZUVycm9yYC5cbiAgICAgIGNvbnN0IGxlYXNlID0gbGVhc2VGYWlsdXJlKGUpO1xuICAgICAgaWYgKGxlYXNlKSB7XG4gICAgICAgIGFwcGVuZCh7IGtpbmQ6IFwiZXJyb3JcIiwgdGV4dDogbGVhc2VGYWlsdXJlVGV4dChsZWFzZSwgdHJ1ZSkgfSk7XG4gICAgICAgIGlmIChsZWFzZSA9PT0gXCJsZWFzZS1sb3N0XCIpIHtcbiAgICAgICAgICBzZXRMZWFzZUhlbGQoeyBjb252SWQ6IHJ1bm5pbmdJZFJlZi5jdXJyZW50ID8/IGNvbnZSZWYuY3VycmVudD8uaWQgPz8gXCJcIiwgcmVzdW1lOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcHBlbmQoeyBraW5kOiBcImVycm9yXCIsIHRleHQ6IChlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBTdHJpbmcoZSkgfSk7XG4gICAgICB9XG4gICAgICBpZiAoaXNKb3VybmFsUmVmdXNhbChlKSkge1xuICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIEpPVVJOQUxfUkVGVVNBTF9TVUZGSVgpKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgb2ZmU3RlZXJDaGFuZ2UoKTtcbiAgICAgIHN0ZWVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgZGlzcG9zZVBhdXNlKCk7XG4gICAgICBzZXRRdWV1ZWQoW10pO1xuICAgICAgc2V0U3RlZXJUZXh0KFwiXCIpO1xuICAgICAgc2V0U3RyZWFtaW5nKFwiXCIpO1xuICAgICAgc2V0VGhpbmtpbmcoXCJcIik7XG4gICAgICBzZXRSdW5uaW5nKGZhbHNlKTtcbiAgICAgIHJlbGVhc2VIZWxkTGVhc2UoKTsgLy8gQkVGT1JFIHJ1bm5pbmdJZFJlZiBpcyBjbGVhcmVkIOKAlCBpdCBpcyB0aGUgaWQgdG8gcmVsZWFzZVxuICAgICAgcnVubmluZ0lkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgYWJvcnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBwdWJsaXNoZXJSZWYuY3VycmVudD8ub25SdW5FbmQoKTtcbiAgICB9XG4gIH07XG5cbiAgLyoqIEtlZXAgdGhlIGZpbGVzLCBlbmQgdGhlIHJ1bjogZm9sZCB0aGUgcmVwYWlyZWQgdHJhbnNjcmlwdCBzbyB0aGUgam91cm5hbCdzXG4gICAqICB3YXRlcm1hcmsgYWR2YW5jZXMgYW5kIHRoZSBjb252ZXJzYXRpb24gY2xvc2VzIGNsZWFubHkuIFRoZSBGSUxFIENIQU5HRVNcbiAgICogIFNUQVkg4oCUIHRoZSBjb3B5IHNheXMgc28gKHNwZWMgwqc1LjMncyByZXYtMiB0cmFwKS4gKi9cbiAgY29uc3Qga2VlcEFuZENsb3NlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBjb25zdCBwZW5kaW5nID0gcGVuZGluZ1Jlc3VtZTtcbiAgICBjb25zdCBjb252ID0gY29udlJlZi5jdXJyZW50O1xuICAgIGlmICghc3RvcmUgfHwgIXBlbmRpbmcgfHwgIWNvbnYgfHwgcGVuZGluZy5jb252SWQgIT09IGNvbnYuaWQpIHJldHVybjtcbiAgICBzZXRQZW5kaW5nUmVzdW1lKG51bGwpO1xuICAgIGNvbnN0IHJlcGFpcmVkID0gcmVwYWlyVHJhbnNjcmlwdCh7XG4gICAgICBtZXNzYWdlczogcGVuZGluZy5yZXBsYXkubWVzc2FnZXMsXG4gICAgICBwZW5kaW5nRWZmZWN0czogcGVuZGluZy5yZXBsYXkucGVuZGluZ0VmZmVjdHMsXG4gICAgICB0cmFpbGluZ1BhcnRpYWw6IHBlbmRpbmcucmVwbGF5LnRyYWlsaW5nUGFydGlhbCxcbiAgICB9KTtcbiAgICB0cnkge1xuICAgICAgY29udlJlZi5jdXJyZW50ID0gYXdhaXQgc3RvcmUuZm9sZChjb252LmlkLCB7XG4gICAgICAgIG1lc3NhZ2VzOiByZXBhaXJlZC5tZXNzYWdlcyxcbiAgICAgICAgcmVwbzogY29udi5yZXBvID8/IHdvcmtzcGFjZVJlcG8sXG4gICAgICAgIC4uLihjb252LnJlcG8gPT09IHVuZGVmaW5lZCA/IHsgcmVwb1Byb3ZpZGVyOiB3b3Jrc3BhY2VQcm92aWRlciB9IDoge30pLFxuICAgICAgfSk7XG4gICAgICBzZXRMb2cobWVzc2FnZXNUb0xvZyhyZXBhaXJlZC5tZXNzYWdlcykpO1xuICAgICAgc2V0U3RvcmVFcnJvcihudWxsKTtcbiAgICAgIHZvaWQgcG9zdFRvUmVnaW9uKFBBTkVMX1JFR0lPTiwgeyB0eXBlOiBcImNvbnZlcnNhdGlvbi11cGRhdGVkXCIsIGlkOiBjb252LmlkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgIH1cbiAgfTtcblxuICAvLyBSMy0zMzM6IHRoZSBPVEhFUiB2ZXJiLiBgcXVldWVgIGFwcGxpZXMgYXQgdGhlIG5leHQgdHVybiBib3VuZGFyeSAodGhlIGluLWZsaWdodFxuICAvLyB0dXJuIGZpbmlzaGVzKTsgYGludGVycnVwdGAgZW5kcyB0aGUgaW4tZmxpZ2h0IG1vZGVsIHR1cm4gbm93IGFuZCBjb250aW51ZXMgd2l0aFxuICAvLyB0aGUgY29ycmVjdGlvbi4gTmVpdGhlciBlbmRzIHRoZSBydW4g4oCUIHRoYXQgaXMgd2hhdCBTdG9wIGlzIGZvci5cbiAgY29uc3Qgc3RlZXIgPSB1c2VDYWxsYmFjaygobW9kZTogU3RlZXJNb2RlKSA9PiB7XG4gICAgY29uc3QgcyA9IHN0ZWVyUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzKSByZXR1cm47XG4gICAgaWYgKHMuZW5xdWV1ZShzdGVlclRleHQsIG1vZGUpKSBzZXRTdGVlclRleHQoXCJcIik7XG4gIH0sIFtzdGVlclRleHRdKTtcblxuICBjb25zdCBjYW5jZWxTdGVlciA9IHVzZUNhbGxiYWNrKChpZDogc3RyaW5nKSA9PiB7XG4gICAgc3RlZXJSZWYuY3VycmVudD8uY2FuY2VsKGlkKTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYSBjYS0tc3RhZ2VcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiY2EtaGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtdGl0bGVcIj57dGl0bGUgfHwgXCJDb252ZXJzYXRpb25cIn08L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXN1YlwiPlxuICAgICAgICAgIHt0b29sc2V0LnRvb2xzLmxlbmd0aH0gdG9vbHMge3N0YWdlVHJlZSA/IFwiKGNhdGFsb2cgKyBmaWxlcylcIiA6IFwiKGNhdGFsb2cgb25seSlcIn1cbiAgICAgICAgICB7dXNhZ2UgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAge1wiIMK3IFwifVxuICAgICAgICAgICAgICB7dXNhZ2Uuc3BlbnRUb2tlbnMudG9Mb2NhbGVTdHJpbmcoKX0gdG9rZW5zXG4gICAgICAgICAgICAgIHsvKiBTaG93biBvbmx5IHdoZW4gdGhlIHByb3ZpZGVyIGFjdHVhbGx5IHJlcG9ydHMgY2FjaGluZyDigJQgYW4gYWJzZW50XG4gICAgICAgICAgICAgICAgICBjb3VudGVyIGlzIG5vdCBhIHplcm8sIGFuZCBhIFwiMCBjYWNoZWRcIiBiYWRnZSBvbiBhIHByb3ZpZGVyIHRoYXQgc2F5c1xuICAgICAgICAgICAgICAgICAgbm90aGluZyB3b3VsZCBiZSBhIGZhYnJpY2F0ZWQgbWVhc3VyZW1lbnQuICovfVxuICAgICAgICAgICAgICB7dXNhZ2UuY2FjaGVSZWFkVG9rZW5zICE9PSB1bmRlZmluZWQgJiYgYCDCtyAke3VzYWdlLmNhY2hlUmVhZFRva2Vucy50b0xvY2FsZVN0cmluZygpfSBjYWNoZWRgfVxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHshc3RhZ2VUcmVlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYS1saW5lIGNhLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLWVyclwiPlxuICAgICAgICAgICAgV2FpdGluZyBmb3IgdGhlIGFwcCdzIHdvcmtzcGFjZSB0byBjb25uZWN04oCmIGZpbGUgdG9vbHMgYXJlIHVuYXZhaWxhYmxlIHVudGlsIHRoZW5cbiAgICAgICAgICAgIChJIHdvbid0IGVkaXQgbXkgb3duIGZpbGVzKS5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge3N0b3JlRXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhLWxpbmUgY2EtZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtZXJyXCI+e3N0b3JlRXJyb3J9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJjYS1sb2dcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiByZWY9e2xvZ1JlZn0ga2V5PXtjb252SWQgPz8gXCJub25lXCJ9PlxuICAgICAgICB7LyogRm9sZGVkIHRvb2wgY2FsbHMgKyBtYXJrZG93biByZXBsaWVzIChSMy00NzMvUjMtNDc0KSDigJQgc2hhcmVkIHdpdGggdGhlXG4gICAgICAgICAgICBzdGFuZGFsb25lIENvZGluZ0FnZW50IHNvIGJvdGggdHJhbnNjcmlwdHMgcmVhZCBpZGVudGljYWxseS4gKi99XG4gICAgICAgIDxUcmFuc2NyaXB0Um93cyBsb2c9e2xvZ30gLz5cbiAgICAgICAgey8qIFRoZSBsaXZlIHN0cmVhbWluZyByb3cgc3RheXMgUExBSU4gdGV4dCAoUjMtNDc0KTogcmUtcGFyc2luZyBhblxuICAgICAgICAgICAgaW5jb21wbGV0ZSBtYXJrZG93biBkb2N1bWVudCBwZXIgZGVsdGEgZmxpY2tlcnMgKGFuIHVuY2xvc2VkIGNvZGUgZmVuY2VcbiAgICAgICAgICAgIHN3YWxsb3dzIHRoZSB0YWlsKTsgdGhlIHJvdyBzd2FwcyB0byByZW5kZXJlZCBtYXJrZG93biB3aGVuIHRoZSB0dXJuXG4gICAgICAgICAgICBjb21wbGV0ZXMgaW50byBhIHRyYW5zY3JpcHQgZW50cnkgYWJvdmUuICovfVxuICAgICAgICB7dGhpbmtpbmcgJiYgKFxuICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJjYS1saW5lIGNhLWxpdmVcIj5cbiAgICAgICAgICAgIHsvKiBPcGVuIHdoaWxlIGl0IHN0cmVhbXMg4oCUIHRoZSBwb2ludCBpcyB0byBTSE9XIHRoYXQgd29yayBpcyBoYXBwZW5pbmcg4oCUXG4gICAgICAgICAgICAgICAgdGhlbiBjb2xsYXBzZWQgb25jZSBpdCBiZWNvbWVzIGEgdHJhbnNjcmlwdCByb3cuICovfVxuICAgICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiY2EtcmVhc29uaW5nXCIgb3Blbj5cbiAgICAgICAgICAgICAgPHN1bW1hcnk+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtdGhpbmtpbmctZG90XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICB0aGlua2luZ+KAplxuICAgICAgICAgICAgICA8L3N1bW1hcnk+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhLXJlYXNvbmluZy1ib2R5XCIgcmVmPXtyZWFzb25pbmdSZWZ9PlxuICAgICAgICAgICAgICAgIHt0aGlua2luZ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kZXRhaWxzPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICl9XG4gICAgICAgIHtzdHJlYW1pbmcgJiYgKFxuICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJjYS1saW5lIGNhLXRleHQgY2EtbGl2ZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtdGV4dFwiPntzdHJlYW1pbmd9PC9zcGFuPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICl9XG4gICAgICA8L3VsPlxuXG4gICAgICB7LyogUjMtMzMzOiB3aGF0IGlzIHdhaXRpbmcgdG8gYmUgYXBwbGllZCwgYW5kIGEgd2F5IHRvIHRha2UgaXQgYmFjay4gQSBxdWV1ZWRcbiAgICAgICAgICBmb2xsb3ctdXAgdGhlIHVzZXIgY2Fubm90IHNlZSBvciBjYW5jZWwgaXMgd29yc2UgdGhhbiBubyBxdWV1ZSBhdCBhbGwuICovfVxuICAgICAge3F1ZXVlZC5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cImNhLXF1ZXVlZFwiIGFyaWEtbGFiZWw9XCJRdWV1ZWQgY29ycmVjdGlvbnNcIj5cbiAgICAgICAgICB7cXVldWVkLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgPGxpIGtleT17bS5pZH0gY2xhc3NOYW1lPVwiY2EtcXVldWVkLWl0ZW1cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtcXVldWVkLW1vZGVcIj57bS5tb2RlID09PSBcImludGVycnVwdFwiID8gXCJub3dcIiA6IFwibmV4dCBzdGVwXCJ9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYS1xdWV1ZWQtdGV4dFwiPnttLnRleHR9PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2EtcXVldWVkLWNhbmNlbFwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YENhbmNlbCBxdWV1ZWQgY29ycmVjdGlvbjogJHttLnRleHR9YH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjYW5jZWxTdGVlcihtLmlkKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIMOXXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSMy01NjAg4oCUIHRoZSBhdHRlbmRlZC1yZXN1bWUgYWZmb3JkYW5jZSAoUi1BUkQtMTUpLCBleHRyYWN0ZWQgKFIzLTY5NSlcbiAgICAgICAgICBzbyB0aGUgdHdvLWNob2ljZSBzaGFwZSBpcyBwaW5uZWQgYnkgaXRzIG93biB0ZXN0LiBTZWVcbiAgICAgICAgICBSZXN1bWVBZmZvcmRhbmNlLnRzeCBhbmQgdGhlIGNvbW1lbnQgYWJvdmUgYHJlc3VtZVJ1bmAuICovfVxuICAgICAge3BlbmRpbmdSZXN1bWUgJiYgIXJ1bm5pbmcgJiYgKFxuICAgICAgICA8UmVzdW1lQWZmb3JkYW5jZVxuICAgICAgICAgIGpvdXJuYWxEZXB0aD17cGVuZGluZ1Jlc3VtZS5yZXBsYXkuam91cm5hbERlcHRofVxuICAgICAgICAgIG9uUmVzdW1lPXsoKSA9PiB2b2lkIHJlc3VtZVJ1bigpfVxuICAgICAgICAgIG9uS2VlcEFuZEVuZD17KCkgPT4gdm9pZCBrZWVwQW5kQ2xvc2UoKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSMy01NjEgLyBSLUFSRC0xOGEg4oCUIHRoZSBsZWFzZSByZW5kZXJzIGFzIGFuIE9GRkVSLiBUaGUgY29weSBzYXlzIFwibWF5IGJlXCIsXG4gICAgICAgICAgbm90IFwiaXNcIiwgYmVjYXVzZSB0aGF0IGlzIHRoZSBob25lc3Qgc3RyZW5ndGggb2YgYW4gYWR2aXNvcnkgbGVhc2U6IHRoZVxuICAgICAgICAgIGhvbGRlciBjb3VsZCBiZSBhIGxpdmUgd2luZG93LCBvciBhIGZyYW1lIHRoYXQgd2FzIHRvcm4gZG93biB3aXRob3V0IGFuXG4gICAgICAgICAgdW5sb2FkIGhhbmRsZXIgYW5kIHdob3NlIGxlYXNlIGlzIHNpbXBseSB3YWl0aW5nIG91dCBpdHMgVFRMLiBUYWtpbmcgb3ZlclxuICAgICAgICAgIGNvbnRpbnVlcyB0aGUgYWN0aW9uIHRoYXQgd2FzIHJlZnVzZWQsIHNvIHRoZSB1c2VyIGRvZXMgbm90IGhhdmUgdG8gYXNrXG4gICAgICAgICAgdHdpY2UuICovfVxuICAgICAge2xlYXNlSGVsZCAmJiAhcnVubmluZyAmJiBsZWFzZUhlbGQuY29udklkID09PSBjb252SWQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhLWxpbmUgY2EtZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2EtZXJyXCI+e2xlYXNlSGVsZFRleHQodHJ1ZSl9PC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EtcmVzdW1lLXJvd1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2EtcnVuXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgcmVzdW1lOiB3YXNSZXN1bWUsIGNvbnZJZDogZm9yQ29udiB9ID0gbGVhc2VIZWxkO1xuICAgICAgICAgICAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhlIG9mZmVyIHN0YXlzIHVwIHVudGlsIHRoZSB0YWtlb3ZlciBhY3R1YWxseSBsYW5kcy4gQW5cbiAgICAgICAgICAgICAgICAgICAgLy8gZWFybGllciB2ZXJzaW9uIGRpc21pc3NlZCBpdCBmaXJzdCwgc28gYSByZWplY3RlZCB3cml0ZSBsZWZ0XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSB1c2VyIHdpdGggbm8gb2ZmZXIsIG5vIHJ1biBhbmQgbm8gbWVzc2FnZS5cbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0b3JlKSBhd2FpdCBzdG9yZS50YWtlT3ZlclJ1bihmb3JDb252KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0TGVhc2VIZWxkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRTdG9yZUVycm9yKGRlc2NyaWJlKGUsIE5PX1NUT1JFX1NVRkZJWCkpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBhd2FpdCAod2FzUmVzdW1lID8gcmVzdW1lUnVuKCkgOiBydW4oKSk7XG4gICAgICAgICAgICAgICAgfSkoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgVGFrZSBvdmVyXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNhLXN0ZWVyLWJ0blwiIG9uQ2xpY2s9eygpID0+IHNldExlYXNlSGVsZChudWxsKX0+XG4gICAgICAgICAgICAgIExlYXZlIGl0IGFsb25lXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogT25lIHJvdywgdHdvIG1vZGVzLiBOb3QgcnVubmluZzogdHlwZSBhIHByb21wdCBhbmQgUnVuLiBSdW5uaW5nOiB0aGUgc2FtZVxuICAgICAgICAgIGZpZWxkIFNURUVSUyDigJQgXCJTZW5kIGFmdGVyIHRoaXMgc3RlcFwiIHF1ZXVlcyBmb3IgdGhlIHR1cm4gYm91bmRhcnksIFwiU2VuZCBub3dcIlxuICAgICAgICAgIGludGVycnVwdHMgdGhlIGluLWZsaWdodCB0dXJuIOKAlCBhbmQgU3RvcCBzdGlsbCBlbmRzIHRoZSBydW4uIFRoZSB0aHJlZSB2ZXJic1xuICAgICAgICAgIHN0YXkgdmlzaWJseSBkaXN0aW5jdCAoZXhpdCAzKSBhbmQgd3JhcCBvbiBhIHBob25lICh2YWx1ZSA4KS4gKi99XG4gICAgICB7cnVubmluZyAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImNhLXN0ZWVyLWhpbnRcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAge3N0ZWVyVGV4dC50cmltKClcbiAgICAgICAgICAgID8gXCJUaGUgYWdlbnQgaXMgd29ya2luZy4gVHlwZSBoZXJlIHRvIHJlZGlyZWN0IGl0LlwiXG4gICAgICAgICAgICA6IFwiVHlwZSBhIG1lc3NhZ2UgdG8gc3RlZXJcIn1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2EtcHJvbXB0LXJvd1wiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBjbGFzc05hbWU9XCJjYS1wcm9tcHRcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPXtcbiAgICAgICAgICAgIHJ1bm5pbmdcbiAgICAgICAgICAgICAgPyBcIlN0ZWVyIHRoZSBhZ2VudCDigJQgc2F5IHdoYXQgdG8gZG8gZGlmZmVyZW50bHnigKZcIlxuICAgICAgICAgICAgICA6IFwiQXNrIHRoZSBhZ2VudCB0byByZWFkLCBzZWFyY2gsIG9yIGVkaXQgeW91ciBhcHDigKZcIlxuICAgICAgICAgIH1cbiAgICAgICAgICB2YWx1ZT17cnVubmluZyA/IHN0ZWVyVGV4dCA6IHByb21wdH1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IChydW5uaW5nID8gc2V0U3RlZXJUZXh0KGUudGFyZ2V0LnZhbHVlKSA6IHNldFByb21wdChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICAgIGlmIChlLmtleSAhPT0gXCJFbnRlclwiKSByZXR1cm47XG4gICAgICAgICAgICBpZiAocnVubmluZykgc3RlZXIoXCJxdWV1ZVwiKTtcbiAgICAgICAgICAgIGVsc2Ugdm9pZCBydW4oKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGFyaWEtbGFiZWw9e3J1bm5pbmcgPyBcIlN0ZWVyIHRoZSBhZ2VudFwiIDogXCJQcm9tcHRcIn1cbiAgICAgICAgLz5cbiAgICAgICAge3J1bm5pbmcgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYS1zdGVlci1idG5cIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17IXN0ZWVyVGV4dC50cmltKCl9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0ZWVyKFwicXVldWVcIil9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFNlbmQgYWZ0ZXIgdGhpcyBzdGVwXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhLXN0ZWVyLWJ0biBjYS1zdGVlci1ub3dcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17IXN0ZWVyVGV4dC50cmltKCl9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0ZWVyKFwiaW50ZXJydXB0XCIpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBTZW5kIG5vd1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJjYS1ydW5cIlxuICAgICAgICAgIC8vIFdoaWxlIHJ1bm5pbmcsIHRoZSBidXR0b24gYmVjb21lcyBhIGxpdmUgU3RvcCBjb250cm9sIChSMy0yMjQpOiBpdCBtdXN0XG4gICAgICAgICAgLy8gc3RheSBlbmFibGVkIHNvIHRoZSB1c2VyIGNhbiBhYm9ydCB0aGUgaW4tZmxpZ2h0IHR1cm4gYW5kIHN0b3AgYmlsbGluZy5cbiAgICAgICAgICBkaXNhYmxlZD17cnVubmluZyA/IGZhbHNlIDogIXN0YWdlVHJlZX1cbiAgICAgICAgICB0aXRsZT17XG4gICAgICAgICAgICBydW5uaW5nXG4gICAgICAgICAgICAgID8gXCJFbmQgdGhlIHJ1biBhbmQgYWJvcnQgdGhlIGluLWZsaWdodCByZXF1ZXN0XCJcbiAgICAgICAgICAgICAgOiAhc3RhZ2VUcmVlXG4gICAgICAgICAgICAgICAgPyBcIldhaXRpbmcgZm9yIHRoZSBhcHAncyB3b3Jrc3BhY2UgdG8gY29ubmVjdFwiXG4gICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgICB9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gKHJ1bm5pbmcgPyBzdG9wKCkgOiB2b2lkIHJ1bigpKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtydW5uaW5nID8gXCJTdG9wXCIgOiBcIlJ1blwifVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQU1BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQVNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGFBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLGlCQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxTQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxZQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxPQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxnQkFBQSxHQUFBVCxPQUFBO0FBQ0EsSUFBQVUsVUFBQSxHQUFBVixPQUFBO0FBQ0EsSUFBQVcsU0FBQSxHQUFBWCxPQUFBO0FBQ0EsSUFBQVksU0FBQSxHQUFBWixPQUFBO0FBQ0EsSUFBQWEsT0FBQSxHQUFBYixPQUFBO0FBQ0EsSUFBQWMsZ0JBQUEsR0FBQWQsT0FBQTtBQUNBLElBQUFlLGtCQUFBLEdBQUFmLE9BQUE7QUFDQSxJQUFBZ0Isa0JBQUEsR0FBQWhCLE9BQUE7QUFNQSxJQUFBaUIsZUFBQSxHQUFBakIsT0FBQTtBQUNBLElBQUFrQixpQkFBQSxHQUFBbEIsT0FBQTtBQUVBLElBQUFtQixXQUFBLEdBQUFuQixPQUFBO0FBQ0EsSUFBQW9CLGVBQUEsR0FBQUMsc0JBQUEsQ0FBQXJCLE9BQUE7QUFDQSxJQUFBc0IsaUJBQUEsR0FBQUQsc0JBQUEsQ0FBQXJCLE9BQUE7QUFDQSxJQUFBdUIsZ0JBQUEsR0FBQXZCLE9BQUE7QUFDQSxJQUFBd0IsV0FBQSxHQUFBeEIsT0FBQTtBQUNBQSxPQUFBO0FBQTJCLElBQUF5QixXQUFBLEdBQUF6QixPQUFBO0FBQUEsSUFBQTBCLEVBQUEsR0FBQUMsWUFBQSxJQTVDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBeUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFOLHVCQUFBTyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBQ0EsTUFBTUcsZUFBZSxHQUNuQixrSEFBa0g7O0FBRXBIO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLHNCQUFzQixHQUMxQix5RUFBeUU7QUFFNUQsU0FBU0MsaUJBQWlCQSxDQUFBLEVBQUc7RUFBQVAsRUFBQTtFQUMxQyxNQUFNUSxPQUFPLEdBQUcsSUFBQUMsZUFBVSxFQUFDLENBQUM7RUFDNUIsTUFBTUMsTUFBTSxHQUFHLElBQUFDLGNBQVMsRUFBQyxDQUFDO0VBQzFCLE1BQU1DLFFBQVEsR0FBRyxJQUFBQyxhQUFNLEVBQTJCLElBQUksQ0FBQztFQUN2RCxNQUFNQyxPQUFPLEdBQUcsSUFBQUQsYUFBTSxFQUFzQixJQUFJLENBQUM7RUFDakQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUUsYUFBYSxHQUFHLElBQUFGLGFBQU0sRUFBaUMsSUFBSSxDQUFDO0VBQ2xFLE1BQU1HLFlBQVksR0FBRyxJQUFBSCxhQUFNLEVBQTZCLElBQUksQ0FBQztFQUM3RDtFQUNBO0VBQ0EsTUFBTUksUUFBUSxHQUFHLElBQUFKLGFBQU0sRUFBeUIsSUFBSSxDQUFDO0VBQ3JEO0VBQ0E7RUFDQTtFQUNBLE1BQU1LLFFBQVEsR0FBRyxJQUFBTCxhQUFNLEVBQXlCLElBQUksQ0FBQztFQUNyRCxNQUFNLENBQUNNLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUEwQixFQUFFLENBQUM7RUFDakUsTUFBTSxDQUFDQyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDOUMsTUFBTSxDQUFDRyxHQUFHLEVBQUVDLE1BQU0sQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBYSxFQUFFLENBQUM7RUFDOUMsTUFBTSxDQUFDSyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFOLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDeEMsTUFBTSxDQUFDTyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFSLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDOUM7RUFDQTtFQUNBLE1BQU0sQ0FBQ1MsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBVixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQzVDO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ1csS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBWixlQUFRLEVBSXhCLElBQUksQ0FBQztFQUNmLE1BQU0sQ0FBQ2EsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBZCxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDO0VBQ0E7RUFDQSxNQUFNZSxZQUFZLEdBQUcsSUFBQXZCLGFBQU0sRUFBZ0IsSUFBSSxDQUFDO0VBQ2hELE1BQU0sQ0FBQ3dCLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQWpCLGVBQVEsRUFBUyxFQUFFLENBQUM7RUFDOUM7RUFDQTtFQUNBLE1BQU0sQ0FBQ2tCLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQW5CLGVBQVEsRUFBcUJvQixTQUFTLENBQUM7RUFDbkU7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0MsVUFBVSxFQUFFQyxhQUFhLENBQUMsR0FBRyxJQUFBdEIsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDakU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTSxDQUFDdUIsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBeEIsZUFBUSxFQUE2QyxJQUFJLENBQUM7RUFDNUY7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUN5QixhQUFhLEVBQUVDLHFCQUFxQixDQUFDLEdBQUcsSUFBQTFCLGVBQVEsRUFBa0QsSUFBSSxDQUFDO0VBQzlHO0VBQ0E7RUFDQSxNQUFNMkIsZ0JBQWdCLEdBQUcsSUFBQW5DLGFBQU0sRUFBa0QsSUFBSSxDQUFDO0VBQ3RGLE1BQU1vQyxnQkFBZ0IsR0FBSUMsQ0FBa0QsSUFBVztJQUNyRkYsZ0JBQWdCLENBQUNHLE9BQU8sR0FBR0QsQ0FBQztJQUM1QkgscUJBQXFCLENBQUNHLENBQUMsQ0FBQztFQUMxQixDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0EsTUFBTUUsaUJBQWlCLEdBQUcsSUFBQXZDLGFBQU0sRUFBb0QsSUFBSSxDQUFDOztFQUV6RjtFQUNBO0VBQ0E7RUFDQSxNQUFNd0MsTUFBTSxHQUFHLElBQUF4QyxhQUFNLEVBQW1CLElBQUksQ0FBQztFQUM3QyxNQUFNeUMsWUFBWSxHQUFHLElBQUF6QyxhQUFNLEVBQWtCLElBQUksQ0FBQztFQUNsRDtFQUNBO0VBQ0E7RUFDQSxNQUFNMEMsY0FBYyxHQUFHLElBQUFDLGNBQU8sRUFDNUIsTUFBTSxDQUFDaEMsR0FBRyxFQUFFTSxRQUFRLEVBQUVGLFNBQVMsQ0FBQyxFQUNoQyxDQUFDSixHQUFHLEVBQUVNLFFBQVEsRUFBRUYsU0FBUyxDQUMzQixDQUFDO0VBQ0QsSUFBQTZCLGtDQUFnQixFQUFDSixNQUFNLEVBQUVFLGNBQWMsQ0FBQztFQUN4QyxJQUFBRSxrQ0FBZ0IsRUFBQ0gsWUFBWSxFQUFFeEIsUUFBUSxDQUFDOztFQUV4QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNNEIsU0FBUyxHQUFHLElBQUFGLGNBQU8sRUFBQyxNQUFNLElBQUFHLDhCQUFxQixFQUFDakQsTUFBTSxFQUFFLElBQUFrRCxvQkFBZSxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUNsRCxNQUFNLENBQUMsQ0FBQzs7RUFFM0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTW1ELE1BQU0sR0FBRyxJQUFBTCxjQUFPLEVBQUMsTUFBTSxJQUFBTSxpQkFBWSxFQUFDLENBQUMsRUFBRUMsUUFBUSxDQUFDRixNQUFNLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQztFQUUxRSxNQUFNO0lBQUVHLE9BQU87SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQVQsY0FBTyxFQUFDLE1BQU07SUFDeEM7SUFDQTtJQUNBO0lBQ0EsSUFBSSxDQUFDRSxTQUFTLEVBQUUsT0FBTyxJQUFBUSxrQkFBVSxFQUFDLElBQUFDLHVCQUFjLEVBQUMzRCxPQUFPLENBQUMsQ0FBQztJQUMxRCxNQUFNNEQsT0FBTyxHQUFHLElBQUFDLHdCQUFlLEVBQUM7TUFBRUMsSUFBSSxFQUFFWixTQUFTLENBQUNZLElBQUk7TUFBRUMsUUFBUSxFQUFFYixTQUFTLENBQUNhLFFBQVE7TUFBRVY7SUFBTyxDQUFDLENBQUM7SUFDL0YsTUFBTVcsWUFBWSxHQUFHLElBQUFDLGtDQUFvQixFQUFDO01BQUVILElBQUksRUFBRVosU0FBUyxDQUFDWSxJQUFJO01BQUVDLFFBQVEsRUFBRWIsU0FBUyxDQUFDYTtJQUFTLENBQUMsQ0FBQztJQUNqRyxNQUFNRyxnQkFBZ0IsR0FBRyxJQUFBQywwQ0FBd0IsRUFBQyxDQUFDO0lBQ25EO0lBQ0E7SUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQUMsMEJBQWdCLEVBQUM7TUFBRXJFO0lBQVEsQ0FBQyxDQUFDO0lBQzlDO0lBQ0E7SUFDQSxPQUFPLElBQUEwRCxrQkFBVSxFQUFDLElBQUFZLHNCQUFhLEVBQUMsSUFBQVgsdUJBQWMsRUFBQzNELE9BQU8sQ0FBQyxFQUFFNEQsT0FBTyxFQUFFSSxZQUFZLEVBQUVFLGdCQUFnQixFQUFFRSxRQUFRLENBQUMsQ0FBQztFQUM5RyxDQUFDLEVBQUUsQ0FBQ3BFLE9BQU8sRUFBRWtELFNBQVMsRUFBRUcsTUFBTSxDQUFDLENBQUM7RUFFaEMsTUFBTWtCLE1BQU0sR0FBSTdFLENBQVcsSUFBS3VCLE1BQU0sQ0FBRXVELENBQUMsSUFBSyxDQUFDLEdBQUdBLENBQUMsRUFBRTlFLENBQUMsQ0FBQyxDQUFDOztFQUV4RDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBK0UsZ0NBQWUsRUFBQ3JFLFFBQVEsRUFBRXdCLFlBQVksRUFBRUYsT0FBTyxDQUFDOztFQUVoRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1nRCxnQkFBZ0IsR0FBRyxJQUFBQyxrQkFBVyxFQUFDLE1BQU07SUFDekMsTUFBTUMsS0FBSyxHQUFHeEUsUUFBUSxDQUFDdUMsT0FBTztJQUM5QixNQUFNa0MsRUFBRSxHQUFHakQsWUFBWSxDQUFDZSxPQUFPO0lBQy9CLElBQUlpQyxLQUFLLElBQUlDLEVBQUUsRUFBRSxLQUFLRCxLQUFLLENBQUNFLFVBQVUsQ0FBQ0QsRUFBRSxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQzVELENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNQyxnQkFBZ0IsR0FBRyxJQUFBTCxrQkFBVyxFQUFFTSxJQUFrQixJQUFLO0lBQzNEM0UsT0FBTyxDQUFDcUMsT0FBTyxHQUFHc0MsSUFBSTtJQUN0QmpELFNBQVMsQ0FBQ2lELElBQUksQ0FBQ0osRUFBRSxDQUFDO0lBQ2xCL0MsUUFBUSxDQUFDbUQsSUFBSSxDQUFDcEQsS0FBSyxDQUFDO0lBQ3BCWixNQUFNLENBQUMsSUFBQWlFLHlCQUFhLEVBQUNELElBQUksQ0FBQ0UsUUFBUSxDQUFDLENBQUM7SUFDcEM5RCxZQUFZLENBQUMsRUFBRSxDQUFDO0lBQ2hCYixZQUFZLENBQUNtQyxPQUFPLEVBQUV5QyxNQUFNLENBQUMsQ0FBQztJQUM5QjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EzQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7SUFDdEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBSixZQUFZLENBQUMsSUFBSSxDQUFDO0lBQ2xCLE1BQU11QyxLQUFLLEdBQUd4RSxRQUFRLENBQUN1QyxPQUFPO0lBQzlCLElBQUlpQyxLQUFLLEVBQUVTLFVBQVUsQ0FBQyxDQUFDLEVBQUU7TUFDdkIsTUFBTUMsT0FBTyxHQUFHVixLQUFLLENBQ2xCVyxNQUFNLENBQUNOLElBQUksQ0FBQ0osRUFBRSxDQUFDLENBQ2ZXLElBQUksQ0FBRUMsQ0FBQyxJQUFLO1FBQ1gsSUFBSW5GLE9BQU8sQ0FBQ3FDLE9BQU8sRUFBRWtDLEVBQUUsS0FBS0ksSUFBSSxDQUFDSixFQUFFLElBQUlqRCxZQUFZLENBQUNlLE9BQU8sS0FBSyxJQUFJLEVBQUU7UUFDdEUsSUFBSSxDQUFDLElBQUErQyxtQkFBVyxFQUFDRCxDQUFDLENBQUMsRUFBRTtRQUNyQnhFLE1BQU0sQ0FBQyxJQUFBaUUseUJBQWEsRUFBQ08sQ0FBQyxDQUFDTixRQUFRLENBQUMsQ0FBQztRQUNqQzFDLGdCQUFnQixDQUFDO1VBQUVWLE1BQU0sRUFBRWtELElBQUksQ0FBQ0osRUFBRTtVQUFFVSxNQUFNLEVBQUVFO1FBQUUsQ0FBQyxDQUFDO01BQ2xELENBQUMsQ0FBQyxDQUNEVixLQUFLLENBQUVyRixDQUFDLElBQUs7UUFDWjtRQUNBO1FBQ0E7UUFDQSxJQUFJWSxPQUFPLENBQUNxQyxPQUFPLEVBQUVrQyxFQUFFLEtBQUtJLElBQUksQ0FBQ0osRUFBRSxFQUFFO1FBQ3JDLElBQUksSUFBQWMsbUNBQWdCLEVBQUNqRyxDQUFDLENBQUMsRUFBRTtVQUN2QjZFLE1BQU0sQ0FBQztZQUNMcUIsSUFBSSxFQUFFLE9BQU87WUFDYkMsSUFBSSxFQUFFO1VBQ1IsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxNQUFNO1VBQ0wxRCxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO1FBQzdDO01BQ0YsQ0FBQyxDQUFDLENBQ0RrRyxPQUFPLENBQUMsTUFBTTtRQUNiO1FBQ0E7UUFDQTtRQUNBLElBQUluRCxpQkFBaUIsQ0FBQ0QsT0FBTyxFQUFFMkMsT0FBTyxLQUFLQSxPQUFPLEVBQUUxQyxpQkFBaUIsQ0FBQ0QsT0FBTyxHQUFHLElBQUk7TUFDdEYsQ0FBQyxDQUFDO01BQ0pDLGlCQUFpQixDQUFDRCxPQUFPLEdBQUc7UUFBRVosTUFBTSxFQUFFa0QsSUFBSSxDQUFDSixFQUFFO1FBQUVTO01BQVEsQ0FBQztJQUMxRDtFQUNGLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1VLGlCQUFpQixHQUFHLElBQUEzRixhQUFNLEVBQXdCLElBQUksQ0FBQztFQUM3RCxJQUFBNEYsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RELGlCQUFpQixDQUFDckQsT0FBTyxHQUFHLElBQUF1RCxvQ0FBb0IsRUFBQztNQUMvQ0MsSUFBSSxFQUFFbkIsZ0JBQWdCO01BQ3RCb0IsU0FBUyxFQUFHdkIsRUFBRSxJQUFLakQsWUFBWSxDQUFDZSxPQUFPLEtBQUtrQztJQUM5QyxDQUFDLENBQUM7SUFDRixPQUFPLE1BQU07TUFDWG1CLGlCQUFpQixDQUFDckQsT0FBTyxHQUFHLElBQUk7SUFDbEMsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDcUMsZ0JBQWdCLENBQUMsQ0FBQzs7RUFFdEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTXFCLFNBQVMsR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDaEMsTUFBTUMsYUFBYSxHQUFHRixTQUFTLEVBQUVHLEtBQUs7RUFDdEM7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxpQkFBaUIsR0FBR0osU0FBUyxFQUFFSyxRQUFROztFQUU3QztFQUNBO0VBQ0E7RUFDQSxNQUFNQyxZQUFZLEdBQUcsSUFBQXRHLGFBQU0sRUFBQ2tHLGFBQWEsQ0FBQztFQUMxQyxJQUFBTixnQkFBUyxFQUFDLE1BQU07SUFDZFUsWUFBWSxDQUFDaEUsT0FBTyxHQUFHNEQsYUFBYTtFQUN0QyxDQUFDLEVBQUUsQ0FBQ0EsYUFBYSxDQUFDLENBQUM7O0VBRW5CO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBTixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJVyxJQUFJLEdBQUcsSUFBSTtJQUNmLEtBQUssQ0FBQyxZQUFZO01BQ2hCLElBQUk7UUFDRixNQUFNaEMsS0FBSyxHQUFHLE1BQU0sSUFBQWlDLHdDQUFxQixFQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDRCxJQUFJLEVBQUU7UUFDWHhHLFFBQVEsQ0FBQ3VDLE9BQU8sR0FBR2lDLEtBQUs7UUFDeEJ6QyxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ25CLE1BQU02RCxpQkFBaUIsQ0FBQ3JELE9BQU8sQ0FBRW1FLFdBQVcsQ0FBQ2xDLEtBQUssRUFBRStCLFlBQVksQ0FBQ2hFLE9BQU8sQ0FBQztNQUMzRSxDQUFDLENBQUMsT0FBT2pELENBQUMsRUFBRTtRQUNWO1FBQ0E7UUFDQSxJQUFJa0gsSUFBSSxFQUFFekUsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztNQUN2RDtJQUNGLENBQUMsRUFBRSxDQUFDO0lBQ0o7SUFDQTtJQUNBO0lBQ0E7SUFDQVUsYUFBYSxDQUFDb0MsT0FBTyxHQUFHLElBQUk7SUFDNUJuQyxZQUFZLENBQUNtQyxPQUFPLEdBQUcsSUFBQW9FLDRDQUF5QixFQUM5QyxNQUFNeEcsYUFBYSxDQUFDb0MsT0FBTyxFQUMzQixPQUFPO01BQUVzQyxJQUFJLEVBQUUzRSxPQUFPLENBQUNxQyxPQUFPO01BQUVxRSxTQUFTLEVBQUVwRixZQUFZLENBQUNlO0lBQVEsQ0FBQyxDQUNuRSxDQUFDO0lBQ0QsS0FBSyxJQUFBc0UsOENBQTJCLEVBQUMsQ0FBQyxDQUMvQnpCLElBQUksQ0FBRTBCLENBQUMsSUFBSztNQUNYLElBQUlOLElBQUksRUFBRTtRQUNSckcsYUFBYSxDQUFDb0MsT0FBTyxHQUFHdUUsQ0FBQztRQUN6QjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTFHLFlBQVksQ0FBQ21DLE9BQU8sRUFBRXlDLE1BQU0sQ0FBQyxDQUFDO01BQ2hDO0lBQ0YsQ0FBQyxDQUFDLENBQ0RMLEtBQUssQ0FBRXJGLENBQUMsSUFBSztNQUNaO01BQ0E7TUFDQXlILE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLG9FQUFvRSxFQUFFMUgsQ0FBQyxDQUFDO0lBQ3ZGLENBQUMsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYa0gsSUFBSSxHQUFHLEtBQUs7TUFDWjtNQUNBO01BQ0FwRyxZQUFZLENBQUNtQyxPQUFPLEVBQUUwRSxTQUFTLENBQUMsQ0FBQztNQUNqQzdHLFlBQVksQ0FBQ21DLE9BQU8sR0FBRyxJQUFJO01BQzNCcEMsYUFBYSxDQUFDb0MsT0FBTyxHQUFHLElBQUk7SUFDOUIsQ0FBQztFQUNILENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQSxJQUFBc0QsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsT0FBTyxJQUFBcUIsb0JBQWUsRUFBRUMsQ0FBQyxJQUFLO01BQzVCLElBQUksSUFBQUMseUJBQVEsRUFBQ0QsQ0FBQyxDQUFDRSxJQUFJLENBQUMsRUFBRSxLQUFLekIsaUJBQWlCLENBQUNyRCxPQUFPLENBQUUrRSxNQUFNLENBQUNILENBQUMsQ0FBQ0UsSUFBSSxDQUFDNUMsRUFBRSxDQUFDO0lBQ3pFLENBQUMsQ0FBQztFQUNKLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQW9CLGdCQUFTLEVBQUMsTUFBTTtJQUNkLEtBQUssSUFBQTBCLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQW9CLENBQUMsQ0FBQyxDQUFDOUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDaEYsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU0rQyxHQUFHLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQ3RCLElBQUksQ0FBQzVHLE1BQU0sQ0FBQzZHLElBQUksQ0FBQyxDQUFDLElBQUlyRyxPQUFPLEVBQUU7SUFDL0I7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1zRyxXQUFXLEdBQUcxSCxPQUFPLENBQUNxQyxPQUFPO0lBQ25DLE1BQU1zRixRQUFRLEdBQUdyRixpQkFBaUIsQ0FBQ0QsT0FBTztJQUMxQyxJQUFJcUYsV0FBVyxJQUFJQyxRQUFRLElBQUlBLFFBQVEsQ0FBQ2xHLE1BQU0sS0FBS2lHLFdBQVcsQ0FBQ25ELEVBQUUsRUFBRTtNQUNqRSxNQUFNb0QsUUFBUSxDQUFDM0MsT0FBTztJQUN4QjtJQUNBLE1BQU00QyxPQUFPLEdBQUcxRixnQkFBZ0IsQ0FBQ0csT0FBTztJQUN4QyxJQUFJdUYsT0FBTyxJQUFJNUgsT0FBTyxDQUFDcUMsT0FBTyxJQUFJdUYsT0FBTyxDQUFDbkcsTUFBTSxLQUFLekIsT0FBTyxDQUFDcUMsT0FBTyxDQUFDa0MsRUFBRSxFQUFFO01BQ3ZFTixNQUFNLENBQUM7UUFDTHFCLElBQUksRUFBRSxPQUFPO1FBQ2JDLElBQUksRUFBRTtNQUNSLENBQUMsQ0FBQztNQUNGO0lBQ0Y7SUFDQXBELGdCQUFnQixDQUFDLElBQUksQ0FBQztJQUN0QjtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUNTLFNBQVMsRUFBRTtNQUNkcUIsTUFBTSxDQUFDO1FBQUVxQixJQUFJLEVBQUUsTUFBTTtRQUFFQyxJQUFJLEVBQUUzRTtNQUFPLENBQUMsQ0FBQztNQUN0Q3FELE1BQU0sQ0FBQztRQUNMcUIsSUFBSSxFQUFFLE9BQU87UUFDYkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO01BQ0YxRSxTQUFTLENBQUMsRUFBRSxDQUFDO01BQ2I7SUFDRjtJQUNBLE1BQU15RCxLQUFLLEdBQUd4RSxRQUFRLENBQUN1QyxPQUFPO0lBQzlCO0lBQ0E7SUFDQSxJQUFJc0MsSUFBSSxHQUFHM0UsT0FBTyxDQUFDcUMsT0FBTztJQUMxQixJQUFJLENBQUNzQyxJQUFJLElBQUlMLEtBQUssRUFBRTtNQUNsQixJQUFJO1FBQ0ZLLElBQUksR0FBRyxNQUFNTCxLQUFLLENBQUN1RCxNQUFNLENBQUNsRyxTQUFTLEVBQUVzRSxhQUFhLEVBQUVFLGlCQUFpQixDQUFDO1FBQ3RFbkcsT0FBTyxDQUFDcUMsT0FBTyxHQUFHc0MsSUFBSTtRQUN0QmUsaUJBQWlCLENBQUNyRCxPQUFPLENBQUV5RixLQUFLLENBQUNuRCxJQUFJLENBQUM7UUFDdENuRCxRQUFRLENBQUNtRCxJQUFJLENBQUNwRCxLQUFLLENBQUM7UUFDcEJNLGFBQWEsQ0FBQyxJQUFJLENBQUM7TUFDckIsQ0FBQyxDQUFDLE9BQU96QyxDQUFDLEVBQUU7UUFDVjtRQUNBO1FBQ0E7UUFDQXlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUcsZUFBZSxDQUFDLENBQUM7TUFDN0M7SUFDRjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJK0UsS0FBSyxJQUFJSyxJQUFJLEVBQUU7TUFDakIsSUFBSTtRQUNGLElBQUksQ0FBQyxNQUFNTCxLQUFLLENBQUN5RCxVQUFVLENBQUNwRCxJQUFJLENBQUNKLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtVQUNoRHhDLFlBQVksQ0FBQztZQUFFTixNQUFNLEVBQUVrRCxJQUFJLENBQUNKLEVBQUU7WUFBRXlELE1BQU0sRUFBRTtVQUFNLENBQUMsQ0FBQztVQUNoRDtRQUNGO01BQ0YsQ0FBQyxDQUFDLE9BQU81SSxDQUFDLEVBQUU7UUFDVjtRQUNBO1FBQ0E7UUFDQTtRQUNBeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztNQUM3QztJQUNGO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTTBJLE9BQU8sR0FBR3RELElBQUksSUFBSUwsS0FBSyxFQUFFUyxVQUFVLENBQUMsQ0FBQyxHQUFHSixJQUFJLEdBQUcsSUFBSTtJQUN6RCxJQUFJTCxLQUFLLElBQUlLLElBQUksSUFBSSxDQUFDTCxLQUFLLENBQUNTLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQ25ELFVBQVUsRUFBRTtNQUN2REMsYUFBYSxDQUNYLDBKQUNGLENBQUM7SUFDSDtJQUNBLE1BQU1xRyxPQUFPLEdBQUd2RCxJQUFJLEVBQUVFLFFBQVEsSUFBSSxFQUFFO0lBQ3BDLE1BQU1zRCxPQUFPLEdBQUd2SCxNQUFNO0lBQ3RCQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQ2JRLFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDaEJDLFlBQVksQ0FBQ2UsT0FBTyxHQUFHc0MsSUFBSSxFQUFFSixFQUFFLElBQUksSUFBSTtJQUN2Q3JFLFlBQVksQ0FBQ21DLE9BQU8sRUFBRStGLFVBQVUsQ0FBQ3pELElBQUksRUFBRUosRUFBRSxJQUFJLElBQUksQ0FBQztJQUNsRHhELFlBQVksQ0FBQyxFQUFFLENBQUM7SUFDaEJFLFdBQVcsQ0FBQyxFQUFFLENBQUM7SUFDZkUsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNkOEMsTUFBTSxDQUFDO01BQUVxQixJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU0QztJQUFRLENBQUMsQ0FBQztJQUN2QyxNQUFNRSxVQUFVLEdBQUcsSUFBSUMsZUFBZSxDQUFDLENBQUM7SUFDeENuSSxRQUFRLENBQUNrQyxPQUFPLEdBQUdnRyxVQUFVO0lBQzdCLE1BQU1FLFFBQVEsR0FBRyxJQUFJQyx5QkFBZSxDQUFDLENBQUM7SUFDdENwSSxRQUFRLENBQUNpQyxPQUFPLEdBQUdrRyxRQUFRO0lBQzNCO0lBQ0E7SUFDQTtJQUNBLE1BQU07TUFBRUUsS0FBSztNQUFFQyxPQUFPLEVBQUVDO0lBQWEsQ0FBQyxHQUFHLElBQUFDLHdCQUFjLEVBQUMsQ0FBQztJQUN6RHRJLFNBQVMsQ0FBQyxFQUFFLENBQUM7SUFDYixNQUFNdUksY0FBYyxHQUFHTixRQUFRLENBQUNPLFFBQVEsQ0FBRWxCLE9BQU8sSUFBS3RILFNBQVMsQ0FBQyxDQUFDLEdBQUdzSCxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzlFO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNbUIsWUFBWSxHQUFHLElBQUFDLDhCQUFpQixFQUFDO01BQUVDLEtBQUssRUFBRSxJQUFBQyxxQkFBUSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzdELElBQUk7TUFDRixNQUFNQyxVQUFVLEdBQUcsTUFBTSxJQUFBQyxtQkFBUSxFQUFDO1FBQ2hDQyxNQUFNLEVBQUUsSUFBQUMsc0NBQXFCLEVBQUMsQ0FBQztRQUMvQkMsS0FBSyxFQUFFckcsT0FBTyxDQUFDcUcsS0FBSztRQUNwQkMsT0FBTyxFQUFFdEcsT0FBTyxDQUFDc0csT0FBTztRQUN4QkMsTUFBTSxFQUFFLElBQUFDLGdDQUFtQixFQUFDWCxZQUFZLEVBQUUsSUFBQVksNEJBQWUsRUFBQztVQUFFSixLQUFLLEVBQUVyRyxPQUFPLENBQUNxRyxLQUFLO1VBQUVLLGFBQWEsRUFBRWhILFNBQVMsRUFBRVksSUFBSTtVQUFFTDtRQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzVINEMsU0FBUyxFQUFFRSxhQUFhLElBQUl0RSxTQUFTO1FBQ3JDa0ksWUFBWSxFQUFFZCxZQUFZO1FBQzFCYixPQUFPO1FBQ1B0SCxNQUFNLEVBQUV1SCxPQUFPO1FBQ2Y7UUFDQTJCLE1BQU0sRUFBRXpCLFVBQVUsQ0FBQ3lCLE1BQU07UUFDekI7UUFDQXZCLFFBQVE7UUFDUjtRQUNBRSxLQUFLO1FBQ0w7UUFDQXNCLGFBQWEsRUFBRSxJQUFBL0csaUJBQVksRUFBQyxDQUFDLEVBQUVDLFFBQVEsQ0FBQytHLGdCQUFnQjtRQUN4REMsTUFBTSxFQUFFO1VBQ047VUFDQTtVQUNBO1VBQ0EsSUFBSWhDLE9BQU8sR0FDUDtZQUNFaUMsVUFBVSxFQUFFLE1BQU9DLENBQUMsSUFBSztjQUN2QixNQUFNN0YsS0FBSyxDQUFFTCxNQUFNLENBQUNnRSxPQUFPLENBQUMxRCxFQUFFLEVBQUU0RixDQUFDLENBQUM7WUFDcEM7VUFDRixDQUFDLEdBQ0QsQ0FBQyxDQUFDLENBQUM7VUFDUEMsZ0JBQWdCLEVBQUc3RSxJQUFJLElBQUt4RSxZQUFZLENBQUVzSixDQUFDLElBQUtBLENBQUMsR0FBRzlFLElBQUksQ0FBQztVQUN6RDtVQUNBO1VBQ0E7VUFDQStFLGdCQUFnQixFQUFHL0UsSUFBSSxJQUFLdEUsV0FBVyxDQUFFc0osQ0FBQyxJQUFLQSxDQUFDLEdBQUdoRixJQUFJLENBQUM7VUFDeERpRixXQUFXLEVBQUdDLEtBQUssSUFBSztZQUN0QnhKLFdBQVcsQ0FBQyxFQUFFLENBQUM7WUFDZmdELE1BQU0sQ0FDSndHLEtBQUssQ0FBQ0MsWUFBWSxLQUFLL0ksU0FBUyxHQUM1QjtjQUFFMkQsSUFBSSxFQUFFLFdBQVc7Y0FBRUMsSUFBSSxFQUFFLEVBQUU7Y0FBRW9GLFFBQVEsRUFBRTtZQUFLLENBQUMsR0FDL0M7Y0FBRXJGLElBQUksRUFBRSxXQUFXO2NBQUVDLElBQUksRUFBRWtGLEtBQUssQ0FBQ2xGO1lBQUssQ0FDNUMsQ0FBQztVQUNILENBQUM7VUFDRHFGLGVBQWUsRUFBR3JGLElBQUksSUFBSztZQUN6QjtZQUNBO1lBQ0EsSUFBSUEsSUFBSSxLQUFLc0YsK0JBQXFCLEVBQUU1RyxNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRTtZQUFjLENBQUMsQ0FBQyxDQUFDLEtBQy9ELElBQUlDLElBQUksQ0FBQ2tDLElBQUksQ0FBQyxDQUFDLEVBQUV4RCxNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRSxNQUFNO2NBQUVDO1lBQUssQ0FBQyxDQUFDO1lBQ3BEeEUsWUFBWSxDQUFDLEVBQUUsQ0FBQztVQUNsQixDQUFDO1VBQ0QrSixTQUFTLEVBQUVBLENBQUNDLElBQUksRUFBRUMsS0FBSyxLQUFLL0csTUFBTSxDQUFDO1lBQUVxQixJQUFJLEVBQUUsTUFBTTtZQUFFeUYsSUFBSTtZQUFFQztVQUFNLENBQUMsQ0FBQztVQUNqRUMsWUFBWSxFQUFFQSxDQUFDRixJQUFJLEVBQUU1RixDQUFDLEtBQUtsQixNQUFNLENBQUM7WUFBRXFCLElBQUksRUFBRSxRQUFRO1lBQUV5RixJQUFJO1lBQUVHLE9BQU8sRUFBRS9GLENBQUMsQ0FBQytGLE9BQU87WUFBRUMsT0FBTyxFQUFFaEcsQ0FBQyxDQUFDZ0c7VUFBUSxDQUFDLENBQUM7VUFDbkdDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkgsTUFBTSxDQUFDO1lBQUVxQixJQUFJLEVBQUU7VUFBUSxDQUFDLENBQUM7VUFDeEMrRixPQUFPLEVBQUdDLENBQUMsSUFDVG5LLFFBQVEsQ0FBQztZQUNQb0ssV0FBVyxFQUFFRCxDQUFDLENBQUNDLFdBQVc7WUFDMUJDLGVBQWUsRUFBRUYsQ0FBQyxDQUFDRSxlQUFlO1lBQ2xDQyxnQkFBZ0IsRUFBRUgsQ0FBQyxDQUFDRztVQUN0QixDQUFDLENBQUM7VUFDSkMsU0FBUyxFQUFFQSxDQUFDO1lBQUVDLGVBQWU7WUFBRUg7VUFBZ0IsQ0FBQyxLQUFLO1lBQ25EdkgsTUFBTSxDQUFDO2NBQ0xxQixJQUFJLEVBQUUsWUFBWTtjQUNsQjtjQUNBO2NBQ0E7Y0FDQTtjQUNBc0csT0FBTyxFQUNMLEdBQUdELGVBQWUsOEJBQThCLElBQy9DSCxlQUFlLEtBQUs3SixTQUFTLEdBQUcsTUFBTTZKLGVBQWUsNEJBQTRCLEdBQUcsRUFBRTtZQUMzRixDQUFDLENBQUM7WUFDRjtZQUNBO1lBQ0E7WUFDQTtZQUNBLElBQUl2RCxPQUFPLEVBQUU7Y0FDWCxLQUFLM0QsS0FBSyxDQUFFdUgsSUFBSSxDQUFDNUQsT0FBTyxDQUFDMUQsRUFBRSxDQUFDLENBQUNFLEtBQUssQ0FBRXJGLENBQUMsSUFBSztnQkFDeEN5SCxPQUFPLENBQUNDLElBQUksQ0FBQyw2REFBNkQsRUFBRTFILENBQUMsQ0FBQztjQUNoRixDQUFDLENBQUM7WUFDSjtVQUNGLENBQUM7VUFDRDBNLE9BQU8sRUFBRUEsQ0FBQztZQUFFakg7VUFBUyxDQUFDLEtBQUs7WUFDekIsS0FBSyxNQUFNb0MsQ0FBQyxJQUFJcEMsUUFBUSxFQUFFWixNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRSxPQUFPO2NBQUV5RyxJQUFJLEVBQUU5RSxDQUFDLENBQUM4RSxJQUFJO2NBQUV4RyxJQUFJLEVBQUUwQixDQUFDLENBQUMxQjtZQUFLLENBQUMsQ0FBQztVQUNqRjtRQUNGO01BQ0YsQ0FBQyxDQUFDO01BQ0YsSUFBSVosSUFBSSxJQUFJTCxLQUFLLEVBQUU7UUFDakIsTUFBTTBILFFBQVEsR0FBR3JILElBQUksQ0FBQ3BELEtBQUssS0FBSyxrQkFBa0IsR0FBRyxJQUFBMEssOEJBQVcsRUFBQzlDLFVBQVUsQ0FBQyxHQUFHeEUsSUFBSSxDQUFDcEQsS0FBSztRQUN6RixJQUFJO1VBQ0Y7VUFDQTtVQUNBO1VBQ0E7VUFDQXZCLE9BQU8sQ0FBQ3FDLE9BQU8sR0FBRyxNQUFNaUMsS0FBSyxDQUFDdUgsSUFBSSxDQUFDbEgsSUFBSSxDQUFDSixFQUFFLEVBQUU7WUFDMUNNLFFBQVEsRUFBRXNFLFVBQVU7WUFDcEI1SCxLQUFLLEVBQUV5SyxRQUFRO1lBQ2ZFLElBQUksRUFBRXZILElBQUksQ0FBQ3VILElBQUksSUFBSWpHLGFBQWE7WUFDaEMsSUFBSXRCLElBQUksQ0FBQ3VILElBQUksS0FBS3ZLLFNBQVMsR0FBRztjQUFFd0ssWUFBWSxFQUFFaEc7WUFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztVQUN4RSxDQUFDLENBQUM7VUFDRjNFLFFBQVEsQ0FBQ3dLLFFBQVEsQ0FBQztVQUNsQm5LLGFBQWEsQ0FBQyxJQUFJLENBQUM7VUFDbkI7VUFDQTNCLFlBQVksQ0FBQ21DLE9BQU8sRUFBRStKLE9BQU8sQ0FBQyxDQUFDO1VBQy9CLEtBQUssSUFBQS9FLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUU7WUFBRUMsSUFBSSxFQUFFLHNCQUFzQjtZQUFFaEQsRUFBRSxFQUFFSSxJQUFJLENBQUNKO1VBQUcsQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ2hHLENBQUMsQ0FBQyxPQUFPckYsQ0FBQyxFQUFFO1VBQ1Y7VUFDQTtVQUNBO1VBQ0F5QyxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO1FBQzdDO01BQ0Y7SUFDRixDQUFDLENBQUMsT0FBT0gsQ0FBQyxFQUFFO01BQ1Y7TUFDQTtNQUNBO01BQ0EsTUFBTWlOLEtBQUssR0FBRyxJQUFBQyx3QkFBWSxFQUFDbE4sQ0FBQyxDQUFDO01BQzdCLElBQUlpTixLQUFLLEVBQUU7UUFDVHBJLE1BQU0sQ0FBQztVQUFFcUIsSUFBSSxFQUFFLE9BQU87VUFBRUMsSUFBSSxFQUFFLElBQUFnSCw0QkFBZ0IsRUFBQ0YsS0FBSyxFQUFFLElBQUk7UUFBRSxDQUFDLENBQUM7UUFDOUQsSUFBSUEsS0FBSyxLQUFLLFlBQVksRUFBRTtVQUMxQnRLLFlBQVksQ0FBQztZQUFFTixNQUFNLEVBQUVILFlBQVksQ0FBQ2UsT0FBTyxJQUFJckMsT0FBTyxDQUFDcUMsT0FBTyxFQUFFa0MsRUFBRSxJQUFJLEVBQUU7WUFBRXlELE1BQU0sRUFBRTtVQUFNLENBQUMsQ0FBQztRQUM1RjtNQUNGLENBQUMsTUFBTTtRQUNML0QsTUFBTSxDQUFDO1VBQUVxQixJQUFJLEVBQUUsT0FBTztVQUFFQyxJQUFJLEVBQUduRyxDQUFDLEVBQVlvTixPQUFPLElBQUlDLE1BQU0sQ0FBQ3JOLENBQUM7UUFBRSxDQUFDLENBQUM7TUFDckU7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJLElBQUFpRyxtQ0FBZ0IsRUFBQ2pHLENBQUMsQ0FBQyxFQUFFO1FBQ3ZCeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFSSxzQkFBc0IsQ0FBQyxDQUFDO01BQ3BEO0lBQ0YsQ0FBQyxTQUFTO01BQ1JxSixjQUFjLENBQUMsQ0FBQztNQUNoQnpJLFFBQVEsQ0FBQ2lDLE9BQU8sR0FBRyxJQUFJO01BQ3ZCc0csWUFBWSxDQUFDLENBQUM7TUFDZHJJLFNBQVMsQ0FBQyxFQUFFLENBQUM7TUFDYkcsWUFBWSxDQUFDLEVBQUUsQ0FBQztNQUNoQk0sWUFBWSxDQUFDLEVBQUUsQ0FBQztNQUNoQkUsV0FBVyxDQUFDLEVBQUUsQ0FBQztNQUNmSSxVQUFVLENBQUMsS0FBSyxDQUFDO01BQ2pCK0MsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDcEI5QyxZQUFZLENBQUNlLE9BQU8sR0FBRyxJQUFJO01BQzNCbEMsUUFBUSxDQUFDa0MsT0FBTyxHQUFHLElBQUk7TUFDdkJuQyxZQUFZLENBQUNtQyxPQUFPLEVBQUVxSyxRQUFRLENBQUMsQ0FBQztJQUNsQztFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBLE1BQU1DLElBQUksR0FBRyxJQUFBdEksa0JBQVcsRUFBQyxNQUFNO0lBQzdCbEUsUUFBUSxDQUFDa0MsT0FBTyxFQUFFdUssS0FBSyxDQUFDLENBQUM7RUFDM0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0VBRUE7QUFDRjtFQUNFLE1BQU1DLFNBQVMsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDNUIsTUFBTXZJLEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87SUFDOUIsTUFBTXVGLE9BQU8sR0FBRzVGLGFBQWE7SUFDN0IsTUFBTTJDLElBQUksR0FBRzNFLE9BQU8sQ0FBQ3FDLE9BQU87SUFDNUIsSUFBSSxDQUFDaUMsS0FBSyxJQUFJLENBQUNzRCxPQUFPLElBQUksQ0FBQ2pELElBQUksSUFBSXZELE9BQU8sSUFBSXdHLE9BQU8sQ0FBQ25HLE1BQU0sS0FBS2tELElBQUksQ0FBQ0osRUFBRSxFQUFFO0lBQzFFO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQzNCLFNBQVMsRUFBRTtNQUNkcUIsTUFBTSxDQUFDO1FBQ0xxQixJQUFJLEVBQUUsT0FBTztRQUNiQyxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUM7TUFDRjtJQUNGO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUk7TUFDRixJQUFJLENBQUMsTUFBTWpCLEtBQUssQ0FBQ3lELFVBQVUsQ0FBQ3BELElBQUksQ0FBQ0osRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO1FBQ2hEeEMsWUFBWSxDQUFDO1VBQUVOLE1BQU0sRUFBRWtELElBQUksQ0FBQ0osRUFBRTtVQUFFeUQsTUFBTSxFQUFFO1FBQUssQ0FBQyxDQUFDO1FBQy9DO01BQ0Y7SUFDRixDQUFDLENBQUMsT0FBTzVJLENBQUMsRUFBRTtNQUNWeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFRyxlQUFlLENBQUMsQ0FBQztJQUM3QztJQUNBNEMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0lBQ3RCLE1BQU04QyxNQUFNLEdBQUcyQyxPQUFPLENBQUMzQyxNQUFNO0lBQzdCLE1BQU02SCxRQUFRLEdBQUcsSUFBQUMsd0JBQWdCLEVBQUM7TUFDaENsSSxRQUFRLEVBQUVJLE1BQU0sQ0FBQ0osUUFBUTtNQUN6Qm1JLGNBQWMsRUFBRS9ILE1BQU0sQ0FBQytILGNBQWM7TUFDckNDLGVBQWUsRUFBRWhJLE1BQU0sQ0FBQ2dJO0lBQzFCLENBQUMsQ0FBQztJQUNGO0lBQ0E7SUFDQTtJQUNBLE1BQU1DLFVBQVUsR0FBRyxJQUFBQyx5QkFBaUIsRUFBQ2xJLE1BQU0sQ0FBQ21JLGdCQUFnQixFQUFFbkgsYUFBYSxDQUFDO0lBQzVFLE1BQU1vSCxPQUFPLEdBQUcsSUFBQUMsdUJBQWUsRUFBQ1IsUUFBUSxDQUFDakksUUFBUSxFQUFFcUksVUFBVSxDQUFDO0lBQzlEdk0sTUFBTSxDQUFDLElBQUFpRSx5QkFBYSxFQUFDa0ksUUFBUSxDQUFDakksUUFBUSxDQUFDLENBQUM7SUFDeEN4RCxVQUFVLENBQUMsSUFBSSxDQUFDO0lBQ2hCQyxZQUFZLENBQUNlLE9BQU8sR0FBR3NDLElBQUksQ0FBQ0osRUFBRTtJQUM5QnJFLFlBQVksQ0FBQ21DLE9BQU8sRUFBRStGLFVBQVUsQ0FBQ3pELElBQUksQ0FBQ0osRUFBRSxDQUFDO0lBQ3pDeEQsWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUNoQkUsV0FBVyxDQUFDLEVBQUUsQ0FBQztJQUNmZ0QsTUFBTSxDQUFDO01BQUVxQixJQUFJLEVBQUUsT0FBTztNQUFFeUcsSUFBSSxFQUFFLE9BQU87TUFBRXhHLElBQUksRUFBRTtJQUF1QyxDQUFDLENBQUM7SUFDdEYsTUFBTThDLFVBQVUsR0FBRyxJQUFJQyxlQUFlLENBQUMsQ0FBQztJQUN4Q25JLFFBQVEsQ0FBQ2tDLE9BQU8sR0FBR2dHLFVBQVU7SUFDN0IsTUFBTWtGLFNBQVMsR0FBRyxJQUFJL0UseUJBQWUsQ0FBQyxDQUFDO0lBQ3ZDcEksUUFBUSxDQUFDaUMsT0FBTyxHQUFHa0wsU0FBUztJQUM1QjtJQUNBO0lBQ0EsTUFBTTtNQUFFOUUsS0FBSztNQUFFQyxPQUFPLEVBQUVDO0lBQWEsQ0FBQyxHQUFHLElBQUFDLHdCQUFjLEVBQUMsQ0FBQztJQUN6RHRJLFNBQVMsQ0FBQyxFQUFFLENBQUM7SUFDYixNQUFNdUksY0FBYyxHQUFHMEUsU0FBUyxDQUFDekUsUUFBUSxDQUFFMEUsQ0FBQyxJQUFLbE4sU0FBUyxDQUFDLENBQUMsR0FBR2tOLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkU7SUFDQTtJQUNBO0lBQ0EsTUFBTXpFLFlBQVksR0FBRzlELE1BQU0sQ0FBQzRFLFlBQVksSUFBSSxJQUFBYiw4QkFBaUIsRUFBQztNQUFFQyxLQUFLLEVBQUUsSUFBQUMscUJBQVEsRUFBQztJQUFFLENBQUMsQ0FBQztJQUNwRixJQUFJO01BQ0YsTUFBTUMsVUFBVSxHQUFHLE1BQU0sSUFBQUMsbUJBQVEsRUFBQztRQUNoQ0MsTUFBTSxFQUFFLElBQUFDLHNDQUFxQixFQUFDLENBQUM7UUFDL0JDLEtBQUssRUFBRXJHLE9BQU8sQ0FBQ3FHLEtBQUs7UUFDcEJDLE9BQU8sRUFBRXRHLE9BQU8sQ0FBQ3NHLE9BQU87UUFDeEJDLE1BQU0sRUFBRSxJQUFBQyxnQ0FBbUIsRUFBQ1gsWUFBWSxFQUFFLElBQUFZLDRCQUFlLEVBQUM7VUFBRUosS0FBSyxFQUFFckcsT0FBTyxDQUFDcUcsS0FBSztVQUFFSyxhQUFhLEVBQUVoSCxTQUFTLEVBQUVZLElBQUk7VUFBRUw7UUFBTyxDQUFDLENBQUMsQ0FBQztRQUM1SDRDLFNBQVMsRUFBRUUsYUFBYSxJQUFJdEUsU0FBUztRQUNyQ2tJLFlBQVksRUFBRWQsWUFBWTtRQUMxQmYsTUFBTSxFQUFFO1VBQ05uRCxRQUFRLEVBQUV3SSxPQUFPO1VBQ2pCLElBQUlwSSxNQUFNLENBQUN3SSxRQUFRLEtBQUssSUFBSSxHQUFHO1lBQUVBLFFBQVEsRUFBRXhJLE1BQU0sQ0FBQ3dJO1VBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDL0UsQ0FBQztRQUNEM0QsTUFBTSxFQUFFekIsVUFBVSxDQUFDeUIsTUFBTTtRQUN6QnZCLFFBQVEsRUFBRWdGLFNBQVM7UUFDbkI5RSxLQUFLO1FBQ0xzQixhQUFhLEVBQUUsSUFBQS9HLGlCQUFZLEVBQUMsQ0FBQyxFQUFFQyxRQUFRLENBQUMrRyxnQkFBZ0I7UUFDeERDLE1BQU0sRUFBRTtVQUNOQyxVQUFVLEVBQUUsTUFBT0MsQ0FBQyxJQUFLO1lBQ3ZCLE1BQU03RixLQUFLLENBQUNMLE1BQU0sQ0FBQ1UsSUFBSSxDQUFDSixFQUFFLEVBQUU0RixDQUFDLENBQUM7VUFDaEMsQ0FBQztVQUNEQyxnQkFBZ0IsRUFBRzdFLElBQUksSUFBS3hFLFlBQVksQ0FBRXNKLENBQUMsSUFBS0EsQ0FBQyxHQUFHOUUsSUFBSSxDQUFDO1VBQ3pEK0UsZ0JBQWdCLEVBQUcvRSxJQUFJLElBQUt0RSxXQUFXLENBQUVzSixDQUFDLElBQUtBLENBQUMsR0FBR2hGLElBQUksQ0FBQztVQUN4RGlGLFdBQVcsRUFBR0MsS0FBSyxJQUFLO1lBQ3RCeEosV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUNmZ0QsTUFBTSxDQUNKd0csS0FBSyxDQUFDQyxZQUFZLEtBQUsvSSxTQUFTLEdBQzVCO2NBQUUyRCxJQUFJLEVBQUUsV0FBVztjQUFFQyxJQUFJLEVBQUUsRUFBRTtjQUFFb0YsUUFBUSxFQUFFO1lBQUssQ0FBQyxHQUMvQztjQUFFckYsSUFBSSxFQUFFLFdBQVc7Y0FBRUMsSUFBSSxFQUFFa0YsS0FBSyxDQUFDbEY7WUFBSyxDQUM1QyxDQUFDO1VBQ0gsQ0FBQztVQUNEcUYsZUFBZSxFQUFHckYsSUFBSSxJQUFLO1lBQ3pCLElBQUlBLElBQUksS0FBS3NGLCtCQUFxQixFQUFFNUcsTUFBTSxDQUFDO2NBQUVxQixJQUFJLEVBQUU7WUFBYyxDQUFDLENBQUMsQ0FBQyxLQUMvRCxJQUFJQyxJQUFJLENBQUNrQyxJQUFJLENBQUMsQ0FBQyxFQUFFeEQsTUFBTSxDQUFDO2NBQUVxQixJQUFJLEVBQUUsTUFBTTtjQUFFQztZQUFLLENBQUMsQ0FBQztZQUNwRHhFLFlBQVksQ0FBQyxFQUFFLENBQUM7VUFDbEIsQ0FBQztVQUNEK0osU0FBUyxFQUFFQSxDQUFDQyxJQUFJLEVBQUVDLEtBQUssS0FBSy9HLE1BQU0sQ0FBQztZQUFFcUIsSUFBSSxFQUFFLE1BQU07WUFBRXlGLElBQUk7WUFBRUM7VUFBTSxDQUFDLENBQUM7VUFDakVDLFlBQVksRUFBRUEsQ0FBQ0YsSUFBSSxFQUFFNUYsQ0FBQyxLQUFLbEIsTUFBTSxDQUFDO1lBQUVxQixJQUFJLEVBQUUsUUFBUTtZQUFFeUYsSUFBSTtZQUFFRyxPQUFPLEVBQUUvRixDQUFDLENBQUMrRixPQUFPO1lBQUVDLE9BQU8sRUFBRWhHLENBQUMsQ0FBQ2dHO1VBQVEsQ0FBQyxDQUFDO1VBQ25HQyxPQUFPLEVBQUVBLENBQUEsS0FBTW5ILE1BQU0sQ0FBQztZQUFFcUIsSUFBSSxFQUFFO1VBQVEsQ0FBQyxDQUFDO1VBQ3hDK0YsT0FBTyxFQUFHQyxDQUFDLElBQ1RuSyxRQUFRLENBQUM7WUFDUG9LLFdBQVcsRUFBRUQsQ0FBQyxDQUFDQyxXQUFXO1lBQzFCQyxlQUFlLEVBQUVGLENBQUMsQ0FBQ0UsZUFBZTtZQUNsQ0MsZ0JBQWdCLEVBQUVILENBQUMsQ0FBQ0c7VUFDdEIsQ0FBQyxDQUFDO1VBQ0pDLFNBQVMsRUFBRUEsQ0FBQztZQUFFQztVQUFnQixDQUFDLEtBQUs7WUFDbEMxSCxNQUFNLENBQUM7Y0FBRXFCLElBQUksRUFBRSxZQUFZO2NBQUVzRyxPQUFPLEVBQUUsR0FBR0QsZUFBZTtZQUErQixDQUFDLENBQUM7WUFDekYsS0FBS3JILEtBQUssQ0FDUHVILElBQUksQ0FBQ2xILElBQUksQ0FBQ0osRUFBRSxDQUFDLENBQ2JFLEtBQUssQ0FBRXJGLENBQUMsSUFBS3lILE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLDZEQUE2RCxFQUFFMUgsQ0FBQyxDQUFDLENBQUM7VUFDakcsQ0FBQztVQUNEME0sT0FBTyxFQUFFQSxDQUFDO1lBQUVqSDtVQUFTLENBQUMsS0FBSztZQUN6QixLQUFLLE1BQU1vQyxDQUFDLElBQUlwQyxRQUFRLEVBQUVaLE1BQU0sQ0FBQztjQUFFcUIsSUFBSSxFQUFFLE9BQU87Y0FBRXlHLElBQUksRUFBRTlFLENBQUMsQ0FBQzhFLElBQUk7Y0FBRXhHLElBQUksRUFBRTBCLENBQUMsQ0FBQzFCO1lBQUssQ0FBQyxDQUFDO1VBQ2pGO1FBQ0Y7TUFDRixDQUFDLENBQUM7TUFDRixJQUFJO1FBQ0Z2RixPQUFPLENBQUNxQyxPQUFPLEdBQUcsTUFBTWlDLEtBQUssQ0FBQ3VILElBQUksQ0FBQ2xILElBQUksQ0FBQ0osRUFBRSxFQUFFO1VBQzFDTSxRQUFRLEVBQUVzRSxVQUFVO1VBQ3BCK0MsSUFBSSxFQUFFdkgsSUFBSSxDQUFDdUgsSUFBSSxJQUFJakcsYUFBYTtVQUNoQyxJQUFJdEIsSUFBSSxDQUFDdUgsSUFBSSxLQUFLdkssU0FBUyxHQUFHO1lBQUV3SyxZQUFZLEVBQUVoRztVQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3hFLENBQUMsQ0FBQztRQUNGdEUsYUFBYSxDQUFDLElBQUksQ0FBQztRQUNuQjNCLFlBQVksQ0FBQ21DLE9BQU8sRUFBRStKLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLEtBQUssSUFBQS9FLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUU7VUFBRUMsSUFBSSxFQUFFLHNCQUFzQjtVQUFFaEQsRUFBRSxFQUFFSSxJQUFJLENBQUNKO1FBQUcsQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQ2hHLENBQUMsQ0FBQyxPQUFPckYsQ0FBQyxFQUFFO1FBQ1Z5QyxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO01BQzdDO0lBQ0YsQ0FBQyxDQUFDLE9BQU9ILENBQUMsRUFBRTtNQUNWO01BQ0E7TUFDQTtNQUNBO01BQ0EsTUFBTWlOLEtBQUssR0FBRyxJQUFBQyx3QkFBWSxFQUFDbE4sQ0FBQyxDQUFDO01BQzdCLElBQUlpTixLQUFLLEVBQUU7UUFDVHBJLE1BQU0sQ0FBQztVQUFFcUIsSUFBSSxFQUFFLE9BQU87VUFBRUMsSUFBSSxFQUFFLElBQUFnSCw0QkFBZ0IsRUFBQ0YsS0FBSyxFQUFFLElBQUk7UUFBRSxDQUFDLENBQUM7UUFDOUQsSUFBSUEsS0FBSyxLQUFLLFlBQVksRUFBRTtVQUMxQnRLLFlBQVksQ0FBQztZQUFFTixNQUFNLEVBQUVILFlBQVksQ0FBQ2UsT0FBTyxJQUFJckMsT0FBTyxDQUFDcUMsT0FBTyxFQUFFa0MsRUFBRSxJQUFJLEVBQUU7WUFBRXlELE1BQU0sRUFBRTtVQUFLLENBQUMsQ0FBQztRQUMzRjtNQUNGLENBQUMsTUFBTTtRQUNML0QsTUFBTSxDQUFDO1VBQUVxQixJQUFJLEVBQUUsT0FBTztVQUFFQyxJQUFJLEVBQUduRyxDQUFDLEVBQVlvTixPQUFPLElBQUlDLE1BQU0sQ0FBQ3JOLENBQUM7UUFBRSxDQUFDLENBQUM7TUFDckU7TUFDQSxJQUFJLElBQUFpRyxtQ0FBZ0IsRUFBQ2pHLENBQUMsQ0FBQyxFQUFFO1FBQ3ZCeUMsYUFBYSxDQUFDLElBQUEyRCxnQ0FBUSxFQUFDcEcsQ0FBQyxFQUFFSSxzQkFBc0IsQ0FBQyxDQUFDO01BQ3BEO0lBQ0YsQ0FBQyxTQUFTO01BQ1JxSixjQUFjLENBQUMsQ0FBQztNQUNoQnpJLFFBQVEsQ0FBQ2lDLE9BQU8sR0FBRyxJQUFJO01BQ3ZCc0csWUFBWSxDQUFDLENBQUM7TUFDZHJJLFNBQVMsQ0FBQyxFQUFFLENBQUM7TUFDYkcsWUFBWSxDQUFDLEVBQUUsQ0FBQztNQUNoQk0sWUFBWSxDQUFDLEVBQUUsQ0FBQztNQUNoQkUsV0FBVyxDQUFDLEVBQUUsQ0FBQztNQUNmSSxVQUFVLENBQUMsS0FBSyxDQUFDO01BQ2pCK0MsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDcEI5QyxZQUFZLENBQUNlLE9BQU8sR0FBRyxJQUFJO01BQzNCbEMsUUFBUSxDQUFDa0MsT0FBTyxHQUFHLElBQUk7TUFDdkJuQyxZQUFZLENBQUNtQyxPQUFPLEVBQUVxSyxRQUFRLENBQUMsQ0FBQztJQUNsQztFQUNGLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0UsTUFBTWdCLFlBQVksR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDL0IsTUFBTXBKLEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87SUFDOUIsTUFBTXVGLE9BQU8sR0FBRzVGLGFBQWE7SUFDN0IsTUFBTTJDLElBQUksR0FBRzNFLE9BQU8sQ0FBQ3FDLE9BQU87SUFDNUIsSUFBSSxDQUFDaUMsS0FBSyxJQUFJLENBQUNzRCxPQUFPLElBQUksQ0FBQ2pELElBQUksSUFBSWlELE9BQU8sQ0FBQ25HLE1BQU0sS0FBS2tELElBQUksQ0FBQ0osRUFBRSxFQUFFO0lBQy9EcEMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0lBQ3RCLE1BQU0ySyxRQUFRLEdBQUcsSUFBQUMsd0JBQWdCLEVBQUM7TUFDaENsSSxRQUFRLEVBQUUrQyxPQUFPLENBQUMzQyxNQUFNLENBQUNKLFFBQVE7TUFDakNtSSxjQUFjLEVBQUVwRixPQUFPLENBQUMzQyxNQUFNLENBQUMrSCxjQUFjO01BQzdDQyxlQUFlLEVBQUVyRixPQUFPLENBQUMzQyxNQUFNLENBQUNnSTtJQUNsQyxDQUFDLENBQUM7SUFDRixJQUFJO01BQ0ZqTixPQUFPLENBQUNxQyxPQUFPLEdBQUcsTUFBTWlDLEtBQUssQ0FBQ3VILElBQUksQ0FBQ2xILElBQUksQ0FBQ0osRUFBRSxFQUFFO1FBQzFDTSxRQUFRLEVBQUVpSSxRQUFRLENBQUNqSSxRQUFRO1FBQzNCcUgsSUFBSSxFQUFFdkgsSUFBSSxDQUFDdUgsSUFBSSxJQUFJakcsYUFBYTtRQUNoQyxJQUFJdEIsSUFBSSxDQUFDdUgsSUFBSSxLQUFLdkssU0FBUyxHQUFHO1VBQUV3SyxZQUFZLEVBQUVoRztRQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQ3hFLENBQUMsQ0FBQztNQUNGeEYsTUFBTSxDQUFDLElBQUFpRSx5QkFBYSxFQUFDa0ksUUFBUSxDQUFDakksUUFBUSxDQUFDLENBQUM7TUFDeENoRCxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ25CLEtBQUssSUFBQXdGLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUU7UUFBRUMsSUFBSSxFQUFFLHNCQUFzQjtRQUFFaEQsRUFBRSxFQUFFSSxJQUFJLENBQUNKO01BQUcsQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ2hHLENBQUMsQ0FBQyxPQUFPckYsQ0FBQyxFQUFFO01BQ1Z5QyxhQUFhLENBQUMsSUFBQTJELGdDQUFRLEVBQUNwRyxDQUFDLEVBQUVHLGVBQWUsQ0FBQyxDQUFDO0lBQzdDO0VBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQSxNQUFNb08sS0FBSyxHQUFHLElBQUF0SixrQkFBVyxFQUFFMEgsSUFBZSxJQUFLO0lBQzdDLE1BQU0xQixDQUFDLEdBQUdqSyxRQUFRLENBQUNpQyxPQUFPO0lBQzFCLElBQUksQ0FBQ2dJLENBQUMsRUFBRTtJQUNSLElBQUlBLENBQUMsQ0FBQ3VELE9BQU8sQ0FBQ3BOLFNBQVMsRUFBRXVMLElBQUksQ0FBQyxFQUFFdEwsWUFBWSxDQUFDLEVBQUUsQ0FBQztFQUNsRCxDQUFDLEVBQUUsQ0FBQ0QsU0FBUyxDQUFDLENBQUM7RUFFZixNQUFNcU4sV0FBVyxHQUFHLElBQUF4SixrQkFBVyxFQUFFRSxFQUFVLElBQUs7SUFDOUNuRSxRQUFRLENBQUNpQyxPQUFPLEVBQUV5TCxNQUFNLENBQUN2SixFQUFFLENBQUM7RUFDOUIsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLG9CQUNFLElBQUF0RixXQUFBLENBQUE4TyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxjQUFjO0lBQUFDLFFBQUEsZ0JBQzNCLElBQUFoUCxXQUFBLENBQUE4TyxJQUFBO01BQVFDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ3ZCLElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBRTFNLEtBQUssSUFBSTtNQUFjLENBQU8sQ0FBQyxlQUMzRCxJQUFBdEMsV0FBQSxDQUFBOE8sSUFBQTtRQUFNQyxTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEdBQ3JCL0ssT0FBTyxDQUFDcUcsS0FBSyxDQUFDNEUsTUFBTSxFQUFDLFNBQU8sRUFBQ3ZMLFNBQVMsR0FBRyxtQkFBbUIsR0FBRyxnQkFBZ0IsRUFDL0UxQixLQUFLLGlCQUNKLElBQUFqQyxXQUFBLENBQUE4TyxJQUFBLEVBQUE5TyxXQUFBLENBQUFtUCxRQUFBO1VBQUFILFFBQUEsR0FDRyxLQUFLLEVBQ0wvTSxLQUFLLENBQUNxSyxXQUFXLENBQUM4QyxjQUFjLENBQUMsQ0FBQyxFQUFDLFNBQ3BDLEVBR0NuTixLQUFLLENBQUNzSyxlQUFlLEtBQUs3SixTQUFTLElBQUksTUFBTVQsS0FBSyxDQUFDc0ssZUFBZSxDQUFDNkMsY0FBYyxDQUFDLENBQUMsU0FBUztRQUFBLENBQzdGLENBQ0g7TUFBQSxDQUNHLENBQUM7SUFBQSxDQUNELENBQUMsRUFFUixDQUFDekwsU0FBUyxpQkFDVCxJQUFBM0QsV0FBQSxDQUFBaVAsR0FBQTtNQUFLRixTQUFTLEVBQUMsa0JBQWtCO01BQUNNLElBQUksRUFBQyxRQUFRO01BQUFMLFFBQUEsZUFDN0MsSUFBQWhQLFdBQUEsQ0FBQWlQLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFFBQVE7UUFBQUMsUUFBQSxFQUFDO01BR3pCLENBQU07SUFBQyxDQUNKLENBQ04sRUFFQXJNLFVBQVUsaUJBQ1QsSUFBQTNDLFdBQUEsQ0FBQWlQLEdBQUE7TUFBS0YsU0FBUyxFQUFDLGtCQUFrQjtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLGVBQzdDLElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1FBQU1GLFNBQVMsRUFBQyxRQUFRO1FBQUFDLFFBQUEsRUFBRXJNO01BQVUsQ0FBTztJQUFDLENBQ3pDLENBQ04sZUFFRCxJQUFBM0MsV0FBQSxDQUFBOE8sSUFBQTtNQUFJQyxTQUFTLEVBQUMsUUFBUTtNQUFDLGFBQVUsUUFBUTtNQUFDTyxHQUFHLEVBQUVoTSxNQUFPO01BQUEwTCxRQUFBLGdCQUdwRCxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQSxFQUFDdFAsZUFBQSxDQUFBVSxPQUFjO1FBQUNvQixHQUFHLEVBQUVBO01BQUksQ0FBRSxDQUFDLEVBSzNCTSxRQUFRLGlCQUNQLElBQUEvQixXQUFBLENBQUFpUCxHQUFBO1FBQUlGLFNBQVMsRUFBQyxpQkFBaUI7UUFBQUMsUUFBQSxlQUc3QixJQUFBaFAsV0FBQSxDQUFBOE8sSUFBQTtVQUFTQyxTQUFTLEVBQUMsY0FBYztVQUFDUSxJQUFJO1VBQUFQLFFBQUEsZ0JBQ3BDLElBQUFoUCxXQUFBLENBQUE4TyxJQUFBO1lBQUFFLFFBQUEsZ0JBQ0UsSUFBQWhQLFdBQUEsQ0FBQWlQLEdBQUE7Y0FBTUYsU0FBUyxFQUFDLGlCQUFpQjtjQUFDLGVBQVk7WUFBTSxDQUFFLENBQUMsa0JBRXpEO1VBQUEsQ0FBUyxDQUFDLGVBQ1YsSUFBQS9PLFdBQUEsQ0FBQWlQLEdBQUE7WUFBTUYsU0FBUyxFQUFDLG1CQUFtQjtZQUFDTyxHQUFHLEVBQUUvTCxZQUFhO1lBQUF5TCxRQUFBLEVBQ25Eak47VUFBUSxDQUNMLENBQUM7UUFBQSxDQUNBO01BQUMsQ0FDUixDQUNMLEVBQ0FGLFNBQVMsaUJBQ1IsSUFBQTdCLFdBQUEsQ0FBQWlQLEdBQUE7UUFBSUYsU0FBUyxFQUFDLHlCQUF5QjtRQUFBQyxRQUFBLGVBQ3JDLElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1VBQU1GLFNBQVMsRUFBQyxTQUFTO1VBQUFDLFFBQUEsRUFBRW5OO1FBQVMsQ0FBTztNQUFDLENBQzFDLENBQ0w7SUFBQSxHQTNCeURXLE1BQU0sSUFBSSxNQTRCbEUsQ0FBQyxFQUlKcEIsTUFBTSxDQUFDOE4sTUFBTSxHQUFHLENBQUMsaUJBQ2hCLElBQUFsUCxXQUFBLENBQUFpUCxHQUFBO01BQUlGLFNBQVMsRUFBQyxXQUFXO01BQUMsY0FBVyxvQkFBb0I7TUFBQUMsUUFBQSxFQUN0RDVOLE1BQU0sQ0FBQ29PLEdBQUcsQ0FBRXhILENBQUMsaUJBQ1osSUFBQWhJLFdBQUEsQ0FBQThPLElBQUE7UUFBZUMsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLGdCQUN2QyxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQTtVQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1VBQUFDLFFBQUEsRUFBRWhILENBQUMsQ0FBQzhFLElBQUksS0FBSyxXQUFXLEdBQUcsS0FBSyxHQUFHO1FBQVcsQ0FBTyxDQUFDLGVBQ3RGLElBQUE5TSxXQUFBLENBQUFpUCxHQUFBO1VBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUMsUUFBQSxFQUFFaEgsQ0FBQyxDQUFDMUI7UUFBSSxDQUFPLENBQUMsZUFDaEQsSUFBQXRHLFdBQUEsQ0FBQWlQLEdBQUE7VUFDRTNHLElBQUksRUFBQyxRQUFRO1VBQ2J5RyxTQUFTLEVBQUMsa0JBQWtCO1VBQzVCLGNBQVksNkJBQTZCL0csQ0FBQyxDQUFDMUIsSUFBSSxFQUFHO1VBQ2xEbUosT0FBTyxFQUFFQSxDQUFBLEtBQU1iLFdBQVcsQ0FBQzVHLENBQUMsQ0FBQzFDLEVBQUUsQ0FBRTtVQUFBMEosUUFBQSxFQUNsQztRQUVELENBQVEsQ0FBQztNQUFBLEdBVkZoSCxDQUFDLENBQUMxQyxFQVdQLENBQ0w7SUFBQyxDQUNBLENBQ0wsRUFLQXZDLGFBQWEsSUFBSSxDQUFDWixPQUFPLGlCQUN4QixJQUFBbkMsV0FBQSxDQUFBaVAsR0FBQSxFQUFDcFAsaUJBQUEsQ0FBQVEsT0FBZ0I7TUFDZnFQLFlBQVksRUFBRTNNLGFBQWEsQ0FBQ2lELE1BQU0sQ0FBQzBKLFlBQWE7TUFDaERDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLEtBQUsvQixTQUFTLENBQUMsQ0FBRTtNQUNqQ2dDLFlBQVksRUFBRUEsQ0FBQSxLQUFNLEtBQUtuQixZQUFZLENBQUM7SUFBRSxDQUN6QyxDQUNGLEVBUUE1TCxTQUFTLElBQUksQ0FBQ1YsT0FBTyxJQUFJVSxTQUFTLENBQUNMLE1BQU0sS0FBS0EsTUFBTSxpQkFDbkQsSUFBQXhDLFdBQUEsQ0FBQThPLElBQUE7TUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLGdCQUM3QyxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQTtRQUFNRixTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLEVBQUUsSUFBQWEseUJBQWEsRUFBQyxJQUFJO01BQUMsQ0FBTyxDQUFDLGVBQ3JELElBQUE3UCxXQUFBLENBQUE4TyxJQUFBO1FBQUtDLFNBQVMsRUFBQyxlQUFlO1FBQUFDLFFBQUEsZ0JBQzVCLElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1VBQ0UzRyxJQUFJLEVBQUMsUUFBUTtVQUNieUcsU0FBUyxFQUFDLFFBQVE7VUFDbEJVLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO1lBQ2IsTUFBTTtjQUFFMUcsTUFBTSxFQUFFK0csU0FBUztjQUFFdE4sTUFBTSxFQUFFdU47WUFBUSxDQUFDLEdBQUdsTixTQUFTO1lBQ3hELEtBQUssQ0FBQyxZQUFZO2NBQ2hCLElBQUk7Z0JBQ0YsTUFBTXdDLEtBQUssR0FBR3hFLFFBQVEsQ0FBQ3VDLE9BQU87Z0JBQzlCO2dCQUNBO2dCQUNBO2dCQUNBLElBQUlpQyxLQUFLLEVBQUUsTUFBTUEsS0FBSyxDQUFDMkssV0FBVyxDQUFDRCxPQUFPLENBQUM7Z0JBQzNDak4sWUFBWSxDQUFDLElBQUksQ0FBQztjQUNwQixDQUFDLENBQUMsT0FBTzNDLENBQUMsRUFBRTtnQkFDVnlDLGFBQWEsQ0FBQyxJQUFBMkQsZ0NBQVEsRUFBQ3BHLENBQUMsRUFBRUcsZUFBZSxDQUFDLENBQUM7Z0JBQzNDO2NBQ0Y7Y0FDQSxPQUFPd1AsU0FBUyxHQUFHbEMsU0FBUyxDQUFDLENBQUMsR0FBR3JGLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDekMsQ0FBQyxFQUFFLENBQUM7VUFDTixDQUFFO1VBQUF5RyxRQUFBLEVBQ0g7UUFFRCxDQUFRLENBQUMsZUFDVCxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQTtVQUFRM0csSUFBSSxFQUFDLFFBQVE7VUFBQ3lHLFNBQVMsRUFBQyxjQUFjO1VBQUNVLE9BQU8sRUFBRUEsQ0FBQSxLQUFNM00sWUFBWSxDQUFDLElBQUksQ0FBRTtVQUFBa00sUUFBQSxFQUFDO1FBRWxGLENBQVEsQ0FBQztNQUFBLENBQ04sQ0FBQztJQUFBLENBQ0gsQ0FDTixFQU1BN00sT0FBTyxpQkFDTixJQUFBbkMsV0FBQSxDQUFBaVAsR0FBQTtNQUFHRixTQUFTLEVBQUMsZUFBZTtNQUFDTSxJQUFJLEVBQUMsUUFBUTtNQUFBTCxRQUFBLEVBQ3ZDek4sU0FBUyxDQUFDaUgsSUFBSSxDQUFDLENBQUMsR0FDYixpREFBaUQsR0FDakQ7SUFBeUIsQ0FDNUIsQ0FDSixlQUNELElBQUF4SSxXQUFBLENBQUE4TyxJQUFBO01BQUtDLFNBQVMsRUFBQyxlQUFlO01BQUFDLFFBQUEsZ0JBQzVCLElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1FBQ0VGLFNBQVMsRUFBQyxXQUFXO1FBQ3JCa0IsV0FBVyxFQUNUOU4sT0FBTyxHQUNILCtDQUErQyxHQUMvQyxrREFDTDtRQUNEK04sS0FBSyxFQUFFL04sT0FBTyxHQUFHWixTQUFTLEdBQUdJLE1BQU87UUFDcENrSSxRQUFRLEVBQUcxSixDQUFDLElBQU1nQyxPQUFPLEdBQUdYLFlBQVksQ0FBQ3JCLENBQUMsQ0FBQ2dRLE1BQU0sQ0FBQ0QsS0FBSyxDQUFDLEdBQUd0TyxTQUFTLENBQUN6QixDQUFDLENBQUNnUSxNQUFNLENBQUNELEtBQUssQ0FBRztRQUN0RkUsU0FBUyxFQUFHalEsQ0FBQyxJQUFLO1VBQ2hCLElBQUlBLENBQUMsQ0FBQ2tRLEdBQUcsS0FBSyxPQUFPLEVBQUU7VUFDdkIsSUFBSWxPLE9BQU8sRUFBRXVNLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUN2QixLQUFLbkcsR0FBRyxDQUFDLENBQUM7UUFDakIsQ0FBRTtRQUNGLGNBQVlwRyxPQUFPLEdBQUcsaUJBQWlCLEdBQUc7TUFBUyxDQUNwRCxDQUFDLEVBQ0RBLE9BQU8saUJBQ04sSUFBQW5DLFdBQUEsQ0FBQThPLElBQUEsRUFBQTlPLFdBQUEsQ0FBQW1QLFFBQUE7UUFBQUgsUUFBQSxnQkFDRSxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQTtVQUNFM0csSUFBSSxFQUFDLFFBQVE7VUFDYnlHLFNBQVMsRUFBQyxjQUFjO1VBQ3hCdUIsUUFBUSxFQUFFLENBQUMvTyxTQUFTLENBQUNpSCxJQUFJLENBQUMsQ0FBRTtVQUM1QmlILE9BQU8sRUFBRUEsQ0FBQSxLQUFNZixLQUFLLENBQUMsT0FBTyxDQUFFO1VBQUFNLFFBQUEsRUFDL0I7UUFFRCxDQUFRLENBQUMsZUFDVCxJQUFBaFAsV0FBQSxDQUFBaVAsR0FBQTtVQUNFM0csSUFBSSxFQUFDLFFBQVE7VUFDYnlHLFNBQVMsRUFBQywyQkFBMkI7VUFDckN1QixRQUFRLEVBQUUsQ0FBQy9PLFNBQVMsQ0FBQ2lILElBQUksQ0FBQyxDQUFFO1VBQzVCaUgsT0FBTyxFQUFFQSxDQUFBLEtBQU1mLEtBQUssQ0FBQyxXQUFXLENBQUU7VUFBQU0sUUFBQSxFQUNuQztRQUVELENBQVEsQ0FBQztNQUFBLENBQ1QsQ0FDSCxlQUNELElBQUFoUCxXQUFBLENBQUFpUCxHQUFBO1FBQ0UzRyxJQUFJLEVBQUMsUUFBUTtRQUNieUcsU0FBUyxFQUFDO1FBQ1Y7UUFDQTtRQUFBO1FBQ0F1QixRQUFRLEVBQUVuTyxPQUFPLEdBQUcsS0FBSyxHQUFHLENBQUN3QixTQUFVO1FBQ3ZDckIsS0FBSyxFQUNISCxPQUFPLEdBQ0gsNkNBQTZDLEdBQzdDLENBQUN3QixTQUFTLEdBQ1IsNENBQTRDLEdBQzVDakIsU0FDUDtRQUNEK00sT0FBTyxFQUFFQSxDQUFBLEtBQU90TixPQUFPLEdBQUd1TCxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUtuRixHQUFHLENBQUMsQ0FBRztRQUFBeUcsUUFBQSxFQUU5QzdNLE9BQU8sR0FBRyxNQUFNLEdBQUc7TUFBSyxDQUNuQixDQUFDO0lBQUEsQ0FDTixDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ2xDLEVBQUEsQ0FuL0J1Qk8saUJBQWlCO0VBQUEsUUFDdkJFLGVBQVUsRUFDWEUsY0FBUyxFQW9GeEI4QyxrQ0FBZ0IsRUFDaEJBLGtDQUFnQixFQTBDaEJ3QixnQ0FBZSxFQTRHRzZCLGlCQUFZO0FBQUE7QUFBQXdKLEVBQUEsR0E3T1IvUCxpQkFBaUI7QUFBQSxJQUFBK1AsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}