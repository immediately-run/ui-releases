var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ConversationList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _conversationStore = require("../lib/conversationStore");
var _conversationScope = require("../lib/conversationScope");
var _conversationUpdate = require("../lib/conversationUpdate");
var _conversationIpc = require("../lib/conversationIpc");
var _storeError = require("../lib/storeError");
require("./ConversationList.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The conversation LIST — the panel-slot half of the agents activity (plan Phase
// 04, region `panel.agent`). The analog of the file explorer: it lists the user's
// conversations and a "new" button, and on selection posts the conversation id to
// the stage over IPC. It runs no agent and holds no net:fetch — all model calls
// happen in the stage (ConversationStage).
//
// R3-475 — the list is SCOPED to the repository loaded in the workbench: the
// scoping key is `useWorkspace()?.label` (the workspace the host projects to the
// panel), NOT a conferred worktree mount — the `exposesWorkingTree` shortcut was
// rejected (the panel holds no such capability and site-main pins it absent; see
// the item's narrowed history). Conversations stamped with another repo never mix
// into the list; they surface under "Other repositories" (repo + count). Legacy
// unstamped conversations ride along with every scope and get stamped on their
// next save.
function relTime(ms) {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 45) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

/** R3-475 — what an other-repositories count IS, in words ("2 conversations in
 *  other/repo"): the hover title and the visually-hidden accessible text are the
 *  one string, so they can never disagree. */
function countLabel(g) {
  return `${g.count} ${g.count === 1 ? "conversation" : "conversations"} in ${g.repo}`;
}
function ConversationList() {
  _s();
  const storeRef = (0, _react.useRef)(null);
  const [items, setItems] = (0, _react.useState)([]);
  const [selected, setSelected] = (0, _react.useState)(null);
  const [ready, setReady] = (0, _react.useState)(false);
  // Why the store is unavailable, if it is. Without it "New conversation" is a
  // silent no-op and the list is permanently empty — never leave that unexplained
  // (R3-247).
  const [storeError, setStoreError] = (0, _react.useState)(null);

  // The repository loaded in the workbench (R3-475), from the baseline workspace
  // channel (R3-491). `undefined` when there is no editing session — the channel
  // reports `null` and `scopeConversations` then lists only unstamped conversations,
  // which is the honest answer rather than a guess.
  const workspace = (0, _sdk.useWorkspace)();
  const currentRepo = workspace?.label;

  // Scope the list (R3-475): this repo's conversations (plus legacy unstamped
  // ones) vs. every other repo, grouped. Pure rule in conversationScope.ts.
  const {
    mine,
    others
  } = (0, _react.useMemo)(() => (0, _conversationScope.scopeConversations)(items, currentRepo), [items, currentRepo]);

  // The selection the stage should show: the user's explicit choice while it is
  // still in scope, else the newest in-scope conversation (so the stage isn't
  // blank, and a repo switch or delete re-lands somewhere sensible). DERIVED, not
  // set from an effect — there is one writer (`setSelected`, gesture handlers),
  // while the announcements come from both a gesture post (`openConversation`,
  // so a re-tap of the selected row still lands) and the derived-change effect below.
  const effectiveSelected = (0, _react.useMemo)(() => {
    if (selected && mine.some(c => c.id === selected)) return selected;
    return mine[0]?.id ?? null;
  }, [selected, mine]);

  // Announce a DERIVED selection change to the stage — the bookkeeping fallback (first
  // row on load, next after a delete/scope change). A user's tap is also announced
  // directly by `openConversation`, so a re-tap of the already-selected row — which does
  // not change `effectiveSelected` and so skips this effect — still posts (R3-616). A
  // tap on a *different* row is therefore announced twice — by the gesture post and
  // again by this effect — the item's accepted cost, harmless because the arbiter is
  // idempotent.
  (0, _react.useEffect)(() => {
    if (!effectiveSelected) return;
    void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(effectiveSelected)).catch(() => {});
  }, [effectiveSelected]);

  // The current selection, readable from the IPC listener without re-subscribing it
  // on every change (the stage asks for it when it mounts). Mirrored in an effect,
  // not during render — the listener only ever reads it asynchronously.
  const selectedRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    selectedRef.current = effectiveSelected;
  }, [effectiveSelected]);

  // OPEN = select AND take the user there (R3-243). Distinct from `select` on
  // purpose: only a tap that MEANS "show me this" advances the column. Selecting
  // the first conversation on load, or the next one after a delete, is bookkeeping
  // — advancing there would move the user somewhere they didn't ask to go, and the
  // host would refuse it anyway (no gesture).
  //
  // The host ignores a reveal it doesn't like, so this needs no success handling;
  // it only swallows the authorization rejection (an older host has no `reveal`
  // method, which must degrade to today's behaviour rather than an unhandled reject).
  const openConversation = (0, _react.useCallback)(id => {
    setSelected(id);
    // A tap is an event, not a state transition: announce it directly (R3-616) so a tap
    // on the already-selected row still posts — the derived-value effect above only fires
    // when `effectiveSelected` changes, so the re-tap case was previously silent.
    void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(id)).catch(() => {});
    void (0, _sdk.revealRegion)(_conversationIpc.STAGE_REGION).catch(() => {});
  }, []);
  const refresh = (0, _react.useCallback)(async () => {
    const store = storeRef.current;
    if (!store) return;
    try {
      setItems(await store.list());
    } catch {
      /* transient read failure — keep the last good list */
    }
  }, []);

  // Open the store and list. Selection happens in the scoped effect below, so the
  // stage isn't seeded with another repo's newest conversation (R3-475).
  (0, _react.useEffect)(() => {
    let live = true;
    void (async () => {
      try {
        const store = await (0, _conversationStore.openConversationStore)();
        if (!live) return;
        storeRef.current = store;
        const list = await store.list();
        if (!live) return;
        setItems(list);
        setStoreError(null);
      } catch (e) {
        if (live) setStoreError((0, _storeError.describeStoreFailure)(e));
      } finally {
        if (live) setReady(true);
      }
    })();
    return () => {
      live = false;
    };
  }, []);

  // Keep the list fresh. A `conversation-updated` message names ONE conversation,
  // so the handler loads that row and patches it in place (R3-612 / R-IX-4) — a
  // full `list()` re-reads every conversation JSON (cap 500) to learn one row's
  // title and timestamp moved. `refresh()` stays for the focus-regain path, where
  // there is no narrower signal; the mount path lists directly (it needs the
  // store-open error handling too).
  const patchOne = (0, _react.useCallback)(async id => {
    const store = storeRef.current;
    if (!store) return;
    try {
      const conv = await store.load(id);
      // `null` = deleted elsewhere (or corrupt): the row goes.
      setItems(l => conv ? (0, _conversationUpdate.applyConversationUpdate)(l, (0, _conversationStore.metaOf)(conv)) : l.filter(c => c.id !== id));
    } catch {
      // Read failure — keep the last good list, the same resolution as refresh().
    }
  }, []);
  (0, _react.useEffect)(() => {
    const off = (0, _sdk.onRegionMessage)(m => {
      if ((0, _conversationIpc.isUpdated)(m.data)) void patchOne(m.data.id);
      // The stage mounted and wants to know what it should be showing (R3-243). It
      // may have missed the `select-conversation` entirely: on mobile it does not
      // exist until the reveal puts it on screen, which happens after the post.
      // Answering here is what makes tapping an OLDER conversation land on that one
      // rather than on the newest.
      else if ((0, _conversationIpc.isRequestSelection)(m.data) && selectedRef.current) {
        void (0, _sdk.postToRegion)(_conversationIpc.STAGE_REGION, (0, _conversationIpc.selectMessage)(selectedRef.current)).catch(() => {});
      }
    });
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      off();
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh, patchOne]);
  const newConversation = async () => {
    const store = storeRef.current;
    // No store ⇒ the button cannot work. Say why rather than doing nothing.
    if (!store) {
      setStoreError(prev => prev ?? (0, _storeError.describeStoreFailure)(new Error("settings unavailable")));
      return;
    }
    try {
      // Stamped with the loaded repo (R3-475) so it scopes correctly from birth —
      // label AND provider (R3-848): the label alone cannot say which provider
      // the repo lives under.
      const conv = await store.create(undefined, currentRepo, workspace?.provider);
      setItems(l => [(0, _conversationStore.metaOf)(conv), ...l]);
      setStoreError(null);
      openConversation(conv.id);
    } catch (e) {
      setStoreError((0, _storeError.describeStoreFailure)(e));
    }
  };

  // R3-848 — a refused repository open, shown ON the row that asked (never
  // swallowed): keyed by the group's repo label.
  const [openError, setOpenError] = (0, _react.useState)(null);

  // Open another repo's row's repository in a new tab (R3-848): the
  // host-mediated verb, called DIRECTLY from the click handler — no `await`
  // before it, so the host still sees the click's transient activation (a
  // deferred call is refused `no-activation`). The app names COORDINATES and
  // nothing else: no URL, no route prefix — the host builds the destination.
  // A group that cannot name its coordinates (a legacy record with no provider
  // stamp, a label that is not a namespace/repository pair) is REFUSED on the
  // row — never opened under a guessed provider (the round-1 review: the SDK's
  // workspace can carry a `local` provider; the guess is the thing the item
  // said not to do).
  const openRepoRow = g => {
    const coords = (0, _conversationScope.repoCoordinatesOf)(g);
    if (!coords) {
      setOpenError({
        repo: g.repo,
        code: g.provider === undefined ? "no provider stamp (a legacy conversation)" : "invalid"
      });
      return;
    }
    void (0, _sdk.openRepository)(coords).then(() => {
      // A success clears the row's earlier refusal, if any — a refusal that
      // no longer holds must not stay on the row.
      setOpenError(prev => prev?.repo === g.repo ? null : prev);
    }).catch(e => {
      setOpenError({
        repo: g.repo,
        code: e?.code ?? "unknown"
      });
    });
  };
  const remove = async id => {
    const store = storeRef.current;
    if (!store) return;
    try {
      await store.remove(id);
    } catch (e) {
      // A delete that failed must leave the row in place and say why (R-IX-3):
      // dropping it anyway would show a change that did not happen. Same
      // failure surface as create/save above.
      setStoreError((0, _storeError.describeStoreFailure)(e));
      return;
    }
    setItems(l => l.filter(c => c.id !== id));
    if (selected === id) setSelected(null); // the scoped effect re-selects
    setStoreError(null);
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "cl",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "cl-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "cl-title",
        children: "Conversations"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "cl-new",
        onClick: () => void newConversation(),
        children: "New conversation"
      })]
    }), currentRepo && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-scope",
      title: "Conversations are scoped to the repository loaded in the workbench.",
      children: currentRepo
    }), storeError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-empty cl-error",
      role: "status",
      children: storeError
    }), ready && !storeError && mine.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "cl-empty",
      children: "No conversations here yet. Start one with \u201CNew conversation\u201D."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "cl-list",
      children: mine.map(c => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: `cl-row${effectiveSelected === c.id ? " cl-row-active" : ""}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "cl-row-open",
          "aria-pressed": effectiveSelected === c.id,
          onClick: () => openConversation(c.id),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "cl-row-title",
            children: c.title
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "cl-row-time",
            children: relTime(c.updatedAt)
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "cl-del",
          "aria-label": `Delete ${c.title}`,
          onClick: () => void remove(c.id),
          children: "\xD7"
        })]
      }, c.id))
    }), ready && others.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
      className: "cl-others",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
        children: "Other repositories"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "cl-others-list",
        children: others.map(g => {
          // R3-475 — the count must say what it counts: a bare digit has no
          // hover label and announces as a lone number to a screen reader.
          // The row's own title says what OPENING the repo does; the count's
          // label says what the number IS. (The accessible text is
          // visually-hidden real text, not aria-label on a generic span —
          // naming is prohibited on role=generic, so aria-label would be a
          // placebo.)
          const label = countLabel(g);
          const refused = openError?.repo === g.repo ? openError.code : null;
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
            className: "cl-others-row",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
              type: "button",
              className: "cl-others-open",
              title: `Open ${g.repo} on immediately.run to see these conversations.`,
              onClick: () => openRepoRow(g),
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "cl-others-repo",
                children: g.repo
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
                className: "cl-others-count",
                title: label,
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "cl-vh",
                  children: label
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  "aria-hidden": "true",
                  children: g.count
                })]
              })]
            }), refused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "cl-others-refused",
              role: "status",
              children: refused
            })]
          }, g.repo);
        })
      })]
    })]
  });
}
_s(ConversationList, "vfXLMcgFq0rSuLEsF4vjm31SO1s=", false, function () {
  return [_sdk.useWorkspace];
});
_c = ConversationList;
var _c;
$RefreshReg$(_c, "ConversationList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb252ZXJzYXRpb25TdG9yZSIsIl9jb252ZXJzYXRpb25TY29wZSIsIl9jb252ZXJzYXRpb25VcGRhdGUiLCJfY29udmVyc2F0aW9uSXBjIiwiX3N0b3JlRXJyb3IiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwicmVsVGltZSIsIm1zIiwicyIsIk1hdGgiLCJtYXgiLCJyb3VuZCIsIkRhdGUiLCJub3ciLCJtIiwiaCIsImNvdW50TGFiZWwiLCJnIiwiY291bnQiLCJyZXBvIiwiQ29udmVyc2F0aW9uTGlzdCIsInN0b3JlUmVmIiwidXNlUmVmIiwiaXRlbXMiLCJzZXRJdGVtcyIsInVzZVN0YXRlIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInJlYWR5Iiwic2V0UmVhZHkiLCJzdG9yZUVycm9yIiwic2V0U3RvcmVFcnJvciIsIndvcmtzcGFjZSIsInVzZVdvcmtzcGFjZSIsImN1cnJlbnRSZXBvIiwibGFiZWwiLCJtaW5lIiwib3RoZXJzIiwidXNlTWVtbyIsInNjb3BlQ29udmVyc2F0aW9ucyIsImVmZmVjdGl2ZVNlbGVjdGVkIiwic29tZSIsImMiLCJpZCIsInVzZUVmZmVjdCIsInBvc3RUb1JlZ2lvbiIsIlNUQUdFX1JFR0lPTiIsInNlbGVjdE1lc3NhZ2UiLCJjYXRjaCIsInNlbGVjdGVkUmVmIiwiY3VycmVudCIsIm9wZW5Db252ZXJzYXRpb24iLCJ1c2VDYWxsYmFjayIsInJldmVhbFJlZ2lvbiIsInJlZnJlc2giLCJzdG9yZSIsImxpc3QiLCJsaXZlIiwib3BlbkNvbnZlcnNhdGlvblN0b3JlIiwiZSIsImRlc2NyaWJlU3RvcmVGYWlsdXJlIiwicGF0Y2hPbmUiLCJjb252IiwibG9hZCIsImwiLCJhcHBseUNvbnZlcnNhdGlvblVwZGF0ZSIsIm1ldGFPZiIsImZpbHRlciIsIm9mZiIsIm9uUmVnaW9uTWVzc2FnZSIsImlzVXBkYXRlZCIsImRhdGEiLCJpc1JlcXVlc3RTZWxlY3Rpb24iLCJvbkZvY3VzIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJuZXdDb252ZXJzYXRpb24iLCJwcmV2IiwiRXJyb3IiLCJjcmVhdGUiLCJ1bmRlZmluZWQiLCJwcm92aWRlciIsIm9wZW5FcnJvciIsInNldE9wZW5FcnJvciIsIm9wZW5SZXBvUm93IiwiY29vcmRzIiwicmVwb0Nvb3JkaW5hdGVzT2YiLCJjb2RlIiwib3BlblJlcG9zaXRvcnkiLCJ0aGVuIiwicmVtb3ZlIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwidHlwZSIsIm9uQ2xpY2siLCJ0aXRsZSIsInJvbGUiLCJsZW5ndGgiLCJtYXAiLCJ1cGRhdGVkQXQiLCJyZWZ1c2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb252ZXJzYXRpb25MaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgY29udmVyc2F0aW9uIExJU1Qg4oCUIHRoZSBwYW5lbC1zbG90IGhhbGYgb2YgdGhlIGFnZW50cyBhY3Rpdml0eSAocGxhbiBQaGFzZVxuLy8gMDQsIHJlZ2lvbiBgcGFuZWwuYWdlbnRgKS4gVGhlIGFuYWxvZyBvZiB0aGUgZmlsZSBleHBsb3JlcjogaXQgbGlzdHMgdGhlIHVzZXInc1xuLy8gY29udmVyc2F0aW9ucyBhbmQgYSBcIm5ld1wiIGJ1dHRvbiwgYW5kIG9uIHNlbGVjdGlvbiBwb3N0cyB0aGUgY29udmVyc2F0aW9uIGlkIHRvXG4vLyB0aGUgc3RhZ2Ugb3ZlciBJUEMuIEl0IHJ1bnMgbm8gYWdlbnQgYW5kIGhvbGRzIG5vIG5ldDpmZXRjaCDigJQgYWxsIG1vZGVsIGNhbGxzXG4vLyBoYXBwZW4gaW4gdGhlIHN0YWdlIChDb252ZXJzYXRpb25TdGFnZSkuXG4vL1xuLy8gUjMtNDc1IOKAlCB0aGUgbGlzdCBpcyBTQ09QRUQgdG8gdGhlIHJlcG9zaXRvcnkgbG9hZGVkIGluIHRoZSB3b3JrYmVuY2g6IHRoZVxuLy8gc2NvcGluZyBrZXkgaXMgYHVzZVdvcmtzcGFjZSgpPy5sYWJlbGAgKHRoZSB3b3Jrc3BhY2UgdGhlIGhvc3QgcHJvamVjdHMgdG8gdGhlXG4vLyBwYW5lbCksIE5PVCBhIGNvbmZlcnJlZCB3b3JrdHJlZSBtb3VudCDigJQgdGhlIGBleHBvc2VzV29ya2luZ1RyZWVgIHNob3J0Y3V0IHdhc1xuLy8gcmVqZWN0ZWQgKHRoZSBwYW5lbCBob2xkcyBubyBzdWNoIGNhcGFiaWxpdHkgYW5kIHNpdGUtbWFpbiBwaW5zIGl0IGFic2VudDsgc2VlXG4vLyB0aGUgaXRlbSdzIG5hcnJvd2VkIGhpc3RvcnkpLiBDb252ZXJzYXRpb25zIHN0YW1wZWQgd2l0aCBhbm90aGVyIHJlcG8gbmV2ZXIgbWl4XG4vLyBpbnRvIHRoZSBsaXN0OyB0aGV5IHN1cmZhY2UgdW5kZXIgXCJPdGhlciByZXBvc2l0b3JpZXNcIiAocmVwbyArIGNvdW50KS4gTGVnYWN5XG4vLyB1bnN0YW1wZWQgY29udmVyc2F0aW9ucyByaWRlIGFsb25nIHdpdGggZXZlcnkgc2NvcGUgYW5kIGdldCBzdGFtcGVkIG9uIHRoZWlyXG4vLyBuZXh0IHNhdmUuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBwb3N0VG9SZWdpb24sIG9uUmVnaW9uTWVzc2FnZSwgcmV2ZWFsUmVnaW9uLCB1c2VXb3Jrc3BhY2UsIG9wZW5SZXBvc2l0b3J5IH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyBvcGVuQ29udmVyc2F0aW9uU3RvcmUsIG1ldGFPZiwgdHlwZSBDb252ZXJzYXRpb25TdG9yZSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uU3RvcmVcIjtcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uTWV0YSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uTW9kZWxcIjtcbmltcG9ydCB7IHNjb3BlQ29udmVyc2F0aW9ucywgcmVwb0Nvb3JkaW5hdGVzT2YsIHR5cGUgUmVwb0dyb3VwIH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25TY29wZVwiO1xuaW1wb3J0IHsgYXBwbHlDb252ZXJzYXRpb25VcGRhdGUgfSBmcm9tIFwiLi4vbGliL2NvbnZlcnNhdGlvblVwZGF0ZVwiO1xuaW1wb3J0IHsgU1RBR0VfUkVHSU9OLCBpc1VwZGF0ZWQsIGlzUmVxdWVzdFNlbGVjdGlvbiwgc2VsZWN0TWVzc2FnZSB9IGZyb20gXCIuLi9saWIvY29udmVyc2F0aW9uSXBjXCI7XG5pbXBvcnQgeyBkZXNjcmliZVN0b3JlRmFpbHVyZSB9IGZyb20gXCIuLi9saWIvc3RvcmVFcnJvclwiO1xuaW1wb3J0IFwiLi9Db252ZXJzYXRpb25MaXN0LmNzc1wiO1xuXG5mdW5jdGlvbiByZWxUaW1lKG1zOiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCBzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIG1zKSAvIDEwMDApKTtcbiAgaWYgKHMgPCA0NSkgcmV0dXJuIFwianVzdCBub3dcIjtcbiAgY29uc3QgbSA9IE1hdGgucm91bmQocyAvIDYwKTtcbiAgaWYgKG0gPCA2MCkgcmV0dXJuIGAke219bSBhZ29gO1xuICBjb25zdCBoID0gTWF0aC5yb3VuZChtIC8gNjApO1xuICBpZiAoaCA8IDI0KSByZXR1cm4gYCR7aH1oIGFnb2A7XG4gIHJldHVybiBgJHtNYXRoLnJvdW5kKGggLyAyNCl9ZCBhZ29gO1xufVxuXG4vKiogUjMtNDc1IOKAlCB3aGF0IGFuIG90aGVyLXJlcG9zaXRvcmllcyBjb3VudCBJUywgaW4gd29yZHMgKFwiMiBjb252ZXJzYXRpb25zIGluXG4gKiAgb3RoZXIvcmVwb1wiKTogdGhlIGhvdmVyIHRpdGxlIGFuZCB0aGUgdmlzdWFsbHktaGlkZGVuIGFjY2Vzc2libGUgdGV4dCBhcmUgdGhlXG4gKiAgb25lIHN0cmluZywgc28gdGhleSBjYW4gbmV2ZXIgZGlzYWdyZWUuICovXG5mdW5jdGlvbiBjb3VudExhYmVsKGc6IFJlcG9Hcm91cCk6IHN0cmluZyB7XG4gIHJldHVybiBgJHtnLmNvdW50fSAke2cuY291bnQgPT09IDEgPyBcImNvbnZlcnNhdGlvblwiIDogXCJjb252ZXJzYXRpb25zXCJ9IGluICR7Zy5yZXBvfWA7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnZlcnNhdGlvbkxpc3QoKSB7XG4gIGNvbnN0IHN0b3JlUmVmID0gdXNlUmVmPENvbnZlcnNhdGlvblN0b3JlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8Q29udmVyc2F0aW9uTWV0YVtdPihbXSk7XG4gIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtyZWFkeSwgc2V0UmVhZHldID0gdXNlU3RhdGUoZmFsc2UpO1xuICAvLyBXaHkgdGhlIHN0b3JlIGlzIHVuYXZhaWxhYmxlLCBpZiBpdCBpcy4gV2l0aG91dCBpdCBcIk5ldyBjb252ZXJzYXRpb25cIiBpcyBhXG4gIC8vIHNpbGVudCBuby1vcCBhbmQgdGhlIGxpc3QgaXMgcGVybWFuZW50bHkgZW1wdHkg4oCUIG5ldmVyIGxlYXZlIHRoYXQgdW5leHBsYWluZWRcbiAgLy8gKFIzLTI0NykuXG4gIGNvbnN0IFtzdG9yZUVycm9yLCBzZXRTdG9yZUVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFRoZSByZXBvc2l0b3J5IGxvYWRlZCBpbiB0aGUgd29ya2JlbmNoIChSMy00NzUpLCBmcm9tIHRoZSBiYXNlbGluZSB3b3Jrc3BhY2VcbiAgLy8gY2hhbm5lbCAoUjMtNDkxKS4gYHVuZGVmaW5lZGAgd2hlbiB0aGVyZSBpcyBubyBlZGl0aW5nIHNlc3Npb24g4oCUIHRoZSBjaGFubmVsXG4gIC8vIHJlcG9ydHMgYG51bGxgIGFuZCBgc2NvcGVDb252ZXJzYXRpb25zYCB0aGVuIGxpc3RzIG9ubHkgdW5zdGFtcGVkIGNvbnZlcnNhdGlvbnMsXG4gIC8vIHdoaWNoIGlzIHRoZSBob25lc3QgYW5zd2VyIHJhdGhlciB0aGFuIGEgZ3Vlc3MuXG4gIGNvbnN0IHdvcmtzcGFjZSA9IHVzZVdvcmtzcGFjZSgpO1xuICBjb25zdCBjdXJyZW50UmVwbyA9IHdvcmtzcGFjZT8ubGFiZWw7XG5cbiAgLy8gU2NvcGUgdGhlIGxpc3QgKFIzLTQ3NSk6IHRoaXMgcmVwbydzIGNvbnZlcnNhdGlvbnMgKHBsdXMgbGVnYWN5IHVuc3RhbXBlZFxuICAvLyBvbmVzKSB2cy4gZXZlcnkgb3RoZXIgcmVwbywgZ3JvdXBlZC4gUHVyZSBydWxlIGluIGNvbnZlcnNhdGlvblNjb3BlLnRzLlxuICBjb25zdCB7IG1pbmUsIG90aGVycyB9ID0gdXNlTWVtbygoKSA9PiBzY29wZUNvbnZlcnNhdGlvbnMoaXRlbXMsIGN1cnJlbnRSZXBvKSwgW2l0ZW1zLCBjdXJyZW50UmVwb10pO1xuXG4gIC8vIFRoZSBzZWxlY3Rpb24gdGhlIHN0YWdlIHNob3VsZCBzaG93OiB0aGUgdXNlcidzIGV4cGxpY2l0IGNob2ljZSB3aGlsZSBpdCBpc1xuICAvLyBzdGlsbCBpbiBzY29wZSwgZWxzZSB0aGUgbmV3ZXN0IGluLXNjb3BlIGNvbnZlcnNhdGlvbiAoc28gdGhlIHN0YWdlIGlzbid0XG4gIC8vIGJsYW5rLCBhbmQgYSByZXBvIHN3aXRjaCBvciBkZWxldGUgcmUtbGFuZHMgc29tZXdoZXJlIHNlbnNpYmxlKS4gREVSSVZFRCwgbm90XG4gIC8vIHNldCBmcm9tIGFuIGVmZmVjdCDigJQgdGhlcmUgaXMgb25lIHdyaXRlciAoYHNldFNlbGVjdGVkYCwgZ2VzdHVyZSBoYW5kbGVycyksXG4gIC8vIHdoaWxlIHRoZSBhbm5vdW5jZW1lbnRzIGNvbWUgZnJvbSBib3RoIGEgZ2VzdHVyZSBwb3N0IChgb3BlbkNvbnZlcnNhdGlvbmAsXG4gIC8vIHNvIGEgcmUtdGFwIG9mIHRoZSBzZWxlY3RlZCByb3cgc3RpbGwgbGFuZHMpIGFuZCB0aGUgZGVyaXZlZC1jaGFuZ2UgZWZmZWN0IGJlbG93LlxuICBjb25zdCBlZmZlY3RpdmVTZWxlY3RlZCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZCAmJiBtaW5lLnNvbWUoKGMpID0+IGMuaWQgPT09IHNlbGVjdGVkKSkgcmV0dXJuIHNlbGVjdGVkO1xuICAgIHJldHVybiBtaW5lWzBdPy5pZCA/PyBudWxsO1xuICB9LCBbc2VsZWN0ZWQsIG1pbmVdKTtcblxuICAvLyBBbm5vdW5jZSBhIERFUklWRUQgc2VsZWN0aW9uIGNoYW5nZSB0byB0aGUgc3RhZ2Ug4oCUIHRoZSBib29ra2VlcGluZyBmYWxsYmFjayAoZmlyc3RcbiAgLy8gcm93IG9uIGxvYWQsIG5leHQgYWZ0ZXIgYSBkZWxldGUvc2NvcGUgY2hhbmdlKS4gQSB1c2VyJ3MgdGFwIGlzIGFsc28gYW5ub3VuY2VkXG4gIC8vIGRpcmVjdGx5IGJ5IGBvcGVuQ29udmVyc2F0aW9uYCwgc28gYSByZS10YXAgb2YgdGhlIGFscmVhZHktc2VsZWN0ZWQgcm93IOKAlCB3aGljaCBkb2VzXG4gIC8vIG5vdCBjaGFuZ2UgYGVmZmVjdGl2ZVNlbGVjdGVkYCBhbmQgc28gc2tpcHMgdGhpcyBlZmZlY3Qg4oCUIHN0aWxsIHBvc3RzIChSMy02MTYpLiBBXG4gIC8vIHRhcCBvbiBhICpkaWZmZXJlbnQqIHJvdyBpcyB0aGVyZWZvcmUgYW5ub3VuY2VkIHR3aWNlIOKAlCBieSB0aGUgZ2VzdHVyZSBwb3N0IGFuZFxuICAvLyBhZ2FpbiBieSB0aGlzIGVmZmVjdCDigJQgdGhlIGl0ZW0ncyBhY2NlcHRlZCBjb3N0LCBoYXJtbGVzcyBiZWNhdXNlIHRoZSBhcmJpdGVyIGlzXG4gIC8vIGlkZW1wb3RlbnQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlZmZlY3RpdmVTZWxlY3RlZCkgcmV0dXJuO1xuICAgIHZvaWQgcG9zdFRvUmVnaW9uKFNUQUdFX1JFR0lPTiwgc2VsZWN0TWVzc2FnZShlZmZlY3RpdmVTZWxlY3RlZCkpLmNhdGNoKCgpID0+IHt9KTtcbiAgfSwgW2VmZmVjdGl2ZVNlbGVjdGVkXSk7XG5cbiAgLy8gVGhlIGN1cnJlbnQgc2VsZWN0aW9uLCByZWFkYWJsZSBmcm9tIHRoZSBJUEMgbGlzdGVuZXIgd2l0aG91dCByZS1zdWJzY3JpYmluZyBpdFxuICAvLyBvbiBldmVyeSBjaGFuZ2UgKHRoZSBzdGFnZSBhc2tzIGZvciBpdCB3aGVuIGl0IG1vdW50cykuIE1pcnJvcmVkIGluIGFuIGVmZmVjdCxcbiAgLy8gbm90IGR1cmluZyByZW5kZXIg4oCUIHRoZSBsaXN0ZW5lciBvbmx5IGV2ZXIgcmVhZHMgaXQgYXN5bmNocm9ub3VzbHkuXG4gIGNvbnN0IHNlbGVjdGVkUmVmID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNlbGVjdGVkUmVmLmN1cnJlbnQgPSBlZmZlY3RpdmVTZWxlY3RlZDtcbiAgfSwgW2VmZmVjdGl2ZVNlbGVjdGVkXSk7XG5cbiAgLy8gT1BFTiA9IHNlbGVjdCBBTkQgdGFrZSB0aGUgdXNlciB0aGVyZSAoUjMtMjQzKS4gRGlzdGluY3QgZnJvbSBgc2VsZWN0YCBvblxuICAvLyBwdXJwb3NlOiBvbmx5IGEgdGFwIHRoYXQgTUVBTlMgXCJzaG93IG1lIHRoaXNcIiBhZHZhbmNlcyB0aGUgY29sdW1uLiBTZWxlY3RpbmdcbiAgLy8gdGhlIGZpcnN0IGNvbnZlcnNhdGlvbiBvbiBsb2FkLCBvciB0aGUgbmV4dCBvbmUgYWZ0ZXIgYSBkZWxldGUsIGlzIGJvb2trZWVwaW5nXG4gIC8vIOKAlCBhZHZhbmNpbmcgdGhlcmUgd291bGQgbW92ZSB0aGUgdXNlciBzb21ld2hlcmUgdGhleSBkaWRuJ3QgYXNrIHRvIGdvLCBhbmQgdGhlXG4gIC8vIGhvc3Qgd291bGQgcmVmdXNlIGl0IGFueXdheSAobm8gZ2VzdHVyZSkuXG4gIC8vXG4gIC8vIFRoZSBob3N0IGlnbm9yZXMgYSByZXZlYWwgaXQgZG9lc24ndCBsaWtlLCBzbyB0aGlzIG5lZWRzIG5vIHN1Y2Nlc3MgaGFuZGxpbmc7XG4gIC8vIGl0IG9ubHkgc3dhbGxvd3MgdGhlIGF1dGhvcml6YXRpb24gcmVqZWN0aW9uIChhbiBvbGRlciBob3N0IGhhcyBubyBgcmV2ZWFsYFxuICAvLyBtZXRob2QsIHdoaWNoIG11c3QgZGVncmFkZSB0byB0b2RheSdzIGJlaGF2aW91ciByYXRoZXIgdGhhbiBhbiB1bmhhbmRsZWQgcmVqZWN0KS5cbiAgY29uc3Qgb3BlbkNvbnZlcnNhdGlvbiA9IHVzZUNhbGxiYWNrKChpZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWQoaWQpO1xuICAgIC8vIEEgdGFwIGlzIGFuIGV2ZW50LCBub3QgYSBzdGF0ZSB0cmFuc2l0aW9uOiBhbm5vdW5jZSBpdCBkaXJlY3RseSAoUjMtNjE2KSBzbyBhIHRhcFxuICAgIC8vIG9uIHRoZSBhbHJlYWR5LXNlbGVjdGVkIHJvdyBzdGlsbCBwb3N0cyDigJQgdGhlIGRlcml2ZWQtdmFsdWUgZWZmZWN0IGFib3ZlIG9ubHkgZmlyZXNcbiAgICAvLyB3aGVuIGBlZmZlY3RpdmVTZWxlY3RlZGAgY2hhbmdlcywgc28gdGhlIHJlLXRhcCBjYXNlIHdhcyBwcmV2aW91c2x5IHNpbGVudC5cbiAgICB2b2lkIHBvc3RUb1JlZ2lvbihTVEFHRV9SRUdJT04sIHNlbGVjdE1lc3NhZ2UoaWQpKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgdm9pZCByZXZlYWxSZWdpb24oU1RBR0VfUkVHSU9OKS5jYXRjaCgoKSA9PiB7fSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCByZWZyZXNoID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gc3RvcmVSZWYuY3VycmVudDtcbiAgICBpZiAoIXN0b3JlKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIHNldEl0ZW1zKGF3YWl0IHN0b3JlLmxpc3QoKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiB0cmFuc2llbnQgcmVhZCBmYWlsdXJlIOKAlCBrZWVwIHRoZSBsYXN0IGdvb2QgbGlzdCAqL1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIC8vIE9wZW4gdGhlIHN0b3JlIGFuZCBsaXN0LiBTZWxlY3Rpb24gaGFwcGVucyBpbiB0aGUgc2NvcGVkIGVmZmVjdCBiZWxvdywgc28gdGhlXG4gIC8vIHN0YWdlIGlzbid0IHNlZWRlZCB3aXRoIGFub3RoZXIgcmVwbydzIG5ld2VzdCBjb252ZXJzYXRpb24gKFIzLTQ3NSkuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGxpdmUgPSB0cnVlO1xuICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXdhaXQgb3BlbkNvbnZlcnNhdGlvblN0b3JlKCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzdG9yZVJlZi5jdXJyZW50ID0gc3RvcmU7XG4gICAgICAgIGNvbnN0IGxpc3QgPSBhd2FpdCBzdG9yZS5saXN0KCk7XG4gICAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgICBzZXRJdGVtcyhsaXN0KTtcbiAgICAgICAgc2V0U3RvcmVFcnJvcihudWxsKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGxpdmUpIHNldFN0b3JlRXJyb3IoZGVzY3JpYmVTdG9yZUZhaWx1cmUoZSkpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaWYgKGxpdmUpIHNldFJlYWR5KHRydWUpO1xuICAgICAgfVxuICAgIH0pKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGxpdmUgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgLy8gS2VlcCB0aGUgbGlzdCBmcmVzaC4gQSBgY29udmVyc2F0aW9uLXVwZGF0ZWRgIG1lc3NhZ2UgbmFtZXMgT05FIGNvbnZlcnNhdGlvbixcbiAgLy8gc28gdGhlIGhhbmRsZXIgbG9hZHMgdGhhdCByb3cgYW5kIHBhdGNoZXMgaXQgaW4gcGxhY2UgKFIzLTYxMiAvIFItSVgtNCkg4oCUIGFcbiAgLy8gZnVsbCBgbGlzdCgpYCByZS1yZWFkcyBldmVyeSBjb252ZXJzYXRpb24gSlNPTiAoY2FwIDUwMCkgdG8gbGVhcm4gb25lIHJvdydzXG4gIC8vIHRpdGxlIGFuZCB0aW1lc3RhbXAgbW92ZWQuIGByZWZyZXNoKClgIHN0YXlzIGZvciB0aGUgZm9jdXMtcmVnYWluIHBhdGgsIHdoZXJlXG4gIC8vIHRoZXJlIGlzIG5vIG5hcnJvd2VyIHNpZ25hbDsgdGhlIG1vdW50IHBhdGggbGlzdHMgZGlyZWN0bHkgKGl0IG5lZWRzIHRoZVxuICAvLyBzdG9yZS1vcGVuIGVycm9yIGhhbmRsaW5nIHRvbykuXG4gIGNvbnN0IHBhdGNoT25lID0gdXNlQ2FsbGJhY2soYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzdG9yZSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb252ID0gYXdhaXQgc3RvcmUubG9hZChpZCk7XG4gICAgICAvLyBgbnVsbGAgPSBkZWxldGVkIGVsc2V3aGVyZSAob3IgY29ycnVwdCk6IHRoZSByb3cgZ29lcy5cbiAgICAgIHNldEl0ZW1zKChsKSA9PiAoY29udiA/IGFwcGx5Q29udmVyc2F0aW9uVXBkYXRlKGwsIG1ldGFPZihjb252KSkgOiBsLmZpbHRlcigoYykgPT4gYy5pZCAhPT0gaWQpKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBSZWFkIGZhaWx1cmUg4oCUIGtlZXAgdGhlIGxhc3QgZ29vZCBsaXN0LCB0aGUgc2FtZSByZXNvbHV0aW9uIGFzIHJlZnJlc2goKS5cbiAgICB9XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG9mZiA9IG9uUmVnaW9uTWVzc2FnZSgobSkgPT4ge1xuICAgICAgaWYgKGlzVXBkYXRlZChtLmRhdGEpKSB2b2lkIHBhdGNoT25lKG0uZGF0YS5pZCk7XG4gICAgICAvLyBUaGUgc3RhZ2UgbW91bnRlZCBhbmQgd2FudHMgdG8ga25vdyB3aGF0IGl0IHNob3VsZCBiZSBzaG93aW5nIChSMy0yNDMpLiBJdFxuICAgICAgLy8gbWF5IGhhdmUgbWlzc2VkIHRoZSBgc2VsZWN0LWNvbnZlcnNhdGlvbmAgZW50aXJlbHk6IG9uIG1vYmlsZSBpdCBkb2VzIG5vdFxuICAgICAgLy8gZXhpc3QgdW50aWwgdGhlIHJldmVhbCBwdXRzIGl0IG9uIHNjcmVlbiwgd2hpY2ggaGFwcGVucyBhZnRlciB0aGUgcG9zdC5cbiAgICAgIC8vIEFuc3dlcmluZyBoZXJlIGlzIHdoYXQgbWFrZXMgdGFwcGluZyBhbiBPTERFUiBjb252ZXJzYXRpb24gbGFuZCBvbiB0aGF0IG9uZVxuICAgICAgLy8gcmF0aGVyIHRoYW4gb24gdGhlIG5ld2VzdC5cbiAgICAgIGVsc2UgaWYgKGlzUmVxdWVzdFNlbGVjdGlvbihtLmRhdGEpICYmIHNlbGVjdGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgdm9pZCBwb3N0VG9SZWdpb24oU1RBR0VfUkVHSU9OLCBzZWxlY3RNZXNzYWdlKHNlbGVjdGVkUmVmLmN1cnJlbnQpKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3Qgb25Gb2N1cyA9ICgpID0+IHZvaWQgcmVmcmVzaCgpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNcIiwgb25Gb2N1cyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG9mZigpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJmb2N1c1wiLCBvbkZvY3VzKTtcbiAgICB9O1xuICB9LCBbcmVmcmVzaCwgcGF0Y2hPbmVdKTtcblxuICBjb25zdCBuZXdDb252ZXJzYXRpb24gPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBzdG9yZVJlZi5jdXJyZW50O1xuICAgIC8vIE5vIHN0b3JlIOKHkiB0aGUgYnV0dG9uIGNhbm5vdCB3b3JrLiBTYXkgd2h5IHJhdGhlciB0aGFuIGRvaW5nIG5vdGhpbmcuXG4gICAgaWYgKCFzdG9yZSkge1xuICAgICAgc2V0U3RvcmVFcnJvcigocHJldikgPT4gcHJldiA/PyBkZXNjcmliZVN0b3JlRmFpbHVyZShuZXcgRXJyb3IoXCJzZXR0aW5ncyB1bmF2YWlsYWJsZVwiKSkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgLy8gU3RhbXBlZCB3aXRoIHRoZSBsb2FkZWQgcmVwbyAoUjMtNDc1KSBzbyBpdCBzY29wZXMgY29ycmVjdGx5IGZyb20gYmlydGgg4oCUXG4gICAgICAvLyBsYWJlbCBBTkQgcHJvdmlkZXIgKFIzLTg0OCk6IHRoZSBsYWJlbCBhbG9uZSBjYW5ub3Qgc2F5IHdoaWNoIHByb3ZpZGVyXG4gICAgICAvLyB0aGUgcmVwbyBsaXZlcyB1bmRlci5cbiAgICAgIGNvbnN0IGNvbnYgPSBhd2FpdCBzdG9yZS5jcmVhdGUodW5kZWZpbmVkLCBjdXJyZW50UmVwbywgd29ya3NwYWNlPy5wcm92aWRlcik7XG4gICAgICBzZXRJdGVtcygobCkgPT4gW21ldGFPZihjb252KSwgLi4ubF0pO1xuICAgICAgc2V0U3RvcmVFcnJvcihudWxsKTtcbiAgICAgIG9wZW5Db252ZXJzYXRpb24oY29udi5pZCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgc2V0U3RvcmVFcnJvcihkZXNjcmliZVN0b3JlRmFpbHVyZShlKSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFIzLTg0OCDigJQgYSByZWZ1c2VkIHJlcG9zaXRvcnkgb3Blbiwgc2hvd24gT04gdGhlIHJvdyB0aGF0IGFza2VkIChuZXZlclxuICAvLyBzd2FsbG93ZWQpOiBrZXllZCBieSB0aGUgZ3JvdXAncyByZXBvIGxhYmVsLlxuICBjb25zdCBbb3BlbkVycm9yLCBzZXRPcGVuRXJyb3JdID0gdXNlU3RhdGU8eyByZXBvOiBzdHJpbmc7IGNvZGU6IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gT3BlbiBhbm90aGVyIHJlcG8ncyByb3cncyByZXBvc2l0b3J5IGluIGEgbmV3IHRhYiAoUjMtODQ4KTogdGhlXG4gIC8vIGhvc3QtbWVkaWF0ZWQgdmVyYiwgY2FsbGVkIERJUkVDVExZIGZyb20gdGhlIGNsaWNrIGhhbmRsZXIg4oCUIG5vIGBhd2FpdGBcbiAgLy8gYmVmb3JlIGl0LCBzbyB0aGUgaG9zdCBzdGlsbCBzZWVzIHRoZSBjbGljaydzIHRyYW5zaWVudCBhY3RpdmF0aW9uIChhXG4gIC8vIGRlZmVycmVkIGNhbGwgaXMgcmVmdXNlZCBgbm8tYWN0aXZhdGlvbmApLiBUaGUgYXBwIG5hbWVzIENPT1JESU5BVEVTIGFuZFxuICAvLyBub3RoaW5nIGVsc2U6IG5vIFVSTCwgbm8gcm91dGUgcHJlZml4IOKAlCB0aGUgaG9zdCBidWlsZHMgdGhlIGRlc3RpbmF0aW9uLlxuICAvLyBBIGdyb3VwIHRoYXQgY2Fubm90IG5hbWUgaXRzIGNvb3JkaW5hdGVzIChhIGxlZ2FjeSByZWNvcmQgd2l0aCBubyBwcm92aWRlclxuICAvLyBzdGFtcCwgYSBsYWJlbCB0aGF0IGlzIG5vdCBhIG5hbWVzcGFjZS9yZXBvc2l0b3J5IHBhaXIpIGlzIFJFRlVTRUQgb24gdGhlXG4gIC8vIHJvdyDigJQgbmV2ZXIgb3BlbmVkIHVuZGVyIGEgZ3Vlc3NlZCBwcm92aWRlciAodGhlIHJvdW5kLTEgcmV2aWV3OiB0aGUgU0RLJ3NcbiAgLy8gd29ya3NwYWNlIGNhbiBjYXJyeSBhIGBsb2NhbGAgcHJvdmlkZXI7IHRoZSBndWVzcyBpcyB0aGUgdGhpbmcgdGhlIGl0ZW1cbiAgLy8gc2FpZCBub3QgdG8gZG8pLlxuICBjb25zdCBvcGVuUmVwb1JvdyA9IChnOiBSZXBvR3JvdXApID0+IHtcbiAgICBjb25zdCBjb29yZHMgPSByZXBvQ29vcmRpbmF0ZXNPZihnKTtcbiAgICBpZiAoIWNvb3Jkcykge1xuICAgICAgc2V0T3BlbkVycm9yKHtcbiAgICAgICAgcmVwbzogZy5yZXBvLFxuICAgICAgICBjb2RlOiBnLnByb3ZpZGVyID09PSB1bmRlZmluZWQgPyBcIm5vIHByb3ZpZGVyIHN0YW1wIChhIGxlZ2FjeSBjb252ZXJzYXRpb24pXCIgOiBcImludmFsaWRcIixcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2b2lkIG9wZW5SZXBvc2l0b3J5KGNvb3JkcylcbiAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgLy8gQSBzdWNjZXNzIGNsZWFycyB0aGUgcm93J3MgZWFybGllciByZWZ1c2FsLCBpZiBhbnkg4oCUIGEgcmVmdXNhbCB0aGF0XG4gICAgICAgIC8vIG5vIGxvbmdlciBob2xkcyBtdXN0IG5vdCBzdGF5IG9uIHRoZSByb3cuXG4gICAgICAgIHNldE9wZW5FcnJvcigocHJldikgPT4gKHByZXY/LnJlcG8gPT09IGcucmVwbyA/IG51bGwgOiBwcmV2KSk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlOiB7IGNvZGU/OiBzdHJpbmcgfSB8IG51bGwpID0+IHtcbiAgICAgICAgc2V0T3BlbkVycm9yKHsgcmVwbzogZy5yZXBvLCBjb2RlOiBlPy5jb2RlID8/IFwidW5rbm93blwiIH0pO1xuICAgICAgfSk7XG4gIH07XG5cbiAgY29uc3QgcmVtb3ZlID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IHN0b3JlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzdG9yZSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzdG9yZS5yZW1vdmUoaWQpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIEEgZGVsZXRlIHRoYXQgZmFpbGVkIG11c3QgbGVhdmUgdGhlIHJvdyBpbiBwbGFjZSBhbmQgc2F5IHdoeSAoUi1JWC0zKTpcbiAgICAgIC8vIGRyb3BwaW5nIGl0IGFueXdheSB3b3VsZCBzaG93IGEgY2hhbmdlIHRoYXQgZGlkIG5vdCBoYXBwZW4uIFNhbWVcbiAgICAgIC8vIGZhaWx1cmUgc3VyZmFjZSBhcyBjcmVhdGUvc2F2ZSBhYm92ZS5cbiAgICAgIHNldFN0b3JlRXJyb3IoZGVzY3JpYmVTdG9yZUZhaWx1cmUoZSkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRJdGVtcygobCkgPT4gbC5maWx0ZXIoKGMpID0+IGMuaWQgIT09IGlkKSk7XG4gICAgaWYgKHNlbGVjdGVkID09PSBpZCkgc2V0U2VsZWN0ZWQobnVsbCk7IC8vIHRoZSBzY29wZWQgZWZmZWN0IHJlLXNlbGVjdHNcbiAgICBzZXRTdG9yZUVycm9yKG51bGwpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJjbC1oZFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC10aXRsZVwiPkNvbnZlcnNhdGlvbnM8L3NwYW4+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNsLW5ld1wiIG9uQ2xpY2s9eygpID0+IHZvaWQgbmV3Q29udmVyc2F0aW9uKCl9PlxuICAgICAgICAgIE5ldyBjb252ZXJzYXRpb25cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAge2N1cnJlbnRSZXBvICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2wtc2NvcGVcIiB0aXRsZT1cIkNvbnZlcnNhdGlvbnMgYXJlIHNjb3BlZCB0byB0aGUgcmVwb3NpdG9yeSBsb2FkZWQgaW4gdGhlIHdvcmtiZW5jaC5cIj5cbiAgICAgICAgICB7Y3VycmVudFJlcG99XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHtzdG9yZUVycm9yICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2wtZW1wdHkgY2wtZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAge3N0b3JlRXJyb3J9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHtyZWFkeSAmJiAhc3RvcmVFcnJvciAmJiBtaW5lLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImNsLWVtcHR5XCI+Tm8gY29udmVyc2F0aW9ucyBoZXJlIHlldC4gU3RhcnQgb25lIHdpdGgg4oCcTmV3IGNvbnZlcnNhdGlvbuKAnS48L3A+XG4gICAgICApfVxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiY2wtbGlzdFwiPlxuICAgICAgICB7bWluZS5tYXAoKGMpID0+IChcbiAgICAgICAgICA8bGkga2V5PXtjLmlkfSBjbGFzc05hbWU9e2BjbC1yb3cke2VmZmVjdGl2ZVNlbGVjdGVkID09PSBjLmlkID8gXCIgY2wtcm93LWFjdGl2ZVwiIDogXCJcIn1gfT5cbiAgICAgICAgICAgIHsvKiBSMy02MTIg4oCUIHRoZSBvcGVuIGFjdGlvbiBpcyBhIFJFQUwgYnV0dG9uIG92ZXIgdGhlIHJvdydzIG1haW5cbiAgICAgICAgICAgICAgICBjb250ZW50OiBhIHJvdy1sZXZlbCBidXR0b24gcm9sZSBjb250YWluaW5nIHRoaXMgY29udHJvbCBtYWRlIHRoZVxuICAgICAgICAgICAgICAgIHJvdydzIG5hbWUtZnJvbS1jb250ZW50IGFic29yYiBcIkRlbGV0ZSDigKZcIiBhbmQgZ2F2ZSB0aGUgdHdvXG4gICAgICAgICAgICAgICAgY29udHJvbHMgb25lIGFjdGl2YXRpb24gc3VyZmFjZSAoV0NBRyA0LjEuMiwgdHdpY2UpLiBTZWxlY3RlZFxuICAgICAgICAgICAgICAgIHN0YXRlIHRyYXZlbHMgdmlhIGFyaWEtcHJlc3NlZCBvbiB0aGUgb3BlbiBjb250cm9sLiAqL31cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNsLXJvdy1vcGVuXCJcbiAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtlZmZlY3RpdmVTZWxlY3RlZCA9PT0gYy5pZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbkNvbnZlcnNhdGlvbihjLmlkKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2wtcm93LXRpdGxlXCI+e2MudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1yb3ctdGltZVwiPntyZWxUaW1lKGMudXBkYXRlZEF0KX08L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNsLWRlbFwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BEZWxldGUgJHtjLnRpdGxlfWB9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVtb3ZlKGMuaWQpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDDl1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuXG4gICAgICB7LyogQ29udmVyc2F0aW9ucyBiZWxvbmdpbmcgdG8gT1RIRVIgcmVwb3NpdG9yaWVzIChSMy00NzUpOiB2aXNpYmxlIHNvIHRoZXkgYXJlXG4gICAgICAgICAgbmV2ZXIgbG9zdCwgYnV0IG5ldmVyIG1peGVkIGludG8gdGhlIGxpc3QgYWJvdmUuIEVhY2ggcm93IE9QRU5TIHRoYXRcbiAgICAgICAgICByZXBvc2l0b3J5IGluIGEgbmV3IHRhYiB0aHJvdWdoIHRoZSBob3N0LW1lZGlhdGVkIGBvcGVuUmVwb3NpdG9yeSgpYCB2ZXJiXG4gICAgICAgICAgKFIzLTQ3Niwgd2lyZWQgYnkgUjMtODQ4KTogYSB0YWIgb3BlbmVkIGZyb20gdGhpcyBzYW5kYm94ZWQgZnJhbWUgd291bGRcbiAgICAgICAgICBpbmhlcml0IHRoZSBzYW5kYm94IChvcGFxdWUgb3JpZ2luLCBtZWFzdXJlZCkgYW5kIHRoZSB3b3JrYmVuY2ggY2Fubm90XG4gICAgICAgICAgcnVuIGluIGl0LCBzbyB0aGUgYXBwIGFza3MgdGhlIGhvc3Qg4oCUIG5hbWluZyBjb29yZGluYXRlcywgbmV2ZXIgYSBVUkwuICovfVxuICAgICAge3JlYWR5ICYmIG90aGVycy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiY2wtb3RoZXJzXCI+XG4gICAgICAgICAgPHN1bW1hcnk+T3RoZXIgcmVwb3NpdG9yaWVzPC9zdW1tYXJ5PlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJjbC1vdGhlcnMtbGlzdFwiPlxuICAgICAgICAgICAge290aGVycy5tYXAoKGcpID0+IHtcbiAgICAgICAgICAgICAgLy8gUjMtNDc1IOKAlCB0aGUgY291bnQgbXVzdCBzYXkgd2hhdCBpdCBjb3VudHM6IGEgYmFyZSBkaWdpdCBoYXMgbm9cbiAgICAgICAgICAgICAgLy8gaG92ZXIgbGFiZWwgYW5kIGFubm91bmNlcyBhcyBhIGxvbmUgbnVtYmVyIHRvIGEgc2NyZWVuIHJlYWRlci5cbiAgICAgICAgICAgICAgLy8gVGhlIHJvdydzIG93biB0aXRsZSBzYXlzIHdoYXQgT1BFTklORyB0aGUgcmVwbyBkb2VzOyB0aGUgY291bnQnc1xuICAgICAgICAgICAgICAvLyBsYWJlbCBzYXlzIHdoYXQgdGhlIG51bWJlciBJUy4gKFRoZSBhY2Nlc3NpYmxlIHRleHQgaXNcbiAgICAgICAgICAgICAgLy8gdmlzdWFsbHktaGlkZGVuIHJlYWwgdGV4dCwgbm90IGFyaWEtbGFiZWwgb24gYSBnZW5lcmljIHNwYW4g4oCUXG4gICAgICAgICAgICAgIC8vIG5hbWluZyBpcyBwcm9oaWJpdGVkIG9uIHJvbGU9Z2VuZXJpYywgc28gYXJpYS1sYWJlbCB3b3VsZCBiZSBhXG4gICAgICAgICAgICAgIC8vIHBsYWNlYm8uKVxuICAgICAgICAgICAgICBjb25zdCBsYWJlbCA9IGNvdW50TGFiZWwoZyk7XG4gICAgICAgICAgICAgIGNvbnN0IHJlZnVzZWQgPSBvcGVuRXJyb3I/LnJlcG8gPT09IGcucmVwbyA/IG9wZW5FcnJvci5jb2RlIDogbnVsbDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtnLnJlcG99IGNsYXNzTmFtZT1cImNsLW90aGVycy1yb3dcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBSMy04NDgg4oCUIHRoZSBvcGVuIGNvbnRyb2wgaXMgYSByZWFsIGJ1dHRvbiAoa2V5Ym9hcmRcbiAgICAgICAgICAgICAgICAgICAgICByZWFjaGFibGUsIG5hbWVkIGZyb20gdGhlIHJvdydzIGNvbnRlbnQpLCBub3QgYW4gb25DbGljayBvblxuICAgICAgICAgICAgICAgICAgICAgIHRoZSBsaTsgdGhlIGNvdW50IGtlZXBzIFIzLTQ3NSdzIHZpc3VhbGx5LWhpZGRlbiBsYWJlbC4gKi99XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjbC1vdGhlcnMtb3BlblwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgT3BlbiAke2cucmVwb30gb24gaW1tZWRpYXRlbHkucnVuIHRvIHNlZSB0aGVzZSBjb252ZXJzYXRpb25zLmB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5SZXBvUm93KGcpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1vdGhlcnMtcmVwb1wiPntnLnJlcG99PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1vdGhlcnMtY291bnRcIiB0aXRsZT17bGFiZWx9PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNsLXZoXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj57Zy5jb3VudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAge3JlZnVzZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbC1vdGhlcnMtcmVmdXNlZFwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cmVmdXNlZH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kZXRhaWxzPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQWNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGtCQUFBLEdBQUFGLE9BQUE7QUFFQSxJQUFBRyxrQkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksbUJBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLGdCQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxXQUFBLEdBQUFOLE9BQUE7QUFDQUEsT0FBQTtBQUFnQyxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFBQSxJQUFBUSxFQUFBLEdBQUFDLFlBQUEsSUF0QmhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXQSxTQUFTQyxPQUFPQSxDQUFDQyxFQUFVLEVBQVU7RUFDbkMsTUFBTUMsQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUVELElBQUksQ0FBQ0UsS0FBSyxDQUFDLENBQUNDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsR0FBR04sRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDO0VBQzNELElBQUlDLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxVQUFVO0VBQzdCLE1BQU1NLENBQUMsR0FBR0wsSUFBSSxDQUFDRSxLQUFLLENBQUNILENBQUMsR0FBRyxFQUFFLENBQUM7RUFDNUIsSUFBSU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEdBQUdBLENBQUMsT0FBTztFQUM5QixNQUFNQyxDQUFDLEdBQUdOLElBQUksQ0FBQ0UsS0FBSyxDQUFDRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQzVCLElBQUlDLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxHQUFHQSxDQUFDLE9BQU87RUFDOUIsT0FBTyxHQUFHTixJQUFJLENBQUNFLEtBQUssQ0FBQ0ksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPO0FBQ3JDOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLFVBQVVBLENBQUNDLENBQVksRUFBVTtFQUN4QyxPQUFPLEdBQUdBLENBQUMsQ0FBQ0MsS0FBSyxJQUFJRCxDQUFDLENBQUNDLEtBQUssS0FBSyxDQUFDLEdBQUcsY0FBYyxHQUFHLGVBQWUsT0FBT0QsQ0FBQyxDQUFDRSxJQUFJLEVBQUU7QUFDdEY7QUFFZSxTQUFTQyxnQkFBZ0JBLENBQUEsRUFBRztFQUFBaEIsRUFBQTtFQUN6QyxNQUFNaUIsUUFBUSxHQUFHLElBQUFDLGFBQU0sRUFBMkIsSUFBSSxDQUFDO0VBQ3ZELE1BQU0sQ0FBQ0MsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQXFCLEVBQUUsQ0FBQztFQUMxRCxNQUFNLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDN0QsTUFBTSxDQUFDRyxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDekM7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDSyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFOLGVBQVEsRUFBZ0IsSUFBSSxDQUFDOztFQUVqRTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1PLFNBQVMsR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDaEMsTUFBTUMsV0FBVyxHQUFHRixTQUFTLEVBQUVHLEtBQUs7O0VBRXBDO0VBQ0E7RUFDQSxNQUFNO0lBQUVDLElBQUk7SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMscUNBQWtCLEVBQUNoQixLQUFLLEVBQUVXLFdBQVcsQ0FBQyxFQUFFLENBQUNYLEtBQUssRUFBRVcsV0FBVyxDQUFDLENBQUM7O0VBRXBHO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1NLGlCQUFpQixHQUFHLElBQUFGLGNBQU8sRUFBQyxNQUFNO0lBQ3RDLElBQUlaLFFBQVEsSUFBSVUsSUFBSSxDQUFDSyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUtqQixRQUFRLENBQUMsRUFBRSxPQUFPQSxRQUFRO0lBQ3BFLE9BQU9VLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRU8sRUFBRSxJQUFJLElBQUk7RUFDNUIsQ0FBQyxFQUFFLENBQUNqQixRQUFRLEVBQUVVLElBQUksQ0FBQyxDQUFDOztFQUVwQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUFRLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ0osaUJBQWlCLEVBQUU7SUFDeEIsS0FBSyxJQUFBSyxpQkFBWSxFQUFDQyw2QkFBWSxFQUFFLElBQUFDLDhCQUFhLEVBQUNQLGlCQUFpQixDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkYsQ0FBQyxFQUFFLENBQUNSLGlCQUFpQixDQUFDLENBQUM7O0VBRXZCO0VBQ0E7RUFDQTtFQUNBLE1BQU1TLFdBQVcsR0FBRyxJQUFBM0IsYUFBTSxFQUFnQixJQUFJLENBQUM7RUFDL0MsSUFBQXNCLGdCQUFTLEVBQUMsTUFBTTtJQUNkSyxXQUFXLENBQUNDLE9BQU8sR0FBR1YsaUJBQWlCO0VBQ3pDLENBQUMsRUFBRSxDQUFDQSxpQkFBaUIsQ0FBQyxDQUFDOztFQUV2QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNVyxnQkFBZ0IsR0FBRyxJQUFBQyxrQkFBVyxFQUFFVCxFQUFVLElBQUs7SUFDbkRoQixXQUFXLENBQUNnQixFQUFFLENBQUM7SUFDZjtJQUNBO0lBQ0E7SUFDQSxLQUFLLElBQUFFLGlCQUFZLEVBQUNDLDZCQUFZLEVBQUUsSUFBQUMsOEJBQWEsRUFBQ0osRUFBRSxDQUFDLENBQUMsQ0FBQ0ssS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDbEUsS0FBSyxJQUFBSyxpQkFBWSxFQUFDUCw2QkFBWSxDQUFDLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ2pELENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNTSxPQUFPLEdBQUcsSUFBQUYsa0JBQVcsRUFBQyxZQUFZO0lBQ3RDLE1BQU1HLEtBQUssR0FBR2xDLFFBQVEsQ0FBQzZCLE9BQU87SUFDOUIsSUFBSSxDQUFDSyxLQUFLLEVBQUU7SUFDWixJQUFJO01BQ0YvQixRQUFRLENBQUMsTUFBTStCLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5QixDQUFDLENBQUMsTUFBTTtNQUNOO0lBQUE7RUFFSixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQSxJQUFBWixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJYSxJQUFJLEdBQUcsSUFBSTtJQUNmLEtBQUssQ0FBQyxZQUFZO01BQ2hCLElBQUk7UUFDRixNQUFNRixLQUFLLEdBQUcsTUFBTSxJQUFBRyx3Q0FBcUIsRUFBQyxDQUFDO1FBQzNDLElBQUksQ0FBQ0QsSUFBSSxFQUFFO1FBQ1hwQyxRQUFRLENBQUM2QixPQUFPLEdBQUdLLEtBQUs7UUFDeEIsTUFBTUMsSUFBSSxHQUFHLE1BQU1ELEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDQyxJQUFJLEVBQUU7UUFDWGpDLFFBQVEsQ0FBQ2dDLElBQUksQ0FBQztRQUNkekIsYUFBYSxDQUFDLElBQUksQ0FBQztNQUNyQixDQUFDLENBQUMsT0FBTzRCLENBQUMsRUFBRTtRQUNWLElBQUlGLElBQUksRUFBRTFCLGFBQWEsQ0FBQyxJQUFBNkIsZ0NBQW9CLEVBQUNELENBQUMsQ0FBQyxDQUFDO01BQ2xELENBQUMsU0FBUztRQUNSLElBQUlGLElBQUksRUFBRTVCLFFBQVEsQ0FBQyxJQUFJLENBQUM7TUFDMUI7SUFDRixDQUFDLEVBQUUsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYNEIsSUFBSSxHQUFHLEtBQUs7SUFDZCxDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNSSxRQUFRLEdBQUcsSUFBQVQsa0JBQVcsRUFBQyxNQUFPVCxFQUFVLElBQUs7SUFDakQsTUFBTVksS0FBSyxHQUFHbEMsUUFBUSxDQUFDNkIsT0FBTztJQUM5QixJQUFJLENBQUNLLEtBQUssRUFBRTtJQUNaLElBQUk7TUFDRixNQUFNTyxJQUFJLEdBQUcsTUFBTVAsS0FBSyxDQUFDUSxJQUFJLENBQUNwQixFQUFFLENBQUM7TUFDakM7TUFDQW5CLFFBQVEsQ0FBRXdDLENBQUMsSUFBTUYsSUFBSSxHQUFHLElBQUFHLDJDQUF1QixFQUFDRCxDQUFDLEVBQUUsSUFBQUUseUJBQU0sRUFBQ0osSUFBSSxDQUFDLENBQUMsR0FBR0UsQ0FBQyxDQUFDRyxNQUFNLENBQUV6QixDQUFDLElBQUtBLENBQUMsQ0FBQ0MsRUFBRSxLQUFLQSxFQUFFLENBQUUsQ0FBQztJQUNuRyxDQUFDLENBQUMsTUFBTTtNQUNOO0lBQUE7RUFFSixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTXdCLEdBQUcsR0FBRyxJQUFBQyxvQkFBZSxFQUFFdkQsQ0FBQyxJQUFLO01BQ2pDLElBQUksSUFBQXdELDBCQUFTLEVBQUN4RCxDQUFDLENBQUN5RCxJQUFJLENBQUMsRUFBRSxLQUFLVixRQUFRLENBQUMvQyxDQUFDLENBQUN5RCxJQUFJLENBQUM1QixFQUFFLENBQUM7TUFDL0M7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUFBLEtBQ0ssSUFBSSxJQUFBNkIsbUNBQWtCLEVBQUMxRCxDQUFDLENBQUN5RCxJQUFJLENBQUMsSUFBSXRCLFdBQVcsQ0FBQ0MsT0FBTyxFQUFFO1FBQzFELEtBQUssSUFBQUwsaUJBQVksRUFBQ0MsNkJBQVksRUFBRSxJQUFBQyw4QkFBYSxFQUFDRSxXQUFXLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUNGLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQ3JGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsTUFBTXlCLE9BQU8sR0FBR0EsQ0FBQSxLQUFNLEtBQUtuQixPQUFPLENBQUMsQ0FBQztJQUNwQ29CLE1BQU0sQ0FBQ0MsZ0JBQWdCLENBQUMsT0FBTyxFQUFFRixPQUFPLENBQUM7SUFDekMsT0FBTyxNQUFNO01BQ1hMLEdBQUcsQ0FBQyxDQUFDO01BQ0xNLE1BQU0sQ0FBQ0UsbUJBQW1CLENBQUMsT0FBTyxFQUFFSCxPQUFPLENBQUM7SUFDOUMsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDbkIsT0FBTyxFQUFFTyxRQUFRLENBQUMsQ0FBQztFQUV2QixNQUFNZ0IsZUFBZSxHQUFHLE1BQUFBLENBQUEsS0FBWTtJQUNsQyxNQUFNdEIsS0FBSyxHQUFHbEMsUUFBUSxDQUFDNkIsT0FBTztJQUM5QjtJQUNBLElBQUksQ0FBQ0ssS0FBSyxFQUFFO01BQ1Z4QixhQUFhLENBQUUrQyxJQUFJLElBQUtBLElBQUksSUFBSSxJQUFBbEIsZ0NBQW9CLEVBQUMsSUFBSW1CLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7TUFDeEY7SUFDRjtJQUNBLElBQUk7TUFDRjtNQUNBO01BQ0E7TUFDQSxNQUFNakIsSUFBSSxHQUFHLE1BQU1QLEtBQUssQ0FBQ3lCLE1BQU0sQ0FBQ0MsU0FBUyxFQUFFL0MsV0FBVyxFQUFFRixTQUFTLEVBQUVrRCxRQUFRLENBQUM7TUFDNUUxRCxRQUFRLENBQUV3QyxDQUFDLElBQUssQ0FBQyxJQUFBRSx5QkFBTSxFQUFDSixJQUFJLENBQUMsRUFBRSxHQUFHRSxDQUFDLENBQUMsQ0FBQztNQUNyQ2pDLGFBQWEsQ0FBQyxJQUFJLENBQUM7TUFDbkJvQixnQkFBZ0IsQ0FBQ1csSUFBSSxDQUFDbkIsRUFBRSxDQUFDO0lBQzNCLENBQUMsQ0FBQyxPQUFPZ0IsQ0FBQyxFQUFFO01BQ1Y1QixhQUFhLENBQUMsSUFBQTZCLGdDQUFvQixFQUFDRCxDQUFDLENBQUMsQ0FBQztJQUN4QztFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBLE1BQU0sQ0FBQ3dCLFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUcsSUFBQTNELGVBQVEsRUFBd0MsSUFBSSxDQUFDOztFQUV2RjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU00RCxXQUFXLEdBQUlwRSxDQUFZLElBQUs7SUFDcEMsTUFBTXFFLE1BQU0sR0FBRyxJQUFBQyxvQ0FBaUIsRUFBQ3RFLENBQUMsQ0FBQztJQUNuQyxJQUFJLENBQUNxRSxNQUFNLEVBQUU7TUFDWEYsWUFBWSxDQUFDO1FBQ1hqRSxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSTtRQUNacUUsSUFBSSxFQUFFdkUsQ0FBQyxDQUFDaUUsUUFBUSxLQUFLRCxTQUFTLEdBQUcsMkNBQTJDLEdBQUc7TUFDakYsQ0FBQyxDQUFDO01BQ0Y7SUFDRjtJQUNBLEtBQUssSUFBQVEsbUJBQWMsRUFBQ0gsTUFBTSxDQUFDLENBQ3hCSSxJQUFJLENBQUMsTUFBTTtNQUNWO01BQ0E7TUFDQU4sWUFBWSxDQUFFTixJQUFJLElBQU1BLElBQUksRUFBRTNELElBQUksS0FBS0YsQ0FBQyxDQUFDRSxJQUFJLEdBQUcsSUFBSSxHQUFHMkQsSUFBSyxDQUFDO0lBQy9ELENBQUMsQ0FBQyxDQUNEOUIsS0FBSyxDQUFFVyxDQUEyQixJQUFLO01BQ3RDeUIsWUFBWSxDQUFDO1FBQUVqRSxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSTtRQUFFcUUsSUFBSSxFQUFFN0IsQ0FBQyxFQUFFNkIsSUFBSSxJQUFJO01BQVUsQ0FBQyxDQUFDO0lBQzVELENBQUMsQ0FBQztFQUNOLENBQUM7RUFFRCxNQUFNRyxNQUFNLEdBQUcsTUFBT2hELEVBQVUsSUFBSztJQUNuQyxNQUFNWSxLQUFLLEdBQUdsQyxRQUFRLENBQUM2QixPQUFPO0lBQzlCLElBQUksQ0FBQ0ssS0FBSyxFQUFFO0lBQ1osSUFBSTtNQUNGLE1BQU1BLEtBQUssQ0FBQ29DLE1BQU0sQ0FBQ2hELEVBQUUsQ0FBQztJQUN4QixDQUFDLENBQUMsT0FBT2dCLENBQUMsRUFBRTtNQUNWO01BQ0E7TUFDQTtNQUNBNUIsYUFBYSxDQUFDLElBQUE2QixnQ0FBb0IsRUFBQ0QsQ0FBQyxDQUFDLENBQUM7TUFDdEM7SUFDRjtJQUNBbkMsUUFBUSxDQUFFd0MsQ0FBQyxJQUFLQSxDQUFDLENBQUNHLE1BQU0sQ0FBRXpCLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUtBLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLElBQUlqQixRQUFRLEtBQUtpQixFQUFFLEVBQUVoQixXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUN4Q0ksYUFBYSxDQUFDLElBQUksQ0FBQztFQUNyQixDQUFDO0VBRUQsb0JBQ0UsSUFBQTVCLFdBQUEsQ0FBQXlGLElBQUE7SUFBS0MsU0FBUyxFQUFDLElBQUk7SUFBQUMsUUFBQSxnQkFDakIsSUFBQTNGLFdBQUEsQ0FBQXlGLElBQUE7TUFBUUMsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxnQkFDdkIsSUFBQTNGLFdBQUEsQ0FBQTRGLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQWEsQ0FBTSxDQUFDLGVBQy9DLElBQUEzRixXQUFBLENBQUE0RixHQUFBO1FBQVFDLElBQUksRUFBQyxRQUFRO1FBQUNILFNBQVMsRUFBQyxRQUFRO1FBQUNJLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLEtBQUtwQixlQUFlLENBQUMsQ0FBRTtRQUFBaUIsUUFBQSxFQUFDO01BRWhGLENBQVEsQ0FBQztJQUFBLENBQ0gsQ0FBQyxFQUVSNUQsV0FBVyxpQkFDVixJQUFBL0IsV0FBQSxDQUFBNEYsR0FBQTtNQUFHRixTQUFTLEVBQUMsVUFBVTtNQUFDSyxLQUFLLEVBQUMscUVBQXFFO01BQUFKLFFBQUEsRUFDaEc1RDtJQUFXLENBQ1gsQ0FDSixFQUVBSixVQUFVLGlCQUNULElBQUEzQixXQUFBLENBQUE0RixHQUFBO01BQUdGLFNBQVMsRUFBQyxtQkFBbUI7TUFBQ00sSUFBSSxFQUFDLFFBQVE7TUFBQUwsUUFBQSxFQUMzQ2hFO0lBQVUsQ0FDVixDQUNKLEVBRUFGLEtBQUssSUFBSSxDQUFDRSxVQUFVLElBQUlNLElBQUksQ0FBQ2dFLE1BQU0sS0FBSyxDQUFDLGlCQUN4QyxJQUFBakcsV0FBQSxDQUFBNEYsR0FBQTtNQUFHRixTQUFTLEVBQUMsVUFBVTtNQUFBQyxRQUFBLEVBQUM7SUFBNkQsQ0FBRyxDQUN6RixlQUVELElBQUEzRixXQUFBLENBQUE0RixHQUFBO01BQUlGLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsRUFDcEIxRCxJQUFJLENBQUNpRSxHQUFHLENBQUUzRCxDQUFDLGlCQUNWLElBQUF2QyxXQUFBLENBQUF5RixJQUFBO1FBQWVDLFNBQVMsRUFBRSxTQUFTckQsaUJBQWlCLEtBQUtFLENBQUMsQ0FBQ0MsRUFBRSxHQUFHLGdCQUFnQixHQUFHLEVBQUUsRUFBRztRQUFBbUQsUUFBQSxnQkFNdEYsSUFBQTNGLFdBQUEsQ0FBQXlGLElBQUE7VUFDRUksSUFBSSxFQUFDLFFBQVE7VUFDYkgsU0FBUyxFQUFDLGFBQWE7VUFDdkIsZ0JBQWNyRCxpQkFBaUIsS0FBS0UsQ0FBQyxDQUFDQyxFQUFHO1VBQ3pDc0QsT0FBTyxFQUFFQSxDQUFBLEtBQU05QyxnQkFBZ0IsQ0FBQ1QsQ0FBQyxDQUFDQyxFQUFFLENBQUU7VUFBQW1ELFFBQUEsZ0JBRXRDLElBQUEzRixXQUFBLENBQUE0RixHQUFBO1lBQU1GLFNBQVMsRUFBQyxjQUFjO1lBQUFDLFFBQUEsRUFBRXBELENBQUMsQ0FBQ3dEO1VBQUssQ0FBTyxDQUFDLGVBQy9DLElBQUEvRixXQUFBLENBQUE0RixHQUFBO1lBQU1GLFNBQVMsRUFBQyxhQUFhO1lBQUFDLFFBQUEsRUFBRXhGLE9BQU8sQ0FBQ29DLENBQUMsQ0FBQzRELFNBQVM7VUFBQyxDQUFPLENBQUM7UUFBQSxDQUNyRCxDQUFDLGVBQ1QsSUFBQW5HLFdBQUEsQ0FBQTRGLEdBQUE7VUFDRUMsSUFBSSxFQUFDLFFBQVE7VUFDYkgsU0FBUyxFQUFDLFFBQVE7VUFDbEIsY0FBWSxVQUFVbkQsQ0FBQyxDQUFDd0QsS0FBSyxFQUFHO1VBQ2hDRCxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLTixNQUFNLENBQUNqRCxDQUFDLENBQUNDLEVBQUUsQ0FBRTtVQUFBbUQsUUFBQSxFQUNsQztRQUVELENBQVEsQ0FBQztNQUFBLEdBdEJGcEQsQ0FBQyxDQUFDQyxFQXVCUCxDQUNMO0lBQUMsQ0FDQSxDQUFDLEVBUUpmLEtBQUssSUFBSVMsTUFBTSxDQUFDK0QsTUFBTSxHQUFHLENBQUMsaUJBQ3pCLElBQUFqRyxXQUFBLENBQUF5RixJQUFBO01BQVNDLFNBQVMsRUFBQyxXQUFXO01BQUFDLFFBQUEsZ0JBQzVCLElBQUEzRixXQUFBLENBQUE0RixHQUFBO1FBQUFELFFBQUEsRUFBUztNQUFrQixDQUFTLENBQUMsZUFDckMsSUFBQTNGLFdBQUEsQ0FBQTRGLEdBQUE7UUFBSUYsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLEVBQzNCekQsTUFBTSxDQUFDZ0UsR0FBRyxDQUFFcEYsQ0FBQyxJQUFLO1VBQ2pCO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsTUFBTWtCLEtBQUssR0FBR25CLFVBQVUsQ0FBQ0MsQ0FBQyxDQUFDO1VBQzNCLE1BQU1zRixPQUFPLEdBQUdwQixTQUFTLEVBQUVoRSxJQUFJLEtBQUtGLENBQUMsQ0FBQ0UsSUFBSSxHQUFHZ0UsU0FBUyxDQUFDSyxJQUFJLEdBQUcsSUFBSTtVQUNsRSxvQkFDRSxJQUFBckYsV0FBQSxDQUFBeUYsSUFBQTtZQUFpQkMsU0FBUyxFQUFDLGVBQWU7WUFBQUMsUUFBQSxnQkFJeEMsSUFBQTNGLFdBQUEsQ0FBQXlGLElBQUE7Y0FDRUksSUFBSSxFQUFDLFFBQVE7Y0FDYkgsU0FBUyxFQUFDLGdCQUFnQjtjQUMxQkssS0FBSyxFQUFFLFFBQVFqRixDQUFDLENBQUNFLElBQUksaURBQWtEO2NBQ3ZFOEUsT0FBTyxFQUFFQSxDQUFBLEtBQU1aLFdBQVcsQ0FBQ3BFLENBQUMsQ0FBRTtjQUFBNkUsUUFBQSxnQkFFOUIsSUFBQTNGLFdBQUEsQ0FBQTRGLEdBQUE7Z0JBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7Z0JBQUFDLFFBQUEsRUFBRTdFLENBQUMsQ0FBQ0U7Y0FBSSxDQUFPLENBQUMsZUFDaEQsSUFBQWhCLFdBQUEsQ0FBQXlGLElBQUE7Z0JBQU1DLFNBQVMsRUFBQyxpQkFBaUI7Z0JBQUNLLEtBQUssRUFBRS9ELEtBQU07Z0JBQUEyRCxRQUFBLGdCQUM3QyxJQUFBM0YsV0FBQSxDQUFBNEYsR0FBQTtrQkFBTUYsU0FBUyxFQUFDLE9BQU87a0JBQUFDLFFBQUEsRUFBRTNEO2dCQUFLLENBQU8sQ0FBQyxlQUN0QyxJQUFBaEMsV0FBQSxDQUFBNEYsR0FBQTtrQkFBTSxlQUFZLE1BQU07a0JBQUFELFFBQUEsRUFBRTdFLENBQUMsQ0FBQ0M7Z0JBQUssQ0FBTyxDQUFDO2NBQUEsQ0FDckMsQ0FBQztZQUFBLENBQ0QsQ0FBQyxFQUNScUYsT0FBTyxpQkFDTixJQUFBcEcsV0FBQSxDQUFBNEYsR0FBQTtjQUFNRixTQUFTLEVBQUMsbUJBQW1CO2NBQUNNLElBQUksRUFBQyxRQUFRO2NBQUFMLFFBQUEsRUFDOUNTO1lBQU8sQ0FDSixDQUNQO1VBQUEsR0FwQk10RixDQUFDLENBQUNFLElBcUJQLENBQUM7UUFFVCxDQUFDO01BQUMsQ0FDQSxDQUFDO0lBQUEsQ0FDRSxDQUNWO0VBQUEsQ0FDRSxDQUFDO0FBRVY7QUFBQ2YsRUFBQSxDQTdUdUJnQixnQkFBZ0I7RUFBQSxRQWNwQmEsaUJBQVk7QUFBQTtBQUFBdUUsRUFBQSxHQWRScEYsZ0JBQWdCO0FBQUEsSUFBQW9GLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}