var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("@testing-library/react");
var _ConversationList = _interopRequireDefault(require("./ConversationList"));
var _conversationIpc = require("../lib/conversationIpc");
var _sdk = require("@immediately-run/sdk");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment happy-dom
// R3-612 — the first component tests in this repo (the item's harness: happy-dom +
// @testing-library/react, the SDK barrel mocked exactly as the lib tests mock it).
//
// What is under test is the ACCESSIBLE shape, not the pixels: the row is a plain
// <li> whose open control is a real button (WCAG 4.1.2 — two controls, two names),
// delete removes through the store, and a `conversation-updated` message patches
// the ONE row it names without re-listing the store (R-IX-4). Rows come from the
// REAL fs-injected store over MemFs — never a hand-typed array (R2).
_vitest.vi.mock("@immediately-run/sdk", () => ({
  postToRegion: _vitest.vi.fn(async () => {}),
  revealRegion: _vitest.vi.fn(async () => {}),
  // R3-848: the host-mediated verb, spied from the click handler.
  openRepository: _vitest.vi.fn(async () => {}),
  useWorkspace: _vitest.vi.fn(() => null),
  onRegionMessage: _vitest.vi.fn(listener => {
    regionListeners.push(listener);
    return () => {
      const i = regionListeners.indexOf(listener);
      if (i >= 0) regionListeners.splice(i, 1);
    };
  })
}));

// The store is REAL (fs-injected core over MemFs); only its mount resolution is
// replaced, so list/load/save/remove run the shipped code. One seeded row per
// store, created through the store itself — the list test fixture is store output,
// not a literal. (The vi.mock factory below is hoisted, so it reaches the impl
// through this holder rather than a top-level const.)
const storeHolder = _vitest.vi.hoisted(() => ({
  make: null
}));
_vitest.vi.mock("../lib/conversationStore", async importOriginal => {
  const actual = await importOriginal();
  return {
    ...actual,
    openConversationStore: () => storeHolder.make()
  };
});
let lastStore = null;

/** The one seeded-store builder: a REAL fs-injected store over MemFs, seeded
 *  through the store itself, then spy-wrapped. Both describes ride it. */
const makeSeededStore = async seed => {
  const {
    createConversationStore
  } = await Promise.resolve().then(() => _interopRequireWildcard(require("../lib/conversationStore")));
  const {
    MemFs
  } = await Promise.resolve().then(() => _interopRequireWildcard(require("../lib/testing/memStoreFs")));
  const base = createConversationStore({
    recordRoot: "/settings",
    fs: new MemFs(),
    tabId: "tab-conversation-list"
  });
  await seed(base);
  const wrapped = {
    ...base,
    list: _vitest.vi.fn(base.list.bind(base)),
    load: _vitest.vi.fn(base.load.bind(base)),
    save: _vitest.vi.fn(base.save.bind(base)),
    remove: _vitest.vi.fn(base.remove.bind(base))
  };
  lastStore = wrapped;
  return wrapped;
};
const makeStore = () => makeSeededStore(async s => {
  await s.create("notes");
});
const regionListeners = [];
(0, _vitest.beforeEach)(() => {
  regionListeners.length = 0;
  lastStore = null;
  _vitest.vi.mocked(_sdk.openRepository).mockClear();
  _vitest.vi.mocked(_sdk.openRepository).mockImplementation(async () => {});
  // Restore the default factory — a describe that re-seeds `storeHolder.make`
  // must never leak its fixture into describes that run after it.
  storeHolder.make = makeStore;
});
_s((0, _vitest.afterEach)(_s(() => {
  _s();
  (0, _react.cleanup)();
  _vitest.vi.useRealTimers();
}, "SorhAKJ5LalUUOIFAWOBDEomlvs=", false, function () {
  return [_vitest.vi.useRealTimers];
})), "SorhAKJ5LalUUOIFAWOBDEomlvs=", false, function () {
  return [_vitest.vi.useRealTimers];
});
const postFromStage = data => {
  for (const l of [...regionListeners]) l({
    from: _conversationIpc.STAGE_REGION,
    data
  });
};
const renderWithNotesRow = async () => {
  (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationList.default, {}));
  await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("notes")).toBeTruthy());
};
(0, _vitest.describe)("ConversationList — the row is two controls, two names (R3-612 / WCAG 4.1.2)", () => {
  (0, _vitest.it)("the open control is a real button named by its content, and never absorbs the delete label", async () => {
    await renderWithNotesRow();

    // The open control's accessible name is its content ("notes just now") — the
    // delete label ("Delete notes") must not be absorbed into it. (A regex /notes/
    // here would match BOTH controls — the delete row's name legitimately contains
    // the title; the defect under test is the OPEN control carrying "Delete …".)
    const open = _react.screen.getByRole("button", {
      name: "notes just now"
    });
    (0, _vitest.expect)(open.getAttribute("aria-label")).toBeNull();
    (0, _vitest.expect)(open.textContent).not.toContain("Delete");
    (0, _vitest.expect)(_react.screen.getByRole("button", {
      name: "Delete notes"
    })).not.toBe(open);

    // The <li> itself is not interactive: no button role, no tabindex.
    const row = open.closest("li");
    (0, _vitest.expect)(row.getAttribute("role")).toBeNull();
    (0, _vitest.expect)(row.getAttribute("tabindex")).toBeNull();
  });
  (0, _vitest.it)("delete removes through the store and the row goes", async () => {
    await renderWithNotesRow();
    const id = (await lastStore.list())[0].id;
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Delete notes"
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.queryByText("notes")).toBeNull());
    await (0, _react.waitFor)(() => (0, _vitest.expect)(lastStore.remove).toHaveBeenCalledWith(id));
  });
  (0, _vitest.it)("a conversation-updated message patches the ONE row it names and never calls list() again (R-IX-4)", async () => {
    await renderWithNotesRow();

    // The stage saved the conversation (retitled) and posted the id. Apply the
    // save through the SAME real store, then replay the message the stage posts.
    const id = (await lastStore.list())[0].id;
    const saved = await lastStore.load(id);
    (0, _vitest.expect)(saved).toBeTruthy();
    await lastStore.save({
      ...saved,
      title: "notes, renamed"
    });
    const listCalls = lastStore.list.mock.calls.length;
    postFromStage({
      type: "conversation-updated",
      id
    });
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("notes, renamed")).toBeTruthy());
    (0, _vitest.expect)(lastStore.list.mock.calls.length).toBe(listCalls);
    (0, _vitest.expect)(lastStore.load).toHaveBeenCalledWith(id);
  });
  (0, _vitest.it)("the message for a row deleted elsewhere removes that row", async () => {
    await renderWithNotesRow();
    const id = (await lastStore.list())[0].id;
    await lastStore.remove(id);
    postFromStage({
      type: "conversation-updated",
      id
    });
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.queryByText("notes")).toBeNull());
  });
});
(0, _vitest.describe)("ConversationList — the other-repositories count names what it counts (R3-475)", () => {
  // Two stamped repos ride the REAL store (one with two members, one with one), so
  // the group counts are the producer's own arithmetic; the workspace mock stays
  // null, so every stamped repo groups under "other repositories" by rule. The
  // factory swap is restored by the shared beforeEach, which resets it to makeStore.
  const seedWithOthers = () => {
    storeHolder.make = () => makeSeededStore(async s => {
      await s.create("notes");
      await s.create("recipe plan", "other/repo");
      await s.create("recipe followup", "other/repo");
      await s.create("solo elsewhere", "third/repo");
    });
  };
  (0, _vitest.it)("the count carries a hover label and an accessible text — singular and plural", async () => {
    seedWithOthers();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationList.default, {}));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("Other repositories")).toBeTruthy());

    // The accessible form is REAL (visually hidden) text; the visible digit is
    // aria-hidden so the number is never announced as a bare "2".
    const pluralLabel = _react.screen.getByText("2 conversations in other/repo");
    (0, _vitest.expect)(pluralLabel.classList.contains("cl-vh")).toBe(true);
    const pluralDigit = _react.screen.getByText("2");
    (0, _vitest.expect)(pluralDigit.getAttribute("aria-hidden")).toBe("true");
    (0, _vitest.expect)(pluralDigit.parentElement.getAttribute("title")).toBe("2 conversations in other/repo");
    const singularLabel = _react.screen.getByText("1 conversation in third/repo");
    (0, _vitest.expect)(singularLabel.classList.contains("cl-vh")).toBe(true);
    const singularDigit = _react.screen.getByText("1");
    (0, _vitest.expect)(singularDigit.getAttribute("aria-hidden")).toBe("true");
    (0, _vitest.expect)(singularDigit.parentElement.getAttribute("title")).toBe("1 conversation in third/repo");
  });
});

// ── R3-848 — the other-repositories rows open their repository ───────────────
// Each row is a real button that calls the host-mediated openRepository() with
// the row's coordinates, synchronously from the click handler (an await before
// the call would lose the host's transient activation), and a refusal lands
// its code ON the row. Rows come from the REAL fs-injected store.
(0, _vitest.describe)("ConversationList — other-repositories rows open the repository (R3-848)", () => {
  const makeOtherRepoStore = () => makeSeededStore(async s => {
    await s.create("mine", "owner/current");
    // Stamped for ANOTHER repo, with its provider stamp.
    await s.create("elsewhere", "other/repo", "github");
  });
  const renderWithOthers = async () => {
    storeHolder.make = makeOtherRepoStore;
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationList.default, {}));
    // No workspace mocked ⇒ every stamped conversation groups under "other"
    // — which is exactly this fixture's shape. The rows render the GROUP's
    // repo label, never the conversation titles.
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("other/repo")).toBeTruthy());
    // Open the <details> so the rows render.
    _react.fireEvent.click(_react.screen.getByText("Other repositories"));
  };
  (0, _vitest.it)("a row is a real button whose click calls openRepository once, with the row's coordinates", async () => {
    await renderWithOthers();
    const row = _react.screen.getByRole("button", {
      name: /other\/repo/
    });
    _react.fireEvent.click(row);
    (0, _vitest.expect)(_sdk.openRepository).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(_sdk.openRepository).toHaveBeenCalledWith({
      provider: "github",
      namespace: "other",
      repository: "repo"
    });
  });
  (0, _vitest.it)("the call happens synchronously inside the handler — no await can slip in front of it", async () => {
    await renderWithOthers();
    // A pending promise: the handler cannot have awaited anything before the
    // call and still see the host's transient activation (an await before it is
    // the no-activation refusal this guard exists to prevent).
    let settle;
    _vitest.vi.mocked(_sdk.openRepository).mockImplementation(() => new Promise(res => {
      settle = res;
    }));
    const row = _react.screen.getByRole("button", {
      name: /other\/repo/
    });
    _react.fireEvent.click(row);
    // Called IMMEDIATELY after the dispatch — before anything asynchronous ran.
    (0, _vitest.expect)(_sdk.openRepository).toHaveBeenCalledTimes(1);
    settle();
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.queryByRole("status")).toBeNull());
  });
  (0, _vitest.it)("a refusal lands its code on the row that asked", async () => {
    await renderWithOthers();
    _vitest.vi.mocked(_sdk.openRepository).mockRejectedValueOnce(Object.assign(new Error("repository open refused"), {
      code: "forbidden"
    }));
    const row = _react.screen.getByRole("button", {
      name: /other\/repo/
    });
    _react.fireEvent.click(row);
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByRole("status").textContent).toBe("forbidden"));
  });
  (0, _vitest.it)("a legacy group (no provider stamp) is REFUSED on the row, never opened under a guessed provider", async () => {
    // Round-1 review: the SDK's workspace can carry a `local` provider, so a
    // github default is the guess the item said not to make. The row refuses.
    storeHolder.make = () => makeSeededStore(async s => {
      await s.create("mine", "owner/current");
      await s.create("legacy", "old/repo"); // stamped before R3-848: no provider
    });
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_ConversationList.default, {}));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByText("old/repo")).toBeTruthy());
    _react.fireEvent.click(_react.screen.getByText("Other repositories"));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: /old\/repo/
    }));
    (0, _vitest.expect)(_sdk.openRepository).not.toHaveBeenCalled();
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByRole("status").textContent).toContain("no provider stamp"));
  });
  (0, _vitest.it)("a successful open clears the row's earlier refusal", async () => {
    await renderWithOthers();
    const row = _react.screen.getByRole("button", {
      name: /other\/repo/
    });
    _vitest.vi.mocked(_sdk.openRepository).mockRejectedValueOnce(Object.assign(new Error("repository open refused"), {
      code: "forbidden"
    }));
    _react.fireEvent.click(row);
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.getByRole("status").textContent).toBe("forbidden"));
    _vitest.vi.mocked(_sdk.openRepository).mockResolvedValueOnce(undefined);
    _react.fireEvent.click(row);
    await (0, _react.waitFor)(() => (0, _vitest.expect)(_react.screen.queryByRole("status")).toBeNull());
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9Db252ZXJzYXRpb25MaXN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9jb252ZXJzYXRpb25JcGMiLCJfc2RrIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIldlYWtNYXAiLCJyIiwidCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwidmkiLCJtb2NrIiwicG9zdFRvUmVnaW9uIiwiZm4iLCJyZXZlYWxSZWdpb24iLCJvcGVuUmVwb3NpdG9yeSIsInVzZVdvcmtzcGFjZSIsIm9uUmVnaW9uTWVzc2FnZSIsImxpc3RlbmVyIiwicmVnaW9uTGlzdGVuZXJzIiwicHVzaCIsImluZGV4T2YiLCJzcGxpY2UiLCJzdG9yZUhvbGRlciIsImhvaXN0ZWQiLCJtYWtlIiwiaW1wb3J0T3JpZ2luYWwiLCJhY3R1YWwiLCJvcGVuQ29udmVyc2F0aW9uU3RvcmUiLCJsYXN0U3RvcmUiLCJtYWtlU2VlZGVkU3RvcmUiLCJzZWVkIiwiY3JlYXRlQ29udmVyc2F0aW9uU3RvcmUiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJNZW1GcyIsImJhc2UiLCJyZWNvcmRSb290IiwiZnMiLCJ0YWJJZCIsIndyYXBwZWQiLCJsaXN0IiwiYmluZCIsImxvYWQiLCJzYXZlIiwicmVtb3ZlIiwibWFrZVN0b3JlIiwicyIsImNyZWF0ZSIsImJlZm9yZUVhY2giLCJsZW5ndGgiLCJtb2NrZWQiLCJtb2NrQ2xlYXIiLCJtb2NrSW1wbGVtZW50YXRpb24iLCJhZnRlckVhY2giLCJjbGVhbnVwIiwidXNlUmVhbFRpbWVycyIsInBvc3RGcm9tU3RhZ2UiLCJkYXRhIiwibCIsImZyb20iLCJTVEFHRV9SRUdJT04iLCJyZW5kZXJXaXRoTm90ZXNSb3ciLCJyZW5kZXIiLCJqc3giLCJ3YWl0Rm9yIiwiZXhwZWN0Iiwic2NyZWVuIiwiZ2V0QnlUZXh0IiwidG9CZVRydXRoeSIsImRlc2NyaWJlIiwiaXQiLCJvcGVuIiwiZ2V0QnlSb2xlIiwibmFtZSIsImdldEF0dHJpYnV0ZSIsInRvQmVOdWxsIiwidGV4dENvbnRlbnQiLCJub3QiLCJ0b0NvbnRhaW4iLCJ0b0JlIiwicm93IiwiY2xvc2VzdCIsImlkIiwiZmlyZUV2ZW50IiwiY2xpY2siLCJxdWVyeUJ5VGV4dCIsInRvSGF2ZUJlZW5DYWxsZWRXaXRoIiwic2F2ZWQiLCJ0aXRsZSIsImxpc3RDYWxscyIsImNhbGxzIiwidHlwZSIsInNlZWRXaXRoT3RoZXJzIiwicGx1cmFsTGFiZWwiLCJjbGFzc0xpc3QiLCJjb250YWlucyIsInBsdXJhbERpZ2l0IiwicGFyZW50RWxlbWVudCIsInNpbmd1bGFyTGFiZWwiLCJzaW5ndWxhckRpZ2l0IiwibWFrZU90aGVyUmVwb1N0b3JlIiwicmVuZGVyV2l0aE90aGVycyIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsInByb3ZpZGVyIiwibmFtZXNwYWNlIiwicmVwb3NpdG9yeSIsInNldHRsZSIsInJlcyIsInF1ZXJ5QnlSb2xlIiwibW9ja1JlamVjdGVkVmFsdWVPbmNlIiwiYXNzaWduIiwiRXJyb3IiLCJjb2RlIiwidG9IYXZlQmVlbkNhbGxlZCIsIm1vY2tSZXNvbHZlZFZhbHVlT25jZSIsInVuZGVmaW5lZCJdLCJzb3VyY2VzIjpbIkNvbnZlcnNhdGlvbkxpc3QudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBoYXBweS1kb21cbi8vIFIzLTYxMiDigJQgdGhlIGZpcnN0IGNvbXBvbmVudCB0ZXN0cyBpbiB0aGlzIHJlcG8gKHRoZSBpdGVtJ3MgaGFybmVzczogaGFwcHktZG9tICtcbi8vIEB0ZXN0aW5nLWxpYnJhcnkvcmVhY3QsIHRoZSBTREsgYmFycmVsIG1vY2tlZCBleGFjdGx5IGFzIHRoZSBsaWIgdGVzdHMgbW9jayBpdCkuXG4vL1xuLy8gV2hhdCBpcyB1bmRlciB0ZXN0IGlzIHRoZSBBQ0NFU1NJQkxFIHNoYXBlLCBub3QgdGhlIHBpeGVsczogdGhlIHJvdyBpcyBhIHBsYWluXG4vLyA8bGk+IHdob3NlIG9wZW4gY29udHJvbCBpcyBhIHJlYWwgYnV0dG9uIChXQ0FHIDQuMS4yIOKAlCB0d28gY29udHJvbHMsIHR3byBuYW1lcyksXG4vLyBkZWxldGUgcmVtb3ZlcyB0aHJvdWdoIHRoZSBzdG9yZSwgYW5kIGEgYGNvbnZlcnNhdGlvbi11cGRhdGVkYCBtZXNzYWdlIHBhdGNoZXNcbi8vIHRoZSBPTkUgcm93IGl0IG5hbWVzIHdpdGhvdXQgcmUtbGlzdGluZyB0aGUgc3RvcmUgKFItSVgtNCkuIFJvd3MgY29tZSBmcm9tIHRoZVxuLy8gUkVBTCBmcy1pbmplY3RlZCBzdG9yZSBvdmVyIE1lbUZzIOKAlCBuZXZlciBhIGhhbmQtdHlwZWQgYXJyYXkgKFIyKS5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSwgYmVmb3JlRWFjaCwgYWZ0ZXJFYWNoIH0gZnJvbSBcInZpdGVzdFwiO1xuaW1wb3J0IHtcbiAgcmVuZGVyLFxuICBzY3JlZW4sXG4gIGZpcmVFdmVudCxcbiAgd2FpdEZvcixcbiAgY2xlYW51cCxcbn0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcblxudmkubW9jayhcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCIsICgpID0+ICh7XG4gIHBvc3RUb1JlZ2lvbjogdmkuZm4oYXN5bmMgKCkgPT4ge30pLFxuICByZXZlYWxSZWdpb246IHZpLmZuKGFzeW5jICgpID0+IHt9KSxcbiAgLy8gUjMtODQ4OiB0aGUgaG9zdC1tZWRpYXRlZCB2ZXJiLCBzcGllZCBmcm9tIHRoZSBjbGljayBoYW5kbGVyLlxuICBvcGVuUmVwb3NpdG9yeTogdmkuZm4oYXN5bmMgKCkgPT4ge30pLFxuICB1c2VXb3Jrc3BhY2U6IHZpLmZuKCgpID0+IG51bGwpLFxuICBvblJlZ2lvbk1lc3NhZ2U6IHZpLmZuKFxuICAgIChsaXN0ZW5lcjogKG06IHsgZnJvbTogc3RyaW5nOyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQpID0+IHtcbiAgICAgIHJlZ2lvbkxpc3RlbmVycy5wdXNoKGxpc3RlbmVyKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGkgPSByZWdpb25MaXN0ZW5lcnMuaW5kZXhPZihsaXN0ZW5lcik7XG4gICAgICAgIGlmIChpID49IDApIHJlZ2lvbkxpc3RlbmVycy5zcGxpY2UoaSwgMSk7XG4gICAgICB9O1xuICAgIH0sXG4gICksXG59KSk7XG5cbi8vIFRoZSBzdG9yZSBpcyBSRUFMIChmcy1pbmplY3RlZCBjb3JlIG92ZXIgTWVtRnMpOyBvbmx5IGl0cyBtb3VudCByZXNvbHV0aW9uIGlzXG4vLyByZXBsYWNlZCwgc28gbGlzdC9sb2FkL3NhdmUvcmVtb3ZlIHJ1biB0aGUgc2hpcHBlZCBjb2RlLiBPbmUgc2VlZGVkIHJvdyBwZXJcbi8vIHN0b3JlLCBjcmVhdGVkIHRocm91Z2ggdGhlIHN0b3JlIGl0c2VsZiDigJQgdGhlIGxpc3QgdGVzdCBmaXh0dXJlIGlzIHN0b3JlIG91dHB1dCxcbi8vIG5vdCBhIGxpdGVyYWwuIChUaGUgdmkubW9jayBmYWN0b3J5IGJlbG93IGlzIGhvaXN0ZWQsIHNvIGl0IHJlYWNoZXMgdGhlIGltcGxcbi8vIHRocm91Z2ggdGhpcyBob2xkZXIgcmF0aGVyIHRoYW4gYSB0b3AtbGV2ZWwgY29uc3QuKVxuY29uc3Qgc3RvcmVIb2xkZXIgPSB2aS5ob2lzdGVkKCgpID0+ICh7XG4gIG1ha2U6IG51bGwgYXMgbnVsbCB8ICgoKSA9PiBQcm9taXNlPHVua25vd24+KSxcbn0pKTtcblxudmkubW9jayhcIi4uL2xpYi9jb252ZXJzYXRpb25TdG9yZVwiLCBhc3luYyAoaW1wb3J0T3JpZ2luYWwpID0+IHtcbiAgY29uc3QgYWN0dWFsID1cbiAgICBhd2FpdCBpbXBvcnRPcmlnaW5hbDx0eXBlb2YgaW1wb3J0KFwiLi4vbGliL2NvbnZlcnNhdGlvblN0b3JlXCIpPigpO1xuICByZXR1cm4geyAuLi5hY3R1YWwsIG9wZW5Db252ZXJzYXRpb25TdG9yZTogKCkgPT4gc3RvcmVIb2xkZXIubWFrZSEoKSB9O1xufSk7XG5cbnR5cGUgU3BpZWRTdG9yZSA9IGltcG9ydChcIi4uL2xpYi9jb252ZXJzYXRpb25TdG9yZVwiKS5Db252ZXJzYXRpb25TdG9yZSAmIHtcbiAgbGlzdDogUmV0dXJuVHlwZTx0eXBlb2YgdmkuZm4+O1xuICBsb2FkOiBSZXR1cm5UeXBlPHR5cGVvZiB2aS5mbj47XG4gIHNhdmU6IFJldHVyblR5cGU8dHlwZW9mIHZpLmZuPjtcbiAgcmVtb3ZlOiBSZXR1cm5UeXBlPHR5cGVvZiB2aS5mbj47XG59O1xubGV0IGxhc3RTdG9yZTogU3BpZWRTdG9yZSB8IG51bGwgPSBudWxsO1xuXG4vKiogVGhlIG9uZSBzZWVkZWQtc3RvcmUgYnVpbGRlcjogYSBSRUFMIGZzLWluamVjdGVkIHN0b3JlIG92ZXIgTWVtRnMsIHNlZWRlZFxuICogIHRocm91Z2ggdGhlIHN0b3JlIGl0c2VsZiwgdGhlbiBzcHktd3JhcHBlZC4gQm90aCBkZXNjcmliZXMgcmlkZSBpdC4gKi9cbmNvbnN0IG1ha2VTZWVkZWRTdG9yZSA9IGFzeW5jIChcbiAgc2VlZDogKHN0b3JlOiBpbXBvcnQoXCIuLi9saWIvY29udmVyc2F0aW9uU3RvcmVcIikuQ29udmVyc2F0aW9uU3RvcmUpID0+IFByb21pc2U8dm9pZD4sXG4pOiBQcm9taXNlPFNwaWVkU3RvcmU+ID0+IHtcbiAgY29uc3QgeyBjcmVhdGVDb252ZXJzYXRpb25TdG9yZSB9ID0gYXdhaXQgaW1wb3J0KFwiLi4vbGliL2NvbnZlcnNhdGlvblN0b3JlXCIpO1xuICBjb25zdCB7IE1lbUZzIH0gPSBhd2FpdCBpbXBvcnQoXCIuLi9saWIvdGVzdGluZy9tZW1TdG9yZUZzXCIpO1xuICBjb25zdCBiYXNlID0gY3JlYXRlQ29udmVyc2F0aW9uU3RvcmUoe1xuICAgIHJlY29yZFJvb3Q6IFwiL3NldHRpbmdzXCIsXG4gICAgZnM6IG5ldyBNZW1GcygpLFxuICAgIHRhYklkOiBcInRhYi1jb252ZXJzYXRpb24tbGlzdFwiLFxuICB9KTtcbiAgYXdhaXQgc2VlZChiYXNlKTtcbiAgY29uc3Qgd3JhcHBlZCA9IHtcbiAgICAuLi5iYXNlLFxuICAgIGxpc3Q6IHZpLmZuKGJhc2UubGlzdC5iaW5kKGJhc2UpKSxcbiAgICBsb2FkOiB2aS5mbihiYXNlLmxvYWQuYmluZChiYXNlKSksXG4gICAgc2F2ZTogdmkuZm4oYmFzZS5zYXZlLmJpbmQoYmFzZSkpLFxuICAgIHJlbW92ZTogdmkuZm4oYmFzZS5yZW1vdmUuYmluZChiYXNlKSksXG4gIH07XG4gIGxhc3RTdG9yZSA9IHdyYXBwZWQ7XG4gIHJldHVybiB3cmFwcGVkO1xufTtcblxuY29uc3QgbWFrZVN0b3JlID0gKCkgPT4gbWFrZVNlZWRlZFN0b3JlKGFzeW5jIChzKSA9PiB7XG4gIGF3YWl0IHMuY3JlYXRlKFwibm90ZXNcIik7XG59KTtcblxuaW1wb3J0IENvbnZlcnNhdGlvbkxpc3QgZnJvbSBcIi4vQ29udmVyc2F0aW9uTGlzdFwiO1xuaW1wb3J0IHsgU1RBR0VfUkVHSU9OIH0gZnJvbSBcIi4uL2xpYi9jb252ZXJzYXRpb25JcGNcIjtcbmltcG9ydCB7IG9wZW5SZXBvc2l0b3J5IH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5cbmNvbnN0IHJlZ2lvbkxpc3RlbmVyczogQXJyYXk8KG06IHsgZnJvbTogc3RyaW5nOyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQ+ID0gW107XG5cbmJlZm9yZUVhY2goKCkgPT4ge1xuICByZWdpb25MaXN0ZW5lcnMubGVuZ3RoID0gMDtcbiAgbGFzdFN0b3JlID0gbnVsbDtcbiAgdmkubW9ja2VkKG9wZW5SZXBvc2l0b3J5KS5tb2NrQ2xlYXIoKTtcbiAgdmkubW9ja2VkKG9wZW5SZXBvc2l0b3J5KS5tb2NrSW1wbGVtZW50YXRpb24oYXN5bmMgKCkgPT4ge30pO1xuICAvLyBSZXN0b3JlIHRoZSBkZWZhdWx0IGZhY3Rvcnkg4oCUIGEgZGVzY3JpYmUgdGhhdCByZS1zZWVkcyBgc3RvcmVIb2xkZXIubWFrZWBcbiAgLy8gbXVzdCBuZXZlciBsZWFrIGl0cyBmaXh0dXJlIGludG8gZGVzY3JpYmVzIHRoYXQgcnVuIGFmdGVyIGl0LlxuICBzdG9yZUhvbGRlci5tYWtlID0gbWFrZVN0b3JlO1xufSk7XG5cbmFmdGVyRWFjaCgoKSA9PiB7XG4gIGNsZWFudXAoKTtcbiAgdmkudXNlUmVhbFRpbWVycygpO1xufSk7XG5cbmNvbnN0IHBvc3RGcm9tU3RhZ2UgPSAoZGF0YTogdW5rbm93bik6IHZvaWQgPT4ge1xuICBmb3IgKGNvbnN0IGwgb2YgWy4uLnJlZ2lvbkxpc3RlbmVyc10pIGwoeyBmcm9tOiBTVEFHRV9SRUdJT04sIGRhdGEgfSk7XG59O1xuXG5jb25zdCByZW5kZXJXaXRoTm90ZXNSb3cgPSBhc3luYyAoKSA9PiB7XG4gIHJlbmRlcig8Q29udmVyc2F0aW9uTGlzdCAvPik7XG4gIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJub3Rlc1wiKSkudG9CZVRydXRoeSgpKTtcbn07XG5cbmRlc2NyaWJlKFwiQ29udmVyc2F0aW9uTGlzdCDigJQgdGhlIHJvdyBpcyB0d28gY29udHJvbHMsIHR3byBuYW1lcyAoUjMtNjEyIC8gV0NBRyA0LjEuMilcIiwgKCkgPT4ge1xuICBpdChcInRoZSBvcGVuIGNvbnRyb2wgaXMgYSByZWFsIGJ1dHRvbiBuYW1lZCBieSBpdHMgY29udGVudCwgYW5kIG5ldmVyIGFic29yYnMgdGhlIGRlbGV0ZSBsYWJlbFwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE5vdGVzUm93KCk7XG5cbiAgICAvLyBUaGUgb3BlbiBjb250cm9sJ3MgYWNjZXNzaWJsZSBuYW1lIGlzIGl0cyBjb250ZW50IChcIm5vdGVzIGp1c3Qgbm93XCIpIOKAlCB0aGVcbiAgICAvLyBkZWxldGUgbGFiZWwgKFwiRGVsZXRlIG5vdGVzXCIpIG11c3Qgbm90IGJlIGFic29yYmVkIGludG8gaXQuIChBIHJlZ2V4IC9ub3Rlcy9cbiAgICAvLyBoZXJlIHdvdWxkIG1hdGNoIEJPVEggY29udHJvbHMg4oCUIHRoZSBkZWxldGUgcm93J3MgbmFtZSBsZWdpdGltYXRlbHkgY29udGFpbnNcbiAgICAvLyB0aGUgdGl0bGU7IHRoZSBkZWZlY3QgdW5kZXIgdGVzdCBpcyB0aGUgT1BFTiBjb250cm9sIGNhcnJ5aW5nIFwiRGVsZXRlIOKAplwiLilcbiAgICBjb25zdCBvcGVuID0gc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwibm90ZXMganVzdCBub3dcIiB9KTtcbiAgICBleHBlY3Qob3Blbi5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpKS50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChvcGVuLnRleHRDb250ZW50KS5ub3QudG9Db250YWluKFwiRGVsZXRlXCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJEZWxldGUgbm90ZXNcIiB9KSkubm90LnRvQmUob3Blbik7XG5cbiAgICAvLyBUaGUgPGxpPiBpdHNlbGYgaXMgbm90IGludGVyYWN0aXZlOiBubyBidXR0b24gcm9sZSwgbm8gdGFiaW5kZXguXG4gICAgY29uc3Qgcm93ID0gb3Blbi5jbG9zZXN0KFwibGlcIikhO1xuICAgIGV4cGVjdChyb3cuZ2V0QXR0cmlidXRlKFwicm9sZVwiKSkudG9CZU51bGwoKTtcbiAgICBleHBlY3Qocm93LmdldEF0dHJpYnV0ZShcInRhYmluZGV4XCIpKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcImRlbGV0ZSByZW1vdmVzIHRocm91Z2ggdGhlIHN0b3JlIGFuZCB0aGUgcm93IGdvZXNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhOb3Rlc1JvdygpO1xuICAgIGNvbnN0IGlkID0gKGF3YWl0IGxhc3RTdG9yZSEubGlzdCgpKVswXS5pZDtcblxuICAgIGZpcmVFdmVudC5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJEZWxldGUgbm90ZXNcIiB9KSk7XG5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoXCJub3Rlc1wiKSkudG9CZU51bGwoKSk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QobGFzdFN0b3JlIS5yZW1vdmUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKGlkKSk7XG4gIH0pO1xuXG4gIGl0KFwiYSBjb252ZXJzYXRpb24tdXBkYXRlZCBtZXNzYWdlIHBhdGNoZXMgdGhlIE9ORSByb3cgaXQgbmFtZXMgYW5kIG5ldmVyIGNhbGxzIGxpc3QoKSBhZ2FpbiAoUi1JWC00KVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE5vdGVzUm93KCk7XG5cbiAgICAvLyBUaGUgc3RhZ2Ugc2F2ZWQgdGhlIGNvbnZlcnNhdGlvbiAocmV0aXRsZWQpIGFuZCBwb3N0ZWQgdGhlIGlkLiBBcHBseSB0aGVcbiAgICAvLyBzYXZlIHRocm91Z2ggdGhlIFNBTUUgcmVhbCBzdG9yZSwgdGhlbiByZXBsYXkgdGhlIG1lc3NhZ2UgdGhlIHN0YWdlIHBvc3RzLlxuICAgIGNvbnN0IGlkID0gKGF3YWl0IGxhc3RTdG9yZSEubGlzdCgpKVswXS5pZDtcbiAgICBjb25zdCBzYXZlZCA9IGF3YWl0IGxhc3RTdG9yZSEubG9hZChpZCk7XG4gICAgZXhwZWN0KHNhdmVkKS50b0JlVHJ1dGh5KCk7XG4gICAgYXdhaXQgbGFzdFN0b3JlIS5zYXZlKHsgLi4uc2F2ZWQhLCB0aXRsZTogXCJub3RlcywgcmVuYW1lZFwiIH0pO1xuICAgIGNvbnN0IGxpc3RDYWxscyA9IGxhc3RTdG9yZSEubGlzdC5tb2NrLmNhbGxzLmxlbmd0aDtcblxuICAgIHBvc3RGcm9tU3RhZ2UoeyB0eXBlOiBcImNvbnZlcnNhdGlvbi11cGRhdGVkXCIsIGlkIH0pO1xuXG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PlxuICAgICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJub3RlcywgcmVuYW1lZFwiKSkudG9CZVRydXRoeSgpLFxuICAgICk7XG4gICAgZXhwZWN0KGxhc3RTdG9yZSEubGlzdC5tb2NrLmNhbGxzLmxlbmd0aCkudG9CZShsaXN0Q2FsbHMpO1xuICAgIGV4cGVjdChsYXN0U3RvcmUhLmxvYWQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKGlkKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgbWVzc2FnZSBmb3IgYSByb3cgZGVsZXRlZCBlbHNld2hlcmUgcmVtb3ZlcyB0aGF0IHJvd1wiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE5vdGVzUm93KCk7XG4gICAgY29uc3QgaWQgPSAoYXdhaXQgbGFzdFN0b3JlIS5saXN0KCkpWzBdLmlkO1xuICAgIGF3YWl0IGxhc3RTdG9yZSEucmVtb3ZlKGlkKTtcblxuICAgIHBvc3RGcm9tU3RhZ2UoeyB0eXBlOiBcImNvbnZlcnNhdGlvbi11cGRhdGVkXCIsIGlkIH0pO1xuXG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KFwibm90ZXNcIikpLnRvQmVOdWxsKCkpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIkNvbnZlcnNhdGlvbkxpc3Qg4oCUIHRoZSBvdGhlci1yZXBvc2l0b3JpZXMgY291bnQgbmFtZXMgd2hhdCBpdCBjb3VudHMgKFIzLTQ3NSlcIiwgKCkgPT4ge1xuICAvLyBUd28gc3RhbXBlZCByZXBvcyByaWRlIHRoZSBSRUFMIHN0b3JlIChvbmUgd2l0aCB0d28gbWVtYmVycywgb25lIHdpdGggb25lKSwgc29cbiAgLy8gdGhlIGdyb3VwIGNvdW50cyBhcmUgdGhlIHByb2R1Y2VyJ3Mgb3duIGFyaXRobWV0aWM7IHRoZSB3b3Jrc3BhY2UgbW9jayBzdGF5c1xuICAvLyBudWxsLCBzbyBldmVyeSBzdGFtcGVkIHJlcG8gZ3JvdXBzIHVuZGVyIFwib3RoZXIgcmVwb3NpdG9yaWVzXCIgYnkgcnVsZS4gVGhlXG4gIC8vIGZhY3Rvcnkgc3dhcCBpcyByZXN0b3JlZCBieSB0aGUgc2hhcmVkIGJlZm9yZUVhY2gsIHdoaWNoIHJlc2V0cyBpdCB0byBtYWtlU3RvcmUuXG4gIGNvbnN0IHNlZWRXaXRoT3RoZXJzID0gKCkgPT4ge1xuICAgIHN0b3JlSG9sZGVyLm1ha2UgPSAoKSA9PlxuICAgICAgbWFrZVNlZWRlZFN0b3JlKGFzeW5jIChzKSA9PiB7XG4gICAgICAgIGF3YWl0IHMuY3JlYXRlKFwibm90ZXNcIik7XG4gICAgICAgIGF3YWl0IHMuY3JlYXRlKFwicmVjaXBlIHBsYW5cIiwgXCJvdGhlci9yZXBvXCIpO1xuICAgICAgICBhd2FpdCBzLmNyZWF0ZShcInJlY2lwZSBmb2xsb3d1cFwiLCBcIm90aGVyL3JlcG9cIik7XG4gICAgICAgIGF3YWl0IHMuY3JlYXRlKFwic29sbyBlbHNld2hlcmVcIiwgXCJ0aGlyZC9yZXBvXCIpO1xuICAgICAgfSk7XG4gIH07XG5cbiAgaXQoXCJ0aGUgY291bnQgY2FycmllcyBhIGhvdmVyIGxhYmVsIGFuZCBhbiBhY2Nlc3NpYmxlIHRleHQg4oCUIHNpbmd1bGFyIGFuZCBwbHVyYWxcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHNlZWRXaXRoT3RoZXJzKCk7XG4gICAgcmVuZGVyKDxDb252ZXJzYXRpb25MaXN0IC8+KTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KFwiT3RoZXIgcmVwb3NpdG9yaWVzXCIpKS50b0JlVHJ1dGh5KCkpO1xuXG4gICAgLy8gVGhlIGFjY2Vzc2libGUgZm9ybSBpcyBSRUFMICh2aXN1YWxseSBoaWRkZW4pIHRleHQ7IHRoZSB2aXNpYmxlIGRpZ2l0IGlzXG4gICAgLy8gYXJpYS1oaWRkZW4gc28gdGhlIG51bWJlciBpcyBuZXZlciBhbm5vdW5jZWQgYXMgYSBiYXJlIFwiMlwiLlxuICAgIGNvbnN0IHBsdXJhbExhYmVsID0gc2NyZWVuLmdldEJ5VGV4dChcIjIgY29udmVyc2F0aW9ucyBpbiBvdGhlci9yZXBvXCIpO1xuICAgIGV4cGVjdChwbHVyYWxMYWJlbC5jbGFzc0xpc3QuY29udGFpbnMoXCJjbC12aFwiKSkudG9CZSh0cnVlKTtcbiAgICBjb25zdCBwbHVyYWxEaWdpdCA9IHNjcmVlbi5nZXRCeVRleHQoXCIyXCIpO1xuICAgIGV4cGVjdChwbHVyYWxEaWdpdC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiKSkudG9CZShcInRydWVcIik7XG4gICAgZXhwZWN0KHBsdXJhbERpZ2l0LnBhcmVudEVsZW1lbnQhLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpKS50b0JlKFwiMiBjb252ZXJzYXRpb25zIGluIG90aGVyL3JlcG9cIik7XG5cbiAgICBjb25zdCBzaW5ndWxhckxhYmVsID0gc2NyZWVuLmdldEJ5VGV4dChcIjEgY29udmVyc2F0aW9uIGluIHRoaXJkL3JlcG9cIik7XG4gICAgZXhwZWN0KHNpbmd1bGFyTGFiZWwuY2xhc3NMaXN0LmNvbnRhaW5zKFwiY2wtdmhcIikpLnRvQmUodHJ1ZSk7XG4gICAgY29uc3Qgc2luZ3VsYXJEaWdpdCA9IHNjcmVlbi5nZXRCeVRleHQoXCIxXCIpO1xuICAgIGV4cGVjdChzaW5ndWxhckRpZ2l0LmdldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIpKS50b0JlKFwidHJ1ZVwiKTtcbiAgICBleHBlY3Qoc2luZ3VsYXJEaWdpdC5wYXJlbnRFbGVtZW50IS5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKSkudG9CZShcIjEgY29udmVyc2F0aW9uIGluIHRoaXJkL3JlcG9cIik7XG4gIH0pO1xufSk7XG5cbi8vIOKUgOKUgCBSMy04NDgg4oCUIHRoZSBvdGhlci1yZXBvc2l0b3JpZXMgcm93cyBvcGVuIHRoZWlyIHJlcG9zaXRvcnkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBFYWNoIHJvdyBpcyBhIHJlYWwgYnV0dG9uIHRoYXQgY2FsbHMgdGhlIGhvc3QtbWVkaWF0ZWQgb3BlblJlcG9zaXRvcnkoKSB3aXRoXG4vLyB0aGUgcm93J3MgY29vcmRpbmF0ZXMsIHN5bmNocm9ub3VzbHkgZnJvbSB0aGUgY2xpY2sgaGFuZGxlciAoYW4gYXdhaXQgYmVmb3JlXG4vLyB0aGUgY2FsbCB3b3VsZCBsb3NlIHRoZSBob3N0J3MgdHJhbnNpZW50IGFjdGl2YXRpb24pLCBhbmQgYSByZWZ1c2FsIGxhbmRzXG4vLyBpdHMgY29kZSBPTiB0aGUgcm93LiBSb3dzIGNvbWUgZnJvbSB0aGUgUkVBTCBmcy1pbmplY3RlZCBzdG9yZS5cbmRlc2NyaWJlKFwiQ29udmVyc2F0aW9uTGlzdCDigJQgb3RoZXItcmVwb3NpdG9yaWVzIHJvd3Mgb3BlbiB0aGUgcmVwb3NpdG9yeSAoUjMtODQ4KVwiLCAoKSA9PiB7XG4gIGNvbnN0IG1ha2VPdGhlclJlcG9TdG9yZSA9ICgpID0+XG4gICAgbWFrZVNlZWRlZFN0b3JlKGFzeW5jIChzKSA9PiB7XG4gICAgICBhd2FpdCBzLmNyZWF0ZShcIm1pbmVcIiwgXCJvd25lci9jdXJyZW50XCIpO1xuICAgICAgLy8gU3RhbXBlZCBmb3IgQU5PVEhFUiByZXBvLCB3aXRoIGl0cyBwcm92aWRlciBzdGFtcC5cbiAgICAgIGF3YWl0IHMuY3JlYXRlKFwiZWxzZXdoZXJlXCIsIFwib3RoZXIvcmVwb1wiLCBcImdpdGh1YlwiKTtcbiAgICB9KTtcblxuICBjb25zdCByZW5kZXJXaXRoT3RoZXJzID0gYXN5bmMgKCkgPT4ge1xuICAgIHN0b3JlSG9sZGVyLm1ha2UgPSBtYWtlT3RoZXJSZXBvU3RvcmU7XG4gICAgcmVuZGVyKDxDb252ZXJzYXRpb25MaXN0IC8+KTtcbiAgICAvLyBObyB3b3Jrc3BhY2UgbW9ja2VkIOKHkiBldmVyeSBzdGFtcGVkIGNvbnZlcnNhdGlvbiBncm91cHMgdW5kZXIgXCJvdGhlclwiXG4gICAgLy8g4oCUIHdoaWNoIGlzIGV4YWN0bHkgdGhpcyBmaXh0dXJlJ3Mgc2hhcGUuIFRoZSByb3dzIHJlbmRlciB0aGUgR1JPVVAnc1xuICAgIC8vIHJlcG8gbGFiZWwsIG5ldmVyIHRoZSBjb252ZXJzYXRpb24gdGl0bGVzLlxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJvdGhlci9yZXBvXCIpKS50b0JlVHJ1dGh5KCkpO1xuICAgIC8vIE9wZW4gdGhlIDxkZXRhaWxzPiBzbyB0aGUgcm93cyByZW5kZXIuXG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJPdGhlciByZXBvc2l0b3JpZXNcIikpO1xuICB9O1xuXG4gIGl0KFwiYSByb3cgaXMgYSByZWFsIGJ1dHRvbiB3aG9zZSBjbGljayBjYWxscyBvcGVuUmVwb3NpdG9yeSBvbmNlLCB3aXRoIHRoZSByb3cncyBjb29yZGluYXRlc1wiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE90aGVycygpO1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvb3RoZXJcXC9yZXBvLyB9KTtcbiAgICBmaXJlRXZlbnQuY2xpY2socm93KTtcbiAgICBleHBlY3Qob3BlblJlcG9zaXRvcnkpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3Qob3BlblJlcG9zaXRvcnkpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHtcbiAgICAgIHByb3ZpZGVyOiBcImdpdGh1YlwiLFxuICAgICAgbmFtZXNwYWNlOiBcIm90aGVyXCIsXG4gICAgICByZXBvc2l0b3J5OiBcInJlcG9cIixcbiAgICB9KTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgY2FsbCBoYXBwZW5zIHN5bmNocm9ub3VzbHkgaW5zaWRlIHRoZSBoYW5kbGVyIOKAlCBubyBhd2FpdCBjYW4gc2xpcCBpbiBmcm9udCBvZiBpdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE90aGVycygpO1xuICAgIC8vIEEgcGVuZGluZyBwcm9taXNlOiB0aGUgaGFuZGxlciBjYW5ub3QgaGF2ZSBhd2FpdGVkIGFueXRoaW5nIGJlZm9yZSB0aGVcbiAgICAvLyBjYWxsIGFuZCBzdGlsbCBzZWUgdGhlIGhvc3QncyB0cmFuc2llbnQgYWN0aXZhdGlvbiAoYW4gYXdhaXQgYmVmb3JlIGl0IGlzXG4gICAgLy8gdGhlIG5vLWFjdGl2YXRpb24gcmVmdXNhbCB0aGlzIGd1YXJkIGV4aXN0cyB0byBwcmV2ZW50KS5cbiAgICBsZXQgc2V0dGxlITogKCkgPT4gdm9pZDtcbiAgICB2aS5tb2NrZWQob3BlblJlcG9zaXRvcnkpLm1vY2tJbXBsZW1lbnRhdGlvbihcbiAgICAgICgpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyZXMpID0+IHsgc2V0dGxlID0gcmVzOyB9KSxcbiAgICApO1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvb3RoZXJcXC9yZXBvLyB9KTtcbiAgICBmaXJlRXZlbnQuY2xpY2socm93KTtcbiAgICAvLyBDYWxsZWQgSU1NRURJQVRFTFkgYWZ0ZXIgdGhlIGRpc3BhdGNoIOKAlCBiZWZvcmUgYW55dGhpbmcgYXN5bmNocm9ub3VzIHJhbi5cbiAgICBleHBlY3Qob3BlblJlcG9zaXRvcnkpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBzZXR0bGUoKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJzdGF0dXNcIikpLnRvQmVOdWxsKCkpO1xuICB9KTtcblxuICBpdChcImEgcmVmdXNhbCBsYW5kcyBpdHMgY29kZSBvbiB0aGUgcm93IHRoYXQgYXNrZWRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhPdGhlcnMoKTtcbiAgICB2aS5tb2NrZWQob3BlblJlcG9zaXRvcnkpLm1vY2tSZWplY3RlZFZhbHVlT25jZShcbiAgICAgIE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwicmVwb3NpdG9yeSBvcGVuIHJlZnVzZWRcIiksIHsgY29kZTogXCJmb3JiaWRkZW5cIiB9KSxcbiAgICApO1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvb3RoZXJcXC9yZXBvLyB9KTtcbiAgICBmaXJlRXZlbnQuY2xpY2socm93KTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwic3RhdHVzXCIpLnRleHRDb250ZW50KS50b0JlKFwiZm9yYmlkZGVuXCIpKTtcbiAgfSk7XG5cbiAgaXQoXCJhIGxlZ2FjeSBncm91cCAobm8gcHJvdmlkZXIgc3RhbXApIGlzIFJFRlVTRUQgb24gdGhlIHJvdywgbmV2ZXIgb3BlbmVkIHVuZGVyIGEgZ3Vlc3NlZCBwcm92aWRlclwiLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gUm91bmQtMSByZXZpZXc6IHRoZSBTREsncyB3b3Jrc3BhY2UgY2FuIGNhcnJ5IGEgYGxvY2FsYCBwcm92aWRlciwgc28gYVxuICAgIC8vIGdpdGh1YiBkZWZhdWx0IGlzIHRoZSBndWVzcyB0aGUgaXRlbSBzYWlkIG5vdCB0byBtYWtlLiBUaGUgcm93IHJlZnVzZXMuXG4gICAgc3RvcmVIb2xkZXIubWFrZSA9ICgpID0+IG1ha2VTZWVkZWRTdG9yZShhc3luYyAocykgPT4ge1xuICAgICAgYXdhaXQgcy5jcmVhdGUoXCJtaW5lXCIsIFwib3duZXIvY3VycmVudFwiKTtcbiAgICAgIGF3YWl0IHMuY3JlYXRlKFwibGVnYWN5XCIsIFwib2xkL3JlcG9cIik7IC8vIHN0YW1wZWQgYmVmb3JlIFIzLTg0ODogbm8gcHJvdmlkZXJcbiAgICB9KTtcbiAgICByZW5kZXIoPENvbnZlcnNhdGlvbkxpc3QgLz4pO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJvbGQvcmVwb1wiKSkudG9CZVRydXRoeSgpKTtcbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcIk90aGVyIHJlcG9zaXRvcmllc1wiKSk7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvb2xkXFwvcmVwby8gfSkpO1xuICAgIGV4cGVjdChvcGVuUmVwb3NpdG9yeSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+XG4gICAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInN0YXR1c1wiKS50ZXh0Q29udGVudCkudG9Db250YWluKFwibm8gcHJvdmlkZXIgc3RhbXBcIiksXG4gICAgKTtcbiAgfSk7XG5cbiAgaXQoXCJhIHN1Y2Nlc3NmdWwgb3BlbiBjbGVhcnMgdGhlIHJvdydzIGVhcmxpZXIgcmVmdXNhbFwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aE90aGVycygpO1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvb3RoZXJcXC9yZXBvLyB9KTtcbiAgICB2aS5tb2NrZWQob3BlblJlcG9zaXRvcnkpLm1vY2tSZWplY3RlZFZhbHVlT25jZShcbiAgICAgIE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwicmVwb3NpdG9yeSBvcGVuIHJlZnVzZWRcIiksIHsgY29kZTogXCJmb3JiaWRkZW5cIiB9KSxcbiAgICApO1xuICAgIGZpcmVFdmVudC5jbGljayhyb3cpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJzdGF0dXNcIikudGV4dENvbnRlbnQpLnRvQmUoXCJmb3JiaWRkZW5cIikpO1xuICAgIHZpLm1vY2tlZChvcGVuUmVwb3NpdG9yeSkubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHVuZGVmaW5lZCBhcyBuZXZlcik7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHJvdyk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwic3RhdHVzXCIpKS50b0JlTnVsbCgpKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFTQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUE0RUEsSUFBQUUsaUJBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFJLGdCQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxJQUFBLEdBQUFMLE9BQUE7QUFBc0QsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQUEsSUFBQU8sRUFBQSxHQUFBQyxZQUFBO0FBQUEsU0FBQUwsdUJBQUFNLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyx5QkFBQUgsQ0FBQSw2QkFBQUksT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRCx3QkFBQSxZQUFBQSxDQUFBSCxDQUFBLFdBQUFBLENBQUEsR0FBQU0sQ0FBQSxHQUFBRCxDQUFBLEtBQUFMLENBQUE7QUFBQSxTQUFBTyx3QkFBQVAsQ0FBQSxFQUFBSyxDQUFBLFNBQUFBLENBQUEsSUFBQUwsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsU0FBQUQsQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFFLE9BQUEsRUFBQUYsQ0FBQSxRQUFBTSxDQUFBLEdBQUFILHdCQUFBLENBQUFFLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFFLEdBQUEsQ0FBQVIsQ0FBQSxVQUFBTSxDQUFBLENBQUFHLEdBQUEsQ0FBQVQsQ0FBQSxPQUFBVSxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFoQixDQUFBLG9CQUFBZ0IsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWxCLENBQUEsRUFBQWdCLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWYsQ0FBQSxFQUFBZ0IsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBaEIsQ0FBQSxDQUFBZ0IsQ0FBQSxZQUFBTixDQUFBLENBQUFSLE9BQUEsR0FBQUYsQ0FBQSxFQUFBTSxDQUFBLElBQUFBLENBQUEsQ0FBQWMsR0FBQSxDQUFBcEIsQ0FBQSxFQUFBVSxDQUFBLEdBQUFBLENBQUEsSUF4RnREO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVVBVyxVQUFFLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxPQUFPO0VBQ3JDQyxZQUFZLEVBQUVGLFVBQUUsQ0FBQ0csRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDbkNDLFlBQVksRUFBRUosVUFBRSxDQUFDRyxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUNuQztFQUNBRSxjQUFjLEVBQUVMLFVBQUUsQ0FBQ0csRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDckNHLFlBQVksRUFBRU4sVUFBRSxDQUFDRyxFQUFFLENBQUMsTUFBTSxJQUFJLENBQUM7RUFDL0JJLGVBQWUsRUFBRVAsVUFBRSxDQUFDRyxFQUFFLENBQ25CSyxRQUFzRCxJQUFLO0lBQzFEQyxlQUFlLENBQUNDLElBQUksQ0FBQ0YsUUFBUSxDQUFDO0lBQzlCLE9BQU8sTUFBTTtNQUNYLE1BQU1WLENBQUMsR0FBR1csZUFBZSxDQUFDRSxPQUFPLENBQUNILFFBQVEsQ0FBQztNQUMzQyxJQUFJVixDQUFDLElBQUksQ0FBQyxFQUFFVyxlQUFlLENBQUNHLE1BQU0sQ0FBQ2QsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxQyxDQUFDO0VBQ0gsQ0FDRjtBQUNGLENBQUMsQ0FBQyxDQUFDOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNZSxXQUFXLEdBQUdiLFVBQUUsQ0FBQ2MsT0FBTyxDQUFDLE9BQU87RUFDcENDLElBQUksRUFBRTtBQUNSLENBQUMsQ0FBQyxDQUFDO0FBRUhmLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLDBCQUEwQixFQUFFLE1BQU9lLGNBQWMsSUFBSztFQUM1RCxNQUFNQyxNQUFNLEdBQ1YsTUFBTUQsY0FBYyxDQUE0QyxDQUFDO0VBQ25FLE9BQU87SUFBRSxHQUFHQyxNQUFNO0lBQUVDLHFCQUFxQixFQUFFQSxDQUFBLEtBQU1MLFdBQVcsQ0FBQ0UsSUFBSSxDQUFFO0VBQUUsQ0FBQztBQUN4RSxDQUFDLENBQUM7QUFRRixJQUFJSSxTQUE0QixHQUFHLElBQUk7O0FBRXZDO0FBQ0E7QUFDQSxNQUFNQyxlQUFlLEdBQUcsTUFDdEJDLElBQW9GLElBQzVEO0VBQ3hCLE1BQU07SUFBRUM7RUFBd0IsQ0FBQyxHQUFHLE1BQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUF2Qyx1QkFBQSxDQUFBaEIsT0FBQSxDQUFhLDBCQUEwQixHQUFDO0VBQzVFLE1BQU07SUFBRXdEO0VBQU0sQ0FBQyxHQUFHLE1BQUFILE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUF2Qyx1QkFBQSxDQUFBaEIsT0FBQSxDQUFhLDJCQUEyQixHQUFDO0VBQzNELE1BQU15RCxJQUFJLEdBQUdMLHVCQUF1QixDQUFDO0lBQ25DTSxVQUFVLEVBQUUsV0FBVztJQUN2QkMsRUFBRSxFQUFFLElBQUlILEtBQUssQ0FBQyxDQUFDO0lBQ2ZJLEtBQUssRUFBRTtFQUNULENBQUMsQ0FBQztFQUNGLE1BQU1ULElBQUksQ0FBQ00sSUFBSSxDQUFDO0VBQ2hCLE1BQU1JLE9BQU8sR0FBRztJQUNkLEdBQUdKLElBQUk7SUFDUEssSUFBSSxFQUFFaEMsVUFBRSxDQUFDRyxFQUFFLENBQUN3QixJQUFJLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxDQUFDTixJQUFJLENBQUMsQ0FBQztJQUNqQ08sSUFBSSxFQUFFbEMsVUFBRSxDQUFDRyxFQUFFLENBQUN3QixJQUFJLENBQUNPLElBQUksQ0FBQ0QsSUFBSSxDQUFDTixJQUFJLENBQUMsQ0FBQztJQUNqQ1EsSUFBSSxFQUFFbkMsVUFBRSxDQUFDRyxFQUFFLENBQUN3QixJQUFJLENBQUNRLElBQUksQ0FBQ0YsSUFBSSxDQUFDTixJQUFJLENBQUMsQ0FBQztJQUNqQ1MsTUFBTSxFQUFFcEMsVUFBRSxDQUFDRyxFQUFFLENBQUN3QixJQUFJLENBQUNTLE1BQU0sQ0FBQ0gsSUFBSSxDQUFDTixJQUFJLENBQUM7RUFDdEMsQ0FBQztFQUNEUixTQUFTLEdBQUdZLE9BQU87RUFDbkIsT0FBT0EsT0FBTztBQUNoQixDQUFDO0FBRUQsTUFBTU0sU0FBUyxHQUFHQSxDQUFBLEtBQU1qQixlQUFlLENBQUMsTUFBT2tCLENBQUMsSUFBSztFQUNuRCxNQUFNQSxDQUFDLENBQUNDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBTUYsTUFBTTlCLGVBQW9FLEdBQUcsRUFBRTtBQUUvRSxJQUFBK0Isa0JBQVUsRUFBQyxNQUFNO0VBQ2YvQixlQUFlLENBQUNnQyxNQUFNLEdBQUcsQ0FBQztFQUMxQnRCLFNBQVMsR0FBRyxJQUFJO0VBQ2hCbkIsVUFBRSxDQUFDMEMsTUFBTSxDQUFDckMsbUJBQWMsQ0FBQyxDQUFDc0MsU0FBUyxDQUFDLENBQUM7RUFDckMzQyxVQUFFLENBQUMwQyxNQUFNLENBQUNyQyxtQkFBYyxDQUFDLENBQUN1QyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQzVEO0VBQ0E7RUFDQS9CLFdBQVcsQ0FBQ0UsSUFBSSxHQUFHc0IsU0FBUztBQUM5QixDQUFDLENBQUM7QUFFRjVELEVBQUEsS0FBQW9FLGlCQUFTLEVBQUFwRSxFQUFBLENBQUMsTUFBTTtFQUFBQSxFQUFBO0VBQ2QsSUFBQXFFLGNBQU8sRUFBQyxDQUFDO0VBQ1Q5QyxVQUFFLENBQUMrQyxhQUFhLENBQUMsQ0FBQztBQUNwQixDQUFDO0VBQUEsUUFEQy9DLFVBQUUsQ0FBQytDLGFBQWE7QUFBQSxFQUNqQixDQUFDO0VBQUEsUUFEQS9DLFVBQUUsQ0FBQytDLGFBQWE7QUFBQTtBQUdsQixNQUFNQyxhQUFhLEdBQUlDLElBQWEsSUFBVztFQUM3QyxLQUFLLE1BQU1DLENBQUMsSUFBSSxDQUFDLEdBQUd6QyxlQUFlLENBQUMsRUFBRXlDLENBQUMsQ0FBQztJQUFFQyxJQUFJLEVBQUVDLDZCQUFZO0lBQUVIO0VBQUssQ0FBQyxDQUFDO0FBQ3ZFLENBQUM7QUFFRCxNQUFNSSxrQkFBa0IsR0FBRyxNQUFBQSxDQUFBLEtBQVk7RUFDckMsSUFBQUMsYUFBTSxlQUFDLElBQUE5RSxXQUFBLENBQUErRSxHQUFBLEVBQUNuRixpQkFBQSxDQUFBUyxPQUFnQixJQUFFLENBQUMsQ0FBQztFQUM1QixNQUFNLElBQUEyRSxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQztBQUVELElBQUFDLGdCQUFRLEVBQUMsNkVBQTZFLEVBQUUsTUFBTTtFQUM1RixJQUFBQyxVQUFFLEVBQUMsNEZBQTRGLEVBQUUsWUFBWTtJQUMzRyxNQUFNVCxrQkFBa0IsQ0FBQyxDQUFDOztJQUUxQjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1VLElBQUksR0FBR0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFpQixDQUFDLENBQUM7SUFDbkUsSUFBQVIsY0FBTSxFQUFDTSxJQUFJLENBQUNHLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztJQUNsRCxJQUFBVixjQUFNLEVBQUNNLElBQUksQ0FBQ0ssV0FBVyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUNoRCxJQUFBYixjQUFNLEVBQUNDLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxHQUFHLENBQUNFLElBQUksQ0FBQ1IsSUFBSSxDQUFDOztJQUUzRTtJQUNBLE1BQU1TLEdBQUcsR0FBR1QsSUFBSSxDQUFDVSxPQUFPLENBQUMsSUFBSSxDQUFFO0lBQy9CLElBQUFoQixjQUFNLEVBQUNlLEdBQUcsQ0FBQ04sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0lBQzNDLElBQUFWLGNBQU0sRUFBQ2UsR0FBRyxDQUFDTixZQUFZLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDakQsQ0FBQyxDQUFDO0VBRUYsSUFBQUwsVUFBRSxFQUFDLG1EQUFtRCxFQUFFLFlBQVk7SUFDbEUsTUFBTVQsa0JBQWtCLENBQUMsQ0FBQztJQUMxQixNQUFNcUIsRUFBRSxHQUFHLENBQUMsTUFBTXZELFNBQVMsQ0FBRWEsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzBDLEVBQUU7SUFFMUNDLGdCQUFTLENBQUNDLEtBQUssQ0FBQ2xCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQztJQUVyRSxNQUFNLElBQUFULGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDbUIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNWLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsTUFBTSxJQUFBWCxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUN0QyxTQUFTLENBQUVpQixNQUFNLENBQUMsQ0FBQzBDLG9CQUFvQixDQUFDSixFQUFFLENBQUMsQ0FBQztFQUN6RSxDQUFDLENBQUM7RUFFRixJQUFBWixVQUFFLEVBQUMsbUdBQW1HLEVBQUUsWUFBWTtJQUNsSCxNQUFNVCxrQkFBa0IsQ0FBQyxDQUFDOztJQUUxQjtJQUNBO0lBQ0EsTUFBTXFCLEVBQUUsR0FBRyxDQUFDLE1BQU12RCxTQUFTLENBQUVhLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMwQyxFQUFFO0lBQzFDLE1BQU1LLEtBQUssR0FBRyxNQUFNNUQsU0FBUyxDQUFFZSxJQUFJLENBQUN3QyxFQUFFLENBQUM7SUFDdkMsSUFBQWpCLGNBQU0sRUFBQ3NCLEtBQUssQ0FBQyxDQUFDbkIsVUFBVSxDQUFDLENBQUM7SUFDMUIsTUFBTXpDLFNBQVMsQ0FBRWdCLElBQUksQ0FBQztNQUFFLEdBQUc0QyxLQUFNO01BQUVDLEtBQUssRUFBRTtJQUFpQixDQUFDLENBQUM7SUFDN0QsTUFBTUMsU0FBUyxHQUFHOUQsU0FBUyxDQUFFYSxJQUFJLENBQUMvQixJQUFJLENBQUNpRixLQUFLLENBQUN6QyxNQUFNO0lBRW5ETyxhQUFhLENBQUM7TUFBRW1DLElBQUksRUFBRSxzQkFBc0I7TUFBRVQ7SUFBRyxDQUFDLENBQUM7SUFFbkQsTUFBTSxJQUFBbEIsY0FBTyxFQUFDLE1BQ1osSUFBQUMsY0FBTSxFQUFDQyxhQUFNLENBQUNDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUN4RCxDQUFDO0lBQ0QsSUFBQUgsY0FBTSxFQUFDdEMsU0FBUyxDQUFFYSxJQUFJLENBQUMvQixJQUFJLENBQUNpRixLQUFLLENBQUN6QyxNQUFNLENBQUMsQ0FBQzhCLElBQUksQ0FBQ1UsU0FBUyxDQUFDO0lBQ3pELElBQUF4QixjQUFNLEVBQUN0QyxTQUFTLENBQUVlLElBQUksQ0FBQyxDQUFDNEMsb0JBQW9CLENBQUNKLEVBQUUsQ0FBQztFQUNsRCxDQUFDLENBQUM7RUFFRixJQUFBWixVQUFFLEVBQUMsMERBQTBELEVBQUUsWUFBWTtJQUN6RSxNQUFNVCxrQkFBa0IsQ0FBQyxDQUFDO0lBQzFCLE1BQU1xQixFQUFFLEdBQUcsQ0FBQyxNQUFNdkQsU0FBUyxDQUFFYSxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDMEMsRUFBRTtJQUMxQyxNQUFNdkQsU0FBUyxDQUFFaUIsTUFBTSxDQUFDc0MsRUFBRSxDQUFDO0lBRTNCMUIsYUFBYSxDQUFDO01BQUVtQyxJQUFJLEVBQUUsc0JBQXNCO01BQUVUO0lBQUcsQ0FBQyxDQUFDO0lBRW5ELE1BQU0sSUFBQWxCLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDbUIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNWLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDckUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQU4sZ0JBQVEsRUFBQywrRUFBK0UsRUFBRSxNQUFNO0VBQzlGO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTXVCLGNBQWMsR0FBR0EsQ0FBQSxLQUFNO0lBQzNCdkUsV0FBVyxDQUFDRSxJQUFJLEdBQUcsTUFDakJLLGVBQWUsQ0FBQyxNQUFPa0IsQ0FBQyxJQUFLO01BQzNCLE1BQU1BLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLE9BQU8sQ0FBQztNQUN2QixNQUFNRCxDQUFDLENBQUNDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDO01BQzNDLE1BQU1ELENBQUMsQ0FBQ0MsTUFBTSxDQUFDLGlCQUFpQixFQUFFLFlBQVksQ0FBQztNQUMvQyxNQUFNRCxDQUFDLENBQUNDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxZQUFZLENBQUM7SUFDaEQsQ0FBQyxDQUFDO0VBQ04sQ0FBQztFQUVELElBQUF1QixVQUFFLEVBQUMsOEVBQThFLEVBQUUsWUFBWTtJQUM3RnNCLGNBQWMsQ0FBQyxDQUFDO0lBQ2hCLElBQUE5QixhQUFNLGVBQUMsSUFBQTlFLFdBQUEsQ0FBQStFLEdBQUEsRUFBQ25GLGlCQUFBLENBQUFTLE9BQWdCLElBQUUsQ0FBQyxDQUFDO0lBQzVCLE1BQU0sSUFBQTJFLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDQyxVQUFVLENBQUMsQ0FBQyxDQUFDOztJQUVoRjtJQUNBO0lBQ0EsTUFBTXlCLFdBQVcsR0FBRzNCLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLCtCQUErQixDQUFDO0lBQ3JFLElBQUFGLGNBQU0sRUFBQzRCLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDMUQsTUFBTWlCLFdBQVcsR0FBRzlCLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLEdBQUcsQ0FBQztJQUN6QyxJQUFBRixjQUFNLEVBQUMrQixXQUFXLENBQUN0QixZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ0ssSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUM1RCxJQUFBZCxjQUFNLEVBQUMrQixXQUFXLENBQUNDLGFBQWEsQ0FBRXZCLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDSyxJQUFJLENBQUMsK0JBQStCLENBQUM7SUFFOUYsTUFBTW1CLGFBQWEsR0FBR2hDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLDhCQUE4QixDQUFDO0lBQ3RFLElBQUFGLGNBQU0sRUFBQ2lDLGFBQWEsQ0FBQ0osU0FBUyxDQUFDQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDNUQsTUFBTW9CLGFBQWEsR0FBR2pDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLEdBQUcsQ0FBQztJQUMzQyxJQUFBRixjQUFNLEVBQUNrQyxhQUFhLENBQUN6QixZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ0ssSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUM5RCxJQUFBZCxjQUFNLEVBQUNrQyxhQUFhLENBQUNGLGFBQWEsQ0FBRXZCLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDSyxJQUFJLENBQUMsOEJBQThCLENBQUM7RUFDakcsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBVixnQkFBUSxFQUFDLHlFQUF5RSxFQUFFLE1BQU07RUFDeEYsTUFBTStCLGtCQUFrQixHQUFHQSxDQUFBLEtBQ3pCeEUsZUFBZSxDQUFDLE1BQU9rQixDQUFDLElBQUs7SUFDM0IsTUFBTUEsQ0FBQyxDQUFDQyxNQUFNLENBQUMsTUFBTSxFQUFFLGVBQWUsQ0FBQztJQUN2QztJQUNBLE1BQU1ELENBQUMsQ0FBQ0MsTUFBTSxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsUUFBUSxDQUFDO0VBQ3JELENBQUMsQ0FBQztFQUVKLE1BQU1zRCxnQkFBZ0IsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDbkNoRixXQUFXLENBQUNFLElBQUksR0FBRzZFLGtCQUFrQjtJQUNyQyxJQUFBdEMsYUFBTSxlQUFDLElBQUE5RSxXQUFBLENBQUErRSxHQUFBLEVBQUNuRixpQkFBQSxDQUFBUyxPQUFnQixJQUFFLENBQUMsQ0FBQztJQUM1QjtJQUNBO0lBQ0E7SUFDQSxNQUFNLElBQUEyRSxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDeEU7SUFDQWUsZ0JBQVMsQ0FBQ0MsS0FBSyxDQUFDbEIsYUFBTSxDQUFDQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQztFQUN6RCxDQUFDO0VBRUQsSUFBQUcsVUFBRSxFQUFDLDBGQUEwRixFQUFFLFlBQVk7SUFDekcsTUFBTStCLGdCQUFnQixDQUFDLENBQUM7SUFDeEIsTUFBTXJCLEdBQUcsR0FBR2QsYUFBTSxDQUFDTSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQztJQUMvRFUsZ0JBQVMsQ0FBQ0MsS0FBSyxDQUFDSixHQUFHLENBQUM7SUFDcEIsSUFBQWYsY0FBTSxFQUFDcEQsbUJBQWMsQ0FBQyxDQUFDeUYscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQy9DLElBQUFyQyxjQUFNLEVBQUNwRCxtQkFBYyxDQUFDLENBQUN5RSxvQkFBb0IsQ0FBQztNQUMxQ2lCLFFBQVEsRUFBRSxRQUFRO01BQ2xCQyxTQUFTLEVBQUUsT0FBTztNQUNsQkMsVUFBVSxFQUFFO0lBQ2QsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxDQUFDO0VBRUYsSUFBQW5DLFVBQUUsRUFBQyxzRkFBc0YsRUFBRSxZQUFZO0lBQ3JHLE1BQU0rQixnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3hCO0lBQ0E7SUFDQTtJQUNBLElBQUlLLE1BQW1CO0lBQ3ZCbEcsVUFBRSxDQUFDMEMsTUFBTSxDQUFDckMsbUJBQWMsQ0FBQyxDQUFDdUMsa0JBQWtCLENBQzFDLE1BQU0sSUFBSXJCLE9BQU8sQ0FBUTRFLEdBQUcsSUFBSztNQUFFRCxNQUFNLEdBQUdDLEdBQUc7SUFBRSxDQUFDLENBQ3BELENBQUM7SUFDRCxNQUFNM0IsR0FBRyxHQUFHZCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0lBQy9EVSxnQkFBUyxDQUFDQyxLQUFLLENBQUNKLEdBQUcsQ0FBQztJQUNwQjtJQUNBLElBQUFmLGNBQU0sRUFBQ3BELG1CQUFjLENBQUMsQ0FBQ3lGLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUMvQ0ksTUFBTSxDQUFDLENBQUM7SUFDUixNQUFNLElBQUExQyxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQzBDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDakMsUUFBUSxDQUFDLENBQUMsQ0FBQztFQUN0RSxDQUFDLENBQUM7RUFFRixJQUFBTCxVQUFFLEVBQUMsZ0RBQWdELEVBQUUsWUFBWTtJQUMvRCxNQUFNK0IsZ0JBQWdCLENBQUMsQ0FBQztJQUN4QjdGLFVBQUUsQ0FBQzBDLE1BQU0sQ0FBQ3JDLG1CQUFjLENBQUMsQ0FBQ2dHLHFCQUFxQixDQUM3QzdHLE1BQU0sQ0FBQzhHLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMseUJBQXlCLENBQUMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQzNFLENBQUM7SUFDRCxNQUFNaEMsR0FBRyxHQUFHZCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0lBQy9EVSxnQkFBUyxDQUFDQyxLQUFLLENBQUNKLEdBQUcsQ0FBQztJQUNwQixNQUFNLElBQUFoQixjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDSSxXQUFXLENBQUMsQ0FBQ0csSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQyxpR0FBaUcsRUFBRSxZQUFZO0lBQ2hIO0lBQ0E7SUFDQWpELFdBQVcsQ0FBQ0UsSUFBSSxHQUFHLE1BQU1LLGVBQWUsQ0FBQyxNQUFPa0IsQ0FBQyxJQUFLO01BQ3BELE1BQU1BLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLE1BQU0sRUFBRSxlQUFlLENBQUM7TUFDdkMsTUFBTUQsQ0FBQyxDQUFDQyxNQUFNLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDeEMsQ0FBQyxDQUFDO0lBQ0YsSUFBQWUsYUFBTSxlQUFDLElBQUE5RSxXQUFBLENBQUErRSxHQUFBLEVBQUNuRixpQkFBQSxDQUFBUyxPQUFnQixJQUFFLENBQUMsQ0FBQztJQUM1QixNQUFNLElBQUEyRSxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDdEVlLGdCQUFTLENBQUNDLEtBQUssQ0FBQ2xCLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkRnQixnQkFBUyxDQUFDQyxLQUFLLENBQUNsQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUM7SUFDbEUsSUFBQVIsY0FBTSxFQUFDcEQsbUJBQWMsQ0FBQyxDQUFDZ0UsR0FBRyxDQUFDb0MsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxNQUFNLElBQUFqRCxjQUFPLEVBQUMsTUFDWixJQUFBQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDSSxXQUFXLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLG1CQUFtQixDQUM5RSxDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLG9EQUFvRCxFQUFFLFlBQVk7SUFDbkUsTUFBTStCLGdCQUFnQixDQUFDLENBQUM7SUFDeEIsTUFBTXJCLEdBQUcsR0FBR2QsYUFBTSxDQUFDTSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQztJQUMvRGpFLFVBQUUsQ0FBQzBDLE1BQU0sQ0FBQ3JDLG1CQUFjLENBQUMsQ0FBQ2dHLHFCQUFxQixDQUM3QzdHLE1BQU0sQ0FBQzhHLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMseUJBQXlCLENBQUMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQzNFLENBQUM7SUFDRDdCLGdCQUFTLENBQUNDLEtBQUssQ0FBQ0osR0FBRyxDQUFDO0lBQ3BCLE1BQU0sSUFBQWhCLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDTSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDckZ2RSxVQUFFLENBQUMwQyxNQUFNLENBQUNyQyxtQkFBYyxDQUFDLENBQUNxRyxxQkFBcUIsQ0FBQ0MsU0FBa0IsQ0FBQztJQUNuRWhDLGdCQUFTLENBQUNDLEtBQUssQ0FBQ0osR0FBRyxDQUFDO0lBQ3BCLE1BQU0sSUFBQWhCLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDMEMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNqQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQ3RFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}