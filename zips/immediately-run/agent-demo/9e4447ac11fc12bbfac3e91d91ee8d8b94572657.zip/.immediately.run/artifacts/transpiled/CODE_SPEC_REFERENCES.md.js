var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "code_spec_references-agent-demo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "code_spec_references-agent-demo"
      }), "CODE_SPEC_REFERENCES — agent-demo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Durable index of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-trivial"
      }), " code↔spec mappings. Seeded by the 2026-06\ncode-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), "). Trivial mappings are\ninline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "// <SPEC> §X"
      }), " comments."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "catalog-as-tools-the-load-bearing-one",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "catalog-as-tools-the-load-bearing-one"
      }), "Catalog-as-tools (the load-bearing one)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "LLM_AND_AGENTS_SPEC §3.3"
      }), " (the agent's tool list ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "is"
      }), " the\ngrant-filtered SDK method catalog) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS_SPEC §5.5"
      }), " (the method catalog)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "CLAUDE.md security rule #8. core_concepts §6 (Service) / §5 (Capability)."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping (non-obvious — a reader wouldn't rediscover the chain quickly):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SDK catalog (grant-filtered, ApiMethod[])\n  → catalogToolset(catalog)                 src/lib/toolset.ts\n  → catalogToTools() (ApiMethod → tool fmt, `:`↔`__` bijection)  src/lib/agentTools.ts\n  → createCatalogExecutor() (off-catalog call → forbidden, before invoke())  agentTools.ts\n  → mergeToolsets(catalogToolset(catalog), fsTools)  toolset.ts\n  → invoke()                                 host-brokered, gated again (§8.4)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The agent can therefore never exceed the app's grants: hallucinated/off-catalog\ntools are rejected at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "agentTools.ts"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "before"
      }), " reaching ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invoke()"
      }), ", and the host\nre-gates at use. There is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no hand-rolled tool that shells around the SDK"
      }), " —\nverified 2026-06. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CodingAgent.tsx"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ConversationStage.tsx"
      }), " instantiate the\nmerged toolset."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "2026-10-01 (R3-859 + R3-860; lands with site-main #663):"
      }), " once every host catalog method advertises a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "paramsSchema"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "catalogToTools"
      }), "'s\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PERMISSIVE_INPUT_SCHEMA"
      }), " fallback (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/agentTools.ts"
      }), ") is unreachable\nagainst the first-party host. Left in place deliberately: against a\nTHIRD-party host (an older or non-immediately.run catalog) the fallback is\nstill the shape. Do not delete it without a host-capability signal."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "byok-streaming-secrets",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "byok-streaming-secrets"
      }), "BYOK streaming + secrets"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "LLM_AND_AGENTS_SPEC §2.2"
      }), " (transport) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SECRETS_SPEC §6"
      }), " (secret\ninjection, never read by the app)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "claudeClient.ts"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "openaiClient.ts"
      }), " route every call through the\nhost fetch helper (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hostFetch"
      }), "); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "modelClient.ts"
      }), " sets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "streamImpl: null"
      }), "\n(SECRETS_SPEC §2.2 — the backend stream proxy never injects BYOK secrets, so\nstreaming is disabled by design). Secrets are injected host-side via\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "injectSecret"
      }), " (declared in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "requests.net:fetch.hosts"
      }), "), never\nread by the app. The dev/test-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "apiKey"
      }), " header paths are explicitly gated\n(\"prod relies on injectSecret\")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "netfetch-host-declaration-verified-2026-06",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "netfetch-host-declaration-verified-2026-06"
      }), "net:fetch host declaration (verified 2026-06)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " declares ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "two"
      }), " hosts and the code calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "both"
      }), ", with no\nundeclared host and no dead declaration:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "https://api.anthropic.com/v1/"
        }), " ← ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "claudeClient.ts"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/v1/messages"
        }), "),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "injectSecret { family: \"anthropic\", type: \"api-key\" }"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "x-api-key"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "https://openrouter.ai/api/v1/"
        }), " ← ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openaiClient.ts"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "modelClient.ts"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/api/v1/chat/completions"
        }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "injectSecret { type: \"bearer-token\" }"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "model-ids-verified-2026-06-against-the-claude-api-skill",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "model-ids-verified-2026-06-against-the-claude-api-skill"
      }), "Model ids (verified 2026-06 against the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "claude-api"
      }), " skill)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Anthropic default ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "claude-opus-4-8"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "claudeClient.ts"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "modelClient.ts"
        }), ") is\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "current"
        }), " Opus model id — not stale, no date suffix. Conforms."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["OpenRouter default ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openai/gpt-4o-mini"
        }), " is a non-Anthropic id (out of scope)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recorded-findings-code-verification-pass-2026-06",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recorded-findings-code-verification-pass-2026-06"
      }), "Recorded findings (code-verification pass, 2026-06)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "SDK-version skew (resolved 2026-09-15):"
        }), " agent-demo pinned\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.12.0"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "^0.68.0"
          })
        }), " by R3-559 (the checkpoint\njournal needs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openLocalStore()"
        }), " from R3-558; verified against sdk main and\nthe published 0.68.0). Recorded here because the old \"do NOT bump\" note is\nsuperseded — the coordinated fleet bump remains separate maintenance debt."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Vocabulary:"
        }), " no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kernel"
        }), " in comments; \"provider\" consistently the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "LLM service-provider"
        }), " sense (core_concepts §6), not app-identity — no rename\nneeded. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), " carries no app logic/CSS (CLAUDE.md conformant)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CODE_SPEC_REFERENCES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwiaHIiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDT0RFX1NQRUNfUkVGRVJFTkNFUy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJjb2RlX3NwZWNfcmVmZXJlbmNlcy1hZ2VudC1kZW1vXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb2RlX3NwZWNfcmVmZXJlbmNlcy1hZ2VudC1kZW1vXCIgLz57XCJDT0RFX1NQRUNfUkVGRVJFTkNFUyDigJQgYWdlbnQtZGVtb1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRHVyYWJsZSBpbmRleCBvZiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vbi10cml2aWFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGNvZGXihpRzcGVjIG1hcHBpbmdzLiBTZWVkZWQgYnkgdGhlIDIwMjYtMDZcXG5jb2RlLXZlcmlmaWNhdGlvbiBwYXNzIChSMy0xMjQ7IHBsYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMDgtc3lzdGVtLWFwcHMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVHJpdmlhbCBtYXBwaW5ncyBhcmVcXG5pbmxpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLy8gPFNQRUM+IMKnWFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tbWVudHMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNhdGFsb2ctYXMtdG9vbHMtdGhlLWxvYWQtYmVhcmluZy1vbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cImNhdGFsb2ctYXMtdG9vbHMtdGhlLWxvYWQtYmVhcmluZy1vbmVcIiAvPntcIkNhdGFsb2ctYXMtdG9vbHMgKHRoZSBsb2FkLWJlYXJpbmcgb25lKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTcGVjOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJMTE1fQU5EX0FHRU5UU19TUEVDIMKnMy4zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhlIGFnZW50J3MgdG9vbCBsaXN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlXFxuZ3JhbnQtZmlsdGVyZWQgU0RLIG1ldGhvZCBjYXRhbG9nKSArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlVJX0FTX0FQUFNfU1BFQyDCpzUuNVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBtZXRob2QgY2F0YWxvZylcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDTEFVREUubWQgc2VjdXJpdHkgcnVsZSAjOC4gY29yZV9jb25jZXB0cyDCpzYgKFNlcnZpY2UpIC8gwqc1IChDYXBhYmlsaXR5KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNYXBwaW5nIChub24tb2J2aW91cyDigJQgYSByZWFkZXIgd291bGRuJ3QgcmVkaXNjb3ZlciB0aGUgY2hhaW4gcXVpY2tseSk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wiU0RLIGNhdGFsb2cgKGdyYW50LWZpbHRlcmVkLCBBcGlNZXRob2RbXSlcXG4gIOKGkiBjYXRhbG9nVG9vbHNldChjYXRhbG9nKSAgICAgICAgICAgICAgICAgc3JjL2xpYi90b29sc2V0LnRzXFxuICDihpIgY2F0YWxvZ1RvVG9vbHMoKSAoQXBpTWV0aG9kIOKGkiB0b29sIGZtdCwgYDpg4oaUYF9fYCBiaWplY3Rpb24pICBzcmMvbGliL2FnZW50VG9vbHMudHNcXG4gIOKGkiBjcmVhdGVDYXRhbG9nRXhlY3V0b3IoKSAob2ZmLWNhdGFsb2cgY2FsbCDihpIgZm9yYmlkZGVuLCBiZWZvcmUgaW52b2tlKCkpICBhZ2VudFRvb2xzLnRzXFxuICDihpIgbWVyZ2VUb29sc2V0cyhjYXRhbG9nVG9vbHNldChjYXRhbG9nKSwgZnNUb29scykgIHRvb2xzZXQudHNcXG4gIOKGkiBpbnZva2UoKSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvc3QtYnJva2VyZWQsIGdhdGVkIGFnYWluICjCpzguNClcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGFnZW50IGNhbiB0aGVyZWZvcmUgbmV2ZXIgZXhjZWVkIHRoZSBhcHAncyBncmFudHM6IGhhbGx1Y2luYXRlZC9vZmYtY2F0YWxvZ1xcbnRvb2xzIGFyZSByZWplY3RlZCBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhZ2VudFRvb2xzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiYmVmb3JlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcmVhY2hpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgdGhlIGhvc3RcXG5yZS1nYXRlcyBhdCB1c2UuIFRoZXJlIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gaGFuZC1yb2xsZWQgdG9vbCB0aGF0IHNoZWxscyBhcm91bmQgdGhlIFNES1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJRcXG52ZXJpZmllZCAyMDI2LTA2LiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb2RpbmdBZ2VudC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ29udmVyc2F0aW9uU3RhZ2UudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbnN0YW50aWF0ZSB0aGVcXG5tZXJnZWQgdG9vbHNldC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIjIwMjYtMTAtMDEgKFIzLTg1OSArIFIzLTg2MDsgbGFuZHMgd2l0aCBzaXRlLW1haW4gIzY2Myk6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb25jZSBldmVyeSBob3N0IGNhdGFsb2cgbWV0aG9kIGFkdmVydGlzZXMgYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtc1NjaGVtYVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhdGFsb2dUb1Rvb2xzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUEVSTUlTU0lWRV9JTlBVVF9TQ0hFTUFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZhbGxiYWNrIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2FnZW50VG9vbHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBpcyB1bnJlYWNoYWJsZVxcbmFnYWluc3QgdGhlIGZpcnN0LXBhcnR5IGhvc3QuIExlZnQgaW4gcGxhY2UgZGVsaWJlcmF0ZWx5OiBhZ2FpbnN0IGFcXG5USElSRC1wYXJ0eSBob3N0IChhbiBvbGRlciBvciBub24taW1tZWRpYXRlbHkucnVuIGNhdGFsb2cpIHRoZSBmYWxsYmFjayBpc1xcbnN0aWxsIHRoZSBzaGFwZS4gRG8gbm90IGRlbGV0ZSBpdCB3aXRob3V0IGEgaG9zdC1jYXBhYmlsaXR5IHNpZ25hbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYnlvay1zdHJlYW1pbmctc2VjcmV0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYnlvay1zdHJlYW1pbmctc2VjcmV0c1wiIC8+e1wiQllPSyBzdHJlYW1pbmcgKyBzZWNyZXRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwZWM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkxMTV9BTkRfQUdFTlRTX1NQRUMgwqcyLjJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0cmFuc3BvcnQpICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU0VDUkVUU19TUEVDIMKnNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNlY3JldFxcbmluamVjdGlvbiwgbmV2ZXIgcmVhZCBieSB0aGUgYXBwKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNYXBwaW5nOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjbGF1ZGVDbGllbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbmFpQ2xpZW50LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByb3V0ZSBldmVyeSBjYWxsIHRocm91Z2ggdGhlXFxuaG9zdCBmZXRjaCBoZWxwZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImhvc3RGZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbENsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2V0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdHJlYW1JbXBsOiBudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbihTRUNSRVRTX1NQRUMgwqcyLjIg4oCUIHRoZSBiYWNrZW5kIHN0cmVhbSBwcm94eSBuZXZlciBpbmplY3RzIEJZT0sgc2VjcmV0cywgc29cXG5zdHJlYW1pbmcgaXMgZGlzYWJsZWQgYnkgZGVzaWduKS4gU2VjcmV0cyBhcmUgaW5qZWN0ZWQgaG9zdC1zaWRlIHZpYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGRlY2xhcmVkIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVxdWVzdHMubmV0OmZldGNoLmhvc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIG5ldmVyXFxucmVhZCBieSB0aGUgYXBwLiBUaGUgZGV2L3Rlc3Qtb25seSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcGlLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhlYWRlciBwYXRocyBhcmUgZXhwbGljaXRseSBnYXRlZFxcbihcXFwicHJvZCByZWxpZXMgb24gaW5qZWN0U2VjcmV0XFxcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm5ldGZldGNoLWhvc3QtZGVjbGFyYXRpb24tdmVyaWZpZWQtMjAyNi0wNlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibmV0ZmV0Y2gtaG9zdC1kZWNsYXJhdGlvbi12ZXJpZmllZC0yMDI2LTA2XCIgLz57XCJuZXQ6ZmV0Y2ggaG9zdCBkZWNsYXJhdGlvbiAodmVyaWZpZWQgMjAyNi0wNilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0d29cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaG9zdHMgYW5kIHRoZSBjb2RlIGNhbGxzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYm90aFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgd2l0aCBub1xcbnVuZGVjbGFyZWQgaG9zdCBhbmQgbm8gZGVhZCBkZWNsYXJhdGlvbjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL2FwaS5hbnRocm9waWMuY29tL3YxL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaQIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXVkZUNsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi92MS9tZXNzYWdlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldCB7IGZhbWlseTogXFxcImFudGhyb3BpY1xcXCIsIHR5cGU6IFxcXCJhcGkta2V5XFxcIiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieC1hcGkta2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL29wZW5yb3V0ZXIuYWkvYXBpL3YxL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaQIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5haUNsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbENsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2FwaS92MS9jaGF0L2NvbXBsZXRpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldCB7IHR5cGU6IFxcXCJiZWFyZXItdG9rZW5cXFwiIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJtb2RlbC1pZHMtdmVyaWZpZWQtMjAyNi0wNi1hZ2FpbnN0LXRoZS1jbGF1ZGUtYXBpLXNraWxsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJtb2RlbC1pZHMtdmVyaWZpZWQtMjAyNi0wNi1hZ2FpbnN0LXRoZS1jbGF1ZGUtYXBpLXNraWxsXCIgLz57XCJNb2RlbCBpZHMgKHZlcmlmaWVkIDIwMjYtMDYgYWdhaW5zdCB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2xhdWRlLWFwaVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2tpbGwpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkFudGhyb3BpYyBkZWZhdWx0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXVkZS1vcHVzLTQtOFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXVkZUNsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbENsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGlzXFxudGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY3VycmVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBPcHVzIG1vZGVsIGlkIOKAlCBub3Qgc3RhbGUsIG5vIGRhdGUgc3VmZml4LiBDb25mb3Jtcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJPcGVuUm91dGVyIGRlZmF1bHQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbmFpL2dwdC00by1taW5pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIG5vbi1BbnRocm9waWMgaWQgKG91dCBvZiBzY29wZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlY29yZGVkLWZpbmRpbmdzLWNvZGUtdmVyaWZpY2F0aW9uLXBhc3MtMjAyNi0wNlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVjb3JkZWQtZmluZGluZ3MtY29kZS12ZXJpZmljYXRpb24tcGFzcy0yMDI2LTA2XCIgLz57XCJSZWNvcmRlZCBmaW5kaW5ncyAoY29kZS12ZXJpZmljYXRpb24gcGFzcywgMjAyNi0wNilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTREstdmVyc2lvbiBza2V3IChyZXNvbHZlZCAyMDI2LTA5LTE1KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYWdlbnQtZGVtbyBwaW5uZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTIuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuNjguMFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgYnkgUjMtNTU5ICh0aGUgY2hlY2twb2ludFxcbmpvdXJuYWwgbmVlZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkxvY2FsU3RvcmUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZnJvbSBSMy01NTg7IHZlcmlmaWVkIGFnYWluc3Qgc2RrIG1haW4gYW5kXFxudGhlIHB1Ymxpc2hlZCAwLjY4LjApLiBSZWNvcmRlZCBoZXJlIGJlY2F1c2UgdGhlIG9sZCBcXFwiZG8gTk9UIGJ1bXBcXFwiIG5vdGUgaXNcXG5zdXBlcnNlZGVkIOKAlCB0aGUgY29vcmRpbmF0ZWQgZmxlZXQgYnVtcCByZW1haW5zIHNlcGFyYXRlIG1haW50ZW5hbmNlIGRlYnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJWb2NhYnVsYXJ5OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJrZXJuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGNvbW1lbnRzOyBcXFwicHJvdmlkZXJcXFwiIGNvbnNpc3RlbnRseSB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkxMTSBzZXJ2aWNlLXByb3ZpZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNlbnNlIChjb3JlX2NvbmNlcHRzIMKnNiksIG5vdCBhcHAtaWRlbnRpdHkg4oCUIG5vIHJlbmFtZVxcbm5lZWRlZC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgbm8gYXBwIGxvZ2ljL0NTUyAoQ0xBVURFLm1kIGNvbmZvcm1hbnQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvQ09ERV9TUEVDX1JFRkVSRU5DRVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyxpQ0FBaUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQyxDQUFFLENBQUMsRUFBQyxtQ0FBbUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsbUZBQW1GLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsWUFBWTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1QyxDQUFFLENBQUMsRUFBQyx5Q0FBeUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUEyRSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBeUUsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWtiLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxHQUFFLHlHQUF5RyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBUSxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFnRCxDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyxtQ0FBbUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLEVBQUU7UUFBQWUsUUFBQSxFQUFFO01BQTBELENBQWlCLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsd09BQXdPO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHdCQUF3QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXdCLENBQUUsQ0FBQyxFQUFDLDBCQUEwQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyx3SkFBd0osZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyx3RUFBd0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEMsQ0FBRSxDQUFDLEVBQUMsK0NBQStDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBMkQsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXlDLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMseURBQXlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUQsQ0FBRSxDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsdURBQXVEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsd0NBQXdDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFSLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyxrREFBa0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRCxDQUFFLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFTLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsdU1BQXVNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXNCLENBQXFCLENBQUMsRUFBQyxtRUFBbUUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsbURBQW1EO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3IvUDtBQUNlLFNBQVNHLFVBQVVBLENBQUNyQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDc0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1osS0FBSyxDQUFDYTtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUF6QixXQUFBLENBQUFzQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLdkIsS0FBSztJQUFBa0IsUUFBQSxlQUFFLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNyQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDd0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}