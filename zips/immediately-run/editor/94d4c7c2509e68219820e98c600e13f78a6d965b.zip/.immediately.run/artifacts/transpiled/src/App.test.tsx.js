var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
var _vitest = require("vitest");
var _react = require("@testing-library/react");
var _App = _interopRequireDefault(require("./App"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// React-surface smoke tests for the editor app. The SDK channels and the
// working-tree port are mocked so the readiness states (§12.7) render without a
// live sandbox. The decision logic itself is covered by the pure core suites
// (buffer / readiness / diagnostics / debounce).

// --- SDK mock ---------------------------------------------------------------
const editorContext = {
  activeFile: null,
  openFiles: [],
  dirtyPaths: []
};
// R3-827 — mutable so the light case can flip what useHostTheme returns.
const hostTheme = {
  current: "dark"
};
const mounts = [];

// R3-388 — the subpath the caret listener rides. The REAL `sandboxUtils` cannot load
// under vitest (tsup emits extensionless specifiers), which the file explorer's suite
// records for the same import. Mocking it also gives this suite a controllable
// host→app channel.
const rawListeners = new Map();
_vitest.vi.mock("@immediately-run/sdk/sandboxUtils", () => ({
  addListener: (type, handler) => {
    const set = rawListeners.get(type) ?? new Set();
    set.add(handler);
    rawListeners.set(type, set);
    readyOrder.push(`subscribe:${type}`);
    return () => set.delete(handler);
  }
}));

// R3-392 — the app's readiness report is the host's gate for releasing a caret
// request to a frame that was still booting when the user clicked. The real module
// imports the real `sandboxUtils` (same extensionless specifier), so mock it, and
// record its order relative to the listener subscription: "ready" must mean
// "listening", or the released one-shot is lost exactly as before.
const readyOrder = [];
_vitest.vi.mock("@immediately-run/sdk/ready", () => ({
  reportReady: () => {
    readyOrder.push("ready");
  }
}));
_vitest.vi.mock("@immediately-run/sdk", () => ({
  useEditorContext: () => editorContext,
  useHostTheme: () => hostTheme.current,
  useFormFactor: () => ({
    class: "desktop",
    orientation: "landscape",
    width: 1280,
    height: 800
  }),
  useDiagnostics: () => ({
    buildErrors: [],
    consoleEntries: [],
    provenance: null
  }),
  useMounts: () => mounts,
  getMounts: () => mounts,
  getAppMountPath: () => "/app",
  setActiveFile: _vitest.vi.fn(() => Promise.resolve()),
  closeFile: _vitest.vi.fn(() => Promise.resolve()),
  // The fs-change subscription captures its listener; a test emits a batch by
  // calling every captured listener (see the R3-804 re-read case).
  onFsChange: _vitest.vi.fn(listener => {
    fsChangeListeners.add(listener);
    return () => fsChangeListeners.delete(listener);
  })
}));

// Captured onFsChange listeners (the SDK mock above adds/removes here).
const fsChangeListeners = new Set();

// --- working-tree port mock --------------------------------------------------
const fs = {
  available: false,
  files: new Map(),
  bytes: new Map(),
  textReads: []
};
_vitest.vi.mock("./fs/mountFs", () => ({
  fsAvailable: () => fs.available,
  readFileText: p => {
    fs.textReads.push(p);
    return fs.files.has(p) ? Promise.resolve(fs.files.get(p)) : Promise.reject(new Error("ENOENT"));
  },
  readFileBytes: p => fs.bytes.has(p) ? Promise.resolve(fs.bytes.get(p)) : Promise.reject(new Error("ENOENT")),
  writeFileText: (p, t) => {
    fs.files.set(p, t);
    return Promise.resolve();
  },
  exists: p => Promise.resolve(fs.files.has(p) || fs.bytes.has(p))
}));
(0, _vitest.beforeEach)(() => {
  hostTheme.current = "dark";
  editorContext.activeFile = null;
  editorContext.openFiles = [];
  editorContext.dirtyPaths = [];
  fs.available = false;
  fs.files.clear();
  fs.bytes.clear();
  fs.textReads.length = 0;
  fsChangeListeners.clear();
});
(0, _vitest.describe)("R3-827 — the host theme reaches the palette", () => {
  (0, _vitest.it)("sets data-theme='light' on .editor-app when the host polarity is light", () => {
    hostTheme.current = "light";
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(container.querySelector(".editor-app")).toHaveAttribute("data-theme", "light");
  });
  (0, _vitest.it)("carries dark when the host polarity is dark", () => {
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(container.querySelector(".editor-app")).toHaveAttribute("data-theme", "dark");
  });
});
(0, _vitest.describe)("R3-392 — readiness report gates caret delivery", () => {
  (0, _vitest.it)("reports ready to the host only AFTER the caret listener is subscribed", () => {
    readyOrder.length = 0;
    fs.available = true;
    editorContext.activeFile = "/src/App.tsx";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(readyOrder).toContain("ready");
    (0, _vitest.expect)(readyOrder.indexOf("subscribe:editor-selection")).toBeGreaterThanOrEqual(0);
    (0, _vitest.expect)(readyOrder.indexOf("subscribe:editor-selection")).toBeLessThan(readyOrder.indexOf("ready"));
  });
});
(0, _vitest.describe)("App readiness states", () => {
  (0, _vitest.it)('shows "awaiting port" when the working tree has not attached', () => {
    fs.available = false;
    editorContext.activeFile = "/src/App.tsx";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(_react.screen.getByText(/connecting to the working tree/i)).toBeInTheDocument();
  });
  (0, _vitest.it)('shows "no file open" when the port is up but nothing is focused', () => {
    fs.available = true;
    editorContext.activeFile = null;
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(_react.screen.getByText(/no file open/i)).toBeInTheDocument();
  });
  (0, _vitest.it)("does not render a tab strip for the open files", () => {
    fs.available = true;
    editorContext.openFiles = ["/src/App.tsx", "/src/main.tsx"];
    editorContext.activeFile = "/src/App.tsx";
    fs.files.set("/app/src/App.tsx", "export default 1;");
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(_react.screen.queryByRole("tablist")).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByText("main.tsx")).not.toBeInTheDocument();
  });
});
(0, _vitest.describe)("R3-804 — image overlay", () => {
  (0, _vitest.it)("shows an image file as an image, never through the text buffer", async () => {
    fs.available = true;
    fs.bytes.set("/app/assets/logo.png", new Uint8Array([137, 80, 78, 71]));
    editorContext.activeFile = "/assets/logo.png";
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const img = await _react.screen.findByRole("img", {
      name: "logo.png"
    });
    (0, _vitest.expect)(img).toHaveAttribute("src", _vitest.expect.stringMatching(/^blob:/));
    // The bytes never went through the UTF-8 text read, and no editor mounted.
    (0, _vitest.expect)(fs.textReads).not.toContain("/app/assets/logo.png");
    (0, _vitest.expect)(container.querySelector(".cm-host")).not.toBeInTheDocument();
    // R-IX-7 — the settle is announced through a live region, not only painted.
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent("Showing image logo.png");
    // The caption names the file and the read-only truth.
    (0, _vitest.expect)(container.querySelector(".ed-image-caption")).toHaveTextContent("logo.png");
    (0, _vitest.expect)(container.querySelector(".ed-image-caption")).toHaveTextContent("read-only");
  });
  (0, _vitest.it)("keeps the EditorView mounted under the overlay across text→image→text", async () => {
    fs.available = true;
    fs.files.set("/app/src/App.tsx", "export default 1;");
    fs.bytes.set("/app/assets/logo.png", new Uint8Array([1, 2, 3]));
    editorContext.activeFile = "/src/App.tsx";
    const {
      container,
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    await _vitest.vi.waitFor(() => {
      (0, _vitest.expect)(container.querySelector(".cm-host")).toHaveTextContent("export default 1");
    });
    const hostBefore = container.querySelector(".cm-host");

    // Switch to the image: the overlay covers the SAME editor host, which is
    // now inert and hidden from the accessibility tree — not unmounted.
    editorContext.activeFile = "/assets/logo.png";
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    await _react.screen.findByRole("img", {
      name: "logo.png"
    });
    const wrap = container.querySelector(".ed-cm-wrap");
    (0, _vitest.expect)(wrap).toHaveAttribute("inert");
    (0, _vitest.expect)(wrap).toHaveAttribute("aria-hidden", "true");
    (0, _vitest.expect)(container.querySelector(".cm-host")).toBe(hostBefore);

    // Switch back: the overlay lifts, the editor is usable, and it is still
    // the same host node — no teardown/buildup happened anywhere.
    editorContext.activeFile = "/src/App.tsx";
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    await _vitest.vi.waitFor(() => {
      (0, _vitest.expect)(container.querySelector(".ed-cm-wrap")).not.toHaveAttribute("inert");
    });
    (0, _vitest.expect)(container.querySelector(".cm-host")).toBe(hostBefore);
    (0, _vitest.expect)(_react.screen.queryByRole("img")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("a failed image read names the path when the file still exists", async () => {
    fs.available = true;
    // Present to exists() via the text map, unreadable as bytes.
    fs.files.set("/app/assets/logo.png", "not really an image");
    editorContext.activeFile = "/assets/logo.png";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    await _react.screen.findByText(/could not open this file/i);
    (0, _vitest.expect)(_react.screen.getByText(/\/assets\/logo\.png/)).toBeInTheDocument();
  });
  (0, _vitest.it)("a missing image gets the vanished state, not mojibake", async () => {
    fs.available = true;
    editorContext.activeFile = "/assets/gone.png";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    await _react.screen.findByText(/this file was removed/i);
    (0, _vitest.expect)(_react.screen.getByText(/deleted or renamed elsewhere/i)).toBeInTheDocument();
  });
  (0, _vitest.it)("re-reads and re-renders the shown image on an fs-change batch (R-IX-4)", async () => {
    fs.available = true;
    fs.bytes.set("/app/assets/logo.png", new Uint8Array([1]));
    editorContext.activeFile = "/assets/logo.png";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const img = await _react.screen.findByRole("img", {
      name: "logo.png"
    });
    const srcBefore = img.getAttribute("src");

    // An external write to the shown image: the host's batch names its path.
    fs.bytes.set("/app/assets/logo.png", new Uint8Array([2, 2]));
    (0, _react.act)(() => {
      fsChangeListeners.forEach(l => l({
        paths: ["/assets/logo.png"],
        epoch: 1
      }));
    });

    // The re-read builds a NEW object URL (the setup stub is counter-backed),
    // so a swapped src proves the re-render; the old one was revoked.
    await _vitest.vi.waitFor(() => {
      (0, _vitest.expect)(_react.screen.getByRole("img", {
        name: "logo.png"
      }).getAttribute("src")).not.toBe(srcBefore);
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9BcHAiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJlZGl0b3JDb250ZXh0IiwiYWN0aXZlRmlsZSIsIm9wZW5GaWxlcyIsImRpcnR5UGF0aHMiLCJob3N0VGhlbWUiLCJjdXJyZW50IiwibW91bnRzIiwicmF3TGlzdGVuZXJzIiwiTWFwIiwidmkiLCJtb2NrIiwiYWRkTGlzdGVuZXIiLCJ0eXBlIiwiaGFuZGxlciIsInNldCIsImdldCIsIlNldCIsImFkZCIsInJlYWR5T3JkZXIiLCJwdXNoIiwiZGVsZXRlIiwicmVwb3J0UmVhZHkiLCJ1c2VFZGl0b3JDb250ZXh0IiwidXNlSG9zdFRoZW1lIiwidXNlRm9ybUZhY3RvciIsImNsYXNzIiwib3JpZW50YXRpb24iLCJ3aWR0aCIsImhlaWdodCIsInVzZURpYWdub3N0aWNzIiwiYnVpbGRFcnJvcnMiLCJjb25zb2xlRW50cmllcyIsInByb3ZlbmFuY2UiLCJ1c2VNb3VudHMiLCJnZXRNb3VudHMiLCJnZXRBcHBNb3VudFBhdGgiLCJzZXRBY3RpdmVGaWxlIiwiZm4iLCJQcm9taXNlIiwicmVzb2x2ZSIsImNsb3NlRmlsZSIsIm9uRnNDaGFuZ2UiLCJsaXN0ZW5lciIsImZzQ2hhbmdlTGlzdGVuZXJzIiwiZnMiLCJhdmFpbGFibGUiLCJmaWxlcyIsImJ5dGVzIiwidGV4dFJlYWRzIiwiZnNBdmFpbGFibGUiLCJyZWFkRmlsZVRleHQiLCJwIiwiaGFzIiwicmVqZWN0IiwiRXJyb3IiLCJyZWFkRmlsZUJ5dGVzIiwid3JpdGVGaWxlVGV4dCIsInQiLCJleGlzdHMiLCJiZWZvcmVFYWNoIiwiY2xlYXIiLCJsZW5ndGgiLCJkZXNjcmliZSIsIml0IiwiY29udGFpbmVyIiwicmVuZGVyIiwianN4IiwiZXhwZWN0IiwicXVlcnlTZWxlY3RvciIsInRvSGF2ZUF0dHJpYnV0ZSIsInRvQ29udGFpbiIsImluZGV4T2YiLCJ0b0JlR3JlYXRlclRoYW5PckVxdWFsIiwidG9CZUxlc3NUaGFuIiwic2NyZWVuIiwiZ2V0QnlUZXh0IiwidG9CZUluVGhlRG9jdW1lbnQiLCJxdWVyeUJ5Um9sZSIsIm5vdCIsInF1ZXJ5QnlUZXh0IiwiVWludDhBcnJheSIsImltZyIsImZpbmRCeVJvbGUiLCJuYW1lIiwic3RyaW5nTWF0Y2hpbmciLCJnZXRCeVJvbGUiLCJ0b0hhdmVUZXh0Q29udGVudCIsInJlcmVuZGVyIiwid2FpdEZvciIsImhvc3RCZWZvcmUiLCJ3cmFwIiwidG9CZSIsImZpbmRCeVRleHQiLCJzcmNCZWZvcmUiLCJnZXRBdHRyaWJ1dGUiLCJhY3QiLCJmb3JFYWNoIiwibCIsInBhdGhzIiwiZXBvY2giXSwic291cmNlcyI6WyJBcHAudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUmVhY3Qtc3VyZmFjZSBzbW9rZSB0ZXN0cyBmb3IgdGhlIGVkaXRvciBhcHAuIFRoZSBTREsgY2hhbm5lbHMgYW5kIHRoZVxuLy8gd29ya2luZy10cmVlIHBvcnQgYXJlIG1vY2tlZCBzbyB0aGUgcmVhZGluZXNzIHN0YXRlcyAowqcxMi43KSByZW5kZXIgd2l0aG91dCBhXG4vLyBsaXZlIHNhbmRib3guIFRoZSBkZWNpc2lvbiBsb2dpYyBpdHNlbGYgaXMgY292ZXJlZCBieSB0aGUgcHVyZSBjb3JlIHN1aXRlc1xuLy8gKGJ1ZmZlciAvIHJlYWRpbmVzcyAvIGRpYWdub3N0aWNzIC8gZGVib3VuY2UpLlxuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCwgdmksIGJlZm9yZUVhY2ggfSBmcm9tIFwidml0ZXN0XCI7XG5pbXBvcnQgeyBhY3QsIHJlbmRlciwgc2NyZWVuIH0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcblxuLy8gLS0tIFNESyBtb2NrIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuY29uc3QgZWRpdG9yQ29udGV4dCA9IHtcbiAgYWN0aXZlRmlsZTogbnVsbCBhcyBzdHJpbmcgfCBudWxsLFxuICBvcGVuRmlsZXM6IFtdIGFzIHN0cmluZ1tdLFxuICBkaXJ0eVBhdGhzOiBbXSBhcyBzdHJpbmdbXSxcbn07XG4vLyBSMy04Mjcg4oCUIG11dGFibGUgc28gdGhlIGxpZ2h0IGNhc2UgY2FuIGZsaXAgd2hhdCB1c2VIb3N0VGhlbWUgcmV0dXJucy5cbmNvbnN0IGhvc3RUaGVtZSA9IHsgY3VycmVudDogXCJkYXJrXCIgYXMgXCJkYXJrXCIgfCBcImxpZ2h0XCIgfTtcbmNvbnN0IG1vdW50czogdW5rbm93bltdID0gW107XG5cbi8vIFIzLTM4OCDigJQgdGhlIHN1YnBhdGggdGhlIGNhcmV0IGxpc3RlbmVyIHJpZGVzLiBUaGUgUkVBTCBgc2FuZGJveFV0aWxzYCBjYW5ub3QgbG9hZFxuLy8gdW5kZXIgdml0ZXN0ICh0c3VwIGVtaXRzIGV4dGVuc2lvbmxlc3Mgc3BlY2lmaWVycyksIHdoaWNoIHRoZSBmaWxlIGV4cGxvcmVyJ3Mgc3VpdGVcbi8vIHJlY29yZHMgZm9yIHRoZSBzYW1lIGltcG9ydC4gTW9ja2luZyBpdCBhbHNvIGdpdmVzIHRoaXMgc3VpdGUgYSBjb250cm9sbGFibGVcbi8vIGhvc3TihpJhcHAgY2hhbm5lbC5cbmNvbnN0IHJhd0xpc3RlbmVycyA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8KG06IHVua25vd24pID0+IHZvaWQ+PigpO1xudmkubW9jayhcIkBpbW1lZGlhdGVseS1ydW4vc2RrL3NhbmRib3hVdGlsc1wiLCAoKSA9PiAoe1xuICBhZGRMaXN0ZW5lcjogKHR5cGU6IHN0cmluZywgaGFuZGxlcjogKG06IHVua25vd24pID0+IHZvaWQpID0+IHtcbiAgICBjb25zdCBzZXQgPSByYXdMaXN0ZW5lcnMuZ2V0KHR5cGUpID8/IG5ldyBTZXQ8KG06IHVua25vd24pID0+IHZvaWQ+KCk7XG4gICAgc2V0LmFkZChoYW5kbGVyKTtcbiAgICByYXdMaXN0ZW5lcnMuc2V0KHR5cGUsIHNldCk7XG4gICAgcmVhZHlPcmRlci5wdXNoKGBzdWJzY3JpYmU6JHt0eXBlfWApO1xuICAgIHJldHVybiAoKSA9PiBzZXQuZGVsZXRlKGhhbmRsZXIpO1xuICB9LFxufSkpO1xuXG4vLyBSMy0zOTIg4oCUIHRoZSBhcHAncyByZWFkaW5lc3MgcmVwb3J0IGlzIHRoZSBob3N0J3MgZ2F0ZSBmb3IgcmVsZWFzaW5nIGEgY2FyZXRcbi8vIHJlcXVlc3QgdG8gYSBmcmFtZSB0aGF0IHdhcyBzdGlsbCBib290aW5nIHdoZW4gdGhlIHVzZXIgY2xpY2tlZC4gVGhlIHJlYWwgbW9kdWxlXG4vLyBpbXBvcnRzIHRoZSByZWFsIGBzYW5kYm94VXRpbHNgIChzYW1lIGV4dGVuc2lvbmxlc3Mgc3BlY2lmaWVyKSwgc28gbW9jayBpdCwgYW5kXG4vLyByZWNvcmQgaXRzIG9yZGVyIHJlbGF0aXZlIHRvIHRoZSBsaXN0ZW5lciBzdWJzY3JpcHRpb246IFwicmVhZHlcIiBtdXN0IG1lYW5cbi8vIFwibGlzdGVuaW5nXCIsIG9yIHRoZSByZWxlYXNlZCBvbmUtc2hvdCBpcyBsb3N0IGV4YWN0bHkgYXMgYmVmb3JlLlxuY29uc3QgcmVhZHlPcmRlcjogc3RyaW5nW10gPSBbXTtcbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9yZWFkeVwiLCAoKSA9PiAoe1xuICByZXBvcnRSZWFkeTogKCkgPT4ge1xuICAgIHJlYWR5T3JkZXIucHVzaChcInJlYWR5XCIpO1xuICB9LFxufSkpO1xuXG52aS5tb2NrKFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIiwgKCkgPT4gKHtcbiAgdXNlRWRpdG9yQ29udGV4dDogKCkgPT4gZWRpdG9yQ29udGV4dCxcbiAgdXNlSG9zdFRoZW1lOiAoKSA9PiBob3N0VGhlbWUuY3VycmVudCxcbiAgdXNlRm9ybUZhY3RvcjogKCkgPT4gKHtcbiAgICBjbGFzczogXCJkZXNrdG9wXCIsXG4gICAgb3JpZW50YXRpb246IFwibGFuZHNjYXBlXCIsXG4gICAgd2lkdGg6IDEyODAsXG4gICAgaGVpZ2h0OiA4MDAsXG4gIH0pLFxuICB1c2VEaWFnbm9zdGljczogKCkgPT4gKHtcbiAgICBidWlsZEVycm9yczogW10sXG4gICAgY29uc29sZUVudHJpZXM6IFtdLFxuICAgIHByb3ZlbmFuY2U6IG51bGwsXG4gIH0pLFxuICB1c2VNb3VudHM6ICgpID0+IG1vdW50cyxcbiAgZ2V0TW91bnRzOiAoKSA9PiBtb3VudHMsXG4gIGdldEFwcE1vdW50UGF0aDogKCkgPT4gXCIvYXBwXCIsXG4gIHNldEFjdGl2ZUZpbGU6IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKSxcbiAgY2xvc2VGaWxlOiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIC8vIFRoZSBmcy1jaGFuZ2Ugc3Vic2NyaXB0aW9uIGNhcHR1cmVzIGl0cyBsaXN0ZW5lcjsgYSB0ZXN0IGVtaXRzIGEgYmF0Y2ggYnlcbiAgLy8gY2FsbGluZyBldmVyeSBjYXB0dXJlZCBsaXN0ZW5lciAoc2VlIHRoZSBSMy04MDQgcmUtcmVhZCBjYXNlKS5cbiAgb25Gc0NoYW5nZTogdmkuZm4oKGxpc3RlbmVyOiAoYzogeyBwYXRoczogc3RyaW5nW107IGVwb2NoOiBudW1iZXIgfSkgPT4gdm9pZCkgPT4ge1xuICAgIGZzQ2hhbmdlTGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG4gICAgcmV0dXJuICgpID0+IGZzQ2hhbmdlTGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG4gIH0pLFxufSkpO1xuXG4vLyBDYXB0dXJlZCBvbkZzQ2hhbmdlIGxpc3RlbmVycyAodGhlIFNESyBtb2NrIGFib3ZlIGFkZHMvcmVtb3ZlcyBoZXJlKS5cbmNvbnN0IGZzQ2hhbmdlTGlzdGVuZXJzID0gbmV3IFNldDxcbiAgKGM6IHsgcGF0aHM6IHN0cmluZ1tdOyBlcG9jaDogbnVtYmVyIH0pID0+IHZvaWRcbj4oKTtcblxuLy8gLS0tIHdvcmtpbmctdHJlZSBwb3J0IG1vY2sgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmNvbnN0IGZzID0ge1xuICBhdmFpbGFibGU6IGZhbHNlLFxuICBmaWxlczogbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKSxcbiAgYnl0ZXM6IG5ldyBNYXA8c3RyaW5nLCBVaW50OEFycmF5PigpLFxuICB0ZXh0UmVhZHM6IFtdIGFzIHN0cmluZ1tdLFxufTtcbnZpLm1vY2soXCIuL2ZzL21vdW50RnNcIiwgKCkgPT4gKHtcbiAgZnNBdmFpbGFibGU6ICgpID0+IGZzLmF2YWlsYWJsZSxcbiAgcmVhZEZpbGVUZXh0OiAocDogc3RyaW5nKSA9PiB7XG4gICAgZnMudGV4dFJlYWRzLnB1c2gocCk7XG4gICAgcmV0dXJuIGZzLmZpbGVzLmhhcyhwKVxuICAgICAgPyBQcm9taXNlLnJlc29sdmUoZnMuZmlsZXMuZ2V0KHApISlcbiAgICAgIDogUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKFwiRU5PRU5UXCIpKTtcbiAgfSxcbiAgcmVhZEZpbGVCeXRlczogKHA6IHN0cmluZykgPT5cbiAgICBmcy5ieXRlcy5oYXMocClcbiAgICAgID8gUHJvbWlzZS5yZXNvbHZlKGZzLmJ5dGVzLmdldChwKSEpXG4gICAgICA6IFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcIkVOT0VOVFwiKSksXG4gIHdyaXRlRmlsZVRleHQ6IChwOiBzdHJpbmcsIHQ6IHN0cmluZykgPT4ge1xuICAgIGZzLmZpbGVzLnNldChwLCB0KTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gIH0sXG4gIGV4aXN0czogKHA6IHN0cmluZykgPT4gUHJvbWlzZS5yZXNvbHZlKGZzLmZpbGVzLmhhcyhwKSB8fCBmcy5ieXRlcy5oYXMocCkpLFxufSkpO1xuXG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcFwiO1xuXG5iZWZvcmVFYWNoKCgpID0+IHtcbiAgaG9zdFRoZW1lLmN1cnJlbnQgPSBcImRhcmtcIjtcbiAgZWRpdG9yQ29udGV4dC5hY3RpdmVGaWxlID0gbnVsbDtcbiAgZWRpdG9yQ29udGV4dC5vcGVuRmlsZXMgPSBbXTtcbiAgZWRpdG9yQ29udGV4dC5kaXJ0eVBhdGhzID0gW107XG4gIGZzLmF2YWlsYWJsZSA9IGZhbHNlO1xuICBmcy5maWxlcy5jbGVhcigpO1xuICBmcy5ieXRlcy5jbGVhcigpO1xuICBmcy50ZXh0UmVhZHMubGVuZ3RoID0gMDtcbiAgZnNDaGFuZ2VMaXN0ZW5lcnMuY2xlYXIoKTtcbn0pO1xuXG5kZXNjcmliZShcIlIzLTgyNyDigJQgdGhlIGhvc3QgdGhlbWUgcmVhY2hlcyB0aGUgcGFsZXR0ZVwiLCAoKSA9PiB7XG4gIGl0KFwic2V0cyBkYXRhLXRoZW1lPSdsaWdodCcgb24gLmVkaXRvci1hcHAgd2hlbiB0aGUgaG9zdCBwb2xhcml0eSBpcyBsaWdodFwiLCAoKSA9PiB7XG4gICAgaG9zdFRoZW1lLmN1cnJlbnQgPSBcImxpZ2h0XCI7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8QXBwIC8+KTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoXCIuZWRpdG9yLWFwcFwiKSkudG9IYXZlQXR0cmlidXRlKFwiZGF0YS10aGVtZVwiLCBcImxpZ2h0XCIpO1xuICB9KTtcblxuICBpdChcImNhcnJpZXMgZGFyayB3aGVuIHRoZSBob3N0IHBvbGFyaXR5IGlzIGRhcmtcIiwgKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSByZW5kZXIoPEFwcCAvPik7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKFwiLmVkaXRvci1hcHBcIikpLnRvSGF2ZUF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIiwgXCJkYXJrXCIpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIlIzLTM5MiDigJQgcmVhZGluZXNzIHJlcG9ydCBnYXRlcyBjYXJldCBkZWxpdmVyeVwiLCAoKSA9PiB7XG4gIGl0KFwicmVwb3J0cyByZWFkeSB0byB0aGUgaG9zdCBvbmx5IEFGVEVSIHRoZSBjYXJldCBsaXN0ZW5lciBpcyBzdWJzY3JpYmVkXCIsICgpID0+IHtcbiAgICByZWFkeU9yZGVyLmxlbmd0aCA9IDA7XG4gICAgZnMuYXZhaWxhYmxlID0gdHJ1ZTtcbiAgICBlZGl0b3JDb250ZXh0LmFjdGl2ZUZpbGUgPSBcIi9zcmMvQXBwLnRzeFwiO1xuICAgIHJlbmRlcig8QXBwIC8+KTtcbiAgICBleHBlY3QocmVhZHlPcmRlcikudG9Db250YWluKFwicmVhZHlcIik7XG4gICAgZXhwZWN0KHJlYWR5T3JkZXIuaW5kZXhPZihcInN1YnNjcmliZTplZGl0b3Itc2VsZWN0aW9uXCIpKS50b0JlR3JlYXRlclRoYW5PckVxdWFsKDApO1xuICAgIGV4cGVjdChyZWFkeU9yZGVyLmluZGV4T2YoXCJzdWJzY3JpYmU6ZWRpdG9yLXNlbGVjdGlvblwiKSkudG9CZUxlc3NUaGFuKFxuICAgICAgcmVhZHlPcmRlci5pbmRleE9mKFwicmVhZHlcIiksXG4gICAgKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJBcHAgcmVhZGluZXNzIHN0YXRlc1wiLCAoKSA9PiB7XG4gIGl0KCdzaG93cyBcImF3YWl0aW5nIHBvcnRcIiB3aGVuIHRoZSB3b3JraW5nIHRyZWUgaGFzIG5vdCBhdHRhY2hlZCcsICgpID0+IHtcbiAgICBmcy5hdmFpbGFibGUgPSBmYWxzZTtcbiAgICBlZGl0b3JDb250ZXh0LmFjdGl2ZUZpbGUgPSBcIi9zcmMvQXBwLnRzeFwiO1xuICAgIHJlbmRlcig8QXBwIC8+KTtcbiAgICBleHBlY3QoXG4gICAgICBzY3JlZW4uZ2V0QnlUZXh0KC9jb25uZWN0aW5nIHRvIHRoZSB3b3JraW5nIHRyZWUvaSksXG4gICAgKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdCgnc2hvd3MgXCJubyBmaWxlIG9wZW5cIiB3aGVuIHRoZSBwb3J0IGlzIHVwIGJ1dCBub3RoaW5nIGlzIGZvY3VzZWQnLCAoKSA9PiB7XG4gICAgZnMuYXZhaWxhYmxlID0gdHJ1ZTtcbiAgICBlZGl0b3JDb250ZXh0LmFjdGl2ZUZpbGUgPSBudWxsO1xuICAgIHJlbmRlcig8QXBwIC8+KTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgvbm8gZmlsZSBvcGVuL2kpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcImRvZXMgbm90IHJlbmRlciBhIHRhYiBzdHJpcCBmb3IgdGhlIG9wZW4gZmlsZXNcIiwgKCkgPT4ge1xuICAgIGZzLmF2YWlsYWJsZSA9IHRydWU7XG4gICAgZWRpdG9yQ29udGV4dC5vcGVuRmlsZXMgPSBbXCIvc3JjL0FwcC50c3hcIiwgXCIvc3JjL21haW4udHN4XCJdO1xuICAgIGVkaXRvckNvbnRleHQuYWN0aXZlRmlsZSA9IFwiL3NyYy9BcHAudHN4XCI7XG4gICAgZnMuZmlsZXMuc2V0KFwiL2FwcC9zcmMvQXBwLnRzeFwiLCBcImV4cG9ydCBkZWZhdWx0IDE7XCIpO1xuICAgIHJlbmRlcig8QXBwIC8+KTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwidGFibGlzdFwiKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcIm1haW4udHN4XCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJSMy04MDQg4oCUIGltYWdlIG92ZXJsYXlcIiwgKCkgPT4ge1xuICBpdChcInNob3dzIGFuIGltYWdlIGZpbGUgYXMgYW4gaW1hZ2UsIG5ldmVyIHRocm91Z2ggdGhlIHRleHQgYnVmZmVyXCIsIGFzeW5jICgpID0+IHtcbiAgICBmcy5hdmFpbGFibGUgPSB0cnVlO1xuICAgIGZzLmJ5dGVzLnNldChcIi9hcHAvYXNzZXRzL2xvZ28ucG5nXCIsIG5ldyBVaW50OEFycmF5KFsxMzcsIDgwLCA3OCwgNzFdKSk7XG4gICAgZWRpdG9yQ29udGV4dC5hY3RpdmVGaWxlID0gXCIvYXNzZXRzL2xvZ28ucG5nXCI7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8QXBwIC8+KTtcbiAgICBjb25zdCBpbWcgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImltZ1wiLCB7IG5hbWU6IFwibG9nby5wbmdcIiB9KTtcbiAgICBleHBlY3QoaW1nKS50b0hhdmVBdHRyaWJ1dGUoXCJzcmNcIiwgZXhwZWN0LnN0cmluZ01hdGNoaW5nKC9eYmxvYjovKSk7XG4gICAgLy8gVGhlIGJ5dGVzIG5ldmVyIHdlbnQgdGhyb3VnaCB0aGUgVVRGLTggdGV4dCByZWFkLCBhbmQgbm8gZWRpdG9yIG1vdW50ZWQuXG4gICAgZXhwZWN0KGZzLnRleHRSZWFkcykubm90LnRvQ29udGFpbihcIi9hcHAvYXNzZXRzL2xvZ28ucG5nXCIpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcihcIi5jbS1ob3N0XCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICAvLyBSLUlYLTcg4oCUIHRoZSBzZXR0bGUgaXMgYW5ub3VuY2VkIHRocm91Z2ggYSBsaXZlIHJlZ2lvbiwgbm90IG9ubHkgcGFpbnRlZC5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInN0YXR1c1wiKSkudG9IYXZlVGV4dENvbnRlbnQoXG4gICAgICBcIlNob3dpbmcgaW1hZ2UgbG9nby5wbmdcIixcbiAgICApO1xuICAgIC8vIFRoZSBjYXB0aW9uIG5hbWVzIHRoZSBmaWxlIGFuZCB0aGUgcmVhZC1vbmx5IHRydXRoLlxuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcihcIi5lZC1pbWFnZS1jYXB0aW9uXCIpKS50b0hhdmVUZXh0Q29udGVudChcbiAgICAgIFwibG9nby5wbmdcIixcbiAgICApO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcihcIi5lZC1pbWFnZS1jYXB0aW9uXCIpKS50b0hhdmVUZXh0Q29udGVudChcbiAgICAgIFwicmVhZC1vbmx5XCIsXG4gICAgKTtcbiAgfSk7XG5cbiAgaXQoXCJrZWVwcyB0aGUgRWRpdG9yVmlldyBtb3VudGVkIHVuZGVyIHRoZSBvdmVybGF5IGFjcm9zcyB0ZXh04oaSaW1hZ2XihpJ0ZXh0XCIsIGFzeW5jICgpID0+IHtcbiAgICBmcy5hdmFpbGFibGUgPSB0cnVlO1xuICAgIGZzLmZpbGVzLnNldChcIi9hcHAvc3JjL0FwcC50c3hcIiwgXCJleHBvcnQgZGVmYXVsdCAxO1wiKTtcbiAgICBmcy5ieXRlcy5zZXQoXCIvYXBwL2Fzc2V0cy9sb2dvLnBuZ1wiLCBuZXcgVWludDhBcnJheShbMSwgMiwgM10pKTtcbiAgICBlZGl0b3JDb250ZXh0LmFjdGl2ZUZpbGUgPSBcIi9zcmMvQXBwLnRzeFwiO1xuICAgIGNvbnN0IHsgY29udGFpbmVyLCByZXJlbmRlciB9ID0gcmVuZGVyKDxBcHAgLz4pO1xuICAgIGF3YWl0IHZpLndhaXRGb3IoKCkgPT4ge1xuICAgICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKFwiLmNtLWhvc3RcIikpLnRvSGF2ZVRleHRDb250ZW50KFxuICAgICAgICBcImV4cG9ydCBkZWZhdWx0IDFcIixcbiAgICAgICk7XG4gICAgfSk7XG4gICAgY29uc3QgaG9zdEJlZm9yZSA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKFwiLmNtLWhvc3RcIik7XG5cbiAgICAvLyBTd2l0Y2ggdG8gdGhlIGltYWdlOiB0aGUgb3ZlcmxheSBjb3ZlcnMgdGhlIFNBTUUgZWRpdG9yIGhvc3QsIHdoaWNoIGlzXG4gICAgLy8gbm93IGluZXJ0IGFuZCBoaWRkZW4gZnJvbSB0aGUgYWNjZXNzaWJpbGl0eSB0cmVlIOKAlCBub3QgdW5tb3VudGVkLlxuICAgIGVkaXRvckNvbnRleHQuYWN0aXZlRmlsZSA9IFwiL2Fzc2V0cy9sb2dvLnBuZ1wiO1xuICAgIHJlcmVuZGVyKDxBcHAgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiaW1nXCIsIHsgbmFtZTogXCJsb2dvLnBuZ1wiIH0pO1xuICAgIGNvbnN0IHdyYXAgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcihcIi5lZC1jbS13cmFwXCIpO1xuICAgIGV4cGVjdCh3cmFwKS50b0hhdmVBdHRyaWJ1dGUoXCJpbmVydFwiKTtcbiAgICBleHBlY3Qod3JhcCkudG9IYXZlQXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgXCJ0cnVlXCIpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcihcIi5jbS1ob3N0XCIpKS50b0JlKGhvc3RCZWZvcmUpO1xuXG4gICAgLy8gU3dpdGNoIGJhY2s6IHRoZSBvdmVybGF5IGxpZnRzLCB0aGUgZWRpdG9yIGlzIHVzYWJsZSwgYW5kIGl0IGlzIHN0aWxsXG4gICAgLy8gdGhlIHNhbWUgaG9zdCBub2RlIOKAlCBubyB0ZWFyZG93bi9idWlsZHVwIGhhcHBlbmVkIGFueXdoZXJlLlxuICAgIGVkaXRvckNvbnRleHQuYWN0aXZlRmlsZSA9IFwiL3NyYy9BcHAudHN4XCI7XG4gICAgcmVyZW5kZXIoPEFwcCAvPik7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiB7XG4gICAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoXCIuZWQtY20td3JhcFwiKSkubm90LnRvSGF2ZUF0dHJpYnV0ZShcbiAgICAgICAgXCJpbmVydFwiLFxuICAgICAgKTtcbiAgICB9KTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoXCIuY20taG9zdFwiKSkudG9CZShob3N0QmVmb3JlKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwiaW1nXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJhIGZhaWxlZCBpbWFnZSByZWFkIG5hbWVzIHRoZSBwYXRoIHdoZW4gdGhlIGZpbGUgc3RpbGwgZXhpc3RzXCIsIGFzeW5jICgpID0+IHtcbiAgICBmcy5hdmFpbGFibGUgPSB0cnVlO1xuICAgIC8vIFByZXNlbnQgdG8gZXhpc3RzKCkgdmlhIHRoZSB0ZXh0IG1hcCwgdW5yZWFkYWJsZSBhcyBieXRlcy5cbiAgICBmcy5maWxlcy5zZXQoXCIvYXBwL2Fzc2V0cy9sb2dvLnBuZ1wiLCBcIm5vdCByZWFsbHkgYW4gaW1hZ2VcIik7XG4gICAgZWRpdG9yQ29udGV4dC5hY3RpdmVGaWxlID0gXCIvYXNzZXRzL2xvZ28ucG5nXCI7XG4gICAgcmVuZGVyKDxBcHAgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KC9jb3VsZCBub3Qgb3BlbiB0aGlzIGZpbGUvaSk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoL1xcL2Fzc2V0c1xcL2xvZ29cXC5wbmcvKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJhIG1pc3NpbmcgaW1hZ2UgZ2V0cyB0aGUgdmFuaXNoZWQgc3RhdGUsIG5vdCBtb2ppYmFrZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgZnMuYXZhaWxhYmxlID0gdHJ1ZTtcbiAgICBlZGl0b3JDb250ZXh0LmFjdGl2ZUZpbGUgPSBcIi9hc3NldHMvZ29uZS5wbmdcIjtcbiAgICByZW5kZXIoPEFwcCAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoL3RoaXMgZmlsZSB3YXMgcmVtb3ZlZC9pKTtcbiAgICBleHBlY3QoXG4gICAgICBzY3JlZW4uZ2V0QnlUZXh0KC9kZWxldGVkIG9yIHJlbmFtZWQgZWxzZXdoZXJlL2kpLFxuICAgICkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJyZS1yZWFkcyBhbmQgcmUtcmVuZGVycyB0aGUgc2hvd24gaW1hZ2Ugb24gYW4gZnMtY2hhbmdlIGJhdGNoIChSLUlYLTQpXCIsIGFzeW5jICgpID0+IHtcbiAgICBmcy5hdmFpbGFibGUgPSB0cnVlO1xuICAgIGZzLmJ5dGVzLnNldChcIi9hcHAvYXNzZXRzL2xvZ28ucG5nXCIsIG5ldyBVaW50OEFycmF5KFsxXSkpO1xuICAgIGVkaXRvckNvbnRleHQuYWN0aXZlRmlsZSA9IFwiL2Fzc2V0cy9sb2dvLnBuZ1wiO1xuICAgIHJlbmRlcig8QXBwIC8+KTtcbiAgICBjb25zdCBpbWcgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImltZ1wiLCB7IG5hbWU6IFwibG9nby5wbmdcIiB9KTtcbiAgICBjb25zdCBzcmNCZWZvcmUgPSBpbWcuZ2V0QXR0cmlidXRlKFwic3JjXCIpO1xuXG4gICAgLy8gQW4gZXh0ZXJuYWwgd3JpdGUgdG8gdGhlIHNob3duIGltYWdlOiB0aGUgaG9zdCdzIGJhdGNoIG5hbWVzIGl0cyBwYXRoLlxuICAgIGZzLmJ5dGVzLnNldChcIi9hcHAvYXNzZXRzL2xvZ28ucG5nXCIsIG5ldyBVaW50OEFycmF5KFsyLCAyXSkpO1xuICAgIGFjdCgoKSA9PiB7XG4gICAgICBmc0NoYW5nZUxpc3RlbmVycy5mb3JFYWNoKChsKSA9PlxuICAgICAgICBsKHsgcGF0aHM6IFtcIi9hc3NldHMvbG9nby5wbmdcIl0sIGVwb2NoOiAxIH0pLFxuICAgICAgKTtcbiAgICB9KTtcblxuICAgIC8vIFRoZSByZS1yZWFkIGJ1aWxkcyBhIE5FVyBvYmplY3QgVVJMICh0aGUgc2V0dXAgc3R1YiBpcyBjb3VudGVyLWJhY2tlZCksXG4gICAgLy8gc28gYSBzd2FwcGVkIHNyYyBwcm92ZXMgdGhlIHJlLXJlbmRlcjsgdGhlIG9sZCBvbmUgd2FzIHJldm9rZWQuXG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiB7XG4gICAgICBleHBlY3QoXG4gICAgICAgIHNjcmVlbi5nZXRCeVJvbGUoXCJpbWdcIiwgeyBuYW1lOiBcImxvZ28ucG5nXCIgfSkuZ2V0QXR0cmlidXRlKFwic3JjXCIpLFxuICAgICAgKS5ub3QudG9CZShzcmNCZWZvcmUpO1xuICAgIH0pO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7O0FBS0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBaUdBLElBQUFFLElBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUF3QixJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxTQUFBRyx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQXZHeEI7QUFDQTtBQUNBO0FBQ0E7O0FBS0E7QUFDQSxNQUFNRyxhQUFhLEdBQUc7RUFDcEJDLFVBQVUsRUFBRSxJQUFxQjtFQUNqQ0MsU0FBUyxFQUFFLEVBQWM7RUFDekJDLFVBQVUsRUFBRTtBQUNkLENBQUM7QUFDRDtBQUNBLE1BQU1DLFNBQVMsR0FBRztFQUFFQyxPQUFPLEVBQUU7QUFBMkIsQ0FBQztBQUN6RCxNQUFNQyxNQUFpQixHQUFHLEVBQUU7O0FBRTVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUlDLEdBQUcsQ0FBb0MsQ0FBQztBQUNqRUMsVUFBRSxDQUFDQyxJQUFJLENBQUMsbUNBQW1DLEVBQUUsT0FBTztFQUNsREMsV0FBVyxFQUFFQSxDQUFDQyxJQUFZLEVBQUVDLE9BQTZCLEtBQUs7SUFDNUQsTUFBTUMsR0FBRyxHQUFHUCxZQUFZLENBQUNRLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDLElBQUksSUFBSUksR0FBRyxDQUF1QixDQUFDO0lBQ3JFRixHQUFHLENBQUNHLEdBQUcsQ0FBQ0osT0FBTyxDQUFDO0lBQ2hCTixZQUFZLENBQUNPLEdBQUcsQ0FBQ0YsSUFBSSxFQUFFRSxHQUFHLENBQUM7SUFDM0JJLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDLGFBQWFQLElBQUksRUFBRSxDQUFDO0lBQ3BDLE9BQU8sTUFBTUUsR0FBRyxDQUFDTSxNQUFNLENBQUNQLE9BQU8sQ0FBQztFQUNsQztBQUNGLENBQUMsQ0FBQyxDQUFDOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNSyxVQUFvQixHQUFHLEVBQUU7QUFDL0JULFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLDRCQUE0QixFQUFFLE9BQU87RUFDM0NXLFdBQVcsRUFBRUEsQ0FBQSxLQUFNO0lBQ2pCSCxVQUFVLENBQUNDLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDMUI7QUFDRixDQUFDLENBQUMsQ0FBQztBQUVIVixVQUFFLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxPQUFPO0VBQ3JDWSxnQkFBZ0IsRUFBRUEsQ0FBQSxLQUFNdEIsYUFBYTtFQUNyQ3VCLFlBQVksRUFBRUEsQ0FBQSxLQUFNbkIsU0FBUyxDQUFDQyxPQUFPO0VBQ3JDbUIsYUFBYSxFQUFFQSxDQUFBLE1BQU87SUFDcEJDLEtBQUssRUFBRSxTQUFTO0lBQ2hCQyxXQUFXLEVBQUUsV0FBVztJQUN4QkMsS0FBSyxFQUFFLElBQUk7SUFDWEMsTUFBTSxFQUFFO0VBQ1YsQ0FBQyxDQUFDO0VBQ0ZDLGNBQWMsRUFBRUEsQ0FBQSxNQUFPO0lBQ3JCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxjQUFjLEVBQUUsRUFBRTtJQUNsQkMsVUFBVSxFQUFFO0VBQ2QsQ0FBQyxDQUFDO0VBQ0ZDLFNBQVMsRUFBRUEsQ0FBQSxLQUFNM0IsTUFBTTtFQUN2QjRCLFNBQVMsRUFBRUEsQ0FBQSxLQUFNNUIsTUFBTTtFQUN2QjZCLGVBQWUsRUFBRUEsQ0FBQSxLQUFNLE1BQU07RUFDN0JDLGFBQWEsRUFBRTNCLFVBQUUsQ0FBQzRCLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDN0NDLFNBQVMsRUFBRS9CLFVBQUUsQ0FBQzRCLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDekM7RUFDQTtFQUNBRSxVQUFVLEVBQUVoQyxVQUFFLENBQUM0QixFQUFFLENBQUVLLFFBQXlELElBQUs7SUFDL0VDLGlCQUFpQixDQUFDMUIsR0FBRyxDQUFDeUIsUUFBUSxDQUFDO0lBQy9CLE9BQU8sTUFBTUMsaUJBQWlCLENBQUN2QixNQUFNLENBQUNzQixRQUFRLENBQUM7RUFDakQsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDOztBQUVIO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcsSUFBSTNCLEdBQUcsQ0FFL0IsQ0FBQzs7QUFFSDtBQUNBLE1BQU00QixFQUFFLEdBQUc7RUFDVEMsU0FBUyxFQUFFLEtBQUs7RUFDaEJDLEtBQUssRUFBRSxJQUFJdEMsR0FBRyxDQUFpQixDQUFDO0VBQ2hDdUMsS0FBSyxFQUFFLElBQUl2QyxHQUFHLENBQXFCLENBQUM7RUFDcEN3QyxTQUFTLEVBQUU7QUFDYixDQUFDO0FBQ0R2QyxVQUFFLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTztFQUM3QnVDLFdBQVcsRUFBRUEsQ0FBQSxLQUFNTCxFQUFFLENBQUNDLFNBQVM7RUFDL0JLLFlBQVksRUFBR0MsQ0FBUyxJQUFLO0lBQzNCUCxFQUFFLENBQUNJLFNBQVMsQ0FBQzdCLElBQUksQ0FBQ2dDLENBQUMsQ0FBQztJQUNwQixPQUFPUCxFQUFFLENBQUNFLEtBQUssQ0FBQ00sR0FBRyxDQUFDRCxDQUFDLENBQUMsR0FDbEJiLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDSyxFQUFFLENBQUNFLEtBQUssQ0FBQy9CLEdBQUcsQ0FBQ29DLENBQUMsQ0FBRSxDQUFDLEdBQ2pDYixPQUFPLENBQUNlLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7RUFDekMsQ0FBQztFQUNEQyxhQUFhLEVBQUdKLENBQVMsSUFDdkJQLEVBQUUsQ0FBQ0csS0FBSyxDQUFDSyxHQUFHLENBQUNELENBQUMsQ0FBQyxHQUNYYixPQUFPLENBQUNDLE9BQU8sQ0FBQ0ssRUFBRSxDQUFDRyxLQUFLLENBQUNoQyxHQUFHLENBQUNvQyxDQUFDLENBQUUsQ0FBQyxHQUNqQ2IsT0FBTyxDQUFDZSxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ3pDRSxhQUFhLEVBQUVBLENBQUNMLENBQVMsRUFBRU0sQ0FBUyxLQUFLO0lBQ3ZDYixFQUFFLENBQUNFLEtBQUssQ0FBQ2hDLEdBQUcsQ0FBQ3FDLENBQUMsRUFBRU0sQ0FBQyxDQUFDO0lBQ2xCLE9BQU9uQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0VBQzFCLENBQUM7RUFDRG1CLE1BQU0sRUFBR1AsQ0FBUyxJQUFLYixPQUFPLENBQUNDLE9BQU8sQ0FBQ0ssRUFBRSxDQUFDRSxLQUFLLENBQUNNLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDLElBQUlQLEVBQUUsQ0FBQ0csS0FBSyxDQUFDSyxHQUFHLENBQUNELENBQUMsQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQztBQUlILElBQUFRLGtCQUFVLEVBQUMsTUFBTTtFQUNmdkQsU0FBUyxDQUFDQyxPQUFPLEdBQUcsTUFBTTtFQUMxQkwsYUFBYSxDQUFDQyxVQUFVLEdBQUcsSUFBSTtFQUMvQkQsYUFBYSxDQUFDRSxTQUFTLEdBQUcsRUFBRTtFQUM1QkYsYUFBYSxDQUFDRyxVQUFVLEdBQUcsRUFBRTtFQUM3QnlDLEVBQUUsQ0FBQ0MsU0FBUyxHQUFHLEtBQUs7RUFDcEJELEVBQUUsQ0FBQ0UsS0FBSyxDQUFDYyxLQUFLLENBQUMsQ0FBQztFQUNoQmhCLEVBQUUsQ0FBQ0csS0FBSyxDQUFDYSxLQUFLLENBQUMsQ0FBQztFQUNoQmhCLEVBQUUsQ0FBQ0ksU0FBUyxDQUFDYSxNQUFNLEdBQUcsQ0FBQztFQUN2QmxCLGlCQUFpQixDQUFDaUIsS0FBSyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDO0FBRUYsSUFBQUUsZ0JBQVEsRUFBQyw2Q0FBNkMsRUFBRSxNQUFNO0VBQzVELElBQUFDLFVBQUUsRUFBQyx3RUFBd0UsRUFBRSxNQUFNO0lBQ2pGM0QsU0FBUyxDQUFDQyxPQUFPLEdBQUcsT0FBTztJQUMzQixNQUFNO01BQUUyRDtJQUFVLENBQUMsR0FBRyxJQUFBQyxhQUFNLGVBQUMsSUFBQXJFLFdBQUEsQ0FBQXNFLEdBQUEsRUFBQ3hFLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUNyQyxJQUFBb0UsY0FBTSxFQUFDSCxTQUFTLENBQUNJLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDQyxlQUFlLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQztFQUN2RixDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsNkNBQTZDLEVBQUUsTUFBTTtJQUN0RCxNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGFBQU0sZUFBQyxJQUFBckUsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ3JDLElBQUFvRSxjQUFNLEVBQUNILFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDO0VBQ3RGLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFQLGdCQUFRLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtFQUMvRCxJQUFBQyxVQUFFLEVBQUMsdUVBQXVFLEVBQUUsTUFBTTtJQUNoRjdDLFVBQVUsQ0FBQzJDLE1BQU0sR0FBRyxDQUFDO0lBQ3JCakIsRUFBRSxDQUFDQyxTQUFTLEdBQUcsSUFBSTtJQUNuQjdDLGFBQWEsQ0FBQ0MsVUFBVSxHQUFHLGNBQWM7SUFDekMsSUFBQWdFLGFBQU0sZUFBQyxJQUFBckUsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2YsSUFBQW9FLGNBQU0sRUFBQ2pELFVBQVUsQ0FBQyxDQUFDb0QsU0FBUyxDQUFDLE9BQU8sQ0FBQztJQUNyQyxJQUFBSCxjQUFNLEVBQUNqRCxVQUFVLENBQUNxRCxPQUFPLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7SUFDbEYsSUFBQUwsY0FBTSxFQUFDakQsVUFBVSxDQUFDcUQsT0FBTyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQ0UsWUFBWSxDQUNuRXZELFVBQVUsQ0FBQ3FELE9BQU8sQ0FBQyxPQUFPLENBQzVCLENBQUM7RUFDSCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBVCxnQkFBUSxFQUFDLHNCQUFzQixFQUFFLE1BQU07RUFDckMsSUFBQUMsVUFBRSxFQUFDLDhEQUE4RCxFQUFFLE1BQU07SUFDdkVuQixFQUFFLENBQUNDLFNBQVMsR0FBRyxLQUFLO0lBQ3BCN0MsYUFBYSxDQUFDQyxVQUFVLEdBQUcsY0FBYztJQUN6QyxJQUFBZ0UsYUFBTSxlQUFDLElBQUFyRSxXQUFBLENBQUFzRSxHQUFBLEVBQUN4RSxJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDZixJQUFBb0UsY0FBTSxFQUNKTyxhQUFNLENBQUNDLFNBQVMsQ0FBQyxpQ0FBaUMsQ0FDcEQsQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDO0VBQ3ZCLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxNQUFNO0lBQzFFbkIsRUFBRSxDQUFDQyxTQUFTLEdBQUcsSUFBSTtJQUNuQjdDLGFBQWEsQ0FBQ0MsVUFBVSxHQUFHLElBQUk7SUFDL0IsSUFBQWdFLGFBQU0sZUFBQyxJQUFBckUsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2YsSUFBQW9FLGNBQU0sRUFBQ08sYUFBTSxDQUFDQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0MsaUJBQWlCLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtJQUN6RG5CLEVBQUUsQ0FBQ0MsU0FBUyxHQUFHLElBQUk7SUFDbkI3QyxhQUFhLENBQUNFLFNBQVMsR0FBRyxDQUFDLGNBQWMsRUFBRSxlQUFlLENBQUM7SUFDM0RGLGFBQWEsQ0FBQ0MsVUFBVSxHQUFHLGNBQWM7SUFDekMyQyxFQUFFLENBQUNFLEtBQUssQ0FBQ2hDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxtQkFBbUIsQ0FBQztJQUNyRCxJQUFBbUQsYUFBTSxlQUFDLElBQUFyRSxXQUFBLENBQUFzRSxHQUFBLEVBQUN4RSxJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDZixJQUFBb0UsY0FBTSxFQUFDTyxhQUFNLENBQUNHLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNGLGlCQUFpQixDQUFDLENBQUM7SUFDN0QsSUFBQVQsY0FBTSxFQUFDTyxhQUFNLENBQUNLLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDRCxHQUFHLENBQUNGLGlCQUFpQixDQUFDLENBQUM7RUFDaEUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQWQsZ0JBQVEsRUFBQyx3QkFBd0IsRUFBRSxNQUFNO0VBQ3ZDLElBQUFDLFVBQUUsRUFBQyxnRUFBZ0UsRUFBRSxZQUFZO0lBQy9FbkIsRUFBRSxDQUFDQyxTQUFTLEdBQUcsSUFBSTtJQUNuQkQsRUFBRSxDQUFDRyxLQUFLLENBQUNqQyxHQUFHLENBQUMsc0JBQXNCLEVBQUUsSUFBSWtFLFVBQVUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDdkVoRixhQUFhLENBQUNDLFVBQVUsR0FBRyxrQkFBa0I7SUFDN0MsTUFBTTtNQUFFK0Q7SUFBVSxDQUFDLEdBQUcsSUFBQUMsYUFBTSxlQUFDLElBQUFyRSxXQUFBLENBQUFzRSxHQUFBLEVBQUN4RSxJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDckMsTUFBTWtGLEdBQUcsR0FBRyxNQUFNUCxhQUFNLENBQUNRLFVBQVUsQ0FBQyxLQUFLLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0lBQ2hFLElBQUFoQixjQUFNLEVBQUNjLEdBQUcsQ0FBQyxDQUFDWixlQUFlLENBQUMsS0FBSyxFQUFFRixjQUFNLENBQUNpQixjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDbkU7SUFDQSxJQUFBakIsY0FBTSxFQUFDdkIsRUFBRSxDQUFDSSxTQUFTLENBQUMsQ0FBQzhCLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLHNCQUFzQixDQUFDO0lBQzFELElBQUFILGNBQU0sRUFBQ0gsU0FBUyxDQUFDSSxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ1UsR0FBRyxDQUFDRixpQkFBaUIsQ0FBQyxDQUFDO0lBQ25FO0lBQ0EsSUFBQVQsY0FBTSxFQUFDTyxhQUFNLENBQUNXLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDQyxpQkFBaUIsQ0FDbEQsd0JBQ0YsQ0FBQztJQUNEO0lBQ0EsSUFBQW5CLGNBQU0sRUFBQ0gsU0FBUyxDQUFDSSxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDa0IsaUJBQWlCLENBQ3BFLFVBQ0YsQ0FBQztJQUNELElBQUFuQixjQUFNLEVBQUNILFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ2tCLGlCQUFpQixDQUNwRSxXQUNGLENBQUM7RUFDSCxDQUFDLENBQUM7RUFFRixJQUFBdkIsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEZuQixFQUFFLENBQUNDLFNBQVMsR0FBRyxJQUFJO0lBQ25CRCxFQUFFLENBQUNFLEtBQUssQ0FBQ2hDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxtQkFBbUIsQ0FBQztJQUNyRDhCLEVBQUUsQ0FBQ0csS0FBSyxDQUFDakMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLElBQUlrRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0RoRixhQUFhLENBQUNDLFVBQVUsR0FBRyxjQUFjO0lBQ3pDLE1BQU07TUFBRStELFNBQVM7TUFBRXVCO0lBQVMsQ0FBQyxHQUFHLElBQUF0QixhQUFNLGVBQUMsSUFBQXJFLFdBQUEsQ0FBQXNFLEdBQUEsRUFBQ3hFLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUMvQyxNQUFNVSxVQUFFLENBQUMrRSxPQUFPLENBQUMsTUFBTTtNQUNyQixJQUFBckIsY0FBTSxFQUFDSCxTQUFTLENBQUNJLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDa0IsaUJBQWlCLENBQzNELGtCQUNGLENBQUM7SUFDSCxDQUFDLENBQUM7SUFDRixNQUFNRyxVQUFVLEdBQUd6QixTQUFTLENBQUNJLGFBQWEsQ0FBQyxVQUFVLENBQUM7O0lBRXREO0lBQ0E7SUFDQXBFLGFBQWEsQ0FBQ0MsVUFBVSxHQUFHLGtCQUFrQjtJQUM3Q3NGLFFBQVEsY0FBQyxJQUFBM0YsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2pCLE1BQU0yRSxhQUFNLENBQUNRLFVBQVUsQ0FBQyxLQUFLLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0lBQ3BELE1BQU1PLElBQUksR0FBRzFCLFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLGFBQWEsQ0FBQztJQUNuRCxJQUFBRCxjQUFNLEVBQUN1QixJQUFJLENBQUMsQ0FBQ3JCLGVBQWUsQ0FBQyxPQUFPLENBQUM7SUFDckMsSUFBQUYsY0FBTSxFQUFDdUIsSUFBSSxDQUFDLENBQUNyQixlQUFlLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQztJQUNuRCxJQUFBRixjQUFNLEVBQUNILFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUN1QixJQUFJLENBQUNGLFVBQVUsQ0FBQzs7SUFFNUQ7SUFDQTtJQUNBekYsYUFBYSxDQUFDQyxVQUFVLEdBQUcsY0FBYztJQUN6Q3NGLFFBQVEsY0FBQyxJQUFBM0YsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2pCLE1BQU1VLFVBQUUsQ0FBQytFLE9BQU8sQ0FBQyxNQUFNO01BQ3JCLElBQUFyQixjQUFNLEVBQUNILFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNVLEdBQUcsQ0FBQ1QsZUFBZSxDQUNoRSxPQUNGLENBQUM7SUFDSCxDQUFDLENBQUM7SUFDRixJQUFBRixjQUFNLEVBQUNILFNBQVMsQ0FBQ0ksYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUN1QixJQUFJLENBQUNGLFVBQVUsQ0FBQztJQUM1RCxJQUFBdEIsY0FBTSxFQUFDTyxhQUFNLENBQUNHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNGLGlCQUFpQixDQUFDLENBQUM7RUFDM0QsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLCtEQUErRCxFQUFFLFlBQVk7SUFDOUVuQixFQUFFLENBQUNDLFNBQVMsR0FBRyxJQUFJO0lBQ25CO0lBQ0FELEVBQUUsQ0FBQ0UsS0FBSyxDQUFDaEMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLHFCQUFxQixDQUFDO0lBQzNEZCxhQUFhLENBQUNDLFVBQVUsR0FBRyxrQkFBa0I7SUFDN0MsSUFBQWdFLGFBQU0sZUFBQyxJQUFBckUsV0FBQSxDQUFBc0UsR0FBQSxFQUFDeEUsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2YsTUFBTTJFLGFBQU0sQ0FBQ2tCLFVBQVUsQ0FBQywyQkFBMkIsQ0FBQztJQUNwRCxJQUFBekIsY0FBTSxFQUFDTyxhQUFNLENBQUNDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUNDLGlCQUFpQixDQUFDLENBQUM7RUFDckUsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLHVEQUF1RCxFQUFFLFlBQVk7SUFDdEVuQixFQUFFLENBQUNDLFNBQVMsR0FBRyxJQUFJO0lBQ25CN0MsYUFBYSxDQUFDQyxVQUFVLEdBQUcsa0JBQWtCO0lBQzdDLElBQUFnRSxhQUFNLGVBQUMsSUFBQXJFLFdBQUEsQ0FBQXNFLEdBQUEsRUFBQ3hFLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUNmLE1BQU0yRSxhQUFNLENBQUNrQixVQUFVLENBQUMsd0JBQXdCLENBQUM7SUFDakQsSUFBQXpCLGNBQU0sRUFDSk8sYUFBTSxDQUFDQyxTQUFTLENBQUMsK0JBQStCLENBQ2xELENBQUMsQ0FBQ0MsaUJBQWlCLENBQUMsQ0FBQztFQUN2QixDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsd0VBQXdFLEVBQUUsWUFBWTtJQUN2Rm5CLEVBQUUsQ0FBQ0MsU0FBUyxHQUFHLElBQUk7SUFDbkJELEVBQUUsQ0FBQ0csS0FBSyxDQUFDakMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLElBQUlrRSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pEaEYsYUFBYSxDQUFDQyxVQUFVLEdBQUcsa0JBQWtCO0lBQzdDLElBQUFnRSxhQUFNLGVBQUMsSUFBQXJFLFdBQUEsQ0FBQXNFLEdBQUEsRUFBQ3hFLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUNmLE1BQU1rRixHQUFHLEdBQUcsTUFBTVAsYUFBTSxDQUFDUSxVQUFVLENBQUMsS0FBSyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUNoRSxNQUFNVSxTQUFTLEdBQUdaLEdBQUcsQ0FBQ2EsWUFBWSxDQUFDLEtBQUssQ0FBQzs7SUFFekM7SUFDQWxELEVBQUUsQ0FBQ0csS0FBSyxDQUFDakMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLElBQUlrRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM1RCxJQUFBZSxVQUFHLEVBQUMsTUFBTTtNQUNScEQsaUJBQWlCLENBQUNxRCxPQUFPLENBQUVDLENBQUMsSUFDMUJBLENBQUMsQ0FBQztRQUFFQyxLQUFLLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztRQUFFQyxLQUFLLEVBQUU7TUFBRSxDQUFDLENBQzdDLENBQUM7SUFDSCxDQUFDLENBQUM7O0lBRUY7SUFDQTtJQUNBLE1BQU0xRixVQUFFLENBQUMrRSxPQUFPLENBQUMsTUFBTTtNQUNyQixJQUFBckIsY0FBTSxFQUNKTyxhQUFNLENBQUNXLFNBQVMsQ0FBQyxLQUFLLEVBQUU7UUFBRUYsSUFBSSxFQUFFO01BQVcsQ0FBQyxDQUFDLENBQUNXLFlBQVksQ0FBQyxLQUFLLENBQ2xFLENBQUMsQ0FBQ2hCLEdBQUcsQ0FBQ2EsSUFBSSxDQUFDRSxTQUFTLENBQUM7SUFDdkIsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}