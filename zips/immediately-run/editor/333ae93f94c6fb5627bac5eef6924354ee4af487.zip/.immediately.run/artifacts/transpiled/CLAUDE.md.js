var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "claudemd-editor-app",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "claudemd-editor-app"
      }), "CLAUDE.md — editor app"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The immediately.run code editor as a forkable system app (raw CodeMirror 6 + SDK).\nSee ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "README.md"
      }), " for the full design; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDITOR_AS_APP_SPEC"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/plans/editor-as-app/"
      }), "\nin the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs"
      }), " repo are the source of truth."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "architecture-rules",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "architecture-rules"
      }), "Architecture rules"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Boundary:"
        }), " kernel owns the document (bytes, transpile, COW, Sandpack client); this\napp owns the view (CodeMirror state, cursor, undo, tabs). Never drive the transpile\nloop or host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SandpackProvider"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pure core, tested."
        }), " All decision logic lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/core/"
        }), " as pure functions with\nunit tests — the conflict state machine (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "buffer.ts"
        }), "), readiness (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "readiness.ts"
        }), "),\ndiagnostics mapping (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "diagnostics.ts"
        }), "), debounce (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "debounce.ts"
        }), "), language/rewritten\nselectors, the image-extension map (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "imageFile.ts"
        }), ", R3-804). The React layer\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/editor/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/chrome/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), ") is\nglue: keep logic out of it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Debounce the WRITE, not compilation."
        }), " The host recompiles on its ZenFS watch; do\nnot add a compile debounce or match ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "recompileDelay"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "§6 is load-bearing."
        }), " Never silently substitute external bytes into a dirty buffer.\nA conflict blocks save until the user resolves it. Don't \"improve\" this into an\nauto-merge."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["No same-origin, no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "window.parent"
          }), ", no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute:*"
          }), "."]
        }), " SDK channels/port/intents\nonly."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "commands",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "commands"
      }), "Commands"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run dev"
        }), " — local Vite dev (the working-tree port is absent → \"awaiting port\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm test"
        }), " — vitest (the suite that must stay green)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " — the same strings CI runs. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lint"
        }), " carries\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--max-warnings 0"
        }), ", because three rules here are warn-level\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "react-hooks/exhaustive-deps"
        }), " among them) and ESLint reads no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CI"
        }), " variable. This line\nused to say \"warnings are errors under CI\", which was true of neither side — R3-653."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "reusing-across-repos",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reusing-across-repos"
      }), "Reusing across repos"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/fs/mountFs.ts"
      }), " keeps only the editor's domain helpers (UTF-8 read/write/exists); the\nsandbox-fs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "resolution"
      }), " lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk/fs"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sandboxFs"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fsAvailable"
      }), "),\nshared with the file-explorer app — so there is nothing to \"keep in sync\" by hand anymore.\nIf the sandbox fs accessor changes, it changes once, in the SDK."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsImxpIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNMQVVERS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiY2xhdWRlbWQtZWRpdG9yLWFwcFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2xhdWRlbWQtZWRpdG9yLWFwcFwiIC8+e1wiQ0xBVURFLm1kIOKAlCBlZGl0b3IgYXBwXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgaW1tZWRpYXRlbHkucnVuIGNvZGUgZWRpdG9yIGFzIGEgZm9ya2FibGUgc3lzdGVtIGFwcCAocmF3IENvZGVNaXJyb3IgNiArIFNESykuXFxuU2VlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFQURNRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBmdWxsIGRlc2lnbjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0FTX0FQUF9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3MvcGxhbnMvZWRpdG9yLWFzLWFwcC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuaW4gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlcG8gYXJlIHRoZSBzb3VyY2Ugb2YgdHJ1dGguXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImFyY2hpdGVjdHVyZS1ydWxlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYXJjaGl0ZWN0dXJlLXJ1bGVzXCIgLz57XCJBcmNoaXRlY3R1cmUgcnVsZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCb3VuZGFyeTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIga2VybmVsIG93bnMgdGhlIGRvY3VtZW50IChieXRlcywgdHJhbnNwaWxlLCBDT1csIFNhbmRwYWNrIGNsaWVudCk7IHRoaXNcXG5hcHAgb3ducyB0aGUgdmlldyAoQ29kZU1pcnJvciBzdGF0ZSwgY3Vyc29yLCB1bmRvLCB0YWJzKS4gTmV2ZXIgZHJpdmUgdGhlIHRyYW5zcGlsZVxcbmxvb3Agb3IgaG9zdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTYW5kcGFja1Byb3ZpZGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlB1cmUgY29yZSwgdGVzdGVkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBbGwgZGVjaXNpb24gbG9naWMgbGl2ZXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvcmUvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcyBwdXJlIGZ1bmN0aW9ucyB3aXRoXFxudW5pdCB0ZXN0cyDigJQgdGhlIGNvbmZsaWN0IHN0YXRlIG1hY2hpbmUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1ZmZlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCByZWFkaW5lc3MgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRpbmVzcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcbmRpYWdub3N0aWNzIG1hcHBpbmcgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRpYWdub3N0aWNzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGRlYm91bmNlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZWJvdW5jZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBsYW5ndWFnZS9yZXdyaXR0ZW5cXG5zZWxlY3RvcnMsIHRoZSBpbWFnZS1leHRlbnNpb24gbWFwIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbWFnZUZpbGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBSMy04MDQpLiBUaGUgUmVhY3QgbGF5ZXJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VkaXRvci9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2Nocm9tZS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgaXNcXG5nbHVlOiBrZWVwIGxvZ2ljIG91dCBvZiBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlYm91bmNlIHRoZSBXUklURSwgbm90IGNvbXBpbGF0aW9uLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaG9zdCByZWNvbXBpbGVzIG9uIGl0cyBaZW5GUyB3YXRjaDsgZG9cXG5ub3QgYWRkIGEgY29tcGlsZSBkZWJvdW5jZSBvciBtYXRjaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWNvbXBpbGVEZWxheVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCLCpzYgaXMgbG9hZC1iZWFyaW5nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOZXZlciBzaWxlbnRseSBzdWJzdGl0dXRlIGV4dGVybmFsIGJ5dGVzIGludG8gYSBkaXJ0eSBidWZmZXIuXFxuQSBjb25mbGljdCBibG9ja3Mgc2F2ZSB1bnRpbCB0aGUgdXNlciByZXNvbHZlcyBpdC4gRG9uJ3QgXFxcImltcHJvdmVcXFwiIHRoaXMgaW50byBhblxcbmF1dG8tbWVyZ2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBzYW1lLW9yaWdpbiwgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2luZG93LnBhcmVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6KlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNESyBjaGFubmVscy9wb3J0L2ludGVudHNcXG5vbmx5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJjb21tYW5kc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY29tbWFuZHNcIiAvPntcIkNvbW1hbmRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgbG9jYWwgVml0ZSBkZXYgKHRoZSB3b3JraW5nLXRyZWUgcG9ydCBpcyBhYnNlbnQg4oaSIFxcXCJhd2FpdGluZyBwb3J0XFxcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB2aXRlc3QgKHRoZSBzdWl0ZSB0aGF0IG11c3Qgc3RheSBncmVlbikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgc2FtZSBzdHJpbmdzIENJIHJ1bnMuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCItLW1heC13YXJuaW5ncyAwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYmVjYXVzZSB0aHJlZSBydWxlcyBoZXJlIGFyZSB3YXJuLWxldmVsXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW1vbmcgdGhlbSkgYW5kIEVTTGludCByZWFkcyBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDSVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmFyaWFibGUuIFRoaXMgbGluZVxcbnVzZWQgdG8gc2F5IFxcXCJ3YXJuaW5ncyBhcmUgZXJyb3JzIHVuZGVyIENJXFxcIiwgd2hpY2ggd2FzIHRydWUgb2YgbmVpdGhlciBzaWRlIOKAlCBSMy02NTMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJldXNpbmctYWNyb3NzLXJlcG9zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZXVzaW5nLWFjcm9zcy1yZXBvc1wiIC8+e1wiUmV1c2luZyBhY3Jvc3MgcmVwb3NcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9mcy9tb3VudEZzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBrZWVwcyBvbmx5IHRoZSBlZGl0b3IncyBkb21haW4gaGVscGVycyAoVVRGLTggcmVhZC93cml0ZS9leGlzdHMpOyB0aGVcXG5zYW5kYm94LWZzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVzb2x1dGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBsaXZlcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nkay9mc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNhbmRib3hGc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZnNBdmFpbGFibGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSxcXG5zaGFyZWQgd2l0aCB0aGUgZmlsZS1leHBsb3JlciBhcHAg4oCUIHNvIHRoZXJlIGlzIG5vdGhpbmcgdG8gXFxcImtlZXAgaW4gc3luY1xcXCIgYnkgaGFuZCBhbnltb3JlLlxcbklmIHRoZSBzYW5kYm94IGZzIGFjY2Vzc29yIGNoYW5nZXMsIGl0IGNoYW5nZXMgb25jZSwgaW4gdGhlIFNESy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NMQVVERS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdULEtBQUssQ0FBQ1U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdWLFdBQVc7RUFDaEMsSUFBSSxDQUFDVSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUFmLFdBQUEsQ0FBQWdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0UsRUFBRTtNQUFDYSxFQUFFLEVBQUMscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUIsQ0FBRSxDQUFDLEVBQUMsd0JBQXdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsMEZBQTBGLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUEyQixDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNHLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLG9CQUFvQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9CLENBQUUsQ0FBQyxFQUFDLG9CQUFvQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNPLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNNLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLDhLQUE4SyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNNLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW9CLENBQXFCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNJLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDTSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsbUZBQW1GLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLGdLQUFnSztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNJLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ00sTUFBTTtVQUFBUSxRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBYSxRQUFBLEVBQUU7VUFBZSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7WUFBQWEsUUFBQSxFQUFFO1VBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsbUNBQW1DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDRyxFQUFFO01BQUNZLEVBQUUsRUFBQyxVQUFVO01BQUFELFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBVSxDQUFFLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ08sRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsMEVBQTBFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNJLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsOEdBQThHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDRyxFQUFFO01BQUNZLEVBQUUsRUFBQyxzQkFBc0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNNLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxvS0FBb0s7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2orSTtBQUNlLFNBQVNHLFVBQVVBLENBQUNsQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDbUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1QsS0FBSyxDQUFDVTtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUF0QixXQUFBLENBQUFtQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLcEIsS0FBSztJQUFBZSxRQUFBLGVBQUUsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2xCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNxQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}