"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useImagePreview = useImagePreview;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _imageFile = require("../core/imageFile");
var _useFileBuffer = require("./useFileBuffer");
var _workingTree = require("../fs/workingTree");
/* eslint-disable react-hooks/set-state-in-effect --
   This hook synchronises React state from two genuinely-external systems — the
   working-tree byte read and the host's fs-change stream — inside an effect,
   exactly like useFileBuffer. Neither fits the "derive during render" model. */
// R3-804 — the image counterpart of `useFileBuffer`. When the active file is a
// recognised raster image (`core/imageFile.ts`), read its BYTES through the
// working-tree port and hand the view an object URL; the §6 text state machine
// does not apply (an image is never dirty and never conflicts). The overlay
// this feeds covers the still-mounted CodeMirror view, so the text→image→text
// round trip costs no editor teardown.
//
// Lifecycle: the object URL is revoked when the file changes, when a re-read
// replaces it, and on unmount — the bound is one URL per shown image (R17).
// External changes ride the §4.2 `onFsChange` channel like the text path: a
// batch naming the active path triggers a re-read; a read failure on a file
// that no longer exists is the §12.4 vanished case, otherwise an honest error.

function useImagePreview(activeFile, portReady) {
  const mime = activeFile ? (0, _imageFile.imageMimeForPath)(activeFile) : null;
  const [preview, setPreview] = (0, _react.useState)({
    state: 'idle'
  });
  // Bumped by the fs-change subscription to re-read the shown image.
  const [reloadNonce, setReloadNonce] = (0, _react.useState)(0);
  (0, _react.useEffect)(() => {
    if (!activeFile || !mime || !portReady) {
      setPreview({
        state: 'idle'
      });
      return;
    }
    let cancelled = false;
    let objectUrl = null;
    setPreview({
      state: 'loading',
      path: activeFile
    });
    const tree = _workingTree.WorkingTree.current();
    tree.readBytes(activeFile).then(bytes => {
      if (cancelled) return;
      objectUrl = URL.createObjectURL(new Blob([bytes], {
        type: mime
      }));
      setPreview({
        state: 'ready',
        path: activeFile,
        url: objectUrl
      });
    }).catch(e => {
      if (cancelled) return;
      const message = e instanceof Error ? e.message : String(e);
      // Distinguish a vanished file from a transient unreadable fs (§12.4).
      // The exists probe itself can reject (the fs torn down mid-failure —
      // R17: every promise names its rejection sink): fall back to the honest
      // error state; only a definitive "gone" is vanished.
      void tree.exists(activeFile).then(present => {
        if (cancelled) return;
        setPreview(present ? {
          state: 'error',
          path: activeFile,
          message
        } : {
          state: 'vanished',
          path: activeFile
        });
      }).catch(() => {
        if (cancelled) return;
        setPreview({
          state: 'error',
          path: activeFile,
          message
        });
      });
    });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [activeFile, mime, portReady, reloadNonce]);

  // Re-read when the host's fs-change batch names the shown image (R-IX-4: a
  // write renders its own result). epoch 0 is the empty initial — nothing to do.
  (0, _react.useEffect)(() => {
    if (!activeFile || !mime) return;
    return (0, _sdk.onFsChange)(change => {
      if (change.epoch === 0) return;
      if (change.paths.some(p => (0, _useFileBuffer.samePath)(p, activeFile))) {
        setReloadNonce(n => n + 1);
      }
    });
  }, [activeFile, mime]);
  return preview;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9pbWFnZUZpbGUiLCJfdXNlRmlsZUJ1ZmZlciIsIl93b3JraW5nVHJlZSIsInVzZUltYWdlUHJldmlldyIsImFjdGl2ZUZpbGUiLCJwb3J0UmVhZHkiLCJtaW1lIiwiaW1hZ2VNaW1lRm9yUGF0aCIsInByZXZpZXciLCJzZXRQcmV2aWV3IiwidXNlU3RhdGUiLCJzdGF0ZSIsInJlbG9hZE5vbmNlIiwic2V0UmVsb2FkTm9uY2UiLCJ1c2VFZmZlY3QiLCJjYW5jZWxsZWQiLCJvYmplY3RVcmwiLCJwYXRoIiwidHJlZSIsIldvcmtpbmdUcmVlIiwiY3VycmVudCIsInJlYWRCeXRlcyIsInRoZW4iLCJieXRlcyIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsIkJsb2IiLCJ0eXBlIiwidXJsIiwiY2F0Y2giLCJlIiwibWVzc2FnZSIsIkVycm9yIiwiU3RyaW5nIiwiZXhpc3RzIiwicHJlc2VudCIsInJldm9rZU9iamVjdFVSTCIsIm9uRnNDaGFuZ2UiLCJjaGFuZ2UiLCJlcG9jaCIsInBhdGhzIiwic29tZSIsInAiLCJzYW1lUGF0aCIsIm4iXSwic291cmNlcyI6WyJ1c2VJbWFnZVByZXZpZXcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgcmVhY3QtaG9va3Mvc2V0LXN0YXRlLWluLWVmZmVjdCAtLVxuICAgVGhpcyBob29rIHN5bmNocm9uaXNlcyBSZWFjdCBzdGF0ZSBmcm9tIHR3byBnZW51aW5lbHktZXh0ZXJuYWwgc3lzdGVtcyDigJQgdGhlXG4gICB3b3JraW5nLXRyZWUgYnl0ZSByZWFkIGFuZCB0aGUgaG9zdCdzIGZzLWNoYW5nZSBzdHJlYW0g4oCUIGluc2lkZSBhbiBlZmZlY3QsXG4gICBleGFjdGx5IGxpa2UgdXNlRmlsZUJ1ZmZlci4gTmVpdGhlciBmaXRzIHRoZSBcImRlcml2ZSBkdXJpbmcgcmVuZGVyXCIgbW9kZWwuICovXG4vLyBSMy04MDQg4oCUIHRoZSBpbWFnZSBjb3VudGVycGFydCBvZiBgdXNlRmlsZUJ1ZmZlcmAuIFdoZW4gdGhlIGFjdGl2ZSBmaWxlIGlzIGFcbi8vIHJlY29nbmlzZWQgcmFzdGVyIGltYWdlIChgY29yZS9pbWFnZUZpbGUudHNgKSwgcmVhZCBpdHMgQllURVMgdGhyb3VnaCB0aGVcbi8vIHdvcmtpbmctdHJlZSBwb3J0IGFuZCBoYW5kIHRoZSB2aWV3IGFuIG9iamVjdCBVUkw7IHRoZSDCpzYgdGV4dCBzdGF0ZSBtYWNoaW5lXG4vLyBkb2VzIG5vdCBhcHBseSAoYW4gaW1hZ2UgaXMgbmV2ZXIgZGlydHkgYW5kIG5ldmVyIGNvbmZsaWN0cykuIFRoZSBvdmVybGF5XG4vLyB0aGlzIGZlZWRzIGNvdmVycyB0aGUgc3RpbGwtbW91bnRlZCBDb2RlTWlycm9yIHZpZXcsIHNvIHRoZSB0ZXh04oaSaW1hZ2XihpJ0ZXh0XG4vLyByb3VuZCB0cmlwIGNvc3RzIG5vIGVkaXRvciB0ZWFyZG93bi5cbi8vXG4vLyBMaWZlY3ljbGU6IHRoZSBvYmplY3QgVVJMIGlzIHJldm9rZWQgd2hlbiB0aGUgZmlsZSBjaGFuZ2VzLCB3aGVuIGEgcmUtcmVhZFxuLy8gcmVwbGFjZXMgaXQsIGFuZCBvbiB1bm1vdW50IOKAlCB0aGUgYm91bmQgaXMgb25lIFVSTCBwZXIgc2hvd24gaW1hZ2UgKFIxNykuXG4vLyBFeHRlcm5hbCBjaGFuZ2VzIHJpZGUgdGhlIMKnNC4yIGBvbkZzQ2hhbmdlYCBjaGFubmVsIGxpa2UgdGhlIHRleHQgcGF0aDogYVxuLy8gYmF0Y2ggbmFtaW5nIHRoZSBhY3RpdmUgcGF0aCB0cmlnZ2VycyBhIHJlLXJlYWQ7IGEgcmVhZCBmYWlsdXJlIG9uIGEgZmlsZVxuLy8gdGhhdCBubyBsb25nZXIgZXhpc3RzIGlzIHRoZSDCpzEyLjQgdmFuaXNoZWQgY2FzZSwgb3RoZXJ3aXNlIGFuIGhvbmVzdCBlcnJvci5cblxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG9uRnNDaGFuZ2UgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBpbWFnZU1pbWVGb3JQYXRoIH0gZnJvbSAnLi4vY29yZS9pbWFnZUZpbGUnO1xuaW1wb3J0IHsgc2FtZVBhdGggfSBmcm9tICcuL3VzZUZpbGVCdWZmZXInO1xuaW1wb3J0IHsgV29ya2luZ1RyZWUgfSBmcm9tICcuLi9mcy93b3JraW5nVHJlZSc7XG5cbmV4cG9ydCB0eXBlIEltYWdlUHJldmlldyA9XG4gIC8qKiBUaGUgYWN0aXZlIGZpbGUgaXMgbm90IGEgcmVjb2duaXNlZCBpbWFnZSAob3IgdGhlcmUgaXMgbm9uZSkg4oCUIHRoZSB0ZXh0XG4gICAqICBwYXRoIG93bnMgdGhlIHBhbmUuICovXG4gIHwgeyBzdGF0ZTogJ2lkbGUnIH1cbiAgfCB7IHN0YXRlOiAnbG9hZGluZyc7IHBhdGg6IHN0cmluZyB9XG4gIHwgeyBzdGF0ZTogJ3JlYWR5JzsgcGF0aDogc3RyaW5nOyB1cmw6IHN0cmluZyB9XG4gIC8qKiBUaGUgcmVhZCBmYWlsZWQgYnV0IHRoZSBmaWxlIHN0aWxsIGV4aXN0cy4gKi9cbiAgfCB7IHN0YXRlOiAnZXJyb3InOyBwYXRoOiBzdHJpbmc7IG1lc3NhZ2U6IHN0cmluZyB9XG4gIC8qKiBUaGUgaW1hZ2Ugd2FzIGRlbGV0ZWQvcmVuYW1lZCBvdXQgZnJvbSB1bmRlciB0aGUgcHJldmlldyAowqcxMi40KS4gKi9cbiAgfCB7IHN0YXRlOiAndmFuaXNoZWQnOyBwYXRoOiBzdHJpbmcgfTtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUltYWdlUHJldmlldyhcbiAgYWN0aXZlRmlsZTogc3RyaW5nIHwgbnVsbCxcbiAgcG9ydFJlYWR5OiBib29sZWFuLFxuKTogSW1hZ2VQcmV2aWV3IHtcbiAgY29uc3QgbWltZSA9IGFjdGl2ZUZpbGUgPyBpbWFnZU1pbWVGb3JQYXRoKGFjdGl2ZUZpbGUpIDogbnVsbDtcbiAgY29uc3QgW3ByZXZpZXcsIHNldFByZXZpZXddID0gdXNlU3RhdGU8SW1hZ2VQcmV2aWV3Pih7IHN0YXRlOiAnaWRsZScgfSk7XG4gIC8vIEJ1bXBlZCBieSB0aGUgZnMtY2hhbmdlIHN1YnNjcmlwdGlvbiB0byByZS1yZWFkIHRoZSBzaG93biBpbWFnZS5cbiAgY29uc3QgW3JlbG9hZE5vbmNlLCBzZXRSZWxvYWROb25jZV0gPSB1c2VTdGF0ZSgwKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghYWN0aXZlRmlsZSB8fCAhbWltZSB8fCAhcG9ydFJlYWR5KSB7XG4gICAgICBzZXRQcmV2aWV3KHsgc3RhdGU6ICdpZGxlJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgIGxldCBvYmplY3RVcmw6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgIHNldFByZXZpZXcoeyBzdGF0ZTogJ2xvYWRpbmcnLCBwYXRoOiBhY3RpdmVGaWxlIH0pO1xuICAgIGNvbnN0IHRyZWUgPSBXb3JraW5nVHJlZS5jdXJyZW50KCk7XG4gICAgdHJlZVxuICAgICAgLnJlYWRCeXRlcyhhY3RpdmVGaWxlKVxuICAgICAgLnRoZW4oKGJ5dGVzKSA9PiB7XG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVybjtcbiAgICAgICAgb2JqZWN0VXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChuZXcgQmxvYihbYnl0ZXNdLCB7IHR5cGU6IG1pbWUgfSkpO1xuICAgICAgICBzZXRQcmV2aWV3KHsgc3RhdGU6ICdyZWFkeScsIHBhdGg6IGFjdGl2ZUZpbGUsIHVybDogb2JqZWN0VXJsIH0pO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZTogdW5rbm93bikgPT4ge1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBTdHJpbmcoZSk7XG4gICAgICAgIC8vIERpc3Rpbmd1aXNoIGEgdmFuaXNoZWQgZmlsZSBmcm9tIGEgdHJhbnNpZW50IHVucmVhZGFibGUgZnMgKMKnMTIuNCkuXG4gICAgICAgIC8vIFRoZSBleGlzdHMgcHJvYmUgaXRzZWxmIGNhbiByZWplY3QgKHRoZSBmcyB0b3JuIGRvd24gbWlkLWZhaWx1cmUg4oCUXG4gICAgICAgIC8vIFIxNzogZXZlcnkgcHJvbWlzZSBuYW1lcyBpdHMgcmVqZWN0aW9uIHNpbmspOiBmYWxsIGJhY2sgdG8gdGhlIGhvbmVzdFxuICAgICAgICAvLyBlcnJvciBzdGF0ZTsgb25seSBhIGRlZmluaXRpdmUgXCJnb25lXCIgaXMgdmFuaXNoZWQuXG4gICAgICAgIHZvaWQgdHJlZVxuICAgICAgICAgIC5leGlzdHMoYWN0aXZlRmlsZSlcbiAgICAgICAgICAudGhlbigocHJlc2VudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICAgICAgc2V0UHJldmlldyhcbiAgICAgICAgICAgICAgcHJlc2VudFxuICAgICAgICAgICAgICAgID8geyBzdGF0ZTogJ2Vycm9yJywgcGF0aDogYWN0aXZlRmlsZSwgbWVzc2FnZSB9XG4gICAgICAgICAgICAgICAgOiB7IHN0YXRlOiAndmFuaXNoZWQnLCBwYXRoOiBhY3RpdmVGaWxlIH0sXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVybjtcbiAgICAgICAgICAgIHNldFByZXZpZXcoeyBzdGF0ZTogJ2Vycm9yJywgcGF0aDogYWN0aXZlRmlsZSwgbWVzc2FnZSB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgaWYgKG9iamVjdFVybCkgVVJMLnJldm9rZU9iamVjdFVSTChvYmplY3RVcmwpO1xuICAgIH07XG4gIH0sIFthY3RpdmVGaWxlLCBtaW1lLCBwb3J0UmVhZHksIHJlbG9hZE5vbmNlXSk7XG5cbiAgLy8gUmUtcmVhZCB3aGVuIHRoZSBob3N0J3MgZnMtY2hhbmdlIGJhdGNoIG5hbWVzIHRoZSBzaG93biBpbWFnZSAoUi1JWC00OiBhXG4gIC8vIHdyaXRlIHJlbmRlcnMgaXRzIG93biByZXN1bHQpLiBlcG9jaCAwIGlzIHRoZSBlbXB0eSBpbml0aWFsIOKAlCBub3RoaW5nIHRvIGRvLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghYWN0aXZlRmlsZSB8fCAhbWltZSkgcmV0dXJuO1xuICAgIHJldHVybiBvbkZzQ2hhbmdlKChjaGFuZ2UpID0+IHtcbiAgICAgIGlmIChjaGFuZ2UuZXBvY2ggPT09IDApIHJldHVybjtcbiAgICAgIGlmIChjaGFuZ2UucGF0aHMuc29tZSgocCkgPT4gc2FtZVBhdGgocCwgYWN0aXZlRmlsZSkpKSB7XG4gICAgICAgIHNldFJlbG9hZE5vbmNlKChuKSA9PiBuICsgMSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sIFthY3RpdmVGaWxlLCBtaW1lXSk7XG5cbiAgcmV0dXJuIHByZXZpZXc7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBaUJBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGNBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFlBQUEsR0FBQUosT0FBQTtBQXJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFtQk8sU0FBU0ssZUFBZUEsQ0FDN0JDLFVBQXlCLEVBQ3pCQyxTQUFrQixFQUNKO0VBQ2QsTUFBTUMsSUFBSSxHQUFHRixVQUFVLEdBQUcsSUFBQUcsMkJBQWdCLEVBQUNILFVBQVUsQ0FBQyxHQUFHLElBQUk7RUFDN0QsTUFBTSxDQUFDSSxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBZTtJQUFFQyxLQUFLLEVBQUU7RUFBTyxDQUFDLENBQUM7RUFDdkU7RUFDQSxNQUFNLENBQUNDLFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQUgsZUFBUSxFQUFDLENBQUMsQ0FBQztFQUVqRCxJQUFBSSxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNWLFVBQVUsSUFBSSxDQUFDRSxJQUFJLElBQUksQ0FBQ0QsU0FBUyxFQUFFO01BQ3RDSSxVQUFVLENBQUM7UUFBRUUsS0FBSyxFQUFFO01BQU8sQ0FBQyxDQUFDO01BQzdCO0lBQ0Y7SUFDQSxJQUFJSSxTQUFTLEdBQUcsS0FBSztJQUNyQixJQUFJQyxTQUF3QixHQUFHLElBQUk7SUFDbkNQLFVBQVUsQ0FBQztNQUFFRSxLQUFLLEVBQUUsU0FBUztNQUFFTSxJQUFJLEVBQUViO0lBQVcsQ0FBQyxDQUFDO0lBQ2xELE1BQU1jLElBQUksR0FBR0Msd0JBQVcsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7SUFDbENGLElBQUksQ0FDREcsU0FBUyxDQUFDakIsVUFBVSxDQUFDLENBQ3JCa0IsSUFBSSxDQUFFQyxLQUFLLElBQUs7TUFDZixJQUFJUixTQUFTLEVBQUU7TUFDZkMsU0FBUyxHQUFHUSxHQUFHLENBQUNDLGVBQWUsQ0FBQyxJQUFJQyxJQUFJLENBQUMsQ0FBQ0gsS0FBSyxDQUFDLEVBQUU7UUFBRUksSUFBSSxFQUFFckI7TUFBSyxDQUFDLENBQUMsQ0FBQztNQUNsRUcsVUFBVSxDQUFDO1FBQUVFLEtBQUssRUFBRSxPQUFPO1FBQUVNLElBQUksRUFBRWIsVUFBVTtRQUFFd0IsR0FBRyxFQUFFWjtNQUFVLENBQUMsQ0FBQztJQUNsRSxDQUFDLENBQUMsQ0FDRGEsS0FBSyxDQUFFQyxDQUFVLElBQUs7TUFDckIsSUFBSWYsU0FBUyxFQUFFO01BQ2YsTUFBTWdCLE9BQU8sR0FBR0QsQ0FBQyxZQUFZRSxLQUFLLEdBQUdGLENBQUMsQ0FBQ0MsT0FBTyxHQUFHRSxNQUFNLENBQUNILENBQUMsQ0FBQztNQUMxRDtNQUNBO01BQ0E7TUFDQTtNQUNBLEtBQUtaLElBQUksQ0FDTmdCLE1BQU0sQ0FBQzlCLFVBQVUsQ0FBQyxDQUNsQmtCLElBQUksQ0FBRWEsT0FBTyxJQUFLO1FBQ2pCLElBQUlwQixTQUFTLEVBQUU7UUFDZk4sVUFBVSxDQUNSMEIsT0FBTyxHQUNIO1VBQUV4QixLQUFLLEVBQUUsT0FBTztVQUFFTSxJQUFJLEVBQUViLFVBQVU7VUFBRTJCO1FBQVEsQ0FBQyxHQUM3QztVQUFFcEIsS0FBSyxFQUFFLFVBQVU7VUFBRU0sSUFBSSxFQUFFYjtRQUFXLENBQzVDLENBQUM7TUFDSCxDQUFDLENBQUMsQ0FDRHlCLEtBQUssQ0FBQyxNQUFNO1FBQ1gsSUFBSWQsU0FBUyxFQUFFO1FBQ2ZOLFVBQVUsQ0FBQztVQUFFRSxLQUFLLEVBQUUsT0FBTztVQUFFTSxJQUFJLEVBQUViLFVBQVU7VUFBRTJCO1FBQVEsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYaEIsU0FBUyxHQUFHLElBQUk7TUFDaEIsSUFBSUMsU0FBUyxFQUFFUSxHQUFHLENBQUNZLGVBQWUsQ0FBQ3BCLFNBQVMsQ0FBQztJQUMvQyxDQUFDO0VBQ0gsQ0FBQyxFQUFFLENBQUNaLFVBQVUsRUFBRUUsSUFBSSxFQUFFRCxTQUFTLEVBQUVPLFdBQVcsQ0FBQyxDQUFDOztFQUU5QztFQUNBO0VBQ0EsSUFBQUUsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDVixVQUFVLElBQUksQ0FBQ0UsSUFBSSxFQUFFO0lBQzFCLE9BQU8sSUFBQStCLGVBQVUsRUFBRUMsTUFBTSxJQUFLO01BQzVCLElBQUlBLE1BQU0sQ0FBQ0MsS0FBSyxLQUFLLENBQUMsRUFBRTtNQUN4QixJQUFJRCxNQUFNLENBQUNFLEtBQUssQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUssSUFBQUMsdUJBQVEsRUFBQ0QsQ0FBQyxFQUFFdEMsVUFBVSxDQUFDLENBQUMsRUFBRTtRQUNyRFMsY0FBYyxDQUFFK0IsQ0FBQyxJQUFLQSxDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQzlCO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUFFLENBQUN4QyxVQUFVLEVBQUVFLElBQUksQ0FBQyxDQUFDO0VBRXRCLE9BQU9FLE9BQU87QUFDaEIiLCJpZ25vcmVMaXN0IjpbXX0=