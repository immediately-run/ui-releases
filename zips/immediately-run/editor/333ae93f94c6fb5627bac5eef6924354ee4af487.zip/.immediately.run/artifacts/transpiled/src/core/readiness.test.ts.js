"use strict";

var _vitest = require("vitest");
var _readiness = require("./readiness");
(0, _vitest.describe)('readiness (§12.7 init race)', () => {
  (0, _vitest.it)('awaits the port when it has not arrived (either input order)', () => {
    (0, _vitest.expect)((0, _readiness.resolvePhase)({
      portReady: false,
      activeFile: null
    })).toBe('awaiting-port');
    // activeFile pushed before the port — still awaiting the port, never a crash:
    (0, _vitest.expect)((0, _readiness.resolvePhase)({
      portReady: false,
      activeFile: '/src/a.ts'
    })).toBe('awaiting-port');
  });
  (0, _vitest.it)('shows "no active file" once the port is ready but nothing is focused', () => {
    (0, _vitest.expect)((0, _readiness.resolvePhase)({
      portReady: true,
      activeFile: null
    })).toBe('no-active-file');
  });
  (0, _vitest.it)('is ready only when both the port and an active file are present', () => {
    (0, _vitest.expect)((0, _readiness.resolvePhase)({
      portReady: true,
      activeFile: '/src/a.ts'
    })).toBe('ready');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFkaW5lc3MiLCJkZXNjcmliZSIsIml0IiwiZXhwZWN0IiwicmVzb2x2ZVBoYXNlIiwicG9ydFJlYWR5IiwiYWN0aXZlRmlsZSIsInRvQmUiXSwic291cmNlcyI6WyJyZWFkaW5lc3MudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyByZXNvbHZlUGhhc2UgfSBmcm9tICcuL3JlYWRpbmVzcyc7XG5cbmRlc2NyaWJlKCdyZWFkaW5lc3MgKMKnMTIuNyBpbml0IHJhY2UpJywgKCkgPT4ge1xuICBpdCgnYXdhaXRzIHRoZSBwb3J0IHdoZW4gaXQgaGFzIG5vdCBhcnJpdmVkIChlaXRoZXIgaW5wdXQgb3JkZXIpJywgKCkgPT4ge1xuICAgIGV4cGVjdChyZXNvbHZlUGhhc2UoeyBwb3J0UmVhZHk6IGZhbHNlLCBhY3RpdmVGaWxlOiBudWxsIH0pKS50b0JlKCdhd2FpdGluZy1wb3J0Jyk7XG4gICAgLy8gYWN0aXZlRmlsZSBwdXNoZWQgYmVmb3JlIHRoZSBwb3J0IOKAlCBzdGlsbCBhd2FpdGluZyB0aGUgcG9ydCwgbmV2ZXIgYSBjcmFzaDpcbiAgICBleHBlY3QocmVzb2x2ZVBoYXNlKHsgcG9ydFJlYWR5OiBmYWxzZSwgYWN0aXZlRmlsZTogJy9zcmMvYS50cycgfSkpLnRvQmUoJ2F3YWl0aW5nLXBvcnQnKTtcbiAgfSk7XG5cbiAgaXQoJ3Nob3dzIFwibm8gYWN0aXZlIGZpbGVcIiBvbmNlIHRoZSBwb3J0IGlzIHJlYWR5IGJ1dCBub3RoaW5nIGlzIGZvY3VzZWQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KHJlc29sdmVQaGFzZSh7IHBvcnRSZWFkeTogdHJ1ZSwgYWN0aXZlRmlsZTogbnVsbCB9KSkudG9CZSgnbm8tYWN0aXZlLWZpbGUnKTtcbiAgfSk7XG5cbiAgaXQoJ2lzIHJlYWR5IG9ubHkgd2hlbiBib3RoIHRoZSBwb3J0IGFuZCBhbiBhY3RpdmUgZmlsZSBhcmUgcHJlc2VudCcsICgpID0+IHtcbiAgICBleHBlY3QocmVzb2x2ZVBoYXNlKHsgcG9ydFJlYWR5OiB0cnVlLCBhY3RpdmVGaWxlOiAnL3NyYy9hLnRzJyB9KSkudG9CZSgncmVhZHknKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxnQkFBUSxFQUFDLDZCQUE2QixFQUFFLE1BQU07RUFDNUMsSUFBQUMsVUFBRSxFQUFDLDhEQUE4RCxFQUFFLE1BQU07SUFDdkUsSUFBQUMsY0FBTSxFQUFDLElBQUFDLHVCQUFZLEVBQUM7TUFBRUMsU0FBUyxFQUFFLEtBQUs7TUFBRUMsVUFBVSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUNsRjtJQUNBLElBQUFKLGNBQU0sRUFBQyxJQUFBQyx1QkFBWSxFQUFDO01BQUVDLFNBQVMsRUFBRSxLQUFLO01BQUVDLFVBQVUsRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDM0YsQ0FBQyxDQUFDO0VBRUYsSUFBQUwsVUFBRSxFQUFDLHNFQUFzRSxFQUFFLE1BQU07SUFDL0UsSUFBQUMsY0FBTSxFQUFDLElBQUFDLHVCQUFZLEVBQUM7TUFBRUMsU0FBUyxFQUFFLElBQUk7TUFBRUMsVUFBVSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0VBQ3BGLENBQUMsQ0FBQztFQUVGLElBQUFMLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxNQUFNO0lBQzFFLElBQUFDLGNBQU0sRUFBQyxJQUFBQyx1QkFBWSxFQUFDO01BQUVDLFNBQVMsRUFBRSxJQUFJO01BQUVDLFVBQVUsRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDbEYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119