"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.samePath = void 0;
exports.useFileBuffer = useFileBuffer;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _buffer = require("../core/buffer");
var _debounce = require("../core/debounce");
var _imageFile = require("../core/imageFile");
var _workingTree = require("../fs/workingTree");
/* eslint-disable react-hooks/refs, react-hooks/set-state-in-effect --
   This hook is the editor's imperative write/conflict engine. It (a) holds the
   latest buffer in a ref so the debounced-write and change-poll closures read the
   current value (the React-sanctioned "latest value in an async callback" pattern),
   and (b) synchronises React state from two genuinely-external systems — the
   working-tree port read and the change poll — inside effects. Neither fits the
   "derive during render" model the react-hooks compiler rules assume; the rest of
   the app keeps those rules on. */
// Orchestrates one active file: read it through the rw working-tree port into the
// pure buffer state machine (`core/buffer.ts`), debounce writes back to the port,
// and fold external changes into the §6 conflict surface. The React glue lives
// here; the decision logic (when to conflict / block / resurrect) is in the
// unit-tested pure core.
//
// External-change source: we detect external writes by re-reading the active file
// when the host's §4.2 `onFsChange` channel reports it changed. The host fans that
// stream out to ALL working-tree consumers INCLUDING us, so a batch can be the
// echo of our own debounced write; the exclusion is consumer-side (the host does
// not tag ports).
//
// That exclusion used to be "disk == buffer ⇒ it was mine", which is not sound.
// The user keeps typing while a write is in flight, so the echo of write N
// legitimately differs from the buffer by keystroke N+1 — and the §6 machine,
// unable to see an origin, called that a foreign divergence and raised a BLOCKING
// conflict against nobody. So the exclusion is now identity-based: remember the
// exact bytes we last sent and the fact that a write is in flight, and recognise
// our own echo by those. Buffer equality remains as the innermost fallback inside
// `applyExternalChange`.

/** Compare two repo-relative paths tolerant of a leading-slash mismatch (the host
 *  pushes `/src/App.tsx`; the active file is also leading-slash, but be defensive).
 *  Exported for `useImagePreview` (R3-804), which matches fs-change batches the
 *  same way. */
const samePath = (a, b) => a.replace(/^\/+/, '') === b.replace(/^\/+/, '');
exports.samePath = samePath;
function useFileBuffer(activeFile) {
  const mounts = (0, _sdk.useMounts)();
  const writable = (0, _workingTree.isWritable)(mounts);
  const [buffer, setBufferState] = (0, _react.useState)(null);
  const [loadError, setLoadError] = (0, _react.useState)(null);
  const [saveError, setSaveError] = (0, _react.useState)(null);
  const [portReady, setPortReady] = (0, _react.useState)(false);

  // Refs mirror the latest state for the debounced-write and poll closures.
  const bufferRef = (0, _react.useRef)(null);
  const writeRef = (0, _react.useRef)(null);

  // ── Origin exclusion state (see the header note) ───────────────────────────
  /** The exact bytes of our most recent write, and where they went. An fs-change
   *  whose disk content equals this is our own echo, whatever the buffer now holds. */
  const lastWriteRef = (0, _react.useRef)(null);
  /** Writes we have issued and not yet seen settle, per path. While one is open,
   *  re-reading the path is pointless at best: the announcement can only be our
   *  own, and a read racing an in-flight write is not guaranteed to be whole. */
  const inFlightRef = (0, _react.useRef)(new Map());
  /** An fs-change we deferred because our own write was open. Drained when it settles. */
  const deferredRereadRef = (0, _react.useRef)(false);
  /** Re-read generation. Re-reads overlap (a batch can announce while an earlier
   *  read is still resolving) and there is no ordering guarantee on when they come
   *  back — so an OLDER read can resolve last and fold yesterday's bytes into the
   *  buffer. That is what threw the cursor to the top of the file: a stale
   *  clean-adopt replaced the whole CodeMirror document, and a whole-document
   *  replace maps every position to 0. Only the newest read is applied. */
  const readSeqRef = (0, _react.useRef)(0);
  /** Set by the fs-change effect so the write-settle path can drain the deferral. */
  const rereadRef = (0, _react.useRef)(null);
  const endWrite = (0, _react.useCallback)(path => {
    const open = (inFlightRef.current.get(path) ?? 1) - 1;
    if (open > 0) inFlightRef.current.set(path, open);else inFlightRef.current.delete(path);
    if (open > 0 || !deferredRereadRef.current) return;
    deferredRereadRef.current = false;
    rereadRef.current?.();
  }, []);
  const setBuffer = (0, _react.useCallback)(next => {
    bufferRef.current = next;
    setBufferState(next);
  }, []);

  // The debounced port write — created once. Writes `text` to `path`; on success
  // re-baselines (markSaved) iff the buffer is unchanged since, on failure
  // surfaces the error and leaves the buffer dirty (the user keeps their edit).
  if (!writeRef.current) {
    writeRef.current = (0, _debounce.debounce)((path, text) => {
      const tree = _workingTree.WorkingTree.current();
      // Record what we are about to send BEFORE awaiting: the host's fs-change
      // announcement can reach us before our own write promise resolves, and the
      // echo has to be recognisable as ours at that moment.
      lastWriteRef.current = {
        path,
        text
      };
      inFlightRef.current.set(path, (inFlightRef.current.get(path) ?? 0) + 1);
      tree.write(path, text).then(() => {
        setSaveError(null);
        const cur = bufferRef.current;
        if (cur && cur.path === path && cur.buffer === text) setBuffer((0, _buffer.markSaved)(cur));
      }).catch(e => setSaveError(e instanceof Error ? e.message : String(e))).finally(() => endWrite(path));
    });
  }

  // Track port readiness independently of the active file: the working-tree mount
  // can attach before OR after the first session push (§12.7 race), and a poll is
  // needed because the sandbox globals appear after boot, not via a React input.
  (0, _react.useEffect)(() => {
    if (portReady) return;
    const check = () => {
      if (_workingTree.WorkingTree.current().ready) setPortReady(true);
    };
    check();
    const id = window.setInterval(check, 300);
    return () => window.clearInterval(id);
  }, [portReady]);

  // Load the active file when it changes. Flush a pending write for the old file
  // first so the user's last edit is never dropped at the switch (§12.5).
  (0, _react.useEffect)(() => {
    writeRef.current?.flush();
    setLoadError(null);
    setSaveError(null);
    if (!activeFile) {
      setBuffer(null);
      return;
    }
    if ((0, _imageFile.imageMimeForPath)(activeFile)) {
      // R3-804 — an image never enters the text buffer: its bytes would decode
      // to mojibake and CodeMirror would parse megabytes of garbage. KEEP the
      // previous buffer (if any) so CodeMirrorView stays mounted under the
      // image overlay — the text→image→text round trip costs no editor
      // teardown. The stale buffer is inert: the fs-change effect below no-ops
      // while `buffer.path !== activeFile`, and App suppresses its chrome.
      return;
    }
    let cancelled = false;
    const tree = _workingTree.WorkingTree.current();
    setPortReady(tree.ready);
    tree.read(activeFile).then(content => {
      if (cancelled) return;
      setPortReady(true);
      setBuffer((0, _buffer.openBuffer)(activeFile, content));
    }).catch(e => {
      if (cancelled) return;
      setPortReady(tree.ready);
      // Port not up yet vs a genuine read failure: the readiness gate (App)
      // shows "awaiting port" for the former; surface the latter.
      setLoadError(e instanceof Error ? e.message : String(e));
      setBuffer(null);
    });
    return () => {
      cancelled = true;
    };
  }, [activeFile, setBuffer]);

  // React to external changes via the §4.2 `onFsChange` channel: when the active
  // file appears in a change batch, re-read it and fold the result through the
  // buffer machine (clean → silent adopt, dirty → blocking conflict; a read failure
  // on a previously-present file means it vanished, §12.4). This replaces the
  // earlier re-read poll — the host now pushes the changed paths, so we re-read
  // exactly the active file exactly when it changes, not on a timer.
  //
  // Origin exclusion (see the header note): a batch can be the echo of our OWN
  // debounced write, and neither the host nor the stream tags it as ours — so we
  // recognise it here, by the bytes we sent and by whether a write of ours is
  // still open.
  (0, _react.useEffect)(() => {
    if (!activeFile) return;
    let stopped = false;
    const reread = async () => {
      const cur = bufferRef.current;
      if (!cur || cur.path !== activeFile) return;
      // Our own write is still open: this announcement can only be that write, and
      // reading now would race it. Reconcile once it settles.
      if ((inFlightRef.current.get(activeFile) ?? 0) > 0) {
        deferredRereadRef.current = true;
        return;
      }
      const tree = _workingTree.WorkingTree.current();
      const seq = ++readSeqRef.current;
      try {
        const disk = await tree.read(activeFile);
        // A newer re-read overtook us: its bytes are the truth, ours are history.
        if (stopped || seq !== readSeqRef.current) return;
        // Re-read the LIVE buffer, not the pre-await snapshot: a write of ours may
        // have re-baselined it while this read was out.
        const now = bufferRef.current;
        if (!now || now.path !== activeFile || disk === now.baseline) return;
        const ours = lastWriteRef.current;
        if (ours && samePath(ours.path, activeFile) && disk === ours.text) {
          // Exactly the bytes we last sent — our echo, never a foreign change,
          // even if the user has typed since.
          setBuffer((0, _buffer.applyOwnWriteEcho)(now, disk));
          return;
        }
        setBuffer((0, _buffer.applyExternalChange)(now, disk));
      } catch {
        if (stopped || seq !== readSeqRef.current) return;
        // Distinguish a vanished file from a transient unreadable fs.
        const gone = !(await tree.exists(activeFile));
        if (!stopped && gone && bufferRef.current?.path === activeFile) {
          setBuffer((0, _buffer.applyExternalDelete)(bufferRef.current));
        }
      }
    };
    // The write-settle path drains a deferral through this.
    rereadRef.current = () => void reread();
    const unsubscribe = (0, _sdk.onFsChange)(change => {
      // epoch 0 is the empty initial (fires immediately on subscribe) — nothing to
      // re-read. Otherwise re-read iff the active file is in this batch.
      if (change.epoch === 0) return;
      if (change.paths.some(p => samePath(p, activeFile))) void reread();
    });
    return () => {
      stopped = true;
      rereadRef.current = null;
      // A deferral belongs to the file we are leaving; the load effect re-reads
      // the new one from scratch.
      deferredRereadRef.current = false;
      unsubscribe();
    };
  }, [activeFile, setBuffer]);

  // Flush the pending write on unmount so a debounced edit isn't lost on a
  // branch-switch remount / revocation (§12.5).
  (0, _react.useEffect)(() => {
    const w = writeRef.current;
    return () => w?.flush();
  }, []);
  const setText = (0, _react.useCallback)(next => {
    const cur = bufferRef.current;
    if (!cur) return;
    const updated = (0, _buffer.applyEdit)(cur, next);
    setBuffer(updated);
    // Only schedule a write when a save is actually permitted (not while
    // blocked by a conflict or vanished file — §6 / §12.4).
    if ((0, _buffer.canSave)(updated) && writable) writeRef.current?.(updated.path, updated.buffer);else writeRef.current?.cancel();
  }, [setBuffer, writable]);
  const resolveKeepMine = (0, _react.useCallback)(() => {
    const cur = bufferRef.current;
    if (!cur) return;
    const updated = (0, _buffer.resolveKeepMine)(cur);
    setBuffer(updated);
    if ((0, _buffer.canSave)(updated) && writable) writeRef.current?.(updated.path, updated.buffer);
  }, [setBuffer, writable]);
  const resolveTakeTheirs = (0, _react.useCallback)(() => {
    const cur = bufferRef.current;
    if (!cur) return;
    setBuffer((0, _buffer.resolveTakeTheirs)(cur));
  }, [setBuffer]);
  const flush = (0, _react.useCallback)(() => writeRef.current?.flush(), []);
  return {
    buffer,
    loadError,
    saveError,
    writable,
    portReady,
    setText,
    resolveKeepMine,
    resolveTakeTheirs,
    flush
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9idWZmZXIiLCJfZGVib3VuY2UiLCJfaW1hZ2VGaWxlIiwiX3dvcmtpbmdUcmVlIiwic2FtZVBhdGgiLCJhIiwiYiIsInJlcGxhY2UiLCJleHBvcnRzIiwidXNlRmlsZUJ1ZmZlciIsImFjdGl2ZUZpbGUiLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJ3cml0YWJsZSIsImlzV3JpdGFibGUiLCJidWZmZXIiLCJzZXRCdWZmZXJTdGF0ZSIsInVzZVN0YXRlIiwibG9hZEVycm9yIiwic2V0TG9hZEVycm9yIiwic2F2ZUVycm9yIiwic2V0U2F2ZUVycm9yIiwicG9ydFJlYWR5Iiwic2V0UG9ydFJlYWR5IiwiYnVmZmVyUmVmIiwidXNlUmVmIiwid3JpdGVSZWYiLCJsYXN0V3JpdGVSZWYiLCJpbkZsaWdodFJlZiIsIk1hcCIsImRlZmVycmVkUmVyZWFkUmVmIiwicmVhZFNlcVJlZiIsInJlcmVhZFJlZiIsImVuZFdyaXRlIiwidXNlQ2FsbGJhY2siLCJwYXRoIiwib3BlbiIsImN1cnJlbnQiLCJnZXQiLCJzZXQiLCJkZWxldGUiLCJzZXRCdWZmZXIiLCJuZXh0IiwiZGVib3VuY2UiLCJ0ZXh0IiwidHJlZSIsIldvcmtpbmdUcmVlIiwid3JpdGUiLCJ0aGVuIiwiY3VyIiwibWFya1NhdmVkIiwiY2F0Y2giLCJlIiwiRXJyb3IiLCJtZXNzYWdlIiwiU3RyaW5nIiwiZmluYWxseSIsInVzZUVmZmVjdCIsImNoZWNrIiwicmVhZHkiLCJpZCIsIndpbmRvdyIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsImZsdXNoIiwiaW1hZ2VNaW1lRm9yUGF0aCIsImNhbmNlbGxlZCIsInJlYWQiLCJjb250ZW50Iiwib3BlbkJ1ZmZlciIsInN0b3BwZWQiLCJyZXJlYWQiLCJzZXEiLCJkaXNrIiwibm93IiwiYmFzZWxpbmUiLCJvdXJzIiwiYXBwbHlPd25Xcml0ZUVjaG8iLCJhcHBseUV4dGVybmFsQ2hhbmdlIiwiZ29uZSIsImV4aXN0cyIsImFwcGx5RXh0ZXJuYWxEZWxldGUiLCJ1bnN1YnNjcmliZSIsIm9uRnNDaGFuZ2UiLCJjaGFuZ2UiLCJlcG9jaCIsInBhdGhzIiwic29tZSIsInAiLCJ3Iiwic2V0VGV4dCIsInVwZGF0ZWQiLCJhcHBseUVkaXQiLCJjYW5TYXZlT2YiLCJjYW5jZWwiLCJyZXNvbHZlS2VlcE1pbmUiLCJrZWVwTWluZSIsInJlc29sdmVUYWtlVGhlaXJzIiwidGFrZVRoZWlycyJdLCJzb3VyY2VzIjpbInVzZUZpbGVCdWZmZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgcmVhY3QtaG9va3MvcmVmcywgcmVhY3QtaG9va3Mvc2V0LXN0YXRlLWluLWVmZmVjdCAtLVxuICAgVGhpcyBob29rIGlzIHRoZSBlZGl0b3IncyBpbXBlcmF0aXZlIHdyaXRlL2NvbmZsaWN0IGVuZ2luZS4gSXQgKGEpIGhvbGRzIHRoZVxuICAgbGF0ZXN0IGJ1ZmZlciBpbiBhIHJlZiBzbyB0aGUgZGVib3VuY2VkLXdyaXRlIGFuZCBjaGFuZ2UtcG9sbCBjbG9zdXJlcyByZWFkIHRoZVxuICAgY3VycmVudCB2YWx1ZSAodGhlIFJlYWN0LXNhbmN0aW9uZWQgXCJsYXRlc3QgdmFsdWUgaW4gYW4gYXN5bmMgY2FsbGJhY2tcIiBwYXR0ZXJuKSxcbiAgIGFuZCAoYikgc3luY2hyb25pc2VzIFJlYWN0IHN0YXRlIGZyb20gdHdvIGdlbnVpbmVseS1leHRlcm5hbCBzeXN0ZW1zIOKAlCB0aGVcbiAgIHdvcmtpbmctdHJlZSBwb3J0IHJlYWQgYW5kIHRoZSBjaGFuZ2UgcG9sbCDigJQgaW5zaWRlIGVmZmVjdHMuIE5laXRoZXIgZml0cyB0aGVcbiAgIFwiZGVyaXZlIGR1cmluZyByZW5kZXJcIiBtb2RlbCB0aGUgcmVhY3QtaG9va3MgY29tcGlsZXIgcnVsZXMgYXNzdW1lOyB0aGUgcmVzdCBvZlxuICAgdGhlIGFwcCBrZWVwcyB0aG9zZSBydWxlcyBvbi4gKi9cbi8vIE9yY2hlc3RyYXRlcyBvbmUgYWN0aXZlIGZpbGU6IHJlYWQgaXQgdGhyb3VnaCB0aGUgcncgd29ya2luZy10cmVlIHBvcnQgaW50byB0aGVcbi8vIHB1cmUgYnVmZmVyIHN0YXRlIG1hY2hpbmUgKGBjb3JlL2J1ZmZlci50c2ApLCBkZWJvdW5jZSB3cml0ZXMgYmFjayB0byB0aGUgcG9ydCxcbi8vIGFuZCBmb2xkIGV4dGVybmFsIGNoYW5nZXMgaW50byB0aGUgwqc2IGNvbmZsaWN0IHN1cmZhY2UuIFRoZSBSZWFjdCBnbHVlIGxpdmVzXG4vLyBoZXJlOyB0aGUgZGVjaXNpb24gbG9naWMgKHdoZW4gdG8gY29uZmxpY3QgLyBibG9jayAvIHJlc3VycmVjdCkgaXMgaW4gdGhlXG4vLyB1bml0LXRlc3RlZCBwdXJlIGNvcmUuXG4vL1xuLy8gRXh0ZXJuYWwtY2hhbmdlIHNvdXJjZTogd2UgZGV0ZWN0IGV4dGVybmFsIHdyaXRlcyBieSByZS1yZWFkaW5nIHRoZSBhY3RpdmUgZmlsZVxuLy8gd2hlbiB0aGUgaG9zdCdzIMKnNC4yIGBvbkZzQ2hhbmdlYCBjaGFubmVsIHJlcG9ydHMgaXQgY2hhbmdlZC4gVGhlIGhvc3QgZmFucyB0aGF0XG4vLyBzdHJlYW0gb3V0IHRvIEFMTCB3b3JraW5nLXRyZWUgY29uc3VtZXJzIElOQ0xVRElORyB1cywgc28gYSBiYXRjaCBjYW4gYmUgdGhlXG4vLyBlY2hvIG9mIG91ciBvd24gZGVib3VuY2VkIHdyaXRlOyB0aGUgZXhjbHVzaW9uIGlzIGNvbnN1bWVyLXNpZGUgKHRoZSBob3N0IGRvZXNcbi8vIG5vdCB0YWcgcG9ydHMpLlxuLy9cbi8vIFRoYXQgZXhjbHVzaW9uIHVzZWQgdG8gYmUgXCJkaXNrID09IGJ1ZmZlciDih5IgaXQgd2FzIG1pbmVcIiwgd2hpY2ggaXMgbm90IHNvdW5kLlxuLy8gVGhlIHVzZXIga2VlcHMgdHlwaW5nIHdoaWxlIGEgd3JpdGUgaXMgaW4gZmxpZ2h0LCBzbyB0aGUgZWNobyBvZiB3cml0ZSBOXG4vLyBsZWdpdGltYXRlbHkgZGlmZmVycyBmcm9tIHRoZSBidWZmZXIgYnkga2V5c3Ryb2tlIE4rMSDigJQgYW5kIHRoZSDCpzYgbWFjaGluZSxcbi8vIHVuYWJsZSB0byBzZWUgYW4gb3JpZ2luLCBjYWxsZWQgdGhhdCBhIGZvcmVpZ24gZGl2ZXJnZW5jZSBhbmQgcmFpc2VkIGEgQkxPQ0tJTkdcbi8vIGNvbmZsaWN0IGFnYWluc3Qgbm9ib2R5LiBTbyB0aGUgZXhjbHVzaW9uIGlzIG5vdyBpZGVudGl0eS1iYXNlZDogcmVtZW1iZXIgdGhlXG4vLyBleGFjdCBieXRlcyB3ZSBsYXN0IHNlbnQgYW5kIHRoZSBmYWN0IHRoYXQgYSB3cml0ZSBpcyBpbiBmbGlnaHQsIGFuZCByZWNvZ25pc2Vcbi8vIG91ciBvd24gZWNobyBieSB0aG9zZS4gQnVmZmVyIGVxdWFsaXR5IHJlbWFpbnMgYXMgdGhlIGlubmVybW9zdCBmYWxsYmFjayBpbnNpZGVcbi8vIGBhcHBseUV4dGVybmFsQ2hhbmdlYC5cblxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1vdW50cywgb25Gc0NoYW5nZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7XG4gIG9wZW5CdWZmZXIsXG4gIGFwcGx5RWRpdCxcbiAgYXBwbHlFeHRlcm5hbENoYW5nZSxcbiAgYXBwbHlPd25Xcml0ZUVjaG8sXG4gIGFwcGx5RXh0ZXJuYWxEZWxldGUsXG4gIHJlc29sdmVLZWVwTWluZSBhcyBrZWVwTWluZSxcbiAgcmVzb2x2ZVRha2VUaGVpcnMgYXMgdGFrZVRoZWlycyxcbiAgbWFya1NhdmVkLFxuICBjYW5TYXZlIGFzIGNhblNhdmVPZixcbiAgdHlwZSBGaWxlQnVmZmVyLFxufSBmcm9tICcuLi9jb3JlL2J1ZmZlcic7XG5pbXBvcnQgeyBkZWJvdW5jZSwgdHlwZSBEZWJvdW5jZWQgfSBmcm9tICcuLi9jb3JlL2RlYm91bmNlJztcbmltcG9ydCB7IGltYWdlTWltZUZvclBhdGggfSBmcm9tICcuLi9jb3JlL2ltYWdlRmlsZSc7XG5pbXBvcnQgeyBXb3JraW5nVHJlZSwgaXNXcml0YWJsZSB9IGZyb20gJy4uL2ZzL3dvcmtpbmdUcmVlJztcblxuLyoqIENvbXBhcmUgdHdvIHJlcG8tcmVsYXRpdmUgcGF0aHMgdG9sZXJhbnQgb2YgYSBsZWFkaW5nLXNsYXNoIG1pc21hdGNoICh0aGUgaG9zdFxuICogIHB1c2hlcyBgL3NyYy9BcHAudHN4YDsgdGhlIGFjdGl2ZSBmaWxlIGlzIGFsc28gbGVhZGluZy1zbGFzaCwgYnV0IGJlIGRlZmVuc2l2ZSkuXG4gKiAgRXhwb3J0ZWQgZm9yIGB1c2VJbWFnZVByZXZpZXdgIChSMy04MDQpLCB3aGljaCBtYXRjaGVzIGZzLWNoYW5nZSBiYXRjaGVzIHRoZVxuICogIHNhbWUgd2F5LiAqL1xuZXhwb3J0IGNvbnN0IHNhbWVQYXRoID0gKGE6IHN0cmluZywgYjogc3RyaW5nKTogYm9vbGVhbiA9PlxuICBhLnJlcGxhY2UoL15cXC8rLywgJycpID09PSBiLnJlcGxhY2UoL15cXC8rLywgJycpO1xuXG5leHBvcnQgaW50ZXJmYWNlIFVzZUZpbGVCdWZmZXIge1xuICBidWZmZXI6IEZpbGVCdWZmZXIgfCBudWxsO1xuICBsb2FkRXJyb3I6IHN0cmluZyB8IG51bGw7XG4gIHNhdmVFcnJvcjogc3RyaW5nIHwgbnVsbDtcbiAgd3JpdGFibGU6IGJvb2xlYW47XG4gIHBvcnRSZWFkeTogYm9vbGVhbjtcbiAgc2V0VGV4dDogKG5leHQ6IHN0cmluZykgPT4gdm9pZDtcbiAgcmVzb2x2ZUtlZXBNaW5lOiAoKSA9PiB2b2lkO1xuICByZXNvbHZlVGFrZVRoZWlyczogKCkgPT4gdm9pZDtcbiAgLyoqIEZsdXNoIGFueSBwZW5kaW5nIGRlYm91bmNlZCB3cml0ZSBub3cgKHRlYXJkb3duIC8gZmlsZSBzd2l0Y2gsIMKnMTIuNSkuICovXG4gIGZsdXNoOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlRmlsZUJ1ZmZlcihhY3RpdmVGaWxlOiBzdHJpbmcgfCBudWxsKTogVXNlRmlsZUJ1ZmZlciB7XG4gIGNvbnN0IG1vdW50cyA9IHVzZU1vdW50cygpO1xuICBjb25zdCB3cml0YWJsZSA9IGlzV3JpdGFibGUobW91bnRzKTtcblxuICBjb25zdCBbYnVmZmVyLCBzZXRCdWZmZXJTdGF0ZV0gPSB1c2VTdGF0ZTxGaWxlQnVmZmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtsb2FkRXJyb3IsIHNldExvYWRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NhdmVFcnJvciwgc2V0U2F2ZUVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcG9ydFJlYWR5LCBzZXRQb3J0UmVhZHldID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIFJlZnMgbWlycm9yIHRoZSBsYXRlc3Qgc3RhdGUgZm9yIHRoZSBkZWJvdW5jZWQtd3JpdGUgYW5kIHBvbGwgY2xvc3VyZXMuXG4gIGNvbnN0IGJ1ZmZlclJlZiA9IHVzZVJlZjxGaWxlQnVmZmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHdyaXRlUmVmID0gdXNlUmVmPERlYm91bmNlZDxbc3RyaW5nLCBzdHJpbmddPiB8IG51bGw+KG51bGwpO1xuXG4gIC8vIOKUgOKUgCBPcmlnaW4gZXhjbHVzaW9uIHN0YXRlIChzZWUgdGhlIGhlYWRlciBub3RlKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLyoqIFRoZSBleGFjdCBieXRlcyBvZiBvdXIgbW9zdCByZWNlbnQgd3JpdGUsIGFuZCB3aGVyZSB0aGV5IHdlbnQuIEFuIGZzLWNoYW5nZVxuICAgKiAgd2hvc2UgZGlzayBjb250ZW50IGVxdWFscyB0aGlzIGlzIG91ciBvd24gZWNobywgd2hhdGV2ZXIgdGhlIGJ1ZmZlciBub3cgaG9sZHMuICovXG4gIGNvbnN0IGxhc3RXcml0ZVJlZiA9IHVzZVJlZjx7IHBhdGg6IHN0cmluZzsgdGV4dDogc3RyaW5nIH0gfCBudWxsPihudWxsKTtcbiAgLyoqIFdyaXRlcyB3ZSBoYXZlIGlzc3VlZCBhbmQgbm90IHlldCBzZWVuIHNldHRsZSwgcGVyIHBhdGguIFdoaWxlIG9uZSBpcyBvcGVuLFxuICAgKiAgcmUtcmVhZGluZyB0aGUgcGF0aCBpcyBwb2ludGxlc3MgYXQgYmVzdDogdGhlIGFubm91bmNlbWVudCBjYW4gb25seSBiZSBvdXJcbiAgICogIG93biwgYW5kIGEgcmVhZCByYWNpbmcgYW4gaW4tZmxpZ2h0IHdyaXRlIGlzIG5vdCBndWFyYW50ZWVkIHRvIGJlIHdob2xlLiAqL1xuICBjb25zdCBpbkZsaWdodFJlZiA9IHVzZVJlZihuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpKTtcbiAgLyoqIEFuIGZzLWNoYW5nZSB3ZSBkZWZlcnJlZCBiZWNhdXNlIG91ciBvd24gd3JpdGUgd2FzIG9wZW4uIERyYWluZWQgd2hlbiBpdCBzZXR0bGVzLiAqL1xuICBjb25zdCBkZWZlcnJlZFJlcmVhZFJlZiA9IHVzZVJlZihmYWxzZSk7XG4gIC8qKiBSZS1yZWFkIGdlbmVyYXRpb24uIFJlLXJlYWRzIG92ZXJsYXAgKGEgYmF0Y2ggY2FuIGFubm91bmNlIHdoaWxlIGFuIGVhcmxpZXJcbiAgICogIHJlYWQgaXMgc3RpbGwgcmVzb2x2aW5nKSBhbmQgdGhlcmUgaXMgbm8gb3JkZXJpbmcgZ3VhcmFudGVlIG9uIHdoZW4gdGhleSBjb21lXG4gICAqICBiYWNrIOKAlCBzbyBhbiBPTERFUiByZWFkIGNhbiByZXNvbHZlIGxhc3QgYW5kIGZvbGQgeWVzdGVyZGF5J3MgYnl0ZXMgaW50byB0aGVcbiAgICogIGJ1ZmZlci4gVGhhdCBpcyB3aGF0IHRocmV3IHRoZSBjdXJzb3IgdG8gdGhlIHRvcCBvZiB0aGUgZmlsZTogYSBzdGFsZVxuICAgKiAgY2xlYW4tYWRvcHQgcmVwbGFjZWQgdGhlIHdob2xlIENvZGVNaXJyb3IgZG9jdW1lbnQsIGFuZCBhIHdob2xlLWRvY3VtZW50XG4gICAqICByZXBsYWNlIG1hcHMgZXZlcnkgcG9zaXRpb24gdG8gMC4gT25seSB0aGUgbmV3ZXN0IHJlYWQgaXMgYXBwbGllZC4gKi9cbiAgY29uc3QgcmVhZFNlcVJlZiA9IHVzZVJlZigwKTtcbiAgLyoqIFNldCBieSB0aGUgZnMtY2hhbmdlIGVmZmVjdCBzbyB0aGUgd3JpdGUtc2V0dGxlIHBhdGggY2FuIGRyYWluIHRoZSBkZWZlcnJhbC4gKi9cbiAgY29uc3QgcmVyZWFkUmVmID0gdXNlUmVmPCgoKSA9PiB2b2lkKSB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGVuZFdyaXRlID0gdXNlQ2FsbGJhY2soKHBhdGg6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IG9wZW4gPSAoaW5GbGlnaHRSZWYuY3VycmVudC5nZXQocGF0aCkgPz8gMSkgLSAxO1xuICAgIGlmIChvcGVuID4gMCkgaW5GbGlnaHRSZWYuY3VycmVudC5zZXQocGF0aCwgb3Blbik7XG4gICAgZWxzZSBpbkZsaWdodFJlZi5jdXJyZW50LmRlbGV0ZShwYXRoKTtcbiAgICBpZiAob3BlbiA+IDAgfHwgIWRlZmVycmVkUmVyZWFkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBkZWZlcnJlZFJlcmVhZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgcmVyZWFkUmVmLmN1cnJlbnQ/LigpO1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc2V0QnVmZmVyID0gdXNlQ2FsbGJhY2soKG5leHQ6IEZpbGVCdWZmZXIgfCBudWxsKSA9PiB7XG4gICAgYnVmZmVyUmVmLmN1cnJlbnQgPSBuZXh0O1xuICAgIHNldEJ1ZmZlclN0YXRlKG5leHQpO1xuICB9LCBbXSk7XG5cbiAgLy8gVGhlIGRlYm91bmNlZCBwb3J0IHdyaXRlIOKAlCBjcmVhdGVkIG9uY2UuIFdyaXRlcyBgdGV4dGAgdG8gYHBhdGhgOyBvbiBzdWNjZXNzXG4gIC8vIHJlLWJhc2VsaW5lcyAobWFya1NhdmVkKSBpZmYgdGhlIGJ1ZmZlciBpcyB1bmNoYW5nZWQgc2luY2UsIG9uIGZhaWx1cmVcbiAgLy8gc3VyZmFjZXMgdGhlIGVycm9yIGFuZCBsZWF2ZXMgdGhlIGJ1ZmZlciBkaXJ0eSAodGhlIHVzZXIga2VlcHMgdGhlaXIgZWRpdCkuXG4gIGlmICghd3JpdGVSZWYuY3VycmVudCkge1xuICAgIHdyaXRlUmVmLmN1cnJlbnQgPSBkZWJvdW5jZTxbc3RyaW5nLCBzdHJpbmddPigocGF0aCwgdGV4dCkgPT4ge1xuICAgICAgY29uc3QgdHJlZSA9IFdvcmtpbmdUcmVlLmN1cnJlbnQoKTtcbiAgICAgIC8vIFJlY29yZCB3aGF0IHdlIGFyZSBhYm91dCB0byBzZW5kIEJFRk9SRSBhd2FpdGluZzogdGhlIGhvc3QncyBmcy1jaGFuZ2VcbiAgICAgIC8vIGFubm91bmNlbWVudCBjYW4gcmVhY2ggdXMgYmVmb3JlIG91ciBvd24gd3JpdGUgcHJvbWlzZSByZXNvbHZlcywgYW5kIHRoZVxuICAgICAgLy8gZWNobyBoYXMgdG8gYmUgcmVjb2duaXNhYmxlIGFzIG91cnMgYXQgdGhhdCBtb21lbnQuXG4gICAgICBsYXN0V3JpdGVSZWYuY3VycmVudCA9IHsgcGF0aCwgdGV4dCB9O1xuICAgICAgaW5GbGlnaHRSZWYuY3VycmVudC5zZXQocGF0aCwgKGluRmxpZ2h0UmVmLmN1cnJlbnQuZ2V0KHBhdGgpID8/IDApICsgMSk7XG4gICAgICB0cmVlXG4gICAgICAgIC53cml0ZShwYXRoLCB0ZXh0KVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgc2V0U2F2ZUVycm9yKG51bGwpO1xuICAgICAgICAgIGNvbnN0IGN1ciA9IGJ1ZmZlclJlZi5jdXJyZW50O1xuICAgICAgICAgIGlmIChjdXIgJiYgY3VyLnBhdGggPT09IHBhdGggJiYgY3VyLmJ1ZmZlciA9PT0gdGV4dCkgc2V0QnVmZmVyKG1hcmtTYXZlZChjdXIpKTtcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKChlOiB1bmtub3duKSA9PiBzZXRTYXZlRXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpKSlcbiAgICAgICAgLmZpbmFsbHkoKCkgPT4gZW5kV3JpdGUocGF0aCkpO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gVHJhY2sgcG9ydCByZWFkaW5lc3MgaW5kZXBlbmRlbnRseSBvZiB0aGUgYWN0aXZlIGZpbGU6IHRoZSB3b3JraW5nLXRyZWUgbW91bnRcbiAgLy8gY2FuIGF0dGFjaCBiZWZvcmUgT1IgYWZ0ZXIgdGhlIGZpcnN0IHNlc3Npb24gcHVzaCAowqcxMi43IHJhY2UpLCBhbmQgYSBwb2xsIGlzXG4gIC8vIG5lZWRlZCBiZWNhdXNlIHRoZSBzYW5kYm94IGdsb2JhbHMgYXBwZWFyIGFmdGVyIGJvb3QsIG5vdCB2aWEgYSBSZWFjdCBpbnB1dC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocG9ydFJlYWR5KSByZXR1cm47XG4gICAgY29uc3QgY2hlY2sgPSAoKSA9PiB7XG4gICAgICBpZiAoV29ya2luZ1RyZWUuY3VycmVudCgpLnJlYWR5KSBzZXRQb3J0UmVhZHkodHJ1ZSk7XG4gICAgfTtcbiAgICBjaGVjaygpO1xuICAgIGNvbnN0IGlkID0gd2luZG93LnNldEludGVydmFsKGNoZWNrLCAzMDApO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbChpZCk7XG4gIH0sIFtwb3J0UmVhZHldKTtcblxuICAvLyBMb2FkIHRoZSBhY3RpdmUgZmlsZSB3aGVuIGl0IGNoYW5nZXMuIEZsdXNoIGEgcGVuZGluZyB3cml0ZSBmb3IgdGhlIG9sZCBmaWxlXG4gIC8vIGZpcnN0IHNvIHRoZSB1c2VyJ3MgbGFzdCBlZGl0IGlzIG5ldmVyIGRyb3BwZWQgYXQgdGhlIHN3aXRjaCAowqcxMi41KS5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB3cml0ZVJlZi5jdXJyZW50Py5mbHVzaCgpO1xuICAgIHNldExvYWRFcnJvcihudWxsKTtcbiAgICBzZXRTYXZlRXJyb3IobnVsbCk7XG4gICAgaWYgKCFhY3RpdmVGaWxlKSB7XG4gICAgICBzZXRCdWZmZXIobnVsbCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChpbWFnZU1pbWVGb3JQYXRoKGFjdGl2ZUZpbGUpKSB7XG4gICAgICAvLyBSMy04MDQg4oCUIGFuIGltYWdlIG5ldmVyIGVudGVycyB0aGUgdGV4dCBidWZmZXI6IGl0cyBieXRlcyB3b3VsZCBkZWNvZGVcbiAgICAgIC8vIHRvIG1vamliYWtlIGFuZCBDb2RlTWlycm9yIHdvdWxkIHBhcnNlIG1lZ2FieXRlcyBvZiBnYXJiYWdlLiBLRUVQIHRoZVxuICAgICAgLy8gcHJldmlvdXMgYnVmZmVyIChpZiBhbnkpIHNvIENvZGVNaXJyb3JWaWV3IHN0YXlzIG1vdW50ZWQgdW5kZXIgdGhlXG4gICAgICAvLyBpbWFnZSBvdmVybGF5IOKAlCB0aGUgdGV4dOKGkmltYWdl4oaSdGV4dCByb3VuZCB0cmlwIGNvc3RzIG5vIGVkaXRvclxuICAgICAgLy8gdGVhcmRvd24uIFRoZSBzdGFsZSBidWZmZXIgaXMgaW5lcnQ6IHRoZSBmcy1jaGFuZ2UgZWZmZWN0IGJlbG93IG5vLW9wc1xuICAgICAgLy8gd2hpbGUgYGJ1ZmZlci5wYXRoICE9PSBhY3RpdmVGaWxlYCwgYW5kIEFwcCBzdXBwcmVzc2VzIGl0cyBjaHJvbWUuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICBjb25zdCB0cmVlID0gV29ya2luZ1RyZWUuY3VycmVudCgpO1xuICAgIHNldFBvcnRSZWFkeSh0cmVlLnJlYWR5KTtcbiAgICB0cmVlXG4gICAgICAucmVhZChhY3RpdmVGaWxlKVxuICAgICAgLnRoZW4oKGNvbnRlbnQpID0+IHtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICBzZXRQb3J0UmVhZHkodHJ1ZSk7XG4gICAgICAgIHNldEJ1ZmZlcihvcGVuQnVmZmVyKGFjdGl2ZUZpbGUsIGNvbnRlbnQpKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGU6IHVua25vd24pID0+IHtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICBzZXRQb3J0UmVhZHkodHJlZS5yZWFkeSk7XG4gICAgICAgIC8vIFBvcnQgbm90IHVwIHlldCB2cyBhIGdlbnVpbmUgcmVhZCBmYWlsdXJlOiB0aGUgcmVhZGluZXNzIGdhdGUgKEFwcClcbiAgICAgICAgLy8gc2hvd3MgXCJhd2FpdGluZyBwb3J0XCIgZm9yIHRoZSBmb3JtZXI7IHN1cmZhY2UgdGhlIGxhdHRlci5cbiAgICAgICAgc2V0TG9hZEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFN0cmluZyhlKSk7XG4gICAgICAgIHNldEJ1ZmZlcihudWxsKTtcbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgIH07XG4gIH0sIFthY3RpdmVGaWxlLCBzZXRCdWZmZXJdKTtcblxuICAvLyBSZWFjdCB0byBleHRlcm5hbCBjaGFuZ2VzIHZpYSB0aGUgwqc0LjIgYG9uRnNDaGFuZ2VgIGNoYW5uZWw6IHdoZW4gdGhlIGFjdGl2ZVxuICAvLyBmaWxlIGFwcGVhcnMgaW4gYSBjaGFuZ2UgYmF0Y2gsIHJlLXJlYWQgaXQgYW5kIGZvbGQgdGhlIHJlc3VsdCB0aHJvdWdoIHRoZVxuICAvLyBidWZmZXIgbWFjaGluZSAoY2xlYW4g4oaSIHNpbGVudCBhZG9wdCwgZGlydHkg4oaSIGJsb2NraW5nIGNvbmZsaWN0OyBhIHJlYWQgZmFpbHVyZVxuICAvLyBvbiBhIHByZXZpb3VzbHktcHJlc2VudCBmaWxlIG1lYW5zIGl0IHZhbmlzaGVkLCDCpzEyLjQpLiBUaGlzIHJlcGxhY2VzIHRoZVxuICAvLyBlYXJsaWVyIHJlLXJlYWQgcG9sbCDigJQgdGhlIGhvc3Qgbm93IHB1c2hlcyB0aGUgY2hhbmdlZCBwYXRocywgc28gd2UgcmUtcmVhZFxuICAvLyBleGFjdGx5IHRoZSBhY3RpdmUgZmlsZSBleGFjdGx5IHdoZW4gaXQgY2hhbmdlcywgbm90IG9uIGEgdGltZXIuXG4gIC8vXG4gIC8vIE9yaWdpbiBleGNsdXNpb24gKHNlZSB0aGUgaGVhZGVyIG5vdGUpOiBhIGJhdGNoIGNhbiBiZSB0aGUgZWNobyBvZiBvdXIgT1dOXG4gIC8vIGRlYm91bmNlZCB3cml0ZSwgYW5kIG5laXRoZXIgdGhlIGhvc3Qgbm9yIHRoZSBzdHJlYW0gdGFncyBpdCBhcyBvdXJzIOKAlCBzbyB3ZVxuICAvLyByZWNvZ25pc2UgaXQgaGVyZSwgYnkgdGhlIGJ5dGVzIHdlIHNlbnQgYW5kIGJ5IHdoZXRoZXIgYSB3cml0ZSBvZiBvdXJzIGlzXG4gIC8vIHN0aWxsIG9wZW4uXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFhY3RpdmVGaWxlKSByZXR1cm47XG4gICAgbGV0IHN0b3BwZWQgPSBmYWxzZTtcbiAgICBjb25zdCByZXJlYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBjdXIgPSBidWZmZXJSZWYuY3VycmVudDtcbiAgICAgIGlmICghY3VyIHx8IGN1ci5wYXRoICE9PSBhY3RpdmVGaWxlKSByZXR1cm47XG4gICAgICAvLyBPdXIgb3duIHdyaXRlIGlzIHN0aWxsIG9wZW46IHRoaXMgYW5ub3VuY2VtZW50IGNhbiBvbmx5IGJlIHRoYXQgd3JpdGUsIGFuZFxuICAgICAgLy8gcmVhZGluZyBub3cgd291bGQgcmFjZSBpdC4gUmVjb25jaWxlIG9uY2UgaXQgc2V0dGxlcy5cbiAgICAgIGlmICgoaW5GbGlnaHRSZWYuY3VycmVudC5nZXQoYWN0aXZlRmlsZSkgPz8gMCkgPiAwKSB7XG4gICAgICAgIGRlZmVycmVkUmVyZWFkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0cmVlID0gV29ya2luZ1RyZWUuY3VycmVudCgpO1xuICAgICAgY29uc3Qgc2VxID0gKytyZWFkU2VxUmVmLmN1cnJlbnQ7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBkaXNrID0gYXdhaXQgdHJlZS5yZWFkKGFjdGl2ZUZpbGUpO1xuICAgICAgICAvLyBBIG5ld2VyIHJlLXJlYWQgb3ZlcnRvb2sgdXM6IGl0cyBieXRlcyBhcmUgdGhlIHRydXRoLCBvdXJzIGFyZSBoaXN0b3J5LlxuICAgICAgICBpZiAoc3RvcHBlZCB8fCBzZXEgIT09IHJlYWRTZXFSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAvLyBSZS1yZWFkIHRoZSBMSVZFIGJ1ZmZlciwgbm90IHRoZSBwcmUtYXdhaXQgc25hcHNob3Q6IGEgd3JpdGUgb2Ygb3VycyBtYXlcbiAgICAgICAgLy8gaGF2ZSByZS1iYXNlbGluZWQgaXQgd2hpbGUgdGhpcyByZWFkIHdhcyBvdXQuXG4gICAgICAgIGNvbnN0IG5vdyA9IGJ1ZmZlclJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoIW5vdyB8fCBub3cucGF0aCAhPT0gYWN0aXZlRmlsZSB8fCBkaXNrID09PSBub3cuYmFzZWxpbmUpIHJldHVybjtcbiAgICAgICAgY29uc3Qgb3VycyA9IGxhc3RXcml0ZVJlZi5jdXJyZW50O1xuICAgICAgICBpZiAob3VycyAmJiBzYW1lUGF0aChvdXJzLnBhdGgsIGFjdGl2ZUZpbGUpICYmIGRpc2sgPT09IG91cnMudGV4dCkge1xuICAgICAgICAgIC8vIEV4YWN0bHkgdGhlIGJ5dGVzIHdlIGxhc3Qgc2VudCDigJQgb3VyIGVjaG8sIG5ldmVyIGEgZm9yZWlnbiBjaGFuZ2UsXG4gICAgICAgICAgLy8gZXZlbiBpZiB0aGUgdXNlciBoYXMgdHlwZWQgc2luY2UuXG4gICAgICAgICAgc2V0QnVmZmVyKGFwcGx5T3duV3JpdGVFY2hvKG5vdywgZGlzaykpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRCdWZmZXIoYXBwbHlFeHRlcm5hbENoYW5nZShub3csIGRpc2spKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBpZiAoc3RvcHBlZCB8fCBzZXEgIT09IHJlYWRTZXFSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAvLyBEaXN0aW5ndWlzaCBhIHZhbmlzaGVkIGZpbGUgZnJvbSBhIHRyYW5zaWVudCB1bnJlYWRhYmxlIGZzLlxuICAgICAgICBjb25zdCBnb25lID0gIShhd2FpdCB0cmVlLmV4aXN0cyhhY3RpdmVGaWxlKSk7XG4gICAgICAgIGlmICghc3RvcHBlZCAmJiBnb25lICYmIGJ1ZmZlclJlZi5jdXJyZW50Py5wYXRoID09PSBhY3RpdmVGaWxlKSB7XG4gICAgICAgICAgc2V0QnVmZmVyKGFwcGx5RXh0ZXJuYWxEZWxldGUoYnVmZmVyUmVmLmN1cnJlbnQpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgLy8gVGhlIHdyaXRlLXNldHRsZSBwYXRoIGRyYWlucyBhIGRlZmVycmFsIHRocm91Z2ggdGhpcy5cbiAgICByZXJlYWRSZWYuY3VycmVudCA9ICgpID0+IHZvaWQgcmVyZWFkKCk7XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSBvbkZzQ2hhbmdlKChjaGFuZ2UpID0+IHtcbiAgICAgIC8vIGVwb2NoIDAgaXMgdGhlIGVtcHR5IGluaXRpYWwgKGZpcmVzIGltbWVkaWF0ZWx5IG9uIHN1YnNjcmliZSkg4oCUIG5vdGhpbmcgdG9cbiAgICAgIC8vIHJlLXJlYWQuIE90aGVyd2lzZSByZS1yZWFkIGlmZiB0aGUgYWN0aXZlIGZpbGUgaXMgaW4gdGhpcyBiYXRjaC5cbiAgICAgIGlmIChjaGFuZ2UuZXBvY2ggPT09IDApIHJldHVybjtcbiAgICAgIGlmIChjaGFuZ2UucGF0aHMuc29tZSgocCkgPT4gc2FtZVBhdGgocCwgYWN0aXZlRmlsZSkpKSB2b2lkIHJlcmVhZCgpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzdG9wcGVkID0gdHJ1ZTtcbiAgICAgIHJlcmVhZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIC8vIEEgZGVmZXJyYWwgYmVsb25ncyB0byB0aGUgZmlsZSB3ZSBhcmUgbGVhdmluZzsgdGhlIGxvYWQgZWZmZWN0IHJlLXJlYWRzXG4gICAgICAvLyB0aGUgbmV3IG9uZSBmcm9tIHNjcmF0Y2guXG4gICAgICBkZWZlcnJlZFJlcmVhZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgIH07XG4gIH0sIFthY3RpdmVGaWxlLCBzZXRCdWZmZXJdKTtcblxuICAvLyBGbHVzaCB0aGUgcGVuZGluZyB3cml0ZSBvbiB1bm1vdW50IHNvIGEgZGVib3VuY2VkIGVkaXQgaXNuJ3QgbG9zdCBvbiBhXG4gIC8vIGJyYW5jaC1zd2l0Y2ggcmVtb3VudCAvIHJldm9jYXRpb24gKMKnMTIuNSkuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdyA9IHdyaXRlUmVmLmN1cnJlbnQ7XG4gICAgcmV0dXJuICgpID0+IHc/LmZsdXNoKCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBzZXRUZXh0ID0gdXNlQ2FsbGJhY2soXG4gICAgKG5leHQ6IHN0cmluZykgPT4ge1xuICAgICAgY29uc3QgY3VyID0gYnVmZmVyUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIWN1cikgcmV0dXJuO1xuICAgICAgY29uc3QgdXBkYXRlZCA9IGFwcGx5RWRpdChjdXIsIG5leHQpO1xuICAgICAgc2V0QnVmZmVyKHVwZGF0ZWQpO1xuICAgICAgLy8gT25seSBzY2hlZHVsZSBhIHdyaXRlIHdoZW4gYSBzYXZlIGlzIGFjdHVhbGx5IHBlcm1pdHRlZCAobm90IHdoaWxlXG4gICAgICAvLyBibG9ja2VkIGJ5IGEgY29uZmxpY3Qgb3IgdmFuaXNoZWQgZmlsZSDigJQgwqc2IC8gwqcxMi40KS5cbiAgICAgIGlmIChjYW5TYXZlT2YodXBkYXRlZCkgJiYgd3JpdGFibGUpIHdyaXRlUmVmLmN1cnJlbnQ/Lih1cGRhdGVkLnBhdGgsIHVwZGF0ZWQuYnVmZmVyKTtcbiAgICAgIGVsc2Ugd3JpdGVSZWYuY3VycmVudD8uY2FuY2VsKCk7XG4gICAgfSxcbiAgICBbc2V0QnVmZmVyLCB3cml0YWJsZV0sXG4gICk7XG5cbiAgY29uc3QgcmVzb2x2ZUtlZXBNaW5lID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGN1ciA9IGJ1ZmZlclJlZi5jdXJyZW50O1xuICAgIGlmICghY3VyKSByZXR1cm47XG4gICAgY29uc3QgdXBkYXRlZCA9IGtlZXBNaW5lKGN1cik7XG4gICAgc2V0QnVmZmVyKHVwZGF0ZWQpO1xuICAgIGlmIChjYW5TYXZlT2YodXBkYXRlZCkgJiYgd3JpdGFibGUpIHdyaXRlUmVmLmN1cnJlbnQ/Lih1cGRhdGVkLnBhdGgsIHVwZGF0ZWQuYnVmZmVyKTtcbiAgfSwgW3NldEJ1ZmZlciwgd3JpdGFibGVdKTtcblxuICBjb25zdCByZXNvbHZlVGFrZVRoZWlycyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBjdXIgPSBidWZmZXJSZWYuY3VycmVudDtcbiAgICBpZiAoIWN1cikgcmV0dXJuO1xuICAgIHNldEJ1ZmZlcih0YWtlVGhlaXJzKGN1cikpO1xuICB9LCBbc2V0QnVmZmVyXSk7XG5cbiAgY29uc3QgZmx1c2ggPSB1c2VDYWxsYmFjaygoKSA9PiB3cml0ZVJlZi5jdXJyZW50Py5mbHVzaCgpLCBbXSk7XG5cbiAgcmV0dXJuIHtcbiAgICBidWZmZXIsXG4gICAgbG9hZEVycm9yLFxuICAgIHNhdmVFcnJvcixcbiAgICB3cml0YWJsZSxcbiAgICBwb3J0UmVhZHksXG4gICAgc2V0VGV4dCxcbiAgICByZXNvbHZlS2VlcE1pbmUsXG4gICAgcmVzb2x2ZVRha2VUaGVpcnMsXG4gICAgZmx1c2gsXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQTZCQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFZQSxJQUFBRyxTQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxVQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFMLE9BQUE7QUE3Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBb0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTU0sUUFBUSxHQUFHQSxDQUFDQyxDQUFTLEVBQUVDLENBQVMsS0FDM0NELENBQUMsQ0FBQ0UsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsS0FBS0QsQ0FBQyxDQUFDQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQztBQUFDQyxPQUFBLENBQUFKLFFBQUEsR0FBQUEsUUFBQTtBQWUzQyxTQUFTSyxhQUFhQSxDQUFDQyxVQUF5QixFQUFpQjtFQUN0RSxNQUFNQyxNQUFNLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUM7RUFDMUIsTUFBTUMsUUFBUSxHQUFHLElBQUFDLHVCQUFVLEVBQUNILE1BQU0sQ0FBQztFQUVuQyxNQUFNLENBQUNJLE1BQU0sRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFvQixJQUFJLENBQUM7RUFDbEUsTUFBTSxDQUFDQyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQy9ELE1BQU0sQ0FBQ0csU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUMvRCxNQUFNLENBQUNLLFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUcsSUFBQU4sZUFBUSxFQUFDLEtBQUssQ0FBQzs7RUFFakQ7RUFDQSxNQUFNTyxTQUFTLEdBQUcsSUFBQUMsYUFBTSxFQUFvQixJQUFJLENBQUM7RUFDakQsTUFBTUMsUUFBUSxHQUFHLElBQUFELGFBQU0sRUFBcUMsSUFBSSxDQUFDOztFQUVqRTtFQUNBO0FBQ0Y7RUFDRSxNQUFNRSxZQUFZLEdBQUcsSUFBQUYsYUFBTSxFQUF3QyxJQUFJLENBQUM7RUFDeEU7QUFDRjtBQUNBO0VBQ0UsTUFBTUcsV0FBVyxHQUFHLElBQUFILGFBQU0sRUFBQyxJQUFJSSxHQUFHLENBQWlCLENBQUMsQ0FBQztFQUNyRDtFQUNBLE1BQU1DLGlCQUFpQixHQUFHLElBQUFMLGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDdkM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTU0sVUFBVSxHQUFHLElBQUFOLGFBQU0sRUFBQyxDQUFDLENBQUM7RUFDNUI7RUFDQSxNQUFNTyxTQUFTLEdBQUcsSUFBQVAsYUFBTSxFQUFzQixJQUFJLENBQUM7RUFFbkQsTUFBTVEsUUFBUSxHQUFHLElBQUFDLGtCQUFXLEVBQUVDLElBQVksSUFBSztJQUM3QyxNQUFNQyxJQUFJLEdBQUcsQ0FBQ1IsV0FBVyxDQUFDUyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDckQsSUFBSUMsSUFBSSxHQUFHLENBQUMsRUFBRVIsV0FBVyxDQUFDUyxPQUFPLENBQUNFLEdBQUcsQ0FBQ0osSUFBSSxFQUFFQyxJQUFJLENBQUMsQ0FBQyxLQUM3Q1IsV0FBVyxDQUFDUyxPQUFPLENBQUNHLE1BQU0sQ0FBQ0wsSUFBSSxDQUFDO0lBQ3JDLElBQUlDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQ04saUJBQWlCLENBQUNPLE9BQU8sRUFBRTtJQUM1Q1AsaUJBQWlCLENBQUNPLE9BQU8sR0FBRyxLQUFLO0lBQ2pDTCxTQUFTLENBQUNLLE9BQU8sR0FBRyxDQUFDO0VBQ3ZCLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNSSxTQUFTLEdBQUcsSUFBQVAsa0JBQVcsRUFBRVEsSUFBdUIsSUFBSztJQUN6RGxCLFNBQVMsQ0FBQ2EsT0FBTyxHQUFHSyxJQUFJO0lBQ3hCMUIsY0FBYyxDQUFDMEIsSUFBSSxDQUFDO0VBQ3RCLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0EsSUFBSSxDQUFDaEIsUUFBUSxDQUFDVyxPQUFPLEVBQUU7SUFDckJYLFFBQVEsQ0FBQ1csT0FBTyxHQUFHLElBQUFNLGtCQUFRLEVBQW1CLENBQUNSLElBQUksRUFBRVMsSUFBSSxLQUFLO01BQzVELE1BQU1DLElBQUksR0FBR0Msd0JBQVcsQ0FBQ1QsT0FBTyxDQUFDLENBQUM7TUFDbEM7TUFDQTtNQUNBO01BQ0FWLFlBQVksQ0FBQ1UsT0FBTyxHQUFHO1FBQUVGLElBQUk7UUFBRVM7TUFBSyxDQUFDO01BQ3JDaEIsV0FBVyxDQUFDUyxPQUFPLENBQUNFLEdBQUcsQ0FBQ0osSUFBSSxFQUFFLENBQUNQLFdBQVcsQ0FBQ1MsT0FBTyxDQUFDQyxHQUFHLENBQUNILElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7TUFDdkVVLElBQUksQ0FDREUsS0FBSyxDQUFDWixJQUFJLEVBQUVTLElBQUksQ0FBQyxDQUNqQkksSUFBSSxDQUFDLE1BQU07UUFDVjNCLFlBQVksQ0FBQyxJQUFJLENBQUM7UUFDbEIsTUFBTTRCLEdBQUcsR0FBR3pCLFNBQVMsQ0FBQ2EsT0FBTztRQUM3QixJQUFJWSxHQUFHLElBQUlBLEdBQUcsQ0FBQ2QsSUFBSSxLQUFLQSxJQUFJLElBQUljLEdBQUcsQ0FBQ2xDLE1BQU0sS0FBSzZCLElBQUksRUFBRUgsU0FBUyxDQUFDLElBQUFTLGlCQUFTLEVBQUNELEdBQUcsQ0FBQyxDQUFDO01BQ2hGLENBQUMsQ0FBQyxDQUNERSxLQUFLLENBQUVDLENBQVUsSUFBSy9CLFlBQVksQ0FBQytCLENBQUMsWUFBWUMsS0FBSyxHQUFHRCxDQUFDLENBQUNFLE9BQU8sR0FBR0MsTUFBTSxDQUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQy9FSSxPQUFPLENBQUMsTUFBTXZCLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQTtFQUNBO0VBQ0EsSUFBQXNCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUluQyxTQUFTLEVBQUU7SUFDZixNQUFNb0MsS0FBSyxHQUFHQSxDQUFBLEtBQU07TUFDbEIsSUFBSVosd0JBQVcsQ0FBQ1QsT0FBTyxDQUFDLENBQUMsQ0FBQ3NCLEtBQUssRUFBRXBDLFlBQVksQ0FBQyxJQUFJLENBQUM7SUFDckQsQ0FBQztJQUNEbUMsS0FBSyxDQUFDLENBQUM7SUFDUCxNQUFNRSxFQUFFLEdBQUdDLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDSixLQUFLLEVBQUUsR0FBRyxDQUFDO0lBQ3pDLE9BQU8sTUFBTUcsTUFBTSxDQUFDRSxhQUFhLENBQUNILEVBQUUsQ0FBQztFQUN2QyxDQUFDLEVBQUUsQ0FBQ3RDLFNBQVMsQ0FBQyxDQUFDOztFQUVmO0VBQ0E7RUFDQSxJQUFBbUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QvQixRQUFRLENBQUNXLE9BQU8sRUFBRTJCLEtBQUssQ0FBQyxDQUFDO0lBQ3pCN0MsWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQkUsWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQixJQUFJLENBQUNYLFVBQVUsRUFBRTtNQUNmK0IsU0FBUyxDQUFDLElBQUksQ0FBQztNQUNmO0lBQ0Y7SUFDQSxJQUFJLElBQUF3QiwyQkFBZ0IsRUFBQ3ZELFVBQVUsQ0FBQyxFQUFFO01BQ2hDO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO0lBQ0Y7SUFDQSxJQUFJd0QsU0FBUyxHQUFHLEtBQUs7SUFDckIsTUFBTXJCLElBQUksR0FBR0Msd0JBQVcsQ0FBQ1QsT0FBTyxDQUFDLENBQUM7SUFDbENkLFlBQVksQ0FBQ3NCLElBQUksQ0FBQ2MsS0FBSyxDQUFDO0lBQ3hCZCxJQUFJLENBQ0RzQixJQUFJLENBQUN6RCxVQUFVLENBQUMsQ0FDaEJzQyxJQUFJLENBQUVvQixPQUFPLElBQUs7TUFDakIsSUFBSUYsU0FBUyxFQUFFO01BQ2YzQyxZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2xCa0IsU0FBUyxDQUFDLElBQUE0QixrQkFBVSxFQUFDM0QsVUFBVSxFQUFFMEQsT0FBTyxDQUFDLENBQUM7SUFDNUMsQ0FBQyxDQUFDLENBQ0RqQixLQUFLLENBQUVDLENBQVUsSUFBSztNQUNyQixJQUFJYyxTQUFTLEVBQUU7TUFDZjNDLFlBQVksQ0FBQ3NCLElBQUksQ0FBQ2MsS0FBSyxDQUFDO01BQ3hCO01BQ0E7TUFDQXhDLFlBQVksQ0FBQ2lDLENBQUMsWUFBWUMsS0FBSyxHQUFHRCxDQUFDLENBQUNFLE9BQU8sR0FBR0MsTUFBTSxDQUFDSCxDQUFDLENBQUMsQ0FBQztNQUN4RFgsU0FBUyxDQUFDLElBQUksQ0FBQztJQUNqQixDQUFDLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWHlCLFNBQVMsR0FBRyxJQUFJO0lBQ2xCLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ3hELFVBQVUsRUFBRStCLFNBQVMsQ0FBQyxDQUFDOztFQUUzQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQWdCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQy9DLFVBQVUsRUFBRTtJQUNqQixJQUFJNEQsT0FBTyxHQUFHLEtBQUs7SUFDbkIsTUFBTUMsTUFBTSxHQUFHLE1BQUFBLENBQUEsS0FBWTtNQUN6QixNQUFNdEIsR0FBRyxHQUFHekIsU0FBUyxDQUFDYSxPQUFPO01BQzdCLElBQUksQ0FBQ1ksR0FBRyxJQUFJQSxHQUFHLENBQUNkLElBQUksS0FBS3pCLFVBQVUsRUFBRTtNQUNyQztNQUNBO01BQ0EsSUFBSSxDQUFDa0IsV0FBVyxDQUFDUyxPQUFPLENBQUNDLEdBQUcsQ0FBQzVCLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDbERvQixpQkFBaUIsQ0FBQ08sT0FBTyxHQUFHLElBQUk7UUFDaEM7TUFDRjtNQUNBLE1BQU1RLElBQUksR0FBR0Msd0JBQVcsQ0FBQ1QsT0FBTyxDQUFDLENBQUM7TUFDbEMsTUFBTW1DLEdBQUcsR0FBRyxFQUFFekMsVUFBVSxDQUFDTSxPQUFPO01BQ2hDLElBQUk7UUFDRixNQUFNb0MsSUFBSSxHQUFHLE1BQU01QixJQUFJLENBQUNzQixJQUFJLENBQUN6RCxVQUFVLENBQUM7UUFDeEM7UUFDQSxJQUFJNEQsT0FBTyxJQUFJRSxHQUFHLEtBQUt6QyxVQUFVLENBQUNNLE9BQU8sRUFBRTtRQUMzQztRQUNBO1FBQ0EsTUFBTXFDLEdBQUcsR0FBR2xELFNBQVMsQ0FBQ2EsT0FBTztRQUM3QixJQUFJLENBQUNxQyxHQUFHLElBQUlBLEdBQUcsQ0FBQ3ZDLElBQUksS0FBS3pCLFVBQVUsSUFBSStELElBQUksS0FBS0MsR0FBRyxDQUFDQyxRQUFRLEVBQUU7UUFDOUQsTUFBTUMsSUFBSSxHQUFHakQsWUFBWSxDQUFDVSxPQUFPO1FBQ2pDLElBQUl1QyxJQUFJLElBQUl4RSxRQUFRLENBQUN3RSxJQUFJLENBQUN6QyxJQUFJLEVBQUV6QixVQUFVLENBQUMsSUFBSStELElBQUksS0FBS0csSUFBSSxDQUFDaEMsSUFBSSxFQUFFO1VBQ2pFO1VBQ0E7VUFDQUgsU0FBUyxDQUFDLElBQUFvQyx5QkFBaUIsRUFBQ0gsR0FBRyxFQUFFRCxJQUFJLENBQUMsQ0FBQztVQUN2QztRQUNGO1FBQ0FoQyxTQUFTLENBQUMsSUFBQXFDLDJCQUFtQixFQUFDSixHQUFHLEVBQUVELElBQUksQ0FBQyxDQUFDO01BQzNDLENBQUMsQ0FBQyxNQUFNO1FBQ04sSUFBSUgsT0FBTyxJQUFJRSxHQUFHLEtBQUt6QyxVQUFVLENBQUNNLE9BQU8sRUFBRTtRQUMzQztRQUNBLE1BQU0wQyxJQUFJLEdBQUcsRUFBRSxNQUFNbEMsSUFBSSxDQUFDbUMsTUFBTSxDQUFDdEUsVUFBVSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDNEQsT0FBTyxJQUFJUyxJQUFJLElBQUl2RCxTQUFTLENBQUNhLE9BQU8sRUFBRUYsSUFBSSxLQUFLekIsVUFBVSxFQUFFO1VBQzlEK0IsU0FBUyxDQUFDLElBQUF3QywyQkFBbUIsRUFBQ3pELFNBQVMsQ0FBQ2EsT0FBTyxDQUFDLENBQUM7UUFDbkQ7TUFDRjtJQUNGLENBQUM7SUFDRDtJQUNBTCxTQUFTLENBQUNLLE9BQU8sR0FBRyxNQUFNLEtBQUtrQyxNQUFNLENBQUMsQ0FBQztJQUN2QyxNQUFNVyxXQUFXLEdBQUcsSUFBQUMsZUFBVSxFQUFFQyxNQUFNLElBQUs7TUFDekM7TUFDQTtNQUNBLElBQUlBLE1BQU0sQ0FBQ0MsS0FBSyxLQUFLLENBQUMsRUFBRTtNQUN4QixJQUFJRCxNQUFNLENBQUNFLEtBQUssQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtwRixRQUFRLENBQUNvRixDQUFDLEVBQUU5RSxVQUFVLENBQUMsQ0FBQyxFQUFFLEtBQUs2RCxNQUFNLENBQUMsQ0FBQztJQUN0RSxDQUFDLENBQUM7SUFDRixPQUFPLE1BQU07TUFDWEQsT0FBTyxHQUFHLElBQUk7TUFDZHRDLFNBQVMsQ0FBQ0ssT0FBTyxHQUFHLElBQUk7TUFDeEI7TUFDQTtNQUNBUCxpQkFBaUIsQ0FBQ08sT0FBTyxHQUFHLEtBQUs7TUFDakM2QyxXQUFXLENBQUMsQ0FBQztJQUNmLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ3hFLFVBQVUsRUFBRStCLFNBQVMsQ0FBQyxDQUFDOztFQUUzQjtFQUNBO0VBQ0EsSUFBQWdCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE1BQU1nQyxDQUFDLEdBQUcvRCxRQUFRLENBQUNXLE9BQU87SUFDMUIsT0FBTyxNQUFNb0QsQ0FBQyxFQUFFekIsS0FBSyxDQUFDLENBQUM7RUFDekIsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU0wQixPQUFPLEdBQUcsSUFBQXhELGtCQUFXLEVBQ3hCUSxJQUFZLElBQUs7SUFDaEIsTUFBTU8sR0FBRyxHQUFHekIsU0FBUyxDQUFDYSxPQUFPO0lBQzdCLElBQUksQ0FBQ1ksR0FBRyxFQUFFO0lBQ1YsTUFBTTBDLE9BQU8sR0FBRyxJQUFBQyxpQkFBUyxFQUFDM0MsR0FBRyxFQUFFUCxJQUFJLENBQUM7SUFDcENELFNBQVMsQ0FBQ2tELE9BQU8sQ0FBQztJQUNsQjtJQUNBO0lBQ0EsSUFBSSxJQUFBRSxlQUFTLEVBQUNGLE9BQU8sQ0FBQyxJQUFJOUUsUUFBUSxFQUFFYSxRQUFRLENBQUNXLE9BQU8sR0FBR3NELE9BQU8sQ0FBQ3hELElBQUksRUFBRXdELE9BQU8sQ0FBQzVFLE1BQU0sQ0FBQyxDQUFDLEtBQ2hGVyxRQUFRLENBQUNXLE9BQU8sRUFBRXlELE1BQU0sQ0FBQyxDQUFDO0VBQ2pDLENBQUMsRUFDRCxDQUFDckQsU0FBUyxFQUFFNUIsUUFBUSxDQUN0QixDQUFDO0VBRUQsTUFBTWtGLGVBQWUsR0FBRyxJQUFBN0Qsa0JBQVcsRUFBQyxNQUFNO0lBQ3hDLE1BQU1lLEdBQUcsR0FBR3pCLFNBQVMsQ0FBQ2EsT0FBTztJQUM3QixJQUFJLENBQUNZLEdBQUcsRUFBRTtJQUNWLE1BQU0wQyxPQUFPLEdBQUcsSUFBQUssdUJBQVEsRUFBQy9DLEdBQUcsQ0FBQztJQUM3QlIsU0FBUyxDQUFDa0QsT0FBTyxDQUFDO0lBQ2xCLElBQUksSUFBQUUsZUFBUyxFQUFDRixPQUFPLENBQUMsSUFBSTlFLFFBQVEsRUFBRWEsUUFBUSxDQUFDVyxPQUFPLEdBQUdzRCxPQUFPLENBQUN4RCxJQUFJLEVBQUV3RCxPQUFPLENBQUM1RSxNQUFNLENBQUM7RUFDdEYsQ0FBQyxFQUFFLENBQUMwQixTQUFTLEVBQUU1QixRQUFRLENBQUMsQ0FBQztFQUV6QixNQUFNb0YsaUJBQWlCLEdBQUcsSUFBQS9ELGtCQUFXLEVBQUMsTUFBTTtJQUMxQyxNQUFNZSxHQUFHLEdBQUd6QixTQUFTLENBQUNhLE9BQU87SUFDN0IsSUFBSSxDQUFDWSxHQUFHLEVBQUU7SUFDVlIsU0FBUyxDQUFDLElBQUF5RCx5QkFBVSxFQUFDakQsR0FBRyxDQUFDLENBQUM7RUFDNUIsQ0FBQyxFQUFFLENBQUNSLFNBQVMsQ0FBQyxDQUFDO0VBRWYsTUFBTXVCLEtBQUssR0FBRyxJQUFBOUIsa0JBQVcsRUFBQyxNQUFNUixRQUFRLENBQUNXLE9BQU8sRUFBRTJCLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRTlELE9BQU87SUFDTGpELE1BQU07SUFDTkcsU0FBUztJQUNURSxTQUFTO0lBQ1RQLFFBQVE7SUFDUlMsU0FBUztJQUNUb0UsT0FBTztJQUNQSyxlQUFlO0lBQ2ZFLGlCQUFpQjtJQUNqQmpDO0VBQ0YsQ0FBQztBQUNIIiwiaWdub3JlTGlzdCI6W119