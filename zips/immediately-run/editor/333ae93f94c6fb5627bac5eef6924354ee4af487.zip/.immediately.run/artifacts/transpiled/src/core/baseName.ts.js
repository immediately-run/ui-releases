"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.baseName = baseName;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
// The one home of "the file's display name" (implementation standards R6 — this
// used to be spelled per call site and the copies had already drifted). A
// trailing slash or an all-separator path falls back to the input itself, so
// the caller always has something to show.

/** The last non-empty path segment — `'/a/b/notes.txt'` → `'notes.txt'`. */
function baseName(p) {
  return p.split('/').filter(Boolean).pop() || p;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJiYXNlTmFtZSIsInAiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJwb3AiXSwic291cmNlcyI6WyJiYXNlTmFtZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgb25lIGhvbWUgb2YgXCJ0aGUgZmlsZSdzIGRpc3BsYXkgbmFtZVwiIChpbXBsZW1lbnRhdGlvbiBzdGFuZGFyZHMgUjYg4oCUIHRoaXNcbi8vIHVzZWQgdG8gYmUgc3BlbGxlZCBwZXIgY2FsbCBzaXRlIGFuZCB0aGUgY29waWVzIGhhZCBhbHJlYWR5IGRyaWZ0ZWQpLiBBXG4vLyB0cmFpbGluZyBzbGFzaCBvciBhbiBhbGwtc2VwYXJhdG9yIHBhdGggZmFsbHMgYmFjayB0byB0aGUgaW5wdXQgaXRzZWxmLCBzb1xuLy8gdGhlIGNhbGxlciBhbHdheXMgaGFzIHNvbWV0aGluZyB0byBzaG93LlxuXG4vKiogVGhlIGxhc3Qgbm9uLWVtcHR5IHBhdGggc2VnbWVudCDigJQgYCcvYS9iL25vdGVzLnR4dCdgIOKGkiBgJ25vdGVzLnR4dCdgLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJhc2VOYW1lKHA6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBwLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pLnBvcCgpIHx8IHA7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTyxTQUFTQSxRQUFRQSxDQUFDQyxDQUFTLEVBQVU7RUFDMUMsT0FBT0EsQ0FBQyxDQUFDQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDLElBQUlKLENBQUM7QUFDaEQiLCJpZ25vcmVMaXN0IjpbXX0=