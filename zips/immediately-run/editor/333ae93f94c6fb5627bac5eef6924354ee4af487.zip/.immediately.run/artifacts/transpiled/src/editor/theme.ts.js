"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.editorTheme = editorTheme;
var _view = require("@codemirror/view");
// CodeMirror theming driven by the host `theme` channel (plan Phase 04 step 7).
// The native editor inherits theme from the Sandpack provider; as a standalone
// app we must pull it ourselves (`useHostTheme`) and translate to a CodeMirror
// EditorView theme. Kept minimal — colours read from the app's CSS variables so
// the editor chrome and the CodeMirror surface stay in step.

const dark = _view.EditorView.theme({
  '&': {
    backgroundColor: 'transparent',
    color: 'var(--cm-fg)'
  },
  '.cm-content': {
    caretColor: 'var(--cm-caret)'
  },
  '.cm-gutters': {
    backgroundColor: 'transparent',
    color: 'var(--cm-gutter)',
    border: 'none'
  },
  '.cm-activeLine': {
    backgroundColor: 'var(--cm-active-line)'
  },
  '.cm-activeLineGutter': {
    backgroundColor: 'var(--cm-active-line)'
  },
  '&.cm-focused .cm-cursor': {
    borderLeftColor: 'var(--cm-caret)'
  },
  '.cm-selectionBackground, &.cm-focused .cm-selectionBackground': {
    backgroundColor: 'var(--cm-selection)'
  }
}, {
  dark: true
});
const light = _view.EditorView.theme({
  '&': {
    backgroundColor: 'transparent',
    color: 'var(--cm-fg)'
  },
  '.cm-content': {
    caretColor: 'var(--cm-caret)'
  },
  '.cm-gutters': {
    backgroundColor: 'transparent',
    color: 'var(--cm-gutter)',
    border: 'none'
  },
  '.cm-activeLine': {
    backgroundColor: 'var(--cm-active-line)'
  },
  '.cm-activeLineGutter': {
    backgroundColor: 'var(--cm-active-line)'
  },
  '&.cm-focused .cm-cursor': {
    borderLeftColor: 'var(--cm-caret)'
  },
  '.cm-selectionBackground, &.cm-focused .cm-selectionBackground': {
    backgroundColor: 'var(--cm-selection)'
  }
}, {
  dark: false
});
function editorTheme(theme) {
  return theme === 'light' ? light : dark;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdmlldyIsInJlcXVpcmUiLCJkYXJrIiwiRWRpdG9yVmlldyIsInRoZW1lIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJjYXJldENvbG9yIiwiYm9yZGVyIiwiYm9yZGVyTGVmdENvbG9yIiwibGlnaHQiLCJlZGl0b3JUaGVtZSJdLCJzb3VyY2VzIjpbInRoZW1lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvZGVNaXJyb3IgdGhlbWluZyBkcml2ZW4gYnkgdGhlIGhvc3QgYHRoZW1lYCBjaGFubmVsIChwbGFuIFBoYXNlIDA0IHN0ZXAgNykuXG4vLyBUaGUgbmF0aXZlIGVkaXRvciBpbmhlcml0cyB0aGVtZSBmcm9tIHRoZSBTYW5kcGFjayBwcm92aWRlcjsgYXMgYSBzdGFuZGFsb25lXG4vLyBhcHAgd2UgbXVzdCBwdWxsIGl0IG91cnNlbHZlcyAoYHVzZUhvc3RUaGVtZWApIGFuZCB0cmFuc2xhdGUgdG8gYSBDb2RlTWlycm9yXG4vLyBFZGl0b3JWaWV3IHRoZW1lLiBLZXB0IG1pbmltYWwg4oCUIGNvbG91cnMgcmVhZCBmcm9tIHRoZSBhcHAncyBDU1MgdmFyaWFibGVzIHNvXG4vLyB0aGUgZWRpdG9yIGNocm9tZSBhbmQgdGhlIENvZGVNaXJyb3Igc3VyZmFjZSBzdGF5IGluIHN0ZXAuXG5cbmltcG9ydCB7IEVkaXRvclZpZXcgfSBmcm9tICdAY29kZW1pcnJvci92aWV3JztcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uIH0gZnJvbSAnQGNvZGVtaXJyb3Ivc3RhdGUnO1xuaW1wb3J0IHR5cGUgeyBIb3N0VGhlbWUgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5cbmNvbnN0IGRhcmsgPSBFZGl0b3JWaWV3LnRoZW1lKFxuICB7XG4gICAgJyYnOiB7IGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JywgY29sb3I6ICd2YXIoLS1jbS1mZyknIH0sXG4gICAgJy5jbS1jb250ZW50JzogeyBjYXJldENvbG9yOiAndmFyKC0tY20tY2FyZXQpJyB9LFxuICAgICcuY20tZ3V0dGVycyc6IHsgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLCBjb2xvcjogJ3ZhcigtLWNtLWd1dHRlciknLCBib3JkZXI6ICdub25lJyB9LFxuICAgICcuY20tYWN0aXZlTGluZSc6IHsgYmFja2dyb3VuZENvbG9yOiAndmFyKC0tY20tYWN0aXZlLWxpbmUpJyB9LFxuICAgICcuY20tYWN0aXZlTGluZUd1dHRlcic6IHsgYmFja2dyb3VuZENvbG9yOiAndmFyKC0tY20tYWN0aXZlLWxpbmUpJyB9LFxuICAgICcmLmNtLWZvY3VzZWQgLmNtLWN1cnNvcic6IHsgYm9yZGVyTGVmdENvbG9yOiAndmFyKC0tY20tY2FyZXQpJyB9LFxuICAgICcuY20tc2VsZWN0aW9uQmFja2dyb3VuZCwgJi5jbS1mb2N1c2VkIC5jbS1zZWxlY3Rpb25CYWNrZ3JvdW5kJzoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiAndmFyKC0tY20tc2VsZWN0aW9uKScsXG4gICAgfSxcbiAgfSxcbiAgeyBkYXJrOiB0cnVlIH0sXG4pO1xuXG5jb25zdCBsaWdodCA9IEVkaXRvclZpZXcudGhlbWUoXG4gIHtcbiAgICAnJic6IHsgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLCBjb2xvcjogJ3ZhcigtLWNtLWZnKScgfSxcbiAgICAnLmNtLWNvbnRlbnQnOiB7IGNhcmV0Q29sb3I6ICd2YXIoLS1jbS1jYXJldCknIH0sXG4gICAgJy5jbS1ndXR0ZXJzJzogeyBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsIGNvbG9yOiAndmFyKC0tY20tZ3V0dGVyKScsIGJvcmRlcjogJ25vbmUnIH0sXG4gICAgJy5jbS1hY3RpdmVMaW5lJzogeyBiYWNrZ3JvdW5kQ29sb3I6ICd2YXIoLS1jbS1hY3RpdmUtbGluZSknIH0sXG4gICAgJy5jbS1hY3RpdmVMaW5lR3V0dGVyJzogeyBiYWNrZ3JvdW5kQ29sb3I6ICd2YXIoLS1jbS1hY3RpdmUtbGluZSknIH0sXG4gICAgJyYuY20tZm9jdXNlZCAuY20tY3Vyc29yJzogeyBib3JkZXJMZWZ0Q29sb3I6ICd2YXIoLS1jbS1jYXJldCknIH0sXG4gICAgJy5jbS1zZWxlY3Rpb25CYWNrZ3JvdW5kLCAmLmNtLWZvY3VzZWQgLmNtLXNlbGVjdGlvbkJhY2tncm91bmQnOiB7XG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd2YXIoLS1jbS1zZWxlY3Rpb24pJyxcbiAgICB9LFxuICB9LFxuICB7IGRhcms6IGZhbHNlIH0sXG4pO1xuXG5leHBvcnQgZnVuY3Rpb24gZWRpdG9yVGhlbWUodGhlbWU6IEhvc3RUaGVtZSk6IEV4dGVuc2lvbiB7XG4gIHJldHVybiB0aGVtZSA9PT0gJ2xpZ2h0JyA/IGxpZ2h0IDogZGFyaztcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsS0FBQSxHQUFBQyxPQUFBO0FBTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFNQSxNQUFNQyxJQUFJLEdBQUdDLGdCQUFVLENBQUNDLEtBQUssQ0FDM0I7RUFDRSxHQUFHLEVBQUU7SUFBRUMsZUFBZSxFQUFFLGFBQWE7SUFBRUMsS0FBSyxFQUFFO0VBQWUsQ0FBQztFQUM5RCxhQUFhLEVBQUU7SUFBRUMsVUFBVSxFQUFFO0VBQWtCLENBQUM7RUFDaEQsYUFBYSxFQUFFO0lBQUVGLGVBQWUsRUFBRSxhQUFhO0lBQUVDLEtBQUssRUFBRSxrQkFBa0I7SUFBRUUsTUFBTSxFQUFFO0VBQU8sQ0FBQztFQUM1RixnQkFBZ0IsRUFBRTtJQUFFSCxlQUFlLEVBQUU7RUFBd0IsQ0FBQztFQUM5RCxzQkFBc0IsRUFBRTtJQUFFQSxlQUFlLEVBQUU7RUFBd0IsQ0FBQztFQUNwRSx5QkFBeUIsRUFBRTtJQUFFSSxlQUFlLEVBQUU7RUFBa0IsQ0FBQztFQUNqRSwrREFBK0QsRUFBRTtJQUMvREosZUFBZSxFQUFFO0VBQ25CO0FBQ0YsQ0FBQyxFQUNEO0VBQUVILElBQUksRUFBRTtBQUFLLENBQ2YsQ0FBQztBQUVELE1BQU1RLEtBQUssR0FBR1AsZ0JBQVUsQ0FBQ0MsS0FBSyxDQUM1QjtFQUNFLEdBQUcsRUFBRTtJQUFFQyxlQUFlLEVBQUUsYUFBYTtJQUFFQyxLQUFLLEVBQUU7RUFBZSxDQUFDO0VBQzlELGFBQWEsRUFBRTtJQUFFQyxVQUFVLEVBQUU7RUFBa0IsQ0FBQztFQUNoRCxhQUFhLEVBQUU7SUFBRUYsZUFBZSxFQUFFLGFBQWE7SUFBRUMsS0FBSyxFQUFFLGtCQUFrQjtJQUFFRSxNQUFNLEVBQUU7RUFBTyxDQUFDO0VBQzVGLGdCQUFnQixFQUFFO0lBQUVILGVBQWUsRUFBRTtFQUF3QixDQUFDO0VBQzlELHNCQUFzQixFQUFFO0lBQUVBLGVBQWUsRUFBRTtFQUF3QixDQUFDO0VBQ3BFLHlCQUF5QixFQUFFO0lBQUVJLGVBQWUsRUFBRTtFQUFrQixDQUFDO0VBQ2pFLCtEQUErRCxFQUFFO0lBQy9ESixlQUFlLEVBQUU7RUFDbkI7QUFDRixDQUFDLEVBQ0Q7RUFBRUgsSUFBSSxFQUFFO0FBQU0sQ0FDaEIsQ0FBQztBQUVNLFNBQVNTLFdBQVdBLENBQUNQLEtBQWdCLEVBQWE7RUFDdkQsT0FBT0EsS0FBSyxLQUFLLE9BQU8sR0FBR00sS0FBSyxHQUFHUixJQUFJO0FBQ3pDIiwiaWdub3JlTGlzdCI6W119