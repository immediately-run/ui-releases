var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Placeholder = Placeholder;
exports.default = void 0;
var _lucideReact = require("lucide-react");
var _jsxRuntime = require("react/jsx-runtime");
// Non-editing render states: the §12.7 init race (awaiting the working-tree port
// / no active file), the §12.4 active-file-vanished case, and load/read errors.

const COPY = {
  'awaiting-port': {
    title: 'Connecting to the working tree…',
    hint: 'The editor is waiting for the file system to attach.',
    icon: _lucideReact.Loader2
  },
  'no-active-file': {
    title: 'No file open',
    hint: 'Open a file from the explorer to start editing.',
    icon: _lucideReact.FilePlus2
  },
  vanished: {
    title: 'This file was removed',
    hint: 'The file you were editing was deleted or renamed elsewhere. Your unsaved text is kept below — copy anything you need.',
    icon: _lucideReact.FileX2
  },
  error: {
    title: 'Could not open this file',
    hint: 'The working tree returned an error while reading it.',
    icon: _lucideReact.FileQuestion
  }
};
function Placeholder({
  kind,
  detail,
  title,
  hint
}) {
  const copy = COPY[kind];
  const Icon = copy.icon;
  const hintText = hint ?? copy.hint;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "placeholder",
    "data-kind": kind,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
      size: 28,
      className: kind === 'awaiting-port' ? 'spin' : undefined
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "placeholder-title",
      children: title ?? copy.title
    }), hintText && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "placeholder-hint",
      children: hintText
    }), detail && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "placeholder-detail",
      children: detail
    })]
  });
}
_c = Placeholder;
var _default = exports.default = Placeholder;
var _c;
$RefreshReg$(_c, "Placeholder");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbHVjaWRlUmVhY3QiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJDT1BZIiwidGl0bGUiLCJoaW50IiwiaWNvbiIsIkxvYWRlcjIiLCJGaWxlUGx1czIiLCJ2YW5pc2hlZCIsIkZpbGVYMiIsImVycm9yIiwiRmlsZVF1ZXN0aW9uIiwiUGxhY2Vob2xkZXIiLCJraW5kIiwiZGV0YWlsIiwiY29weSIsIkljb24iLCJoaW50VGV4dCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInNpemUiLCJ1bmRlZmluZWQiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQbGFjZWhvbGRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTm9uLWVkaXRpbmcgcmVuZGVyIHN0YXRlczogdGhlIMKnMTIuNyBpbml0IHJhY2UgKGF3YWl0aW5nIHRoZSB3b3JraW5nLXRyZWUgcG9ydFxuLy8gLyBubyBhY3RpdmUgZmlsZSksIHRoZSDCpzEyLjQgYWN0aXZlLWZpbGUtdmFuaXNoZWQgY2FzZSwgYW5kIGxvYWQvcmVhZCBlcnJvcnMuXG5cbmltcG9ydCB7IEZpbGVRdWVzdGlvbiwgRmlsZVBsdXMyLCBGaWxlWDIsIExvYWRlcjIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgdHlwZSBQbGFjZWhvbGRlcktpbmQgPSAnYXdhaXRpbmctcG9ydCcgfCAnbm8tYWN0aXZlLWZpbGUnIHwgJ3ZhbmlzaGVkJyB8ICdlcnJvcic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGxhY2Vob2xkZXJQcm9wcyB7XG4gIGtpbmQ6IFBsYWNlaG9sZGVyS2luZDtcbiAgZGV0YWlsPzogc3RyaW5nO1xuICAvKiogT3ZlcnJpZGUgdGhlIGtpbmQncyBjb3B5IHdoZW4gdGhlIHNhbWUgQU5BVE9NWSBzZXJ2ZXMgYSBuZWlnaGJvdXJpbmcgc3RhdGVcbiAgICogIChSMy04MDQncyBpbWFnZSBsb2FkaW5nL3ZhbmlzaGVkIHN0YXRlcykg4oCUIG5ldmVyIGZvcmsgdGhlIG1hcmt1cC4gQW4gZW1wdHlcbiAgICogIGhpbnQgc3VwcHJlc3NlcyB0aGUgaGludCBsaW5lLiAqL1xuICB0aXRsZT86IHN0cmluZztcbiAgaGludD86IHN0cmluZztcbn1cblxuY29uc3QgQ09QWTogUmVjb3JkPFBsYWNlaG9sZGVyS2luZCwgeyB0aXRsZTogc3RyaW5nOyBoaW50OiBzdHJpbmc7IGljb246IHR5cGVvZiBGaWxlUXVlc3Rpb24gfT4gPSB7XG4gICdhd2FpdGluZy1wb3J0Jzoge1xuICAgIHRpdGxlOiAnQ29ubmVjdGluZyB0byB0aGUgd29ya2luZyB0cmVl4oCmJyxcbiAgICBoaW50OiAnVGhlIGVkaXRvciBpcyB3YWl0aW5nIGZvciB0aGUgZmlsZSBzeXN0ZW0gdG8gYXR0YWNoLicsXG4gICAgaWNvbjogTG9hZGVyMixcbiAgfSxcbiAgJ25vLWFjdGl2ZS1maWxlJzoge1xuICAgIHRpdGxlOiAnTm8gZmlsZSBvcGVuJyxcbiAgICBoaW50OiAnT3BlbiBhIGZpbGUgZnJvbSB0aGUgZXhwbG9yZXIgdG8gc3RhcnQgZWRpdGluZy4nLFxuICAgIGljb246IEZpbGVQbHVzMixcbiAgfSxcbiAgdmFuaXNoZWQ6IHtcbiAgICB0aXRsZTogJ1RoaXMgZmlsZSB3YXMgcmVtb3ZlZCcsXG4gICAgaGludDogJ1RoZSBmaWxlIHlvdSB3ZXJlIGVkaXRpbmcgd2FzIGRlbGV0ZWQgb3IgcmVuYW1lZCBlbHNld2hlcmUuIFlvdXIgdW5zYXZlZCB0ZXh0IGlzIGtlcHQgYmVsb3cg4oCUIGNvcHkgYW55dGhpbmcgeW91IG5lZWQuJyxcbiAgICBpY29uOiBGaWxlWDIsXG4gIH0sXG4gIGVycm9yOiB7XG4gICAgdGl0bGU6ICdDb3VsZCBub3Qgb3BlbiB0aGlzIGZpbGUnLFxuICAgIGhpbnQ6ICdUaGUgd29ya2luZyB0cmVlIHJldHVybmVkIGFuIGVycm9yIHdoaWxlIHJlYWRpbmcgaXQuJyxcbiAgICBpY29uOiBGaWxlUXVlc3Rpb24sXG4gIH0sXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gUGxhY2Vob2xkZXIoeyBraW5kLCBkZXRhaWwsIHRpdGxlLCBoaW50IH06IFBsYWNlaG9sZGVyUHJvcHMpIHtcbiAgY29uc3QgY29weSA9IENPUFlba2luZF07XG4gIGNvbnN0IEljb24gPSBjb3B5Lmljb247XG4gIGNvbnN0IGhpbnRUZXh0ID0gaGludCA/PyBjb3B5LmhpbnQ7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZWhvbGRlclwiIGRhdGEta2luZD17a2luZH0+XG4gICAgICA8SWNvbiBzaXplPXsyOH0gY2xhc3NOYW1lPXtraW5kID09PSAnYXdhaXRpbmctcG9ydCcgPyAnc3BpbicgOiB1bmRlZmluZWR9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYWNlaG9sZGVyLXRpdGxlXCI+e3RpdGxlID8/IGNvcHkudGl0bGV9PC9kaXY+XG4gICAgICB7aGludFRleHQgJiYgPGRpdiBjbGFzc05hbWU9XCJwbGFjZWhvbGRlci1oaW50XCI+e2hpbnRUZXh0fTwvZGl2Pn1cbiAgICAgIHtkZXRhaWwgJiYgPGRpdiBjbGFzc05hbWU9XCJwbGFjZWhvbGRlci1kZXRhaWxcIj57ZGV0YWlsfTwvZGl2Pn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGxhY2Vob2xkZXI7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFHQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0UsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBSHhFO0FBQ0E7O0FBZ0JBLE1BQU1FLElBQXlGLEdBQUc7RUFDaEcsZUFBZSxFQUFFO0lBQ2ZDLEtBQUssRUFBRSxpQ0FBaUM7SUFDeENDLElBQUksRUFBRSxzREFBc0Q7SUFDNURDLElBQUksRUFBRUM7RUFDUixDQUFDO0VBQ0QsZ0JBQWdCLEVBQUU7SUFDaEJILEtBQUssRUFBRSxjQUFjO0lBQ3JCQyxJQUFJLEVBQUUsaURBQWlEO0lBQ3ZEQyxJQUFJLEVBQUVFO0VBQ1IsQ0FBQztFQUNEQyxRQUFRLEVBQUU7SUFDUkwsS0FBSyxFQUFFLHVCQUF1QjtJQUM5QkMsSUFBSSxFQUFFLHVIQUF1SDtJQUM3SEMsSUFBSSxFQUFFSTtFQUNSLENBQUM7RUFDREMsS0FBSyxFQUFFO0lBQ0xQLEtBQUssRUFBRSwwQkFBMEI7SUFDakNDLElBQUksRUFBRSxzREFBc0Q7SUFDNURDLElBQUksRUFBRU07RUFDUjtBQUNGLENBQUM7QUFFTSxTQUFTQyxXQUFXQSxDQUFDO0VBQUVDLElBQUk7RUFBRUMsTUFBTTtFQUFFWCxLQUFLO0VBQUVDO0FBQXVCLENBQUMsRUFBRTtFQUMzRSxNQUFNVyxJQUFJLEdBQUdiLElBQUksQ0FBQ1csSUFBSSxDQUFDO0VBQ3ZCLE1BQU1HLElBQUksR0FBR0QsSUFBSSxDQUFDVixJQUFJO0VBQ3RCLE1BQU1ZLFFBQVEsR0FBR2IsSUFBSSxJQUFJVyxJQUFJLENBQUNYLElBQUk7RUFDbEMsb0JBQ0UsSUFBQUgsV0FBQSxDQUFBaUIsSUFBQTtJQUFLQyxTQUFTLEVBQUMsYUFBYTtJQUFDLGFBQVdOLElBQUs7SUFBQU8sUUFBQSxnQkFDM0MsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ0wsSUFBSTtNQUFDTSxJQUFJLEVBQUUsRUFBRztNQUFDSCxTQUFTLEVBQUVOLElBQUksS0FBSyxlQUFlLEdBQUcsTUFBTSxHQUFHVTtJQUFVLENBQUUsQ0FBQyxlQUM1RSxJQUFBdEIsV0FBQSxDQUFBb0IsR0FBQTtNQUFLRixTQUFTLEVBQUMsbUJBQW1CO01BQUFDLFFBQUEsRUFBRWpCLEtBQUssSUFBSVksSUFBSSxDQUFDWjtJQUFLLENBQU0sQ0FBQyxFQUM3RGMsUUFBUSxpQkFBSSxJQUFBaEIsV0FBQSxDQUFBb0IsR0FBQTtNQUFLRixTQUFTLEVBQUMsa0JBQWtCO01BQUFDLFFBQUEsRUFBRUg7SUFBUSxDQUFNLENBQUMsRUFDOURILE1BQU0saUJBQUksSUFBQWIsV0FBQSxDQUFBb0IsR0FBQTtNQUFLRixTQUFTLEVBQUMsb0JBQW9CO01BQUFDLFFBQUEsRUFBRU47SUFBTSxDQUFNLENBQUM7RUFBQSxDQUMxRCxDQUFDO0FBRVY7QUFBQ1UsRUFBQSxHQVplWixXQUFXO0FBQUEsSUFBQWEsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FjWmYsV0FBVztBQUFBLElBQUFZLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}