"use strict";

var _vitest = require("vitest");
var _imageFile = require("./imageFile");
// The extension→MIME map behind the image overlay (R3-804). The map itself is
// the producer here, so literal inputs are the correct fixture (standards R2).

(0, _vitest.describe)('imageMimeForPath', () => {
  _vitest.it.each([['/assets/logo.png', 'image/png'], ['/assets/photo.jpg', 'image/jpeg'], ['/assets/photo.jpeg', 'image/jpeg'], ['/assets/anim.gif', 'image/gif'], ['/assets/pic.webp', 'image/webp'], ['/assets/pic.avif', 'image/avif'], ['/assets/pic.bmp', 'image/bmp'], ['/favicon.ico', 'image/vnd.microsoft.icon']])('maps %s to %s', (path, mime) => {
    (0, _vitest.expect)((0, _imageFile.imageMimeForPath)(path)).toBe(mime);
  });
  (0, _vitest.it)('matches case-insensitively', () => {
    (0, _vitest.expect)((0, _imageFile.imageMimeForPath)('/assets/LOGO.PNG')).toBe('image/png');
    (0, _vitest.expect)((0, _imageFile.imageMimeForPath)('/assets/Photo.JpG')).toBe('image/jpeg');
  });
  _vitest.it.each(['/src/App.tsx', '/assets/icon.svg',
  // source a user edits — the R3-339 decision
  '/assets/archive.zip', '/README', '/.png',
  // a dotfile has no extension
  '/dir.png/file',
  // the extension belongs to a directory segment
  '/x.png.exe' // the LAST extension decides
  ])('returns null for %s', path => {
    (0, _vitest.expect)((0, _imageFile.imageMimeForPath)(path)).toBeNull();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9pbWFnZUZpbGUiLCJkZXNjcmliZSIsIml0IiwiZWFjaCIsInBhdGgiLCJtaW1lIiwiZXhwZWN0IiwiaW1hZ2VNaW1lRm9yUGF0aCIsInRvQmUiLCJ0b0JlTnVsbCJdLCJzb3VyY2VzIjpbImltYWdlRmlsZS50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBleHRlbnNpb27ihpJNSU1FIG1hcCBiZWhpbmQgdGhlIGltYWdlIG92ZXJsYXkgKFIzLTgwNCkuIFRoZSBtYXAgaXRzZWxmIGlzXG4vLyB0aGUgcHJvZHVjZXIgaGVyZSwgc28gbGl0ZXJhbCBpbnB1dHMgYXJlIHRoZSBjb3JyZWN0IGZpeHR1cmUgKHN0YW5kYXJkcyBSMikuXG5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0IH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGltYWdlTWltZUZvclBhdGggfSBmcm9tICcuL2ltYWdlRmlsZSc7XG5cbmRlc2NyaWJlKCdpbWFnZU1pbWVGb3JQYXRoJywgKCkgPT4ge1xuICBpdC5lYWNoKFtcbiAgICBbJy9hc3NldHMvbG9nby5wbmcnLCAnaW1hZ2UvcG5nJ10sXG4gICAgWycvYXNzZXRzL3Bob3RvLmpwZycsICdpbWFnZS9qcGVnJ10sXG4gICAgWycvYXNzZXRzL3Bob3RvLmpwZWcnLCAnaW1hZ2UvanBlZyddLFxuICAgIFsnL2Fzc2V0cy9hbmltLmdpZicsICdpbWFnZS9naWYnXSxcbiAgICBbJy9hc3NldHMvcGljLndlYnAnLCAnaW1hZ2Uvd2VicCddLFxuICAgIFsnL2Fzc2V0cy9waWMuYXZpZicsICdpbWFnZS9hdmlmJ10sXG4gICAgWycvYXNzZXRzL3BpYy5ibXAnLCAnaW1hZ2UvYm1wJ10sXG4gICAgWycvZmF2aWNvbi5pY28nLCAnaW1hZ2Uvdm5kLm1pY3Jvc29mdC5pY29uJ10sXG4gIF0pKCdtYXBzICVzIHRvICVzJywgKHBhdGgsIG1pbWUpID0+IHtcbiAgICBleHBlY3QoaW1hZ2VNaW1lRm9yUGF0aChwYXRoKSkudG9CZShtaW1lKTtcbiAgfSk7XG5cbiAgaXQoJ21hdGNoZXMgY2FzZS1pbnNlbnNpdGl2ZWx5JywgKCkgPT4ge1xuICAgIGV4cGVjdChpbWFnZU1pbWVGb3JQYXRoKCcvYXNzZXRzL0xPR08uUE5HJykpLnRvQmUoJ2ltYWdlL3BuZycpO1xuICAgIGV4cGVjdChpbWFnZU1pbWVGb3JQYXRoKCcvYXNzZXRzL1Bob3RvLkpwRycpKS50b0JlKCdpbWFnZS9qcGVnJyk7XG4gIH0pO1xuXG4gIGl0LmVhY2goW1xuICAgICcvc3JjL0FwcC50c3gnLFxuICAgICcvYXNzZXRzL2ljb24uc3ZnJywgLy8gc291cmNlIGEgdXNlciBlZGl0cyDigJQgdGhlIFIzLTMzOSBkZWNpc2lvblxuICAgICcvYXNzZXRzL2FyY2hpdmUuemlwJyxcbiAgICAnL1JFQURNRScsXG4gICAgJy8ucG5nJywgLy8gYSBkb3RmaWxlIGhhcyBubyBleHRlbnNpb25cbiAgICAnL2Rpci5wbmcvZmlsZScsIC8vIHRoZSBleHRlbnNpb24gYmVsb25ncyB0byBhIGRpcmVjdG9yeSBzZWdtZW50XG4gICAgJy94LnBuZy5leGUnLCAvLyB0aGUgTEFTVCBleHRlbnNpb24gZGVjaWRlc1xuICBdKSgncmV0dXJucyBudWxsIGZvciAlcycsIChwYXRoKSA9PiB7XG4gICAgZXhwZWN0KGltYWdlTWltZUZvclBhdGgocGF0aCkpLnRvQmVOdWxsKCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBR0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsVUFBQSxHQUFBRCxPQUFBO0FBSkE7QUFDQTs7QUFLQSxJQUFBRSxnQkFBUSxFQUFDLGtCQUFrQixFQUFFLE1BQU07RUFDakNDLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLENBQ04sQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsRUFDakMsQ0FBQyxtQkFBbUIsRUFBRSxZQUFZLENBQUMsRUFDbkMsQ0FBQyxvQkFBb0IsRUFBRSxZQUFZLENBQUMsRUFDcEMsQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsRUFDakMsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUMsRUFDbEMsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUMsRUFDbEMsQ0FBQyxpQkFBaUIsRUFBRSxXQUFXLENBQUMsRUFDaEMsQ0FBQyxjQUFjLEVBQUUsMEJBQTBCLENBQUMsQ0FDN0MsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDQyxJQUFJLEVBQUVDLElBQUksS0FBSztJQUNsQyxJQUFBQyxjQUFNLEVBQUMsSUFBQUMsMkJBQWdCLEVBQUNILElBQUksQ0FBQyxDQUFDLENBQUNJLElBQUksQ0FBQ0gsSUFBSSxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyw0QkFBNEIsRUFBRSxNQUFNO0lBQ3JDLElBQUFJLGNBQU0sRUFBQyxJQUFBQywyQkFBZ0IsRUFBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDOUQsSUFBQUYsY0FBTSxFQUFDLElBQUFDLDJCQUFnQixFQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFlBQVksQ0FBQztFQUNsRSxDQUFDLENBQUM7RUFFRk4sVUFBRSxDQUFDQyxJQUFJLENBQUMsQ0FDTixjQUFjLEVBQ2Qsa0JBQWtCO0VBQUU7RUFDcEIscUJBQXFCLEVBQ3JCLFNBQVMsRUFDVCxPQUFPO0VBQUU7RUFDVCxlQUFlO0VBQUU7RUFDakIsWUFBWSxDQUFFO0VBQUEsQ0FDZixDQUFDLENBQUMscUJBQXFCLEVBQUdDLElBQUksSUFBSztJQUNsQyxJQUFBRSxjQUFNLEVBQUMsSUFBQUMsMkJBQWdCLEVBQUNILElBQUksQ0FBQyxDQUFDLENBQUNLLFFBQVEsQ0FBQyxDQUFDO0VBQzNDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==