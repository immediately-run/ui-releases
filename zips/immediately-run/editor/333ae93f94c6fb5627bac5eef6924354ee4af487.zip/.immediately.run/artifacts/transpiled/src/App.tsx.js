var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
var _sdk = require("@immediately-run/sdk");
var _useFileBuffer = require("./hooks/useFileBuffer");
var _useImagePreview = require("./hooks/useImagePreview");
var _useBuildErrors = require("./hooks/useBuildErrors");
var _useCaretRequest = require("./hooks/useCaretRequest");
var _readiness = require("./core/readiness");
var _CodeMirrorView = require("./editor/CodeMirrorView");
var _ConflictBar = require("./chrome/ConflictBar");
var _ImageOverlay = require("./chrome/ImageOverlay");
var _Placeholder = require("./chrome/Placeholder");
var _rewrittenPaths = require("./core/rewrittenPaths");
require("./index.css");
require("./App.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The editor app — raw CodeMirror over SDK channels, no same-origin assumptions
// (EDITOR_AS_APP_SPEC, plan Phase 04). It reads the editor session (active file)
// and host theme/form-factor from channels and edits the file through the rw
// working-tree port. No tab strip is rendered — the host owns file switching.
// Behind the kernel kill-switch it is not yet bound to `panel.editor` (Phase 05);
// this is parity-in-isolation.
function App() {
  _s();
  const {
    activeFile
  } = (0, _sdk.useEditorContext)();
  const theme = (0, _sdk.useHostTheme)();
  const formFactor = (0, _sdk.useFormFactor)();
  const buildErrors = (0, _useBuildErrors.useBuildErrors)();
  // R3-388 — a host request to land the caret on a line (a problems-list click).
  const caret = (0, _useCaretRequest.useCaretRequest)();
  const {
    buffer,
    loadError,
    saveError,
    writable,
    portReady,
    setText,
    resolveKeepMine,
    resolveTakeTheirs
  } = (0, _useFileBuffer.useFileBuffer)(activeFile);
  const phase = (0, _readiness.resolvePhase)({
    portReady,
    activeFile
  });

  // R3-804 — a recognised image takes the pane as an overlay over the LIVE
  // CodeMirror view: useFileBuffer keeps the previous text buffer (its bytes
  // never enter the text path), CodeMirrorView stays mounted underneath, and
  // the text→image→text round trip costs no editor teardown.
  const image = (0, _useImagePreview.useImagePreview)(activeFile, portReady);
  // The path check matters on the switch frame: the hook's state flips in a
  // passive effect, so without it the just-left image could paint over the
  // newly selected file for one frame.
  const imageActive = phase === "ready" && image.state !== "idle" && image.path === activeFile;

  // A file Sandpack rewrites on every mount (e.g. package.json) is read-only — a
  // user edit would be accepted then silently discarded (native CP-3 parity). So
  // is a non-writable mount (an `ro` view / anonymous viewer).
  const readOnly = !writable || activeFile != null && (0, _rewrittenPaths.isRewrittenPath)(activeFile);
  const conflict = buffer?.conflict ?? null;
  const errors = activeFile ? buildErrors : [];
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "editor-app",
    "data-theme": theme,
    "data-form-factor": formFactor.class,
    "data-orientation": formFactor.orientation,
    children: [!imageActive && conflict && buffer && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ConflictBar.ConflictBar, {
      path: buffer.path,
      mine: buffer.buffer,
      theirs: conflict.theirs,
      onKeepMine: resolveKeepMine,
      onTakeTheirs: resolveTakeTheirs
    }), !imageActive && readOnly && phase === "ready" && !buffer?.vanished && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ed-readonly-note",
      role: "note",
      children: writable ? "Read-only — this file is regenerated on each run." : "Read-only."
    }), !imageActive && saveError && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ed-save-error",
      role: "alert",
      children: ["Save failed: ", saveError]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ed-body",
      children: [phase === "awaiting-port" && /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "awaiting-port"
      }), phase === "no-active-file" && /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "no-active-file"
      }), !imageActive && phase === "ready" && buffer?.vanished && /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "vanished",
        detail: buffer.path
      }), !imageActive && phase === "ready" && !buffer && loadError && /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "error",
        detail: loadError
      }), phase === "ready" && buffer && !buffer.vanished &&
      /*#__PURE__*/
      // While an image covers the pane the editor underneath is hidden
      // from pointer, keyboard and the accessibility tree (WCAG 2.1.1 /
      // 2.4.3) — and stays MOUNTED, so switching back is a reconfigure,
      // not a rebuild.
      (0, _jsxRuntime.jsx)("div", {
        className: "ed-cm-wrap",
        inert: imageActive,
        "aria-hidden": imageActive,
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_CodeMirrorView.CodeMirrorView, {
          path: buffer.path,
          doc: buffer.buffer,
          readOnly: readOnly,
          theme: theme,
          errors: errors,
          selection: caret,
          onChange: setText
        })
      }), imageActive && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ImageOverlay.ImageOverlay, {
        preview: image
      })]
    })]
  });
}
_s(App, "xJqeGZFbqc8e8ObsctRp4CjXC/A=", false, function () {
  return [_sdk.useEditorContext, _sdk.useHostTheme, _sdk.useFormFactor, _useBuildErrors.useBuildErrors, _useCaretRequest.useCaretRequest, _useFileBuffer.useFileBuffer, _useImagePreview.useImagePreview];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl91c2VGaWxlQnVmZmVyIiwiX3VzZUltYWdlUHJldmlldyIsIl91c2VCdWlsZEVycm9ycyIsIl91c2VDYXJldFJlcXVlc3QiLCJfcmVhZGluZXNzIiwiX0NvZGVNaXJyb3JWaWV3IiwiX0NvbmZsaWN0QmFyIiwiX0ltYWdlT3ZlcmxheSIsIl9QbGFjZWhvbGRlciIsIl9yZXdyaXR0ZW5QYXRocyIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJBcHAiLCJhY3RpdmVGaWxlIiwidXNlRWRpdG9yQ29udGV4dCIsInRoZW1lIiwidXNlSG9zdFRoZW1lIiwiZm9ybUZhY3RvciIsInVzZUZvcm1GYWN0b3IiLCJidWlsZEVycm9ycyIsInVzZUJ1aWxkRXJyb3JzIiwiY2FyZXQiLCJ1c2VDYXJldFJlcXVlc3QiLCJidWZmZXIiLCJsb2FkRXJyb3IiLCJzYXZlRXJyb3IiLCJ3cml0YWJsZSIsInBvcnRSZWFkeSIsInNldFRleHQiLCJyZXNvbHZlS2VlcE1pbmUiLCJyZXNvbHZlVGFrZVRoZWlycyIsInVzZUZpbGVCdWZmZXIiLCJwaGFzZSIsInJlc29sdmVQaGFzZSIsImltYWdlIiwidXNlSW1hZ2VQcmV2aWV3IiwiaW1hZ2VBY3RpdmUiLCJzdGF0ZSIsInBhdGgiLCJyZWFkT25seSIsImlzUmV3cml0dGVuUGF0aCIsImNvbmZsaWN0IiwiZXJyb3JzIiwianN4cyIsImNsYXNzTmFtZSIsImNsYXNzIiwib3JpZW50YXRpb24iLCJjaGlsZHJlbiIsImpzeCIsIkNvbmZsaWN0QmFyIiwibWluZSIsInRoZWlycyIsIm9uS2VlcE1pbmUiLCJvblRha2VUaGVpcnMiLCJ2YW5pc2hlZCIsInJvbGUiLCJQbGFjZWhvbGRlciIsImtpbmQiLCJkZXRhaWwiLCJpbmVydCIsIkNvZGVNaXJyb3JWaWV3IiwiZG9jIiwic2VsZWN0aW9uIiwib25DaGFuZ2UiLCJJbWFnZU92ZXJsYXkiLCJwcmV2aWV3IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlZGl0b3IgYXBwIOKAlCByYXcgQ29kZU1pcnJvciBvdmVyIFNESyBjaGFubmVscywgbm8gc2FtZS1vcmlnaW4gYXNzdW1wdGlvbnNcbi8vIChFRElUT1JfQVNfQVBQX1NQRUMsIHBsYW4gUGhhc2UgMDQpLiBJdCByZWFkcyB0aGUgZWRpdG9yIHNlc3Npb24gKGFjdGl2ZSBmaWxlKVxuLy8gYW5kIGhvc3QgdGhlbWUvZm9ybS1mYWN0b3IgZnJvbSBjaGFubmVscyBhbmQgZWRpdHMgdGhlIGZpbGUgdGhyb3VnaCB0aGUgcndcbi8vIHdvcmtpbmctdHJlZSBwb3J0LiBObyB0YWIgc3RyaXAgaXMgcmVuZGVyZWQg4oCUIHRoZSBob3N0IG93bnMgZmlsZSBzd2l0Y2hpbmcuXG4vLyBCZWhpbmQgdGhlIGtlcm5lbCBraWxsLXN3aXRjaCBpdCBpcyBub3QgeWV0IGJvdW5kIHRvIGBwYW5lbC5lZGl0b3JgIChQaGFzZSAwNSk7XG4vLyB0aGlzIGlzIHBhcml0eS1pbi1pc29sYXRpb24uXG5cbmltcG9ydCB7XG4gIHVzZUVkaXRvckNvbnRleHQsXG4gIHVzZUhvc3RUaGVtZSxcbiAgdXNlRm9ybUZhY3Rvcixcbn0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyB1c2VGaWxlQnVmZmVyIH0gZnJvbSBcIi4vaG9va3MvdXNlRmlsZUJ1ZmZlclwiO1xuaW1wb3J0IHsgdXNlSW1hZ2VQcmV2aWV3IH0gZnJvbSBcIi4vaG9va3MvdXNlSW1hZ2VQcmV2aWV3XCI7XG5pbXBvcnQgeyB1c2VCdWlsZEVycm9ycyB9IGZyb20gXCIuL2hvb2tzL3VzZUJ1aWxkRXJyb3JzXCI7XG5pbXBvcnQgeyB1c2VDYXJldFJlcXVlc3QgfSBmcm9tIFwiLi9ob29rcy91c2VDYXJldFJlcXVlc3RcIjtcbmltcG9ydCB7IHJlc29sdmVQaGFzZSB9IGZyb20gXCIuL2NvcmUvcmVhZGluZXNzXCI7XG5pbXBvcnQgeyBDb2RlTWlycm9yVmlldyB9IGZyb20gXCIuL2VkaXRvci9Db2RlTWlycm9yVmlld1wiO1xuaW1wb3J0IHsgQ29uZmxpY3RCYXIgfSBmcm9tIFwiLi9jaHJvbWUvQ29uZmxpY3RCYXJcIjtcbmltcG9ydCB7IEltYWdlT3ZlcmxheSB9IGZyb20gXCIuL2Nocm9tZS9JbWFnZU92ZXJsYXlcIjtcbmltcG9ydCB7IFBsYWNlaG9sZGVyIH0gZnJvbSBcIi4vY2hyb21lL1BsYWNlaG9sZGVyXCI7XG5pbXBvcnQgeyBpc1Jld3JpdHRlblBhdGggfSBmcm9tIFwiLi9jb3JlL3Jld3JpdHRlblBhdGhzXCI7XG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgeyBhY3RpdmVGaWxlIH0gPSB1c2VFZGl0b3JDb250ZXh0KCk7XG4gIGNvbnN0IHRoZW1lID0gdXNlSG9zdFRoZW1lKCk7XG4gIGNvbnN0IGZvcm1GYWN0b3IgPSB1c2VGb3JtRmFjdG9yKCk7XG4gIGNvbnN0IGJ1aWxkRXJyb3JzID0gdXNlQnVpbGRFcnJvcnMoKTtcbiAgLy8gUjMtMzg4IOKAlCBhIGhvc3QgcmVxdWVzdCB0byBsYW5kIHRoZSBjYXJldCBvbiBhIGxpbmUgKGEgcHJvYmxlbXMtbGlzdCBjbGljaykuXG4gIGNvbnN0IGNhcmV0ID0gdXNlQ2FyZXRSZXF1ZXN0KCk7XG5cbiAgY29uc3Qge1xuICAgIGJ1ZmZlcixcbiAgICBsb2FkRXJyb3IsXG4gICAgc2F2ZUVycm9yLFxuICAgIHdyaXRhYmxlLFxuICAgIHBvcnRSZWFkeSxcbiAgICBzZXRUZXh0LFxuICAgIHJlc29sdmVLZWVwTWluZSxcbiAgICByZXNvbHZlVGFrZVRoZWlycyxcbiAgfSA9IHVzZUZpbGVCdWZmZXIoYWN0aXZlRmlsZSk7XG5cbiAgY29uc3QgcGhhc2UgPSByZXNvbHZlUGhhc2UoeyBwb3J0UmVhZHksIGFjdGl2ZUZpbGUgfSk7XG5cbiAgLy8gUjMtODA0IOKAlCBhIHJlY29nbmlzZWQgaW1hZ2UgdGFrZXMgdGhlIHBhbmUgYXMgYW4gb3ZlcmxheSBvdmVyIHRoZSBMSVZFXG4gIC8vIENvZGVNaXJyb3IgdmlldzogdXNlRmlsZUJ1ZmZlciBrZWVwcyB0aGUgcHJldmlvdXMgdGV4dCBidWZmZXIgKGl0cyBieXRlc1xuICAvLyBuZXZlciBlbnRlciB0aGUgdGV4dCBwYXRoKSwgQ29kZU1pcnJvclZpZXcgc3RheXMgbW91bnRlZCB1bmRlcm5lYXRoLCBhbmRcbiAgLy8gdGhlIHRleHTihpJpbWFnZeKGknRleHQgcm91bmQgdHJpcCBjb3N0cyBubyBlZGl0b3IgdGVhcmRvd24uXG4gIGNvbnN0IGltYWdlID0gdXNlSW1hZ2VQcmV2aWV3KGFjdGl2ZUZpbGUsIHBvcnRSZWFkeSk7XG4gIC8vIFRoZSBwYXRoIGNoZWNrIG1hdHRlcnMgb24gdGhlIHN3aXRjaCBmcmFtZTogdGhlIGhvb2sncyBzdGF0ZSBmbGlwcyBpbiBhXG4gIC8vIHBhc3NpdmUgZWZmZWN0LCBzbyB3aXRob3V0IGl0IHRoZSBqdXN0LWxlZnQgaW1hZ2UgY291bGQgcGFpbnQgb3ZlciB0aGVcbiAgLy8gbmV3bHkgc2VsZWN0ZWQgZmlsZSBmb3Igb25lIGZyYW1lLlxuICBjb25zdCBpbWFnZUFjdGl2ZSA9XG4gICAgcGhhc2UgPT09IFwicmVhZHlcIiAmJiBpbWFnZS5zdGF0ZSAhPT0gXCJpZGxlXCIgJiYgaW1hZ2UucGF0aCA9PT0gYWN0aXZlRmlsZTtcblxuICAvLyBBIGZpbGUgU2FuZHBhY2sgcmV3cml0ZXMgb24gZXZlcnkgbW91bnQgKGUuZy4gcGFja2FnZS5qc29uKSBpcyByZWFkLW9ubHkg4oCUIGFcbiAgLy8gdXNlciBlZGl0IHdvdWxkIGJlIGFjY2VwdGVkIHRoZW4gc2lsZW50bHkgZGlzY2FyZGVkIChuYXRpdmUgQ1AtMyBwYXJpdHkpLiBTb1xuICAvLyBpcyBhIG5vbi13cml0YWJsZSBtb3VudCAoYW4gYHJvYCB2aWV3IC8gYW5vbnltb3VzIHZpZXdlcikuXG4gIGNvbnN0IHJlYWRPbmx5ID1cbiAgICAhd3JpdGFibGUgfHwgKGFjdGl2ZUZpbGUgIT0gbnVsbCAmJiBpc1Jld3JpdHRlblBhdGgoYWN0aXZlRmlsZSkpO1xuXG4gIGNvbnN0IGNvbmZsaWN0ID0gYnVmZmVyPy5jb25mbGljdCA/PyBudWxsO1xuICBjb25zdCBlcnJvcnMgPSBhY3RpdmVGaWxlID8gYnVpbGRFcnJvcnMgOiBbXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImVkaXRvci1hcHBcIlxuICAgICAgZGF0YS10aGVtZT17dGhlbWV9XG4gICAgICBkYXRhLWZvcm0tZmFjdG9yPXtmb3JtRmFjdG9yLmNsYXNzfVxuICAgICAgZGF0YS1vcmllbnRhdGlvbj17Zm9ybUZhY3Rvci5vcmllbnRhdGlvbn1cbiAgICA+XG4gICAgICB7IWltYWdlQWN0aXZlICYmIGNvbmZsaWN0ICYmIGJ1ZmZlciAmJiAoXG4gICAgICAgIDxDb25mbGljdEJhclxuICAgICAgICAgIHBhdGg9e2J1ZmZlci5wYXRofVxuICAgICAgICAgIG1pbmU9e2J1ZmZlci5idWZmZXJ9XG4gICAgICAgICAgdGhlaXJzPXtjb25mbGljdC50aGVpcnN9XG4gICAgICAgICAgb25LZWVwTWluZT17cmVzb2x2ZUtlZXBNaW5lfVxuICAgICAgICAgIG9uVGFrZVRoZWlycz17cmVzb2x2ZVRha2VUaGVpcnN9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7IWltYWdlQWN0aXZlICYmIHJlYWRPbmx5ICYmIHBoYXNlID09PSBcInJlYWR5XCIgJiYgIWJ1ZmZlcj8udmFuaXNoZWQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVkLXJlYWRvbmx5LW5vdGVcIiByb2xlPVwibm90ZVwiPlxuICAgICAgICAgIHt3cml0YWJsZVxuICAgICAgICAgICAgPyBcIlJlYWQtb25seSDigJQgdGhpcyBmaWxlIGlzIHJlZ2VuZXJhdGVkIG9uIGVhY2ggcnVuLlwiXG4gICAgICAgICAgICA6IFwiUmVhZC1vbmx5LlwifVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7IWltYWdlQWN0aXZlICYmIHNhdmVFcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWQtc2F2ZS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgIFNhdmUgZmFpbGVkOiB7c2F2ZUVycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWQtYm9keVwiPlxuICAgICAgICB7cGhhc2UgPT09IFwiYXdhaXRpbmctcG9ydFwiICYmIDxQbGFjZWhvbGRlciBraW5kPVwiYXdhaXRpbmctcG9ydFwiIC8+fVxuICAgICAgICB7cGhhc2UgPT09IFwibm8tYWN0aXZlLWZpbGVcIiAmJiA8UGxhY2Vob2xkZXIga2luZD1cIm5vLWFjdGl2ZS1maWxlXCIgLz59XG4gICAgICAgIHshaW1hZ2VBY3RpdmUgJiYgcGhhc2UgPT09IFwicmVhZHlcIiAmJiBidWZmZXI/LnZhbmlzaGVkICYmIChcbiAgICAgICAgICA8UGxhY2Vob2xkZXIga2luZD1cInZhbmlzaGVkXCIgZGV0YWlsPXtidWZmZXIucGF0aH0gLz5cbiAgICAgICAgKX1cbiAgICAgICAgeyFpbWFnZUFjdGl2ZSAmJiBwaGFzZSA9PT0gXCJyZWFkeVwiICYmICFidWZmZXIgJiYgbG9hZEVycm9yICYmIChcbiAgICAgICAgICA8UGxhY2Vob2xkZXIga2luZD1cImVycm9yXCIgZGV0YWlsPXtsb2FkRXJyb3J9IC8+XG4gICAgICAgICl9XG4gICAgICAgIHtwaGFzZSA9PT0gXCJyZWFkeVwiICYmIGJ1ZmZlciAmJiAhYnVmZmVyLnZhbmlzaGVkICYmIChcbiAgICAgICAgICAvLyBXaGlsZSBhbiBpbWFnZSBjb3ZlcnMgdGhlIHBhbmUgdGhlIGVkaXRvciB1bmRlcm5lYXRoIGlzIGhpZGRlblxuICAgICAgICAgIC8vIGZyb20gcG9pbnRlciwga2V5Ym9hcmQgYW5kIHRoZSBhY2Nlc3NpYmlsaXR5IHRyZWUgKFdDQUcgMi4xLjEgL1xuICAgICAgICAgIC8vIDIuNC4zKSDigJQgYW5kIHN0YXlzIE1PVU5URUQsIHNvIHN3aXRjaGluZyBiYWNrIGlzIGEgcmVjb25maWd1cmUsXG4gICAgICAgICAgLy8gbm90IGEgcmVidWlsZC5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVkLWNtLXdyYXBcIiBpbmVydD17aW1hZ2VBY3RpdmV9IGFyaWEtaGlkZGVuPXtpbWFnZUFjdGl2ZX0+XG4gICAgICAgICAgICA8Q29kZU1pcnJvclZpZXdcbiAgICAgICAgICAgICAgcGF0aD17YnVmZmVyLnBhdGh9XG4gICAgICAgICAgICAgIGRvYz17YnVmZmVyLmJ1ZmZlcn1cbiAgICAgICAgICAgICAgcmVhZE9ubHk9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICB0aGVtZT17dGhlbWV9XG4gICAgICAgICAgICAgIGVycm9ycz17ZXJyb3JzfVxuICAgICAgICAgICAgICBzZWxlY3Rpb249e2NhcmV0fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0VGV4dH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIHtpbWFnZUFjdGl2ZSAmJiA8SW1hZ2VPdmVybGF5IHByZXZpZXc9e2ltYWdlfSAvPn1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFPQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFLQSxJQUFBQyxjQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxnQkFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsZUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksZ0JBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFVBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLGVBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLFlBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLGFBQUEsR0FBQVIsT0FBQTtBQUNBLElBQUFTLFlBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLGVBQUEsR0FBQVYsT0FBQTtBQUNBQSxPQUFBO0FBQ0FBLE9BQUE7QUFBbUIsSUFBQVcsV0FBQSxHQUFBWCxPQUFBO0FBQUEsSUFBQVksRUFBQSxHQUFBQyxZQUFBLElBdkJuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFvQmUsU0FBU0MsR0FBR0EsQ0FBQSxFQUFHO0VBQUFGLEVBQUE7RUFDNUIsTUFBTTtJQUFFRztFQUFXLENBQUMsR0FBRyxJQUFBQyxxQkFBZ0IsRUFBQyxDQUFDO0VBQ3pDLE1BQU1DLEtBQUssR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDNUIsTUFBTUMsVUFBVSxHQUFHLElBQUFDLGtCQUFhLEVBQUMsQ0FBQztFQUNsQyxNQUFNQyxXQUFXLEdBQUcsSUFBQUMsOEJBQWMsRUFBQyxDQUFDO0VBQ3BDO0VBQ0EsTUFBTUMsS0FBSyxHQUFHLElBQUFDLGdDQUFlLEVBQUMsQ0FBQztFQUUvQixNQUFNO0lBQ0pDLE1BQU07SUFDTkMsU0FBUztJQUNUQyxTQUFTO0lBQ1RDLFFBQVE7SUFDUkMsU0FBUztJQUNUQyxPQUFPO0lBQ1BDLGVBQWU7SUFDZkM7RUFDRixDQUFDLEdBQUcsSUFBQUMsNEJBQWEsRUFBQ2xCLFVBQVUsQ0FBQztFQUU3QixNQUFNbUIsS0FBSyxHQUFHLElBQUFDLHVCQUFZLEVBQUM7SUFBRU4sU0FBUztJQUFFZDtFQUFXLENBQUMsQ0FBQzs7RUFFckQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNcUIsS0FBSyxHQUFHLElBQUFDLGdDQUFlLEVBQUN0QixVQUFVLEVBQUVjLFNBQVMsQ0FBQztFQUNwRDtFQUNBO0VBQ0E7RUFDQSxNQUFNUyxXQUFXLEdBQ2ZKLEtBQUssS0FBSyxPQUFPLElBQUlFLEtBQUssQ0FBQ0csS0FBSyxLQUFLLE1BQU0sSUFBSUgsS0FBSyxDQUFDSSxJQUFJLEtBQUt6QixVQUFVOztFQUUxRTtFQUNBO0VBQ0E7RUFDQSxNQUFNMEIsUUFBUSxHQUNaLENBQUNiLFFBQVEsSUFBS2IsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFBMkIsK0JBQWUsRUFBQzNCLFVBQVUsQ0FBRTtFQUVsRSxNQUFNNEIsUUFBUSxHQUFHbEIsTUFBTSxFQUFFa0IsUUFBUSxJQUFJLElBQUk7RUFDekMsTUFBTUMsTUFBTSxHQUFHN0IsVUFBVSxHQUFHTSxXQUFXLEdBQUcsRUFBRTtFQUU1QyxvQkFDRSxJQUFBVixXQUFBLENBQUFrQyxJQUFBO0lBQ0VDLFNBQVMsRUFBQyxZQUFZO0lBQ3RCLGNBQVk3QixLQUFNO0lBQ2xCLG9CQUFrQkUsVUFBVSxDQUFDNEIsS0FBTTtJQUNuQyxvQkFBa0I1QixVQUFVLENBQUM2QixXQUFZO0lBQUFDLFFBQUEsR0FFeEMsQ0FBQ1gsV0FBVyxJQUFJSyxRQUFRLElBQUlsQixNQUFNLGlCQUNqQyxJQUFBZCxXQUFBLENBQUF1QyxHQUFBLEVBQUMzQyxZQUFBLENBQUE0QyxXQUFXO01BQ1ZYLElBQUksRUFBRWYsTUFBTSxDQUFDZSxJQUFLO01BQ2xCWSxJQUFJLEVBQUUzQixNQUFNLENBQUNBLE1BQU87TUFDcEI0QixNQUFNLEVBQUVWLFFBQVEsQ0FBQ1UsTUFBTztNQUN4QkMsVUFBVSxFQUFFdkIsZUFBZ0I7TUFDNUJ3QixZQUFZLEVBQUV2QjtJQUFrQixDQUNqQyxDQUNGLEVBRUEsQ0FBQ00sV0FBVyxJQUFJRyxRQUFRLElBQUlQLEtBQUssS0FBSyxPQUFPLElBQUksQ0FBQ1QsTUFBTSxFQUFFK0IsUUFBUSxpQkFDakUsSUFBQTdDLFdBQUEsQ0FBQXVDLEdBQUE7TUFBS0osU0FBUyxFQUFDLGtCQUFrQjtNQUFDVyxJQUFJLEVBQUMsTUFBTTtNQUFBUixRQUFBLEVBQzFDckIsUUFBUSxHQUNMLG1EQUFtRCxHQUNuRDtJQUFZLENBQ2IsQ0FDTixFQUNBLENBQUNVLFdBQVcsSUFBSVgsU0FBUyxpQkFDeEIsSUFBQWhCLFdBQUEsQ0FBQWtDLElBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQ1csSUFBSSxFQUFDLE9BQU87TUFBQVIsUUFBQSxHQUFDLGVBQzdCLEVBQUN0QixTQUFTO0lBQUEsQ0FDcEIsQ0FDTixlQUVELElBQUFoQixXQUFBLENBQUFrQyxJQUFBO01BQUtDLFNBQVMsRUFBQyxTQUFTO01BQUFHLFFBQUEsR0FDckJmLEtBQUssS0FBSyxlQUFlLGlCQUFJLElBQUF2QixXQUFBLENBQUF1QyxHQUFBLEVBQUN6QyxZQUFBLENBQUFpRCxXQUFXO1FBQUNDLElBQUksRUFBQztNQUFlLENBQUUsQ0FBQyxFQUNqRXpCLEtBQUssS0FBSyxnQkFBZ0IsaUJBQUksSUFBQXZCLFdBQUEsQ0FBQXVDLEdBQUEsRUFBQ3pDLFlBQUEsQ0FBQWlELFdBQVc7UUFBQ0MsSUFBSSxFQUFDO01BQWdCLENBQUUsQ0FBQyxFQUNuRSxDQUFDckIsV0FBVyxJQUFJSixLQUFLLEtBQUssT0FBTyxJQUFJVCxNQUFNLEVBQUUrQixRQUFRLGlCQUNwRCxJQUFBN0MsV0FBQSxDQUFBdUMsR0FBQSxFQUFDekMsWUFBQSxDQUFBaUQsV0FBVztRQUFDQyxJQUFJLEVBQUMsVUFBVTtRQUFDQyxNQUFNLEVBQUVuQyxNQUFNLENBQUNlO01BQUssQ0FBRSxDQUNwRCxFQUNBLENBQUNGLFdBQVcsSUFBSUosS0FBSyxLQUFLLE9BQU8sSUFBSSxDQUFDVCxNQUFNLElBQUlDLFNBQVMsaUJBQ3hELElBQUFmLFdBQUEsQ0FBQXVDLEdBQUEsRUFBQ3pDLFlBQUEsQ0FBQWlELFdBQVc7UUFBQ0MsSUFBSSxFQUFDLE9BQU87UUFBQ0MsTUFBTSxFQUFFbEM7TUFBVSxDQUFFLENBQy9DLEVBQ0FRLEtBQUssS0FBSyxPQUFPLElBQUlULE1BQU0sSUFBSSxDQUFDQSxNQUFNLENBQUMrQixRQUFRO01BQUE7TUFDOUM7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFBN0MsV0FBQSxDQUFBdUMsR0FBQTtRQUFLSixTQUFTLEVBQUMsWUFBWTtRQUFDZSxLQUFLLEVBQUV2QixXQUFZO1FBQUMsZUFBYUEsV0FBWTtRQUFBVyxRQUFBLGVBQ3ZFLElBQUF0QyxXQUFBLENBQUF1QyxHQUFBLEVBQUM1QyxlQUFBLENBQUF3RCxjQUFjO1VBQ2J0QixJQUFJLEVBQUVmLE1BQU0sQ0FBQ2UsSUFBSztVQUNsQnVCLEdBQUcsRUFBRXRDLE1BQU0sQ0FBQ0EsTUFBTztVQUNuQmdCLFFBQVEsRUFBRUEsUUFBUztVQUNuQnhCLEtBQUssRUFBRUEsS0FBTTtVQUNiMkIsTUFBTSxFQUFFQSxNQUFPO1VBQ2ZvQixTQUFTLEVBQUV6QyxLQUFNO1VBQ2pCMEMsUUFBUSxFQUFFbkM7UUFBUSxDQUNuQjtNQUFDLENBQ0MsQ0FDTixFQUNBUSxXQUFXLGlCQUFJLElBQUEzQixXQUFBLENBQUF1QyxHQUFBLEVBQUMxQyxhQUFBLENBQUEwRCxZQUFZO1FBQUNDLE9BQU8sRUFBRS9CO01BQU0sQ0FBRSxDQUFDO0lBQUEsQ0FDN0MsQ0FBQztFQUFBLENBQ0gsQ0FBQztBQUVWO0FBQUN4QixFQUFBLENBckd1QkUsR0FBRztFQUFBLFFBQ0ZFLHFCQUFnQixFQUN6QkUsaUJBQVksRUFDUEUsa0JBQWEsRUFDWkUsOEJBQWMsRUFFcEJFLGdDQUFlLEVBV3pCUyw0QkFBYSxFQVFISSxnQ0FBZTtBQUFBO0FBQUErQixFQUFBLEdBekJQdEQsR0FBRztBQUFBLElBQUFzRCxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}