"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.languageExtension = languageExtension;
var _langJavascript = require("@codemirror/lang-javascript");
var _langJson = require("@codemirror/lang-json");
var _langCss = require("@codemirror/lang-css");
var _langHtml = require("@codemirror/lang-html");
var _langMarkdown = require("@codemirror/lang-markdown");
var _langForPath = require("../core/langForPath");
// Resolve a CodeMirror 6 language extension for a path. Keeps the (impure,
// dependency-heavy) CodeMirror imports out of the pure `core/langForPath.ts`
// selector, which is what the unit tests exercise.

function languageExtension(path) {
  switch ((0, _langForPath.langForPath)(path)) {
    case 'javascript':
      return [(0, _langJavascript.javascript)({
        typescript: (0, _langForPath.isTypeScript)(path),
        jsx: (0, _langForPath.isJsx)(path)
      })];
    case 'json':
      return [(0, _langJson.json)()];
    case 'css':
      return [(0, _langCss.css)()];
    case 'html':
      return [(0, _langHtml.html)()];
    case 'markdown':
      return [(0, _langMarkdown.markdown)()];
    case 'none':
      return [];
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbGFuZ0phdmFzY3JpcHQiLCJyZXF1aXJlIiwiX2xhbmdKc29uIiwiX2xhbmdDc3MiLCJfbGFuZ0h0bWwiLCJfbGFuZ01hcmtkb3duIiwiX2xhbmdGb3JQYXRoIiwibGFuZ3VhZ2VFeHRlbnNpb24iLCJwYXRoIiwibGFuZ0ZvclBhdGgiLCJqYXZhc2NyaXB0IiwidHlwZXNjcmlwdCIsImlzVHlwZVNjcmlwdCIsImpzeCIsImlzSnN4IiwianNvbiIsImNzcyIsImh0bWwiLCJtYXJrZG93biJdLCJzb3VyY2VzIjpbImxhbmd1YWdlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJlc29sdmUgYSBDb2RlTWlycm9yIDYgbGFuZ3VhZ2UgZXh0ZW5zaW9uIGZvciBhIHBhdGguIEtlZXBzIHRoZSAoaW1wdXJlLFxuLy8gZGVwZW5kZW5jeS1oZWF2eSkgQ29kZU1pcnJvciBpbXBvcnRzIG91dCBvZiB0aGUgcHVyZSBgY29yZS9sYW5nRm9yUGF0aC50c2Bcbi8vIHNlbGVjdG9yLCB3aGljaCBpcyB3aGF0IHRoZSB1bml0IHRlc3RzIGV4ZXJjaXNlLlxuXG5pbXBvcnQgdHlwZSB7IEV4dGVuc2lvbiB9IGZyb20gJ0Bjb2RlbWlycm9yL3N0YXRlJztcbmltcG9ydCB7IGphdmFzY3JpcHQgfSBmcm9tICdAY29kZW1pcnJvci9sYW5nLWphdmFzY3JpcHQnO1xuaW1wb3J0IHsganNvbiB9IGZyb20gJ0Bjb2RlbWlycm9yL2xhbmctanNvbic7XG5pbXBvcnQgeyBjc3MgfSBmcm9tICdAY29kZW1pcnJvci9sYW5nLWNzcyc7XG5pbXBvcnQgeyBodG1sIH0gZnJvbSAnQGNvZGVtaXJyb3IvbGFuZy1odG1sJztcbmltcG9ydCB7IG1hcmtkb3duIH0gZnJvbSAnQGNvZGVtaXJyb3IvbGFuZy1tYXJrZG93bic7XG5pbXBvcnQgeyBsYW5nRm9yUGF0aCwgaXNUeXBlU2NyaXB0LCBpc0pzeCB9IGZyb20gJy4uL2NvcmUvbGFuZ0ZvclBhdGgnO1xuXG5leHBvcnQgZnVuY3Rpb24gbGFuZ3VhZ2VFeHRlbnNpb24ocGF0aDogc3RyaW5nKTogRXh0ZW5zaW9uW10ge1xuICBzd2l0Y2ggKGxhbmdGb3JQYXRoKHBhdGgpKSB7XG4gICAgY2FzZSAnamF2YXNjcmlwdCc6XG4gICAgICByZXR1cm4gW2phdmFzY3JpcHQoeyB0eXBlc2NyaXB0OiBpc1R5cGVTY3JpcHQocGF0aCksIGpzeDogaXNKc3gocGF0aCkgfSldO1xuICAgIGNhc2UgJ2pzb24nOlxuICAgICAgcmV0dXJuIFtqc29uKCldO1xuICAgIGNhc2UgJ2Nzcyc6XG4gICAgICByZXR1cm4gW2NzcygpXTtcbiAgICBjYXNlICdodG1sJzpcbiAgICAgIHJldHVybiBbaHRtbCgpXTtcbiAgICBjYXNlICdtYXJrZG93bic6XG4gICAgICByZXR1cm4gW21hcmtkb3duKCldO1xuICAgIGNhc2UgJ25vbmUnOlxuICAgICAgcmV0dXJuIFtdO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLGVBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFNBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGFBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFlBQUEsR0FBQUwsT0FBQTtBQVZBO0FBQ0E7QUFDQTs7QUFVTyxTQUFTTSxpQkFBaUJBLENBQUNDLElBQVksRUFBZTtFQUMzRCxRQUFRLElBQUFDLHdCQUFXLEVBQUNELElBQUksQ0FBQztJQUN2QixLQUFLLFlBQVk7TUFDZixPQUFPLENBQUMsSUFBQUUsMEJBQVUsRUFBQztRQUFFQyxVQUFVLEVBQUUsSUFBQUMseUJBQVksRUFBQ0osSUFBSSxDQUFDO1FBQUVLLEdBQUcsRUFBRSxJQUFBQyxrQkFBSyxFQUFDTixJQUFJO01BQUUsQ0FBQyxDQUFDLENBQUM7SUFDM0UsS0FBSyxNQUFNO01BQ1QsT0FBTyxDQUFDLElBQUFPLGNBQUksRUFBQyxDQUFDLENBQUM7SUFDakIsS0FBSyxLQUFLO01BQ1IsT0FBTyxDQUFDLElBQUFDLFlBQUcsRUFBQyxDQUFDLENBQUM7SUFDaEIsS0FBSyxNQUFNO01BQ1QsT0FBTyxDQUFDLElBQUFDLGNBQUksRUFBQyxDQUFDLENBQUM7SUFDakIsS0FBSyxVQUFVO01BQ2IsT0FBTyxDQUFDLElBQUFDLHNCQUFRLEVBQUMsQ0FBQyxDQUFDO0lBQ3JCLEtBQUssTUFBTTtNQUNULE9BQU8sRUFBRTtFQUNiO0FBQ0YiLCJpZ25vcmVMaXN0IjpbXX0=