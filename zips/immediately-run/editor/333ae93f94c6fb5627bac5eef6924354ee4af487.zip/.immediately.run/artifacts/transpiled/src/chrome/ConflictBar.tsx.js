var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ConflictBar = ConflictBar;
exports.default = void 0;
var _react = require("react");
var _lucideReact = require("lucide-react");
var _baseName = require("../core/baseName");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The §6 blocking conflict surface. When an external write lands on a file the
// user has uncommitted edits in, the buffer is NOT modified and save is blocked;
// this bar offers the only ways out — keep mine / take theirs / show diff. The
// user's keystrokes are never touched (the editor anchors "Save to GitHub", so a
// silent byte-substitution into the about-to-be-saved buffer is a code-integrity
// vector — spec §6 / threat M6).
function ConflictBar({
  path,
  mine,
  theirs,
  onKeepMine,
  onTakeTheirs
}) {
  _s();
  const [showDiff, setShowDiff] = (0, _react.useState)(false);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "conflict",
    role: "alertdialog",
    "aria-label": "File changed on disk",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "conflict-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "conflict-msg",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.AlertTriangle, {
          size: 14
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
          children: (0, _baseName.baseName)(path)
        }), " changed on disk while you were editing. Saving is blocked until you choose."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "conflict-actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "btn",
          onClick: onKeepMine,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Check, {
            size: 13
          }), " Keep mine"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "btn",
          onClick: onTakeTheirs,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Download, {
            size: 13
          }), " Take theirs"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "btn ghost",
          onClick: () => setShowDiff(v => !v),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.GitCompare, {
            size: 13
          }), " ", showDiff ? 'Hide diff' : 'Show diff']
        })]
      })]
    }), showDiff && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "conflict-diff",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "diff-col",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "diff-head",
          children: "Mine (unsaved)"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
          children: mine
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "diff-col",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "diff-head",
          children: "Theirs (on disk)"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("pre", {
          children: theirs
        })]
      })]
    })]
  });
}
_s(ConflictBar, "vdM8gx281PCsDmykpuRMyGp4K3o=");
_c = ConflictBar;
var _default = exports.default = ConflictBar;
var _c;
$RefreshReg$(_c, "ConflictBar");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX2Jhc2VOYW1lIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkNvbmZsaWN0QmFyIiwicGF0aCIsIm1pbmUiLCJ0aGVpcnMiLCJvbktlZXBNaW5lIiwib25UYWtlVGhlaXJzIiwic2hvd0RpZmYiLCJzZXRTaG93RGlmZiIsInVzZVN0YXRlIiwianN4cyIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsImpzeCIsIkFsZXJ0VHJpYW5nbGUiLCJzaXplIiwiYmFzZU5hbWUiLCJ0eXBlIiwib25DbGljayIsIkNoZWNrIiwiRG93bmxvYWQiLCJ2IiwiR2l0Q29tcGFyZSIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbmZsaWN0QmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgwqc2IGJsb2NraW5nIGNvbmZsaWN0IHN1cmZhY2UuIFdoZW4gYW4gZXh0ZXJuYWwgd3JpdGUgbGFuZHMgb24gYSBmaWxlIHRoZVxuLy8gdXNlciBoYXMgdW5jb21taXR0ZWQgZWRpdHMgaW4sIHRoZSBidWZmZXIgaXMgTk9UIG1vZGlmaWVkIGFuZCBzYXZlIGlzIGJsb2NrZWQ7XG4vLyB0aGlzIGJhciBvZmZlcnMgdGhlIG9ubHkgd2F5cyBvdXQg4oCUIGtlZXAgbWluZSAvIHRha2UgdGhlaXJzIC8gc2hvdyBkaWZmLiBUaGVcbi8vIHVzZXIncyBrZXlzdHJva2VzIGFyZSBuZXZlciB0b3VjaGVkICh0aGUgZWRpdG9yIGFuY2hvcnMgXCJTYXZlIHRvIEdpdEh1YlwiLCBzbyBhXG4vLyBzaWxlbnQgYnl0ZS1zdWJzdGl0dXRpb24gaW50byB0aGUgYWJvdXQtdG8tYmUtc2F2ZWQgYnVmZmVyIGlzIGEgY29kZS1pbnRlZ3JpdHlcbi8vIHZlY3RvciDigJQgc3BlYyDCpzYgLyB0aHJlYXQgTTYpLlxuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIENoZWNrLCBEb3dubG9hZCwgR2l0Q29tcGFyZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBiYXNlTmFtZSB9IGZyb20gJy4uL2NvcmUvYmFzZU5hbWUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZsaWN0QmFyUHJvcHMge1xuICBwYXRoOiBzdHJpbmc7XG4gIC8qKiBUaGUgdXNlcidzIGN1cnJlbnQgKHVuc2F2ZWQpIGJ1ZmZlci4gKi9cbiAgbWluZTogc3RyaW5nO1xuICAvKiogVGhlIGV4dGVybmFsIGJ5dGVzIG5vdyBvbiBkaXNrLiAqL1xuICB0aGVpcnM6IHN0cmluZztcbiAgb25LZWVwTWluZTogKCkgPT4gdm9pZDtcbiAgb25UYWtlVGhlaXJzOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ29uZmxpY3RCYXIoeyBwYXRoLCBtaW5lLCB0aGVpcnMsIG9uS2VlcE1pbmUsIG9uVGFrZVRoZWlycyB9OiBDb25mbGljdEJhclByb3BzKSB7XG4gIGNvbnN0IFtzaG93RGlmZiwgc2V0U2hvd0RpZmZdID0gdXNlU3RhdGUoZmFsc2UpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29uZmxpY3RcIiByb2xlPVwiYWxlcnRkaWFsb2dcIiBhcmlhLWxhYmVsPVwiRmlsZSBjaGFuZ2VkIG9uIGRpc2tcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29uZmxpY3Qtcm93XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbmZsaWN0LW1zZ1wiPlxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezE0fSAvPlxuICAgICAgICAgIDxzdHJvbmc+e2Jhc2VOYW1lKHBhdGgpfTwvc3Ryb25nPiBjaGFuZ2VkIG9uIGRpc2sgd2hpbGUgeW91IHdlcmUgZWRpdGluZy4gU2F2aW5nIGlzXG4gICAgICAgICAgYmxvY2tlZCB1bnRpbCB5b3UgY2hvb3NlLlxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29uZmxpY3QtYWN0aW9uc1wiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0blwiIG9uQ2xpY2s9e29uS2VlcE1pbmV9PlxuICAgICAgICAgICAgPENoZWNrIHNpemU9ezEzfSAvPiBLZWVwIG1pbmVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG5cIiBvbkNsaWNrPXtvblRha2VUaGVpcnN9PlxuICAgICAgICAgICAgPERvd25sb2FkIHNpemU9ezEzfSAvPiBUYWtlIHRoZWlyc1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dEaWZmKCh2KSA9PiAhdil9PlxuICAgICAgICAgICAgPEdpdENvbXBhcmUgc2l6ZT17MTN9IC8+IHtzaG93RGlmZiA/ICdIaWRlIGRpZmYnIDogJ1Nob3cgZGlmZid9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICB7c2hvd0RpZmYgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbmZsaWN0LWRpZmZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpZmYtY29sXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpZmYtaGVhZFwiPk1pbmUgKHVuc2F2ZWQpPC9kaXY+XG4gICAgICAgICAgICA8cHJlPnttaW5lfTwvcHJlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlmZi1jb2xcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlmZi1oZWFkXCI+VGhlaXJzIChvbiBkaXNrKTwvZGl2PlxuICAgICAgICAgICAgPHByZT57dGhlaXJzfTwvcHJlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbmZsaWN0QmFyO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBT0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBQTRDLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLElBQUFJLEVBQUEsR0FBQUMsWUFBQSxJQVQ1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFnQk8sU0FBU0MsV0FBV0EsQ0FBQztFQUFFQyxJQUFJO0VBQUVDLElBQUk7RUFBRUMsTUFBTTtFQUFFQyxVQUFVO0VBQUVDO0FBQStCLENBQUMsRUFBRTtFQUFBUCxFQUFBO0VBQzlGLE1BQU0sQ0FBQ1EsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQy9DLG9CQUNFLElBQUFYLFdBQUEsQ0FBQVksSUFBQTtJQUFLQyxTQUFTLEVBQUMsVUFBVTtJQUFDQyxJQUFJLEVBQUMsYUFBYTtJQUFDLGNBQVcsc0JBQXNCO0lBQUFDLFFBQUEsZ0JBQzVFLElBQUFmLFdBQUEsQ0FBQVksSUFBQTtNQUFLQyxTQUFTLEVBQUMsY0FBYztNQUFBRSxRQUFBLGdCQUMzQixJQUFBZixXQUFBLENBQUFZLElBQUE7UUFBTUMsU0FBUyxFQUFDLGNBQWM7UUFBQUUsUUFBQSxnQkFDNUIsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDbEIsWUFBQSxDQUFBbUIsYUFBYTtVQUFDQyxJQUFJLEVBQUU7UUFBRyxDQUFFLENBQUMsZUFDM0IsSUFBQWxCLFdBQUEsQ0FBQWdCLEdBQUE7VUFBQUQsUUFBQSxFQUFTLElBQUFJLGtCQUFRLEVBQUNmLElBQUk7UUFBQyxDQUFTLENBQUMsZ0ZBRW5DO01BQUEsQ0FBTSxDQUFDLGVBQ1AsSUFBQUosV0FBQSxDQUFBWSxJQUFBO1FBQUtDLFNBQVMsRUFBQyxrQkFBa0I7UUFBQUUsUUFBQSxnQkFDL0IsSUFBQWYsV0FBQSxDQUFBWSxJQUFBO1VBQVFRLElBQUksRUFBQyxRQUFRO1VBQUNQLFNBQVMsRUFBQyxLQUFLO1VBQUNRLE9BQU8sRUFBRWQsVUFBVztVQUFBUSxRQUFBLGdCQUN4RCxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNsQixZQUFBLENBQUF3QixLQUFLO1lBQUNKLElBQUksRUFBRTtVQUFHLENBQUUsQ0FBQyxjQUNyQjtRQUFBLENBQVEsQ0FBQyxlQUNULElBQUFsQixXQUFBLENBQUFZLElBQUE7VUFBUVEsSUFBSSxFQUFDLFFBQVE7VUFBQ1AsU0FBUyxFQUFDLEtBQUs7VUFBQ1EsT0FBTyxFQUFFYixZQUFhO1VBQUFPLFFBQUEsZ0JBQzFELElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2xCLFlBQUEsQ0FBQXlCLFFBQVE7WUFBQ0wsSUFBSSxFQUFFO1VBQUcsQ0FBRSxDQUFDLGdCQUN4QjtRQUFBLENBQVEsQ0FBQyxlQUNULElBQUFsQixXQUFBLENBQUFZLElBQUE7VUFBUVEsSUFBSSxFQUFDLFFBQVE7VUFBQ1AsU0FBUyxFQUFDLFdBQVc7VUFBQ1EsT0FBTyxFQUFFQSxDQUFBLEtBQU1YLFdBQVcsQ0FBRWMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBRTtVQUFBVCxRQUFBLGdCQUNoRixJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNsQixZQUFBLENBQUEyQixVQUFVO1lBQUNQLElBQUksRUFBRTtVQUFHLENBQUUsQ0FBQyxLQUFDLEVBQUNULFFBQVEsR0FBRyxXQUFXLEdBQUcsV0FBVztRQUFBLENBQ3hELENBQUM7TUFBQSxDQUNOLENBQUM7SUFBQSxDQUNILENBQUMsRUFDTEEsUUFBUSxpQkFDUCxJQUFBVCxXQUFBLENBQUFZLElBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQUUsUUFBQSxnQkFDNUIsSUFBQWYsV0FBQSxDQUFBWSxJQUFBO1FBQUtDLFNBQVMsRUFBQyxVQUFVO1FBQUFFLFFBQUEsZ0JBQ3ZCLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUE7VUFBS0gsU0FBUyxFQUFDLFdBQVc7VUFBQUUsUUFBQSxFQUFDO1FBQWMsQ0FBSyxDQUFDLGVBQy9DLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUE7VUFBQUQsUUFBQSxFQUFNVjtRQUFJLENBQU0sQ0FBQztNQUFBLENBQ2QsQ0FBQyxlQUNOLElBQUFMLFdBQUEsQ0FBQVksSUFBQTtRQUFLQyxTQUFTLEVBQUMsVUFBVTtRQUFBRSxRQUFBLGdCQUN2QixJQUFBZixXQUFBLENBQUFnQixHQUFBO1VBQUtILFNBQVMsRUFBQyxXQUFXO1VBQUFFLFFBQUEsRUFBQztRQUFnQixDQUFLLENBQUMsZUFDakQsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQTtVQUFBRCxRQUFBLEVBQU1UO1FBQU0sQ0FBTSxDQUFDO01BQUEsQ0FDaEIsQ0FBQztJQUFBLENBQ0gsQ0FDTjtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUNMLEVBQUEsQ0FwQ2VFLFdBQVc7QUFBQXVCLEVBQUEsR0FBWHZCLFdBQVc7QUFBQSxJQUFBd0IsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FzQ1oxQixXQUFXO0FBQUEsSUFBQXVCLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}