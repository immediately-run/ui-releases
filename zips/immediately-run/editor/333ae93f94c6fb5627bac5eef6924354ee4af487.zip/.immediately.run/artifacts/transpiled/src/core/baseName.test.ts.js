"use strict";

var _vitest = require("vitest");
var _baseName = require("./baseName");
(0, _vitest.describe)('baseName', () => {
  (0, _vitest.it)('returns the last non-empty segment', () => {
    (0, _vitest.expect)((0, _baseName.baseName)('/a/b/notes.txt')).toBe('notes.txt');
    (0, _vitest.expect)((0, _baseName.baseName)('notes.txt')).toBe('notes.txt');
  });
  (0, _vitest.it)('falls back to the input when there is no non-empty segment', () => {
    (0, _vitest.expect)((0, _baseName.baseName)('/')).toBe('/');
  });
  (0, _vitest.it)('ignores a trailing slash', () => {
    (0, _vitest.expect)((0, _baseName.baseName)('/a/b/')).toBe('b');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9iYXNlTmFtZSIsImRlc2NyaWJlIiwiaXQiLCJleHBlY3QiLCJiYXNlTmFtZSIsInRvQmUiXSwic291cmNlcyI6WyJiYXNlTmFtZS50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0IH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGJhc2VOYW1lIH0gZnJvbSAnLi9iYXNlTmFtZSc7XG5cbmRlc2NyaWJlKCdiYXNlTmFtZScsICgpID0+IHtcbiAgaXQoJ3JldHVybnMgdGhlIGxhc3Qgbm9uLWVtcHR5IHNlZ21lbnQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGJhc2VOYW1lKCcvYS9iL25vdGVzLnR4dCcpKS50b0JlKCdub3Rlcy50eHQnKTtcbiAgICBleHBlY3QoYmFzZU5hbWUoJ25vdGVzLnR4dCcpKS50b0JlKCdub3Rlcy50eHQnKTtcbiAgfSk7XG5cbiAgaXQoJ2ZhbGxzIGJhY2sgdG8gdGhlIGlucHV0IHdoZW4gdGhlcmUgaXMgbm8gbm9uLWVtcHR5IHNlZ21lbnQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGJhc2VOYW1lKCcvJykpLnRvQmUoJy8nKTtcbiAgfSk7XG5cbiAgaXQoJ2lnbm9yZXMgYSB0cmFpbGluZyBzbGFzaCcsICgpID0+IHtcbiAgICBleHBlY3QoYmFzZU5hbWUoJy9hL2IvJykpLnRvQmUoJ2InKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxnQkFBUSxFQUFDLFVBQVUsRUFBRSxNQUFNO0VBQ3pCLElBQUFDLFVBQUUsRUFBQyxvQ0FBb0MsRUFBRSxNQUFNO0lBQzdDLElBQUFDLGNBQU0sRUFBQyxJQUFBQyxrQkFBUSxFQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUNwRCxJQUFBRixjQUFNLEVBQUMsSUFBQUMsa0JBQVEsRUFBQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyw0REFBNEQsRUFBRSxNQUFNO0lBQ3JFLElBQUFDLGNBQU0sRUFBQyxJQUFBQyxrQkFBUSxFQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDakMsQ0FBQyxDQUFDO0VBRUYsSUFBQUgsVUFBRSxFQUFDLDBCQUEwQixFQUFFLE1BQU07SUFDbkMsSUFBQUMsY0FBTSxFQUFDLElBQUFDLGtCQUFRLEVBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUNyQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=