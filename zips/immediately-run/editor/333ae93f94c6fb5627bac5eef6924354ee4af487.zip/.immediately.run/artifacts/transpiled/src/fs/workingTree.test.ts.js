"use strict";

var _vitest = require("vitest");
var _workingTree = require("./workingTree");
// The functions under test (joinMount/resolveWorkingTreeRoot/isWritable) are pure
// and never call the SDK; mock it only so importing workingTree.ts doesn't pull
// the SDK's extensionless ESM re-exports through vitest's strict resolver.
_vitest.vi.mock('@immediately-run/sdk', () => ({
  getMounts: () => [],
  getAppMountPath: () => '/app'
}));
// mountFs now reaches the sandbox fs through the SDK's `@immediately-run/sdk/fs`
// subpath; mock it too (same reason — keep its extensionless ESM out of vitest's
// strict resolver). The functions under test never touch it.
_vitest.vi.mock('@immediately-run/sdk/fs', () => ({
  sandboxFs: () => null,
  fsAvailable: () => false
}));
(0, _vitest.describe)('joinMount', () => {
  (0, _vitest.it)('joins a mount root with a repo-relative path', () => {
    (0, _vitest.expect)((0, _workingTree.joinMount)('/mnt/abc', '/src/App.tsx')).toBe('/mnt/abc/src/App.tsx');
    (0, _vitest.expect)((0, _workingTree.joinMount)('/mnt/abc/', 'src/App.tsx')).toBe('/mnt/abc/src/App.tsx');
    (0, _vitest.expect)((0, _workingTree.joinMount)('/app', '/index.html')).toBe('/app/index.html');
  });
});
(0, _vitest.describe)('resolveWorkingTreeRoot', () => {
  (0, _vitest.it)('prefers an explicit rw working-tree mount', () => {
    const mounts = [{
      path: '/mnt/wt',
      type: 'worktree',
      mode: 'rw'
    }];
    (0, _vitest.expect)((0, _workingTree.resolveWorkingTreeRoot)(mounts, '/app')).toBe('/mnt/wt');
  });
  (0, _vitest.it)('selects the worktree port by identity even when it is read-only', () => {
    // Regression: a local/zip/space stage app exposes its worktree `ro` (the source
    // mode clamps the binding's `rw`), while the editor's OWN repo is dual-mounted
    // `rw` at `/mnt/{hash}`. Selecting by `mode === 'rw'` skipped the `ro` worktree
    // and fell back to the app's own repo, so the editor read/edited ITSELF.
    const mounts = [{
      path: '/mnt/own',
      type: 'repo',
      mode: 'rw'
    }, {
      path: '/mnt/wt',
      type: 'worktree',
      mode: 'ro'
    }];
    (0, _vitest.expect)((0, _workingTree.resolveWorkingTreeRoot)(mounts, '/mnt/own')).toBe('/mnt/wt');
  });
  (0, _vitest.it)('falls back to the app mount path when there is no worktree or rw mount', () => {
    (0, _vitest.expect)((0, _workingTree.resolveWorkingTreeRoot)([], '/app')).toBe('/app');
    const ro = [{
      path: '/spaces/x',
      type: 'firestore',
      mode: 'ro'
    }];
    (0, _vitest.expect)((0, _workingTree.resolveWorkingTreeRoot)(ro, '/app')).toBe('/app');
  });
});
(0, _vitest.describe)('isWritable', () => {
  (0, _vitest.it)('is writable by default (the repo mount has no mode)', () => {
    (0, _vitest.expect)((0, _workingTree.isWritable)([])).toBe(true);
    (0, _vitest.expect)((0, _workingTree.isWritable)([{
      path: '/app',
      type: 'repo'
    }])).toBe(true);
  });
  (0, _vitest.it)('is read-only when the only mount is ro', () => {
    (0, _vitest.expect)((0, _workingTree.isWritable)([{
      path: '/spaces/x',
      type: 'firestore',
      mode: 'ro'
    }])).toBe(false);
  });
  (0, _vitest.it)('is writable when an rw mount is present alongside an ro one', () => {
    (0, _vitest.expect)((0, _workingTree.isWritable)([{
      path: '/spaces/x',
      type: 'firestore',
      mode: 'ro'
    }, {
      path: '/mnt/wt',
      type: 'worktree',
      mode: 'rw'
    }])).toBe(true);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl93b3JraW5nVHJlZSIsInZpIiwibW9jayIsImdldE1vdW50cyIsImdldEFwcE1vdW50UGF0aCIsInNhbmRib3hGcyIsImZzQXZhaWxhYmxlIiwiZGVzY3JpYmUiLCJpdCIsImV4cGVjdCIsImpvaW5Nb3VudCIsInRvQmUiLCJtb3VudHMiLCJwYXRoIiwidHlwZSIsIm1vZGUiLCJyZXNvbHZlV29ya2luZ1RyZWVSb290Iiwicm8iLCJpc1dyaXRhYmxlIl0sInNvdXJjZXMiOlsid29ya2luZ1RyZWUudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuXG4vLyBUaGUgZnVuY3Rpb25zIHVuZGVyIHRlc3QgKGpvaW5Nb3VudC9yZXNvbHZlV29ya2luZ1RyZWVSb290L2lzV3JpdGFibGUpIGFyZSBwdXJlXG4vLyBhbmQgbmV2ZXIgY2FsbCB0aGUgU0RLOyBtb2NrIGl0IG9ubHkgc28gaW1wb3J0aW5nIHdvcmtpbmdUcmVlLnRzIGRvZXNuJ3QgcHVsbFxuLy8gdGhlIFNESydzIGV4dGVuc2lvbmxlc3MgRVNNIHJlLWV4cG9ydHMgdGhyb3VnaCB2aXRlc3QncyBzdHJpY3QgcmVzb2x2ZXIuXG52aS5tb2NrKCdAaW1tZWRpYXRlbHktcnVuL3NkaycsICgpID0+ICh7XG4gIGdldE1vdW50czogKCkgPT4gW10sXG4gIGdldEFwcE1vdW50UGF0aDogKCkgPT4gJy9hcHAnLFxufSkpO1xuLy8gbW91bnRGcyBub3cgcmVhY2hlcyB0aGUgc2FuZGJveCBmcyB0aHJvdWdoIHRoZSBTREsncyBgQGltbWVkaWF0ZWx5LXJ1bi9zZGsvZnNgXG4vLyBzdWJwYXRoOyBtb2NrIGl0IHRvbyAoc2FtZSByZWFzb24g4oCUIGtlZXAgaXRzIGV4dGVuc2lvbmxlc3MgRVNNIG91dCBvZiB2aXRlc3Qnc1xuLy8gc3RyaWN0IHJlc29sdmVyKS4gVGhlIGZ1bmN0aW9ucyB1bmRlciB0ZXN0IG5ldmVyIHRvdWNoIGl0LlxudmkubW9jaygnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvZnMnLCAoKSA9PiAoe1xuICBzYW5kYm94RnM6ICgpID0+IG51bGwsXG4gIGZzQXZhaWxhYmxlOiAoKSA9PiBmYWxzZSxcbn0pKTtcblxuaW1wb3J0IHsgam9pbk1vdW50LCByZXNvbHZlV29ya2luZ1RyZWVSb290LCBpc1dyaXRhYmxlIH0gZnJvbSAnLi93b3JraW5nVHJlZSc7XG5cbmludGVyZmFjZSBTYW5kYm94TW91bnQge1xuICBwYXRoOiBzdHJpbmc7XG4gIHR5cGU6IHN0cmluZztcbiAgbW9kZT86ICdybycgfCAncncnO1xufVxuXG5kZXNjcmliZSgnam9pbk1vdW50JywgKCkgPT4ge1xuICBpdCgnam9pbnMgYSBtb3VudCByb290IHdpdGggYSByZXBvLXJlbGF0aXZlIHBhdGgnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGpvaW5Nb3VudCgnL21udC9hYmMnLCAnL3NyYy9BcHAudHN4JykpLnRvQmUoJy9tbnQvYWJjL3NyYy9BcHAudHN4Jyk7XG4gICAgZXhwZWN0KGpvaW5Nb3VudCgnL21udC9hYmMvJywgJ3NyYy9BcHAudHN4JykpLnRvQmUoJy9tbnQvYWJjL3NyYy9BcHAudHN4Jyk7XG4gICAgZXhwZWN0KGpvaW5Nb3VudCgnL2FwcCcsICcvaW5kZXguaHRtbCcpKS50b0JlKCcvYXBwL2luZGV4Lmh0bWwnKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ3Jlc29sdmVXb3JraW5nVHJlZVJvb3QnLCAoKSA9PiB7XG4gIGl0KCdwcmVmZXJzIGFuIGV4cGxpY2l0IHJ3IHdvcmtpbmctdHJlZSBtb3VudCcsICgpID0+IHtcbiAgICBjb25zdCBtb3VudHM6IFNhbmRib3hNb3VudFtdID0gW3sgcGF0aDogJy9tbnQvd3QnLCB0eXBlOiAnd29ya3RyZWUnLCBtb2RlOiAncncnIH1dO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2luZ1RyZWVSb290KG1vdW50cywgJy9hcHAnKSkudG9CZSgnL21udC93dCcpO1xuICB9KTtcblxuICBpdCgnc2VsZWN0cyB0aGUgd29ya3RyZWUgcG9ydCBieSBpZGVudGl0eSBldmVuIHdoZW4gaXQgaXMgcmVhZC1vbmx5JywgKCkgPT4ge1xuICAgIC8vIFJlZ3Jlc3Npb246IGEgbG9jYWwvemlwL3NwYWNlIHN0YWdlIGFwcCBleHBvc2VzIGl0cyB3b3JrdHJlZSBgcm9gICh0aGUgc291cmNlXG4gICAgLy8gbW9kZSBjbGFtcHMgdGhlIGJpbmRpbmcncyBgcndgKSwgd2hpbGUgdGhlIGVkaXRvcidzIE9XTiByZXBvIGlzIGR1YWwtbW91bnRlZFxuICAgIC8vIGByd2AgYXQgYC9tbnQve2hhc2h9YC4gU2VsZWN0aW5nIGJ5IGBtb2RlID09PSAncncnYCBza2lwcGVkIHRoZSBgcm9gIHdvcmt0cmVlXG4gICAgLy8gYW5kIGZlbGwgYmFjayB0byB0aGUgYXBwJ3Mgb3duIHJlcG8sIHNvIHRoZSBlZGl0b3IgcmVhZC9lZGl0ZWQgSVRTRUxGLlxuICAgIGNvbnN0IG1vdW50czogU2FuZGJveE1vdW50W10gPSBbXG4gICAgICB7IHBhdGg6ICcvbW50L293bicsIHR5cGU6ICdyZXBvJywgbW9kZTogJ3J3JyB9LFxuICAgICAgeyBwYXRoOiAnL21udC93dCcsIHR5cGU6ICd3b3JrdHJlZScsIG1vZGU6ICdybycgfSxcbiAgICBdO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2luZ1RyZWVSb290KG1vdW50cywgJy9tbnQvb3duJykpLnRvQmUoJy9tbnQvd3QnKTtcbiAgfSk7XG5cbiAgaXQoJ2ZhbGxzIGJhY2sgdG8gdGhlIGFwcCBtb3VudCBwYXRoIHdoZW4gdGhlcmUgaXMgbm8gd29ya3RyZWUgb3IgcncgbW91bnQnLCAoKSA9PiB7XG4gICAgZXhwZWN0KHJlc29sdmVXb3JraW5nVHJlZVJvb3QoW10sICcvYXBwJykpLnRvQmUoJy9hcHAnKTtcbiAgICBjb25zdCBybzogU2FuZGJveE1vdW50W10gPSBbeyBwYXRoOiAnL3NwYWNlcy94JywgdHlwZTogJ2ZpcmVzdG9yZScsIG1vZGU6ICdybycgfV07XG4gICAgZXhwZWN0KHJlc29sdmVXb3JraW5nVHJlZVJvb3Qocm8sICcvYXBwJykpLnRvQmUoJy9hcHAnKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoJ2lzV3JpdGFibGUnLCAoKSA9PiB7XG4gIGl0KCdpcyB3cml0YWJsZSBieSBkZWZhdWx0ICh0aGUgcmVwbyBtb3VudCBoYXMgbm8gbW9kZSknLCAoKSA9PiB7XG4gICAgZXhwZWN0KGlzV3JpdGFibGUoW10pKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChpc1dyaXRhYmxlKFt7IHBhdGg6ICcvYXBwJywgdHlwZTogJ3JlcG8nIH1dKSkudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoJ2lzIHJlYWQtb25seSB3aGVuIHRoZSBvbmx5IG1vdW50IGlzIHJvJywgKCkgPT4ge1xuICAgIGV4cGVjdChpc1dyaXRhYmxlKFt7IHBhdGg6ICcvc3BhY2VzL3gnLCB0eXBlOiAnZmlyZXN0b3JlJywgbW9kZTogJ3JvJyB9XSkpLnRvQmUoZmFsc2UpO1xuICB9KTtcblxuICBpdCgnaXMgd3JpdGFibGUgd2hlbiBhbiBydyBtb3VudCBpcyBwcmVzZW50IGFsb25nc2lkZSBhbiBybyBvbmUnLCAoKSA9PiB7XG4gICAgZXhwZWN0KFxuICAgICAgaXNXcml0YWJsZShbXG4gICAgICAgIHsgcGF0aDogJy9zcGFjZXMveCcsIHR5cGU6ICdmaXJlc3RvcmUnLCBtb2RlOiAncm8nIH0sXG4gICAgICAgIHsgcGF0aDogJy9tbnQvd3QnLCB0eXBlOiAnd29ya3RyZWUnLCBtb2RlOiAncncnIH0sXG4gICAgICBdKSxcbiAgICApLnRvQmUodHJ1ZSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBaUJBLElBQUFDLFlBQUEsR0FBQUQsT0FBQTtBQWZBO0FBQ0E7QUFDQTtBQUNBRSxVQUFFLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxPQUFPO0VBQ3JDQyxTQUFTLEVBQUVBLENBQUEsS0FBTSxFQUFFO0VBQ25CQyxlQUFlLEVBQUVBLENBQUEsS0FBTTtBQUN6QixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0E7QUFDQTtBQUNBSCxVQUFFLENBQUNDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxPQUFPO0VBQ3hDRyxTQUFTLEVBQUVBLENBQUEsS0FBTSxJQUFJO0VBQ3JCQyxXQUFXLEVBQUVBLENBQUEsS0FBTTtBQUNyQixDQUFDLENBQUMsQ0FBQztBQVVILElBQUFDLGdCQUFRLEVBQUMsV0FBVyxFQUFFLE1BQU07RUFDMUIsSUFBQUMsVUFBRSxFQUFDLDhDQUE4QyxFQUFFLE1BQU07SUFDdkQsSUFBQUMsY0FBTSxFQUFDLElBQUFDLHNCQUFTLEVBQUMsVUFBVSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztJQUMxRSxJQUFBRixjQUFNLEVBQUMsSUFBQUMsc0JBQVMsRUFBQyxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQzFFLElBQUFGLGNBQU0sRUFBQyxJQUFBQyxzQkFBUyxFQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7RUFDbEUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQUosZ0JBQVEsRUFBQyx3QkFBd0IsRUFBRSxNQUFNO0VBQ3ZDLElBQUFDLFVBQUUsRUFBQywyQ0FBMkMsRUFBRSxNQUFNO0lBQ3BELE1BQU1JLE1BQXNCLEdBQUcsQ0FBQztNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFQyxJQUFJLEVBQUUsVUFBVTtNQUFFQyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDbEYsSUFBQU4sY0FBTSxFQUFDLElBQUFPLG1DQUFzQixFQUFDSixNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNoRSxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsaUVBQWlFLEVBQUUsTUFBTTtJQUMxRTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1JLE1BQXNCLEdBQUcsQ0FDN0I7TUFBRUMsSUFBSSxFQUFFLFVBQVU7TUFBRUMsSUFBSSxFQUFFLE1BQU07TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxFQUM5QztNQUFFRixJQUFJLEVBQUUsU0FBUztNQUFFQyxJQUFJLEVBQUUsVUFBVTtNQUFFQyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQ2xEO0lBQ0QsSUFBQU4sY0FBTSxFQUFDLElBQUFPLG1DQUFzQixFQUFDSixNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNwRSxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsd0VBQXdFLEVBQUUsTUFBTTtJQUNqRixJQUFBQyxjQUFNLEVBQUMsSUFBQU8sbUNBQXNCLEVBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUNMLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDdkQsTUFBTU0sRUFBa0IsR0FBRyxDQUFDO01BQUVKLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNqRixJQUFBTixjQUFNLEVBQUMsSUFBQU8sbUNBQXNCLEVBQUNDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDTixJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3pELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFKLGdCQUFRLEVBQUMsWUFBWSxFQUFFLE1BQU07RUFDM0IsSUFBQUMsVUFBRSxFQUFDLHFEQUFxRCxFQUFFLE1BQU07SUFDOUQsSUFBQUMsY0FBTSxFQUFDLElBQUFTLHVCQUFVLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNqQyxJQUFBRixjQUFNLEVBQUMsSUFBQVMsdUJBQVUsRUFBQyxDQUFDO01BQUVMLElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNqRSxDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsd0NBQXdDLEVBQUUsTUFBTTtJQUNqRCxJQUFBQyxjQUFNLEVBQUMsSUFBQVMsdUJBQVUsRUFBQyxDQUFDO01BQUVMLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0osSUFBSSxDQUFDLEtBQUssQ0FBQztFQUN4RixDQUFDLENBQUM7RUFFRixJQUFBSCxVQUFFLEVBQUMsNkRBQTZELEVBQUUsTUFBTTtJQUN0RSxJQUFBQyxjQUFNLEVBQ0osSUFBQVMsdUJBQVUsRUFBQyxDQUNUO01BQUVMLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsRUFDcEQ7TUFBRUYsSUFBSSxFQUFFLFNBQVM7TUFBRUMsSUFBSSxFQUFFLFVBQVU7TUFBRUMsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUNsRCxDQUNILENBQUMsQ0FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQztFQUNkLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==