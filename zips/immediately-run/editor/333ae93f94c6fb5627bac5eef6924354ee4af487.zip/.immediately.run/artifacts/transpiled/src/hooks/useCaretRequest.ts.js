"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useCaretRequest = useCaretRequest;
var _react = require("react");
var _sandboxUtils = require("@immediately-run/sdk/sandboxUtils");
var _ready = require("@immediately-run/sdk/ready");
// R3-388 — the host's one-shot "put the caret here" message.
//
// Not a channel field. The editor-context payload is de-duped at the source by value
// equality, so a `selection` carried there would mean a SECOND click on the same
// diagnostic pushes nothing and the affordance is dead on reuse. The host therefore
// sends a discrete message, exactly as it sends `viewed-reveal` to the file explorer,
// and the `nonce` is what makes a repeat distinguishable.
//
// Read through the generic `addListener` rather than a typed SDK export, matching how
// the explorer consumes `viewed-reveal`. That is also why this needs no SDK version
// floor: the message is not part of the SDK's surface.

/** Validate defensively: this arrives over a host message, and a consumer should
 *  never have to re-check what a hook handed it. Anything malformed is ignored
 *  outright rather than partially applied — a caret in the wrong place is worse than
 *  a caret that did not move. */
const parse = m => {
  if (typeof m.path !== "string" || !m.path) return null;
  if (typeof m.line !== "number" || !Number.isFinite(m.line) || m.line < 1) return null;
  if (typeof m.nonce !== "number" || !Number.isFinite(m.nonce)) return null;
  const column = typeof m.column === "number" && Number.isFinite(m.column) && m.column >= 1 ? m.column : undefined;
  return {
    path: m.path,
    line: m.line,
    nonce: m.nonce,
    ...(column !== undefined ? {
      column
    } : {})
  };
};
function useCaretRequest() {
  const [request, setRequest] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let dispose;
    try {
      dispose = (0, _sandboxUtils.addListener)("editor-selection", m => {
        const parsed = parse(m);
        if (parsed) setRequest(parsed);
      });
      // The host holds a caret request issued while this frame was still booting and
      // releases it on the app's readiness report — `ir.interactive` fires at the SDK
      // root's first commit, well before this listener exists, and a one-shot sent
      // then is simply lost (TOOLS_ACTIVITY_SPEC §8.2). Report only once the
      // listener is live, so "ready" means "listening".
      (0, _ready.reportReady)();
    } catch {
      // No host transport — a standalone `vite dev` render. The editor still works;
      // nothing sends caret requests.
    }
    return () => dispose?.();
  }, []);
  return request;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NhbmRib3hVdGlscyIsIl9yZWFkeSIsInBhcnNlIiwibSIsInBhdGgiLCJsaW5lIiwiTnVtYmVyIiwiaXNGaW5pdGUiLCJub25jZSIsImNvbHVtbiIsInVuZGVmaW5lZCIsInVzZUNhcmV0UmVxdWVzdCIsInJlcXVlc3QiLCJzZXRSZXF1ZXN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJkaXNwb3NlIiwiYWRkTGlzdGVuZXIiLCJwYXJzZWQiLCJyZXBvcnRSZWFkeSJdLCJzb3VyY2VzIjpbInVzZUNhcmV0UmVxdWVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy0zODgg4oCUIHRoZSBob3N0J3Mgb25lLXNob3QgXCJwdXQgdGhlIGNhcmV0IGhlcmVcIiBtZXNzYWdlLlxuLy9cbi8vIE5vdCBhIGNoYW5uZWwgZmllbGQuIFRoZSBlZGl0b3ItY29udGV4dCBwYXlsb2FkIGlzIGRlLWR1cGVkIGF0IHRoZSBzb3VyY2UgYnkgdmFsdWVcbi8vIGVxdWFsaXR5LCBzbyBhIGBzZWxlY3Rpb25gIGNhcnJpZWQgdGhlcmUgd291bGQgbWVhbiBhIFNFQ09ORCBjbGljayBvbiB0aGUgc2FtZVxuLy8gZGlhZ25vc3RpYyBwdXNoZXMgbm90aGluZyBhbmQgdGhlIGFmZm9yZGFuY2UgaXMgZGVhZCBvbiByZXVzZS4gVGhlIGhvc3QgdGhlcmVmb3JlXG4vLyBzZW5kcyBhIGRpc2NyZXRlIG1lc3NhZ2UsIGV4YWN0bHkgYXMgaXQgc2VuZHMgYHZpZXdlZC1yZXZlYWxgIHRvIHRoZSBmaWxlIGV4cGxvcmVyLFxuLy8gYW5kIHRoZSBgbm9uY2VgIGlzIHdoYXQgbWFrZXMgYSByZXBlYXQgZGlzdGluZ3Vpc2hhYmxlLlxuLy9cbi8vIFJlYWQgdGhyb3VnaCB0aGUgZ2VuZXJpYyBgYWRkTGlzdGVuZXJgIHJhdGhlciB0aGFuIGEgdHlwZWQgU0RLIGV4cG9ydCwgbWF0Y2hpbmcgaG93XG4vLyB0aGUgZXhwbG9yZXIgY29uc3VtZXMgYHZpZXdlZC1yZXZlYWxgLiBUaGF0IGlzIGFsc28gd2h5IHRoaXMgbmVlZHMgbm8gU0RLIHZlcnNpb25cbi8vIGZsb29yOiB0aGUgbWVzc2FnZSBpcyBub3QgcGFydCBvZiB0aGUgU0RLJ3Mgc3VyZmFjZS5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGFkZExpc3RlbmVyIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL3NhbmRib3hVdGlsc1wiO1xuaW1wb3J0IHsgcmVwb3J0UmVhZHkgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvcmVhZHlcIjtcblxuZXhwb3J0IGludGVyZmFjZSBDYXJldFJlcXVlc3Qge1xuICBwYXRoOiBzdHJpbmc7XG4gIGxpbmU6IG51bWJlcjtcbiAgY29sdW1uPzogbnVtYmVyO1xuICBub25jZTogbnVtYmVyO1xufVxuXG4vKiogVmFsaWRhdGUgZGVmZW5zaXZlbHk6IHRoaXMgYXJyaXZlcyBvdmVyIGEgaG9zdCBtZXNzYWdlLCBhbmQgYSBjb25zdW1lciBzaG91bGRcbiAqICBuZXZlciBoYXZlIHRvIHJlLWNoZWNrIHdoYXQgYSBob29rIGhhbmRlZCBpdC4gQW55dGhpbmcgbWFsZm9ybWVkIGlzIGlnbm9yZWRcbiAqICBvdXRyaWdodCByYXRoZXIgdGhhbiBwYXJ0aWFsbHkgYXBwbGllZCDigJQgYSBjYXJldCBpbiB0aGUgd3JvbmcgcGxhY2UgaXMgd29yc2UgdGhhblxuICogIGEgY2FyZXQgdGhhdCBkaWQgbm90IG1vdmUuICovXG5jb25zdCBwYXJzZSA9IChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IENhcmV0UmVxdWVzdCB8IG51bGwgPT4ge1xuICBpZiAodHlwZW9mIG0ucGF0aCAhPT0gXCJzdHJpbmdcIiB8fCAhbS5wYXRoKSByZXR1cm4gbnVsbDtcbiAgaWYgKHR5cGVvZiBtLmxpbmUgIT09IFwibnVtYmVyXCIgfHwgIU51bWJlci5pc0Zpbml0ZShtLmxpbmUpIHx8IG0ubGluZSA8IDEpXG4gICAgcmV0dXJuIG51bGw7XG4gIGlmICh0eXBlb2YgbS5ub25jZSAhPT0gXCJudW1iZXJcIiB8fCAhTnVtYmVyLmlzRmluaXRlKG0ubm9uY2UpKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgY29sdW1uID1cbiAgICB0eXBlb2YgbS5jb2x1bW4gPT09IFwibnVtYmVyXCIgJiYgTnVtYmVyLmlzRmluaXRlKG0uY29sdW1uKSAmJiBtLmNvbHVtbiA+PSAxXG4gICAgICA/IG0uY29sdW1uXG4gICAgICA6IHVuZGVmaW5lZDtcbiAgcmV0dXJuIHtcbiAgICBwYXRoOiBtLnBhdGgsXG4gICAgbGluZTogbS5saW5lLFxuICAgIG5vbmNlOiBtLm5vbmNlLFxuICAgIC4uLihjb2x1bW4gIT09IHVuZGVmaW5lZCA/IHsgY29sdW1uIH0gOiB7fSksXG4gIH07XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2FyZXRSZXF1ZXN0KCk6IENhcmV0UmVxdWVzdCB8IG51bGwge1xuICBjb25zdCBbcmVxdWVzdCwgc2V0UmVxdWVzdF0gPSB1c2VTdGF0ZTxDYXJldFJlcXVlc3QgfCBudWxsPihudWxsKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgZGlzcG9zZTogKCgpID0+IHZvaWQpIHwgdW5kZWZpbmVkO1xuICAgIHRyeSB7XG4gICAgICBkaXNwb3NlID0gYWRkTGlzdGVuZXIoXG4gICAgICAgIFwiZWRpdG9yLXNlbGVjdGlvblwiLFxuICAgICAgICAobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pID0+IHtcbiAgICAgICAgICBjb25zdCBwYXJzZWQgPSBwYXJzZShtKTtcbiAgICAgICAgICBpZiAocGFyc2VkKSBzZXRSZXF1ZXN0KHBhcnNlZCk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgICAgLy8gVGhlIGhvc3QgaG9sZHMgYSBjYXJldCByZXF1ZXN0IGlzc3VlZCB3aGlsZSB0aGlzIGZyYW1lIHdhcyBzdGlsbCBib290aW5nIGFuZFxuICAgICAgLy8gcmVsZWFzZXMgaXQgb24gdGhlIGFwcCdzIHJlYWRpbmVzcyByZXBvcnQg4oCUIGBpci5pbnRlcmFjdGl2ZWAgZmlyZXMgYXQgdGhlIFNES1xuICAgICAgLy8gcm9vdCdzIGZpcnN0IGNvbW1pdCwgd2VsbCBiZWZvcmUgdGhpcyBsaXN0ZW5lciBleGlzdHMsIGFuZCBhIG9uZS1zaG90IHNlbnRcbiAgICAgIC8vIHRoZW4gaXMgc2ltcGx5IGxvc3QgKFRPT0xTX0FDVElWSVRZX1NQRUMgwqc4LjIpLiBSZXBvcnQgb25seSBvbmNlIHRoZVxuICAgICAgLy8gbGlzdGVuZXIgaXMgbGl2ZSwgc28gXCJyZWFkeVwiIG1lYW5zIFwibGlzdGVuaW5nXCIuXG4gICAgICByZXBvcnRSZWFkeSgpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gTm8gaG9zdCB0cmFuc3BvcnQg4oCUIGEgc3RhbmRhbG9uZSBgdml0ZSBkZXZgIHJlbmRlci4gVGhlIGVkaXRvciBzdGlsbCB3b3JrcztcbiAgICAgIC8vIG5vdGhpbmcgc2VuZHMgY2FyZXQgcmVxdWVzdHMuXG4gICAgfVxuICAgIHJldHVybiAoKSA9PiBkaXNwb3NlPy4oKTtcbiAgfSwgW10pO1xuICByZXR1cm4gcmVxdWVzdDtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBV0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFZQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1HLEtBQUssR0FBSUMsQ0FBMEIsSUFBMEI7RUFDakUsSUFBSSxPQUFPQSxDQUFDLENBQUNDLElBQUksS0FBSyxRQUFRLElBQUksQ0FBQ0QsQ0FBQyxDQUFDQyxJQUFJLEVBQUUsT0FBTyxJQUFJO0VBQ3RELElBQUksT0FBT0QsQ0FBQyxDQUFDRSxJQUFJLEtBQUssUUFBUSxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDSixDQUFDLENBQUNFLElBQUksQ0FBQyxJQUFJRixDQUFDLENBQUNFLElBQUksR0FBRyxDQUFDLEVBQ3RFLE9BQU8sSUFBSTtFQUNiLElBQUksT0FBT0YsQ0FBQyxDQUFDSyxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUNGLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDSixDQUFDLENBQUNLLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUN6RSxNQUFNQyxNQUFNLEdBQ1YsT0FBT04sQ0FBQyxDQUFDTSxNQUFNLEtBQUssUUFBUSxJQUFJSCxNQUFNLENBQUNDLFFBQVEsQ0FBQ0osQ0FBQyxDQUFDTSxNQUFNLENBQUMsSUFBSU4sQ0FBQyxDQUFDTSxNQUFNLElBQUksQ0FBQyxHQUN0RU4sQ0FBQyxDQUFDTSxNQUFNLEdBQ1JDLFNBQVM7RUFDZixPQUFPO0lBQ0xOLElBQUksRUFBRUQsQ0FBQyxDQUFDQyxJQUFJO0lBQ1pDLElBQUksRUFBRUYsQ0FBQyxDQUFDRSxJQUFJO0lBQ1pHLEtBQUssRUFBRUwsQ0FBQyxDQUFDSyxLQUFLO0lBQ2QsSUFBSUMsTUFBTSxLQUFLQyxTQUFTLEdBQUc7TUFBRUQ7SUFBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQzVDLENBQUM7QUFDSCxDQUFDO0FBRU0sU0FBU0UsZUFBZUEsQ0FBQSxFQUF3QjtFQUNyRCxNQUFNLENBQUNDLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFzQixJQUFJLENBQUM7RUFDakUsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUMsT0FBaUM7SUFDckMsSUFBSTtNQUNGQSxPQUFPLEdBQUcsSUFBQUMseUJBQVcsRUFDbkIsa0JBQWtCLEVBQ2pCZCxDQUEwQixJQUFLO1FBQzlCLE1BQU1lLE1BQU0sR0FBR2hCLEtBQUssQ0FBQ0MsQ0FBQyxDQUFDO1FBQ3ZCLElBQUllLE1BQU0sRUFBRUwsVUFBVSxDQUFDSyxNQUFNLENBQUM7TUFDaEMsQ0FDRixDQUFDO01BQ0Q7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUFDLGtCQUFXLEVBQUMsQ0FBQztJQUNmLENBQUMsQ0FBQyxNQUFNO01BQ047TUFDQTtJQUFBO0lBRUYsT0FBTyxNQUFNSCxPQUFPLEdBQUcsQ0FBQztFQUMxQixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQ04sT0FBT0osT0FBTztBQUNoQiIsImlnbm9yZUxpc3QiOltdfQ==