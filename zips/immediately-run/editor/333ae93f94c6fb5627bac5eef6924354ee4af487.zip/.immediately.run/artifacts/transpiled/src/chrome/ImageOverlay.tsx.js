var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ImageOverlay = ImageOverlay;
exports.default = void 0;
var _react = require("react");
var _baseName = require("../core/baseName");
var _Placeholder = require("./Placeholder");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // R3-804 — the image surface that covers (never replaces) the mounted
// CodeMirror view while the active file is a recognised image. Rendered inside
// `.ed-body`, absolutely positioned over `.cm-host`; file selection in the
// explorer is the only dismiss (R-IX-1: it opens where the user is looking —
// the pane they just clicked into — and never takes focus). The covered editor
// is `inert`/`aria-hidden` upstream (App.tsx), so keyboard and screen-reader
// users cannot land in a hidden document (WCAG 2.1.1 / 2.4.3).
//
// Every state rides `Placeholder`'s anatomy (one spelling, R6) inside a live
// region: loading and ready announce through `role="status"`, a failed read
// through `role="alert"` (matching App's save-error surface) — the settle is
// announced, not only painted (R-IX-7 / WCAG 4.1.3) — and a failure always
// names the path (R3).
function ImageOverlay({
  preview
}) {
  if (preview.state === 'loading') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ed-image-overlay",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "awaiting-port",
        title: `Loading ${(0, _baseName.baseName)(preview.path)}…`,
        hint: ""
      })
    });
  }
  if (preview.state === 'error') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ed-image-overlay",
      role: "alert",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "error",
        detail: `${preview.path} — ${preview.message}`
      })
    });
  }
  if (preview.state === 'vanished') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ed-image-overlay",
      role: "status",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.Placeholder, {
        kind: "vanished",
        hint: "The image was deleted or renamed elsewhere.",
        detail: preview.path
      })
    });
  }
  if (preview.state !== 'ready') return null;
  // Keyed by url: a re-read (an external write to the shown image) swaps the
  // object URL and ReadyImage remounts, so its dimensions never describe a
  // stale image.
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(ReadyImage, {
    path: preview.path,
    url: preview.url
  }, preview.url);
}
_c = ImageOverlay;
function ReadyImage({
  path,
  url
}) {
  _s();
  const [dims, setDims] = (0, _react.useState)(null);
  const name = (0, _baseName.baseName)(path);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ed-image-overlay",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
      className: "ed-image",
      src: url,
      alt: name,
      onLoad: e => {
        const img = e.currentTarget;
        setDims({
          w: img.naturalWidth,
          h: img.naturalHeight
        });
      }
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ed-image-caption",
      children: [name, dims ? ` · ${dims.w} × ${dims.h}` : '', " \xB7 read-only"]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ed-visually-hidden",
      role: "status",
      children: ["Showing image ", name]
    })]
  });
}
_s(ReadyImage, "ZcpDf3eaCw4dQID4jWpGuzR02X4=");
_c2 = ReadyImage;
var _default = exports.default = ImageOverlay;
var _c, _c2;
$RefreshReg$(_c, "ImageOverlay");
$RefreshReg$(_c2, "ReadyImage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2Jhc2VOYW1lIiwiX1BsYWNlaG9sZGVyIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkltYWdlT3ZlcmxheSIsInByZXZpZXciLCJzdGF0ZSIsImpzeCIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsIlBsYWNlaG9sZGVyIiwia2luZCIsInRpdGxlIiwiYmFzZU5hbWUiLCJwYXRoIiwiaGludCIsImRldGFpbCIsIm1lc3NhZ2UiLCJSZWFkeUltYWdlIiwidXJsIiwiX2MiLCJkaW1zIiwic2V0RGltcyIsInVzZVN0YXRlIiwibmFtZSIsImpzeHMiLCJzcmMiLCJhbHQiLCJvbkxvYWQiLCJlIiwiaW1nIiwiY3VycmVudFRhcmdldCIsInciLCJuYXR1cmFsV2lkdGgiLCJoIiwibmF0dXJhbEhlaWdodCIsIl9jMiIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbWFnZU92ZXJsYXkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFIzLTgwNCDigJQgdGhlIGltYWdlIHN1cmZhY2UgdGhhdCBjb3ZlcnMgKG5ldmVyIHJlcGxhY2VzKSB0aGUgbW91bnRlZFxuLy8gQ29kZU1pcnJvciB2aWV3IHdoaWxlIHRoZSBhY3RpdmUgZmlsZSBpcyBhIHJlY29nbmlzZWQgaW1hZ2UuIFJlbmRlcmVkIGluc2lkZVxuLy8gYC5lZC1ib2R5YCwgYWJzb2x1dGVseSBwb3NpdGlvbmVkIG92ZXIgYC5jbS1ob3N0YDsgZmlsZSBzZWxlY3Rpb24gaW4gdGhlXG4vLyBleHBsb3JlciBpcyB0aGUgb25seSBkaXNtaXNzIChSLUlYLTE6IGl0IG9wZW5zIHdoZXJlIHRoZSB1c2VyIGlzIGxvb2tpbmcg4oCUXG4vLyB0aGUgcGFuZSB0aGV5IGp1c3QgY2xpY2tlZCBpbnRvIOKAlCBhbmQgbmV2ZXIgdGFrZXMgZm9jdXMpLiBUaGUgY292ZXJlZCBlZGl0b3Jcbi8vIGlzIGBpbmVydGAvYGFyaWEtaGlkZGVuYCB1cHN0cmVhbSAoQXBwLnRzeCksIHNvIGtleWJvYXJkIGFuZCBzY3JlZW4tcmVhZGVyXG4vLyB1c2VycyBjYW5ub3QgbGFuZCBpbiBhIGhpZGRlbiBkb2N1bWVudCAoV0NBRyAyLjEuMSAvIDIuNC4zKS5cbi8vXG4vLyBFdmVyeSBzdGF0ZSByaWRlcyBgUGxhY2Vob2xkZXJgJ3MgYW5hdG9teSAob25lIHNwZWxsaW5nLCBSNikgaW5zaWRlIGEgbGl2ZVxuLy8gcmVnaW9uOiBsb2FkaW5nIGFuZCByZWFkeSBhbm5vdW5jZSB0aHJvdWdoIGByb2xlPVwic3RhdHVzXCJgLCBhIGZhaWxlZCByZWFkXG4vLyB0aHJvdWdoIGByb2xlPVwiYWxlcnRcImAgKG1hdGNoaW5nIEFwcCdzIHNhdmUtZXJyb3Igc3VyZmFjZSkg4oCUIHRoZSBzZXR0bGUgaXNcbi8vIGFubm91bmNlZCwgbm90IG9ubHkgcGFpbnRlZCAoUi1JWC03IC8gV0NBRyA0LjEuMykg4oCUIGFuZCBhIGZhaWx1cmUgYWx3YXlzXG4vLyBuYW1lcyB0aGUgcGF0aCAoUjMpLlxuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgSW1hZ2VQcmV2aWV3IH0gZnJvbSAnLi4vaG9va3MvdXNlSW1hZ2VQcmV2aWV3JztcbmltcG9ydCB7IGJhc2VOYW1lIH0gZnJvbSAnLi4vY29yZS9iYXNlTmFtZSc7XG5pbXBvcnQgeyBQbGFjZWhvbGRlciB9IGZyb20gJy4vUGxhY2Vob2xkZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gSW1hZ2VPdmVybGF5KHsgcHJldmlldyB9OiB7IHByZXZpZXc6IEltYWdlUHJldmlldyB9KSB7XG4gIGlmIChwcmV2aWV3LnN0YXRlID09PSAnbG9hZGluZycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJlZC1pbWFnZS1vdmVybGF5XCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICA8UGxhY2Vob2xkZXIga2luZD1cImF3YWl0aW5nLXBvcnRcIiB0aXRsZT17YExvYWRpbmcgJHtiYXNlTmFtZShwcmV2aWV3LnBhdGgpfeKApmB9IGhpbnQ9XCJcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuICBpZiAocHJldmlldy5zdGF0ZSA9PT0gJ2Vycm9yJykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImVkLWltYWdlLW92ZXJsYXlcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgPFBsYWNlaG9sZGVyXG4gICAgICAgICAga2luZD1cImVycm9yXCJcbiAgICAgICAgICBkZXRhaWw9e2Ake3ByZXZpZXcucGF0aH0g4oCUICR7cHJldmlldy5tZXNzYWdlfWB9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG4gIGlmIChwcmV2aWV3LnN0YXRlID09PSAndmFuaXNoZWQnKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWQtaW1hZ2Utb3ZlcmxheVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgPFBsYWNlaG9sZGVyXG4gICAgICAgICAga2luZD1cInZhbmlzaGVkXCJcbiAgICAgICAgICBoaW50PVwiVGhlIGltYWdlIHdhcyBkZWxldGVkIG9yIHJlbmFtZWQgZWxzZXdoZXJlLlwiXG4gICAgICAgICAgZGV0YWlsPXtwcmV2aWV3LnBhdGh9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG4gIGlmIChwcmV2aWV3LnN0YXRlICE9PSAncmVhZHknKSByZXR1cm4gbnVsbDtcbiAgLy8gS2V5ZWQgYnkgdXJsOiBhIHJlLXJlYWQgKGFuIGV4dGVybmFsIHdyaXRlIHRvIHRoZSBzaG93biBpbWFnZSkgc3dhcHMgdGhlXG4gIC8vIG9iamVjdCBVUkwgYW5kIFJlYWR5SW1hZ2UgcmVtb3VudHMsIHNvIGl0cyBkaW1lbnNpb25zIG5ldmVyIGRlc2NyaWJlIGFcbiAgLy8gc3RhbGUgaW1hZ2UuXG4gIHJldHVybiA8UmVhZHlJbWFnZSBrZXk9e3ByZXZpZXcudXJsfSBwYXRoPXtwcmV2aWV3LnBhdGh9IHVybD17cHJldmlldy51cmx9IC8+O1xufVxuXG5mdW5jdGlvbiBSZWFkeUltYWdlKHsgcGF0aCwgdXJsIH06IHsgcGF0aDogc3RyaW5nOyB1cmw6IHN0cmluZyB9KSB7XG4gIGNvbnN0IFtkaW1zLCBzZXREaW1zXSA9IHVzZVN0YXRlPHsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBuYW1lID0gYmFzZU5hbWUocGF0aCk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJlZC1pbWFnZS1vdmVybGF5XCI+XG4gICAgICA8aW1nXG4gICAgICAgIGNsYXNzTmFtZT1cImVkLWltYWdlXCJcbiAgICAgICAgc3JjPXt1cmx9XG4gICAgICAgIGFsdD17bmFtZX1cbiAgICAgICAgb25Mb2FkPXsoZSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGltZyA9IGUuY3VycmVudFRhcmdldDtcbiAgICAgICAgICBzZXREaW1zKHsgdzogaW1nLm5hdHVyYWxXaWR0aCwgaDogaW1nLm5hdHVyYWxIZWlnaHQgfSk7XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJlZC1pbWFnZS1jYXB0aW9uXCI+XG4gICAgICAgIHtuYW1lfVxuICAgICAgICB7ZGltcyA/IGAgwrcgJHtkaW1zLnd9IMOXICR7ZGltcy5ofWAgOiAnJ30gwrcgcmVhZC1vbmx5XG4gICAgICA8L2Rpdj5cbiAgICAgIHsvKiBSLUlYLTcg4oCUIHRoZSBzZXR0bGUgaXMgYW5ub3VuY2VkLCBub3Qgb25seSByZW5kZXJlZCAoV0NBRyA0LjEuMykuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJlZC12aXN1YWxseS1oaWRkZW5cIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgIFNob3dpbmcgaW1hZ2Uge25hbWV9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgSW1hZ2VPdmVybGF5O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBY0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsU0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsWUFBQSxHQUFBRixPQUFBO0FBQTRDLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLElBQUFJLEVBQUEsR0FBQUMsWUFBQSxJQWpCNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPTyxTQUFTQyxZQUFZQSxDQUFDO0VBQUVDO0FBQW1DLENBQUMsRUFBRTtFQUNuRSxJQUFJQSxPQUFPLENBQUNDLEtBQUssS0FBSyxTQUFTLEVBQUU7SUFDL0Isb0JBQ0UsSUFBQUwsV0FBQSxDQUFBTSxHQUFBO01BQUtDLFNBQVMsRUFBQyxrQkFBa0I7TUFBQ0MsSUFBSSxFQUFDLFFBQVE7TUFBQUMsUUFBQSxlQUM3QyxJQUFBVCxXQUFBLENBQUFNLEdBQUEsRUFBQ1AsWUFBQSxDQUFBVyxXQUFXO1FBQUNDLElBQUksRUFBQyxlQUFlO1FBQUNDLEtBQUssRUFBRSxXQUFXLElBQUFDLGtCQUFRLEVBQUNULE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLEdBQUk7UUFBQ0MsSUFBSSxFQUFDO01BQUUsQ0FBRTtJQUFDLENBQ3RGLENBQUM7RUFFVjtFQUNBLElBQUlYLE9BQU8sQ0FBQ0MsS0FBSyxLQUFLLE9BQU8sRUFBRTtJQUM3QixvQkFDRSxJQUFBTCxXQUFBLENBQUFNLEdBQUE7TUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtNQUFDQyxJQUFJLEVBQUMsT0FBTztNQUFBQyxRQUFBLGVBQzVDLElBQUFULFdBQUEsQ0FBQU0sR0FBQSxFQUFDUCxZQUFBLENBQUFXLFdBQVc7UUFDVkMsSUFBSSxFQUFDLE9BQU87UUFDWkssTUFBTSxFQUFFLEdBQUdaLE9BQU8sQ0FBQ1UsSUFBSSxNQUFNVixPQUFPLENBQUNhLE9BQU87TUFBRyxDQUNoRDtJQUFDLENBQ0MsQ0FBQztFQUVWO0VBQ0EsSUFBSWIsT0FBTyxDQUFDQyxLQUFLLEtBQUssVUFBVSxFQUFFO0lBQ2hDLG9CQUNFLElBQUFMLFdBQUEsQ0FBQU0sR0FBQTtNQUFLQyxTQUFTLEVBQUMsa0JBQWtCO01BQUNDLElBQUksRUFBQyxRQUFRO01BQUFDLFFBQUEsZUFDN0MsSUFBQVQsV0FBQSxDQUFBTSxHQUFBLEVBQUNQLFlBQUEsQ0FBQVcsV0FBVztRQUNWQyxJQUFJLEVBQUMsVUFBVTtRQUNmSSxJQUFJLEVBQUMsNkNBQTZDO1FBQ2xEQyxNQUFNLEVBQUVaLE9BQU8sQ0FBQ1U7TUFBSyxDQUN0QjtJQUFDLENBQ0MsQ0FBQztFQUVWO0VBQ0EsSUFBSVYsT0FBTyxDQUFDQyxLQUFLLEtBQUssT0FBTyxFQUFFLE9BQU8sSUFBSTtFQUMxQztFQUNBO0VBQ0E7RUFDQSxvQkFBTyxJQUFBTCxXQUFBLENBQUFNLEdBQUEsRUFBQ1ksVUFBVTtJQUFtQkosSUFBSSxFQUFFVixPQUFPLENBQUNVLElBQUs7SUFBQ0ssR0FBRyxFQUFFZixPQUFPLENBQUNlO0VBQUksR0FBbERmLE9BQU8sQ0FBQ2UsR0FBNEMsQ0FBQztBQUMvRTtBQUFDQyxFQUFBLEdBbENlakIsWUFBWTtBQW9DNUIsU0FBU2UsVUFBVUEsQ0FBQztFQUFFSixJQUFJO0VBQUVLO0FBQW1DLENBQUMsRUFBRTtFQUFBbEIsRUFBQTtFQUNoRSxNQUFNLENBQUNvQixJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBa0MsSUFBSSxDQUFDO0VBQ3ZFLE1BQU1DLElBQUksR0FBRyxJQUFBWCxrQkFBUSxFQUFDQyxJQUFJLENBQUM7RUFDM0Isb0JBQ0UsSUFBQWQsV0FBQSxDQUFBeUIsSUFBQTtJQUFLbEIsU0FBUyxFQUFDLGtCQUFrQjtJQUFBRSxRQUFBLGdCQUMvQixJQUFBVCxXQUFBLENBQUFNLEdBQUE7TUFDRUMsU0FBUyxFQUFDLFVBQVU7TUFDcEJtQixHQUFHLEVBQUVQLEdBQUk7TUFDVFEsR0FBRyxFQUFFSCxJQUFLO01BQ1ZJLE1BQU0sRUFBR0MsQ0FBQyxJQUFLO1FBQ2IsTUFBTUMsR0FBRyxHQUFHRCxDQUFDLENBQUNFLGFBQWE7UUFDM0JULE9BQU8sQ0FBQztVQUFFVSxDQUFDLEVBQUVGLEdBQUcsQ0FBQ0csWUFBWTtVQUFFQyxDQUFDLEVBQUVKLEdBQUcsQ0FBQ0s7UUFBYyxDQUFDLENBQUM7TUFDeEQ7SUFBRSxDQUNILENBQUMsZUFDRixJQUFBbkMsV0FBQSxDQUFBeUIsSUFBQTtNQUFLbEIsU0FBUyxFQUFDLGtCQUFrQjtNQUFBRSxRQUFBLEdBQzlCZSxJQUFJLEVBQ0pILElBQUksR0FBRyxNQUFNQSxJQUFJLENBQUNXLENBQUMsTUFBTVgsSUFBSSxDQUFDYSxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUMsaUJBQzFDO0lBQUEsQ0FBSyxDQUFDLGVBRU4sSUFBQWxDLFdBQUEsQ0FBQXlCLElBQUE7TUFBS2xCLFNBQVMsRUFBQyxvQkFBb0I7TUFBQ0MsSUFBSSxFQUFDLFFBQVE7TUFBQUMsUUFBQSxHQUFDLGdCQUNsQyxFQUFDZSxJQUFJO0lBQUEsQ0FDaEIsQ0FBQztFQUFBLENBQ0gsQ0FBQztBQUVWO0FBQUN2QixFQUFBLENBeEJRaUIsVUFBVTtBQUFBa0IsR0FBQSxHQUFWbEIsVUFBVTtBQUFBLElBQUFtQixRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQTBCSnBDLFlBQVk7QUFBQSxJQUFBaUIsRUFBQSxFQUFBZ0IsR0FBQTtBQUFBSSxZQUFBLENBQUFwQixFQUFBO0FBQUFvQixZQUFBLENBQUFKLEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}