"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.applyEdit = applyEdit;
exports.applyExternalChange = applyExternalChange;
exports.applyExternalDelete = applyExternalDelete;
exports.applyOwnWriteEcho = applyOwnWriteEcho;
exports.canSave = canSave;
exports.isDirty = isDirty;
exports.markSaved = markSaved;
exports.openBuffer = openBuffer;
exports.resolveKeepMine = resolveKeepMine;
exports.resolveTakeTheirs = resolveTakeTheirs;
// The per-file editor buffer state machine — the security-critical core of the
// editor app (EDITOR_AS_APP_SPEC §6, plan Phase 04 step 4). Pure and exhaustively
// unit-tested; the React surface (CodeMirror, the working-tree port) only drives
// these transitions and renders the result.
//
// The editor anchors a *save to GitHub*. So the load-bearing invariant is: an
// external write to a file the user is editing must NEVER silently substitute
// bytes into the about-to-be-saved buffer. A dirty buffer that receives an
// external change enters a BLOCKING conflict and save is refused until the user
// resolves it; the user's keystrokes are never touched. (Spec §6 / threat M6.)

/** A file the editor has open. `baseline` is the working-tree content as the app
 *  last observed it (the bytes a save would currently be based on); `buffer` is
 *  what the user is editing. `dirty` ⟺ the two differ. */

/** Open `path` with freshly-read working-tree `content` (a clean buffer). */
function openBuffer(path, content) {
  return {
    path,
    baseline: content,
    buffer: content,
    conflict: null,
    vanished: false
  };
}

/** True ⟺ the buffer differs from the working-tree baseline (unsaved edits). */
function isDirty(b) {
  return b.buffer !== b.baseline;
}

/**
 * Whether a save (debounced write to the rw port) is currently permitted. Save is
 * BLOCKED while a conflict is unresolved or the file vanished — writing then would
 * either clobber an external change the user hasn't seen, or resurrect a deleted
 * file (spec §6 / §12.4). A clean buffer has nothing to save.
 */
function canSave(b) {
  return isDirty(b) && b.conflict === null && !b.vanished;
}

/** The user typed: replace the buffer. Never touches `baseline`/`conflict` — a
 *  conflict, once raised, stays until explicitly resolved. */
function applyEdit(b, next) {
  return {
    ...b,
    buffer: next
  };
}

/**
 * An external write to this file landed (delivered by the host's fs-change
 * fan-out; this app is origin-excluded from its own writes — Phase 01). Behaviour
 * per spec §6:
 *   - clean buffer  → adopt silently (re-read replaces the buffer).
 *   - dirty buffer  → do NOT modify the buffer; raise a blocking conflict.
 * A file that had vanished and is now re-created clears the vanished flag and is
 * treated as the external content arriving.
 */
function applyExternalChange(b, theirs) {
  if (isDirty(b) && !b.vanished) {
    // Dirty: keep the user's keystrokes untouched; surface the conflict. If the
    // incoming bytes equal what the user already typed, there is nothing to
    // resolve — just re-baseline (now clean).
    if (theirs === b.buffer) {
      return {
        ...b,
        baseline: theirs,
        conflict: null
      };
    }
    return {
      ...b,
      conflict: {
        theirs
      }
    };
  }
  // Clean (or previously vanished): adopt the new content as the new baseline.
  return {
    path: b.path,
    baseline: theirs,
    buffer: theirs,
    conflict: null,
    vanished: false
  };
}

/**
 * The working tree now holds bytes **this app wrote** — the echo of our own save
 * coming back on the fs-change stream. Re-baseline onto them; never a conflict.
 *
 * This is the editor's origin exclusion, and it is deliberately identity-based
 * ("are these the bytes I sent?") rather than the equality it used to rely on
 * ("does disk match my buffer?"). Buffer equality is not a sound test for "mine":
 * the user keeps typing while the write is in flight, so by the time the echo
 * lands the buffer has legitimately moved on and `applyExternalChange` sees a
 * divergence that has no external writer behind it — a blocking conflict raised
 * against nobody, on the second keystroke.
 *
 * The buffer is untouched, so if the user has typed on it stays dirty against the
 * new baseline and the next debounced write saves the rest.
 */
function applyOwnWriteEcho(b, ours) {
  // A vanished file is not resurrected by its own stale echo (§12.4), and a
  // conflict already raised is the user's to resolve — neither is ours to clear.
  if (b.vanished || b.conflict) return b;
  return {
    ...b,
    baseline: ours
  };
}

/** The active/open file was deleted or renamed externally (spec §12.4). Mark it
 *  vanished; the app shows a placeholder and must NOT write the path back (which
 *  would resurrect the file). The user's buffer is preserved in case they want to
 *  copy it out, but save stays blocked. */
function applyExternalDelete(b) {
  return {
    ...b,
    vanished: true,
    conflict: null
  };
}

/** Resolve a conflict by keeping the user's version. The external bytes become the
 *  new baseline (so the buffer is still dirty and a save will overwrite them with
 *  the user's content), and the block lifts. */
function resolveKeepMine(b) {
  if (!b.conflict) return b;
  return {
    ...b,
    baseline: b.conflict.theirs,
    conflict: null
  };
}

/** Resolve a conflict by taking the external version. The buffer is replaced with
 *  their bytes (the user's edits are discarded) and the buffer becomes clean. */
function resolveTakeTheirs(b) {
  if (!b.conflict) return b;
  const theirs = b.conflict.theirs;
  return {
    ...b,
    baseline: theirs,
    buffer: theirs,
    conflict: null
  };
}

/** A debounced write of the current buffer committed to the working tree: the
 *  buffer is now the baseline (clean). Only valid when {@link canSave} held. */
function markSaved(b) {
  return {
    ...b,
    baseline: b.buffer
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJvcGVuQnVmZmVyIiwicGF0aCIsImNvbnRlbnQiLCJiYXNlbGluZSIsImJ1ZmZlciIsImNvbmZsaWN0IiwidmFuaXNoZWQiLCJpc0RpcnR5IiwiYiIsImNhblNhdmUiLCJhcHBseUVkaXQiLCJuZXh0IiwiYXBwbHlFeHRlcm5hbENoYW5nZSIsInRoZWlycyIsImFwcGx5T3duV3JpdGVFY2hvIiwib3VycyIsImFwcGx5RXh0ZXJuYWxEZWxldGUiLCJyZXNvbHZlS2VlcE1pbmUiLCJyZXNvbHZlVGFrZVRoZWlycyIsIm1hcmtTYXZlZCJdLCJzb3VyY2VzIjpbImJ1ZmZlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgcGVyLWZpbGUgZWRpdG9yIGJ1ZmZlciBzdGF0ZSBtYWNoaW5lIOKAlCB0aGUgc2VjdXJpdHktY3JpdGljYWwgY29yZSBvZiB0aGVcbi8vIGVkaXRvciBhcHAgKEVESVRPUl9BU19BUFBfU1BFQyDCpzYsIHBsYW4gUGhhc2UgMDQgc3RlcCA0KS4gUHVyZSBhbmQgZXhoYXVzdGl2ZWx5XG4vLyB1bml0LXRlc3RlZDsgdGhlIFJlYWN0IHN1cmZhY2UgKENvZGVNaXJyb3IsIHRoZSB3b3JraW5nLXRyZWUgcG9ydCkgb25seSBkcml2ZXNcbi8vIHRoZXNlIHRyYW5zaXRpb25zIGFuZCByZW5kZXJzIHRoZSByZXN1bHQuXG4vL1xuLy8gVGhlIGVkaXRvciBhbmNob3JzIGEgKnNhdmUgdG8gR2l0SHViKi4gU28gdGhlIGxvYWQtYmVhcmluZyBpbnZhcmlhbnQgaXM6IGFuXG4vLyBleHRlcm5hbCB3cml0ZSB0byBhIGZpbGUgdGhlIHVzZXIgaXMgZWRpdGluZyBtdXN0IE5FVkVSIHNpbGVudGx5IHN1YnN0aXR1dGVcbi8vIGJ5dGVzIGludG8gdGhlIGFib3V0LXRvLWJlLXNhdmVkIGJ1ZmZlci4gQSBkaXJ0eSBidWZmZXIgdGhhdCByZWNlaXZlcyBhblxuLy8gZXh0ZXJuYWwgY2hhbmdlIGVudGVycyBhIEJMT0NLSU5HIGNvbmZsaWN0IGFuZCBzYXZlIGlzIHJlZnVzZWQgdW50aWwgdGhlIHVzZXJcbi8vIHJlc29sdmVzIGl0OyB0aGUgdXNlcidzIGtleXN0cm9rZXMgYXJlIG5ldmVyIHRvdWNoZWQuIChTcGVjIMKnNiAvIHRocmVhdCBNNi4pXG5cbi8qKiBBIGZpbGUgdGhlIGVkaXRvciBoYXMgb3Blbi4gYGJhc2VsaW5lYCBpcyB0aGUgd29ya2luZy10cmVlIGNvbnRlbnQgYXMgdGhlIGFwcFxuICogIGxhc3Qgb2JzZXJ2ZWQgaXQgKHRoZSBieXRlcyBhIHNhdmUgd291bGQgY3VycmVudGx5IGJlIGJhc2VkIG9uKTsgYGJ1ZmZlcmAgaXNcbiAqICB3aGF0IHRoZSB1c2VyIGlzIGVkaXRpbmcuIGBkaXJ0eWAg4p+6IHRoZSB0d28gZGlmZmVyLiAqL1xuZXhwb3J0IGludGVyZmFjZSBGaWxlQnVmZmVyIHtcbiAgcGF0aDogc3RyaW5nO1xuICAvKiogV29ya2luZy10cmVlIGNvbnRlbnQgYXMgbGFzdCByZWFkL3dyaXR0ZW4gYnkgdGhpcyBhcHAuICovXG4gIGJhc2VsaW5lOiBzdHJpbmc7XG4gIC8qKiBDdXJyZW50IGVkaXRvciBjb250ZW50ICh0aGUgdXNlcidzIGxpdmUga2V5c3Ryb2tlcykuICovXG4gIGJ1ZmZlcjogc3RyaW5nO1xuICAvKiogQSBwZW5kaW5nIGV4dGVybmFsIGNoYW5nZSB0byB0aGlzIGZpbGUgdGhhdCBhcnJpdmVkIHdoaWxlIHRoZSBidWZmZXIgd2FzXG4gICAqICBkaXJ0eSDigJQgdGhlIGJ5dGVzIGFub3RoZXIgd3JpdGVyIHB1dCBvbiBkaXNrLiBOb24tbnVsbCDin7ogYmxvY2tpbmcgY29uZmxpY3QuICovXG4gIGNvbmZsaWN0OiB7IHRoZWlyczogc3RyaW5nIH0gfCBudWxsO1xuICAvKiogVGhlIGZpbGUgd2FzIGRlbGV0ZWQvcmVuYW1lZCBvdXQgZnJvbSB1bmRlciB0aGUgb3BlbiBidWZmZXIgKHNwZWMgwqcxMi40KS4gKi9cbiAgdmFuaXNoZWQ6IGJvb2xlYW47XG59XG5cbi8qKiBPcGVuIGBwYXRoYCB3aXRoIGZyZXNobHktcmVhZCB3b3JraW5nLXRyZWUgYGNvbnRlbnRgIChhIGNsZWFuIGJ1ZmZlcikuICovXG5leHBvcnQgZnVuY3Rpb24gb3BlbkJ1ZmZlcihwYXRoOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZyk6IEZpbGVCdWZmZXIge1xuICByZXR1cm4geyBwYXRoLCBiYXNlbGluZTogY29udGVudCwgYnVmZmVyOiBjb250ZW50LCBjb25mbGljdDogbnVsbCwgdmFuaXNoZWQ6IGZhbHNlIH07XG59XG5cbi8qKiBUcnVlIOKfuiB0aGUgYnVmZmVyIGRpZmZlcnMgZnJvbSB0aGUgd29ya2luZy10cmVlIGJhc2VsaW5lICh1bnNhdmVkIGVkaXRzKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0RpcnR5KGI6IEZpbGVCdWZmZXIpOiBib29sZWFuIHtcbiAgcmV0dXJuIGIuYnVmZmVyICE9PSBiLmJhc2VsaW5lO1xufVxuXG4vKipcbiAqIFdoZXRoZXIgYSBzYXZlIChkZWJvdW5jZWQgd3JpdGUgdG8gdGhlIHJ3IHBvcnQpIGlzIGN1cnJlbnRseSBwZXJtaXR0ZWQuIFNhdmUgaXNcbiAqIEJMT0NLRUQgd2hpbGUgYSBjb25mbGljdCBpcyB1bnJlc29sdmVkIG9yIHRoZSBmaWxlIHZhbmlzaGVkIOKAlCB3cml0aW5nIHRoZW4gd291bGRcbiAqIGVpdGhlciBjbG9iYmVyIGFuIGV4dGVybmFsIGNoYW5nZSB0aGUgdXNlciBoYXNuJ3Qgc2Vlbiwgb3IgcmVzdXJyZWN0IGEgZGVsZXRlZFxuICogZmlsZSAoc3BlYyDCpzYgLyDCpzEyLjQpLiBBIGNsZWFuIGJ1ZmZlciBoYXMgbm90aGluZyB0byBzYXZlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2FuU2F2ZShiOiBGaWxlQnVmZmVyKTogYm9vbGVhbiB7XG4gIHJldHVybiBpc0RpcnR5KGIpICYmIGIuY29uZmxpY3QgPT09IG51bGwgJiYgIWIudmFuaXNoZWQ7XG59XG5cbi8qKiBUaGUgdXNlciB0eXBlZDogcmVwbGFjZSB0aGUgYnVmZmVyLiBOZXZlciB0b3VjaGVzIGBiYXNlbGluZWAvYGNvbmZsaWN0YCDigJQgYVxuICogIGNvbmZsaWN0LCBvbmNlIHJhaXNlZCwgc3RheXMgdW50aWwgZXhwbGljaXRseSByZXNvbHZlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBseUVkaXQoYjogRmlsZUJ1ZmZlciwgbmV4dDogc3RyaW5nKTogRmlsZUJ1ZmZlciB7XG4gIHJldHVybiB7IC4uLmIsIGJ1ZmZlcjogbmV4dCB9O1xufVxuXG4vKipcbiAqIEFuIGV4dGVybmFsIHdyaXRlIHRvIHRoaXMgZmlsZSBsYW5kZWQgKGRlbGl2ZXJlZCBieSB0aGUgaG9zdCdzIGZzLWNoYW5nZVxuICogZmFuLW91dDsgdGhpcyBhcHAgaXMgb3JpZ2luLWV4Y2x1ZGVkIGZyb20gaXRzIG93biB3cml0ZXMg4oCUIFBoYXNlIDAxKS4gQmVoYXZpb3VyXG4gKiBwZXIgc3BlYyDCpzY6XG4gKiAgIC0gY2xlYW4gYnVmZmVyICDihpIgYWRvcHQgc2lsZW50bHkgKHJlLXJlYWQgcmVwbGFjZXMgdGhlIGJ1ZmZlcikuXG4gKiAgIC0gZGlydHkgYnVmZmVyICDihpIgZG8gTk9UIG1vZGlmeSB0aGUgYnVmZmVyOyByYWlzZSBhIGJsb2NraW5nIGNvbmZsaWN0LlxuICogQSBmaWxlIHRoYXQgaGFkIHZhbmlzaGVkIGFuZCBpcyBub3cgcmUtY3JlYXRlZCBjbGVhcnMgdGhlIHZhbmlzaGVkIGZsYWcgYW5kIGlzXG4gKiB0cmVhdGVkIGFzIHRoZSBleHRlcm5hbCBjb250ZW50IGFycml2aW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlFeHRlcm5hbENoYW5nZShiOiBGaWxlQnVmZmVyLCB0aGVpcnM6IHN0cmluZyk6IEZpbGVCdWZmZXIge1xuICBpZiAoaXNEaXJ0eShiKSAmJiAhYi52YW5pc2hlZCkge1xuICAgIC8vIERpcnR5OiBrZWVwIHRoZSB1c2VyJ3Mga2V5c3Ryb2tlcyB1bnRvdWNoZWQ7IHN1cmZhY2UgdGhlIGNvbmZsaWN0LiBJZiB0aGVcbiAgICAvLyBpbmNvbWluZyBieXRlcyBlcXVhbCB3aGF0IHRoZSB1c2VyIGFscmVhZHkgdHlwZWQsIHRoZXJlIGlzIG5vdGhpbmcgdG9cbiAgICAvLyByZXNvbHZlIOKAlCBqdXN0IHJlLWJhc2VsaW5lIChub3cgY2xlYW4pLlxuICAgIGlmICh0aGVpcnMgPT09IGIuYnVmZmVyKSB7XG4gICAgICByZXR1cm4geyAuLi5iLCBiYXNlbGluZTogdGhlaXJzLCBjb25mbGljdDogbnVsbCB9O1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5iLCBjb25mbGljdDogeyB0aGVpcnMgfSB9O1xuICB9XG4gIC8vIENsZWFuIChvciBwcmV2aW91c2x5IHZhbmlzaGVkKTogYWRvcHQgdGhlIG5ldyBjb250ZW50IGFzIHRoZSBuZXcgYmFzZWxpbmUuXG4gIHJldHVybiB7IHBhdGg6IGIucGF0aCwgYmFzZWxpbmU6IHRoZWlycywgYnVmZmVyOiB0aGVpcnMsIGNvbmZsaWN0OiBudWxsLCB2YW5pc2hlZDogZmFsc2UgfTtcbn1cblxuLyoqXG4gKiBUaGUgd29ya2luZyB0cmVlIG5vdyBob2xkcyBieXRlcyAqKnRoaXMgYXBwIHdyb3RlKiog4oCUIHRoZSBlY2hvIG9mIG91ciBvd24gc2F2ZVxuICogY29taW5nIGJhY2sgb24gdGhlIGZzLWNoYW5nZSBzdHJlYW0uIFJlLWJhc2VsaW5lIG9udG8gdGhlbTsgbmV2ZXIgYSBjb25mbGljdC5cbiAqXG4gKiBUaGlzIGlzIHRoZSBlZGl0b3IncyBvcmlnaW4gZXhjbHVzaW9uLCBhbmQgaXQgaXMgZGVsaWJlcmF0ZWx5IGlkZW50aXR5LWJhc2VkXG4gKiAoXCJhcmUgdGhlc2UgdGhlIGJ5dGVzIEkgc2VudD9cIikgcmF0aGVyIHRoYW4gdGhlIGVxdWFsaXR5IGl0IHVzZWQgdG8gcmVseSBvblxuICogKFwiZG9lcyBkaXNrIG1hdGNoIG15IGJ1ZmZlcj9cIikuIEJ1ZmZlciBlcXVhbGl0eSBpcyBub3QgYSBzb3VuZCB0ZXN0IGZvciBcIm1pbmVcIjpcbiAqIHRoZSB1c2VyIGtlZXBzIHR5cGluZyB3aGlsZSB0aGUgd3JpdGUgaXMgaW4gZmxpZ2h0LCBzbyBieSB0aGUgdGltZSB0aGUgZWNob1xuICogbGFuZHMgdGhlIGJ1ZmZlciBoYXMgbGVnaXRpbWF0ZWx5IG1vdmVkIG9uIGFuZCBgYXBwbHlFeHRlcm5hbENoYW5nZWAgc2VlcyBhXG4gKiBkaXZlcmdlbmNlIHRoYXQgaGFzIG5vIGV4dGVybmFsIHdyaXRlciBiZWhpbmQgaXQg4oCUIGEgYmxvY2tpbmcgY29uZmxpY3QgcmFpc2VkXG4gKiBhZ2FpbnN0IG5vYm9keSwgb24gdGhlIHNlY29uZCBrZXlzdHJva2UuXG4gKlxuICogVGhlIGJ1ZmZlciBpcyB1bnRvdWNoZWQsIHNvIGlmIHRoZSB1c2VyIGhhcyB0eXBlZCBvbiBpdCBzdGF5cyBkaXJ0eSBhZ2FpbnN0IHRoZVxuICogbmV3IGJhc2VsaW5lIGFuZCB0aGUgbmV4dCBkZWJvdW5jZWQgd3JpdGUgc2F2ZXMgdGhlIHJlc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBseU93bldyaXRlRWNobyhiOiBGaWxlQnVmZmVyLCBvdXJzOiBzdHJpbmcpOiBGaWxlQnVmZmVyIHtcbiAgLy8gQSB2YW5pc2hlZCBmaWxlIGlzIG5vdCByZXN1cnJlY3RlZCBieSBpdHMgb3duIHN0YWxlIGVjaG8gKMKnMTIuNCksIGFuZCBhXG4gIC8vIGNvbmZsaWN0IGFscmVhZHkgcmFpc2VkIGlzIHRoZSB1c2VyJ3MgdG8gcmVzb2x2ZSDigJQgbmVpdGhlciBpcyBvdXJzIHRvIGNsZWFyLlxuICBpZiAoYi52YW5pc2hlZCB8fCBiLmNvbmZsaWN0KSByZXR1cm4gYjtcbiAgcmV0dXJuIHsgLi4uYiwgYmFzZWxpbmU6IG91cnMgfTtcbn1cblxuLyoqIFRoZSBhY3RpdmUvb3BlbiBmaWxlIHdhcyBkZWxldGVkIG9yIHJlbmFtZWQgZXh0ZXJuYWxseSAoc3BlYyDCpzEyLjQpLiBNYXJrIGl0XG4gKiAgdmFuaXNoZWQ7IHRoZSBhcHAgc2hvd3MgYSBwbGFjZWhvbGRlciBhbmQgbXVzdCBOT1Qgd3JpdGUgdGhlIHBhdGggYmFjayAod2hpY2hcbiAqICB3b3VsZCByZXN1cnJlY3QgdGhlIGZpbGUpLiBUaGUgdXNlcidzIGJ1ZmZlciBpcyBwcmVzZXJ2ZWQgaW4gY2FzZSB0aGV5IHdhbnQgdG9cbiAqICBjb3B5IGl0IG91dCwgYnV0IHNhdmUgc3RheXMgYmxvY2tlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBseUV4dGVybmFsRGVsZXRlKGI6IEZpbGVCdWZmZXIpOiBGaWxlQnVmZmVyIHtcbiAgcmV0dXJuIHsgLi4uYiwgdmFuaXNoZWQ6IHRydWUsIGNvbmZsaWN0OiBudWxsIH07XG59XG5cbi8qKiBSZXNvbHZlIGEgY29uZmxpY3QgYnkga2VlcGluZyB0aGUgdXNlcidzIHZlcnNpb24uIFRoZSBleHRlcm5hbCBieXRlcyBiZWNvbWUgdGhlXG4gKiAgbmV3IGJhc2VsaW5lIChzbyB0aGUgYnVmZmVyIGlzIHN0aWxsIGRpcnR5IGFuZCBhIHNhdmUgd2lsbCBvdmVyd3JpdGUgdGhlbSB3aXRoXG4gKiAgdGhlIHVzZXIncyBjb250ZW50KSwgYW5kIHRoZSBibG9jayBsaWZ0cy4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlS2VlcE1pbmUoYjogRmlsZUJ1ZmZlcik6IEZpbGVCdWZmZXIge1xuICBpZiAoIWIuY29uZmxpY3QpIHJldHVybiBiO1xuICByZXR1cm4geyAuLi5iLCBiYXNlbGluZTogYi5jb25mbGljdC50aGVpcnMsIGNvbmZsaWN0OiBudWxsIH07XG59XG5cbi8qKiBSZXNvbHZlIGEgY29uZmxpY3QgYnkgdGFraW5nIHRoZSBleHRlcm5hbCB2ZXJzaW9uLiBUaGUgYnVmZmVyIGlzIHJlcGxhY2VkIHdpdGhcbiAqICB0aGVpciBieXRlcyAodGhlIHVzZXIncyBlZGl0cyBhcmUgZGlzY2FyZGVkKSBhbmQgdGhlIGJ1ZmZlciBiZWNvbWVzIGNsZWFuLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVUYWtlVGhlaXJzKGI6IEZpbGVCdWZmZXIpOiBGaWxlQnVmZmVyIHtcbiAgaWYgKCFiLmNvbmZsaWN0KSByZXR1cm4gYjtcbiAgY29uc3QgdGhlaXJzID0gYi5jb25mbGljdC50aGVpcnM7XG4gIHJldHVybiB7IC4uLmIsIGJhc2VsaW5lOiB0aGVpcnMsIGJ1ZmZlcjogdGhlaXJzLCBjb25mbGljdDogbnVsbCB9O1xufVxuXG4vKiogQSBkZWJvdW5jZWQgd3JpdGUgb2YgdGhlIGN1cnJlbnQgYnVmZmVyIGNvbW1pdHRlZCB0byB0aGUgd29ya2luZyB0cmVlOiB0aGVcbiAqICBidWZmZXIgaXMgbm93IHRoZSBiYXNlbGluZSAoY2xlYW4pLiBPbmx5IHZhbGlkIHdoZW4ge0BsaW5rIGNhblNhdmV9IGhlbGQuICovXG5leHBvcnQgZnVuY3Rpb24gbWFya1NhdmVkKGI6IEZpbGVCdWZmZXIpOiBGaWxlQnVmZmVyIHtcbiAgcmV0dXJuIHsgLi4uYiwgYmFzZWxpbmU6IGIuYnVmZmVyIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFjQTtBQUNPLFNBQVNBLFVBQVVBLENBQUNDLElBQVksRUFBRUMsT0FBZSxFQUFjO0VBQ3BFLE9BQU87SUFBRUQsSUFBSTtJQUFFRSxRQUFRLEVBQUVELE9BQU87SUFBRUUsTUFBTSxFQUFFRixPQUFPO0lBQUVHLFFBQVEsRUFBRSxJQUFJO0lBQUVDLFFBQVEsRUFBRTtFQUFNLENBQUM7QUFDdEY7O0FBRUE7QUFDTyxTQUFTQyxPQUFPQSxDQUFDQyxDQUFhLEVBQVc7RUFDOUMsT0FBT0EsQ0FBQyxDQUFDSixNQUFNLEtBQUtJLENBQUMsQ0FBQ0wsUUFBUTtBQUNoQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTTSxPQUFPQSxDQUFDRCxDQUFhLEVBQVc7RUFDOUMsT0FBT0QsT0FBTyxDQUFDQyxDQUFDLENBQUMsSUFBSUEsQ0FBQyxDQUFDSCxRQUFRLEtBQUssSUFBSSxJQUFJLENBQUNHLENBQUMsQ0FBQ0YsUUFBUTtBQUN6RDs7QUFFQTtBQUNBO0FBQ08sU0FBU0ksU0FBU0EsQ0FBQ0YsQ0FBYSxFQUFFRyxJQUFZLEVBQWM7RUFDakUsT0FBTztJQUFFLEdBQUdILENBQUM7SUFBRUosTUFBTSxFQUFFTztFQUFLLENBQUM7QUFDL0I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsbUJBQW1CQSxDQUFDSixDQUFhLEVBQUVLLE1BQWMsRUFBYztFQUM3RSxJQUFJTixPQUFPLENBQUNDLENBQUMsQ0FBQyxJQUFJLENBQUNBLENBQUMsQ0FBQ0YsUUFBUSxFQUFFO0lBQzdCO0lBQ0E7SUFDQTtJQUNBLElBQUlPLE1BQU0sS0FBS0wsQ0FBQyxDQUFDSixNQUFNLEVBQUU7TUFDdkIsT0FBTztRQUFFLEdBQUdJLENBQUM7UUFBRUwsUUFBUSxFQUFFVSxNQUFNO1FBQUVSLFFBQVEsRUFBRTtNQUFLLENBQUM7SUFDbkQ7SUFDQSxPQUFPO01BQUUsR0FBR0csQ0FBQztNQUFFSCxRQUFRLEVBQUU7UUFBRVE7TUFBTztJQUFFLENBQUM7RUFDdkM7RUFDQTtFQUNBLE9BQU87SUFBRVosSUFBSSxFQUFFTyxDQUFDLENBQUNQLElBQUk7SUFBRUUsUUFBUSxFQUFFVSxNQUFNO0lBQUVULE1BQU0sRUFBRVMsTUFBTTtJQUFFUixRQUFRLEVBQUUsSUFBSTtJQUFFQyxRQUFRLEVBQUU7RUFBTSxDQUFDO0FBQzVGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNRLGlCQUFpQkEsQ0FBQ04sQ0FBYSxFQUFFTyxJQUFZLEVBQWM7RUFDekU7RUFDQTtFQUNBLElBQUlQLENBQUMsQ0FBQ0YsUUFBUSxJQUFJRSxDQUFDLENBQUNILFFBQVEsRUFBRSxPQUFPRyxDQUFDO0VBQ3RDLE9BQU87SUFBRSxHQUFHQSxDQUFDO0lBQUVMLFFBQVEsRUFBRVk7RUFBSyxDQUFDO0FBQ2pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsbUJBQW1CQSxDQUFDUixDQUFhLEVBQWM7RUFDN0QsT0FBTztJQUFFLEdBQUdBLENBQUM7SUFBRUYsUUFBUSxFQUFFLElBQUk7SUFBRUQsUUFBUSxFQUFFO0VBQUssQ0FBQztBQUNqRDs7QUFFQTtBQUNBO0FBQ0E7QUFDTyxTQUFTWSxlQUFlQSxDQUFDVCxDQUFhLEVBQWM7RUFDekQsSUFBSSxDQUFDQSxDQUFDLENBQUNILFFBQVEsRUFBRSxPQUFPRyxDQUFDO0VBQ3pCLE9BQU87SUFBRSxHQUFHQSxDQUFDO0lBQUVMLFFBQVEsRUFBRUssQ0FBQyxDQUFDSCxRQUFRLENBQUNRLE1BQU07SUFBRVIsUUFBUSxFQUFFO0VBQUssQ0FBQztBQUM5RDs7QUFFQTtBQUNBO0FBQ08sU0FBU2EsaUJBQWlCQSxDQUFDVixDQUFhLEVBQWM7RUFDM0QsSUFBSSxDQUFDQSxDQUFDLENBQUNILFFBQVEsRUFBRSxPQUFPRyxDQUFDO0VBQ3pCLE1BQU1LLE1BQU0sR0FBR0wsQ0FBQyxDQUFDSCxRQUFRLENBQUNRLE1BQU07RUFDaEMsT0FBTztJQUFFLEdBQUdMLENBQUM7SUFBRUwsUUFBUSxFQUFFVSxNQUFNO0lBQUVULE1BQU0sRUFBRVMsTUFBTTtJQUFFUixRQUFRLEVBQUU7RUFBSyxDQUFDO0FBQ25FOztBQUVBO0FBQ0E7QUFDTyxTQUFTYyxTQUFTQSxDQUFDWCxDQUFhLEVBQWM7RUFDbkQsT0FBTztJQUFFLEdBQUdBLENBQUM7SUFBRUwsUUFBUSxFQUFFSyxDQUFDLENBQUNKO0VBQU8sQ0FBQztBQUNyQyIsImlnbm9yZUxpc3QiOltdfQ==