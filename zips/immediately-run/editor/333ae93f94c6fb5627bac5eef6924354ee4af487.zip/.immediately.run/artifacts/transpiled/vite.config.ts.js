"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The editor — a forkable immediately.run system app (EDITOR_AS_APP_SPEC, plan
// Phase 04). It renders raw CodeMirror 6 in an opaque iframe and reaches the
// kernel only through the SDK (the rw working-tree port + the editor channels +
// the session intents). `base: './'` so a Pages-hosted build resolves its own
// assets. https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)({
  base: './',
  plugins: [(0, _pluginReact.default)()]
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwiYmFzZSIsInBsdWdpbnMiLCJyZWFjdCJdLCJzb3VyY2VzIjpbInZpdGUuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gJ3ZpdGUnO1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0JztcblxuLy8gVGhlIGVkaXRvciDigJQgYSBmb3JrYWJsZSBpbW1lZGlhdGVseS5ydW4gc3lzdGVtIGFwcCAoRURJVE9SX0FTX0FQUF9TUEVDLCBwbGFuXG4vLyBQaGFzZSAwNCkuIEl0IHJlbmRlcnMgcmF3IENvZGVNaXJyb3IgNiBpbiBhbiBvcGFxdWUgaWZyYW1lIGFuZCByZWFjaGVzIHRoZVxuLy8ga2VybmVsIG9ubHkgdGhyb3VnaCB0aGUgU0RLICh0aGUgcncgd29ya2luZy10cmVlIHBvcnQgKyB0aGUgZWRpdG9yIGNoYW5uZWxzICtcbi8vIHRoZSBzZXNzaW9uIGludGVudHMpLiBgYmFzZTogJy4vJ2Agc28gYSBQYWdlcy1ob3N0ZWQgYnVpbGQgcmVzb2x2ZXMgaXRzIG93blxuLy8gYXNzZXRzLiBodHRwczovL3ZpdGUuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIGJhc2U6ICcuLycsXG4gIHBsdWdpbnM6IFtyZWFjdCgpXSxcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBeUMsU0FBQUUsdUJBQUFDLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsa0JBQVksRUFBQztFQUMxQkMsSUFBSSxFQUFFLElBQUk7RUFDVkMsT0FBTyxFQUFFLENBQUMsSUFBQUMsb0JBQUssRUFBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==