var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "editor-the-immediatelyrun-code-editor-as-a-forkable-app",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "editor-the-immediatelyrun-code-editor-as-a-forkable-app"
      }), "editor — the immediately.run code editor, as a forkable app"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is the immediately.run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "editor"
      }), ", reclassified from host kernel into a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "forkable system app"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDITOR_AS_APP_SPEC"
      }), ", plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/plans/editor-as-app/"
      }), ",\nroadmap R3-54 / Phase 04). It renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "raw CodeMirror 6"
      }), " in an opaque iframe and\nreaches the kernel ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only through the SDK"
      }), " — the read-write working-tree port, the\neditor-session channels, and the session intents. It is a drop-in successor to the\nnative ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Edit.tsx"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EditorTabs.tsx"
      }), " surface."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-boundary-dont-cross-it",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-boundary-dont-cross-it"
      }), "The boundary (don't cross it)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The kernel owns the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "document"
      }), " — the working-tree bytes, transpilation, the\nCOW/journal, the Sandpack client. This app owns the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "view"
      }), " — CodeMirror state,\ncursor, undo, tabs, decorations. The app never drives the transpile loop and never\nhosts ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SandpackProvider"
      }), "; it edits a kernel-owned document over the SDK."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-it-works",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-it-works"
      }), "How it works"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Content over the rw port."
        }), " The active file (from the editor-session channel) is\nread through the working-tree mount (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/fs/mountFs.ts"
        }), ", reused from the\nfile-explorer app; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/fs/workingTree.ts"
        }), " maps repo-relative paths to the mount).\nEvery keystroke updates the in-iframe CodeMirror state at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "0 hops"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Debounced write — the sole timing knob."
        }), " Edits are debounced\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/core/debounce.ts"
        }), ") and written back to the rw port. We debounce the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "write"
        }), ",\nnot compilation: the host recompiles ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "immediately"
        }), " whenever its ZenFS watch\nobserves a write (host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "recompileMode:'immediate'"
        }), "), so there is no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "recompileDelay"
        }), "\nto match. A pending write is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "flushed before teardown"
        }), " (branch-switch remount /\ngrant revocation) so the user's last edit is never silently dropped (spec §12.5)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The §6 conflict surface."
        }), " An external write to a file with unsaved edits does\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " modify the buffer — it raises a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "blocking"
        }), " conflict (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "keep mine"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "take\ntheirs"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "show diff"
        }), ") and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "blocks save"
        }), " until resolved. The user's keystrokes are\nnever touched. A clean buffer re-reads silently. This is the code-integrity\ninvariant: the editor anchors \"Save to GitHub\", so silent byte-substitution into the\nabout-to-be-saved buffer is rejected (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/core/buffer.ts"
        }), ", threat M6)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Active-file-vanished (§12.4)."
        }), " A file deleted/renamed under the open buffer shows\na \"this file was removed\" placeholder and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never written back"
        }), " (no\nresurrection)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No tab strip."
        }), " The active file is driven entirely by the session channel; the\napp renders only that file and shows no tab bar. The host owns file switching, so\nthis surface holds no local tab state."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Diagnostics, theme, form-factor"
        }), " ride their channels (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useDiagnostics"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useHostTheme"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useFormFactor"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "security-invariants",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "security-invariants"
      }), "Security invariants"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Opaque origin, SDK-only."
        }), " The app never assumes same-origin and never touches\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.parent"
        }), "; it reaches the kernel exclusively through the SDK."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Writes only the files the user edits."
        }), " The vanished handler explicitly does not\nre-create a deleted file — a buggy/forked editor's blast radius is bounded to\nuser-driven edits in the user's own working copy."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute:*"
          }), "."]
        }), " The app cannot push. Saving to GitHub stays a separate,\nseparately-consented authority. A fork scribbles only in the user's own working copy."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "status"
      }), "Status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 04 — parity-in-isolation."
      }), " Built behind the kernel kill-switch; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["not yet\nbound to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "panel.editor"
        })]
      }), " (that flip + the native-editor deletion is Phase 05,\noperator-gated on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HOST_ORIGIN_HARDENING"
      }), " + a deploy). Two host-side dependencies are\nnot on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), " yet and have documented stand-ins here:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "onFsChange"
          }), " channel (Phase 02)."]
        }), " External-change detection currently uses a\nlow-frequency re-read poll (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/useFileBuffer.ts"
        }), "); swap it for the channel\nsubscription when it lands — the buffer transitions are unchanged."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Host ZenFS-watch recompile + per-port origin-exclusion (Phase 01)."
        }), " The write\ndebounce here assumes the host recompiles on watch and excludes this port from the\nfs-change fan-out."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "tests",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "tests"
      }), "Tests"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The decision logic is pure and unit-tested (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/core/*.test.ts"
      }), "): the conflict state\nmachine, the readiness race, diagnostics mapping, the debounce flush/cancel, language\nselection, and the working-tree resolver. The React surface has jsdom smoke tests\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/App.test.tsx"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm install\nnpm test       # vitest\nnpm run build  # tsc -b && vite build\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "verify-standalone-the-harness",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verify-standalone-the-harness"
      }), "Verify standalone (the harness)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Because the app is not yet bound to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.editor"
      }), " (Phase 05), there is no live host\nto drive it. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev:harness"
      }), " runs it against a dev-only mock\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/dev/sdkMock.ts"
      }), ", aliased in by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite.harness.config.ts"
      }), ") that supplies what the\nhost normally would — the editor-session channel (active file + open tabs) and an\nin-memory rw working-tree port with seed files. Open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/harness.html"
      }), " and exercise the\nreal surface: typing → debounced port write, tab switch/close intents, theme, and the\n§6 conflict / §12.4 vanished states. The page exposes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "window.__editorHarness"
      }), " so a\nscripted browser session can drive scenarios:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-js",
        children: "__editorHarness.externalWrite('/app/src/App.tsx', '…')  // dirty buffer → §6 conflict\n__editorHarness.externalDelete('/app/src/App.tsx')       // → §12.4 vanished placeholder\n__editorHarness.setTheme('light'); __editorHarness.activate('/src/main.tsx')\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The harness is dev-only — production builds use the real SDK (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite.config.ts"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "forking",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "forking"
      }), "Forking"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Fork it, edit it, run it — it is an ordinary immediately.run app. A fork inherits a\nread-write port to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "your own"
      }), " working copy (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exposesWorkingTree:'rw'"
      }), " region\nproperty), so its blast radius is self-contained. It cannot push and cannot reach\nanother user's tree."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwiaDMiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZWRpdG9yLXRoZS1pbW1lZGlhdGVseXJ1bi1jb2RlLWVkaXRvci1hcy1hLWZvcmthYmxlLWFwcFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZWRpdG9yLXRoZS1pbW1lZGlhdGVseXJ1bi1jb2RlLWVkaXRvci1hcy1hLWZvcmthYmxlLWFwcFwiIC8+e1wiZWRpdG9yIOKAlCB0aGUgaW1tZWRpYXRlbHkucnVuIGNvZGUgZWRpdG9yLCBhcyBhIGZvcmthYmxlIGFwcFwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyB0aGUgaW1tZWRpYXRlbHkucnVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCByZWNsYXNzaWZpZWQgZnJvbSBob3N0IGtlcm5lbCBpbnRvIGFcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZvcmthYmxlIHN5c3RlbSBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9BU19BUFBfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHBsYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9wbGFucy9lZGl0b3ItYXMtYXBwL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxucm9hZG1hcCBSMy01NCAvIFBoYXNlIDA0KS4gSXQgcmVuZGVycyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJhdyBDb2RlTWlycm9yIDZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gYW4gb3BhcXVlIGlmcmFtZSBhbmRcXG5yZWFjaGVzIHRoZSBrZXJuZWwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbmx5IHRocm91Z2ggdGhlIFNES1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHJlYWQtd3JpdGUgd29ya2luZy10cmVlIHBvcnQsIHRoZVxcbmVkaXRvci1zZXNzaW9uIGNoYW5uZWxzLCBhbmQgdGhlIHNlc3Npb24gaW50ZW50cy4gSXQgaXMgYSBkcm9wLWluIHN1Y2Nlc3NvciB0byB0aGVcXG5uYXRpdmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRWRpdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRWRpdG9yVGFicy50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN1cmZhY2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1ib3VuZGFyeS1kb250LWNyb3NzLWl0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtYm91bmRhcnktZG9udC1jcm9zcy1pdFwiIC8+e1wiVGhlIGJvdW5kYXJ5IChkb24ndCBjcm9zcyBpdClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBrZXJuZWwgb3ducyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHdvcmtpbmctdHJlZSBieXRlcywgdHJhbnNwaWxhdGlvbiwgdGhlXFxuQ09XL2pvdXJuYWwsIHRoZSBTYW5kcGFjayBjbGllbnQuIFRoaXMgYXBwIG93bnMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widmlld1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgQ29kZU1pcnJvciBzdGF0ZSxcXG5jdXJzb3IsIHVuZG8sIHRhYnMsIGRlY29yYXRpb25zLiBUaGUgYXBwIG5ldmVyIGRyaXZlcyB0aGUgdHJhbnNwaWxlIGxvb3AgYW5kIG5ldmVyXFxuaG9zdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2FuZHBhY2tQcm92aWRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGl0IGVkaXRzIGEga2VybmVsLW93bmVkIGRvY3VtZW50IG92ZXIgdGhlIFNESy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaG93LWl0LXdvcmtzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJob3ctaXQtd29ya3NcIiAvPntcIkhvdyBpdCB3b3Jrc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbnRlbnQgb3ZlciB0aGUgcncgcG9ydC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGFjdGl2ZSBmaWxlIChmcm9tIHRoZSBlZGl0b3Itc2Vzc2lvbiBjaGFubmVsKSBpc1xcbnJlYWQgdGhyb3VnaCB0aGUgd29ya2luZy10cmVlIG1vdW50IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZnMvbW91bnRGcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHJldXNlZCBmcm9tIHRoZVxcbmZpbGUtZXhwbG9yZXIgYXBwOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZnMvd29ya2luZ1RyZWUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcHMgcmVwby1yZWxhdGl2ZSBwYXRocyB0byB0aGUgbW91bnQpLlxcbkV2ZXJ5IGtleXN0cm9rZSB1cGRhdGVzIHRoZSBpbi1pZnJhbWUgQ29kZU1pcnJvciBzdGF0ZSBhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIjAgaG9wc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlYm91bmNlZCB3cml0ZSDigJQgdGhlIHNvbGUgdGltaW5nIGtub2IuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEVkaXRzIGFyZSBkZWJvdW5jZWRcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvcmUvZGVib3VuY2UudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgd3JpdHRlbiBiYWNrIHRvIHRoZSBydyBwb3J0LiBXZSBkZWJvdW5jZSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3cml0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIixcXG5ub3QgY29tcGlsYXRpb246IHRoZSBob3N0IHJlY29tcGlsZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbW1lZGlhdGVseVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aGVuZXZlciBpdHMgWmVuRlMgd2F0Y2hcXG5vYnNlcnZlcyBhIHdyaXRlIChob3N0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlY29tcGlsZU1vZGU6J2ltbWVkaWF0ZSdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc28gdGhlcmUgaXMgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVjb21waWxlRGVsYXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxudG8gbWF0Y2guIEEgcGVuZGluZyB3cml0ZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZsdXNoZWQgYmVmb3JlIHRlYXJkb3duXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChicmFuY2gtc3dpdGNoIHJlbW91bnQgL1xcbmdyYW50IHJldm9jYXRpb24pIHNvIHRoZSB1c2VyJ3MgbGFzdCBlZGl0IGlzIG5ldmVyIHNpbGVudGx5IGRyb3BwZWQgKHNwZWMgwqcxMi41KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSDCpzYgY29uZmxpY3Qgc3VyZmFjZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQW4gZXh0ZXJuYWwgd3JpdGUgdG8gYSBmaWxlIHdpdGggdW5zYXZlZCBlZGl0cyBkb2VzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbW9kaWZ5IHRoZSBidWZmZXIg4oCUIGl0IHJhaXNlcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmxvY2tpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY29uZmxpY3QgKFwifTxfY29tcG9uZW50cy5lbT57XCJrZWVwIG1pbmVcIn08L19jb21wb25lbnRzLmVtPntcIiAvIFwifTxfY29tcG9uZW50cy5lbT57XCJ0YWtlXFxudGhlaXJzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgLyBcIn08X2NvbXBvbmVudHMuZW0+e1wic2hvdyBkaWZmXCJ9PC9fY29tcG9uZW50cy5lbT57XCIpIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJsb2NrcyBzYXZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHVudGlsIHJlc29sdmVkLiBUaGUgdXNlcidzIGtleXN0cm9rZXMgYXJlXFxubmV2ZXIgdG91Y2hlZC4gQSBjbGVhbiBidWZmZXIgcmUtcmVhZHMgc2lsZW50bHkuIFRoaXMgaXMgdGhlIGNvZGUtaW50ZWdyaXR5XFxuaW52YXJpYW50OiB0aGUgZWRpdG9yIGFuY2hvcnMgXFxcIlNhdmUgdG8gR2l0SHViXFxcIiwgc28gc2lsZW50IGJ5dGUtc3Vic3RpdHV0aW9uIGludG8gdGhlXFxuYWJvdXQtdG8tYmUtc2F2ZWQgYnVmZmVyIGlzIHJlamVjdGVkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvY29yZS9idWZmZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aHJlYXQgTTYpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWN0aXZlLWZpbGUtdmFuaXNoZWQgKMKnMTIuNCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgZmlsZSBkZWxldGVkL3JlbmFtZWQgdW5kZXIgdGhlIG9wZW4gYnVmZmVyIHNob3dzXFxuYSBcXFwidGhpcyBmaWxlIHdhcyByZW1vdmVkXFxcIiBwbGFjZWhvbGRlciBhbmQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlciB3cml0dGVuIGJhY2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vXFxucmVzdXJyZWN0aW9uKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIHRhYiBzdHJpcC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGFjdGl2ZSBmaWxlIGlzIGRyaXZlbiBlbnRpcmVseSBieSB0aGUgc2Vzc2lvbiBjaGFubmVsOyB0aGVcXG5hcHAgcmVuZGVycyBvbmx5IHRoYXQgZmlsZSBhbmQgc2hvd3Mgbm8gdGFiIGJhci4gVGhlIGhvc3Qgb3ducyBmaWxlIHN3aXRjaGluZywgc29cXG50aGlzIHN1cmZhY2UgaG9sZHMgbm8gbG9jYWwgdGFiIHN0YXRlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGlhZ25vc3RpY3MsIHRoZW1lLCBmb3JtLWZhY3RvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByaWRlIHRoZWlyIGNoYW5uZWxzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VEaWFnbm9zdGljc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlSG9zdFRoZW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlRm9ybUZhY3RvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWN1cml0eS1pbnZhcmlhbnRzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWN1cml0eS1pbnZhcmlhbnRzXCIgLz57XCJTZWN1cml0eSBpbnZhcmlhbnRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT3BhcXVlIG9yaWdpbiwgU0RLLW9ubHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhcHAgbmV2ZXIgYXNzdW1lcyBzYW1lLW9yaWdpbiBhbmQgbmV2ZXIgdG91Y2hlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5wYXJlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBpdCByZWFjaGVzIHRoZSBrZXJuZWwgZXhjbHVzaXZlbHkgdGhyb3VnaCB0aGUgU0RLLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV3JpdGVzIG9ubHkgdGhlIGZpbGVzIHRoZSB1c2VyIGVkaXRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgdmFuaXNoZWQgaGFuZGxlciBleHBsaWNpdGx5IGRvZXMgbm90XFxucmUtY3JlYXRlIGEgZGVsZXRlZCBmaWxlIOKAlCBhIGJ1Z2d5L2ZvcmtlZCBlZGl0b3IncyBibGFzdCByYWRpdXMgaXMgYm91bmRlZCB0b1xcbnVzZXItZHJpdmVuIGVkaXRzIGluIHRoZSB1c2VyJ3Mgb3duIHdvcmtpbmcgY29weS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6KlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhcHAgY2Fubm90IHB1c2guIFNhdmluZyB0byBHaXRIdWIgc3RheXMgYSBzZXBhcmF0ZSxcXG5zZXBhcmF0ZWx5LWNvbnNlbnRlZCBhdXRob3JpdHkuIEEgZm9yayBzY3JpYmJsZXMgb25seSBpbiB0aGUgdXNlcidzIG93biB3b3JraW5nIGNvcHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0YXR1c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RhdHVzXCIgLz57XCJTdGF0dXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGhhc2UgMDQg4oCUIHBhcml0eS1pbi1pc29sYXRpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEJ1aWx0IGJlaGluZCB0aGUga2VybmVsIGtpbGwtc3dpdGNoOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCB5ZXRcXG5ib3VuZCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYW5lbC5lZGl0b3JcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGF0IGZsaXAgKyB0aGUgbmF0aXZlLWVkaXRvciBkZWxldGlvbiBpcyBQaGFzZSAwNSxcXG5vcGVyYXRvci1nYXRlZCBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT1NUX09SSUdJTl9IQVJERU5JTkdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgYSBkZXBsb3kpLiBUd28gaG9zdC1zaWRlIGRlcGVuZGVuY2llcyBhcmVcXG5ub3Qgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgeWV0IGFuZCBoYXZlIGRvY3VtZW50ZWQgc3RhbmQtaW5zIGhlcmU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJvbkZzQ2hhbmdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGFubmVsIChQaGFzZSAwMikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEV4dGVybmFsLWNoYW5nZSBkZXRlY3Rpb24gY3VycmVudGx5IHVzZXMgYVxcbmxvdy1mcmVxdWVuY3kgcmUtcmVhZCBwb2xsIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvdXNlRmlsZUJ1ZmZlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBzd2FwIGl0IGZvciB0aGUgY2hhbm5lbFxcbnN1YnNjcmlwdGlvbiB3aGVuIGl0IGxhbmRzIOKAlCB0aGUgYnVmZmVyIHRyYW5zaXRpb25zIGFyZSB1bmNoYW5nZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIb3N0IFplbkZTLXdhdGNoIHJlY29tcGlsZSArIHBlci1wb3J0IG9yaWdpbi1leGNsdXNpb24gKFBoYXNlIDAxKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHdyaXRlXFxuZGVib3VuY2UgaGVyZSBhc3N1bWVzIHRoZSBob3N0IHJlY29tcGlsZXMgb24gd2F0Y2ggYW5kIGV4Y2x1ZGVzIHRoaXMgcG9ydCBmcm9tIHRoZVxcbmZzLWNoYW5nZSBmYW4tb3V0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0ZXN0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGVzdHNcIiAvPntcIlRlc3RzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZGVjaXNpb24gbG9naWMgaXMgcHVyZSBhbmQgdW5pdC10ZXN0ZWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb3JlLyoudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiB0aGUgY29uZmxpY3Qgc3RhdGVcXG5tYWNoaW5lLCB0aGUgcmVhZGluZXNzIHJhY2UsIGRpYWdub3N0aWNzIG1hcHBpbmcsIHRoZSBkZWJvdW5jZSBmbHVzaC9jYW5jZWwsIGxhbmd1YWdlXFxuc2VsZWN0aW9uLCBhbmQgdGhlIHdvcmtpbmctdHJlZSByZXNvbHZlci4gVGhlIFJlYWN0IHN1cmZhY2UgaGFzIGpzZG9tIHNtb2tlIHRlc3RzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1zaFwiPntcIm5wbSBpbnN0YWxsXFxubnBtIHRlc3QgICAgICAgIyB2aXRlc3RcXG5ucG0gcnVuIGJ1aWxkICAjIHRzYyAtYiAmJiB2aXRlIGJ1aWxkXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInZlcmlmeS1zdGFuZGFsb25lLXRoZS1oYXJuZXNzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ2ZXJpZnktc3RhbmRhbG9uZS10aGUtaGFybmVzc1wiIC8+e1wiVmVyaWZ5IHN0YW5kYWxvbmUgKHRoZSBoYXJuZXNzKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQmVjYXVzZSB0aGUgYXBwIGlzIG5vdCB5ZXQgYm91bmQgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFuZWwuZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoUGhhc2UgMDUpLCB0aGVyZSBpcyBubyBsaXZlIGhvc3RcXG50byBkcml2ZSBpdC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBkZXY6aGFybmVzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyBpdCBhZ2FpbnN0IGEgZGV2LW9ubHkgbW9ja1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGV2L3Nka01vY2sudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbGlhc2VkIGluIGJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUuaGFybmVzcy5jb25maWcudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSB0aGF0IHN1cHBsaWVzIHdoYXQgdGhlXFxuaG9zdCBub3JtYWxseSB3b3VsZCDigJQgdGhlIGVkaXRvci1zZXNzaW9uIGNoYW5uZWwgKGFjdGl2ZSBmaWxlICsgb3BlbiB0YWJzKSBhbmQgYW5cXG5pbi1tZW1vcnkgcncgd29ya2luZy10cmVlIHBvcnQgd2l0aCBzZWVkIGZpbGVzLiBPcGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9oYXJuZXNzLmh0bWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBleGVyY2lzZSB0aGVcXG5yZWFsIHN1cmZhY2U6IHR5cGluZyDihpIgZGVib3VuY2VkIHBvcnQgd3JpdGUsIHRhYiBzd2l0Y2gvY2xvc2UgaW50ZW50cywgdGhlbWUsIGFuZCB0aGVcXG7CpzYgY29uZmxpY3QgLyDCpzEyLjQgdmFuaXNoZWQgc3RhdGVzLiBUaGUgcGFnZSBleHBvc2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5fX2VkaXRvckhhcm5lc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNvIGFcXG5zY3JpcHRlZCBicm93c2VyIHNlc3Npb24gY2FuIGRyaXZlIHNjZW5hcmlvczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc1wiPntcIl9fZWRpdG9ySGFybmVzcy5leHRlcm5hbFdyaXRlKCcvYXBwL3NyYy9BcHAudHN4JywgJ+KApicpICAvLyBkaXJ0eSBidWZmZXIg4oaSIMKnNiBjb25mbGljdFxcbl9fZWRpdG9ySGFybmVzcy5leHRlcm5hbERlbGV0ZSgnL2FwcC9zcmMvQXBwLnRzeCcpICAgICAgIC8vIOKGkiDCpzEyLjQgdmFuaXNoZWQgcGxhY2Vob2xkZXJcXG5fX2VkaXRvckhhcm5lc3Muc2V0VGhlbWUoJ2xpZ2h0Jyk7IF9fZWRpdG9ySGFybmVzcy5hY3RpdmF0ZSgnL3NyYy9tYWluLnRzeCcpXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBoYXJuZXNzIGlzIGRldi1vbmx5IOKAlCBwcm9kdWN0aW9uIGJ1aWxkcyB1c2UgdGhlIHJlYWwgU0RLIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlLmNvbmZpZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmb3JraW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmb3JraW5nXCIgLz57XCJGb3JraW5nXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGb3JrIGl0LCBlZGl0IGl0LCBydW4gaXQg4oCUIGl0IGlzIGFuIG9yZGluYXJ5IGltbWVkaWF0ZWx5LnJ1biBhcHAuIEEgZm9yayBpbmhlcml0cyBhXFxucmVhZC13cml0ZSBwb3J0IHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wieW91ciBvd25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd29ya2luZyBjb3B5ICh0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwb3Nlc1dvcmtpbmdUcmVlOidydydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZ2lvblxcbnByb3BlcnR5KSwgc28gaXRzIGJsYXN0IHJhZGl1cyBpcyBzZWxmLWNvbnRhaW5lZC4gSXQgY2Fubm90IHB1c2ggYW5kIGNhbm5vdCByZWFjaFxcbmFub3RoZXIgdXNlcidzIHRyZWUuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9SRUFETUUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyx5REFBeUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5RCxDQUFFLENBQUMsRUFBQyw2REFBNkQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFzQixDQUFxQixDQUFDLEVBQUMsdUlBQXVJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsNEJBQTRCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEIsQ0FBRSxDQUFDLEVBQUMsK0JBQStCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHFHQUFxRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLGtIQUFrSCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsa0RBQWtEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBeUMsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyw4R0FBOEc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQWMsQ0FBaUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMseVBBQXlQLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxlQUFlO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsNExBQTRMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHFCQUFxQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFCLENBQUUsQ0FBQyxFQUFDLHFCQUFxQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxzREFBc0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXVDLENBQXFCLENBQUMsRUFBQyw2S0FBNks7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEdBQUUsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGlKQUFpSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFFBQVE7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWlDLENBQXFCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsZ0dBQWdHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFvRSxDQUFxQixDQUFDLEVBQUMsb0hBQW9IO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsT0FBTztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsT0FBTztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSw4Q0FBOEMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLG9NQUFvTSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFDbUIsU0FBUyxFQUFDLGFBQWE7UUFBQUgsUUFBQSxFQUFFO01BQStFLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNLLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLGlDQUFpQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsb0tBQW9LLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGtLQUFrSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUSxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUNtQixTQUFTLEVBQUMsYUFBYTtRQUFBSCxRQUFBLEVBQUU7TUFBaVEsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLEdBQUUsZ0VBQWdFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFNBQVM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLEdBQUUsMEdBQTBHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXlCLENBQW1CLENBQUMsRUFBQyxrSEFBa0g7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2grVDtBQUNlLFNBQVNJLFVBQVVBLENBQUN0QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDdUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1osS0FBSyxDQUFDYTtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUExQixXQUFBLENBQUFzQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLeEIsS0FBSztJQUFBa0IsUUFBQSxlQUFFLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNyQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDeUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}