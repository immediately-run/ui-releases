"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
var _rollup = _interopRequireDefault(require("@mdx-js/rollup"));
var _devFs = require("@immediately-run/dev-fs");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// MDX must run before @vitejs/plugin-react so the JSX it emits is handled by
// React's transform (Fast Refresh included). immediately.run processes .mdx
// natively; this wiring keeps the local `vite dev`/`build` in sync.
//
// devFs() (@immediately-run/dev-fs) makes `import ... from 'fs'` work during
// local `vite dev`, bridging the same async ZenFS surface immediately.run
// provides to your real disk. It is dev-only and absent from production builds.
// https://vite.dev/config/
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _devFs.devFs)(), {
    enforce: 'pre',
    ...(0, _rollup.default)()
  }, (0, _pluginReact.default)()],
  test: {
    // The @immediately-run/* dists ship extensionless relative ESM imports
    // (`./sandboxUtils`), which Vite's resolver accepts but Node's — used for
    // externalized deps in vitest — rejects. Inlining routes them through Vite's
    // resolver instead, in tests only; `vite build` was never affected.
    server: {
      deps: {
        inline: ['@immediately-run/sdk', '@immediately-run/omnibox']
      }
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfcm9sbHVwIiwiX2RldkZzIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwicGx1Z2lucyIsImRldkZzIiwiZW5mb3JjZSIsIm1keCIsInJlYWN0IiwidGVzdCIsInNlcnZlciIsImRlcHMiLCJpbmxpbmUiXSwic291cmNlcyI6WyJ2aXRlLmNvbmZpZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlc3QvY29uZmlnJ1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0J1xuaW1wb3J0IG1keCBmcm9tICdAbWR4LWpzL3JvbGx1cCdcbmltcG9ydCB7IGRldkZzIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9kZXYtZnMnXG5cbi8vIE1EWCBtdXN0IHJ1biBiZWZvcmUgQHZpdGVqcy9wbHVnaW4tcmVhY3Qgc28gdGhlIEpTWCBpdCBlbWl0cyBpcyBoYW5kbGVkIGJ5XG4vLyBSZWFjdCdzIHRyYW5zZm9ybSAoRmFzdCBSZWZyZXNoIGluY2x1ZGVkKS4gaW1tZWRpYXRlbHkucnVuIHByb2Nlc3NlcyAubWR4XG4vLyBuYXRpdmVseTsgdGhpcyB3aXJpbmcga2VlcHMgdGhlIGxvY2FsIGB2aXRlIGRldmAvYGJ1aWxkYCBpbiBzeW5jLlxuLy9cbi8vIGRldkZzKCkgKEBpbW1lZGlhdGVseS1ydW4vZGV2LWZzKSBtYWtlcyBgaW1wb3J0IC4uLiBmcm9tICdmcydgIHdvcmsgZHVyaW5nXG4vLyBsb2NhbCBgdml0ZSBkZXZgLCBicmlkZ2luZyB0aGUgc2FtZSBhc3luYyBaZW5GUyBzdXJmYWNlIGltbWVkaWF0ZWx5LnJ1blxuLy8gcHJvdmlkZXMgdG8geW91ciByZWFsIGRpc2suIEl0IGlzIGRldi1vbmx5IGFuZCBhYnNlbnQgZnJvbSBwcm9kdWN0aW9uIGJ1aWxkcy5cbi8vIGh0dHBzOi8vdml0ZS5kZXYvY29uZmlnL1xuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcbiAgcGx1Z2luczogW1xuICAgIGRldkZzKCksXG4gICAgeyBlbmZvcmNlOiAncHJlJywgLi4ubWR4KCkgfSxcbiAgICByZWFjdCgpLFxuICBdLFxuICB0ZXN0OiB7XG4gICAgLy8gVGhlIEBpbW1lZGlhdGVseS1ydW4vKiBkaXN0cyBzaGlwIGV4dGVuc2lvbmxlc3MgcmVsYXRpdmUgRVNNIGltcG9ydHNcbiAgICAvLyAoYC4vc2FuZGJveFV0aWxzYCksIHdoaWNoIFZpdGUncyByZXNvbHZlciBhY2NlcHRzIGJ1dCBOb2RlJ3Mg4oCUIHVzZWQgZm9yXG4gICAgLy8gZXh0ZXJuYWxpemVkIGRlcHMgaW4gdml0ZXN0IOKAlCByZWplY3RzLiBJbmxpbmluZyByb3V0ZXMgdGhlbSB0aHJvdWdoIFZpdGUnc1xuICAgIC8vIHJlc29sdmVyIGluc3RlYWQsIGluIHRlc3RzIG9ubHk7IGB2aXRlIGJ1aWxkYCB3YXMgbmV2ZXIgYWZmZWN0ZWQuXG4gICAgc2VydmVyOiB7IGRlcHM6IHsgaW5saW5lOiBbJ0BpbW1lZGlhdGVseS1ydW4vc2RrJywgJ0BpbW1lZGlhdGVseS1ydW4vb21uaWJveCddIH0gfSxcbiAgfSxcbn0pXG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUQsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFJLE1BQUEsR0FBQUosT0FBQTtBQUErQyxTQUFBRSx1QkFBQUcsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUUvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFGLE9BQUEsR0FDZSxJQUFBRyxvQkFBWSxFQUFDO0VBQzFCQyxPQUFPLEVBQUUsQ0FDUCxJQUFBQyxZQUFLLEVBQUMsQ0FBQyxFQUNQO0lBQUVDLE9BQU8sRUFBRSxLQUFLO0lBQUUsR0FBRyxJQUFBQyxlQUFHLEVBQUM7RUFBRSxDQUFDLEVBQzVCLElBQUFDLG9CQUFLLEVBQUMsQ0FBQyxDQUNSO0VBQ0RDLElBQUksRUFBRTtJQUNKO0lBQ0E7SUFDQTtJQUNBO0lBQ0FDLE1BQU0sRUFBRTtNQUFFQyxJQUFJLEVBQUU7UUFBRUMsTUFBTSxFQUFFLENBQUMsc0JBQXNCLEVBQUUsMEJBQTBCO01BQUU7SUFBRTtFQUNuRjtBQUNGLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==