var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = LinkTile;
var _platformLink = require("@immediately-run/sdk/platformLink");
require("../styles/tiles.css");
var _jsxRuntime = require("react/jsx-runtime");
/** One bordered panel tile with its own eyebrow and one hairline link pill.
 *  Rendered twice — the /MODEL and /NEWS pair; a second tile markup is the
 *  copy defect this component exists to prevent. */
function LinkTile({
  tag,
  title,
  body,
  linkLabel,
  to,
  linkToEnd = false
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: linkToEnd ? 'tile tile--link-end' : 'tile',
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "tag",
      children: tag
    }), title !== undefined ? /*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
      className: "tile__title",
      children: title
    }) : null, body !== undefined ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "tile__body",
      children: body
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      path: to,
      className: "btn-ghost tile__link",
      children: linkLabel
    })]
  });
}
_c = LinkTile;
var _c;
$RefreshReg$(_c, "LinkTile");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiTGlua1RpbGUiLCJ0YWciLCJ0aXRsZSIsImJvZHkiLCJsaW5rTGFiZWwiLCJ0byIsImxpbmtUb0VuZCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInVuZGVmaW5lZCIsIlBsYXRmb3JtTGluayIsInBhdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxpbmtUaWxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbGF0Zm9ybUxpbmsgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9wbGF0Zm9ybUxpbmsnO1xuaW1wb3J0ICcuLi9zdHlsZXMvdGlsZXMuY3NzJztcblxuZXhwb3J0IGludGVyZmFjZSBMaW5rVGlsZVByb3BzIHtcbiAgLyoqIFRoZSBtb25vIGV5ZWJyb3csIGUuZy4gL01PREVMLiAqL1xuICB0YWc6IHN0cmluZztcbiAgLyoqIEFuIG9wdGlvbmFsIGRpc3BsYXkgaGVhZGluZyBpbnNpZGUgdGhlIHRpbGUuICovXG4gIHRpdGxlPzogc3RyaW5nO1xuICAvKiogQW4gb3B0aW9uYWwgYm9keSBzZW50ZW5jZSBpbnNpZGUgdGhlIHRpbGUuICovXG4gIGJvZHk/OiBzdHJpbmc7XG4gIC8qKiBUaGUgcGlsbCdzIGxhYmVsLCBlLmcuIFwiTGFuZ3VhZ2UgbW9kZWwgc2V0dGluZ3Mg4oaSXCIuICovXG4gIGxpbmtMYWJlbDogc3RyaW5nO1xuICAvKiogVGhlIHBsYXRmb3JtIHBhdGggdGhlIHBpbGwgbmF2aWdhdGVzIHRvLiAqL1xuICB0bzogc3RyaW5nO1xuICAvKiogUGluIHRoZSBwaWxsIHRvIHRoZSB0aWxlJ3MgYm90dG9tIGVkZ2UgKHRoZSAvTkVXUyBzaGFwZSkuICovXG4gIGxpbmtUb0VuZD86IGJvb2xlYW47XG59XG5cbi8qKiBPbmUgYm9yZGVyZWQgcGFuZWwgdGlsZSB3aXRoIGl0cyBvd24gZXllYnJvdyBhbmQgb25lIGhhaXJsaW5lIGxpbmsgcGlsbC5cbiAqICBSZW5kZXJlZCB0d2ljZSDigJQgdGhlIC9NT0RFTCBhbmQgL05FV1MgcGFpcjsgYSBzZWNvbmQgdGlsZSBtYXJrdXAgaXMgdGhlXG4gKiAgY29weSBkZWZlY3QgdGhpcyBjb21wb25lbnQgZXhpc3RzIHRvIHByZXZlbnQuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaW5rVGlsZSh7IHRhZywgdGl0bGUsIGJvZHksIGxpbmtMYWJlbCwgdG8sIGxpbmtUb0VuZCA9IGZhbHNlIH06IExpbmtUaWxlUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9e2xpbmtUb0VuZCA/ICd0aWxlIHRpbGUtLWxpbmstZW5kJyA6ICd0aWxlJ30+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YWdcIj57dGFnfTwvc3Bhbj5cbiAgICAgIHt0aXRsZSAhPT0gdW5kZWZpbmVkID8gPGgzIGNsYXNzTmFtZT1cInRpbGVfX3RpdGxlXCI+e3RpdGxlfTwvaDM+IDogbnVsbH1cbiAgICAgIHtib2R5ICE9PSB1bmRlZmluZWQgPyA8cCBjbGFzc05hbWU9XCJ0aWxlX19ib2R5XCI+e2JvZHl9PC9wPiA6IG51bGx9XG4gICAgICA8UGxhdGZvcm1MaW5rIHBhdGg9e3RvfSBjbGFzc05hbWU9XCJidG4tZ2hvc3QgdGlsZV9fbGlua1wiPntsaW5rTGFiZWx9PC9QbGF0Zm9ybUxpbms+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFDQUEsT0FBQTtBQUE2QixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFpQjdCO0FBQ0E7QUFDQTtBQUNlLFNBQVNFLFFBQVFBLENBQUM7RUFBRUMsR0FBRztFQUFFQyxLQUFLO0VBQUVDLElBQUk7RUFBRUMsU0FBUztFQUFFQyxFQUFFO0VBQUVDLFNBQVMsR0FBRztBQUFxQixDQUFDLEVBQUU7RUFDdEcsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBUSxJQUFBO0lBQVNDLFNBQVMsRUFBRUYsU0FBUyxHQUFHLHFCQUFxQixHQUFHLE1BQU87SUFBQUcsUUFBQSxnQkFDN0QsSUFBQVYsV0FBQSxDQUFBVyxHQUFBO01BQU1GLFNBQVMsRUFBQyxLQUFLO01BQUFDLFFBQUEsRUFBRVI7SUFBRyxDQUFPLENBQUMsRUFDakNDLEtBQUssS0FBS1MsU0FBUyxnQkFBRyxJQUFBWixXQUFBLENBQUFXLEdBQUE7TUFBSUYsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxFQUFFUDtJQUFLLENBQUssQ0FBQyxHQUFHLElBQUksRUFDckVDLElBQUksS0FBS1EsU0FBUyxnQkFBRyxJQUFBWixXQUFBLENBQUFXLEdBQUE7TUFBR0YsU0FBUyxFQUFDLFlBQVk7TUFBQUMsUUFBQSxFQUFFTjtJQUFJLENBQUksQ0FBQyxHQUFHLElBQUksZUFDakUsSUFBQUosV0FBQSxDQUFBVyxHQUFBLEVBQUNiLGFBQUEsQ0FBQWUsWUFBWTtNQUFDQyxJQUFJLEVBQUVSLEVBQUc7TUFBQ0csU0FBUyxFQUFDLHNCQUFzQjtNQUFBQyxRQUFBLEVBQUVMO0lBQVMsQ0FBZSxDQUFDO0VBQUEsQ0FDNUUsQ0FBQztBQUVkO0FBQUNVLEVBQUEsR0FUdUJkLFFBQVE7QUFBQSxJQUFBYyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}