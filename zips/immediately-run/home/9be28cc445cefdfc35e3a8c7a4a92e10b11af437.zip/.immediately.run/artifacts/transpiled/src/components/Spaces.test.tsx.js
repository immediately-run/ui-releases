var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("@testing-library/react");
var _vitest = require("vitest");
var _sdk = require("@immediately-run/sdk");
var _Spaces = _interopRequireDefault(require("./Spaces"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// @vitest-environment jsdom

_vitest.vi.mock('@immediately-run/sdk', () => ({
  // Spaces reads once on mount; each test decides what the host answers.
  listAllSpaces: _vitest.vi.fn()
}));
_vitest.vi.mock('@immediately-run/sdk/platformLink', () => ({
  // The mock mirrors the real contract: a platform route anchor that always
  // carries target="_top".
  PlatformLink: ({
    path,
    children,
    ...rest
  }) => /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
    href: path,
    target: "_top",
    ...rest,
    children: children
  })
}));
const mockList = _vitest.vi.mocked(_sdk.listAllSpaces);

// Built field-by-field against the SDK's exported record type.
const household = {
  spaceId: 'space-1',
  name: 'Household',
  role: 'owner'
};
const chessClub = {
  spaceId: 'space-2',
  name: 'Chess club',
  role: 'writer'
};
const bookWiki = {
  spaceId: 'space-3',
  name: 'Book wiki',
  role: 'reader'
};
(0, _vitest.beforeEach)(() => {
  // In flight by default: the section renders nothing until the host answers.
  mockList.mockReset();
  mockList.mockReturnValue(new Promise(() => {}));
});
(0, _vitest.afterEach)(_react.cleanup);
(0, _vitest.describe)('Spaces', () => {
  (0, _vitest.it)('the list state renders the rows, the two header links, and never the gradient primary', async () => {
    mockList.mockResolvedValue([household, chessClub, bookWiki]);
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: "list"
    }));
    await _react.screen.findByText('Household');
    (0, _vitest.expect)(container.querySelectorAll('.sp-row')).toHaveLength(3);
    (0, _vitest.expect)(container.querySelectorAll('.btn')).toHaveLength(0);
    (0, _vitest.expect)(_react.screen.getByText('All spaces →')).toBeDefined();
    (0, _vitest.expect)(_react.screen.getByText('Create a space →')).toBeDefined();
    for (const a of Array.from(container.querySelectorAll('.section-head__links a'))) {
      (0, _vitest.expect)(a.getAttribute('href')).toBe('/spaces');
      (0, _vitest.expect)(a.getAttribute('target')).toBe('_top');
    }
  });
  (0, _vitest.it)('the Manage pill deep-links the manager at the space', async () => {
    mockList.mockResolvedValue([household, chessClub, bookWiki]);
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: "list"
    }));
    await _react.screen.findByText('Household');
    const manages = Array.from(container.querySelectorAll('.sp-manage'));
    (0, _vitest.expect)(manages.map(a => a.getAttribute('href'))).toEqual(['/spaces?space=space-1', '/spaces?space=space-2', '/spaces?space=space-3']);
  });
  (0, _vitest.it)('the empty state renders the heading links, the sentence verbatim, and the Create pill in the dashed box', async () => {
    mockList.mockResolvedValue([]);
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: "list"
    }));
    await _react.screen.findByText('You are not in any space yet. Create one, or wait for an invitation to reach your notifications.');
    (0, _vitest.expect)(container.querySelector('.sp-empty-box')).not.toBeNull();
    (0, _vitest.expect)(container.querySelectorAll('.sp-row')).toHaveLength(0);
    // the heading's right carries both links; the box carries the Create pill
    (0, _vitest.expect)(_react.screen.getAllByText('Create a space →')).toHaveLength(2);
    (0, _vitest.expect)(_react.screen.getByText('All spaces →')).toBeDefined();
  });
  (0, _vitest.it)('the off state renders the single line with the All spaces pill and no heading, no rows', async () => {
    mockList.mockRejectedValue({
      code: 'forbidden'
    });
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: "list"
    }));
    await _react.screen.findByText(/This version of Home cannot list your spaces\./);
    const all = _react.screen.getByText('All spaces →');
    (0, _vitest.expect)(all.getAttribute('href')).toBe('/spaces');
    (0, _vitest.expect)(container.querySelector('.section-head')).toBeNull();
    (0, _vitest.expect)(container.querySelectorAll('.sp-row')).toHaveLength(0);
    (0, _vitest.expect)(container.querySelector('.sp-list')).toBeNull();
  });
  (0, _vitest.it)('the phone layout renders the strip of cards and a heading without links', async () => {
    mockList.mockResolvedValue([household, chessClub, bookWiki]);
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: "strip"
    }));
    await _react.screen.findByText('Household');
    (0, _vitest.expect)(container.querySelector('.sp-strip')).not.toBeNull();
    (0, _vitest.expect)(container.querySelectorAll('.sp-card')).toHaveLength(3);
    (0, _vitest.expect)(container.querySelectorAll('.sp-row')).toHaveLength(0);
    (0, _vitest.expect)(container.querySelector('.section-head__links')).toBeNull();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZpdGVzdCIsIl9zZGsiLCJfU3BhY2VzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwidmkiLCJtb2NrIiwibGlzdEFsbFNwYWNlcyIsImZuIiwiUGxhdGZvcm1MaW5rIiwicGF0aCIsImNoaWxkcmVuIiwicmVzdCIsImpzeCIsImhyZWYiLCJ0YXJnZXQiLCJtb2NrTGlzdCIsIm1vY2tlZCIsImhvdXNlaG9sZCIsInNwYWNlSWQiLCJuYW1lIiwicm9sZSIsImNoZXNzQ2x1YiIsImJvb2tXaWtpIiwiYmVmb3JlRWFjaCIsIm1vY2tSZXNldCIsIm1vY2tSZXR1cm5WYWx1ZSIsIlByb21pc2UiLCJhZnRlckVhY2giLCJjbGVhbnVwIiwiZGVzY3JpYmUiLCJpdCIsIm1vY2tSZXNvbHZlZFZhbHVlIiwiY29udGFpbmVyIiwicmVuZGVyIiwibGF5b3V0Iiwic2NyZWVuIiwiZmluZEJ5VGV4dCIsImV4cGVjdCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJ0b0hhdmVMZW5ndGgiLCJnZXRCeVRleHQiLCJ0b0JlRGVmaW5lZCIsImEiLCJBcnJheSIsImZyb20iLCJnZXRBdHRyaWJ1dGUiLCJ0b0JlIiwibWFuYWdlcyIsIm1hcCIsInRvRXF1YWwiLCJxdWVyeVNlbGVjdG9yIiwibm90IiwidG9CZU51bGwiLCJnZXRBbGxCeVRleHQiLCJtb2NrUmVqZWN0ZWRWYWx1ZSIsImNvZGUiLCJhbGwiXSwic291cmNlcyI6WyJTcGFjZXMudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuaW1wb3J0IHsgY2xlYW51cCwgcmVuZGVyLCBzY3JlZW4gfSBmcm9tICdAdGVzdGluZy1saWJyYXJ5L3JlYWN0JztcbmltcG9ydCB7IGFmdGVyRWFjaCwgYmVmb3JlRWFjaCwgZGVzY3JpYmUsIGV4cGVjdCwgaXQsIHZpIH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGxpc3RBbGxTcGFjZXMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFNwYWNlSW5mbyB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCBTcGFjZXMgZnJvbSAnLi9TcGFjZXMnO1xuXG52aS5tb2NrKCdAaW1tZWRpYXRlbHktcnVuL3NkaycsICgpID0+ICh7XG4gIC8vIFNwYWNlcyByZWFkcyBvbmNlIG9uIG1vdW50OyBlYWNoIHRlc3QgZGVjaWRlcyB3aGF0IHRoZSBob3N0IGFuc3dlcnMuXG4gIGxpc3RBbGxTcGFjZXM6IHZpLmZuKCksXG59KSk7XG5cbnZpLm1vY2soJ0BpbW1lZGlhdGVseS1ydW4vc2RrL3BsYXRmb3JtTGluaycsICgpID0+ICh7XG4gIC8vIFRoZSBtb2NrIG1pcnJvcnMgdGhlIHJlYWwgY29udHJhY3Q6IGEgcGxhdGZvcm0gcm91dGUgYW5jaG9yIHRoYXQgYWx3YXlzXG4gIC8vIGNhcnJpZXMgdGFyZ2V0PVwiX3RvcFwiLlxuICBQbGF0Zm9ybUxpbms6ICh7IHBhdGgsIGNoaWxkcmVuLCAuLi5yZXN0IH06IHsgcGF0aDogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pID0+IChcbiAgICA8YSBocmVmPXtwYXRofSB0YXJnZXQ9XCJfdG9wXCIgey4uLnJlc3R9PntjaGlsZHJlbn08L2E+XG4gICksXG59KSk7XG5cbmNvbnN0IG1vY2tMaXN0ID0gdmkubW9ja2VkKGxpc3RBbGxTcGFjZXMpO1xuXG4vLyBCdWlsdCBmaWVsZC1ieS1maWVsZCBhZ2FpbnN0IHRoZSBTREsncyBleHBvcnRlZCByZWNvcmQgdHlwZS5cbmNvbnN0IGhvdXNlaG9sZDogU3BhY2VJbmZvID0geyBzcGFjZUlkOiAnc3BhY2UtMScsIG5hbWU6ICdIb3VzZWhvbGQnLCByb2xlOiAnb3duZXInIH07XG5jb25zdCBjaGVzc0NsdWI6IFNwYWNlSW5mbyA9IHsgc3BhY2VJZDogJ3NwYWNlLTInLCBuYW1lOiAnQ2hlc3MgY2x1YicsIHJvbGU6ICd3cml0ZXInIH07XG5jb25zdCBib29rV2lraTogU3BhY2VJbmZvID0geyBzcGFjZUlkOiAnc3BhY2UtMycsIG5hbWU6ICdCb29rIHdpa2knLCByb2xlOiAncmVhZGVyJyB9O1xuXG5iZWZvcmVFYWNoKCgpID0+IHtcbiAgLy8gSW4gZmxpZ2h0IGJ5IGRlZmF1bHQ6IHRoZSBzZWN0aW9uIHJlbmRlcnMgbm90aGluZyB1bnRpbCB0aGUgaG9zdCBhbnN3ZXJzLlxuICBtb2NrTGlzdC5tb2NrUmVzZXQoKTtcbiAgbW9ja0xpc3QubW9ja1JldHVyblZhbHVlKG5ldyBQcm9taXNlKCgpID0+IHt9KSk7XG59KTtcblxuYWZ0ZXJFYWNoKGNsZWFudXApO1xuXG5kZXNjcmliZSgnU3BhY2VzJywgKCkgPT4ge1xuICBpdCgndGhlIGxpc3Qgc3RhdGUgcmVuZGVycyB0aGUgcm93cywgdGhlIHR3byBoZWFkZXIgbGlua3MsIGFuZCBuZXZlciB0aGUgZ3JhZGllbnQgcHJpbWFyeScsIGFzeW5jICgpID0+IHtcbiAgICBtb2NrTGlzdC5tb2NrUmVzb2x2ZWRWYWx1ZShbaG91c2Vob2xkLCBjaGVzc0NsdWIsIGJvb2tXaWtpXSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8U3BhY2VzIGxheW91dD1cImxpc3RcIiAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoJ0hvdXNlaG9sZCcpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnLnNwLXJvdycpKS50b0hhdmVMZW5ndGgoMyk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCcuYnRuJykpLnRvSGF2ZUxlbmd0aCgwKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgnQWxsIHNwYWNlcyDihpInKSkudG9CZURlZmluZWQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgnQ3JlYXRlIGEgc3BhY2Ug4oaSJykpLnRvQmVEZWZpbmVkKCk7XG4gICAgZm9yIChjb25zdCBhIG9mIEFycmF5LmZyb20oY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZWN0aW9uLWhlYWRfX2xpbmtzIGEnKSkpIHtcbiAgICAgIGV4cGVjdChhLmdldEF0dHJpYnV0ZSgnaHJlZicpKS50b0JlKCcvc3BhY2VzJyk7XG4gICAgICBleHBlY3QoYS5nZXRBdHRyaWJ1dGUoJ3RhcmdldCcpKS50b0JlKCdfdG9wJyk7XG4gICAgfVxuICB9KTtcblxuICBpdCgndGhlIE1hbmFnZSBwaWxsIGRlZXAtbGlua3MgdGhlIG1hbmFnZXIgYXQgdGhlIHNwYWNlJywgYXN5bmMgKCkgPT4ge1xuICAgIG1vY2tMaXN0Lm1vY2tSZXNvbHZlZFZhbHVlKFtob3VzZWhvbGQsIGNoZXNzQ2x1YiwgYm9va1dpa2ldKTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKDxTcGFjZXMgbGF5b3V0PVwibGlzdFwiIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dCgnSG91c2Vob2xkJyk7XG4gICAgY29uc3QgbWFuYWdlcyA9IEFycmF5LmZyb20oY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5zcC1tYW5hZ2UnKSk7XG4gICAgZXhwZWN0KG1hbmFnZXMubWFwKChhKSA9PiBhLmdldEF0dHJpYnV0ZSgnaHJlZicpKSkudG9FcXVhbChbXG4gICAgICAnL3NwYWNlcz9zcGFjZT1zcGFjZS0xJyxcbiAgICAgICcvc3BhY2VzP3NwYWNlPXNwYWNlLTInLFxuICAgICAgJy9zcGFjZXM/c3BhY2U9c3BhY2UtMycsXG4gICAgXSk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgZW1wdHkgc3RhdGUgcmVuZGVycyB0aGUgaGVhZGluZyBsaW5rcywgdGhlIHNlbnRlbmNlIHZlcmJhdGltLCBhbmQgdGhlIENyZWF0ZSBwaWxsIGluIHRoZSBkYXNoZWQgYm94JywgYXN5bmMgKCkgPT4ge1xuICAgIG1vY2tMaXN0Lm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKDxTcGFjZXMgbGF5b3V0PVwibGlzdFwiIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcbiAgICAgICdZb3UgYXJlIG5vdCBpbiBhbnkgc3BhY2UgeWV0LiBDcmVhdGUgb25lLCBvciB3YWl0IGZvciBhbiBpbnZpdGF0aW9uIHRvIHJlYWNoIHlvdXIgbm90aWZpY2F0aW9ucy4nLFxuICAgICk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuc3AtZW1wdHktYm94JykpLm5vdC50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnLnNwLXJvdycpKS50b0hhdmVMZW5ndGgoMCk7XG4gICAgLy8gdGhlIGhlYWRpbmcncyByaWdodCBjYXJyaWVzIGJvdGggbGlua3M7IHRoZSBib3ggY2FycmllcyB0aGUgQ3JlYXRlIHBpbGxcbiAgICBleHBlY3Qoc2NyZWVuLmdldEFsbEJ5VGV4dCgnQ3JlYXRlIGEgc3BhY2Ug4oaSJykpLnRvSGF2ZUxlbmd0aCgyKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgnQWxsIHNwYWNlcyDihpInKSkudG9CZURlZmluZWQoKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBvZmYgc3RhdGUgcmVuZGVycyB0aGUgc2luZ2xlIGxpbmUgd2l0aCB0aGUgQWxsIHNwYWNlcyBwaWxsIGFuZCBubyBoZWFkaW5nLCBubyByb3dzJywgYXN5bmMgKCkgPT4ge1xuICAgIG1vY2tMaXN0Lm1vY2tSZWplY3RlZFZhbHVlKHsgY29kZTogJ2ZvcmJpZGRlbicgfSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8U3BhY2VzIGxheW91dD1cImxpc3RcIiAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoL1RoaXMgdmVyc2lvbiBvZiBIb21lIGNhbm5vdCBsaXN0IHlvdXIgc3BhY2VzXFwuLyk7XG4gICAgY29uc3QgYWxsID0gc2NyZWVuLmdldEJ5VGV4dCgnQWxsIHNwYWNlcyDihpInKTtcbiAgICBleHBlY3QoYWxsLmdldEF0dHJpYnV0ZSgnaHJlZicpKS50b0JlKCcvc3BhY2VzJyk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuc2VjdGlvbi1oZWFkJykpLnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCcuc3Atcm93JykpLnRvSGF2ZUxlbmd0aCgwKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5zcC1saXN0JykpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgcGhvbmUgbGF5b3V0IHJlbmRlcnMgdGhlIHN0cmlwIG9mIGNhcmRzIGFuZCBhIGhlYWRpbmcgd2l0aG91dCBsaW5rcycsIGFzeW5jICgpID0+IHtcbiAgICBtb2NrTGlzdC5tb2NrUmVzb2x2ZWRWYWx1ZShbaG91c2Vob2xkLCBjaGVzc0NsdWIsIGJvb2tXaWtpXSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8U3BhY2VzIGxheW91dD1cInN0cmlwXCIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KCdIb3VzZWhvbGQnKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5zcC1zdHJpcCcpKS5ub3QudG9CZU51bGwoKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5zcC1jYXJkJykpLnRvSGF2ZUxlbmd0aCgzKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5zcC1yb3cnKSkudG9IYXZlTGVuZ3RoKDApO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLnNlY3Rpb24taGVhZF9fbGlua3MnKSkudG9CZU51bGwoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLElBQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLE9BQUEsR0FBQUMsc0JBQUEsQ0FBQUosT0FBQTtBQUE4QixJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxTQUFBSSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUw5Qjs7QUFPQUcsVUFBRSxDQUFDQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsT0FBTztFQUNyQztFQUNBQyxhQUFhLEVBQUVGLFVBQUUsQ0FBQ0csRUFBRSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0FBRUhILFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLE9BQU87RUFDbEQ7RUFDQTtFQUNBRyxZQUFZLEVBQUVBLENBQUM7SUFBRUMsSUFBSTtJQUFFQyxRQUFRO0lBQUUsR0FBR0M7RUFBa0QsQ0FBQyxrQkFDckYsSUFBQVgsV0FBQSxDQUFBWSxHQUFBO0lBQUdDLElBQUksRUFBRUosSUFBSztJQUFDSyxNQUFNLEVBQUMsTUFBTTtJQUFBLEdBQUtILElBQUk7SUFBQUQsUUFBQSxFQUFHQTtFQUFRLENBQUk7QUFFeEQsQ0FBQyxDQUFDLENBQUM7QUFFSCxNQUFNSyxRQUFRLEdBQUdYLFVBQUUsQ0FBQ1ksTUFBTSxDQUFDVixrQkFBYSxDQUFDOztBQUV6QztBQUNBLE1BQU1XLFNBQW9CLEdBQUc7RUFBRUMsT0FBTyxFQUFFLFNBQVM7RUFBRUMsSUFBSSxFQUFFLFdBQVc7RUFBRUMsSUFBSSxFQUFFO0FBQVEsQ0FBQztBQUNyRixNQUFNQyxTQUFvQixHQUFHO0VBQUVILE9BQU8sRUFBRSxTQUFTO0VBQUVDLElBQUksRUFBRSxZQUFZO0VBQUVDLElBQUksRUFBRTtBQUFTLENBQUM7QUFDdkYsTUFBTUUsUUFBbUIsR0FBRztFQUFFSixPQUFPLEVBQUUsU0FBUztFQUFFQyxJQUFJLEVBQUUsV0FBVztFQUFFQyxJQUFJLEVBQUU7QUFBUyxDQUFDO0FBRXJGLElBQUFHLGtCQUFVLEVBQUMsTUFBTTtFQUNmO0VBQ0FSLFFBQVEsQ0FBQ1MsU0FBUyxDQUFDLENBQUM7RUFDcEJULFFBQVEsQ0FBQ1UsZUFBZSxDQUFDLElBQUlDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDO0FBRUYsSUFBQUMsaUJBQVMsRUFBQ0MsY0FBTyxDQUFDO0FBRWxCLElBQUFDLGdCQUFRLEVBQUMsUUFBUSxFQUFFLE1BQU07RUFDdkIsSUFBQUMsVUFBRSxFQUFDLHVGQUF1RixFQUFFLFlBQVk7SUFDdEdmLFFBQVEsQ0FBQ2dCLGlCQUFpQixDQUFDLENBQUNkLFNBQVMsRUFBRUksU0FBUyxFQUFFQyxRQUFRLENBQUMsQ0FBQztJQUM1RCxNQUFNO01BQUVVO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGFBQU0sZUFBQyxJQUFBakMsV0FBQSxDQUFBWSxHQUFBLEVBQUNkLE9BQUEsQ0FBQUssT0FBTTtNQUFDK0IsTUFBTSxFQUFDO0lBQU0sQ0FBRSxDQUFDLENBQUM7SUFDdEQsTUFBTUMsYUFBTSxDQUFDQyxVQUFVLENBQUMsV0FBVyxDQUFDO0lBQ3BDLElBQUFDLGNBQU0sRUFBQ0wsU0FBUyxDQUFDTSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdELElBQUFGLGNBQU0sRUFBQ0wsU0FBUyxDQUFDTSxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzFELElBQUFGLGNBQU0sRUFBQ0YsYUFBTSxDQUFDSyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7SUFDdEQsSUFBQUosY0FBTSxFQUFDRixhQUFNLENBQUNLLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO0lBQzFELEtBQUssTUFBTUMsQ0FBQyxJQUFJQyxLQUFLLENBQUNDLElBQUksQ0FBQ1osU0FBUyxDQUFDTSxnQkFBZ0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLEVBQUU7TUFDaEYsSUFBQUQsY0FBTSxFQUFDSyxDQUFDLENBQUNHLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsU0FBUyxDQUFDO01BQzlDLElBQUFULGNBQU0sRUFBQ0ssQ0FBQyxDQUFDRyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUMvQztFQUNGLENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMscURBQXFELEVBQUUsWUFBWTtJQUNwRWYsUUFBUSxDQUFDZ0IsaUJBQWlCLENBQUMsQ0FBQ2QsU0FBUyxFQUFFSSxTQUFTLEVBQUVDLFFBQVEsQ0FBQyxDQUFDO0lBQzVELE1BQU07TUFBRVU7SUFBVSxDQUFDLEdBQUcsSUFBQUMsYUFBTSxlQUFDLElBQUFqQyxXQUFBLENBQUFZLEdBQUEsRUFBQ2QsT0FBQSxDQUFBSyxPQUFNO01BQUMrQixNQUFNLEVBQUM7SUFBTSxDQUFFLENBQUMsQ0FBQztJQUN0RCxNQUFNQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxXQUFXLENBQUM7SUFDcEMsTUFBTVcsT0FBTyxHQUFHSixLQUFLLENBQUNDLElBQUksQ0FBQ1osU0FBUyxDQUFDTSxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNwRSxJQUFBRCxjQUFNLEVBQUNVLE9BQU8sQ0FBQ0MsR0FBRyxDQUFFTixDQUFDLElBQUtBLENBQUMsQ0FBQ0csWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksT0FBTyxDQUFDLENBQ3pELHVCQUF1QixFQUN2Qix1QkFBdUIsRUFDdkIsdUJBQXVCLENBQ3hCLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBbkIsVUFBRSxFQUFDLHlHQUF5RyxFQUFFLFlBQVk7SUFDeEhmLFFBQVEsQ0FBQ2dCLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUM5QixNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGFBQU0sZUFBQyxJQUFBakMsV0FBQSxDQUFBWSxHQUFBLEVBQUNkLE9BQUEsQ0FBQUssT0FBTTtNQUFDK0IsTUFBTSxFQUFDO0lBQU0sQ0FBRSxDQUFDLENBQUM7SUFDdEQsTUFBTUMsYUFBTSxDQUFDQyxVQUFVLENBQ3JCLGtHQUNGLENBQUM7SUFDRCxJQUFBQyxjQUFNLEVBQUNMLFNBQVMsQ0FBQ2tCLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0lBQy9ELElBQUFmLGNBQU0sRUFBQ0wsU0FBUyxDQUFDTSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdEO0lBQ0EsSUFBQUYsY0FBTSxFQUFDRixhQUFNLENBQUNrQixZQUFZLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDZCxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUFGLGNBQU0sRUFBQ0YsYUFBTSxDQUFDSyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7RUFDeEQsQ0FBQyxDQUFDO0VBRUYsSUFBQVgsVUFBRSxFQUFDLHdGQUF3RixFQUFFLFlBQVk7SUFDdkdmLFFBQVEsQ0FBQ3VDLGlCQUFpQixDQUFDO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQztJQUNqRCxNQUFNO01BQUV2QjtJQUFVLENBQUMsR0FBRyxJQUFBQyxhQUFNLGVBQUMsSUFBQWpDLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxPQUFBLENBQUFLLE9BQU07TUFBQytCLE1BQU0sRUFBQztJQUFNLENBQUUsQ0FBQyxDQUFDO0lBQ3RELE1BQU1DLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLGdEQUFnRCxDQUFDO0lBQ3pFLE1BQU1vQixHQUFHLEdBQUdyQixhQUFNLENBQUNLLFNBQVMsQ0FBQyxjQUFjLENBQUM7SUFDNUMsSUFBQUgsY0FBTSxFQUFDbUIsR0FBRyxDQUFDWCxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNoRCxJQUFBVCxjQUFNLEVBQUNMLFNBQVMsQ0FBQ2tCLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRSxRQUFRLENBQUMsQ0FBQztJQUMzRCxJQUFBZixjQUFNLEVBQUNMLFNBQVMsQ0FBQ00sZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ0MsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUM3RCxJQUFBRixjQUFNLEVBQUNMLFNBQVMsQ0FBQ2tCLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDRSxRQUFRLENBQUMsQ0FBQztFQUN4RCxDQUFDLENBQUM7RUFFRixJQUFBdEIsVUFBRSxFQUFDLHlFQUF5RSxFQUFFLFlBQVk7SUFDeEZmLFFBQVEsQ0FBQ2dCLGlCQUFpQixDQUFDLENBQUNkLFNBQVMsRUFBRUksU0FBUyxFQUFFQyxRQUFRLENBQUMsQ0FBQztJQUM1RCxNQUFNO01BQUVVO0lBQVUsQ0FBQyxHQUFHLElBQUFDLGFBQU0sZUFBQyxJQUFBakMsV0FBQSxDQUFBWSxHQUFBLEVBQUNkLE9BQUEsQ0FBQUssT0FBTTtNQUFDK0IsTUFBTSxFQUFDO0lBQU8sQ0FBRSxDQUFDLENBQUM7SUFDdkQsTUFBTUMsYUFBTSxDQUFDQyxVQUFVLENBQUMsV0FBVyxDQUFDO0lBQ3BDLElBQUFDLGNBQU0sRUFBQ0wsU0FBUyxDQUFDa0IsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7SUFDM0QsSUFBQWYsY0FBTSxFQUFDTCxTQUFTLENBQUNNLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDOUQsSUFBQUYsY0FBTSxFQUFDTCxTQUFTLENBQUNNLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDN0QsSUFBQUYsY0FBTSxFQUFDTCxTQUFTLENBQUNrQixhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDRSxRQUFRLENBQUMsQ0FBQztFQUNwRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}