var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SpaceRow;
var _platformLink = require("@immediately-run/sdk/platformLink");
var _routes = require("../lib/routes");
var _jsxRuntime = require("react/jsx-runtime");
// One space, two layouts of the same content — a bordered list row on the
// desktop, a card in the phone's horizontal strip. One component, one class
// set; the section's `layout` prop decides, and the stylesheet arranges.
function SpaceRow({
  row,
  layout
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: layout === 'strip' ? 'sp-card' : 'sp-row',
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "sp-name",
      children: row.name
    }), row.role && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "sp-role",
      children: row.role
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      path: (0, _routes.spacesRoute)(row.spaceId),
      className: "sp-manage",
      children: "Manage \u2192"
    })]
  });
}
_c = SpaceRow;
var _c;
$RefreshReg$(_c, "SpaceRow");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9yb3V0ZXMiLCJfanN4UnVudGltZSIsIlNwYWNlUm93Iiwicm93IiwibGF5b3V0IiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwibmFtZSIsInJvbGUiLCJQbGF0Zm9ybUxpbmsiLCJwYXRoIiwic3BhY2VzUm91dGUiLCJzcGFjZUlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTcGFjZVJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGxhdGZvcm1MaW5rIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvcGxhdGZvcm1MaW5rJztcbmltcG9ydCB0eXBlIHsgU3BhY2VSb3cgYXMgU3BhY2VSb3dEYXRhIH0gZnJvbSAnLi4vbGliL3NwYWNlcyc7XG5pbXBvcnQgeyBzcGFjZXNSb3V0ZSB9IGZyb20gJy4uL2xpYi9yb3V0ZXMnO1xuXG4vLyBPbmUgc3BhY2UsIHR3byBsYXlvdXRzIG9mIHRoZSBzYW1lIGNvbnRlbnQg4oCUIGEgYm9yZGVyZWQgbGlzdCByb3cgb24gdGhlXG4vLyBkZXNrdG9wLCBhIGNhcmQgaW4gdGhlIHBob25lJ3MgaG9yaXpvbnRhbCBzdHJpcC4gT25lIGNvbXBvbmVudCwgb25lIGNsYXNzXG4vLyBzZXQ7IHRoZSBzZWN0aW9uJ3MgYGxheW91dGAgcHJvcCBkZWNpZGVzLCBhbmQgdGhlIHN0eWxlc2hlZXQgYXJyYW5nZXMuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNwYWNlUm93KHsgcm93LCBsYXlvdXQgfTogeyByb3c6IFNwYWNlUm93RGF0YTsgbGF5b3V0OiAnbGlzdCcgfCAnc3RyaXAnIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17bGF5b3V0ID09PSAnc3RyaXAnID8gJ3NwLWNhcmQnIDogJ3NwLXJvdyd9PlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3AtbmFtZVwiPntyb3cubmFtZX08L3NwYW4+XG4gICAgICB7cm93LnJvbGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwic3Atcm9sZVwiPntyb3cucm9sZX08L3NwYW4+fVxuICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtzcGFjZXNSb3V0ZShyb3cuc3BhY2VJZCl9IGNsYXNzTmFtZT1cInNwLW1hbmFnZVwiPlxuICAgICAgICBNYW5hZ2Ug4oaSXG4gICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQTRDLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUU1QztBQUNBO0FBQ0E7QUFFZSxTQUFTRyxRQUFRQSxDQUFDO0VBQUVDLEdBQUc7RUFBRUM7QUFBd0QsQ0FBQyxFQUFFO0VBQ2pHLG9CQUNFLElBQUFILFdBQUEsQ0FBQUksSUFBQTtJQUFLQyxTQUFTLEVBQUVGLE1BQU0sS0FBSyxPQUFPLEdBQUcsU0FBUyxHQUFHLFFBQVM7SUFBQUcsUUFBQSxnQkFDeEQsSUFBQU4sV0FBQSxDQUFBTyxHQUFBO01BQU1GLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsRUFBRUosR0FBRyxDQUFDTTtJQUFJLENBQU8sQ0FBQyxFQUMxQ04sR0FBRyxDQUFDTyxJQUFJLGlCQUFJLElBQUFULFdBQUEsQ0FBQU8sR0FBQTtNQUFNRixTQUFTLEVBQUMsU0FBUztNQUFBQyxRQUFBLEVBQUVKLEdBQUcsQ0FBQ087SUFBSSxDQUFPLENBQUMsZUFDeEQsSUFBQVQsV0FBQSxDQUFBTyxHQUFBLEVBQUNWLGFBQUEsQ0FBQWEsWUFBWTtNQUFDQyxJQUFJLEVBQUUsSUFBQUMsbUJBQVcsRUFBQ1YsR0FBRyxDQUFDVyxPQUFPLENBQUU7TUFBQ1IsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxFQUFDO0lBRXBFLENBQWMsQ0FBQztFQUFBLENBQ1osQ0FBQztBQUVWO0FBQUNRLEVBQUEsR0FWdUJiLFFBQVE7QUFBQSxJQUFBYSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}