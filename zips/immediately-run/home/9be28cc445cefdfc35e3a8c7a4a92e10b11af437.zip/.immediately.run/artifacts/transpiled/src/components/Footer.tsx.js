var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Footer;
var _platformLink = require("@immediately-run/sdk/platformLink");
var _routes = require("../lib/routes");
require("../styles/footer.css");
var _jsxRuntime = require("react/jsx-runtime");
function Footer() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("footer", {
    className: "foot",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "foot__note",
      children: "Home is an app you can fork."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
      href: _routes.HOME_SOURCE,
      target: "_blank",
      rel: "noreferrer",
      children: "view source"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      path: _routes.HOME_EDIT,
      children: "fork this page \u2192"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      className: "foot__door",
      path: _routes.FRONT_DOOR,
      children: "Front door \u2192"
    })]
  });
}
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9yb3V0ZXMiLCJfanN4UnVudGltZSIsIkZvb3RlciIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsImhyZWYiLCJIT01FX1NPVVJDRSIsInRhcmdldCIsInJlbCIsIlBsYXRmb3JtTGluayIsInBhdGgiLCJIT01FX0VESVQiLCJGUk9OVF9ET09SIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGb290ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBsYXRmb3JtTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL3BsYXRmb3JtTGluayc7XG5pbXBvcnQgeyBGUk9OVF9ET09SLCBIT01FX0VESVQsIEhPTUVfU09VUkNFIH0gZnJvbSAnLi4vbGliL3JvdXRlcyc7XG5pbXBvcnQgJy4uL3N0eWxlcy9mb290ZXIuY3NzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9vdGVyKCkge1xuICByZXR1cm4gKFxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiZm9vdFwiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9vdF9fbm90ZVwiPkhvbWUgaXMgYW4gYXBwIHlvdSBjYW4gZm9yay48L3NwYW4+XG4gICAgICA8YSBocmVmPXtIT01FX1NPVVJDRX0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiPnZpZXcgc291cmNlPC9hPlxuICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtIT01FX0VESVR9PmZvcmsgdGhpcyBwYWdlIOKGkjwvUGxhdGZvcm1MaW5rPlxuICAgICAgPFBsYXRmb3JtTGluayBjbGFzc05hbWU9XCJmb290X19kb29yXCIgcGF0aD17RlJPTlRfRE9PUn0+RnJvbnQgZG9vciDihpI8L1BsYXRmb3JtTGluaz5cbiAgICA8L2Zvb3Rlcj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0FBLE9BQUE7QUFBOEIsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBRWYsU0FBU0csTUFBTUEsQ0FBQSxFQUFHO0VBQy9CLG9CQUNFLElBQUFELFdBQUEsQ0FBQUUsSUFBQTtJQUFRQyxTQUFTLEVBQUMsTUFBTTtJQUFBQyxRQUFBLGdCQUN0QixJQUFBSixXQUFBLENBQUFLLEdBQUE7TUFBTUYsU0FBUyxFQUFDLFlBQVk7TUFBQUMsUUFBQSxFQUFDO0lBQTRCLENBQU0sQ0FBQyxlQUNoRSxJQUFBSixXQUFBLENBQUFLLEdBQUE7TUFBR0MsSUFBSSxFQUFFQyxtQkFBWTtNQUFDQyxNQUFNLEVBQUMsUUFBUTtNQUFDQyxHQUFHLEVBQUMsWUFBWTtNQUFBTCxRQUFBLEVBQUM7SUFBVyxDQUFHLENBQUMsZUFDdEUsSUFBQUosV0FBQSxDQUFBSyxHQUFBLEVBQUNSLGFBQUEsQ0FBQWEsWUFBWTtNQUFDQyxJQUFJLEVBQUVDLGlCQUFVO01BQUFSLFFBQUEsRUFBQztJQUFnQixDQUFjLENBQUMsZUFDOUQsSUFBQUosV0FBQSxDQUFBSyxHQUFBLEVBQUNSLGFBQUEsQ0FBQWEsWUFBWTtNQUFDUCxTQUFTLEVBQUMsWUFBWTtNQUFDUSxJQUFJLEVBQUVFLGtCQUFXO01BQUFULFFBQUEsRUFBQztJQUFZLENBQWMsQ0FBQztFQUFBLENBQzVFLENBQUM7QUFFYjtBQUFDVSxFQUFBLEdBVHVCYixNQUFNO0FBQUEsSUFBQWEsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}