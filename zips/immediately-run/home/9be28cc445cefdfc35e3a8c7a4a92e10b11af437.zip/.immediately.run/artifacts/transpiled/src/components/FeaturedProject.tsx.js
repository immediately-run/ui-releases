var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = FeaturedProject;
var _platformLink = require("@immediately-run/sdk/platformLink");
var _ProjectMark = _interopRequireDefault(require("./ProjectMark"));
var _recents = require("../lib/recents");
var _routes = require("../lib/routes");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The newest project — the arrival target. Open is the page's one gradient
// primary when `primary` (the page decides, never a class name); on the phone
// the decorative panel and the inline Edit go, Edit moving behind the ⋯ menu
// rather than rendering hidden (a hidden button is still a tab stop).

// Escape collapses the ⋯ menu and leaves focus on its toggle — the same
// close-and-refocus contract the paste block follows. The <details> is
// otherwise native: uncontrolled, so closing is a plain DOM write.
function closeMenuOnEscape(e) {
  if (e.key !== 'Escape' || !e.currentTarget.open) return;
  e.currentTarget.open = false;
  e.currentTarget.querySelector('.rec-menu__toggle')?.focus();
}
function FeaturedProject({
  project,
  now,
  primary,
  mobile
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "rec-featured",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rec-featured__text",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "rec-featured__title",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "rec-featured__name",
            children: [project.namespace, "/", project.repository]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "rec-chip",
            children: project.ref
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "rec-featured__opened",
          children: (0, _recents.relativeOpened)(project.ts, now)
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rec-featured__actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
          path: (0, _routes.presentRoute)(project),
          className: primary ? 'btn rec-open' : 'btn-ghost rec-open',
          children: "Open"
        }), mobile ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
          className: "rec-menu",
          onKeyDown: closeMenuOnEscape,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
            className: "rec-menu__toggle",
            "aria-label": "More actions",
            children: "\u22EF"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
            path: (0, _routes.editRoute)(project),
            className: "btn-ghost rec-menu__item",
            children: "Edit"
          })]
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
          path: (0, _routes.editRoute)(project),
          className: "btn-ghost rec-edit",
          children: "Edit"
        })]
      })]
    }), !mobile && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ProjectMark.default, {
      project: project
    })]
  });
}
_c = FeaturedProject;
var _c;
$RefreshReg$(_c, "FeaturedProject");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9Qcm9qZWN0TWFyayIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfcmVjZW50cyIsIl9yb3V0ZXMiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImNsb3NlTWVudU9uRXNjYXBlIiwia2V5IiwiY3VycmVudFRhcmdldCIsIm9wZW4iLCJxdWVyeVNlbGVjdG9yIiwiZm9jdXMiLCJGZWF0dXJlZFByb2plY3QiLCJwcm9qZWN0Iiwibm93IiwicHJpbWFyeSIsIm1vYmlsZSIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm5hbWVzcGFjZSIsInJlcG9zaXRvcnkiLCJqc3giLCJyZWYiLCJyZWxhdGl2ZU9wZW5lZCIsInRzIiwiUGxhdGZvcm1MaW5rIiwicGF0aCIsInByZXNlbnRSb3V0ZSIsIm9uS2V5RG93biIsImVkaXRSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmVhdHVyZWRQcm9qZWN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbGF0Zm9ybUxpbmsgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9wbGF0Zm9ybUxpbmsnO1xuaW1wb3J0IHR5cGUgeyBLZXlib2FyZEV2ZW50IGFzIFJlYWN0S2V5Ym9hcmRFdmVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgUmVjZW50UHJvamVjdCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCBQcm9qZWN0TWFyayBmcm9tICcuL1Byb2plY3RNYXJrJztcbmltcG9ydCB7IHJlbGF0aXZlT3BlbmVkIH0gZnJvbSAnLi4vbGliL3JlY2VudHMnO1xuaW1wb3J0IHsgZWRpdFJvdXRlLCBwcmVzZW50Um91dGUgfSBmcm9tICcuLi9saWIvcm91dGVzJztcblxuLy8gVGhlIG5ld2VzdCBwcm9qZWN0IOKAlCB0aGUgYXJyaXZhbCB0YXJnZXQuIE9wZW4gaXMgdGhlIHBhZ2UncyBvbmUgZ3JhZGllbnRcbi8vIHByaW1hcnkgd2hlbiBgcHJpbWFyeWAgKHRoZSBwYWdlIGRlY2lkZXMsIG5ldmVyIGEgY2xhc3MgbmFtZSk7IG9uIHRoZSBwaG9uZVxuLy8gdGhlIGRlY29yYXRpdmUgcGFuZWwgYW5kIHRoZSBpbmxpbmUgRWRpdCBnbywgRWRpdCBtb3ZpbmcgYmVoaW5kIHRoZSDii68gbWVudVxuLy8gcmF0aGVyIHRoYW4gcmVuZGVyaW5nIGhpZGRlbiAoYSBoaWRkZW4gYnV0dG9uIGlzIHN0aWxsIGEgdGFiIHN0b3ApLlxuXG4vLyBFc2NhcGUgY29sbGFwc2VzIHRoZSDii68gbWVudSBhbmQgbGVhdmVzIGZvY3VzIG9uIGl0cyB0b2dnbGUg4oCUIHRoZSBzYW1lXG4vLyBjbG9zZS1hbmQtcmVmb2N1cyBjb250cmFjdCB0aGUgcGFzdGUgYmxvY2sgZm9sbG93cy4gVGhlIDxkZXRhaWxzPiBpc1xuLy8gb3RoZXJ3aXNlIG5hdGl2ZTogdW5jb250cm9sbGVkLCBzbyBjbG9zaW5nIGlzIGEgcGxhaW4gRE9NIHdyaXRlLlxuZnVuY3Rpb24gY2xvc2VNZW51T25Fc2NhcGUoZTogUmVhY3RLZXlib2FyZEV2ZW50PEhUTUxEZXRhaWxzRWxlbWVudD4pIHtcbiAgaWYgKGUua2V5ICE9PSAnRXNjYXBlJyB8fCAhZS5jdXJyZW50VGFyZ2V0Lm9wZW4pIHJldHVybjtcbiAgZS5jdXJyZW50VGFyZ2V0Lm9wZW4gPSBmYWxzZTtcbiAgZS5jdXJyZW50VGFyZ2V0LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCcucmVjLW1lbnVfX3RvZ2dsZScpPy5mb2N1cygpO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGZWF0dXJlZFByb2plY3Qoe1xuICBwcm9qZWN0LFxuICBub3csXG4gIHByaW1hcnksXG4gIG1vYmlsZSxcbn06IHtcbiAgcHJvamVjdDogUmVjZW50UHJvamVjdDtcbiAgbm93OiBudW1iZXI7XG4gIHByaW1hcnk6IGJvb2xlYW47XG4gIG1vYmlsZTogYm9vbGVhbjtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlYy1mZWF0dXJlZFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWMtZmVhdHVyZWRfX3RleHRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlYy1mZWF0dXJlZF9fdGl0bGVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlYy1mZWF0dXJlZF9fbmFtZVwiPlxuICAgICAgICAgICAgICB7cHJvamVjdC5uYW1lc3BhY2V9L3twcm9qZWN0LnJlcG9zaXRvcnl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWMtY2hpcFwiPntwcm9qZWN0LnJlZn08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWMtZmVhdHVyZWRfX29wZW5lZFwiPntyZWxhdGl2ZU9wZW5lZChwcm9qZWN0LnRzLCBub3cpfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWMtZmVhdHVyZWRfX2FjdGlvbnNcIj5cbiAgICAgICAgICA8UGxhdGZvcm1MaW5rXG4gICAgICAgICAgICBwYXRoPXtwcmVzZW50Um91dGUocHJvamVjdCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e3ByaW1hcnkgPyAnYnRuIHJlYy1vcGVuJyA6ICdidG4tZ2hvc3QgcmVjLW9wZW4nfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIE9wZW5cbiAgICAgICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICAgICAgICB7bW9iaWxlID8gKFxuICAgICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwicmVjLW1lbnVcIiBvbktleURvd249e2Nsb3NlTWVudU9uRXNjYXBlfT5cbiAgICAgICAgICAgICAgPHN1bW1hcnkgY2xhc3NOYW1lPVwicmVjLW1lbnVfX3RvZ2dsZVwiIGFyaWEtbGFiZWw9XCJNb3JlIGFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICDii69cbiAgICAgICAgICAgICAgPC9zdW1tYXJ5PlxuICAgICAgICAgICAgICA8UGxhdGZvcm1MaW5rIHBhdGg9e2VkaXRSb3V0ZShwcm9qZWN0KX0gY2xhc3NOYW1lPVwiYnRuLWdob3N0IHJlYy1tZW51X19pdGVtXCI+XG4gICAgICAgICAgICAgICAgRWRpdFxuICAgICAgICAgICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtlZGl0Um91dGUocHJvamVjdCl9IGNsYXNzTmFtZT1cImJ0bi1naG9zdCByZWMtZWRpdFwiPlxuICAgICAgICAgICAgICBFZGl0XG4gICAgICAgICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgeyFtb2JpbGUgJiYgPFByb2plY3RNYXJrIHByb2plY3Q9e3Byb2plY3R9IC8+fVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFHQSxJQUFBQyxZQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxRQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxPQUFBLEdBQUFKLE9BQUE7QUFBd0QsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQUEsU0FBQUUsdUJBQUFJLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFeEQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0csaUJBQWlCQSxDQUFDSCxDQUF5QyxFQUFFO0VBQ3BFLElBQUlBLENBQUMsQ0FBQ0ksR0FBRyxLQUFLLFFBQVEsSUFBSSxDQUFDSixDQUFDLENBQUNLLGFBQWEsQ0FBQ0MsSUFBSSxFQUFFO0VBQ2pETixDQUFDLENBQUNLLGFBQWEsQ0FBQ0MsSUFBSSxHQUFHLEtBQUs7RUFDNUJOLENBQUMsQ0FBQ0ssYUFBYSxDQUFDRSxhQUFhLENBQWMsbUJBQW1CLENBQUMsRUFBRUMsS0FBSyxDQUFDLENBQUM7QUFDMUU7QUFFZSxTQUFTQyxlQUFlQSxDQUFDO0VBQ3RDQyxPQUFPO0VBQ1BDLEdBQUc7RUFDSEMsT0FBTztFQUNQQztBQU1GLENBQUMsRUFBRTtFQUNELG9CQUNFLElBQUFkLFdBQUEsQ0FBQWUsSUFBQTtJQUFLQyxTQUFTLEVBQUMsY0FBYztJQUFBQyxRQUFBLGdCQUMzQixJQUFBakIsV0FBQSxDQUFBZSxJQUFBO01BQUtDLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUMsUUFBQSxnQkFDakMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQTtRQUFBRSxRQUFBLGdCQUNFLElBQUFqQixXQUFBLENBQUFlLElBQUE7VUFBS0MsU0FBUyxFQUFDLHFCQUFxQjtVQUFBQyxRQUFBLGdCQUNsQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBO1lBQU1DLFNBQVMsRUFBQyxvQkFBb0I7WUFBQUMsUUFBQSxHQUNqQ04sT0FBTyxDQUFDTyxTQUFTLEVBQUMsR0FBQyxFQUFDUCxPQUFPLENBQUNRLFVBQVU7VUFBQSxDQUNuQyxDQUFDLGVBQ1AsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUE7WUFBTUosU0FBUyxFQUFDLFVBQVU7WUFBQUMsUUFBQSxFQUFFTixPQUFPLENBQUNVO1VBQUcsQ0FBTyxDQUFDO1FBQUEsQ0FDNUMsQ0FBQyxlQUNOLElBQUFyQixXQUFBLENBQUFvQixHQUFBO1VBQUtKLFNBQVMsRUFBQyxzQkFBc0I7VUFBQUMsUUFBQSxFQUFFLElBQUFLLHVCQUFjLEVBQUNYLE9BQU8sQ0FBQ1ksRUFBRSxFQUFFWCxHQUFHO1FBQUMsQ0FBTSxDQUFDO01BQUEsQ0FDMUUsQ0FBQyxlQUNOLElBQUFaLFdBQUEsQ0FBQWUsSUFBQTtRQUFLQyxTQUFTLEVBQUMsdUJBQXVCO1FBQUFDLFFBQUEsZ0JBQ3BDLElBQUFqQixXQUFBLENBQUFvQixHQUFBLEVBQUMxQixhQUFBLENBQUE4QixZQUFZO1VBQ1hDLElBQUksRUFBRSxJQUFBQyxvQkFBWSxFQUFDZixPQUFPLENBQUU7VUFDNUJLLFNBQVMsRUFBRUgsT0FBTyxHQUFHLGNBQWMsR0FBRyxvQkFBcUI7VUFBQUksUUFBQSxFQUM1RDtRQUVELENBQWMsQ0FBQyxFQUNkSCxNQUFNLGdCQUNMLElBQUFkLFdBQUEsQ0FBQWUsSUFBQTtVQUFTQyxTQUFTLEVBQUMsVUFBVTtVQUFDVyxTQUFTLEVBQUV2QixpQkFBa0I7VUFBQWEsUUFBQSxnQkFDekQsSUFBQWpCLFdBQUEsQ0FBQW9CLEdBQUE7WUFBU0osU0FBUyxFQUFDLGtCQUFrQjtZQUFDLGNBQVcsY0FBYztZQUFBQyxRQUFBLEVBQUM7VUFFaEUsQ0FBUyxDQUFDLGVBQ1YsSUFBQWpCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQzFCLGFBQUEsQ0FBQThCLFlBQVk7WUFBQ0MsSUFBSSxFQUFFLElBQUFHLGlCQUFTLEVBQUNqQixPQUFPLENBQUU7WUFBQ0ssU0FBUyxFQUFDLDBCQUEwQjtZQUFBQyxRQUFBLEVBQUM7VUFFN0UsQ0FBYyxDQUFDO1FBQUEsQ0FDUixDQUFDLGdCQUVWLElBQUFqQixXQUFBLENBQUFvQixHQUFBLEVBQUMxQixhQUFBLENBQUE4QixZQUFZO1VBQUNDLElBQUksRUFBRSxJQUFBRyxpQkFBUyxFQUFDakIsT0FBTyxDQUFFO1VBQUNLLFNBQVMsRUFBQyxvQkFBb0I7VUFBQUMsUUFBQSxFQUFDO1FBRXZFLENBQWMsQ0FDZjtNQUFBLENBQ0UsQ0FBQztJQUFBLENBQ0gsQ0FBQyxFQUNMLENBQUNILE1BQU0saUJBQUksSUFBQWQsV0FBQSxDQUFBb0IsR0FBQSxFQUFDeEIsWUFBQSxDQUFBTyxPQUFXO01BQUNRLE9BQU8sRUFBRUE7SUFBUSxDQUFFLENBQUM7RUFBQSxDQUMxQyxDQUFDO0FBRVY7QUFBQ2tCLEVBQUEsR0FqRHVCbkIsZUFBZTtBQUFBLElBQUFtQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}