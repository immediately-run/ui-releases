var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ProjectMark;
var _recents = require("../lib/recents");
var _jsxRuntime = require("react/jsx-runtime");
// The featured card's decorative panel — derived, never fetched. A 45° hatch
// over a radial wash whose hue is a deterministic hash of the repository
// coordinates, with the repository name as a chip in the corner. Home holds
// no capability that could fetch a screenshot or a favicon, and a launcher
// making a third-party request is what the sandbox exists to prevent. The
// one inline style here is the hue custom property.
function ProjectMark({
  project
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "rec-mark",
    style: {
      '--rec-hue': (0, _recents.recentsHue)(project)
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rec-mark__chip",
      children: project.repository
    })
  });
}
_c = ProjectMark;
var _c;
$RefreshReg$(_c, "ProjectMark");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVjZW50cyIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIlByb2plY3RNYXJrIiwicHJvamVjdCIsImpzeCIsImNsYXNzTmFtZSIsInN0eWxlIiwicmVjZW50c0h1ZSIsImNoaWxkcmVuIiwicmVwb3NpdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvamVjdE1hcmsudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ1NTUHJvcGVydGllcyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgUmVjZW50UHJvamVjdCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHJlY2VudHNIdWUgfSBmcm9tICcuLi9saWIvcmVjZW50cyc7XG5cbi8vIFRoZSBmZWF0dXJlZCBjYXJkJ3MgZGVjb3JhdGl2ZSBwYW5lbCDigJQgZGVyaXZlZCwgbmV2ZXIgZmV0Y2hlZC4gQSA0NcKwIGhhdGNoXG4vLyBvdmVyIGEgcmFkaWFsIHdhc2ggd2hvc2UgaHVlIGlzIGEgZGV0ZXJtaW5pc3RpYyBoYXNoIG9mIHRoZSByZXBvc2l0b3J5XG4vLyBjb29yZGluYXRlcywgd2l0aCB0aGUgcmVwb3NpdG9yeSBuYW1lIGFzIGEgY2hpcCBpbiB0aGUgY29ybmVyLiBIb21lIGhvbGRzXG4vLyBubyBjYXBhYmlsaXR5IHRoYXQgY291bGQgZmV0Y2ggYSBzY3JlZW5zaG90IG9yIGEgZmF2aWNvbiwgYW5kIGEgbGF1bmNoZXJcbi8vIG1ha2luZyBhIHRoaXJkLXBhcnR5IHJlcXVlc3QgaXMgd2hhdCB0aGUgc2FuZGJveCBleGlzdHMgdG8gcHJldmVudC4gVGhlXG4vLyBvbmUgaW5saW5lIHN0eWxlIGhlcmUgaXMgdGhlIGh1ZSBjdXN0b20gcHJvcGVydHkuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2plY3RNYXJrKHsgcHJvamVjdCB9OiB7IHByb2plY3Q6IFJlY2VudFByb2plY3QgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjLW1hcmtcIiBzdHlsZT17eyAnLS1yZWMtaHVlJzogcmVjZW50c0h1ZShwcm9qZWN0KSB9IGFzIENTU1Byb3BlcnRpZXN9PlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVjLW1hcmtfX2NoaXBcIj57cHJvamVjdC5yZXBvc2l0b3J5fTwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsUUFBQSxHQUFBQyxPQUFBO0FBQTRDLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUU1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFZSxTQUFTRSxXQUFXQSxDQUFDO0VBQUVDO0FBQW9DLENBQUMsRUFBRTtFQUMzRSxvQkFDRSxJQUFBRixXQUFBLENBQUFHLEdBQUE7SUFBS0MsU0FBUyxFQUFDLFVBQVU7SUFBQ0MsS0FBSyxFQUFFO01BQUUsV0FBVyxFQUFFLElBQUFDLG1CQUFVLEVBQUNKLE9BQU87SUFBRSxDQUFtQjtJQUFBSyxRQUFBLGVBQ3JGLElBQUFQLFdBQUEsQ0FBQUcsR0FBQTtNQUFNQyxTQUFTLEVBQUMsZ0JBQWdCO01BQUFHLFFBQUEsRUFBRUwsT0FBTyxDQUFDTTtJQUFVLENBQU87RUFBQyxDQUN6RCxDQUFDO0FBRVY7QUFBQ0MsRUFBQSxHQU51QlIsV0FBVztBQUFBLElBQUFRLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}