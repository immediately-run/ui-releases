var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Skeleton;
require("../styles/skeleton.css");
var _jsxRuntime = require("react/jsx-runtime");
/** The auth-resolving state: the greeting row and four row placeholders,
 *  and nothing else — no sign-in prompt, no flash. */function Skeleton() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "skel",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "skel__greet",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "skel__title"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "skel__actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "skel__pill skel__pill--a"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "skel__pill skel__pill--b"
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "skel__rows",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "skel__eyebrow"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "skel__feat"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "skel__row"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "skel__row"
      })]
    })]
  });
}
_c = Skeleton;
var _c;
$RefreshReg$(_c, "Skeleton");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJTa2VsZXRvbiIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2tlbGV0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL3NrZWxldG9uLmNzcyc7XG5cbi8qKiBUaGUgYXV0aC1yZXNvbHZpbmcgc3RhdGU6IHRoZSBncmVldGluZyByb3cgYW5kIGZvdXIgcm93IHBsYWNlaG9sZGVycyxcbiAqICBhbmQgbm90aGluZyBlbHNlIOKAlCBubyBzaWduLWluIHByb21wdCwgbm8gZmxhc2guICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tlbF9fZ3JlZXRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsX190aXRsZVwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tlbF9fYWN0aW9uc1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tlbF9fcGlsbCBza2VsX19waWxsLS1hXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxfX3BpbGwgc2tlbF9fcGlsbC0tYlwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxfX3Jvd3NcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsX19leWVicm93XCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsX19mZWF0XCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsX19yb3dcIiAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxfX3Jvd1wiIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUFBLE9BQUE7QUFBZ0MsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRWhDO0FBQ0Esc0RBQ2UsU0FBU0UsUUFBUUEsQ0FBQSxFQUFHO0VBQ2pDLG9CQUNFLElBQUFELFdBQUEsQ0FBQUUsSUFBQTtJQUFLQyxTQUFTLEVBQUMsTUFBTTtJQUFBQyxRQUFBLGdCQUNuQixJQUFBSixXQUFBLENBQUFFLElBQUE7TUFBS0MsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxnQkFDMUIsSUFBQUosV0FBQSxDQUFBSyxHQUFBO1FBQUtGLFNBQVMsRUFBQztNQUFhLENBQUUsQ0FBQyxlQUMvQixJQUFBSCxXQUFBLENBQUFFLElBQUE7UUFBS0MsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxnQkFDNUIsSUFBQUosV0FBQSxDQUFBSyxHQUFBO1VBQUtGLFNBQVMsRUFBQztRQUEwQixDQUFFLENBQUMsZUFDNUMsSUFBQUgsV0FBQSxDQUFBSyxHQUFBO1VBQUtGLFNBQVMsRUFBQztRQUEwQixDQUFFLENBQUM7TUFBQSxDQUN6QyxDQUFDO0lBQUEsQ0FDSCxDQUFDLGVBQ04sSUFBQUgsV0FBQSxDQUFBRSxJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUFKLFdBQUEsQ0FBQUssR0FBQTtRQUFLRixTQUFTLEVBQUM7TUFBZSxDQUFFLENBQUMsZUFDakMsSUFBQUgsV0FBQSxDQUFBSyxHQUFBO1FBQUtGLFNBQVMsRUFBQztNQUFZLENBQUUsQ0FBQyxlQUM5QixJQUFBSCxXQUFBLENBQUFLLEdBQUE7UUFBS0YsU0FBUyxFQUFDO01BQVcsQ0FBRSxDQUFDLGVBQzdCLElBQUFILFdBQUEsQ0FBQUssR0FBQTtRQUFLRixTQUFTLEVBQUM7TUFBVyxDQUFFLENBQUM7SUFBQSxDQUMxQixDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ0csRUFBQSxHQWxCdUJMLFFBQVE7QUFBQSxJQUFBSyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}