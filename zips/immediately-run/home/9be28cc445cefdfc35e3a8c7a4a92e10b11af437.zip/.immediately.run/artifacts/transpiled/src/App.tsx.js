var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
require("./index.css");
require("./styles/app.css");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _omnibox = require("@immediately-run/omnibox");
var _Footer = _interopRequireDefault(require("./components/Footer"));
var _Greeting = _interopRequireDefault(require("./components/Greeting"));
var _LinkTile = _interopRequireDefault(require("./components/LinkTile"));
var _RecentProjects = _interopRequireDefault(require("./components/RecentProjects"));
var _Skeleton = _interopRequireDefault(require("./components/Skeleton"));
var _Spaces = _interopRequireDefault(require("./components/Spaces"));
var _recents = require("./lib/recents");
var _primary = require("./lib/primary");
var _routes = require("./lib/routes");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The record's one read site — exactly one caller per mount, so the grep for
// the platform call lands on a single line (import alias `readRecents`).
// A read's outcome plus the clock reading it was taken against — labels are
// relative to the read, and the purity rule keeps Date.now() out of render.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  const {
    status
  } = (0, _sdk.useAuth)();
  const formFactor = (0, _sdk.useFormFactor)();
  // The one read of the host-owned record, on mount — no polling, no
  // re-read on focus. The raw result (list, null, or the refusal's code)
  // goes into state and every decision about it runs through the pure
  // module during render, so a failure that is not `forbidden` reaches the
  // error boundary instead of masquerading as "recents are off".
  const [raw, setRaw] = (0, _react.useState)();
  (0, _react.useEffect)(() => {
    let alive = true;
    const now = Date.now();
    (0, _sdk.listRecentProjects)().then(projects => {
      if (alive) setRaw({
        projects,
        now
      });
    }, err => {
      if (alive) setRaw({
        projects: err,
        now
      });
    });
    return () => {
      alive = false;
    };
  }, []);

  // A signed-out render is impossible by construction — the home mode is
  // signed-in only, and the host draws its own sign-in posture outside this
  // frame. Say it once and render nothing rather than inventing a prompt
  // (which would be imitating host chrome). The effect, not the render, owns
  // the log so it fires once per arrival at the state, not per re-render.
  (0, _react.useEffect)(() => {
    if (status === 'signed-out') {
      console.warn('home: rendered signed out, which the home mode forbids — the host should have drawn its sign-in posture');
    }
  }, [status]);

  // The paste box's open state and its focus wiring sit with the other hooks —
  // hooks never come after the auth early-returns below.
  const [omniboxOpen, setOmniboxOpen] = (0, _react.useState)(false);
  const pasteToggle = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (omniboxOpen) (0, _omnibox.focusHeroOmnibox)();
  }, [omniboxOpen]);
  if (status === 'unknown') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `page page--${formFactor.class}`,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Skeleton.default, {})
    });
  }
  if (status === 'signed-out') {
    return null;
  }

  // The static half renders while the read is in flight; the featured
  // recent's Open becomes the gradient primary only once a list is on
  // screen, and falls back to the create door when the record is absent.
  // The paste box is the third owner of that primary: while it is open, its
  // Run is the primary and every other candidate is hairline.
  const recents = raw === undefined ? undefined : (0, _recents.recentsState)(raw.projects);
  const primaryTarget = (0, _primary.primary)({
    hasRecents: recents?.kind === 'list',
    omniboxOpen
  });
  const mobile = formFactor.class === 'mobile';
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: `page page--${formFactor.class}`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Greeting.default, {
      primary: primaryTarget,
      omniboxOpen: omniboxOpen,
      onToggle: () => setOmniboxOpen(open => !open),
      toggleRef: pasteToggle,
      onOmniboxKeyDown: e => {
        // The package's Escape clears and blurs its panel; closing the
        // block and handing focus back to the toggle is Home's half.
        if (e.key === 'Escape') {
          setOmniboxOpen(false);
          pasteToggle.current?.focus();
        }
      }
    }), recents !== undefined && raw !== undefined && /*#__PURE__*/(0, _jsxRuntime.jsx)(_RecentProjects.default, {
      state: recents,
      now: raw.now,
      primary: primaryTarget === 'recents',
      mobile: mobile,
      onCleared: () => setRaw({
        projects: null,
        now: Date.now()
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Spaces.default, {
      layout: mobile ? 'strip' : 'list'
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tiles",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_LinkTile.default, {
        tag: "/MODEL",
        body: "Connect a language model to use the built-in agent in any app.",
        linkLabel: "Language model settings \u2192",
        to: _routes.SETTINGS_LANGUAGE_MODEL
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_LinkTile.default, {
        tag: "/NEWS",
        title: "Notifications",
        linkLabel: "Open \u2192",
        to: _routes.NOTIFICATIONS,
        linkToEnd: true
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Footer.default, {})]
  });
}
_s(App, "6Cp9tWEX4guH9EoGScwEAIhZB7o=", false, function () {
  return [_sdk.useAuth, _sdk.useFormFactor];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3JlYWN0IiwiX3NkayIsIl9vbW5pYm94IiwiX0Zvb3RlciIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfR3JlZXRpbmciLCJfTGlua1RpbGUiLCJfUmVjZW50UHJvamVjdHMiLCJfU2tlbGV0b24iLCJfU3BhY2VzIiwiX3JlY2VudHMiLCJfcHJpbWFyeSIsIl9yb3V0ZXMiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwic3RhdHVzIiwidXNlQXV0aCIsImZvcm1GYWN0b3IiLCJ1c2VGb3JtRmFjdG9yIiwicmF3Iiwic2V0UmF3IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhbGl2ZSIsIm5vdyIsIkRhdGUiLCJyZWFkUmVjZW50cyIsInRoZW4iLCJwcm9qZWN0cyIsImVyciIsImNvbnNvbGUiLCJ3YXJuIiwib21uaWJveE9wZW4iLCJzZXRPbW5pYm94T3BlbiIsInBhc3RlVG9nZ2xlIiwidXNlUmVmIiwiZm9jdXNIZXJvT21uaWJveCIsImpzeCIsImNsYXNzTmFtZSIsImNsYXNzIiwiY2hpbGRyZW4iLCJyZWNlbnRzIiwidW5kZWZpbmVkIiwicmVjZW50c1N0YXRlIiwicHJpbWFyeVRhcmdldCIsInByaW1hcnkiLCJoYXNSZWNlbnRzIiwia2luZCIsIm1vYmlsZSIsImpzeHMiLCJvblRvZ2dsZSIsIm9wZW4iLCJ0b2dnbGVSZWYiLCJvbk9tbmlib3hLZXlEb3duIiwia2V5IiwiY3VycmVudCIsImZvY3VzIiwic3RhdGUiLCJvbkNsZWFyZWQiLCJsYXlvdXQiLCJ0YWciLCJib2R5IiwibGlua0xhYmVsIiwidG8iLCJTRVRUSU5HU19MQU5HVUFHRV9NT0RFTCIsInRpdGxlIiwiTk9USUZJQ0FUSU9OUyIsImxpbmtUb0VuZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4vaW5kZXguY3NzJztcbmltcG9ydCAnLi9zdHlsZXMvYXBwLmNzcyc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG4vLyBUaGUgcmVjb3JkJ3Mgb25lIHJlYWQgc2l0ZSDigJQgZXhhY3RseSBvbmUgY2FsbGVyIHBlciBtb3VudCwgc28gdGhlIGdyZXAgZm9yXG4vLyB0aGUgcGxhdGZvcm0gY2FsbCBsYW5kcyBvbiBhIHNpbmdsZSBsaW5lIChpbXBvcnQgYWxpYXMgYHJlYWRSZWNlbnRzYCkuXG5pbXBvcnQgeyB1c2VBdXRoLCB1c2VGb3JtRmFjdG9yLCBsaXN0UmVjZW50UHJvamVjdHMgYXMgcmVhZFJlY2VudHMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFJlY2VudFByb2plY3QgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBmb2N1c0hlcm9PbW5pYm94IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9vbW5pYm94JztcbmltcG9ydCBGb290ZXIgZnJvbSAnLi9jb21wb25lbnRzL0Zvb3Rlcic7XG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi9jb21wb25lbnRzL0dyZWV0aW5nJztcbmltcG9ydCBMaW5rVGlsZSBmcm9tICcuL2NvbXBvbmVudHMvTGlua1RpbGUnO1xuaW1wb3J0IFJlY2VudFByb2plY3RzIGZyb20gJy4vY29tcG9uZW50cy9SZWNlbnRQcm9qZWN0cyc7XG5pbXBvcnQgU2tlbGV0b24gZnJvbSAnLi9jb21wb25lbnRzL1NrZWxldG9uJztcbmltcG9ydCBTcGFjZXMgZnJvbSAnLi9jb21wb25lbnRzL1NwYWNlcyc7XG5pbXBvcnQgeyByZWNlbnRzU3RhdGUgfSBmcm9tICcuL2xpYi9yZWNlbnRzJztcbmltcG9ydCB0eXBlIHsgUmVjZW50UmVmdXNhbCwgUmVjZW50c1N0YXRlIH0gZnJvbSAnLi9saWIvcmVjZW50cyc7XG5pbXBvcnQgeyBwcmltYXJ5IH0gZnJvbSAnLi9saWIvcHJpbWFyeSc7XG5pbXBvcnQgeyBOT1RJRklDQVRJT05TLCBTRVRUSU5HU19MQU5HVUFHRV9NT0RFTCB9IGZyb20gJy4vbGliL3JvdXRlcyc7XG5cbi8vIEEgcmVhZCdzIG91dGNvbWUgcGx1cyB0aGUgY2xvY2sgcmVhZGluZyBpdCB3YXMgdGFrZW4gYWdhaW5zdCDigJQgbGFiZWxzIGFyZVxuLy8gcmVsYXRpdmUgdG8gdGhlIHJlYWQsIGFuZCB0aGUgcHVyaXR5IHJ1bGUga2VlcHMgRGF0ZS5ub3coKSBvdXQgb2YgcmVuZGVyLlxuaW50ZXJmYWNlIFJhd1JlY2VudHMge1xuICBwcm9qZWN0czogUmVjZW50UHJvamVjdFtdIHwgbnVsbCB8IFJlY2VudFJlZnVzYWw7XG4gIG5vdzogbnVtYmVyO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHsgc3RhdHVzIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGZvcm1GYWN0b3IgPSB1c2VGb3JtRmFjdG9yKCk7XG4gIC8vIFRoZSBvbmUgcmVhZCBvZiB0aGUgaG9zdC1vd25lZCByZWNvcmQsIG9uIG1vdW50IOKAlCBubyBwb2xsaW5nLCBub1xuICAvLyByZS1yZWFkIG9uIGZvY3VzLiBUaGUgcmF3IHJlc3VsdCAobGlzdCwgbnVsbCwgb3IgdGhlIHJlZnVzYWwncyBjb2RlKVxuICAvLyBnb2VzIGludG8gc3RhdGUgYW5kIGV2ZXJ5IGRlY2lzaW9uIGFib3V0IGl0IHJ1bnMgdGhyb3VnaCB0aGUgcHVyZVxuICAvLyBtb2R1bGUgZHVyaW5nIHJlbmRlciwgc28gYSBmYWlsdXJlIHRoYXQgaXMgbm90IGBmb3JiaWRkZW5gIHJlYWNoZXMgdGhlXG4gIC8vIGVycm9yIGJvdW5kYXJ5IGluc3RlYWQgb2YgbWFzcXVlcmFkaW5nIGFzIFwicmVjZW50cyBhcmUgb2ZmXCIuXG4gIGNvbnN0IFtyYXcsIHNldFJhd10gPSB1c2VTdGF0ZTxSYXdSZWNlbnRzPigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGFsaXZlID0gdHJ1ZTtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIHJlYWRSZWNlbnRzKCkudGhlbihcbiAgICAgIChwcm9qZWN0cykgPT4ge1xuICAgICAgICBpZiAoYWxpdmUpIHNldFJhdyh7IHByb2plY3RzLCBub3cgfSk7XG4gICAgICB9LFxuICAgICAgKGVycjogUmVjZW50UmVmdXNhbCkgPT4ge1xuICAgICAgICBpZiAoYWxpdmUpIHNldFJhdyh7IHByb2plY3RzOiBlcnIsIG5vdyB9KTtcbiAgICAgIH0sXG4gICAgKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWxpdmUgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgLy8gQSBzaWduZWQtb3V0IHJlbmRlciBpcyBpbXBvc3NpYmxlIGJ5IGNvbnN0cnVjdGlvbiDigJQgdGhlIGhvbWUgbW9kZSBpc1xuICAvLyBzaWduZWQtaW4gb25seSwgYW5kIHRoZSBob3N0IGRyYXdzIGl0cyBvd24gc2lnbi1pbiBwb3N0dXJlIG91dHNpZGUgdGhpc1xuICAvLyBmcmFtZS4gU2F5IGl0IG9uY2UgYW5kIHJlbmRlciBub3RoaW5nIHJhdGhlciB0aGFuIGludmVudGluZyBhIHByb21wdFxuICAvLyAod2hpY2ggd291bGQgYmUgaW1pdGF0aW5nIGhvc3QgY2hyb21lKS4gVGhlIGVmZmVjdCwgbm90IHRoZSByZW5kZXIsIG93bnNcbiAgLy8gdGhlIGxvZyBzbyBpdCBmaXJlcyBvbmNlIHBlciBhcnJpdmFsIGF0IHRoZSBzdGF0ZSwgbm90IHBlciByZS1yZW5kZXIuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHN0YXR1cyA9PT0gJ3NpZ25lZC1vdXQnKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ2hvbWU6IHJlbmRlcmVkIHNpZ25lZCBvdXQsIHdoaWNoIHRoZSBob21lIG1vZGUgZm9yYmlkcyDigJQgdGhlIGhvc3Qgc2hvdWxkIGhhdmUgZHJhd24gaXRzIHNpZ24taW4gcG9zdHVyZScpO1xuICAgIH1cbiAgfSwgW3N0YXR1c10pO1xuXG4gIC8vIFRoZSBwYXN0ZSBib3gncyBvcGVuIHN0YXRlIGFuZCBpdHMgZm9jdXMgd2lyaW5nIHNpdCB3aXRoIHRoZSBvdGhlciBob29rcyDigJRcbiAgLy8gaG9va3MgbmV2ZXIgY29tZSBhZnRlciB0aGUgYXV0aCBlYXJseS1yZXR1cm5zIGJlbG93LlxuICBjb25zdCBbb21uaWJveE9wZW4sIHNldE9tbmlib3hPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgcGFzdGVUb2dnbGUgPSB1c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG9tbmlib3hPcGVuKSBmb2N1c0hlcm9PbW5pYm94KCk7XG4gIH0sIFtvbW5pYm94T3Blbl0pO1xuXG4gIGlmIChzdGF0dXMgPT09ICd1bmtub3duJykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YHBhZ2UgcGFnZS0tJHtmb3JtRmFjdG9yLmNsYXNzfWB9PlxuICAgICAgICA8U2tlbGV0b24gLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoc3RhdHVzID09PSAnc2lnbmVkLW91dCcpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIFRoZSBzdGF0aWMgaGFsZiByZW5kZXJzIHdoaWxlIHRoZSByZWFkIGlzIGluIGZsaWdodDsgdGhlIGZlYXR1cmVkXG4gIC8vIHJlY2VudCdzIE9wZW4gYmVjb21lcyB0aGUgZ3JhZGllbnQgcHJpbWFyeSBvbmx5IG9uY2UgYSBsaXN0IGlzIG9uXG4gIC8vIHNjcmVlbiwgYW5kIGZhbGxzIGJhY2sgdG8gdGhlIGNyZWF0ZSBkb29yIHdoZW4gdGhlIHJlY29yZCBpcyBhYnNlbnQuXG4gIC8vIFRoZSBwYXN0ZSBib3ggaXMgdGhlIHRoaXJkIG93bmVyIG9mIHRoYXQgcHJpbWFyeTogd2hpbGUgaXQgaXMgb3BlbiwgaXRzXG4gIC8vIFJ1biBpcyB0aGUgcHJpbWFyeSBhbmQgZXZlcnkgb3RoZXIgY2FuZGlkYXRlIGlzIGhhaXJsaW5lLlxuICBjb25zdCByZWNlbnRzOiBSZWNlbnRzU3RhdGUgfCB1bmRlZmluZWQgPSByYXcgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHJlY2VudHNTdGF0ZShyYXcucHJvamVjdHMpO1xuICBjb25zdCBwcmltYXJ5VGFyZ2V0ID0gcHJpbWFyeSh7XG4gICAgaGFzUmVjZW50czogcmVjZW50cz8ua2luZCA9PT0gJ2xpc3QnLFxuICAgIG9tbmlib3hPcGVuLFxuICB9KTtcbiAgY29uc3QgbW9iaWxlID0gZm9ybUZhY3Rvci5jbGFzcyA9PT0gJ21vYmlsZSc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHBhZ2UgcGFnZS0tJHtmb3JtRmFjdG9yLmNsYXNzfWB9PlxuICAgICAgPEdyZWV0aW5nXG4gICAgICAgIHByaW1hcnk9e3ByaW1hcnlUYXJnZXR9XG4gICAgICAgIG9tbmlib3hPcGVuPXtvbW5pYm94T3Blbn1cbiAgICAgICAgb25Ub2dnbGU9eygpID0+IHNldE9tbmlib3hPcGVuKChvcGVuKSA9PiAhb3Blbil9XG4gICAgICAgIHRvZ2dsZVJlZj17cGFzdGVUb2dnbGV9XG4gICAgICAgIG9uT21uaWJveEtleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgLy8gVGhlIHBhY2thZ2UncyBFc2NhcGUgY2xlYXJzIGFuZCBibHVycyBpdHMgcGFuZWw7IGNsb3NpbmcgdGhlXG4gICAgICAgICAgLy8gYmxvY2sgYW5kIGhhbmRpbmcgZm9jdXMgYmFjayB0byB0aGUgdG9nZ2xlIGlzIEhvbWUncyBoYWxmLlxuICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgICAgIHNldE9tbmlib3hPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIHBhc3RlVG9nZ2xlLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICAgIHtyZWNlbnRzICE9PSB1bmRlZmluZWQgJiYgcmF3ICE9PSB1bmRlZmluZWQgJiYgKFxuICAgICAgICA8UmVjZW50UHJvamVjdHNcbiAgICAgICAgICBzdGF0ZT17cmVjZW50c31cbiAgICAgICAgICBub3c9e3Jhdy5ub3d9XG4gICAgICAgICAgcHJpbWFyeT17cHJpbWFyeVRhcmdldCA9PT0gJ3JlY2VudHMnfVxuICAgICAgICAgIG1vYmlsZT17bW9iaWxlfVxuICAgICAgICAgIG9uQ2xlYXJlZD17KCkgPT4gc2V0UmF3KHsgcHJvamVjdHM6IG51bGwsIG5vdzogRGF0ZS5ub3coKSB9KX1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgICA8U3BhY2VzIGxheW91dD17bW9iaWxlID8gJ3N0cmlwJyA6ICdsaXN0J30gLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlsZXNcIj5cbiAgICAgICAgPExpbmtUaWxlXG4gICAgICAgICAgdGFnPVwiL01PREVMXCJcbiAgICAgICAgICBib2R5PVwiQ29ubmVjdCBhIGxhbmd1YWdlIG1vZGVsIHRvIHVzZSB0aGUgYnVpbHQtaW4gYWdlbnQgaW4gYW55IGFwcC5cIlxuICAgICAgICAgIGxpbmtMYWJlbD1cIkxhbmd1YWdlIG1vZGVsIHNldHRpbmdzIOKGklwiXG4gICAgICAgICAgdG89e1NFVFRJTkdTX0xBTkdVQUdFX01PREVMfVxuICAgICAgICAvPlxuICAgICAgICA8TGlua1RpbGVcbiAgICAgICAgICB0YWc9XCIvTkVXU1wiXG4gICAgICAgICAgdGl0bGU9XCJOb3RpZmljYXRpb25zXCJcbiAgICAgICAgICBsaW5rTGFiZWw9XCJPcGVuIOKGklwiXG4gICAgICAgICAgdG89e05PVElGSUNBVElPTlN9XG4gICAgICAgICAgbGlua1RvRW5kXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUFBLE9BQUE7QUFDQUEsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUdBLElBQUFFLElBQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLE9BQUEsR0FBQUMsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFNLFNBQUEsR0FBQUQsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFPLFNBQUEsR0FBQUYsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFRLGVBQUEsR0FBQUgsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFTLFNBQUEsR0FBQUosc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFVLE9BQUEsR0FBQUwsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFXLFFBQUEsR0FBQVgsT0FBQTtBQUVBLElBQUFZLFFBQUEsR0FBQVosT0FBQTtBQUNBLElBQUFhLE9BQUEsR0FBQWIsT0FBQTtBQUFzRSxJQUFBYyxXQUFBLEdBQUFkLE9BQUE7QUFBQSxJQUFBZSxFQUFBLEdBQUFDLFlBQUEsSUFkdEU7QUFDQTtBQWVBO0FBQ0E7QUFBQSxTQUFBWCx1QkFBQVksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQU1lLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQzVCLE1BQU07SUFBRU07RUFBTyxDQUFDLEdBQUcsSUFBQUMsWUFBTyxFQUFDLENBQUM7RUFDNUIsTUFBTUMsVUFBVSxHQUFHLElBQUFDLGtCQUFhLEVBQUMsQ0FBQztFQUNsQztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDQyxHQUFHLEVBQUVDLE1BQU0sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBYSxDQUFDO0VBRTVDLElBQUFDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlDLEtBQUssR0FBRyxJQUFJO0lBQ2hCLE1BQU1DLEdBQUcsR0FBR0MsSUFBSSxDQUFDRCxHQUFHLENBQUMsQ0FBQztJQUN0QixJQUFBRSx1QkFBVyxFQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUNmQyxRQUFRLElBQUs7TUFDWixJQUFJTCxLQUFLLEVBQUVILE1BQU0sQ0FBQztRQUFFUSxRQUFRO1FBQUVKO01BQUksQ0FBQyxDQUFDO0lBQ3RDLENBQUMsRUFDQUssR0FBa0IsSUFBSztNQUN0QixJQUFJTixLQUFLLEVBQUVILE1BQU0sQ0FBQztRQUFFUSxRQUFRLEVBQUVDLEdBQUc7UUFBRUw7TUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FDRixDQUFDO0lBQ0QsT0FBTyxNQUFNO01BQ1hELEtBQUssR0FBRyxLQUFLO0lBQ2YsQ0FBQztFQUNILENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUFELGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlQLE1BQU0sS0FBSyxZQUFZLEVBQUU7TUFDM0JlLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLHlHQUF5RyxDQUFDO0lBQ3pIO0VBQ0YsQ0FBQyxFQUFFLENBQUNoQixNQUFNLENBQUMsQ0FBQzs7RUFFWjtFQUNBO0VBQ0EsTUFBTSxDQUFDaUIsV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBRyxJQUFBWixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ3JELE1BQU1hLFdBQVcsR0FBRyxJQUFBQyxhQUFNLEVBQW9CLElBQUksQ0FBQztFQUVuRCxJQUFBYixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJVSxXQUFXLEVBQUUsSUFBQUkseUJBQWdCLEVBQUMsQ0FBQztFQUNyQyxDQUFDLEVBQUUsQ0FBQ0osV0FBVyxDQUFDLENBQUM7RUFFakIsSUFBSWpCLE1BQU0sS0FBSyxTQUFTLEVBQUU7SUFDeEIsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBNkIsR0FBQTtNQUFLQyxTQUFTLEVBQUUsY0FBY3JCLFVBQVUsQ0FBQ3NCLEtBQUssRUFBRztNQUFBQyxRQUFBLGVBQy9DLElBQUFoQyxXQUFBLENBQUE2QixHQUFBLEVBQUNsQyxTQUFBLENBQUFVLE9BQVEsSUFBRTtJQUFDLENBQ1QsQ0FBQztFQUVWO0VBRUEsSUFBSUUsTUFBTSxLQUFLLFlBQVksRUFBRTtJQUMzQixPQUFPLElBQUk7RUFDYjs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTBCLE9BQWlDLEdBQUd0QixHQUFHLEtBQUt1QixTQUFTLEdBQUdBLFNBQVMsR0FBRyxJQUFBQyxxQkFBWSxFQUFDeEIsR0FBRyxDQUFDUyxRQUFRLENBQUM7RUFDcEcsTUFBTWdCLGFBQWEsR0FBRyxJQUFBQyxnQkFBTyxFQUFDO0lBQzVCQyxVQUFVLEVBQUVMLE9BQU8sRUFBRU0sSUFBSSxLQUFLLE1BQU07SUFDcENmO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsTUFBTWdCLE1BQU0sR0FBRy9CLFVBQVUsQ0FBQ3NCLEtBQUssS0FBSyxRQUFRO0VBRTVDLG9CQUNFLElBQUEvQixXQUFBLENBQUF5QyxJQUFBO0lBQUtYLFNBQVMsRUFBRSxjQUFjckIsVUFBVSxDQUFDc0IsS0FBSyxFQUFHO0lBQUFDLFFBQUEsZ0JBQy9DLElBQUFoQyxXQUFBLENBQUE2QixHQUFBLEVBQUNyQyxTQUFBLENBQUFhLE9BQVE7TUFDUGdDLE9BQU8sRUFBRUQsYUFBYztNQUN2QlosV0FBVyxFQUFFQSxXQUFZO01BQ3pCa0IsUUFBUSxFQUFFQSxDQUFBLEtBQU1qQixjQUFjLENBQUVrQixJQUFJLElBQUssQ0FBQ0EsSUFBSSxDQUFFO01BQ2hEQyxTQUFTLEVBQUVsQixXQUFZO01BQ3ZCbUIsZ0JBQWdCLEVBQUcxQyxDQUFDLElBQUs7UUFDdkI7UUFDQTtRQUNBLElBQUlBLENBQUMsQ0FBQzJDLEdBQUcsS0FBSyxRQUFRLEVBQUU7VUFDdEJyQixjQUFjLENBQUMsS0FBSyxDQUFDO1VBQ3JCQyxXQUFXLENBQUNxQixPQUFPLEVBQUVDLEtBQUssQ0FBQyxDQUFDO1FBQzlCO01BQ0Y7SUFBRSxDQUNILENBQUMsRUFDRGYsT0FBTyxLQUFLQyxTQUFTLElBQUl2QixHQUFHLEtBQUt1QixTQUFTLGlCQUN6QyxJQUFBbEMsV0FBQSxDQUFBNkIsR0FBQSxFQUFDbkMsZUFBQSxDQUFBVyxPQUFjO01BQ2I0QyxLQUFLLEVBQUVoQixPQUFRO01BQ2ZqQixHQUFHLEVBQUVMLEdBQUcsQ0FBQ0ssR0FBSTtNQUNicUIsT0FBTyxFQUFFRCxhQUFhLEtBQUssU0FBVTtNQUNyQ0ksTUFBTSxFQUFFQSxNQUFPO01BQ2ZVLFNBQVMsRUFBRUEsQ0FBQSxLQUFNdEMsTUFBTSxDQUFDO1FBQUVRLFFBQVEsRUFBRSxJQUFJO1FBQUVKLEdBQUcsRUFBRUMsSUFBSSxDQUFDRCxHQUFHLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FDOUQsQ0FDRixlQUNELElBQUFoQixXQUFBLENBQUE2QixHQUFBLEVBQUNqQyxPQUFBLENBQUFTLE9BQU07TUFBQzhDLE1BQU0sRUFBRVgsTUFBTSxHQUFHLE9BQU8sR0FBRztJQUFPLENBQUUsQ0FBQyxlQUM3QyxJQUFBeEMsV0FBQSxDQUFBeUMsSUFBQTtNQUFLWCxTQUFTLEVBQUMsT0FBTztNQUFBRSxRQUFBLGdCQUNwQixJQUFBaEMsV0FBQSxDQUFBNkIsR0FBQSxFQUFDcEMsU0FBQSxDQUFBWSxPQUFRO1FBQ1ArQyxHQUFHLEVBQUMsUUFBUTtRQUNaQyxJQUFJLEVBQUMsZ0VBQWdFO1FBQ3JFQyxTQUFTLEVBQUMsZ0NBQTJCO1FBQ3JDQyxFQUFFLEVBQUVDO01BQXdCLENBQzdCLENBQUMsZUFDRixJQUFBeEQsV0FBQSxDQUFBNkIsR0FBQSxFQUFDcEMsU0FBQSxDQUFBWSxPQUFRO1FBQ1ArQyxHQUFHLEVBQUMsT0FBTztRQUNYSyxLQUFLLEVBQUMsZUFBZTtRQUNyQkgsU0FBUyxFQUFDLGFBQVE7UUFDbEJDLEVBQUUsRUFBRUcscUJBQWM7UUFDbEJDLFNBQVM7TUFBQSxDQUNWLENBQUM7SUFBQSxDQUNDLENBQUMsZUFDTixJQUFBM0QsV0FBQSxDQUFBNkIsR0FBQSxFQUFDdkMsT0FBQSxDQUFBZSxPQUFNLElBQUUsQ0FBQztFQUFBLENBQ1AsQ0FBQztBQUVWO0FBQUNKLEVBQUEsQ0FsSHVCSyxHQUFHO0VBQUEsUUFDTkUsWUFBTyxFQUNQRSxrQkFBYTtBQUFBO0FBQUFrRCxFQUFBLEdBRlZ0RCxHQUFHO0FBQUEsSUFBQXNELEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}