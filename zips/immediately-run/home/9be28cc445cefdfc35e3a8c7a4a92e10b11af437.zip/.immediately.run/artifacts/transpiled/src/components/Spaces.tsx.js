var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Spaces;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _platformLink = require("@immediately-run/sdk/platformLink");
var _SectionHeading = _interopRequireDefault(require("./SectionHeading"));
var _SpaceRow = _interopRequireDefault(require("./SpaceRow"));
var _spaces = require("../lib/spaces");
var _routes = require("../lib/routes");
require("../styles/spaces.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The one call site — exactly one caller per mount, so the grep for the
// platform call lands on a single line (import alias `readSpaces`).
// The /SPACES section: the user's spaces as a compact list (desktop) or a
// horizontal card strip (phone) — the list and nothing more. Every verb
// beyond listing stays in the space manager (R-SPACES-7): Manage → is the
// only action, and Home never opens a space's files (it holds no mount for
// them). The read happens once, on mount, right here — no polling.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Spaces({
  layout
}) {
  _s();
  const [raw, setRaw] = (0, _react.useState)();
  (0, _react.useEffect)(() => {
    let alive = true;
    (0, _sdk.listAllSpaces)().then(spaces => {
      if (alive) setRaw(spaces);
    }, err => {
      if (alive) setRaw(err);
    });
    return () => {
      alive = false;
    };
  }, []);
  if (raw === undefined) return null;
  const state = (0, _spaces.spacesState)(raw);

  // The header links ride the heading on the desktop layouts (artboards 1a
  // and 1d draw them; the phone 1e heading carries none). Both links target
  // the same path on purpose: the manager renders its create entry whenever
  // it is full-tab with no create-intent parameter (verified 2026-09-04), so
  // there is no `?create=1` for a second link to spell. `?space=<id>`
  // selects the space only for an owner; for a writer or reader the link
  // still lands in the manager, on its list — accepted, not worked around.
  const links = layout === 'list' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      path: (0, _routes.spacesRoute)(),
      children: "All spaces \u2192"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
      path: (0, _routes.spacesRoute)(),
      children: "Create a space \u2192"
    })]
  }) : undefined;
  if (state.kind === 'empty') {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "sp",
      "aria-label": "Your spaces",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_SectionHeading.default, {
        tag: "/SPACES",
        title: "Your spaces.",
        children: links
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "sp-empty-box",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          className: "sp-empty",
          children: "You are not in any space yet. Create one, or wait for an invitation to reach your notifications."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
          path: (0, _routes.spacesRoute)(),
          className: "sp-empty__create",
          children: "Create a space \u2192"
        })]
      })]
    });
  }
  if (state.kind === 'off') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("section", {
      className: "sp",
      "aria-label": "Your spaces",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "sp-off",
        children: ["This version of Home cannot list your spaces.", /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
          path: (0, _routes.spacesRoute)(),
          className: "sp-off__all",
          children: "All spaces \u2192"
        })]
      })
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "sp",
    "aria-label": "Your spaces",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_SectionHeading.default, {
      tag: "/SPACES",
      title: "Your spaces.",
      children: links
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: layout === 'strip' ? 'sp-strip' : 'sp-list',
      children: state.rows.map(row => /*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceRow.default, {
        row: row,
        layout: layout
      }, row.spaceId))
    })]
  });
}
_s(Spaces, "1j45okMAzFskV9P7q99eRGjmLQ8=");
_c = Spaces;
var _c;
$RefreshReg$(_c, "Spaces");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9wbGF0Zm9ybUxpbmsiLCJfU2VjdGlvbkhlYWRpbmciLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1NwYWNlUm93IiwiX3NwYWNlcyIsIl9yb3V0ZXMiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiU3BhY2VzIiwibGF5b3V0IiwicmF3Iiwic2V0UmF3IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhbGl2ZSIsInJlYWRTcGFjZXMiLCJ0aGVuIiwic3BhY2VzIiwiZXJyIiwidW5kZWZpbmVkIiwic3RhdGUiLCJzcGFjZXNTdGF0ZSIsImxpbmtzIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJqc3giLCJQbGF0Zm9ybUxpbmsiLCJwYXRoIiwic3BhY2VzUm91dGUiLCJraW5kIiwiY2xhc3NOYW1lIiwidGFnIiwidGl0bGUiLCJyb3dzIiwibWFwIiwicm93Iiwic3BhY2VJZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3BhY2VzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuLy8gVGhlIG9uZSBjYWxsIHNpdGUg4oCUIGV4YWN0bHkgb25lIGNhbGxlciBwZXIgbW91bnQsIHNvIHRoZSBncmVwIGZvciB0aGVcbi8vIHBsYXRmb3JtIGNhbGwgbGFuZHMgb24gYSBzaW5nbGUgbGluZSAoaW1wb3J0IGFsaWFzIGByZWFkU3BhY2VzYCkuXG5pbXBvcnQgeyBsaXN0QWxsU3BhY2VzIGFzIHJlYWRTcGFjZXMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFNwYWNlSW5mbyB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFBsYXRmb3JtTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL3BsYXRmb3JtTGluayc7XG5pbXBvcnQgU2VjdGlvbkhlYWRpbmcgZnJvbSAnLi9TZWN0aW9uSGVhZGluZyc7XG5pbXBvcnQgU3BhY2VSb3cgZnJvbSAnLi9TcGFjZVJvdyc7XG5pbXBvcnQgeyBzcGFjZXNTdGF0ZSB9IGZyb20gJy4uL2xpYi9zcGFjZXMnO1xuaW1wb3J0IHR5cGUgeyBTcGFjZXNSZWZ1c2FsLCBTcGFjZXNTdGF0ZSB9IGZyb20gJy4uL2xpYi9zcGFjZXMnO1xuaW1wb3J0IHsgc3BhY2VzUm91dGUgfSBmcm9tICcuLi9saWIvcm91dGVzJztcbmltcG9ydCAnLi4vc3R5bGVzL3NwYWNlcy5jc3MnO1xuXG4vLyBUaGUgL1NQQUNFUyBzZWN0aW9uOiB0aGUgdXNlcidzIHNwYWNlcyBhcyBhIGNvbXBhY3QgbGlzdCAoZGVza3RvcCkgb3IgYVxuLy8gaG9yaXpvbnRhbCBjYXJkIHN0cmlwIChwaG9uZSkg4oCUIHRoZSBsaXN0IGFuZCBub3RoaW5nIG1vcmUuIEV2ZXJ5IHZlcmJcbi8vIGJleW9uZCBsaXN0aW5nIHN0YXlzIGluIHRoZSBzcGFjZSBtYW5hZ2VyIChSLVNQQUNFUy03KTogTWFuYWdlIOKGkiBpcyB0aGVcbi8vIG9ubHkgYWN0aW9uLCBhbmQgSG9tZSBuZXZlciBvcGVucyBhIHNwYWNlJ3MgZmlsZXMgKGl0IGhvbGRzIG5vIG1vdW50IGZvclxuLy8gdGhlbSkuIFRoZSByZWFkIGhhcHBlbnMgb25jZSwgb24gbW91bnQsIHJpZ2h0IGhlcmUg4oCUIG5vIHBvbGxpbmcuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNwYWNlcyh7IGxheW91dCB9OiB7IGxheW91dDogJ2xpc3QnIHwgJ3N0cmlwJyB9KSB7XG4gIGNvbnN0IFtyYXcsIHNldFJhd10gPSB1c2VTdGF0ZTxTcGFjZUluZm9bXSB8IFNwYWNlc1JlZnVzYWw+KCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgYWxpdmUgPSB0cnVlO1xuICAgIHJlYWRTcGFjZXMoKS50aGVuKFxuICAgICAgKHNwYWNlcykgPT4ge1xuICAgICAgICBpZiAoYWxpdmUpIHNldFJhdyhzcGFjZXMpO1xuICAgICAgfSxcbiAgICAgIChlcnI6IFNwYWNlc1JlZnVzYWwpID0+IHtcbiAgICAgICAgaWYgKGFsaXZlKSBzZXRSYXcoZXJyKTtcbiAgICAgIH0sXG4gICAgKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWxpdmUgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgaWYgKHJhdyA9PT0gdW5kZWZpbmVkKSByZXR1cm4gbnVsbDtcbiAgY29uc3Qgc3RhdGU6IFNwYWNlc1N0YXRlID0gc3BhY2VzU3RhdGUocmF3KTtcblxuICAvLyBUaGUgaGVhZGVyIGxpbmtzIHJpZGUgdGhlIGhlYWRpbmcgb24gdGhlIGRlc2t0b3AgbGF5b3V0cyAoYXJ0Ym9hcmRzIDFhXG4gIC8vIGFuZCAxZCBkcmF3IHRoZW07IHRoZSBwaG9uZSAxZSBoZWFkaW5nIGNhcnJpZXMgbm9uZSkuIEJvdGggbGlua3MgdGFyZ2V0XG4gIC8vIHRoZSBzYW1lIHBhdGggb24gcHVycG9zZTogdGhlIG1hbmFnZXIgcmVuZGVycyBpdHMgY3JlYXRlIGVudHJ5IHdoZW5ldmVyXG4gIC8vIGl0IGlzIGZ1bGwtdGFiIHdpdGggbm8gY3JlYXRlLWludGVudCBwYXJhbWV0ZXIgKHZlcmlmaWVkIDIwMjYtMDktMDQpLCBzb1xuICAvLyB0aGVyZSBpcyBubyBgP2NyZWF0ZT0xYCBmb3IgYSBzZWNvbmQgbGluayB0byBzcGVsbC4gYD9zcGFjZT08aWQ+YFxuICAvLyBzZWxlY3RzIHRoZSBzcGFjZSBvbmx5IGZvciBhbiBvd25lcjsgZm9yIGEgd3JpdGVyIG9yIHJlYWRlciB0aGUgbGlua1xuICAvLyBzdGlsbCBsYW5kcyBpbiB0aGUgbWFuYWdlciwgb24gaXRzIGxpc3Qg4oCUIGFjY2VwdGVkLCBub3Qgd29ya2VkIGFyb3VuZC5cbiAgY29uc3QgbGlua3MgPVxuICAgIGxheW91dCA9PT0gJ2xpc3QnID8gKFxuICAgICAgPD5cbiAgICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtzcGFjZXNSb3V0ZSgpfT5BbGwgc3BhY2VzIOKGkjwvUGxhdGZvcm1MaW5rPlxuICAgICAgICA8UGxhdGZvcm1MaW5rIHBhdGg9e3NwYWNlc1JvdXRlKCl9PkNyZWF0ZSBhIHNwYWNlIOKGkjwvUGxhdGZvcm1MaW5rPlxuICAgICAgPC8+XG4gICAgKSA6IHVuZGVmaW5lZDtcblxuICBpZiAoc3RhdGUua2luZCA9PT0gJ2VtcHR5Jykge1xuICAgIHJldHVybiAoXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcFwiIGFyaWEtbGFiZWw9XCJZb3VyIHNwYWNlc1wiPlxuICAgICAgICA8U2VjdGlvbkhlYWRpbmcgdGFnPVwiL1NQQUNFU1wiIHRpdGxlPVwiWW91ciBzcGFjZXMuXCI+XG4gICAgICAgICAge2xpbmtzfVxuICAgICAgICA8L1NlY3Rpb25IZWFkaW5nPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwLWVtcHR5LWJveFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNwLWVtcHR5XCI+XG4gICAgICAgICAgICBZb3UgYXJlIG5vdCBpbiBhbnkgc3BhY2UgeWV0LiBDcmVhdGUgb25lLCBvciB3YWl0IGZvciBhbiBpbnZpdGF0aW9uIHRvIHJlYWNoIHlvdXJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbnMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxQbGF0Zm9ybUxpbmsgcGF0aD17c3BhY2VzUm91dGUoKX0gY2xhc3NOYW1lPVwic3AtZW1wdHlfX2NyZWF0ZVwiPlxuICAgICAgICAgICAgQ3JlYXRlIGEgc3BhY2Ug4oaSXG4gICAgICAgICAgPC9QbGF0Zm9ybUxpbms+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH1cblxuICBpZiAoc3RhdGUua2luZCA9PT0gJ29mZicpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BcIiBhcmlhLWxhYmVsPVwiWW91ciBzcGFjZXNcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic3Atb2ZmXCI+XG4gICAgICAgICAgVGhpcyB2ZXJzaW9uIG9mIEhvbWUgY2Fubm90IGxpc3QgeW91ciBzcGFjZXMuXG4gICAgICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtzcGFjZXNSb3V0ZSgpfSBjbGFzc05hbWU9XCJzcC1vZmZfX2FsbFwiPlxuICAgICAgICAgICAgQWxsIHNwYWNlcyDihpJcbiAgICAgICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICAgICAgPC9wPlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwXCIgYXJpYS1sYWJlbD1cIllvdXIgc3BhY2VzXCI+XG4gICAgICA8U2VjdGlvbkhlYWRpbmcgdGFnPVwiL1NQQUNFU1wiIHRpdGxlPVwiWW91ciBzcGFjZXMuXCI+XG4gICAgICAgIHtsaW5rc31cbiAgICAgIDwvU2VjdGlvbkhlYWRpbmc+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17bGF5b3V0ID09PSAnc3RyaXAnID8gJ3NwLXN0cmlwJyA6ICdzcC1saXN0J30+XG4gICAgICAgIHtzdGF0ZS5yb3dzLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgPFNwYWNlUm93IGtleT17cm93LnNwYWNlSWR9IHJvdz17cm93fSBsYXlvdXQ9e2xheW91dH0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBR0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsYUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsZUFBQSxHQUFBQyxzQkFBQSxDQUFBSixPQUFBO0FBQ0EsSUFBQUssU0FBQSxHQUFBRCxzQkFBQSxDQUFBSixPQUFBO0FBQ0EsSUFBQU0sT0FBQSxHQUFBTixPQUFBO0FBRUEsSUFBQU8sT0FBQSxHQUFBUCxPQUFBO0FBQ0FBLE9BQUE7QUFBOEIsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsSUFBQVMsRUFBQSxHQUFBQyxZQUFBLElBVjlCO0FBQ0E7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQU4sdUJBQUFPLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFZSxTQUFTRyxNQUFNQSxDQUFDO0VBQUVDO0FBQXFDLENBQUMsRUFBRTtFQUFBTixFQUFBO0VBQ3ZFLE1BQU0sQ0FBQ08sR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQThCLENBQUM7RUFFN0QsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUMsS0FBSyxHQUFHLElBQUk7SUFDaEIsSUFBQUMsa0JBQVUsRUFBQyxDQUFDLENBQUNDLElBQUksQ0FDZEMsTUFBTSxJQUFLO01BQ1YsSUFBSUgsS0FBSyxFQUFFSCxNQUFNLENBQUNNLE1BQU0sQ0FBQztJQUMzQixDQUFDLEVBQ0FDLEdBQWtCLElBQUs7TUFDdEIsSUFBSUosS0FBSyxFQUFFSCxNQUFNLENBQUNPLEdBQUcsQ0FBQztJQUN4QixDQUNGLENBQUM7SUFDRCxPQUFPLE1BQU07TUFDWEosS0FBSyxHQUFHLEtBQUs7SUFDZixDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLElBQUlKLEdBQUcsS0FBS1MsU0FBUyxFQUFFLE9BQU8sSUFBSTtFQUNsQyxNQUFNQyxLQUFrQixHQUFHLElBQUFDLG1CQUFXLEVBQUNYLEdBQUcsQ0FBQzs7RUFFM0M7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNWSxLQUFLLEdBQ1RiLE1BQU0sS0FBSyxNQUFNLGdCQUNmLElBQUFQLFdBQUEsQ0FBQXFCLElBQUEsRUFBQXJCLFdBQUEsQ0FBQXNCLFFBQUE7SUFBQUMsUUFBQSxnQkFDRSxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDOUIsYUFBQSxDQUFBK0IsWUFBWTtNQUFDQyxJQUFJLEVBQUUsSUFBQUMsbUJBQVcsRUFBQyxDQUFFO01BQUFKLFFBQUEsRUFBQztJQUFZLENBQWMsQ0FBQyxlQUM5RCxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDOUIsYUFBQSxDQUFBK0IsWUFBWTtNQUFDQyxJQUFJLEVBQUUsSUFBQUMsbUJBQVcsRUFBQyxDQUFFO01BQUFKLFFBQUEsRUFBQztJQUFnQixDQUFjLENBQUM7RUFBQSxDQUNsRSxDQUFDLEdBQ0ROLFNBQVM7RUFFZixJQUFJQyxLQUFLLENBQUNVLElBQUksS0FBSyxPQUFPLEVBQUU7SUFDMUIsb0JBQ0UsSUFBQTVCLFdBQUEsQ0FBQXFCLElBQUE7TUFBU1EsU0FBUyxFQUFDLElBQUk7TUFBQyxjQUFXLGFBQWE7TUFBQU4sUUFBQSxnQkFDOUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQzdCLGVBQUEsQ0FBQVUsT0FBYztRQUFDeUIsR0FBRyxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDLGNBQWM7UUFBQVIsUUFBQSxFQUMvQ0g7TUFBSyxDQUNRLENBQUMsZUFDakIsSUFBQXBCLFdBQUEsQ0FBQXFCLElBQUE7UUFBS1EsU0FBUyxFQUFDLGNBQWM7UUFBQU4sUUFBQSxnQkFDM0IsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUE7VUFBR0ssU0FBUyxFQUFDLFVBQVU7VUFBQU4sUUFBQSxFQUFDO1FBR3hCLENBQUcsQ0FBQyxlQUNKLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUM5QixhQUFBLENBQUErQixZQUFZO1VBQUNDLElBQUksRUFBRSxJQUFBQyxtQkFBVyxFQUFDLENBQUU7VUFBQ0UsU0FBUyxFQUFDLGtCQUFrQjtVQUFBTixRQUFBLEVBQUM7UUFFaEUsQ0FBYyxDQUFDO01BQUEsQ0FDWixDQUFDO0lBQUEsQ0FDQyxDQUFDO0VBRWQ7RUFFQSxJQUFJTCxLQUFLLENBQUNVLElBQUksS0FBSyxLQUFLLEVBQUU7SUFDeEIsb0JBQ0UsSUFBQTVCLFdBQUEsQ0FBQXdCLEdBQUE7TUFBU0ssU0FBUyxFQUFDLElBQUk7TUFBQyxjQUFXLGFBQWE7TUFBQU4sUUFBQSxlQUM5QyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQTtRQUFHUSxTQUFTLEVBQUMsUUFBUTtRQUFBTixRQUFBLEdBQUMsK0NBRXBCLG1CQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDOUIsYUFBQSxDQUFBK0IsWUFBWTtVQUFDQyxJQUFJLEVBQUUsSUFBQUMsbUJBQVcsRUFBQyxDQUFFO1VBQUNFLFNBQVMsRUFBQyxhQUFhO1VBQUFOLFFBQUEsRUFBQztRQUUzRCxDQUFjLENBQUM7TUFBQSxDQUNkO0lBQUMsQ0FDRyxDQUFDO0VBRWQ7RUFFQSxvQkFDRSxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQTtJQUFTUSxTQUFTLEVBQUMsSUFBSTtJQUFDLGNBQVcsYUFBYTtJQUFBTixRQUFBLGdCQUM5QyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDN0IsZUFBQSxDQUFBVSxPQUFjO01BQUN5QixHQUFHLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUMsY0FBYztNQUFBUixRQUFBLEVBQy9DSDtJQUFLLENBQ1EsQ0FBQyxlQUNqQixJQUFBcEIsV0FBQSxDQUFBd0IsR0FBQTtNQUFLSyxTQUFTLEVBQUV0QixNQUFNLEtBQUssT0FBTyxHQUFHLFVBQVUsR0FBRyxTQUFVO01BQUFnQixRQUFBLEVBQ3pETCxLQUFLLENBQUNjLElBQUksQ0FBQ0MsR0FBRyxDQUFFQyxHQUFHLGlCQUNsQixJQUFBbEMsV0FBQSxDQUFBd0IsR0FBQSxFQUFDM0IsU0FBQSxDQUFBUSxPQUFRO1FBQW1CNkIsR0FBRyxFQUFFQSxHQUFJO1FBQUMzQixNQUFNLEVBQUVBO01BQU8sR0FBdEMyQixHQUFHLENBQUNDLE9BQW9DLENBQ3hEO0lBQUMsQ0FDQyxDQUFDO0VBQUEsQ0FDQyxDQUFDO0FBRWQ7QUFBQ2xDLEVBQUEsQ0FoRnVCSyxNQUFNO0FBQUE4QixFQUFBLEdBQU45QixNQUFNO0FBQUEsSUFBQThCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}