var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SectionHeading;
require("../styles/section-heading.css");
var _jsxRuntime = require("react/jsx-runtime");
function SectionHeading({
  tag,
  title,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "section-head",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "tag",
      children: tag
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
      children: title
    }), children !== undefined && children !== null ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "section-head__links",
      children: children
    }) : null]
  });
}
_c = SectionHeading;
var _c;
$RefreshReg$(_c, "SectionHeading");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJTZWN0aW9uSGVhZGluZyIsInRhZyIsInRpdGxlIiwiY2hpbGRyZW4iLCJqc3hzIiwiY2xhc3NOYW1lIiwianN4IiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWN0aW9uSGVhZGluZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgJy4uL3N0eWxlcy9zZWN0aW9uLWhlYWRpbmcuY3NzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VjdGlvbkhlYWRpbmcoeyB0YWcsIHRpdGxlLCBjaGlsZHJlbiB9OiB7IHRhZzogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhZ1wiPnt0YWd9PC9zcGFuPlxuICAgICAgPGgyPnt0aXRsZX08L2gyPlxuICAgICAge2NoaWxkcmVuICE9PSB1bmRlZmluZWQgJiYgY2hpbGRyZW4gIT09IG51bGwgPyA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZF9fbGlua3NcIj57Y2hpbGRyZW59PC9kaXY+IDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQ0FBLE9BQUE7QUFBdUMsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRXhCLFNBQVNFLGNBQWNBLENBQUM7RUFBRUMsR0FBRztFQUFFQyxLQUFLO0VBQUVDO0FBQStELENBQUMsRUFBRTtFQUNySCxvQkFDRSxJQUFBSixXQUFBLENBQUFLLElBQUE7SUFBS0MsU0FBUyxFQUFDLGNBQWM7SUFBQUYsUUFBQSxnQkFDM0IsSUFBQUosV0FBQSxDQUFBTyxHQUFBO01BQU1ELFNBQVMsRUFBQyxLQUFLO01BQUFGLFFBQUEsRUFBRUY7SUFBRyxDQUFPLENBQUMsZUFDbEMsSUFBQUYsV0FBQSxDQUFBTyxHQUFBO01BQUFILFFBQUEsRUFBS0Q7SUFBSyxDQUFLLENBQUMsRUFDZkMsUUFBUSxLQUFLSSxTQUFTLElBQUlKLFFBQVEsS0FBSyxJQUFJLGdCQUFHLElBQUFKLFdBQUEsQ0FBQU8sR0FBQTtNQUFLRCxTQUFTLEVBQUMscUJBQXFCO01BQUFGLFFBQUEsRUFBRUE7SUFBUSxDQUFNLENBQUMsR0FBRyxJQUFJO0VBQUEsQ0FDeEcsQ0FBQztBQUVWO0FBQUNLLEVBQUEsR0FSdUJSLGNBQWM7QUFBQSxJQUFBUSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}