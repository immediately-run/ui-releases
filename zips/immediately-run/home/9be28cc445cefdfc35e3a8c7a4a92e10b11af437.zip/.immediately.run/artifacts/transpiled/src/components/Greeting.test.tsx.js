var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("@testing-library/react");
var _vitest = require("vitest");
var _Greeting = _interopRequireDefault(require("./Greeting"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// @vitest-environment jsdom

_vitest.vi.mock('@immediately-run/sdk/platformLink', () => ({
  // The mock mirrors the real contract: a platform route anchor that always
  // carries target="_top".
  PlatformLink: ({
    path,
    children,
    ...rest
  }) => /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
    href: path,
    target: "_top",
    ...rest,
    children: children
  })
}));
_vitest.vi.mock('@immediately-run/omnibox', () => ({
  // A stub carrying the marker class the test asserts on.
  Omnibox: () => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    "data-testid": "omnibox"
  })
}));
(0, _vitest.afterEach)(_react.cleanup);
(0, _vitest.describe)('Greeting', () => {
  (0, _vitest.it)('clicking Paste a repo calls onToggle', () => {
    const onToggle = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Greeting.default, {
      primary: "create",
      omniboxOpen: false,
      onToggle: onToggle,
      toggleRef: undefined,
      onOmniboxKeyDown: () => {}
    }));
    _react.fireEvent.click(_react.screen.getByText('Paste a repo'));
    (0, _vitest.expect)(onToggle).toHaveBeenCalledTimes(1);
  });
  (0, _vitest.it)('closed: no omnibox block, and Make an app carries the gradient', () => {
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Greeting.default, {
      primary: "create",
      omniboxOpen: false,
      onToggle: () => {},
      toggleRef: undefined,
      onOmniboxKeyDown: () => {}
    }));
    (0, _vitest.expect)(container.querySelector('.greeting__paste')).toBeNull();
    (0, _vitest.expect)(container.querySelector('.greeting__actions .btn')?.textContent).toBe('Make an app →');
  });
  (0, _vitest.it)('open: the omnibox block is in the DOM and Make an app is hairline', () => {
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Greeting.default, {
      primary: "omnibox",
      omniboxOpen: true,
      onToggle: () => {},
      toggleRef: undefined,
      onOmniboxKeyDown: () => {}
    }));
    (0, _vitest.expect)(_react.screen.getByTestId('omnibox')).toBeDefined();
    (0, _vitest.expect)(container.querySelector('.greeting__paste')).not.toBeNull();
    const actions = container.querySelectorAll('.greeting__actions a');
    (0, _vitest.expect)(actions).toHaveLength(1);
    (0, _vitest.expect)(actions[0].className).toBe('btn-ghost');
  });
  (0, _vitest.it)('Escape inside the block reaches the wrapper handler', () => {
    const onOmniboxKeyDown = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_Greeting.default, {
      primary: "omnibox",
      omniboxOpen: true,
      onToggle: () => {},
      toggleRef: undefined,
      onOmniboxKeyDown: onOmniboxKeyDown
    }));
    _react.fireEvent.keyDown(_react.screen.getByTestId('omnibox'), {
      key: 'Escape'
    });
    (0, _vitest.expect)(onOmniboxKeyDown).toHaveBeenCalledTimes(1);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZpdGVzdCIsIl9HcmVldGluZyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInZpIiwibW9jayIsIlBsYXRmb3JtTGluayIsInBhdGgiLCJjaGlsZHJlbiIsInJlc3QiLCJqc3giLCJocmVmIiwidGFyZ2V0IiwiT21uaWJveCIsImFmdGVyRWFjaCIsImNsZWFudXAiLCJkZXNjcmliZSIsIml0Iiwib25Ub2dnbGUiLCJmbiIsInJlbmRlciIsInByaW1hcnkiLCJvbW5pYm94T3BlbiIsInRvZ2dsZVJlZiIsInVuZGVmaW5lZCIsIm9uT21uaWJveEtleURvd24iLCJmaXJlRXZlbnQiLCJjbGljayIsInNjcmVlbiIsImdldEJ5VGV4dCIsImV4cGVjdCIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsImNvbnRhaW5lciIsInF1ZXJ5U2VsZWN0b3IiLCJ0b0JlTnVsbCIsInRleHRDb250ZW50IiwidG9CZSIsImdldEJ5VGVzdElkIiwidG9CZURlZmluZWQiLCJub3QiLCJhY3Rpb25zIiwicXVlcnlTZWxlY3RvckFsbCIsInRvSGF2ZUxlbmd0aCIsImNsYXNzTmFtZSIsImtleURvd24iLCJrZXkiXSwic291cmNlcyI6WyJHcmVldGluZy50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGpzZG9tXG5pbXBvcnQgeyBjbGVhbnVwLCBmaXJlRXZlbnQsIHJlbmRlciwgc2NyZWVuIH0gZnJvbSAnQHRlc3RpbmctbGlicmFyeS9yZWFjdCc7XG5pbXBvcnQgeyBhZnRlckVhY2gsIGRlc2NyaWJlLCBleHBlY3QsIGl0LCB2aSB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi9HcmVldGluZyc7XG5cbnZpLm1vY2soJ0BpbW1lZGlhdGVseS1ydW4vc2RrL3BsYXRmb3JtTGluaycsICgpID0+ICh7XG4gIC8vIFRoZSBtb2NrIG1pcnJvcnMgdGhlIHJlYWwgY29udHJhY3Q6IGEgcGxhdGZvcm0gcm91dGUgYW5jaG9yIHRoYXQgYWx3YXlzXG4gIC8vIGNhcnJpZXMgdGFyZ2V0PVwiX3RvcFwiLlxuICBQbGF0Zm9ybUxpbms6ICh7IHBhdGgsIGNoaWxkcmVuLCAuLi5yZXN0IH06IHsgcGF0aDogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pID0+IChcbiAgICA8YSBocmVmPXtwYXRofSB0YXJnZXQ9XCJfdG9wXCIgey4uLnJlc3R9PntjaGlsZHJlbn08L2E+XG4gICksXG59KSk7XG5cbnZpLm1vY2soJ0BpbW1lZGlhdGVseS1ydW4vb21uaWJveCcsICgpID0+ICh7XG4gIC8vIEEgc3R1YiBjYXJyeWluZyB0aGUgbWFya2VyIGNsYXNzIHRoZSB0ZXN0IGFzc2VydHMgb24uXG4gIE9tbmlib3g6ICgpID0+IDxkaXYgZGF0YS10ZXN0aWQ9XCJvbW5pYm94XCIgLz4sXG59KSk7XG5cbmFmdGVyRWFjaChjbGVhbnVwKTtcblxuZGVzY3JpYmUoJ0dyZWV0aW5nJywgKCkgPT4ge1xuICBpdCgnY2xpY2tpbmcgUGFzdGUgYSByZXBvIGNhbGxzIG9uVG9nZ2xlJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uVG9nZ2xlID0gdmkuZm4oKTtcbiAgICByZW5kZXIoPEdyZWV0aW5nIHByaW1hcnk9XCJjcmVhdGVcIiBvbW5pYm94T3Blbj17ZmFsc2V9IG9uVG9nZ2xlPXtvblRvZ2dsZX0gdG9nZ2xlUmVmPXt1bmRlZmluZWR9IG9uT21uaWJveEtleURvd249eygpID0+IHt9fSAvPik7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoJ1Bhc3RlIGEgcmVwbycpKTtcbiAgICBleHBlY3Qob25Ub2dnbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgfSk7XG5cbiAgaXQoJ2Nsb3NlZDogbm8gb21uaWJveCBibG9jaywgYW5kIE1ha2UgYW4gYXBwIGNhcnJpZXMgdGhlIGdyYWRpZW50JywgKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSByZW5kZXIoPEdyZWV0aW5nIHByaW1hcnk9XCJjcmVhdGVcIiBvbW5pYm94T3Blbj17ZmFsc2V9IG9uVG9nZ2xlPXsoKSA9PiB7fX0gdG9nZ2xlUmVmPXt1bmRlZmluZWR9IG9uT21uaWJveEtleURvd249eygpID0+IHt9fSAvPik7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ3JlZXRpbmdfX3Bhc3RlJykpLnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ3JlZXRpbmdfX2FjdGlvbnMgLmJ0bicpPy50ZXh0Q29udGVudCkudG9CZSgnTWFrZSBhbiBhcHAg4oaSJyk7XG4gIH0pO1xuXG4gIGl0KCdvcGVuOiB0aGUgb21uaWJveCBibG9jayBpcyBpbiB0aGUgRE9NIGFuZCBNYWtlIGFuIGFwcCBpcyBoYWlybGluZScsICgpID0+IHtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKDxHcmVldGluZyBwcmltYXJ5PVwib21uaWJveFwiIG9tbmlib3hPcGVuIG9uVG9nZ2xlPXsoKSA9PiB7fX0gdG9nZ2xlUmVmPXt1bmRlZmluZWR9IG9uT21uaWJveEtleURvd249eygpID0+IHt9fSAvPik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRlc3RJZCgnb21uaWJveCcpKS50b0JlRGVmaW5lZCgpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdyZWV0aW5nX19wYXN0ZScpKS5ub3QudG9CZU51bGwoKTtcbiAgICBjb25zdCBhY3Rpb25zID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5ncmVldGluZ19fYWN0aW9ucyBhJyk7XG4gICAgZXhwZWN0KGFjdGlvbnMpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgICBleHBlY3QoYWN0aW9uc1swXS5jbGFzc05hbWUpLnRvQmUoJ2J0bi1naG9zdCcpO1xuICB9KTtcblxuICBpdCgnRXNjYXBlIGluc2lkZSB0aGUgYmxvY2sgcmVhY2hlcyB0aGUgd3JhcHBlciBoYW5kbGVyJywgKCkgPT4ge1xuICAgIGNvbnN0IG9uT21uaWJveEtleURvd24gPSB2aS5mbigpO1xuICAgIHJlbmRlcig8R3JlZXRpbmcgcHJpbWFyeT1cIm9tbmlib3hcIiBvbW5pYm94T3BlbiBvblRvZ2dsZT17KCkgPT4ge319IHRvZ2dsZVJlZj17dW5kZWZpbmVkfSBvbk9tbmlib3hLZXlEb3duPXtvbk9tbmlib3hLZXlEb3dufSAvPik7XG4gICAgZmlyZUV2ZW50LmtleURvd24oc2NyZWVuLmdldEJ5VGVzdElkKCdvbW5pYm94JyksIHsga2V5OiAnRXNjYXBlJyB9KTtcbiAgICBleHBlY3Qob25PbW5pYm94S2V5RG93bikudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUFrQyxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxTQUFBRyx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUhsQzs7QUFLQUcsVUFBRSxDQUFDQyxJQUFJLENBQUMsbUNBQW1DLEVBQUUsT0FBTztFQUNsRDtFQUNBO0VBQ0FDLFlBQVksRUFBRUEsQ0FBQztJQUFFQyxJQUFJO0lBQUVDLFFBQVE7SUFBRSxHQUFHQztFQUFrRCxDQUFDLGtCQUNyRixJQUFBVCxXQUFBLENBQUFVLEdBQUE7SUFBR0MsSUFBSSxFQUFFSixJQUFLO0lBQUNLLE1BQU0sRUFBQyxNQUFNO0lBQUEsR0FBS0gsSUFBSTtJQUFBRCxRQUFBLEVBQUdBO0VBQVEsQ0FBSTtBQUV4RCxDQUFDLENBQUMsQ0FBQztBQUVISixVQUFFLENBQUNDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxPQUFPO0VBQ3pDO0VBQ0FRLE9BQU8sRUFBRUEsQ0FBQSxrQkFBTSxJQUFBYixXQUFBLENBQUFVLEdBQUE7SUFBSyxlQUFZO0VBQVMsQ0FBRTtBQUM3QyxDQUFDLENBQUMsQ0FBQztBQUVILElBQUFJLGlCQUFTLEVBQUNDLGNBQU8sQ0FBQztBQUVsQixJQUFBQyxnQkFBUSxFQUFDLFVBQVUsRUFBRSxNQUFNO0VBQ3pCLElBQUFDLFVBQUUsRUFBQyxzQ0FBc0MsRUFBRSxNQUFNO0lBQy9DLE1BQU1DLFFBQVEsR0FBR2QsVUFBRSxDQUFDZSxFQUFFLENBQUMsQ0FBQztJQUN4QixJQUFBQyxhQUFNLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQVUsR0FBQSxFQUFDWixTQUFBLENBQUFLLE9BQVE7TUFBQ2tCLE9BQU8sRUFBQyxRQUFRO01BQUNDLFdBQVcsRUFBRSxLQUFNO01BQUNKLFFBQVEsRUFBRUEsUUFBUztNQUFDSyxTQUFTLEVBQUVDLFNBQVU7TUFBQ0MsZ0JBQWdCLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDL0hDLGdCQUFTLENBQUNDLEtBQUssQ0FBQ0MsYUFBTSxDQUFDQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDakQsSUFBQUMsY0FBTSxFQUFDWixRQUFRLENBQUMsQ0FBQ2EscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFkLFVBQUUsRUFBQyxnRUFBZ0UsRUFBRSxNQUFNO0lBQ3pFLE1BQU07TUFBRWU7SUFBVSxDQUFDLEdBQUcsSUFBQVosYUFBTSxlQUFDLElBQUFwQixXQUFBLENBQUFVLEdBQUEsRUFBQ1osU0FBQSxDQUFBSyxPQUFRO01BQUNrQixPQUFPLEVBQUMsUUFBUTtNQUFDQyxXQUFXLEVBQUUsS0FBTTtNQUFDSixRQUFRLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUU7TUFBQ0ssU0FBUyxFQUFFQyxTQUFVO01BQUNDLGdCQUFnQixFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUFFLENBQUUsQ0FBQyxDQUFDO0lBQ3JKLElBQUFLLGNBQU0sRUFBQ0UsU0FBUyxDQUFDQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztJQUM5RCxJQUFBSixjQUFNLEVBQUNFLFNBQVMsQ0FBQ0MsYUFBYSxDQUFDLHlCQUF5QixDQUFDLEVBQUVFLFdBQVcsQ0FBQyxDQUFDQyxJQUFJLENBQUMsZUFBZSxDQUFDO0VBQy9GLENBQUMsQ0FBQztFQUVGLElBQUFuQixVQUFFLEVBQUMsbUVBQW1FLEVBQUUsTUFBTTtJQUM1RSxNQUFNO01BQUVlO0lBQVUsQ0FBQyxHQUFHLElBQUFaLGFBQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBVSxHQUFBLEVBQUNaLFNBQUEsQ0FBQUssT0FBUTtNQUFDa0IsT0FBTyxFQUFDLFNBQVM7TUFBQ0MsV0FBVztNQUFDSixRQUFRLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUU7TUFBQ0ssU0FBUyxFQUFFQyxTQUFVO01BQUNDLGdCQUFnQixFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUFFLENBQUUsQ0FBQyxDQUFDO0lBQzlJLElBQUFLLGNBQU0sRUFBQ0YsYUFBTSxDQUFDUyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7SUFDbkQsSUFBQVIsY0FBTSxFQUFDRSxTQUFTLENBQUNDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNNLEdBQUcsQ0FBQ0wsUUFBUSxDQUFDLENBQUM7SUFDbEUsTUFBTU0sT0FBTyxHQUFHUixTQUFTLENBQUNTLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDO0lBQ2xFLElBQUFYLGNBQU0sRUFBQ1UsT0FBTyxDQUFDLENBQUNFLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDL0IsSUFBQVosY0FBTSxFQUFDVSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNHLFNBQVMsQ0FBQyxDQUFDUCxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ2hELENBQUMsQ0FBQztFQUVGLElBQUFuQixVQUFFLEVBQUMscURBQXFELEVBQUUsTUFBTTtJQUM5RCxNQUFNUSxnQkFBZ0IsR0FBR3JCLFVBQUUsQ0FBQ2UsRUFBRSxDQUFDLENBQUM7SUFDaEMsSUFBQUMsYUFBTSxlQUFDLElBQUFwQixXQUFBLENBQUFVLEdBQUEsRUFBQ1osU0FBQSxDQUFBSyxPQUFRO01BQUNrQixPQUFPLEVBQUMsU0FBUztNQUFDQyxXQUFXO01BQUNKLFFBQVEsRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBRTtNQUFDSyxTQUFTLEVBQUVDLFNBQVU7TUFBQ0MsZ0JBQWdCLEVBQUVBO0lBQWlCLENBQUUsQ0FBQyxDQUFDO0lBQ2hJQyxnQkFBUyxDQUFDa0IsT0FBTyxDQUFDaEIsYUFBTSxDQUFDUyxXQUFXLENBQUMsU0FBUyxDQUFDLEVBQUU7TUFBRVEsR0FBRyxFQUFFO0lBQVMsQ0FBQyxDQUFDO0lBQ25FLElBQUFmLGNBQU0sRUFBQ0wsZ0JBQWdCLENBQUMsQ0FBQ00scUJBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQ25ELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}