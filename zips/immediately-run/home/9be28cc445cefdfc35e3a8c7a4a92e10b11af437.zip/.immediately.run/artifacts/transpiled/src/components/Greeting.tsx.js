var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Greeting;
var _platformLink = require("@immediately-run/sdk/platformLink");
var _omnibox = require("@immediately-run/omnibox");
var _routes = require("../lib/routes");
require("../styles/greeting.css");
var _jsxRuntime = require("react/jsx-runtime");
// The greeting row and, beneath it, the pasted-repo launcher. The open state
// lives in App (it is an input to the page's primary decision); this shell
// renders the row and the omnibox block from props. The omnibox is the front
// door's component, mounted once, launch grammar only — no `hits` prop, so
// the panel shows the location row and nothing else. Escape inside the block
// closes the block and returns focus to the Paste a repo link: the package's
// own handler clears and blurs its panel, and App's wrapper handler (one
// listener, not two doing the same job) closes and refocuses.
function Greeting({
  primary,
  omniboxOpen,
  onToggle,
  toggleRef,
  onOmniboxKeyDown
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
    className: "greeting",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
      className: "greeting__title",
      children: "Welcome back."
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "greeting__actions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "btn-ghost",
        onClick: onToggle,
        ref: toggleRef,
        children: "Paste a repo"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
        path: _routes.MAKE_AN_APP,
        className: primary === 'create' ? 'btn' : 'btn-ghost',
        children: "Make an app \u2192"
      })]
    }), omniboxOpen && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "greeting__paste",
      onKeyDown: onOmniboxKeyDown,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_omnibox.Omnibox, {
        variant: "hero"
      })
    })]
  });
}
_c = Greeting;
var _c;
$RefreshReg$(_c, "Greeting");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9vbW5pYm94IiwiX3JvdXRlcyIsIl9qc3hSdW50aW1lIiwiR3JlZXRpbmciLCJwcmltYXJ5Iiwib21uaWJveE9wZW4iLCJvblRvZ2dsZSIsInRvZ2dsZVJlZiIsIm9uT21uaWJveEtleURvd24iLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwib25DbGljayIsInJlZiIsIlBsYXRmb3JtTGluayIsInBhdGgiLCJNQUtFX0FOX0FQUCIsIm9uS2V5RG93biIsIk9tbmlib3giLCJ2YXJpYW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJHcmVldGluZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdHlwZSB7IEtleWJvYXJkRXZlbnQgYXMgUmVhY3RLZXlib2FyZEV2ZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUGxhdGZvcm1MaW5rIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvcGxhdGZvcm1MaW5rJztcbmltcG9ydCB7IE9tbmlib3ggfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL29tbmlib3gnO1xuaW1wb3J0IHR5cGUgeyBQcmltYXJ5VGFyZ2V0IH0gZnJvbSAnLi4vbGliL3ByaW1hcnknO1xuaW1wb3J0IHsgTUFLRV9BTl9BUFAgfSBmcm9tICcuLi9saWIvcm91dGVzJztcbmltcG9ydCAnLi4vc3R5bGVzL2dyZWV0aW5nLmNzcyc7XG5cbi8vIFRoZSBncmVldGluZyByb3cgYW5kLCBiZW5lYXRoIGl0LCB0aGUgcGFzdGVkLXJlcG8gbGF1bmNoZXIuIFRoZSBvcGVuIHN0YXRlXG4vLyBsaXZlcyBpbiBBcHAgKGl0IGlzIGFuIGlucHV0IHRvIHRoZSBwYWdlJ3MgcHJpbWFyeSBkZWNpc2lvbik7IHRoaXMgc2hlbGxcbi8vIHJlbmRlcnMgdGhlIHJvdyBhbmQgdGhlIG9tbmlib3ggYmxvY2sgZnJvbSBwcm9wcy4gVGhlIG9tbmlib3ggaXMgdGhlIGZyb250XG4vLyBkb29yJ3MgY29tcG9uZW50LCBtb3VudGVkIG9uY2UsIGxhdW5jaCBncmFtbWFyIG9ubHkg4oCUIG5vIGBoaXRzYCBwcm9wLCBzb1xuLy8gdGhlIHBhbmVsIHNob3dzIHRoZSBsb2NhdGlvbiByb3cgYW5kIG5vdGhpbmcgZWxzZS4gRXNjYXBlIGluc2lkZSB0aGUgYmxvY2tcbi8vIGNsb3NlcyB0aGUgYmxvY2sgYW5kIHJldHVybnMgZm9jdXMgdG8gdGhlIFBhc3RlIGEgcmVwbyBsaW5rOiB0aGUgcGFja2FnZSdzXG4vLyBvd24gaGFuZGxlciBjbGVhcnMgYW5kIGJsdXJzIGl0cyBwYW5lbCwgYW5kIEFwcCdzIHdyYXBwZXIgaGFuZGxlciAob25lXG4vLyBsaXN0ZW5lciwgbm90IHR3byBkb2luZyB0aGUgc2FtZSBqb2IpIGNsb3NlcyBhbmQgcmVmb2N1c2VzLlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcmVldGluZyh7XG4gIHByaW1hcnksXG4gIG9tbmlib3hPcGVuLFxuICBvblRvZ2dsZSxcbiAgdG9nZ2xlUmVmLFxuICBvbk9tbmlib3hLZXlEb3duLFxufToge1xuICBwcmltYXJ5OiBQcmltYXJ5VGFyZ2V0O1xuICBvbW5pYm94T3BlbjogYm9vbGVhbjtcbiAgb25Ub2dnbGU6ICgpID0+IHZvaWQ7XG4gIHRvZ2dsZVJlZj86IFJlZjxIVE1MQnV0dG9uRWxlbWVudD47XG4gIG9uT21uaWJveEtleURvd246IChlOiBSZWFjdEtleWJvYXJkRXZlbnQpID0+IHZvaWQ7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJncmVldGluZ1wiPlxuICAgICAgPGgxIGNsYXNzTmFtZT1cImdyZWV0aW5nX190aXRsZVwiPldlbGNvbWUgYmFjay48L2gxPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmVldGluZ19fYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBvbkNsaWNrPXtvblRvZ2dsZX0gcmVmPXt0b2dnbGVSZWZ9PlxuICAgICAgICAgIFBhc3RlIGEgcmVwb1xuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPFBsYXRmb3JtTGluayBwYXRoPXtNQUtFX0FOX0FQUH0gY2xhc3NOYW1lPXtwcmltYXJ5ID09PSAnY3JlYXRlJyA/ICdidG4nIDogJ2J0bi1naG9zdCd9PlxuICAgICAgICAgIE1ha2UgYW4gYXBwIOKGklxuICAgICAgICA8L1BsYXRmb3JtTGluaz5cbiAgICAgIDwvZGl2PlxuICAgICAge29tbmlib3hPcGVuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmVldGluZ19fcGFzdGVcIiBvbktleURvd249e29uT21uaWJveEtleURvd259PlxuICAgICAgICAgIDxPbW5pYm94IHZhcmlhbnQ9XCJoZXJvXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxRQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQUEsT0FBQTtBQUFnQyxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFFaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVlLFNBQVNJLFFBQVFBLENBQUM7RUFDL0JDLE9BQU87RUFDUEMsV0FBVztFQUNYQyxRQUFRO0VBQ1JDLFNBQVM7RUFDVEM7QUFPRixDQUFDLEVBQUU7RUFDRCxvQkFDRSxJQUFBTixXQUFBLENBQUFPLElBQUE7SUFBUUMsU0FBUyxFQUFDLFVBQVU7SUFBQUMsUUFBQSxnQkFDMUIsSUFBQVQsV0FBQSxDQUFBVSxHQUFBO01BQUlGLFNBQVMsRUFBQyxpQkFBaUI7TUFBQUMsUUFBQSxFQUFDO0lBQWEsQ0FBSSxDQUFDLGVBQ2xELElBQUFULFdBQUEsQ0FBQU8sSUFBQTtNQUFLQyxTQUFTLEVBQUMsbUJBQW1CO01BQUFDLFFBQUEsZ0JBQ2hDLElBQUFULFdBQUEsQ0FBQVUsR0FBQTtRQUFRQyxJQUFJLEVBQUMsUUFBUTtRQUFDSCxTQUFTLEVBQUMsV0FBVztRQUFDSSxPQUFPLEVBQUVSLFFBQVM7UUFBQ1MsR0FBRyxFQUFFUixTQUFVO1FBQUFJLFFBQUEsRUFBQztNQUUvRSxDQUFRLENBQUMsZUFDVCxJQUFBVCxXQUFBLENBQUFVLEdBQUEsRUFBQ2QsYUFBQSxDQUFBa0IsWUFBWTtRQUFDQyxJQUFJLEVBQUVDLG1CQUFZO1FBQUNSLFNBQVMsRUFBRU4sT0FBTyxLQUFLLFFBQVEsR0FBRyxLQUFLLEdBQUcsV0FBWTtRQUFBTyxRQUFBLEVBQUM7TUFFeEYsQ0FBYyxDQUFDO0lBQUEsQ0FDWixDQUFDLEVBQ0xOLFdBQVcsaUJBQ1YsSUFBQUgsV0FBQSxDQUFBVSxHQUFBO01BQUtGLFNBQVMsRUFBQyxpQkFBaUI7TUFBQ1MsU0FBUyxFQUFFWCxnQkFBaUI7TUFBQUcsUUFBQSxlQUMzRCxJQUFBVCxXQUFBLENBQUFVLEdBQUEsRUFBQ1osUUFBQSxDQUFBb0IsT0FBTztRQUFDQyxPQUFPLEVBQUM7TUFBTSxDQUFFO0lBQUMsQ0FDdkIsQ0FDTjtFQUFBLENBQ0ssQ0FBQztBQUViO0FBQUNDLEVBQUEsR0EvQnVCbkIsUUFBUTtBQUFBLElBQUFtQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}