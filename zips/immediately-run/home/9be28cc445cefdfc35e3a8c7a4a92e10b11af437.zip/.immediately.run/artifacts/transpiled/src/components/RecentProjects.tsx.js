var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = RecentProjects;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _FeaturedProject = _interopRequireDefault(require("./FeaturedProject"));
var _RecentRow = _interopRequireDefault(require("./RecentRow"));
var _SectionHeading = _interopRequireDefault(require("./SectionHeading"));
require("../styles/recents.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The /RECENT section: it renders what a RecentsState decided and owns the
// clear flow. The read itself lives in App.tsx — exactly one caller per mount
// — and the page's primary moves with it, so a cleared record reports back
// through `onCleared` instead of hiding itself locally (the gradient then
// lands on the create door, which only the page can decide).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function RecentProjects({
  state,
  now,
  primary,
  mobile,
  onCleared
}) {
  _s();
  const [confirming, setConfirming] = (0, _react.useState)(false);
  const [clearing, setClearing] = (0, _react.useState)(false);
  const [clearFailure, setClearFailure] = (0, _react.useState)(null);
  if (state.kind === 'absent') return null;
  const clear = async () => {
    setClearing(true);
    setClearFailure(null);
    try {
      await (0, _sdk.clearRecentProjects)();
      onCleared();
    } catch (err) {
      // The record is host-owned; the truthful surface after a failed clear
      // is the one that is still there. Log loudly, stay on the list, and
      // name the typed reason for the user — the code, never the message.
      console.error('home: clearing recent projects failed', err);
      const code = typeof err === 'object' && err !== null && 'code' in err ? String(err.code) : 'unknown';
      setClearFailure(code);
      setConfirming(false);
    } finally {
      setClearing(false);
    }
  };
  if (state.kind === 'off') {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "rec",
      "aria-label": "Recent projects",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_SectionHeading.default, {
        tag: "/RECENT",
        title: "Recent projects."
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "rec-off",
        children: "Recents are off for this version of Home."
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "rec",
    "aria-label": "Recent projects",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_SectionHeading.default, {
      tag: "/RECENT",
      title: "Recent projects."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_FeaturedProject.default, {
      project: state.featured,
      now: now,
      primary: primary,
      mobile: mobile
    }), state.rest.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rec-rows",
      children: state.rest.map(project => /*#__PURE__*/(0, _jsxRuntime.jsx)(_RecentRow.default, {
        project: project,
        now: now,
        mobile: mobile,
        dimmed: clearing
      }, `${project.namespace}/${project.repository}/${project.ref}`))
    }), clearFailure !== null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "rec-clear__error",
      role: "status",
      children: ["Could not clear your recent projects (", clearFailure, "). Nothing was removed."]
    }), confirming ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "rec-clear",
      children: ["Clear recent projects?", ' ', /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rec-clear__btn",
        onClick: clear,
        disabled: clearing,
        "aria-busy": clearing,
        children: clearing ? 'Clearing…' : 'Clear'
      }), ' ', /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "rec-clear__btn",
        onClick: () => setConfirming(false),
        disabled: clearing,
        children: "Keep"
      })]
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "rec-clear__line",
      onClick: () => setConfirming(true),
      children: "Clear recent projects"
    })]
  });
}
_s(RecentProjects, "S172CvToKiOsshm/Oj0cPMw7REw=");
_c = RecentProjects;
var _c;
$RefreshReg$(_c, "RecentProjects");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9GZWF0dXJlZFByb2plY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1JlY2VudFJvdyIsIl9TZWN0aW9uSGVhZGluZyIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJSZWNlbnRQcm9qZWN0cyIsInN0YXRlIiwibm93IiwicHJpbWFyeSIsIm1vYmlsZSIsIm9uQ2xlYXJlZCIsImNvbmZpcm1pbmciLCJzZXRDb25maXJtaW5nIiwidXNlU3RhdGUiLCJjbGVhcmluZyIsInNldENsZWFyaW5nIiwiY2xlYXJGYWlsdXJlIiwic2V0Q2xlYXJGYWlsdXJlIiwia2luZCIsImNsZWFyIiwiY2xlYXJSZWNlbnRQcm9qZWN0cyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImNvZGUiLCJTdHJpbmciLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0YWciLCJ0aXRsZSIsInByb2plY3QiLCJmZWF0dXJlZCIsInJlc3QiLCJsZW5ndGgiLCJtYXAiLCJkaW1tZWQiLCJuYW1lc3BhY2UiLCJyZXBvc2l0b3J5IiwicmVmIiwicm9sZSIsInR5cGUiLCJvbkNsaWNrIiwiZGlzYWJsZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlY2VudFByb2plY3RzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsZWFyUmVjZW50UHJvamVjdHMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgRmVhdHVyZWRQcm9qZWN0IGZyb20gJy4vRmVhdHVyZWRQcm9qZWN0JztcbmltcG9ydCBSZWNlbnRSb3cgZnJvbSAnLi9SZWNlbnRSb3cnO1xuaW1wb3J0IFNlY3Rpb25IZWFkaW5nIGZyb20gJy4vU2VjdGlvbkhlYWRpbmcnO1xuaW1wb3J0IHR5cGUgeyBSZWNlbnRzU3RhdGUgfSBmcm9tICcuLi9saWIvcmVjZW50cyc7XG5pbXBvcnQgJy4uL3N0eWxlcy9yZWNlbnRzLmNzcyc7XG5cbi8vIFRoZSAvUkVDRU5UIHNlY3Rpb246IGl0IHJlbmRlcnMgd2hhdCBhIFJlY2VudHNTdGF0ZSBkZWNpZGVkIGFuZCBvd25zIHRoZVxuLy8gY2xlYXIgZmxvdy4gVGhlIHJlYWQgaXRzZWxmIGxpdmVzIGluIEFwcC50c3gg4oCUIGV4YWN0bHkgb25lIGNhbGxlciBwZXIgbW91bnRcbi8vIOKAlCBhbmQgdGhlIHBhZ2UncyBwcmltYXJ5IG1vdmVzIHdpdGggaXQsIHNvIGEgY2xlYXJlZCByZWNvcmQgcmVwb3J0cyBiYWNrXG4vLyB0aHJvdWdoIGBvbkNsZWFyZWRgIGluc3RlYWQgb2YgaGlkaW5nIGl0c2VsZiBsb2NhbGx5ICh0aGUgZ3JhZGllbnQgdGhlblxuLy8gbGFuZHMgb24gdGhlIGNyZWF0ZSBkb29yLCB3aGljaCBvbmx5IHRoZSBwYWdlIGNhbiBkZWNpZGUpLlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZWNlbnRQcm9qZWN0cyh7XG4gIHN0YXRlLFxuICBub3csXG4gIHByaW1hcnksXG4gIG1vYmlsZSxcbiAgb25DbGVhcmVkLFxufToge1xuICBzdGF0ZTogUmVjZW50c1N0YXRlO1xuICBub3c6IG51bWJlcjtcbiAgcHJpbWFyeTogYm9vbGVhbjtcbiAgbW9iaWxlOiBib29sZWFuO1xuICBvbkNsZWFyZWQ6ICgpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IFtjb25maXJtaW5nLCBzZXRDb25maXJtaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NsZWFyaW5nLCBzZXRDbGVhcmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjbGVhckZhaWx1cmUsIHNldENsZWFyRmFpbHVyZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBpZiAoc3RhdGUua2luZCA9PT0gJ2Fic2VudCcpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGNsZWFyID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldENsZWFyaW5nKHRydWUpO1xuICAgIHNldENsZWFyRmFpbHVyZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2xlYXJSZWNlbnRQcm9qZWN0cygpO1xuICAgICAgb25DbGVhcmVkKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBUaGUgcmVjb3JkIGlzIGhvc3Qtb3duZWQ7IHRoZSB0cnV0aGZ1bCBzdXJmYWNlIGFmdGVyIGEgZmFpbGVkIGNsZWFyXG4gICAgICAvLyBpcyB0aGUgb25lIHRoYXQgaXMgc3RpbGwgdGhlcmUuIExvZyBsb3VkbHksIHN0YXkgb24gdGhlIGxpc3QsIGFuZFxuICAgICAgLy8gbmFtZSB0aGUgdHlwZWQgcmVhc29uIGZvciB0aGUgdXNlciDigJQgdGhlIGNvZGUsIG5ldmVyIHRoZSBtZXNzYWdlLlxuICAgICAgY29uc29sZS5lcnJvcignaG9tZTogY2xlYXJpbmcgcmVjZW50IHByb2plY3RzIGZhaWxlZCcsIGVycik7XG4gICAgICBjb25zdCBjb2RlID0gdHlwZW9mIGVyciA9PT0gJ29iamVjdCcgJiYgZXJyICE9PSBudWxsICYmICdjb2RlJyBpbiBlcnIgPyBTdHJpbmcoZXJyLmNvZGUpIDogJ3Vua25vd24nO1xuICAgICAgc2V0Q2xlYXJGYWlsdXJlKGNvZGUpO1xuICAgICAgc2V0Q29uZmlybWluZyhmYWxzZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldENsZWFyaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKHN0YXRlLmtpbmQgPT09ICdvZmYnKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJlY1wiIGFyaWEtbGFiZWw9XCJSZWNlbnQgcHJvamVjdHNcIj5cbiAgICAgICAgPFNlY3Rpb25IZWFkaW5nIHRhZz1cIi9SRUNFTlRcIiB0aXRsZT1cIlJlY2VudCBwcm9qZWN0cy5cIiAvPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJyZWMtb2ZmXCI+UmVjZW50cyBhcmUgb2ZmIGZvciB0aGlzIHZlcnNpb24gb2YgSG9tZS48L3A+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicmVjXCIgYXJpYS1sYWJlbD1cIlJlY2VudCBwcm9qZWN0c1wiPlxuICAgICAgPFNlY3Rpb25IZWFkaW5nIHRhZz1cIi9SRUNFTlRcIiB0aXRsZT1cIlJlY2VudCBwcm9qZWN0cy5cIiAvPlxuICAgICAgPEZlYXR1cmVkUHJvamVjdCBwcm9qZWN0PXtzdGF0ZS5mZWF0dXJlZH0gbm93PXtub3d9IHByaW1hcnk9e3ByaW1hcnl9IG1vYmlsZT17bW9iaWxlfSAvPlxuICAgICAge3N0YXRlLnJlc3QubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjLXJvd3NcIj5cbiAgICAgICAgICB7c3RhdGUucmVzdC5tYXAoKHByb2plY3QpID0+IChcbiAgICAgICAgICAgIDxSZWNlbnRSb3dcbiAgICAgICAgICAgICAga2V5PXtgJHtwcm9qZWN0Lm5hbWVzcGFjZX0vJHtwcm9qZWN0LnJlcG9zaXRvcnl9LyR7cHJvamVjdC5yZWZ9YH1cbiAgICAgICAgICAgICAgcHJvamVjdD17cHJvamVjdH1cbiAgICAgICAgICAgICAgbm93PXtub3d9XG4gICAgICAgICAgICAgIG1vYmlsZT17bW9iaWxlfVxuICAgICAgICAgICAgICBkaW1tZWQ9e2NsZWFyaW5nfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAge2NsZWFyRmFpbHVyZSAhPT0gbnVsbCAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInJlYy1jbGVhcl9fZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgQ291bGQgbm90IGNsZWFyIHlvdXIgcmVjZW50IHByb2plY3RzICh7Y2xlYXJGYWlsdXJlfSkuIE5vdGhpbmcgd2FzIHJlbW92ZWQuXG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgICB7Y29uZmlybWluZyA/IChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicmVjLWNsZWFyXCI+XG4gICAgICAgICAgQ2xlYXIgcmVjZW50IHByb2plY3RzP3snICd9XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmVjLWNsZWFyX19idG5cIiBvbkNsaWNrPXtjbGVhcn0gZGlzYWJsZWQ9e2NsZWFyaW5nfSBhcmlhLWJ1c3k9e2NsZWFyaW5nfT5cbiAgICAgICAgICAgIHtjbGVhcmluZyA/ICdDbGVhcmluZ+KApicgOiAnQ2xlYXInfVxuICAgICAgICAgIDwvYnV0dG9uPnsnICd9XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmVjLWNsZWFyX19idG5cIiBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtaW5nKGZhbHNlKX0gZGlzYWJsZWQ9e2NsZWFyaW5nfT5cbiAgICAgICAgICAgIEtlZXBcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9wPlxuICAgICAgKSA6IChcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmVjLWNsZWFyX19saW5lXCIgb25DbGljaz17KCkgPT4gc2V0Q29uZmlybWluZyh0cnVlKX0+XG4gICAgICAgICAgQ2xlYXIgcmVjZW50IHByb2plY3RzXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsZ0JBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUQsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFLLGVBQUEsR0FBQUYsc0JBQUEsQ0FBQUgsT0FBQTtBQUVBQSxPQUFBO0FBQStCLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQUUvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUwsdUJBQUFNLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFZSxTQUFTRyxjQUFjQSxDQUFDO0VBQ3JDQyxLQUFLO0VBQ0xDLEdBQUc7RUFDSEMsT0FBTztFQUNQQyxNQUFNO0VBQ05DO0FBT0YsQ0FBQyxFQUFFO0VBQUFWLEVBQUE7RUFDRCxNQUFNLENBQUNXLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUNuRCxNQUFNLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUMvQyxNQUFNLENBQUNHLFlBQVksRUFBRUMsZUFBZSxDQUFDLEdBQUcsSUFBQUosZUFBUSxFQUFnQixJQUFJLENBQUM7RUFFckUsSUFBSVAsS0FBSyxDQUFDWSxJQUFJLEtBQUssUUFBUSxFQUFFLE9BQU8sSUFBSTtFQUV4QyxNQUFNQyxLQUFLLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQ3hCSixXQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2pCRSxlQUFlLENBQUMsSUFBSSxDQUFDO0lBQ3JCLElBQUk7TUFDRixNQUFNLElBQUFHLHdCQUFtQixFQUFDLENBQUM7TUFDM0JWLFNBQVMsQ0FBQyxDQUFDO0lBQ2IsQ0FBQyxDQUFDLE9BQU9XLEdBQUcsRUFBRTtNQUNaO01BQ0E7TUFDQTtNQUNBQyxPQUFPLENBQUNDLEtBQUssQ0FBQyx1Q0FBdUMsRUFBRUYsR0FBRyxDQUFDO01BQzNELE1BQU1HLElBQUksR0FBRyxPQUFPSCxHQUFHLEtBQUssUUFBUSxJQUFJQSxHQUFHLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSUEsR0FBRyxHQUFHSSxNQUFNLENBQUNKLEdBQUcsQ0FBQ0csSUFBSSxDQUFDLEdBQUcsU0FBUztNQUNwR1AsZUFBZSxDQUFDTyxJQUFJLENBQUM7TUFDckJaLGFBQWEsQ0FBQyxLQUFLLENBQUM7SUFDdEIsQ0FBQyxTQUFTO01BQ1JHLFdBQVcsQ0FBQyxLQUFLLENBQUM7SUFDcEI7RUFDRixDQUFDO0VBRUQsSUFBSVQsS0FBSyxDQUFDWSxJQUFJLEtBQUssS0FBSyxFQUFFO0lBQ3hCLG9CQUNFLElBQUFuQixXQUFBLENBQUEyQixJQUFBO01BQVNDLFNBQVMsRUFBQyxLQUFLO01BQUMsY0FBVyxpQkFBaUI7TUFBQUMsUUFBQSxnQkFDbkQsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQy9CLGVBQUEsQ0FBQU0sT0FBYztRQUFDMEIsR0FBRyxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDO01BQWtCLENBQUUsQ0FBQyxlQUN6RCxJQUFBaEMsV0FBQSxDQUFBOEIsR0FBQTtRQUFHRixTQUFTLEVBQUMsU0FBUztRQUFBQyxRQUFBLEVBQUM7TUFBeUMsQ0FBRyxDQUFDO0lBQUEsQ0FDN0QsQ0FBQztFQUVkO0VBRUEsb0JBQ0UsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUE7SUFBU0MsU0FBUyxFQUFDLEtBQUs7SUFBQyxjQUFXLGlCQUFpQjtJQUFBQyxRQUFBLGdCQUNuRCxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDL0IsZUFBQSxDQUFBTSxPQUFjO01BQUMwQixHQUFHLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUM7SUFBa0IsQ0FBRSxDQUFDLGVBQ3pELElBQUFoQyxXQUFBLENBQUE4QixHQUFBLEVBQUNsQyxnQkFBQSxDQUFBUyxPQUFlO01BQUM0QixPQUFPLEVBQUUxQixLQUFLLENBQUMyQixRQUFTO01BQUMxQixHQUFHLEVBQUVBLEdBQUk7TUFBQ0MsT0FBTyxFQUFFQSxPQUFRO01BQUNDLE1BQU0sRUFBRUE7SUFBTyxDQUFFLENBQUMsRUFDdkZILEtBQUssQ0FBQzRCLElBQUksQ0FBQ0MsTUFBTSxHQUFHLENBQUMsaUJBQ3BCLElBQUFwQyxXQUFBLENBQUE4QixHQUFBO01BQUtGLFNBQVMsRUFBQyxVQUFVO01BQUFDLFFBQUEsRUFDdEJ0QixLQUFLLENBQUM0QixJQUFJLENBQUNFLEdBQUcsQ0FBRUosT0FBTyxpQkFDdEIsSUFBQWpDLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ2hDLFVBQUEsQ0FBQU8sT0FBUztRQUVSNEIsT0FBTyxFQUFFQSxPQUFRO1FBQ2pCekIsR0FBRyxFQUFFQSxHQUFJO1FBQ1RFLE1BQU0sRUFBRUEsTUFBTztRQUNmNEIsTUFBTSxFQUFFdkI7TUFBUyxHQUpaLEdBQUdrQixPQUFPLENBQUNNLFNBQVMsSUFBSU4sT0FBTyxDQUFDTyxVQUFVLElBQUlQLE9BQU8sQ0FBQ1EsR0FBRyxFQUsvRCxDQUNGO0lBQUMsQ0FDQyxDQUNOLEVBQ0F4QixZQUFZLEtBQUssSUFBSSxpQkFDcEIsSUFBQWpCLFdBQUEsQ0FBQTJCLElBQUE7TUFBR0MsU0FBUyxFQUFDLGtCQUFrQjtNQUFDYyxJQUFJLEVBQUMsUUFBUTtNQUFBYixRQUFBLEdBQUMsd0NBQ04sRUFBQ1osWUFBWSxFQUFDLHlCQUN0RDtJQUFBLENBQUcsQ0FDSixFQUNBTCxVQUFVLGdCQUNULElBQUFaLFdBQUEsQ0FBQTJCLElBQUE7TUFBR0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxHQUFDLHdCQUNELEVBQUMsR0FBRyxlQUMxQixJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQTtRQUFRYSxJQUFJLEVBQUMsUUFBUTtRQUFDZixTQUFTLEVBQUMsZ0JBQWdCO1FBQUNnQixPQUFPLEVBQUV4QixLQUFNO1FBQUN5QixRQUFRLEVBQUU5QixRQUFTO1FBQUMsYUFBV0EsUUFBUztRQUFBYyxRQUFBLEVBQ3RHZCxRQUFRLEdBQUcsV0FBVyxHQUFHO01BQU8sQ0FDM0IsQ0FBQyxFQUFDLEdBQUcsZUFDYixJQUFBZixXQUFBLENBQUE4QixHQUFBO1FBQVFhLElBQUksRUFBQyxRQUFRO1FBQUNmLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQ2dCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNL0IsYUFBYSxDQUFDLEtBQUssQ0FBRTtRQUFDZ0MsUUFBUSxFQUFFOUIsUUFBUztRQUFBYyxRQUFBLEVBQUM7TUFFMUcsQ0FBUSxDQUFDO0lBQUEsQ0FDUixDQUFDLGdCQUVKLElBQUE3QixXQUFBLENBQUE4QixHQUFBO01BQVFhLElBQUksRUFBQyxRQUFRO01BQUNmLFNBQVMsRUFBQyxpQkFBaUI7TUFBQ2dCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNL0IsYUFBYSxDQUFDLElBQUksQ0FBRTtNQUFBZ0IsUUFBQSxFQUFDO0lBRXRGLENBQVEsQ0FDVDtFQUFBLENBQ00sQ0FBQztBQUVkO0FBQUM1QixFQUFBLENBdEZ1QkssY0FBYztBQUFBd0MsRUFBQSxHQUFkeEMsY0FBYztBQUFBLElBQUF3QyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}