var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = RecentRow;
var _platformLink = require("@immediately-run/sdk/platformLink");
var _recents = require("../lib/recents");
var _routes = require("../lib/routes");
var _jsxRuntime = require("react/jsx-runtime");
// One quiet row of the backlog list — hairline-separated by the shared
// container, never bordered on its own. The phone row carries Open only
// (1e); the row is not the place to discover editing.
function RecentRow({
  project,
  now,
  mobile,
  dimmed = false
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: dimmed ? 'rec-row rec-row--clearing' : 'rec-row',
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "rec-row__name",
      children: [project.namespace, "/", project.repository]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rec-chip rec-chip--sm",
      children: project.ref
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "rec-row__opened",
      children: (0, _recents.relativeOpened)(project.ts, now)
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "rec-row__actions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
        path: (0, _routes.presentRoute)(project),
        className: "rec-pill",
        children: "Open"
      }), !mobile && /*#__PURE__*/(0, _jsxRuntime.jsx)(_platformLink.PlatformLink, {
        path: (0, _routes.editRoute)(project),
        className: "rec-pill rec-pill--quiet",
        children: "Edit"
      })]
    })]
  });
}
_c = RecentRow;
var _c;
$RefreshReg$(_c, "RecentRow");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGxhdGZvcm1MaW5rIiwicmVxdWlyZSIsIl9yZWNlbnRzIiwiX3JvdXRlcyIsIl9qc3hSdW50aW1lIiwiUmVjZW50Um93IiwicHJvamVjdCIsIm5vdyIsIm1vYmlsZSIsImRpbW1lZCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm5hbWVzcGFjZSIsInJlcG9zaXRvcnkiLCJqc3giLCJyZWYiLCJyZWxhdGl2ZU9wZW5lZCIsInRzIiwiUGxhdGZvcm1MaW5rIiwicGF0aCIsInByZXNlbnRSb3V0ZSIsImVkaXRSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVjZW50Um93LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbGF0Zm9ybUxpbmsgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9wbGF0Zm9ybUxpbmsnO1xuaW1wb3J0IHR5cGUgeyBSZWNlbnRQcm9qZWN0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgcmVsYXRpdmVPcGVuZWQgfSBmcm9tICcuLi9saWIvcmVjZW50cyc7XG5pbXBvcnQgeyBlZGl0Um91dGUsIHByZXNlbnRSb3V0ZSB9IGZyb20gJy4uL2xpYi9yb3V0ZXMnO1xuXG4vLyBPbmUgcXVpZXQgcm93IG9mIHRoZSBiYWNrbG9nIGxpc3Qg4oCUIGhhaXJsaW5lLXNlcGFyYXRlZCBieSB0aGUgc2hhcmVkXG4vLyBjb250YWluZXIsIG5ldmVyIGJvcmRlcmVkIG9uIGl0cyBvd24uIFRoZSBwaG9uZSByb3cgY2FycmllcyBPcGVuIG9ubHlcbi8vICgxZSk7IHRoZSByb3cgaXMgbm90IHRoZSBwbGFjZSB0byBkaXNjb3ZlciBlZGl0aW5nLlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZWNlbnRSb3coe1xuICBwcm9qZWN0LFxuICBub3csXG4gIG1vYmlsZSxcbiAgZGltbWVkID0gZmFsc2UsXG59OiB7XG4gIHByb2plY3Q6IFJlY2VudFByb2plY3Q7XG4gIG5vdzogbnVtYmVyO1xuICBtb2JpbGU6IGJvb2xlYW47XG4gIGRpbW1lZD86IGJvb2xlYW47XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2RpbW1lZCA/ICdyZWMtcm93IHJlYy1yb3ctLWNsZWFyaW5nJyA6ICdyZWMtcm93J30+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWMtcm93X19uYW1lXCI+XG4gICAgICAgIHtwcm9qZWN0Lm5hbWVzcGFjZX0ve3Byb2plY3QucmVwb3NpdG9yeX1cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlYy1jaGlwIHJlYy1jaGlwLS1zbVwiPntwcm9qZWN0LnJlZn08L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWMtcm93X19vcGVuZWRcIj57cmVsYXRpdmVPcGVuZWQocHJvamVjdC50cywgbm93KX08L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWMtcm93X19hY3Rpb25zXCI+XG4gICAgICAgIDxQbGF0Zm9ybUxpbmsgcGF0aD17cHJlc2VudFJvdXRlKHByb2plY3QpfSBjbGFzc05hbWU9XCJyZWMtcGlsbFwiPlxuICAgICAgICAgIE9wZW5cbiAgICAgICAgPC9QbGF0Zm9ybUxpbms+XG4gICAgICAgIHshbW9iaWxlICYmIChcbiAgICAgICAgICA8UGxhdGZvcm1MaW5rIHBhdGg9e2VkaXRSb3V0ZShwcm9qZWN0KX0gY2xhc3NOYW1lPVwicmVjLXBpbGwgcmVjLXBpbGwtLXF1aWV0XCI+XG4gICAgICAgICAgICBFZGl0XG4gICAgICAgICAgPC9QbGF0Zm9ybUxpbms+XG4gICAgICAgICl9XG4gICAgICA8L3NwYW4+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLFFBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUF3RCxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFFeEQ7QUFDQTtBQUNBO0FBRWUsU0FBU0ksU0FBU0EsQ0FBQztFQUNoQ0MsT0FBTztFQUNQQyxHQUFHO0VBQ0hDLE1BQU07RUFDTkMsTUFBTSxHQUFHO0FBTVgsQ0FBQyxFQUFFO0VBQ0Qsb0JBQ0UsSUFBQUwsV0FBQSxDQUFBTSxJQUFBO0lBQUtDLFNBQVMsRUFBRUYsTUFBTSxHQUFHLDJCQUEyQixHQUFHLFNBQVU7SUFBQUcsUUFBQSxnQkFDL0QsSUFBQVIsV0FBQSxDQUFBTSxJQUFBO01BQU1DLFNBQVMsRUFBQyxlQUFlO01BQUFDLFFBQUEsR0FDNUJOLE9BQU8sQ0FBQ08sU0FBUyxFQUFDLEdBQUMsRUFBQ1AsT0FBTyxDQUFDUSxVQUFVO0lBQUEsQ0FDbkMsQ0FBQyxlQUNQLElBQUFWLFdBQUEsQ0FBQVcsR0FBQTtNQUFNSixTQUFTLEVBQUMsdUJBQXVCO01BQUFDLFFBQUEsRUFBRU4sT0FBTyxDQUFDVTtJQUFHLENBQU8sQ0FBQyxlQUM1RCxJQUFBWixXQUFBLENBQUFXLEdBQUE7TUFBTUosU0FBUyxFQUFDLGlCQUFpQjtNQUFBQyxRQUFBLEVBQUUsSUFBQUssdUJBQWMsRUFBQ1gsT0FBTyxDQUFDWSxFQUFFLEVBQUVYLEdBQUc7SUFBQyxDQUFPLENBQUMsZUFDMUUsSUFBQUgsV0FBQSxDQUFBTSxJQUFBO01BQU1DLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxnQkFDaEMsSUFBQVIsV0FBQSxDQUFBVyxHQUFBLEVBQUNmLGFBQUEsQ0FBQW1CLFlBQVk7UUFBQ0MsSUFBSSxFQUFFLElBQUFDLG9CQUFZLEVBQUNmLE9BQU8sQ0FBRTtRQUFDSyxTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLEVBQUM7TUFFaEUsQ0FBYyxDQUFDLEVBQ2QsQ0FBQ0osTUFBTSxpQkFDTixJQUFBSixXQUFBLENBQUFXLEdBQUEsRUFBQ2YsYUFBQSxDQUFBbUIsWUFBWTtRQUFDQyxJQUFJLEVBQUUsSUFBQUUsaUJBQVMsRUFBQ2hCLE9BQU8sQ0FBRTtRQUFDSyxTQUFTLEVBQUMsMEJBQTBCO1FBQUFDLFFBQUEsRUFBQztNQUU3RSxDQUFjLENBQ2Y7SUFBQSxDQUNHLENBQUM7RUFBQSxDQUNKLENBQUM7QUFFVjtBQUFDVyxFQUFBLEdBOUJ1QmxCLFNBQVM7QUFBQSxJQUFBa0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}