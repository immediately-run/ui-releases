var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      p: "p",
      pre: "pre",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "home-the-immediatelyrun-launcher",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "home-the-immediatelyrun-launcher"
      }), "Home — the immediately.run launcher"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The signed-in launcher bound at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "page.home"
      }), ": the greeting row, the two link\ntiles and the footer, with the recents and spaces sections landing on top\n(see the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "workbench-modes"
      }), " roadmap items in the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://github.com/immediately-run/docs",
        children: "docs repo"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Runs as an immediately.run app — React + TypeScript loaded from this repo and\ntranspiled in the browser. The repo rules (entry point, sandbox limits, the\nSDK API index) are in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), "; verify with:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run verify   # lint && build && test\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwicCIsInByZSIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJob21lLXRoZS1pbW1lZGlhdGVseXJ1bi1sYXVuY2hlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaG9tZS10aGUtaW1tZWRpYXRlbHlydW4tbGF1bmNoZXJcIiAvPntcIkhvbWUg4oCUIHRoZSBpbW1lZGlhdGVseS5ydW4gbGF1bmNoZXJcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBzaWduZWQtaW4gbGF1bmNoZXIgYm91bmQgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFnZS5ob21lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogdGhlIGdyZWV0aW5nIHJvdywgdGhlIHR3byBsaW5rXFxudGlsZXMgYW5kIHRoZSBmb290ZXIsIHdpdGggdGhlIHJlY2VudHMgYW5kIHNwYWNlcyBzZWN0aW9ucyBsYW5kaW5nIG9uIHRvcFxcbihzZWUgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndvcmtiZW5jaC1tb2Rlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcm9hZG1hcCBpdGVtcyBpbiB0aGVcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL2ltbWVkaWF0ZWx5LXJ1bi9kb2NzXCI+e1wiZG9jcyByZXBvXCJ9PC9fY29tcG9uZW50cy5hPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJ1bnMgYXMgYW4gaW1tZWRpYXRlbHkucnVuIGFwcCDigJQgUmVhY3QgKyBUeXBlU2NyaXB0IGxvYWRlZCBmcm9tIHRoaXMgcmVwbyBhbmRcXG50cmFuc3BpbGVkIGluIHRoZSBicm93c2VyLiBUaGUgcmVwbyBydWxlcyAoZW50cnkgcG9pbnQsIHNhbmRib3ggbGltaXRzLCB0aGVcXG5TREsgQVBJIGluZGV4KSBhcmUgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdmVyaWZ5IHdpdGg6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtYmFzaFwiPntcIm5wbSBydW4gdmVyaWZ5ICAgIyBsaW50ICYmIGJ1aWxkICYmIHRlc3RcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1AsS0FBSyxDQUFDUTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1IsV0FBVztFQUNoQyxJQUFJLENBQUNRLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBWixXQUFBLENBQUFhLElBQUEsRUFBQWIsV0FBQSxDQUFBYyxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWYsV0FBQSxDQUFBYSxJQUFBLEVBQUNWLFdBQVcsQ0FBQ0csRUFBRTtNQUFDVSxFQUFFLEVBQUMsa0NBQWtDO01BQUFELFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrQyxDQUFFLENBQUMsRUFBQyxxQ0FBcUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsd0hBQXdILGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNFLElBQUk7UUFBQVUsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDYyxJQUFJLEVBQUMseUNBQXlDO1FBQUFILFFBQUEsRUFBRTtNQUFXLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSxvTEFBb0wsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssR0FBRztNQUFBTyxRQUFBLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNFLElBQUk7UUFBQ2MsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQTRDLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNqaEM7QUFDZSxTQUFTSyxVQUFVQSxDQUFDbEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ21CLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdQLEtBQUssQ0FBQ1E7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBdEIsV0FBQSxDQUFBaUIsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS3BCLEtBQUs7SUFBQWEsUUFBQSxlQUFFLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2hCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNxQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}