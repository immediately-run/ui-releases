var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "working-in-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "working-in-this-repo"
      }), "Working in this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "immediately.run app"
      }), ": React + TypeScript that loads from GitHub and\ntranspiles in the browser (no server, no build step at runtime). Keep the rules\nbelow or the app breaks ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " on immediately.run while still looking fine in\nlocal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " — the most common silent failure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-rules-these-break-immediatelyrun-if-violated",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-rules-these-break-immediatelyrun-if-violated"
      }), "Hard rules (these break immediately.run if violated)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/App.tsx"
          }), " is the entry point."]
        }), " immediately.run renders its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "default\nexport"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/main.tsx"
        }), " is for local dev/build only and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "ignored"
        }), " at\nruntime — never put CSS imports, providers, or app logic there."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Import global CSS from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          })]
        }), ", not from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), ". Anything the\nrendered tree needs (CSS, context providers) must be reachable from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A file that exports a React component exports ONLY components."
        }), " No mixing a\ncomponent with named exports of data/constants/helpers. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "interface"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "type"
        }), "\nare erased at compile time and are fine.) This is the React Fast Refresh rule;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " enforces it. Put data in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ", hooks in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/"
        }), ",\nutilities in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One component per file, default-exported"
        }), ", named for what it renders."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["CSS lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".css"
          }), " files imported from TypeScript"]
        }), " — not in giant\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<style>"
        }), " blocks or inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "style={{}}"
        }), " for the bulk of styling."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Fonts via CSS ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@import"
          })]
        }), " as the first line of the CSS file, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<link>"
        }), "\ntags in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "index.html"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Import local assets"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import logo from './assets/logo.png'"
        }), "); don't\nreference server paths that won't exist in the sandbox."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Node / build-time-only APIs"
        }), " in the rendered tree — it runs in a browser\niframe. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch"
        }), " are available. ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localStorage"
          }), " is\nnot"]
        }), ": apps run at an opaque origin (a sandboxed iframe without\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allow-same-origin"
        }), "), where even ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reading"
        }), " the property throws\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SecurityError"
        }), " — so wrap every access in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "try"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "catch"
        }), " (a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof localStorage === 'undefined'"
        }), " guard does NOT work, because the throw\nis on access, not on the value) and never touch it at module scope. Treat\npersistence as optional and keep the app fully usable without it. This app\nkeeps no local persistence at all — everything it shows is a platform record.\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Downloading a blob works; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "navigating"
          }), " to one does not."]
        }), " A clicked\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<a download href=\"blob:...\">"
        }), " saves the file — the frame carries\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allow-downloads"
        }), " in every stance, and the opaque origin does not stop it.\nBut ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "location.assign(blobUrl)"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.open(blobUrl)"
        }), " silently does nothing\nfor a type the browser would display, because the document that navigation\ncreates gets a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "fresh"
        }), " opaque origin and can no longer resolve the blob. (For\na type Chrome will not display, such as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "text/csv"
        }), ", it converts the\nnavigation into a download — which is why the two paths look inconsistent.)\nSo build exports on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<a download>"
        }), ", and never on \"open it in a tab\".\nMeasured 2026-08-29 (roadmap R3-417)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MDX is only for long-form prose"
        }), " (articles, guides). Structured/repeated\ndata stays as typed arrays in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ". If you add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), ", the Vite plugin\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdx.d.ts"
        }), " shim are already wired up."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "loading-caching-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "loading-caching-on-immediatelyrun"
      }), "Loading & caching on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".github/workflows/cache.yml"
      }), " publishes a pre-cached zip of this repo to its own\nGitHub Pages on each push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", so immediately.run loads fast and within\nanonymous rate limits. To enable it on a repo in your own account/org, turn Pages\non once — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Settings → Pages → Source: GitHub Actions"
      }), " — then push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), "; no\ntokens or secrets. (immediately-run org repos self-provision Pages on the first\nrun via the org's internal deploy GitHub App: its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DEPLOY_APP_ID"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DEPLOY_APP_PRIVATE_KEY"
      }), " org secrets are scoped to all\nrepositories in the org, so the mint step runs on a brand-new repo and no manual\nstep is needed — provided the repo is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "public"
      }), ", since on the Free plan org\nsecrets are unreadable by private repos and Pages needs a public repo anyway.\nOutside the org there is no App — enable Pages once with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "gh api -X POST repos/<owner>/<repo>/pages -f build_type=workflow"
      }), " then\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "gh workflow run cache.yml"
      }), ", or the manual Settings → Pages step.) Don't move the\ncache to a different path or hostname — the client discovers it by convention at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"immediately.run\": { \"requireLatest\": \"...\" }"
      }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " controls\nfreshness. It is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "string enum"
      }), ", not a boolean: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"stale_ok\""
      }), " (always serve\nthe cache, fastest, offline-friendly), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"optimistic\""
      }), " (the default — serve\ncache, check in background), or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"strict\""
      }), " (always run the newest commit, at\nthe cost of a freshness check on launch). Leave it unset unless\nto-the-commit freshness matters; the default is fast and works offline."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "design-system",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-system"
      }), "Design system"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This brand is: cool near-black canvas · magenta↔violet signature gradient ·\nGabarito display type · Space Mono details · hairline borders · hard-offset hover\nshadows · sentence case · headlines end on a period · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no emoji"
      }), ". Dark is the\ndefault; a light theme is wired via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-theme=\"light\""
      }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<html>"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/index.css"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--shadow-card"
        }), ", the type families, etc.) instead of\nhard-coding colors, radii, or fonts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Apply the signature gradient to text with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className=\"grad-text\""
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["For icons beyond the unicode set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "→ ★ ● ☀ ☾"
        }), "), use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://lucide.dev",
          children: "Lucide"
        }), " at 16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ". No emoji."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "finding-the-sdk-api-read-this-before-guessing-imports",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "finding-the-sdk-api-read-this-before-guessing-imports"
      }), "Finding the SDK API (read this before guessing imports)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Everything the platform offers comes from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), ". Don't guess\nexport names or signatures — look them up. The package ships full API docs,\nfetchable in one request and optimized for both humans and coding agents:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "llms.txt"
          })
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/llms.txt",
          children: "https://immediately-run.github.io/immediately-run-sdk/llms.txt"
        }), " —\na concise map of every export grouped by module, with its kind, import path,\nand a one-line description. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Start here."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "api.json"
          })
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/api.json",
          children: "https://immediately-run.github.io/immediately-run-sdk/api.json"
        }), " —\nthe complete TypeDoc model (exact signatures, parameters, types) when you need\nmore than the one-liners."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "HTML reference"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/",
          children: "https://immediately-run.github.io/immediately-run-sdk/"
        }), " —\nhuman-browsable."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Once installed, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "node_modules/@immediately-run/sdk"
      }), " ships ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".d.ts"
      }), " carrying the\nsame JSDoc, so your editor/agent reads the typed API inline with no network. All\nexports are importable from the package root (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), ") or a\nper-module subpath (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk/hooks"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "keep-your-corner-controls-clear-of-the-platform-pill",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "keep-your-corner-controls-clear-of-the-platform-pill"
      }), "Keep your corner controls clear of the platform pill"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["On immediately.run the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "platform pill floats over your app's top-right corner"
      }), "\n(it is how the user reaches the platform menu). Anything you anchor there — a\ntheme toggle, a menu button, a close affordance — can end up underneath it, and\nyour app cannot measure the pill: it is host chrome, outside your iframe."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The host reports the covered box on the form-factor channel, as\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "insets: { top, right, bottom, left }"
      }), " in CSS px."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Read it as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "rectangle per edge"
      }), ": each number is the distance inward from that\nedge of your viewport where platform chrome may sit, and the chrome is in the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "intersection"
      }), " of the nonzero bands. Today that means a nonzero ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "top"
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "right"
      }), " with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "bottom"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "left"
      }), " at 0 — i.e. only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "top-right corner rectangle"
      }), "\nis covered. All zeros means nothing is over you (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ", edit mode, or a host\nthat does not report it — the field is additive, so it is always safe to read)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Pad the control, not the layout."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "index.css"
      }), " declares\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--chrome-inset-top"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--chrome-inset-right"
      }), " (0 by default); a control that\nanchors in that corner pads itself by them. Feed them from the host, once,\nnear your root:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "const { insets } = useFormFactor();\nuseEffect(() => {\n  const root = document.documentElement;\n  root.style.setProperty('--chrome-inset-top', `${insets.top}px`);\n  root.style.setProperty('--chrome-inset-right', `${insets.right}px`);\n}, [insets.top, insets.right]);\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Do ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " reserve a permanent gutter or push your whole page down: apps with\nnothing in that corner should pay nothing, and full-bleed content is meant to run\nunderneath it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Two caveats while this is landing. The host pushes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "insets"
      }), " today, but\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useFormFactor()"
      }), " does not surface it yet — the field is part of the frozen\nsandbox↔SDK wire contract and lands with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sandbox-protocol"
      }), "\nrelease (roadmap R3-415). Until then the vars stay 0 and your layout is unchanged,\nso the wiring above is safe to write now. Separately, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chrome:read"
      }), "'s overlay\nstate tells you whether a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "transient"
      }), " platform menu is open right now — a\ndifferent question from where chrome sits at rest."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "platform-security-model-what-your-app-can-and-cant-do",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "platform-security-model-what-your-app-can-and-cant-do"
      }), "Platform security model (what your app can and can't do)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Your app runs in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sandboxed iframe with an opaque origin"
      }), ". The rules below\nfollow from that and from the platform capability model\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/UI_AS_APPS_SPEC.md"
      }), " §8 in the docs repo). Violations don't just\nbreak your app — calls fail with typed errors, and trying to work around them\nreads as hostile. (Enforcement is rolling out per the spec's §10 ladder —\nitems 4, 6 and 8 describe machinery that is specified but not yet live; write\nnew code as if they're enforced and it will keep working as they land.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["All platform interaction goes through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          }), "."]
        }), " There is\nno other channel: no shared storage with other apps, no reaching sibling\niframes, no postMessage of your own to the parent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Never handle user credentials."
        }), " You will never see the user's GitHub\ntoken, API keys, or any secret — sign-in and privileged actions are\nhost-driven. Call protocol methods reactively, gated on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "getAuthState().status === 'signed-in'"
        }), "; never store or request tokens."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The filesystem you see is the filesystem you got."
        }), " Mounts the host gives\nyou (your app's spaces, granted folders) are your whole world — outside\npaths don't exist, and a grant may be read-only. Don't probe for escapes\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".."
        }), ", absolute paths); writes to read-only mounts fail with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Access to more data is asked for, not taken."
        }), " Need another space or\nfolder? Call the SDK request method and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user"
        }), " picks in host UI. Expect\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code: 'cancelled' | 'forbidden' }"
        }), " and handle it gracefully."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Handle typed errors everywhere."
        }), " Platform calls reply\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code, message }"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "auth-required"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invalid-params"
        }), ", …). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), " means your app lacks that capability —\nthat's policy, not a bug to retry around."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declare what you invoke and provide."
        }), " Cross-app tasks go in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"immediately.run\""
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"invokes\""
        }), " for task contracts\nyou call, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"provides\""
        }), " for ones you implement. Undeclared invocations are\nrejected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Don't imitate host chrome."
        }), " Never render fake sign-in prompts, consent\ndialogs, or the platform's seam/header UI. The host draws those; imitations\nare treated as spoofing."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "If you embed an LLM agent, its tool list is your catalog."
        }), " Use the\nSDK-provided method catalog as the agent's tools — it is pre-filtered to\nyour app's grants, so the agent can't exceed what your app may do. Don't\nhand-roll tools that shell around the SDK."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Expect cancellation and absence."
        }), " Interactive flows can resolve\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "; capabilities can be absent on a fork of your app. Degrade\nfeatures, don't crash."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "editing-delegate-to-the-platform-editor",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "editing-delegate-to-the-platform-editor"
      }), "Editing: delegate to the platform editor"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Your app's default text/code/file editing experience is the platform editor,\nnot a bespoke in-app editor."
      }), " When the thing the user edits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " a file (a\nMarkdown/MDX note, a JSON config, a source module, a CSV), hand that file to the\nplatform's editing surface instead of shipping your own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<textarea>"
      }), " or code\neditor. This is the same instinct as not reimplementing sign-in or PR review:\nthere is already a good, forkable, mobile-capable, agent-readable editor — use it.\n(Full rationale and the proposed platform additions are in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/EDITOR_FIRST_EDITING_SPEC.md"
      }), ".)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Edit a file in one of your mounts via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit-file"
          }), " task."]
        }), " Delegate a\ncapability for exactly that one file; the host opens the editor and tears the\ndelegation down when done. No consent prompt — you're narrowing a grant you\nalready hold:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-ts",
            children: "import { invokeTask, capFile } from '@immediately-run/sdk';\nawait invokeTask('edit-file', {\n  file: capFile({ mountId: 'space:abc', relPath: 'notes/idea.mdx' }, { mode: 'rw' }),\n});\n"
          })
        }), "\n", "This is exactly how the whiteboard's \"Open source\" button works."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Offer \"edit\" as an affordance on the item, not a mode of your app."
        }), " Select\nan object / focus a row → an edit icon that opens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "that"
        }), " file. Keep your\nrun-mode UI free of editor chrome (run-mode comes first)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Gate the affordance on writability."
        }), " Show it only when the mount is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), ";\nre-evaluate on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onMountsChange"
        }), " and hide it on a role downgrade. Never show a\nbutton that comes back ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read-only"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", and never surface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " as UX."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A few typed fields is a form, not an editor."
        }), " An inspector that sets a\ncolor, tags, or a lock toggle should be inline UI. Reach for the platform\neditor for the free-form body / the whole file."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build a real in-app editor only with a stated reason"
        }), " — the content isn't a\nfile the platform editor can edit (freehand drawing, a node graph,\ndirect-manipulation geometry), or a measured UX need the platform editor can't\nmeet. Write the reason down; convenience is not a reason."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Known gaps (don't paper over them with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<textarea>"
          }), "):"]
        }), " an app running in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "present"
        }), " mode can't yet summon the edit experience on its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "own source"
        }), ", and\nopening a specific mounted file in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "main"
        }), " editor (vs. the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), "\noverlay) from a standalone app isn't supported yet. Both are specified as\nproposed deltas in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), " §6; until they land, rely on\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " task and the host's edit experience rather than rolling your own."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verify-before-youre-done",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verify-before-youre-done"
      }), "Verify before you're done"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run build   # must pass with no type errors\nnpm run lint    # must pass — this is the cheapest proof the Fast Refresh rule holds\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Then eyeball the page (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev"
      }), ") and click any interactive controls."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "persistence-not-needed-here-kept-for-forks",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "persistence-not-needed-here-kept-for-forks"
      }), "Persistence: not needed here (kept for forks)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Home keeps no app-local data — every surface it renders is a platform record\n(recents, spaces) read through the SDK. A fork that wants its own data should\nstart from the storage starter in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "new-project-template"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/store.ts"
      }), "):\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "private settings first"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "openSettings()"
      }), " — per-user, per-app, no prompt), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a\nremembered data space"
      }), " (create once with consent, then re-open by id from\nsettings — only the create path prompts), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "one JSON record per file"
      }), " (the\nplatform fs is last-write-wins per file; records keep writes from contending and\nreads whole). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "openAppStore()"
      }), " handles the whole flow, degrades to an in-memory\nsession when signed out or declined, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "watchRecords"
      }), " uses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs.watch (remote changes ARE delivered as watch events) with a poll fallback on older hosts. Seeding is idempotent and the "
      }), "seeded` marker is written last — see the\nStrictMode truth below."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "platform-truths-facts-every-app-here-has-hit-read-once-save-an-hour",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "platform-truths-facts-every-app-here-has-hit-read-once-save-an-hour"
      }), "Platform truths (facts every app here has hit; read once, save an hour)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "These are behaviors of the real environment, not bugs in your code. Each cost a\nbuilder a debugging session during the example-app program (2026-08); they are\none line each so they get read."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Lint / React"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "eslint-plugin-react-hooks"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "v7"
        }), " rejects ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "setState"
        }), " calls inside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useEffect"
        }), "\n(and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ref.current = x"
        }), " during render) — v7 makes these hard errors. Derive\nvalues during render instead of syncing them into state (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "const x = useMemo("
        }), "\nor plain derivation, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useEffect(() => setX(...))"
        }), "); when a component must\nreset when an identity changes, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "remount by key"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Panel key={id} />"
        }), "), not\nvia an effect. Both patterns are the accepted resolutions."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["React ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "StrictMode runs your boot effect twice"
        }), " in dev — first-run seeding\nmust be idempotent. Write a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "seeded"
        }), " marker file ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "last"
        }), " (after all seed\nfiles) and single-flight the seed; note a one-shot ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useRef"
        }), " guard is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "not"
        }), "\nenough (StrictMode discards the first ref, leaving a \"Loading…\" app forever).\nThe platform tolerates concurrent writes (a lost create-race no longer\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EEXIST"
        }), "s), but your seed should still be order-independent."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "What works in the sandbox (don't assume it doesn't)"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.confirm"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.alert"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "work"
        }), " in the app frame."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "crypto.subtle"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "crypto.getRandomValues"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "work"
        }), " (plus the SDK-shimmed\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "crypto.randomBytes"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "What doesn't"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Blob downloads are blocked"
        }), " in the app frame (no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allow-downloads"
        }), " on the\niframe) — an \"export\" button must copy to the clipboard / a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<textarea>"
        }), "\ninstead of creating an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<a download>"
        }), " URL."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "localStorage"
        }), " — see hard rule 8 (throws on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "access"
        }), " at the opaque origin)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Host vs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), " differences"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useFormFactor()"
        }), " reports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "desktop"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), " (the host channel is\nabsent locally); only the host gives the real answer."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useAuth()"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never settles"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), ", and on the host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "user"
        }), " is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "null"
        }), " until the user has actually signed in — build the signed-out state as\na first-class UI, not an error."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sdk/tasks"
        }), " must be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "lazy-imported"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "await import('@immediately-run/sdk/tasks')"
        }), "\ninside the code path that needs it) — the module has an eval-time side effect\nthat misbehaves under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Small sharp edges"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SandboxMount.name"
        }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["absent right after ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "createSpace"
          })]
        }), " resolves — fall\nback to your own name for the first render, don't dereference it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["An interactive SVG group (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<g>"
        }), ") containing a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<text>"
        }), " label can vanish from\nthe accessibility tree — put the accessible name/role on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<g>"
        }), " (or wrap\nin a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<button>"
        }), ") rather than relying on the text child."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The SDK is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "pinned exactly"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " (the platform resolves the\npin, and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^"
        }), " range resolves to its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "floor"
        }), " — a stale major-minor silently).\nA scheduled workflow here fails when the pin drifts behind npm; bump it in\nthe same PR as your app changes that need the new API."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "debugging-on-immediatelyrun-not-just-vite-dev",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "debugging-on-immediatelyrun-not-just-vite-dev"
      }), "Debugging on immediately.run (not just ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " proves your app renders, but the failure mode this whole file warns about\n— ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "\"works locally, breaks on immediately.run\""
      }), " — only shows up ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "running inside the\nhost"
      }), ": the sandboxed iframe, the SDK channel, the capability gate. Debug there too."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Drive a real browser with Chrome DevTools MCP."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mcp__chrome-devtools__*"
        }), "\ntools navigate the page, take an accessibility ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "snapshot"
        }), " (element ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "uid"
        }), "s to\nclick/fill), run JS with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "evaluate_script"
          })
        }), ", and read the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "console"
        }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "network"
        }), " — which is where SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code }"
        }), " replies and sandbox errors\nactually surface. Reproduce, then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_console_messages"
        }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_network_requests"
        }), "; don't guess from the rendered DOM alone."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Run your app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "on the host"
          }), ", with no commit, via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "local"
          }), " provider."]
        }), " Mount\nyour working tree into the real host and edit live:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-bash",
            children: "immediately.run dev . --origin https://local.immediately.run --json\n# → open the printed /edit/local/<name>-<hash8>/.../live#ir-endpoint=…&ir-token=… link\n"
          })
        }), "\n", "Edits on disk hot-reload in the host preview, so you exercise the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "real"
        }), " SDK +\ncapability path (consent prompts, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", mounts) instead of a local stub. A\ndev-served app gets a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "fresh appKey"
        }), " with no prior grants — handy for testing\nyour first-run consent flow honestly. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/cli"
        }), ", Node ≥ 18, git\nrepo.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Always use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "https://local.immediately.run"
          }), ", never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localhost"
          })]
        }), " — config is\nkeyed by hostname and only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "*.immediately.run"
        }), " origin is fully wired\n(sandbox + backend + auth allowlist)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A passkey / Touch-ID prompt can't be automated"
        }), " — the first secret unseal or\nsign-in raises a native dialog; hand that step to a human, or reload after it's\ncached."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["The platform repo also ships a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.__irTest"
        }), " host hook for scripting\nspace/share drills, but that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host-internal"
        }), " (dev builds of immediately.run\nitself) — not something your app uses or should rely on. The full platform-side\nworkflow lives in the docs repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tutorials/browser_debugging/"
        }), "."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDTEFVREUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwid29ya2luZy1pbi10aGlzLXJlcG9cIj48SGVhZGluZ0FuY2hvciBpZD1cIndvcmtpbmctaW4tdGhpcy1yZXBvXCIgLz57XCJXb3JraW5nIGluIHRoaXMgcmVwb1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImltbWVkaWF0ZWx5LnJ1biBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFJlYWN0ICsgVHlwZVNjcmlwdCB0aGF0IGxvYWRzIGZyb20gR2l0SHViIGFuZFxcbnRyYW5zcGlsZXMgaW4gdGhlIGJyb3dzZXIgKG5vIHNlcnZlciwgbm8gYnVpbGQgc3RlcCBhdCBydW50aW1lKS4gS2VlcCB0aGUgcnVsZXNcXG5iZWxvdyBvciB0aGUgYXBwIGJyZWFrcyBcIn08X2NvbXBvbmVudHMuZW0+e1wib25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9uIGltbWVkaWF0ZWx5LnJ1biB3aGlsZSBzdGlsbCBsb29raW5nIGZpbmUgaW5cXG5sb2NhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBtb3N0IGNvbW1vbiBzaWxlbnQgZmFpbHVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiIC8+e1wiSGFyZCBydWxlcyAodGhlc2UgYnJlYWsgaW1tZWRpYXRlbHkucnVuIGlmIHZpb2xhdGVkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgZW50cnkgcG9pbnQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIGl0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmF1bHRcXG5leHBvcnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgZm9yIGxvY2FsIGRldi9idWlsZCBvbmx5IGFuZCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImlnbm9yZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXRcXG5ydW50aW1lIOKAlCBuZXZlciBwdXQgQ1NTIGltcG9ydHMsIHByb3ZpZGVycywgb3IgYXBwIGxvZ2ljIHRoZXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW1wb3J0IGdsb2JhbCBDU1MgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBbnl0aGluZyB0aGVcXG5yZW5kZXJlZCB0cmVlIG5lZWRzIChDU1MsIGNvbnRleHQgcHJvdmlkZXJzKSBtdXN0IGJlIHJlYWNoYWJsZSBmcm9tXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGZpbGUgdGhhdCBleHBvcnRzIGEgUmVhY3QgY29tcG9uZW50IGV4cG9ydHMgT05MWSBjb21wb25lbnRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBObyBtaXhpbmcgYVxcbmNvbXBvbmVudCB3aXRoIG5hbWVkIGV4cG9ydHMgb2YgZGF0YS9jb25zdGFudHMvaGVscGVycy4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImludGVyZmFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5hcmUgZXJhc2VkIGF0IGNvbXBpbGUgdGltZSBhbmQgYXJlIGZpbmUuKSBUaGlzIGlzIHRoZSBSZWFjdCBGYXN0IFJlZnJlc2ggcnVsZTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVuZm9yY2VzIGl0LiBQdXQgZGF0YSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGF0YS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBob29rcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG51dGlsaXRpZXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT25lIGNvbXBvbmVudCBwZXIgZmlsZSwgZGVmYXVsdC1leHBvcnRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbmFtZWQgZm9yIHdoYXQgaXQgcmVuZGVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNTUyBsaXZlcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlcyBpbXBvcnRlZCBmcm9tIFR5cGVTY3JpcHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG5vdCBpbiBnaWFudFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxzdHlsZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJsb2NrcyBvciBpbmxpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3R5bGU9e3t9fVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBidWxrIG9mIHN0eWxpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb250cyB2aWEgQ1NTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbXBvcnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFzIHRoZSBmaXJzdCBsaW5lIG9mIHRoZSBDU1MgZmlsZSwgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxsaW5rPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG50YWdzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4Lmh0bWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW1wb3J0IGxvY2FsIGFzc2V0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0IGxvZ28gZnJvbSAnLi9hc3NldHMvbG9nby5wbmcnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGRvbid0XFxucmVmZXJlbmNlIHNlcnZlciBwYXRocyB0aGF0IHdvbid0IGV4aXN0IGluIHRoZSBzYW5kYm94LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gTm9kZSAvIGJ1aWxkLXRpbWUtb25seSBBUElzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHRoZSByZW5kZXJlZCB0cmVlIOKAlCBpdCBydW5zIGluIGEgYnJvd3NlclxcbmlmcmFtZS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aW5kb3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFyZSBhdmFpbGFibGUuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxTdG9yYWdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpc1xcbm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogYXBwcyBydW4gYXQgYW4gb3BhcXVlIG9yaWdpbiAoYSBzYW5kYm94ZWQgaWZyYW1lIHdpdGhvdXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJhbGxvdy1zYW1lLW9yaWdpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB3aGVyZSBldmVuIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWFkaW5nXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIHByb3BlcnR5IHRocm93c1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlY3VyaXR5RXJyb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBzbyB3cmFwIGV2ZXJ5IGFjY2VzcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0cnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNhdGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInR5cGVvZiBsb2NhbFN0b3JhZ2UgPT09ICd1bmRlZmluZWQnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBndWFyZCBkb2VzIE5PVCB3b3JrLCBiZWNhdXNlIHRoZSB0aHJvd1xcbmlzIG9uIGFjY2Vzcywgbm90IG9uIHRoZSB2YWx1ZSkgYW5kIG5ldmVyIHRvdWNoIGl0IGF0IG1vZHVsZSBzY29wZS4gVHJlYXRcXG5wZXJzaXN0ZW5jZSBhcyBvcHRpb25hbCBhbmQga2VlcCB0aGUgYXBwIGZ1bGx5IHVzYWJsZSB3aXRob3V0IGl0LiBUaGlzIGFwcFxcbmtlZXBzIG5vIGxvY2FsIHBlcnNpc3RlbmNlIGF0IGFsbCDigJQgZXZlcnl0aGluZyBpdCBzaG93cyBpcyBhIHBsYXRmb3JtIHJlY29yZC5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkRvd25sb2FkaW5nIGEgYmxvYiB3b3JrczsgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5hdmlnYXRpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiB0byBvbmUgZG9lcyBub3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgY2xpY2tlZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxhIGRvd25sb2FkIGhyZWY9XFxcImJsb2I6Li4uXFxcIj5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNhdmVzIHRoZSBmaWxlIOKAlCB0aGUgZnJhbWUgY2Fycmllc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImFsbG93LWRvd25sb2Fkc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gZXZlcnkgc3RhbmNlLCBhbmQgdGhlIG9wYXF1ZSBvcmlnaW4gZG9lcyBub3Qgc3RvcCBpdC5cXG5CdXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYXRpb24uYXNzaWduKGJsb2JVcmwpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5vcGVuKGJsb2JVcmwpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaWxlbnRseSBkb2VzIG5vdGhpbmdcXG5mb3IgYSB0eXBlIHRoZSBicm93c2VyIHdvdWxkIGRpc3BsYXksIGJlY2F1c2UgdGhlIGRvY3VtZW50IHRoYXQgbmF2aWdhdGlvblxcbmNyZWF0ZXMgZ2V0cyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJmcmVzaFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9wYXF1ZSBvcmlnaW4gYW5kIGNhbiBubyBsb25nZXIgcmVzb2x2ZSB0aGUgYmxvYi4gKEZvclxcbmEgdHlwZSBDaHJvbWUgd2lsbCBub3QgZGlzcGxheSwgc3VjaCBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZXh0L2NzdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGl0IGNvbnZlcnRzIHRoZVxcbm5hdmlnYXRpb24gaW50byBhIGRvd25sb2FkIOKAlCB3aGljaCBpcyB3aHkgdGhlIHR3byBwYXRocyBsb29rIGluY29uc2lzdGVudC4pXFxuU28gYnVpbGQgZXhwb3J0cyBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8YSBkb3dubG9hZD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgbmV2ZXIgb24gXFxcIm9wZW4gaXQgaW4gYSB0YWJcXFwiLlxcbk1lYXN1cmVkIDIwMjYtMDgtMjkgKHJvYWRtYXAgUjMtNDE3KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1EWCBpcyBvbmx5IGZvciBsb25nLWZvcm0gcHJvc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFydGljbGVzLCBndWlkZXMpLiBTdHJ1Y3R1cmVkL3JlcGVhdGVkXFxuZGF0YSBzdGF5cyBhcyB0eXBlZCBhcnJheXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RhdGEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gSWYgeW91IGFkZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFZpdGUgcGx1Z2luXFxuYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHguZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpbSBhcmUgYWxyZWFkeSB3aXJlZCB1cC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibG9hZGluZy1jYWNoaW5nLW9uLWltbWVkaWF0ZWx5cnVuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsb2FkaW5nLWNhY2hpbmctb24taW1tZWRpYXRlbHlydW5cIiAvPntcIkxvYWRpbmcgJiBjYWNoaW5nIG9uIGltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdpdGh1Yi93b3JrZmxvd3MvY2FjaGUueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwdWJsaXNoZXMgYSBwcmUtY2FjaGVkIHppcCBvZiB0aGlzIHJlcG8gdG8gaXRzIG93blxcbkdpdEh1YiBQYWdlcyBvbiBlYWNoIHB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIGltbWVkaWF0ZWx5LnJ1biBsb2FkcyBmYXN0IGFuZCB3aXRoaW5cXG5hbm9ueW1vdXMgcmF0ZSBsaW1pdHMuIFRvIGVuYWJsZSBpdCBvbiBhIHJlcG8gaW4geW91ciBvd24gYWNjb3VudC9vcmcsIHR1cm4gUGFnZXNcXG5vbiBvbmNlIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNldHRpbmdzIOKGkiBQYWdlcyDihpIgU291cmNlOiBHaXRIdWIgQWN0aW9uc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlbiBwdXNoIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBub1xcbnRva2VucyBvciBzZWNyZXRzLiAoaW1tZWRpYXRlbHktcnVuIG9yZyByZXBvcyBzZWxmLXByb3Zpc2lvbiBQYWdlcyBvbiB0aGUgZmlyc3RcXG5ydW4gdmlhIHRoZSBvcmcncyBpbnRlcm5hbCBkZXBsb3kgR2l0SHViIEFwcDogaXRzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiREVQTE9ZX0FQUF9JRFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiREVQTE9ZX0FQUF9QUklWQVRFX0tFWVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3JnIHNlY3JldHMgYXJlIHNjb3BlZCB0byBhbGxcXG5yZXBvc2l0b3JpZXMgaW4gdGhlIG9yZywgc28gdGhlIG1pbnQgc3RlcCBydW5zIG9uIGEgYnJhbmQtbmV3IHJlcG8gYW5kIG5vIG1hbnVhbFxcbnN0ZXAgaXMgbmVlZGVkIOKAlCBwcm92aWRlZCB0aGUgcmVwbyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInB1YmxpY1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc2luY2Ugb24gdGhlIEZyZWUgcGxhbiBvcmdcXG5zZWNyZXRzIGFyZSB1bnJlYWRhYmxlIGJ5IHByaXZhdGUgcmVwb3MgYW5kIFBhZ2VzIG5lZWRzIGEgcHVibGljIHJlcG8gYW55d2F5Llxcbk91dHNpZGUgdGhlIG9yZyB0aGVyZSBpcyBubyBBcHAg4oCUIGVuYWJsZSBQYWdlcyBvbmNlIHdpdGhcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJnaCBhcGkgLVggUE9TVCByZXBvcy88b3duZXI+LzxyZXBvPi9wYWdlcyAtZiBidWlsZF90eXBlPXdvcmtmbG93XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGVuXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2ggd29ya2Zsb3cgcnVuIGNhY2hlLnltbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9yIHRoZSBtYW51YWwgU2V0dGluZ3Mg4oaSIFBhZ2VzIHN0ZXAuKSBEb24ndCBtb3ZlIHRoZVxcbmNhY2hlIHRvIGEgZGlmZmVyZW50IHBhdGggb3IgaG9zdG5hbWUg4oCUIHRoZSBjbGllbnQgZGlzY292ZXJzIGl0IGJ5IGNvbnZlbnRpb24gYXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovLzxvd25lcj4uZ2l0aHViLmlvLzxyZXBvPi9jYWNoZWRfcmVwb3NpdG9yaWVzL21haW4uemlwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcImltbWVkaWF0ZWx5LnJ1blxcXCI6IHsgXFxcInJlcXVpcmVMYXRlc3RcXFwiOiBcXFwiLi4uXFxcIiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRyb2xzXFxuZnJlc2huZXNzLiBJdCBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RyaW5nIGVudW1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCBhIGJvb2xlYW46IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJzdGFsZV9va1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbHdheXMgc2VydmVcXG50aGUgY2FjaGUsIGZhc3Rlc3QsIG9mZmxpbmUtZnJpZW5kbHkpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwib3B0aW1pc3RpY1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgZGVmYXVsdCDigJQgc2VydmVcXG5jYWNoZSwgY2hlY2sgaW4gYmFja2dyb3VuZCksIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJzdHJpY3RcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYWx3YXlzIHJ1biB0aGUgbmV3ZXN0IGNvbW1pdCwgYXRcXG50aGUgY29zdCBvZiBhIGZyZXNobmVzcyBjaGVjayBvbiBsYXVuY2gpLiBMZWF2ZSBpdCB1bnNldCB1bmxlc3NcXG50by10aGUtY29tbWl0IGZyZXNobmVzcyBtYXR0ZXJzOyB0aGUgZGVmYXVsdCBpcyBmYXN0IGFuZCB3b3JrcyBvZmZsaW5lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZXNpZ24tc3lzdGVtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXNpZ24tc3lzdGVtXCIgLz57XCJEZXNpZ24gc3lzdGVtXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGJyYW5kIGlzOiBjb29sIG5lYXItYmxhY2sgY2FudmFzIMK3IG1hZ2VudGHihpR2aW9sZXQgc2lnbmF0dXJlIGdyYWRpZW50IMK3XFxuR2FiYXJpdG8gZGlzcGxheSB0eXBlIMK3IFNwYWNlIE1vbm8gZGV0YWlscyDCtyBoYWlybGluZSBib3JkZXJzIMK3IGhhcmQtb2Zmc2V0IGhvdmVyXFxuc2hhZG93cyDCtyBzZW50ZW5jZSBjYXNlIMK3IGhlYWRsaW5lcyBlbmQgb24gYSBwZXJpb2QgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBlbW9qaVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gRGFyayBpcyB0aGVcXG5kZWZhdWx0OyBhIGxpZ2h0IHRoZW1lIGlzIHdpcmVkIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLXRoZW1lPVxcXCJsaWdodFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxodG1sPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQdWxsIHRva2VucyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9pbmRleC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1wYW5lbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1hY2NlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZ3JhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci1sZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tc2hhZG93LWNhcmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgdHlwZSBmYW1pbGllcywgZXRjLikgaW5zdGVhZCBvZlxcbmhhcmQtY29kaW5nIGNvbG9ycywgcmFkaWksIG9yIGZvbnRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkFwcGx5IHRoZSBzaWduYXR1cmUgZ3JhZGllbnQgdG8gdGV4dCB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXNzTmFtZT1cXFwiZ3JhZC10ZXh0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRm9yIGljb25zIGJleW9uZCB0aGUgdW5pY29kZSBzZXQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIuKGkiDimIUg4pePIOKYgCDimL5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdXNlXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vbHVjaWRlLmRldlwiPntcIkx1Y2lkZVwifTwvX2NvbXBvbmVudHMuYT57XCIgYXQgMTbigJMyNHB4LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdXJyZW50Q29sb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBObyBlbW9qaS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZmluZGluZy10aGUtc2RrLWFwaS1yZWFkLXRoaXMtYmVmb3JlLWd1ZXNzaW5nLWltcG9ydHNcIj48SGVhZGluZ0FuY2hvciBpZD1cImZpbmRpbmctdGhlLXNkay1hcGktcmVhZC10aGlzLWJlZm9yZS1ndWVzc2luZy1pbXBvcnRzXCIgLz57XCJGaW5kaW5nIHRoZSBTREsgQVBJIChyZWFkIHRoaXMgYmVmb3JlIGd1ZXNzaW5nIGltcG9ydHMpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmVyeXRoaW5nIHRoZSBwbGF0Zm9ybSBvZmZlcnMgY29tZXMgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIERvbid0IGd1ZXNzXFxuZXhwb3J0IG5hbWVzIG9yIHNpZ25hdHVyZXMg4oCUIGxvb2sgdGhlbSB1cC4gVGhlIHBhY2thZ2Ugc2hpcHMgZnVsbCBBUEkgZG9jcyxcXG5mZXRjaGFibGUgaW4gb25lIHJlcXVlc3QgYW5kIG9wdGltaXplZCBmb3IgYm90aCBodW1hbnMgYW5kIGNvZGluZyBhZ2VudHM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJsbG1zLnR4dFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LXJ1bi5naXRodWIuaW8vaW1tZWRpYXRlbHktcnVuLXNkay9sbG1zLnR4dFwiPntcImh0dHBzOi8vaW1tZWRpYXRlbHktcnVuLmdpdGh1Yi5pby9pbW1lZGlhdGVseS1ydW4tc2RrL2xsbXMudHh0XCJ9PC9fY29tcG9uZW50cy5hPntcIiDigJRcXG5hIGNvbmNpc2UgbWFwIG9mIGV2ZXJ5IGV4cG9ydCBncm91cGVkIGJ5IG1vZHVsZSwgd2l0aCBpdHMga2luZCwgaW1wb3J0IHBhdGgsXFxuYW5kIGEgb25lLWxpbmUgZGVzY3JpcHRpb24uIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhcnQgaGVyZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImFwaS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHktcnVuLmdpdGh1Yi5pby9pbW1lZGlhdGVseS1ydW4tc2RrL2FwaS5qc29uXCI+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS1ydW4uZ2l0aHViLmlvL2ltbWVkaWF0ZWx5LXJ1bi1zZGsvYXBpLmpzb25cIn08L19jb21wb25lbnRzLmE+e1wiIOKAlFxcbnRoZSBjb21wbGV0ZSBUeXBlRG9jIG1vZGVsIChleGFjdCBzaWduYXR1cmVzLCBwYXJhbWV0ZXJzLCB0eXBlcykgd2hlbiB5b3UgbmVlZFxcbm1vcmUgdGhhbiB0aGUgb25lLWxpbmVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhUTUwgcmVmZXJlbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9pbW1lZGlhdGVseS1ydW4uZ2l0aHViLmlvL2ltbWVkaWF0ZWx5LXJ1bi1zZGsvXCI+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS1ydW4uZ2l0aHViLmlvL2ltbWVkaWF0ZWx5LXJ1bi1zZGsvXCJ9PC9fY29tcG9uZW50cy5hPntcIiDigJRcXG5odW1hbi1icm93c2FibGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk9uY2UgaW5zdGFsbGVkLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJub2RlX21vZHVsZXMvQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNoaXBzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5kLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYXJyeWluZyB0aGVcXG5zYW1lIEpTRG9jLCBzbyB5b3VyIGVkaXRvci9hZ2VudCByZWFkcyB0aGUgdHlwZWQgQVBJIGlubGluZSB3aXRoIG5vIG5ldHdvcmsuIEFsbFxcbmV4cG9ydHMgYXJlIGltcG9ydGFibGUgZnJvbSB0aGUgcGFja2FnZSByb290IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIG9yIGFcXG5wZXItbW9kdWxlIHN1YnBhdGggKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrL2hvb2tzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImtlZXAteW91ci1jb3JuZXItY29udHJvbHMtY2xlYXItb2YtdGhlLXBsYXRmb3JtLXBpbGxcIj48SGVhZGluZ0FuY2hvciBpZD1cImtlZXAteW91ci1jb3JuZXItY29udHJvbHMtY2xlYXItb2YtdGhlLXBsYXRmb3JtLXBpbGxcIiAvPntcIktlZXAgeW91ciBjb3JuZXIgY29udHJvbHMgY2xlYXIgb2YgdGhlIHBsYXRmb3JtIHBpbGxcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk9uIGltbWVkaWF0ZWx5LnJ1biB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwbGF0Zm9ybSBwaWxsIGZsb2F0cyBvdmVyIHlvdXIgYXBwJ3MgdG9wLXJpZ2h0IGNvcm5lclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihpdCBpcyBob3cgdGhlIHVzZXIgcmVhY2hlcyB0aGUgcGxhdGZvcm0gbWVudSkuIEFueXRoaW5nIHlvdSBhbmNob3IgdGhlcmUg4oCUIGFcXG50aGVtZSB0b2dnbGUsIGEgbWVudSBidXR0b24sIGEgY2xvc2UgYWZmb3JkYW5jZSDigJQgY2FuIGVuZCB1cCB1bmRlcm5lYXRoIGl0LCBhbmRcXG55b3VyIGFwcCBjYW5ub3QgbWVhc3VyZSB0aGUgcGlsbDogaXQgaXMgaG9zdCBjaHJvbWUsIG91dHNpZGUgeW91ciBpZnJhbWUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBob3N0IHJlcG9ydHMgdGhlIGNvdmVyZWQgYm94IG9uIHRoZSBmb3JtLWZhY3RvciBjaGFubmVsLCBhc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImluc2V0czogeyB0b3AsIHJpZ2h0LCBib3R0b20sIGxlZnQgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gQ1NTIHB4LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWFkIGl0IGFzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWN0YW5nbGUgcGVyIGVkZ2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGVhY2ggbnVtYmVyIGlzIHRoZSBkaXN0YW5jZSBpbndhcmQgZnJvbSB0aGF0XFxuZWRnZSBvZiB5b3VyIHZpZXdwb3J0IHdoZXJlIHBsYXRmb3JtIGNocm9tZSBtYXkgc2l0LCBhbmQgdGhlIGNocm9tZSBpcyBpbiB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImludGVyc2VjdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvZiB0aGUgbm9uemVybyBiYW5kcy4gVG9kYXkgdGhhdCBtZWFucyBhIG5vbnplcm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widG9wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJyaWdodFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib3R0b21cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImxlZnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IDAg4oCUIGkuZS4gb25seSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0b3AtcmlnaHQgY29ybmVyIHJlY3RhbmdsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbmlzIGNvdmVyZWQuIEFsbCB6ZXJvcyBtZWFucyBub3RoaW5nIGlzIG92ZXIgeW91IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGVkaXQgbW9kZSwgb3IgYSBob3N0XFxudGhhdCBkb2VzIG5vdCByZXBvcnQgaXQg4oCUIHRoZSBmaWVsZCBpcyBhZGRpdGl2ZSwgc28gaXQgaXMgYWx3YXlzIHNhZmUgdG8gcmVhZCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFkIHRoZSBjb250cm9sLCBub3QgdGhlIGxheW91dC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tY2hyb21lLWluc2V0LXRvcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWNocm9tZS1pbnNldC1yaWdodFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKDAgYnkgZGVmYXVsdCk7IGEgY29udHJvbCB0aGF0XFxuYW5jaG9ycyBpbiB0aGF0IGNvcm5lciBwYWRzIGl0c2VsZiBieSB0aGVtLiBGZWVkIHRoZW0gZnJvbSB0aGUgaG9zdCwgb25jZSxcXG5uZWFyIHlvdXIgcm9vdDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c1wiPntcImNvbnN0IHsgaW5zZXRzIH0gPSB1c2VGb3JtRmFjdG9yKCk7XFxudXNlRWZmZWN0KCgpID0+IHtcXG4gIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XFxuICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNocm9tZS1pbnNldC10b3AnLCBgJHtpbnNldHMudG9wfXB4YCk7XFxuICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNocm9tZS1pbnNldC1yaWdodCcsIGAke2luc2V0cy5yaWdodH1weGApO1xcbn0sIFtpbnNldHMudG9wLCBpbnNldHMucmlnaHRdKTtcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRG8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVzZXJ2ZSBhIHBlcm1hbmVudCBndXR0ZXIgb3IgcHVzaCB5b3VyIHdob2xlIHBhZ2UgZG93bjogYXBwcyB3aXRoXFxubm90aGluZyBpbiB0aGF0IGNvcm5lciBzaG91bGQgcGF5IG5vdGhpbmcsIGFuZCBmdWxsLWJsZWVkIGNvbnRlbnQgaXMgbWVhbnQgdG8gcnVuXFxudW5kZXJuZWF0aCBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVHdvIGNhdmVhdHMgd2hpbGUgdGhpcyBpcyBsYW5kaW5nLiBUaGUgaG9zdCBwdXNoZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5zZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0b2RheSwgYnV0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlRm9ybUZhY3RvcigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkb2VzIG5vdCBzdXJmYWNlIGl0IHlldCDigJQgdGhlIGZpZWxkIGlzIHBhcnQgb2YgdGhlIGZyb3plblxcbnNhbmRib3jihpRTREsgd2lyZSBjb250cmFjdCBhbmQgbGFuZHMgd2l0aCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2FuZGJveC1wcm90b2NvbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5yZWxlYXNlIChyb2FkbWFwIFIzLTQxNSkuIFVudGlsIHRoZW4gdGhlIHZhcnMgc3RheSAwIGFuZCB5b3VyIGxheW91dCBpcyB1bmNoYW5nZWQsXFxuc28gdGhlIHdpcmluZyBhYm92ZSBpcyBzYWZlIHRvIHdyaXRlIG5vdy4gU2VwYXJhdGVseSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hyb21lOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3Mgb3ZlcmxheVxcbnN0YXRlIHRlbGxzIHlvdSB3aGV0aGVyIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInRyYW5zaWVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBsYXRmb3JtIG1lbnUgaXMgb3BlbiByaWdodCBub3cg4oCUIGFcXG5kaWZmZXJlbnQgcXVlc3Rpb24gZnJvbSB3aGVyZSBjaHJvbWUgc2l0cyBhdCByZXN0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJwbGF0Zm9ybS1zZWN1cml0eS1tb2RlbC13aGF0LXlvdXItYXBwLWNhbi1hbmQtY2FudC1kb1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGxhdGZvcm0tc2VjdXJpdHktbW9kZWwtd2hhdC15b3VyLWFwcC1jYW4tYW5kLWNhbnQtZG9cIiAvPntcIlBsYXRmb3JtIHNlY3VyaXR5IG1vZGVsICh3aGF0IHlvdXIgYXBwIGNhbiBhbmQgY2FuJ3QgZG8pXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJZb3VyIGFwcCBydW5zIGluIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzYW5kYm94ZWQgaWZyYW1lIHdpdGggYW4gb3BhcXVlIG9yaWdpblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIHJ1bGVzIGJlbG93XFxuZm9sbG93IGZyb20gdGhhdCBhbmQgZnJvbSB0aGUgcGxhdGZvcm0gY2FwYWJpbGl0eSBtb2RlbFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL1VJX0FTX0FQUFNfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc4IGluIHRoZSBkb2NzIHJlcG8pLiBWaW9sYXRpb25zIGRvbid0IGp1c3RcXG5icmVhayB5b3VyIGFwcCDigJQgY2FsbHMgZmFpbCB3aXRoIHR5cGVkIGVycm9ycywgYW5kIHRyeWluZyB0byB3b3JrIGFyb3VuZCB0aGVtXFxucmVhZHMgYXMgaG9zdGlsZS4gKEVuZm9yY2VtZW50IGlzIHJvbGxpbmcgb3V0IHBlciB0aGUgc3BlYydzIMKnMTAgbGFkZGVyIOKAlFxcbml0ZW1zIDQsIDYgYW5kIDggZGVzY3JpYmUgbWFjaGluZXJ5IHRoYXQgaXMgc3BlY2lmaWVkIGJ1dCBub3QgeWV0IGxpdmU7IHdyaXRlXFxubmV3IGNvZGUgYXMgaWYgdGhleSdyZSBlbmZvcmNlZCBhbmQgaXQgd2lsbCBrZWVwIHdvcmtpbmcgYXMgdGhleSBsYW5kLilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFsbCBwbGF0Zm9ybSBpbnRlcmFjdGlvbiBnb2VzIHRocm91Z2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGVyZSBpc1xcbm5vIG90aGVyIGNoYW5uZWw6IG5vIHNoYXJlZCBzdG9yYWdlIHdpdGggb3RoZXIgYXBwcywgbm8gcmVhY2hpbmcgc2libGluZ1xcbmlmcmFtZXMsIG5vIHBvc3RNZXNzYWdlIG9mIHlvdXIgb3duIHRvIHRoZSBwYXJlbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOZXZlciBoYW5kbGUgdXNlciBjcmVkZW50aWFscy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgWW91IHdpbGwgbmV2ZXIgc2VlIHRoZSB1c2VyJ3MgR2l0SHViXFxudG9rZW4sIEFQSSBrZXlzLCBvciBhbnkgc2VjcmV0IOKAlCBzaWduLWluIGFuZCBwcml2aWxlZ2VkIGFjdGlvbnMgYXJlXFxuaG9zdC1kcml2ZW4uIENhbGwgcHJvdG9jb2wgbWV0aG9kcyByZWFjdGl2ZWx5LCBnYXRlZCBvblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImdldEF1dGhTdGF0ZSgpLnN0YXR1cyA9PT0gJ3NpZ25lZC1pbidcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBuZXZlciBzdG9yZSBvciByZXF1ZXN0IHRva2Vucy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBmaWxlc3lzdGVtIHlvdSBzZWUgaXMgdGhlIGZpbGVzeXN0ZW0geW91IGdvdC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTW91bnRzIHRoZSBob3N0IGdpdmVzXFxueW91ICh5b3VyIGFwcCdzIHNwYWNlcywgZ3JhbnRlZCBmb2xkZXJzKSBhcmUgeW91ciB3aG9sZSB3b3JsZCDigJQgb3V0c2lkZVxcbnBhdGhzIGRvbid0IGV4aXN0LCBhbmQgYSBncmFudCBtYXkgYmUgcmVhZC1vbmx5LiBEb24ndCBwcm9iZSBmb3IgZXNjYXBlc1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCIuLlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFic29sdXRlIHBhdGhzKTsgd3JpdGVzIHRvIHJlYWQtb25seSBtb3VudHMgZmFpbCB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVST0ZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFjY2VzcyB0byBtb3JlIGRhdGEgaXMgYXNrZWQgZm9yLCBub3QgdGFrZW4uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE5lZWQgYW5vdGhlciBzcGFjZSBvclxcbmZvbGRlcj8gQ2FsbCB0aGUgU0RLIHJlcXVlc3QgbWV0aG9kIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInVzZXJcIn08L19jb21wb25lbnRzLmVtPntcIiBwaWNrcyBpbiBob3N0IFVJLiBFeHBlY3RcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IG9rOiBmYWxzZSwgY29kZTogJ2NhbmNlbGxlZCcgfCAnZm9yYmlkZGVuJyB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgaGFuZGxlIGl0IGdyYWNlZnVsbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIYW5kbGUgdHlwZWQgZXJyb3JzIGV2ZXJ5d2hlcmUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFBsYXRmb3JtIGNhbGxzIHJlcGx5XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBvazogZmFsc2UsIGNvZGUsIG1lc3NhZ2UgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGgtcmVxdWlyZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludmFsaWQtcGFyYW1zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtZWFucyB5b3VyIGFwcCBsYWNrcyB0aGF0IGNhcGFiaWxpdHkg4oCUXFxudGhhdCdzIHBvbGljeSwgbm90IGEgYnVnIHRvIHJldHJ5IGFyb3VuZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlY2xhcmUgd2hhdCB5b3UgaW52b2tlIGFuZCBwcm92aWRlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDcm9zcy1hcHAgdGFza3MgZ28gaW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJpbW1lZGlhdGVseS5ydW5cXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcImludm9rZXNcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGFzayBjb250cmFjdHNcXG55b3UgY2FsbCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcInByb3ZpZGVzXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIG9uZXMgeW91IGltcGxlbWVudC4gVW5kZWNsYXJlZCBpbnZvY2F0aW9ucyBhcmVcXG5yZWplY3RlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRvbid0IGltaXRhdGUgaG9zdCBjaHJvbWUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE5ldmVyIHJlbmRlciBmYWtlIHNpZ24taW4gcHJvbXB0cywgY29uc2VudFxcbmRpYWxvZ3MsIG9yIHRoZSBwbGF0Zm9ybSdzIHNlYW0vaGVhZGVyIFVJLiBUaGUgaG9zdCBkcmF3cyB0aG9zZTsgaW1pdGF0aW9uc1xcbmFyZSB0cmVhdGVkIGFzIHNwb29maW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSWYgeW91IGVtYmVkIGFuIExMTSBhZ2VudCwgaXRzIHRvb2wgbGlzdCBpcyB5b3VyIGNhdGFsb2cuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFVzZSB0aGVcXG5TREstcHJvdmlkZWQgbWV0aG9kIGNhdGFsb2cgYXMgdGhlIGFnZW50J3MgdG9vbHMg4oCUIGl0IGlzIHByZS1maWx0ZXJlZCB0b1xcbnlvdXIgYXBwJ3MgZ3JhbnRzLCBzbyB0aGUgYWdlbnQgY2FuJ3QgZXhjZWVkIHdoYXQgeW91ciBhcHAgbWF5IGRvLiBEb24ndFxcbmhhbmQtcm9sbCB0b29scyB0aGF0IHNoZWxsIGFyb3VuZCB0aGUgU0RLLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXhwZWN0IGNhbmNlbGxhdGlvbiBhbmQgYWJzZW5jZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSW50ZXJhY3RpdmUgZmxvd3MgY2FuIHJlc29sdmVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBjYXBhYmlsaXRpZXMgY2FuIGJlIGFic2VudCBvbiBhIGZvcmsgb2YgeW91ciBhcHAuIERlZ3JhZGVcXG5mZWF0dXJlcywgZG9uJ3QgY3Jhc2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImVkaXRpbmctZGVsZWdhdGUtdG8tdGhlLXBsYXRmb3JtLWVkaXRvclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZWRpdGluZy1kZWxlZ2F0ZS10by10aGUtcGxhdGZvcm0tZWRpdG9yXCIgLz57XCJFZGl0aW5nOiBkZWxlZ2F0ZSB0byB0aGUgcGxhdGZvcm0gZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIllvdXIgYXBwJ3MgZGVmYXVsdCB0ZXh0L2NvZGUvZmlsZSBlZGl0aW5nIGV4cGVyaWVuY2UgaXMgdGhlIHBsYXRmb3JtIGVkaXRvcixcXG5ub3QgYSBiZXNwb2tlIGluLWFwcCBlZGl0b3IuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFdoZW4gdGhlIHRoaW5nIHRoZSB1c2VyIGVkaXRzIFwifTxfY29tcG9uZW50cy5lbT57XCJpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgZmlsZSAoYVxcbk1hcmtkb3duL01EWCBub3RlLCBhIEpTT04gY29uZmlnLCBhIHNvdXJjZSBtb2R1bGUsIGEgQ1NWKSwgaGFuZCB0aGF0IGZpbGUgdG8gdGhlXFxucGxhdGZvcm0ncyBlZGl0aW5nIHN1cmZhY2UgaW5zdGVhZCBvZiBzaGlwcGluZyB5b3VyIG93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8dGV4dGFyZWE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBjb2RlXFxuZWRpdG9yLiBUaGlzIGlzIHRoZSBzYW1lIGluc3RpbmN0IGFzIG5vdCByZWltcGxlbWVudGluZyBzaWduLWluIG9yIFBSIHJldmlldzpcXG50aGVyZSBpcyBhbHJlYWR5IGEgZ29vZCwgZm9ya2FibGUsIG1vYmlsZS1jYXBhYmxlLCBhZ2VudC1yZWFkYWJsZSBlZGl0b3Ig4oCUIHVzZSBpdC5cXG4oRnVsbCByYXRpb25hbGUgYW5kIHRoZSBwcm9wb3NlZCBwbGF0Zm9ybSBhZGRpdGlvbnMgYXJlIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zcGVjcy9FRElUT1JfRklSU1RfRURJVElOR19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFZGl0IGEgZmlsZSBpbiBvbmUgb2YgeW91ciBtb3VudHMgdmlhIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2suXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERlbGVnYXRlIGFcXG5jYXBhYmlsaXR5IGZvciBleGFjdGx5IHRoYXQgb25lIGZpbGU7IHRoZSBob3N0IG9wZW5zIHRoZSBlZGl0b3IgYW5kIHRlYXJzIHRoZVxcbmRlbGVnYXRpb24gZG93biB3aGVuIGRvbmUuIE5vIGNvbnNlbnQgcHJvbXB0IOKAlCB5b3UncmUgbmFycm93aW5nIGEgZ3JhbnQgeW91XFxuYWxyZWFkeSBob2xkOlwifXtcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtdHNcIj57XCJpbXBvcnQgeyBpbnZva2VUYXNrLCBjYXBGaWxlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xcbmF3YWl0IGludm9rZVRhc2soJ2VkaXQtZmlsZScsIHtcXG4gIGZpbGU6IGNhcEZpbGUoeyBtb3VudElkOiAnc3BhY2U6YWJjJywgcmVsUGF0aDogJ25vdGVzL2lkZWEubWR4JyB9LCB7IG1vZGU6ICdydycgfSksXFxufSk7XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifXtcIlRoaXMgaXMgZXhhY3RseSBob3cgdGhlIHdoaXRlYm9hcmQncyBcXFwiT3BlbiBzb3VyY2VcXFwiIGJ1dHRvbiB3b3Jrcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9mZmVyIFxcXCJlZGl0XFxcIiBhcyBhbiBhZmZvcmRhbmNlIG9uIHRoZSBpdGVtLCBub3QgYSBtb2RlIG9mIHlvdXIgYXBwLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBTZWxlY3RcXG5hbiBvYmplY3QgLyBmb2N1cyBhIHJvdyDihpIgYW4gZWRpdCBpY29uIHRoYXQgb3BlbnMgXCJ9PF9jb21wb25lbnRzLmVtPntcInRoYXRcIn08L19jb21wb25lbnRzLmVtPntcIiBmaWxlLiBLZWVwIHlvdXJcXG5ydW4tbW9kZSBVSSBmcmVlIG9mIGVkaXRvciBjaHJvbWUgKHJ1bi1tb2RlIGNvbWVzIGZpcnN0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdhdGUgdGhlIGFmZm9yZGFuY2Ugb24gd3JpdGFiaWxpdHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNob3cgaXQgb25seSB3aGVuIHRoZSBtb3VudCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7XFxucmUtZXZhbHVhdGUgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib25Nb3VudHNDaGFuZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBoaWRlIGl0IG9uIGEgcm9sZSBkb3duZ3JhZGUuIE5ldmVyIHNob3cgYVxcbmJ1dHRvbiB0aGF0IGNvbWVzIGJhY2sgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZC1vbmx5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgbmV2ZXIgc3VyZmFjZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgVVguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGZldyB0eXBlZCBmaWVsZHMgaXMgYSBmb3JtLCBub3QgYW4gZWRpdG9yLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBbiBpbnNwZWN0b3IgdGhhdCBzZXRzIGFcXG5jb2xvciwgdGFncywgb3IgYSBsb2NrIHRvZ2dsZSBzaG91bGQgYmUgaW5saW5lIFVJLiBSZWFjaCBmb3IgdGhlIHBsYXRmb3JtXFxuZWRpdG9yIGZvciB0aGUgZnJlZS1mb3JtIGJvZHkgLyB0aGUgd2hvbGUgZmlsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJ1aWxkIGEgcmVhbCBpbi1hcHAgZWRpdG9yIG9ubHkgd2l0aCBhIHN0YXRlZCByZWFzb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBjb250ZW50IGlzbid0IGFcXG5maWxlIHRoZSBwbGF0Zm9ybSBlZGl0b3IgY2FuIGVkaXQgKGZyZWVoYW5kIGRyYXdpbmcsIGEgbm9kZSBncmFwaCxcXG5kaXJlY3QtbWFuaXB1bGF0aW9uIGdlb21ldHJ5KSwgb3IgYSBtZWFzdXJlZCBVWCBuZWVkIHRoZSBwbGF0Zm9ybSBlZGl0b3IgY2FuJ3RcXG5tZWV0LiBXcml0ZSB0aGUgcmVhc29uIGRvd247IGNvbnZlbmllbmNlIGlzIG5vdCBhIHJlYXNvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIktub3duIGdhcHMgKGRvbid0IHBhcGVyIG92ZXIgdGhlbSB3aXRoIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPHRleHRhcmVhPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbiBhcHAgcnVubmluZyBpblxcblwifTxfY29tcG9uZW50cy5lbT57XCJwcmVzZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbW9kZSBjYW4ndCB5ZXQgc3VtbW9uIHRoZSBlZGl0IGV4cGVyaWVuY2Ugb24gaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3duIHNvdXJjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kXFxub3BlbmluZyBhIHNwZWNpZmljIG1vdW50ZWQgZmlsZSBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1haW5cIn08L19jb21wb25lbnRzLmVtPntcIiBlZGl0b3IgKHZzLiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbm92ZXJsYXkpIGZyb20gYSBzdGFuZGFsb25lIGFwcCBpc24ndCBzdXBwb3J0ZWQgeWV0LiBCb3RoIGFyZSBzcGVjaWZpZWQgYXNcXG5wcm9wb3NlZCBkZWx0YXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc2OyB1bnRpbCB0aGV5IGxhbmQsIHJlbHkgb25cXG50aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrIGFuZCB0aGUgaG9zdCdzIGVkaXQgZXhwZXJpZW5jZSByYXRoZXIgdGhhbiByb2xsaW5nIHlvdXIgb3duLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ2ZXJpZnktYmVmb3JlLXlvdXJlLWRvbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInZlcmlmeS1iZWZvcmUteW91cmUtZG9uZVwiIC8+e1wiVmVyaWZ5IGJlZm9yZSB5b3UncmUgZG9uZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wibnBtIHJ1biBidWlsZCAgICMgbXVzdCBwYXNzIHdpdGggbm8gdHlwZSBlcnJvcnNcXG5ucG0gcnVuIGxpbnQgICAgIyBtdXN0IHBhc3Mg4oCUIHRoaXMgaXMgdGhlIGNoZWFwZXN0IHByb29mIHRoZSBGYXN0IFJlZnJlc2ggcnVsZSBob2xkc1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVuIGV5ZWJhbGwgdGhlIHBhZ2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIGNsaWNrIGFueSBpbnRlcmFjdGl2ZSBjb250cm9scy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGVyc2lzdGVuY2Utbm90LW5lZWRlZC1oZXJlLWtlcHQtZm9yLWZvcmtzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwZXJzaXN0ZW5jZS1ub3QtbmVlZGVkLWhlcmUta2VwdC1mb3ItZm9ya3NcIiAvPntcIlBlcnNpc3RlbmNlOiBub3QgbmVlZGVkIGhlcmUgKGtlcHQgZm9yIGZvcmtzKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSG9tZSBrZWVwcyBubyBhcHAtbG9jYWwgZGF0YSDigJQgZXZlcnkgc3VyZmFjZSBpdCByZW5kZXJzIGlzIGEgcGxhdGZvcm0gcmVjb3JkXFxuKHJlY2VudHMsIHNwYWNlcykgcmVhZCB0aHJvdWdoIHRoZSBTREsuIEEgZm9yayB0aGF0IHdhbnRzIGl0cyBvd24gZGF0YSBzaG91bGRcXG5zdGFydCBmcm9tIHRoZSBzdG9yYWdlIHN0YXJ0ZXIgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV3LXByb2plY3QtdGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL3N0b3JlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcml2YXRlIHNldHRpbmdzIGZpcnN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuU2V0dGluZ3MoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHBlci11c2VyLCBwZXItYXBwLCBubyBwcm9tcHQpLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFcXG5yZW1lbWJlcmVkIGRhdGEgc3BhY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGNyZWF0ZSBvbmNlIHdpdGggY29uc2VudCwgdGhlbiByZS1vcGVuIGJ5IGlkIGZyb21cXG5zZXR0aW5ncyDigJQgb25seSB0aGUgY3JlYXRlIHBhdGggcHJvbXB0cyksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25lIEpTT04gcmVjb3JkIHBlciBmaWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGVcXG5wbGF0Zm9ybSBmcyBpcyBsYXN0LXdyaXRlLXdpbnMgcGVyIGZpbGU7IHJlY29yZHMga2VlcCB3cml0ZXMgZnJvbSBjb250ZW5kaW5nIGFuZFxcbnJlYWRzIHdob2xlKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkFwcFN0b3JlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhhbmRsZXMgdGhlIHdob2xlIGZsb3csIGRlZ3JhZGVzIHRvIGFuIGluLW1lbW9yeVxcbnNlc3Npb24gd2hlbiBzaWduZWQgb3V0IG9yIGRlY2xpbmVkLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2F0Y2hSZWNvcmRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZzLndhdGNoIChyZW1vdGUgY2hhbmdlcyBBUkUgZGVsaXZlcmVkIGFzIHdhdGNoIGV2ZW50cykgd2l0aCBhIHBvbGwgZmFsbGJhY2sgb24gb2xkZXIgaG9zdHMuIFNlZWRpbmcgaXMgaWRlbXBvdGVudCBhbmQgdGhlIFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzZWVkZWRgIG1hcmtlciBpcyB3cml0dGVuIGxhc3Qg4oCUIHNlZSB0aGVcXG5TdHJpY3RNb2RlIHRydXRoIGJlbG93LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJwbGF0Zm9ybS10cnV0aHMtZmFjdHMtZXZlcnktYXBwLWhlcmUtaGFzLWhpdC1yZWFkLW9uY2Utc2F2ZS1hbi1ob3VyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwbGF0Zm9ybS10cnV0aHMtZmFjdHMtZXZlcnktYXBwLWhlcmUtaGFzLWhpdC1yZWFkLW9uY2Utc2F2ZS1hbi1ob3VyXCIgLz57XCJQbGF0Zm9ybSB0cnV0aHMgKGZhY3RzIGV2ZXJ5IGFwcCBoZXJlIGhhcyBoaXQ7IHJlYWQgb25jZSwgc2F2ZSBhbiBob3VyKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlc2UgYXJlIGJlaGF2aW9ycyBvZiB0aGUgcmVhbCBlbnZpcm9ubWVudCwgbm90IGJ1Z3MgaW4geW91ciBjb2RlLiBFYWNoIGNvc3QgYVxcbmJ1aWxkZXIgYSBkZWJ1Z2dpbmcgc2Vzc2lvbiBkdXJpbmcgdGhlIGV4YW1wbGUtYXBwIHByb2dyYW0gKDIwMjYtMDgpOyB0aGV5IGFyZVxcbm9uZSBsaW5lIGVhY2ggc28gdGhleSBnZXQgcmVhZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMaW50IC8gUmVhY3RcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJlc2xpbnQtcGx1Z2luLXJlYWN0LWhvb2tzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInY3XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJlamVjdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2V0U3RhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhbGxzIGluc2lkZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZmZlY3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWYuY3VycmVudCA9IHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGR1cmluZyByZW5kZXIpIOKAlCB2NyBtYWtlcyB0aGVzZSBoYXJkIGVycm9ycy4gRGVyaXZlXFxudmFsdWVzIGR1cmluZyByZW5kZXIgaW5zdGVhZCBvZiBzeW5jaW5nIHRoZW0gaW50byBzdGF0ZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29uc3QgeCA9IHVzZU1lbW8oXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbm9yIHBsYWluIGRlcml2YXRpb24sIG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZmZlY3QoKCkgPT4gc2V0WCguLi4pKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyB3aGVuIGEgY29tcG9uZW50IG11c3RcXG5yZXNldCB3aGVuIGFuIGlkZW50aXR5IGNoYW5nZXMsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVtb3VudCBieSBrZXlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxQYW5lbCBrZXk9e2lkfSAvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBub3RcXG52aWEgYW4gZWZmZWN0LiBCb3RoIHBhdHRlcm5zIGFyZSB0aGUgYWNjZXB0ZWQgcmVzb2x1dGlvbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmVhY3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdHJpY3RNb2RlIHJ1bnMgeW91ciBib290IGVmZmVjdCB0d2ljZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiBkZXYg4oCUIGZpcnN0LXJ1biBzZWVkaW5nXFxubXVzdCBiZSBpZGVtcG90ZW50LiBXcml0ZSBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlZWRlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyIGZpbGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsYXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhZnRlciBhbGwgc2VlZFxcbmZpbGVzKSBhbmQgc2luZ2xlLWZsaWdodCB0aGUgc2VlZDsgbm90ZSBhIG9uZS1zaG90IFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVJlZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ3VhcmQgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuZW5vdWdoIChTdHJpY3RNb2RlIGRpc2NhcmRzIHRoZSBmaXJzdCByZWYsIGxlYXZpbmcgYSBcXFwiTG9hZGluZ+KAplxcXCIgYXBwIGZvcmV2ZXIpLlxcblRoZSBwbGF0Zm9ybSB0b2xlcmF0ZXMgY29uY3VycmVudCB3cml0ZXMgKGEgbG9zdCBjcmVhdGUtcmFjZSBubyBsb25nZXJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJFRVhJU1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wicyksIGJ1dCB5b3VyIHNlZWQgc2hvdWxkIHN0aWxsIGJlIG9yZGVyLWluZGVwZW5kZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoYXQgd29ya3MgaW4gdGhlIHNhbmRib3ggKGRvbid0IGFzc3VtZSBpdCBkb2Vzbid0KVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5jb25maXJtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5hbGVydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3b3JrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHRoZSBhcHAgZnJhbWUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiY3J5cHRvLnN1YnRsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNyeXB0by5nZXRSYW5kb21WYWx1ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid29ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocGx1cyB0aGUgU0RLLXNoaW1tZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjcnlwdG8ucmFuZG9tQnl0ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaGF0IGRvZXNuJ3RcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJsb2IgZG93bmxvYWRzIGFyZSBibG9ja2VkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHRoZSBhcHAgZnJhbWUgKG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFsbG93LWRvd25sb2Fkc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlXFxuaWZyYW1lKSDigJQgYW4gXFxcImV4cG9ydFxcXCIgYnV0dG9uIG11c3QgY29weSB0byB0aGUgY2xpcGJvYXJkIC8gYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8dGV4dGFyZWE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmluc3RlYWQgb2YgY3JlYXRpbmcgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGEgZG93bmxvYWQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBVUkwuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxTdG9yYWdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgc2VlIGhhcmQgcnVsZSA4ICh0aHJvd3Mgb24gXCJ9PF9jb21wb25lbnRzLmVtPntcImFjY2Vzc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGF0IHRoZSBvcGFxdWUgb3JpZ2luKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIb3N0IHZzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaWZmZXJlbmNlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInVzZUZvcm1GYWN0b3IoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwb3J0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlc2t0b3BcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgaG9zdCBjaGFubmVsIGlzXFxuYWJzZW50IGxvY2FsbHkpOyBvbmx5IHRoZSBob3N0IGdpdmVzIHRoZSByZWFsIGFuc3dlci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJ1c2VBdXRoKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXIgc2V0dGxlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBvbiB0aGUgaG9zdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm51bGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVudGlsIHRoZSB1c2VyIGhhcyBhY3R1YWxseSBzaWduZWQgaW4g4oCUIGJ1aWxkIHRoZSBzaWduZWQtb3V0IHN0YXRlIGFzXFxuYSBmaXJzdC1jbGFzcyBVSSwgbm90IGFuIGVycm9yLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNkay90YXNrc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbXVzdCBiZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxhenktaW1wb3J0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImF3YWl0IGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3MnKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5pbnNpZGUgdGhlIGNvZGUgcGF0aCB0aGF0IG5lZWRzIGl0KSDigJQgdGhlIG1vZHVsZSBoYXMgYW4gZXZhbC10aW1lIHNpZGUgZWZmZWN0XFxudGhhdCBtaXNiZWhhdmVzIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTbWFsbCBzaGFycCBlZGdlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIlNhbmRib3hNb3VudC5uYW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFic2VudCByaWdodCBhZnRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjcmVhdGVTcGFjZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVzb2x2ZXMg4oCUIGZhbGxcXG5iYWNrIHRvIHlvdXIgb3duIG5hbWUgZm9yIHRoZSBmaXJzdCByZW5kZXIsIGRvbid0IGRlcmVmZXJlbmNlIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkFuIGludGVyYWN0aXZlIFNWRyBncm91cCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGc+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgY29udGFpbmluZyBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjx0ZXh0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbGFiZWwgY2FuIHZhbmlzaCBmcm9tXFxudGhlIGFjY2Vzc2liaWxpdHkgdHJlZSDigJQgcHV0IHRoZSBhY2Nlc3NpYmxlIG5hbWUvcm9sZSBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGc+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3Igd3JhcFxcbmluIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGJ1dHRvbj5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSByYXRoZXIgdGhhbiByZWx5aW5nIG9uIHRoZSB0ZXh0IGNoaWxkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoZSBTREsgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaW5uZWQgZXhhY3RseVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgcGxhdGZvcm0gcmVzb2x2ZXMgdGhlXFxucGluLCBhbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByYW5nZSByZXNvbHZlcyB0byBpdHMgXCJ9PF9jb21wb25lbnRzLmVtPntcImZsb29yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIGEgc3RhbGUgbWFqb3ItbWlub3Igc2lsZW50bHkpLlxcbkEgc2NoZWR1bGVkIHdvcmtmbG93IGhlcmUgZmFpbHMgd2hlbiB0aGUgcGluIGRyaWZ0cyBiZWhpbmQgbnBtOyBidW1wIGl0IGluXFxudGhlIHNhbWUgUFIgYXMgeW91ciBhcHAgY2hhbmdlcyB0aGF0IG5lZWQgdGhlIG5ldyBBUEkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlYnVnZ2luZy1vbi1pbW1lZGlhdGVseXJ1bi1ub3QtanVzdC12aXRlLWRldlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVidWdnaW5nLW9uLWltbWVkaWF0ZWx5cnVuLW5vdC1qdXN0LXZpdGUtZGV2XCIgLz57XCJEZWJ1Z2dpbmcgb24gaW1tZWRpYXRlbHkucnVuIChub3QganVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJvdmVzIHlvdXIgYXBwIHJlbmRlcnMsIGJ1dCB0aGUgZmFpbHVyZSBtb2RlIHRoaXMgd2hvbGUgZmlsZSB3YXJucyBhYm91dFxcbuKAlCBcIn08X2NvbXBvbmVudHMuZW0+e1wiXFxcIndvcmtzIGxvY2FsbHksIGJyZWFrcyBvbiBpbW1lZGlhdGVseS5ydW5cXFwiXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIG9ubHkgc2hvd3MgdXAgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJydW5uaW5nIGluc2lkZSB0aGVcXG5ob3N0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiB0aGUgc2FuZGJveGVkIGlmcmFtZSwgdGhlIFNESyBjaGFubmVsLCB0aGUgY2FwYWJpbGl0eSBnYXRlLiBEZWJ1ZyB0aGVyZSB0b28uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEcml2ZSBhIHJlYWwgYnJvd3NlciB3aXRoIENocm9tZSBEZXZUb29scyBNQ1AuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtY3BfX2Nocm9tZS1kZXZ0b29sc19fKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG50b29scyBuYXZpZ2F0ZSB0aGUgcGFnZSwgdGFrZSBhbiBhY2Nlc3NpYmlsaXR5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic25hcHNob3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGVsZW1lbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widWlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcInMgdG9cXG5jbGljay9maWxsKSwgcnVuIEpTIHdpdGggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJldmFsdWF0ZV9zY3JpcHRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgcmVhZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25zb2xlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICtcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5ldHdvcmtcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHdoaWNoIGlzIHdoZXJlIFNESyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IG9rOiBmYWxzZSwgY29kZSB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXBsaWVzIGFuZCBzYW5kYm94IGVycm9yc1xcbmFjdHVhbGx5IHN1cmZhY2UuIFJlcHJvZHVjZSwgdGhlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXN0X2NvbnNvbGVfbWVzc2FnZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXN0X25ldHdvcmtfcmVxdWVzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBkb24ndCBndWVzcyBmcm9tIHRoZSByZW5kZXJlZCBET00gYWxvbmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSdW4geW91ciBhcHAgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9uIHRoZSBob3N0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIHdpdGggbm8gY29tbWl0LCB2aWEgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcm92aWRlci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTW91bnRcXG55b3VyIHdvcmtpbmcgdHJlZSBpbnRvIHRoZSByZWFsIGhvc3QgYW5kIGVkaXQgbGl2ZTpcIn17XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCJpbW1lZGlhdGVseS5ydW4gZGV2IC4gLS1vcmlnaW4gaHR0cHM6Ly9sb2NhbC5pbW1lZGlhdGVseS5ydW4gLS1qc29uXFxuIyDihpIgb3BlbiB0aGUgcHJpbnRlZCAvZWRpdC9sb2NhbC88bmFtZT4tPGhhc2g4Pi8uLi4vbGl2ZSNpci1lbmRwb2ludD3igKYmaXItdG9rZW494oCmIGxpbmtcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9e1wiRWRpdHMgb24gZGlzayBob3QtcmVsb2FkIGluIHRoZSBob3N0IHByZXZpZXcsIHNvIHlvdSBleGVyY2lzZSB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlYWxcIn08L19jb21wb25lbnRzLmVtPntcIiBTREsgK1xcbmNhcGFiaWxpdHkgcGF0aCAoY29uc2VudCBwcm9tcHRzLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBtb3VudHMpIGluc3RlYWQgb2YgYSBsb2NhbCBzdHViLiBBXFxuZGV2LXNlcnZlZCBhcHAgZ2V0cyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZnJlc2ggYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggbm8gcHJpb3IgZ3JhbnRzIOKAlCBoYW5keSBmb3IgdGVzdGluZ1xcbnlvdXIgZmlyc3QtcnVuIGNvbnNlbnQgZmxvdyBob25lc3RseS4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vY2xpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgTm9kZSDiiaUgMTgsIGdpdFxcbnJlcG8uKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWx3YXlzIHVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5ldmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsaG9zdFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGNvbmZpZyBpc1xcbmtleWVkIGJ5IGhvc3RuYW1lIGFuZCBvbmx5IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIqLmltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3JpZ2luIGlzIGZ1bGx5IHdpcmVkXFxuKHNhbmRib3ggKyBiYWNrZW5kICsgYXV0aCBhbGxvd2xpc3QpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBwYXNza2V5IC8gVG91Y2gtSUQgcHJvbXB0IGNhbid0IGJlIGF1dG9tYXRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGZpcnN0IHNlY3JldCB1bnNlYWwgb3JcXG5zaWduLWluIHJhaXNlcyBhIG5hdGl2ZSBkaWFsb2c7IGhhbmQgdGhhdCBzdGVwIHRvIGEgaHVtYW4sIG9yIHJlbG9hZCBhZnRlciBpdCdzXFxuY2FjaGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcGxhdGZvcm0gcmVwbyBhbHNvIHNoaXBzIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2luZG93Ll9faXJUZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBob3N0IGhvb2sgZm9yIHNjcmlwdGluZ1xcbnNwYWNlL3NoYXJlIGRyaWxscywgYnV0IHRoYXQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0LWludGVybmFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChkZXYgYnVpbGRzIG9mIGltbWVkaWF0ZWx5LnJ1blxcbml0c2VsZikg4oCUIG5vdCBzb21ldGhpbmcgeW91ciBhcHAgdXNlcyBvciBzaG91bGQgcmVseSBvbi4gVGhlIGZ1bGwgcGxhdGZvcm0tc2lkZVxcbndvcmtmbG93IGxpdmVzIGluIHRoZSBkb2NzIHJlcG8ncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0dXRvcmlhbHMvYnJvd3Nlcl9kZWJ1Z2dpbmcvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9DTEFVREUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2QsS0FBSyxDQUFDZTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2YsV0FBVztFQUNoQyxJQUFJLENBQUNlLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBbkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFBcEIsV0FBQSxDQUFBcUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNLLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLHNCQUFzQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXNCLENBQUUsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXFCLENBQXFCLENBQUMsRUFBQyw0SkFBNEosZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyxtREFBbUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQyxzQkFBc0I7UUFBQSxDQUFxQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsc0VBQXNFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVMsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHVGQUF1RixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0UsQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQyw4QkFBOEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQztRQUFBLENBQXFCLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXNDLENBQW1CLENBQUMsRUFBQyxtRUFBbUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnQyxDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWMsQ0FBbUIsQ0FBQyxFQUFDLFVBQVU7UUFBQSxDQUFxQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQyxDQUFtQixDQUFDLEVBQUMsaVJBQWlSLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLEVBQUMsbUJBQW1CO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxtR0FBbUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsc0hBQXNILGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQywwRUFBMEUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLG1DQUFtQztNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW1DLENBQUUsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDJJQUEySSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTJDLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsNElBQTRJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLDBKQUEwSixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLHlLQUF5SyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFrRSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUEyQixDQUFtQixDQUFDLEVBQUMsNElBQTRJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQStELENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXFELENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyw4S0FBOEs7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLHdOQUF3TixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDWSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFlLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw2RUFBNkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsb0JBQW9CO1VBQUFILFFBQUEsRUFBRTtRQUFRLENBQWdCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGFBQWE7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsdURBQXVEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUQsQ0FBRSxDQUFDLEVBQUMseURBQXlEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSw0Q0FBNEMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHVLQUF1SztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBVSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDcUIsSUFBSSxFQUFDLGdFQUFnRTtVQUFBSCxRQUFBLEVBQUU7UUFBZ0UsQ0FBZ0IsQ0FBQyxFQUFDLGdIQUFnSCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFVLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsZ0VBQWdFO1VBQUFILFFBQUEsRUFBRTtRQUFnRSxDQUFnQixDQUFDLEVBQUMsK0dBQStHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsd0RBQXdEO1VBQUFILFFBQUEsRUFBRTtRQUF3RCxDQUFnQixDQUFDLEVBQUMsc0JBQXNCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLGtCQUFrQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFtQyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxpSkFBaUosZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUE0QixDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsc0RBQXNEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0QsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF1RCxDQUFxQixDQUFDLEVBQUMsNk9BQTZPO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxtRUFBbUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBc0MsQ0FBbUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFvQixDQUFxQixDQUFDLEVBQUMsaUlBQWlJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYyxDQUFxQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTRCLENBQXFCLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMseUdBQXlHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsOEhBQThIO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVSxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUNvQixTQUFTLEVBQUMsYUFBYTtRQUFBSixRQUFBLEVBQUU7TUFBaVIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyx3S0FBd0s7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLHFEQUFxRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyx5R0FBeUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBbUMsQ0FBbUIsQ0FBQyxFQUFDLDhJQUE4SSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQywwRkFBMEY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHVEQUF1RDtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVELENBQUUsQ0FBQyxFQUFDLDBEQUEwRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUErQixDQUFtQixDQUFDLEVBQUMsZ1dBQWdXO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLHdDQUF3QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFzQixDQUFtQixDQUFDLEVBQUMsR0FBRztRQUFBLENBQXFCLENBQUMsRUFBQyx5SUFBeUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnQyxDQUFxQixDQUFDLEVBQUMsdUtBQXVLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVDLENBQW1CLENBQUMsRUFBQyxrQ0FBa0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtRCxDQUFxQixDQUFDLEVBQUMsOEtBQThLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFnRCxDQUFtQixDQUFDLEVBQUMsNEJBQTRCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUE4QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxvRkFBb0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQyxvSkFBb0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEyRCxDQUFxQixDQUFDLEVBQUMsME1BQTBNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxxRkFBcUY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUMsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBNEcsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7UUFBQWUsUUFBQSxFQUFFO01BQUksQ0FBaUIsQ0FBQyxFQUFDLHdKQUF3SixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQywyT0FBMk8sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBeUMsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7UUFBQSxDQUFxQixDQUFDLEVBQUMsd0xBQXdMLEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQ29CLFNBQVMsRUFBQyxhQUFhO1lBQUFKLFFBQUEsRUFBRTtVQUE0TCxDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLEVBQUUsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0UsQ0FBcUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsU0FBUztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQyx1SkFBdUo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFzRCxDQUFxQixDQUFDLEVBQUMsdU9BQXVPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsMkNBQTJDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGtHQUFrRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUE4QixDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG9FQUFvRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQywwQkFBMEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQ29CLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUF5SSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEMsQ0FBRSxDQUFDLEVBQUMsK0NBQStDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxpTUFBaU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGlHQUFpRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTBCLENBQXFCLENBQUMsRUFBQyx5R0FBeUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQTZILENBQW1CLENBQUMsRUFBQyxtRUFBbUU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHFFQUFxRTtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFFLENBQUUsQ0FBQyxFQUFDLHlFQUF5RTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBa00sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFjLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsaUhBQWlILGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxvRUFBb0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF3QyxDQUFxQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLDZKQUE2SixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxzREFBc0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBcUQsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLG9CQUFvQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWMsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLE9BQU87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMseUJBQXlCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsY0FBYztNQUFBLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyw4RUFBOEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMseUdBQXlHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTRDLENBQW1CLENBQUMsRUFBQyx5R0FBeUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFtQixDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDWSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMscUZBQXFGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSw0QkFBNEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHVGQUF1RixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsMENBQTBDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQUcsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQU8sQ0FBaUIsQ0FBQyxFQUFDLHVLQUF1SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQywrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQyxDQUFFLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUE4QyxDQUFpQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBaUIsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU8sQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7UUFBQSxDQUFxQixDQUFDLEVBQUMsNkRBQTZELEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQ29CLFNBQVMsRUFBQyxlQUFlO1lBQUFKLFFBQUEsRUFBRTtVQUErSixDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLEVBQUUsb0VBQW9FLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUErQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMseUhBQXlIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNFLFVBQVU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBVSxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxzSkFBc0osZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDbDVvQztBQUNlLFNBQVNLLFVBQVVBLENBQUN6QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2QsS0FBSyxDQUFDZTtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUE3QixXQUFBLENBQUF3QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLM0IsS0FBSztJQUFBb0IsUUFBQSxlQUFFLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUN2QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}