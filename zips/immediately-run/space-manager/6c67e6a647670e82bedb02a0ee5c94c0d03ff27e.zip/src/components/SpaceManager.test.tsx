// R3-91 (FILE_SHARING §6.4/§9.7/§9.8) — the space-manager Invitations UI. Driven
// against a mocked SDK: inviting creates a PENDING offer (not a member); the invitee
// inbox Accepts/Declines; the owner Revokes a pending invite; owner-written strings
// render inert.
import * as React from "react";
import { render, screen, waitFor, within, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, beforeEach, vi } from "vitest";
import type { Invite, Member, SpaceInfo } from "@immediately-run/sdk";
// The REAL shipped stylesheet, as text, so the R3-256 layout test asserts against
// what ships rather than a copy of the rules. `vitest.config.ts` sets `css: true`;
// without it this import is an empty string and that test passes vacuously.
import spaceManagerCss from "./SpaceManager.css?raw";

// --- controllable SDK doubles ------------------------------------------------
const listAllSpaces = vi.fn<() => Promise<SpaceInfo[]>>();
const getSpaceMembers = vi.fn<() => Promise<Member[]>>();
const listPendingInvites = vi.fn<() => Promise<Invite[]>>();
const inviteToSpace = vi.fn<() => Promise<void>>();
const acceptInvite = vi.fn<() => Promise<void>>();
const declineInvite = vi.fn<() => Promise<void>>();
const revokeInvite = vi.fn<() => Promise<void>>();
// R3-259 — the create verb's params are under test (the create-time kind).
const createSpaceMock = vi.fn<(opts?: unknown) => Promise<void>>();

// A controllable `useInvites()` live channel: the host pushes the inbox and the hook
// re-renders. `setInvites(list)` simulates a host push (an invite arriving/leaving).
const inviteState = vi.hoisted(() => ({ current: [] as unknown[], listeners: new Set<() => void>() }));

// A controllable `useRegion()`: admin verbs only render on the non-panel (full-tab)
// surface (R3-96 / PRINCIPALS §9 B3). Default to `page.spaces` so the admin-flow tests
// below exercise the Manage modal; the R3-96 test overrides it to `panel.spaces`.
const regionState = vi.hoisted(() => ({ current: "page.spaces" as string }));

// A controllable `useTaskInput()`: the R3-269 `open-space` boot hint
// (/spaces?space=<id> → auto-open the Manage modal at that space). Default null.
const taskInputState = vi.hoisted(() => ({
  current: null as { task: string; params: Record<string, unknown> } | null,
}));

// R3-206 — the wire call behind "Connect Google Drive". Mocked at the SUBPATH the
// component imports from: the real `sandboxUtils.js` reaches a host runtime that does
// not exist under vitest (and ships extensionless specifiers vitest cannot resolve).
const protocolRequest = vi.fn<(p: string, m: string, args: unknown[]) => Promise<unknown>>();
vi.mock("@immediately-run/sdk/sandboxUtils", () => ({ protocolRequest: (...a: unknown[]) => protocolRequest(...(a as [string, string, unknown[]])) }));

vi.mock("@immediately-run/sdk", () => ({
  listAllSpaces: () => listAllSpaces(),
  getSpaceMembers: () => getSpaceMembers(),
  listPendingInvites: () => listPendingInvites(),
  useInvites: () => {
    const [, force] = React.useReducer((x: number) => x + 1, 0);
    React.useEffect(() => {
      inviteState.listeners.add(force);
      return () => { inviteState.listeners.delete(force); };
    }, []);
    return inviteState.current;
  },
  inviteToSpace: (...a: unknown[]) => inviteToSpace(...(a as [])),
  acceptInvite: (...a: unknown[]) => acceptInvite(...(a as [])),
  declineInvite: (...a: unknown[]) => declineInvite(...(a as [])),
  revokeInvite: (...a: unknown[]) => revokeInvite(...(a as [])),
  unshareSpace: vi.fn(),
  setSpaceRole: vi.fn(),
  listGrants: vi.fn(async () => []),
  revokeGrant: vi.fn(),
  createSpace: (...a: unknown[]) => createSpaceMock(...(a as [opts?: unknown])),
  useAuth: () => ({ status: "signed-in" }),
  useRegion: () => regionState.current,
  useTaskInput: () => taskInputState.current,
}));

import SpaceManager from "./SpaceManager";

const ownedSpace: SpaceInfo = { spaceId: "s1", name: "My space", role: "owner" } as SpaceInfo;

/** Simulate a host push on the live invitations channel. */
const pushInvites = (list: Invite[]) =>
  act(() => {
    inviteState.current = list;
    inviteState.listeners.forEach((l) => l());
  });

beforeEach(() => {
  for (const m of [
    listAllSpaces, getSpaceMembers, listPendingInvites,
    inviteToSpace, acceptInvite, declineInvite, revokeInvite,
  ]) m.mockReset();
  inviteState.current = [];
  regionState.current = "page.spaces"; // full-tab by default; the R3-96 test sets panel.spaces
  taskInputState.current = null;
  // sensible empty defaults; individual tests override.
  listAllSpaces.mockResolvedValue([]);
  getSpaceMembers.mockResolvedValue([]);
  listPendingInvites.mockResolvedValue([]);
  inviteToSpace.mockResolvedValue(undefined);
  acceptInvite.mockResolvedValue(undefined);
  declineInvite.mockResolvedValue(undefined);
  revokeInvite.mockResolvedValue(undefined);
});

describe("SpaceManager — invitations (R3-91)", () => {
  it("inviting calls inviteToSpace and the offer lands under Pending, not Members", async () => {
    const user = userEvent.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);
    // First manage-open load: no members, no pending. After invite: one pending.
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites
      .mockResolvedValueOnce([])
      .mockResolvedValue([{ spaceId: "s1", uid: "uid-of-bob", role: "writer", owner: "u-me", invitedBy: "u-me", login: "bob" }]);

    render(<SpaceManager />);
    await user.click(await screen.findByText("Manage"));

    const dialog = await screen.findByRole("dialog");
    await within(dialog).findByText(/No members|Loading members/i).catch(() => {});
    await user.type(within(dialog).getByPlaceholderText("handle"), "bob");
    await user.click(within(dialog).getByRole("button", { name: "Invite" }));

    await waitFor(() => expect(inviteToSpace).toHaveBeenCalledWith("s1", "bob", "writer"));
    // The offer appears under Pending invites — and is NOT a member row.
    await within(dialog).findByText("Pending invites");
    expect(within(dialog).getByText("@bob")).toBeInTheDocument();
  });

  it("the inbox renders a live invite; Accept calls acceptInvite, then the row is gone (live) and the space appears", async () => {
    const user = userEvent.setup();
    // After accept, the host pushes the emptied inbox (simulated in the mock) and the
    // spaces list gains the accepted space.
    acceptInvite.mockImplementation(async () => {
      inviteState.current = [];
      inviteState.listeners.forEach((l) => l());
    });
    listAllSpaces
      .mockResolvedValueOnce([])
      .mockResolvedValue([{ spaceId: "s9", name: "Shared docs", role: "reader" } as SpaceInfo]);

    render(<SpaceManager />);
    await pushInvites([{ spaceId: "s9", uid: "u-me", role: "reader", owner: "u-owner", invitedBy: "u-owner", name: "Shared docs" }]);
    await screen.findByText("Invitations");
    expect(screen.getByText(/invited you to/i)).toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Accept" }));
    await waitFor(() => expect(acceptInvite).toHaveBeenCalledWith("s9"));
    // The inbox row is gone (live) and the space now appears in the list.
    await waitFor(() => expect(screen.queryByText("Invitations")).not.toBeInTheDocument());
    expect(await screen.findByText("Shared docs")).toBeInTheDocument();
  });

  it("Decline calls declineInvite and the row leaves the inbox (live) with no space added", async () => {
    const user = userEvent.setup();
    declineInvite.mockImplementation(async () => {
      inviteState.current = [];
      inviteState.listeners.forEach((l) => l());
    });
    listAllSpaces.mockResolvedValue([]);

    render(<SpaceManager />);
    await pushInvites([{ spaceId: "s9", uid: "u-me", role: "reader", owner: "u-owner", invitedBy: "u-owner", name: "Shared docs" }]);
    await screen.findByText("Invitations");
    await user.click(screen.getByRole("button", { name: "Decline" }));

    await waitFor(() => expect(declineInvite).toHaveBeenCalledWith("s9"));
    await waitFor(() => expect(screen.queryByText("Invitations")).not.toBeInTheDocument());
    expect(screen.queryByText("Shared docs")).not.toBeInTheDocument();
  });

  it("owner Revoke calls revokeInvite and drops the pending row", async () => {
    const user = userEvent.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites
      .mockResolvedValueOnce([{ spaceId: "s1", uid: "uid-of-bob", role: "writer", owner: "u-me", invitedBy: "u-me", login: "bob" }])
      .mockResolvedValue([]);

    render(<SpaceManager />);
    await user.click(await screen.findByText("Manage"));
    const dialog = await screen.findByRole("dialog");
    await within(dialog).findByText("Pending invites");

    await user.click(within(dialog).getByRole("button", { name: "Revoke" }));
    await waitFor(() => expect(revokeInvite).toHaveBeenCalledWith("s1", "uid-of-bob"));
    await waitFor(() => expect(within(dialog).queryByText("Pending invites")).not.toBeInTheDocument());
  });

  it("the narrow panel.spaces rail exposes NO admin verb, but still browses + shows invitations (R3-96 / §9 B3)", async () => {
    regionState.current = "panel.spaces";
    listAllSpaces.mockResolvedValue([ownedSpace]);

    render(<SpaceManager />);
    // Browse still works — the owned space is listed (spaces:user).
    expect(await screen.findByText("My space")).toBeInTheDocument();
    // ...but the admin affordance is absent on the rail (no spaces:admin here).
    expect(screen.queryByText("Manage")).not.toBeInTheDocument();
    // The invitee-side inbox (spaces:user) is retained — a pushed invite renders.
    await pushInvites([{ spaceId: "s9", uid: "u-me", role: "reader", owner: "u-owner", invitedBy: "u-owner", name: "Shared docs" } as Invite]);
    expect(await screen.findByText("Invitations")).toBeInTheDocument();
  });

  it("the full-tab surface DOES expose Manage for an owned space (page.spaces)", async () => {
    regionState.current = "page.spaces";
    listAllSpaces.mockResolvedValue([ownedSpace]);

    render(<SpaceManager />);
    expect(await screen.findByText("Manage")).toBeInTheDocument();
  });

  it("R3-269: an `open-space` boot hint auto-opens Manage at that owned space", async () => {
    regionState.current = "page.spaces";
    taskInputState.current = { task: "open-space", params: { spaceId: "s1" } };
    listAllSpaces.mockResolvedValue([ownedSpace]);

    render(<SpaceManager />);
    const dialog = await screen.findByRole("dialog", { name: "Manage space" });
    expect(dialog).toHaveTextContent("My space");
  });

  it("R3-269: an `open-space` hint for a non-owned / unknown space opens nothing", async () => {
    regionState.current = "page.spaces";
    taskInputState.current = { task: "open-space", params: { spaceId: "not-mine" } };
    listAllSpaces.mockResolvedValue([ownedSpace]);

    render(<SpaceManager />);
    await screen.findByText("Manage"); // list rendered
    expect(screen.queryByRole("dialog", { name: "Manage space" })).not.toBeInTheDocument();
  });

  it("the invite row cannot push a control outside the dialog (R3-256 / drill F4)", async () => {
    // The reported failure: on a narrow dialog the role select spilled outside and
    // the submit button was "clipped/invisible; only reachable by Tab". jsdom does
    // not lay out, so this cannot be asserted in pixels — but it DOES cascade a
    // stylesheet into getComputedStyle, so the two properties that make the
    // overflow impossible are asserted on the REAL rendered controls with the REAL
    // shipped stylesheet, not by grepping the CSS file:
    //
    //   · the row wraps  ⇒ a control that will not fit moves to the next line
    //                      instead of being pushed past the modal edge;
    //   · the growing input can shrink below its content width ⇒ it gives way
    //                      first, so the row only wraps when it genuinely must.
    //
    // A flex item defaults to `min-width: auto` (its CONTENT minimum), which is
    // precisely why `flex: 1` alone was not enough and the row overflowed.
    // RESIDUAL: the true geometric check ("nothing is clipped at 320px") needs a
    // browser; this repo has no layout-capable harness.
    const user = userEvent.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);

    // Guard against the vacuous pass: if CSS processing is ever disabled again,
    // the sheet is empty, every computed value falls back to its initial value,
    // and the assertions below would "pass" while testing nothing.
    expect(spaceManagerCss.length).toBeGreaterThan(0);
    const style = document.createElement("style");
    style.textContent = spaceManagerCss;
    document.head.appendChild(style);

    render(<SpaceManager />);
    await user.click(await screen.findByText("Manage"));
    const dialog = await screen.findByRole("dialog");

    const input = within(dialog).getByPlaceholderText("handle");
    const row = input.parentElement as HTMLElement;
    const select = within(dialog).getAllByRole("combobox")[0];
    const submit = within(dialog).getByRole("button", { name: "Invite" });

    // All three controls really are in one row — the premise of the failure.
    expect(row).toContainElement(select);
    expect(row).toContainElement(submit);

    expect(getComputedStyle(row).flexWrap).toBe("wrap");
    expect(getComputedStyle(input).minWidth).toBe("0px");

    style.remove();
  });

  it("an invite whose name/invitedBy contains markup renders as inert text (escaped)", async () => {
    const markup = '<img src=x onerror="alert(1)">';
    listAllSpaces.mockResolvedValue([]);

    const { container } = render(<SpaceManager />);
    await pushInvites([
      { spaceId: "s9", uid: "u-me", role: "reader", owner: "u-owner", invitedBy: markup, name: markup },
    ]);
    await screen.findByText("Invitations");
    // The markup is present as TEXT, and produced no injected <img> element.
    expect(screen.getByText(/invited you to/i).textContent).toContain(markup);
    expect(container.querySelector('img[src="x"]')).toBeNull();
  });
});

// R3-206 (GOOGLE_IDENTITY_AND_DRIVE_SPEC §8.2; SPACES_UI_SPEC §4/§5 R-SPACES-6) —
// "Connect a new source → Google Drive".
//
// What this app is responsible for is small and the tests say so: it names the
// SCHEME, and it reflects the result. Every authority step — the incremental Google
// consent, the folder browser, the ro|rw choice, the single-writer disclosure — is
// drawn by the HOST, and its tests live there (`ConnectSourceDialog.test.tsx`). The
// thing worth pinning HERE is that this app paints none of it: a forked space-manager
// that tried to would be drawing its own consent, which §8.3 forbids.
describe("connecting a new source (R3-206)", () => {
  beforeEach(() => {
    listAllSpaces.mockResolvedValue([]);
    protocolRequest.mockReset();
    protocolRequest.mockResolvedValue({ id: "drive:folder-1" });
    regionState.current = "page.spaces";
  });

  it("CONNECT is a distinct action from CREATE — both are offered, and they are not the same button", async () => {
    // `requestMount()` selects from what the user already has; connect SETS ONE UP.
    // Collapsing them is the shape §8.2 rules out, because a picker that sometimes
    // navigates the page to Google is not a picker.
    render(<SpaceManager />);
    expect(await screen.findByRole("button", { name: "Connect Google Drive" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Create a space" })).toBeInTheDocument();
  });

  it("names only the SCHEME — no scope, no folder, no wording", async () => {
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Connect Google Drive" }));

    await waitFor(() => expect(protocolRequest).toHaveBeenCalledTimes(1));
    expect(protocolRequest).toHaveBeenCalledWith("protocol-spaces", "connectSource", [{ scheme: "drive" }]);
  });

  it("paints NO authorization chrome of its own", async () => {
    // The whole §8.3 rule in one assertion: after the click, this app shows a busy
    // label and nothing else. No scope text, no folder list, no ro/rw choice — those
    // exist only in host chrome, which a fork cannot replace.
    let resolve: (v: unknown) => void = () => {};
    protocolRequest.mockReturnValue(new Promise((r) => { resolve = r; }));
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Connect Google Drive" }));

    expect(await screen.findByRole("button", { name: "Connecting…" })).toBeInTheDocument();
    expect(screen.queryByText(/drive\.file/)).not.toBeInTheDocument();
    expect(screen.queryByText(/single-writer/i)).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Read and write/ })).not.toBeInTheDocument();
    await act(async () => { resolve({}); });
  });

  it("treats `cancelled` as calm — the user backed out, nothing failed", async () => {
    protocolRequest.mockRejectedValue(Object.assign(new Error("cancelled"), { code: "cancelled" }));
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Connect Google Drive" }));

    await waitFor(() => expect(screen.getByRole("button", { name: "Connect Google Drive" })).toBeEnabled());
    expect(document.querySelector(".sm-err")).toBeNull();
  });

  it("says what to DO when the Google connection needs re-authorizing", async () => {
    // `google_reauth_required` is not "something went wrong": the remedy is a
    // specific page, and a generic message would leave the user with no next step.
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), { code: "google_reauth_required" }));
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Connect Google Drive" }));

    expect(await screen.findByText(/Reconnect Google in Settings/)).toBeInTheDocument();
  });

  it("says so plainly when the deployment has no Drive connector", async () => {
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), { code: "unsupported-scheme" }));
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Connect Google Drive" }));

    expect(await screen.findByText(/isn’t available on this deployment/)).toBeInTheDocument();
  });

  it("is absent from the narrow panel — the rail exposes no setup verb", async () => {
    // Same rule as the admin surfaces (R3-96 / PRINCIPALS §9 B3): the rail is
    // browse/open/mount-only.
    regionState.current = "panel.spaces";
    render(<SpaceManager />);
    await screen.findByText("Spaces");
    expect(screen.queryByRole("button", { name: "Connect Google Drive" })).not.toBeInTheDocument();
  });
});

// R3-259 — the space's KIND: chosen at create, visible in the list, converted
// once via a named arm-then-confirm act. `kind` rides the wire additively (the
// host derives/validates it); these tests pin what the app sends and shows.
describe("R3-259 — a space's kind", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    regionState.current = "page.spaces";
    taskInputState.current = null;
    inviteState.current = [];
    listAllSpaces.mockResolvedValue([]);
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites.mockResolvedValue([]);
    createSpaceMock.mockResolvedValue(undefined);
    protocolRequest.mockResolvedValue({ ok: true });
  });

  it("create defaults to personal and sends the kind", async () => {
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Create a space" }));
    expect(createSpaceMock).toHaveBeenCalledWith({ kind: "personal" });
  });

  it("choosing Shared sends shared", async () => {
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("radio", { name: "Shared" }));
    await userEvent.click(screen.getByRole("button", { name: "Create a space" }));
    expect(createSpaceMock).toHaveBeenCalledWith({ kind: "shared" });
  });

  it("badges only SHARED spaces — personal is the unmarked default", async () => {
    listAllSpaces.mockResolvedValue([
      { spaceId: "s1", name: "Mine", role: "owner", kind: "personal" } as SpaceInfo,
      { spaceId: "s2", name: "Ours", role: "owner", kind: "shared" } as SpaceInfo,
      { spaceId: "s3", name: "Legacy", role: "owner" } as SpaceInfo, // pre-R3-259 row: unbadged
    ]);
    render(<SpaceManager />);
    const ours = (await screen.findByText("Ours")).closest("li")!;
    expect(within(ours as HTMLElement).getByText("shared")).toBeInTheDocument();
    const mine = screen.getByText("Mine").closest("li")!;
    expect(within(mine as HTMLElement).queryByText("shared")).not.toBeInTheDocument();
    const legacy = screen.getByText("Legacy").closest("li")!;
    expect(within(legacy as HTMLElement).queryByText("shared")).not.toBeInTheDocument();
  });

  it("the owner's personal space offers Convert; arming shows the irreversibility; confirming hits the verb once", async () => {
    listAllSpaces.mockResolvedValue([{ spaceId: "s1", name: "Mine", role: "owner", kind: "personal" } as SpaceInfo]);
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Manage" }));

    const arm = await screen.findByRole("button", { name: /Convert to shared…/ });
    await userEvent.click(arm); // first click ARMS
    expect(protocolRequest).not.toHaveBeenCalled();
    // The armed state is the button that now SAYS what it does.
    expect(screen.getByRole("button", { name: /Convert to shared — cannot be undone/ })).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: /Convert to shared — cannot be undone/ }));
    expect(protocolRequest).toHaveBeenCalledWith("protocol-spaces", "convertToShared", [{ spaceId: "s1", confirm: true }]);
    expect(protocolRequest).toHaveBeenCalledTimes(1);
  });

  it("after converting, the refreshed list shows the shared badge", async () => {
    let kind: string | undefined = "personal";
    listAllSpaces.mockImplementation(async () => [{ spaceId: "s1", name: "Mine", role: "owner", kind } as SpaceInfo]);
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Manage" }));
    await userEvent.click(await screen.findByRole("button", { name: /Convert to shared…/ }));
    // The verb resolving flips what the (mock) host lists next.
    protocolRequest.mockImplementation(async () => {
      kind = "shared";
      return { ok: true };
    });
    await userEvent.click(screen.getByRole("button", { name: /Convert to shared — cannot be undone/ }));
    await waitFor(() =>
      expect(within(screen.getByText("Mine").closest("li") as HTMLElement).getByText("shared")).toBeInTheDocument(),
    );
  });

  it("a SHARED space's Manage modal offers no conversion — there is no way back", async () => {
    listAllSpaces.mockResolvedValue([{ spaceId: "s2", name: "Ours", role: "owner", kind: "shared" } as SpaceInfo]);
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Manage" }));
    await screen.findByText(/Share “Ours”/);
    expect(screen.queryByRole("button", { name: /Convert to shared/ })).not.toBeInTheDocument();
  });

  it("a forbidden conversion surfaces the owner-only message", async () => {
    listAllSpaces.mockResolvedValue([{ spaceId: "s1", name: "Mine", role: "owner", kind: "personal" } as SpaceInfo]);
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), { code: "forbidden" }));
    render(<SpaceManager />);
    await userEvent.click(await screen.findByRole("button", { name: "Manage" }));
    await userEvent.click(await screen.findByRole("button", { name: /Convert to shared…/ }));
    await userEvent.click(screen.getByRole("button", { name: /Convert to shared — cannot be undone/ }));
    expect(await screen.findByText(/Only the owner can convert this space/)).toBeInTheDocument();
  });
});
