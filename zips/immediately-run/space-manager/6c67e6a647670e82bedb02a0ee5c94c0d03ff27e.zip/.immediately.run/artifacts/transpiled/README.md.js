var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "space-manager",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "space-manager"
      }), "space-manager"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "space manager"
      }), " as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), " app\n(UI_AS_APPS_SPEC §5.2). Lists the user's spaces and, for spaces they own, manages\nmembership: invite by provider handle, change a member's role, remove a member."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Elevated capabilities: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spaces:user"
      }), " (enumerate all the user's spaces) +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spaces:admin"
      }), " (membership mutations). The host resolves handles (the identity\nlookup token never reaches this app) and enforces the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "owner-lockout"
      }), " invariant —\na space can never be left without an owner (threat T41). This app just drives the\nflow and renders the result."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm install\nnpm run dev      # standalone (host owns the real protocol, so writes no-op offline)\nnpm run build\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pop the hood: fork it, rebind the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.spaces"
      }), " region to your fork, and the\nSpaces panel becomes yours."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJwIiwicHJlIiwic3Ryb25nIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInNwYWNlLW1hbmFnZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNwYWNlLW1hbmFnZXJcIiAvPntcInNwYWNlLW1hbmFnZXJcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNwYWNlIG1hbmFnZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXMgYW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIiBhcHBcXG4oVUlfQVNfQVBQU19TUEVDIMKnNS4yKS4gTGlzdHMgdGhlIHVzZXIncyBzcGFjZXMgYW5kLCBmb3Igc3BhY2VzIHRoZXkgb3duLCBtYW5hZ2VzXFxubWVtYmVyc2hpcDogaW52aXRlIGJ5IHByb3ZpZGVyIGhhbmRsZSwgY2hhbmdlIGEgbWVtYmVyJ3Mgcm9sZSwgcmVtb3ZlIGEgbWVtYmVyLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFbGV2YXRlZCBjYXBhYmlsaXRpZXM6IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYWNlczp1c2VyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoZW51bWVyYXRlIGFsbCB0aGUgdXNlcidzIHNwYWNlcykgK1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYWNlczphZG1pblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG1lbWJlcnNoaXAgbXV0YXRpb25zKS4gVGhlIGhvc3QgcmVzb2x2ZXMgaGFuZGxlcyAodGhlIGlkZW50aXR5XFxubG9va3VwIHRva2VuIG5ldmVyIHJlYWNoZXMgdGhpcyBhcHApIGFuZCBlbmZvcmNlcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvd25lci1sb2Nrb3V0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGludmFyaWFudCDigJRcXG5hIHNwYWNlIGNhbiBuZXZlciBiZSBsZWZ0IHdpdGhvdXQgYW4gb3duZXIgKHRocmVhdCBUNDEpLiBUaGlzIGFwcCBqdXN0IGRyaXZlcyB0aGVcXG5mbG93IGFuZCByZW5kZXJzIHRoZSByZXN1bHQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cImRldmVsb3BcIiAvPntcIkRldmVsb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2Utc2hcIj57XCJucG0gaW5zdGFsbFxcbm5wbSBydW4gZGV2ICAgICAgIyBzdGFuZGFsb25lIChob3N0IG93bnMgdGhlIHJlYWwgcHJvdG9jb2wsIHNvIHdyaXRlcyBuby1vcCBvZmZsaW5lKVxcbm5wbSBydW4gYnVpbGRcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUG9wIHRoZSBob29kOiBmb3JrIGl0LCByZWJpbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhbmVsLnNwYWNlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVnaW9uIHRvIHlvdXIgZm9yaywgYW5kIHRoZVxcblNwYWNlcyBwYW5lbCBiZWNvbWVzIHlvdXJzLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1QsS0FBSyxDQUFDVTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1YsV0FBVztFQUNoQyxJQUFJLENBQUNVLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBZCxXQUFBLENBQUFlLElBQUEsRUFBQWYsV0FBQSxDQUFBZ0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDRyxFQUFFO01BQUNZLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNPLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNnQixJQUFJLEVBQUMseUJBQXlCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsMEtBQTBLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsMEhBQTBILGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsK0hBQStIO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDVyxFQUFFLEVBQUMsU0FBUztNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsU0FBUztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sR0FBRztNQUFBUSxRQUFBLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDZ0IsU0FBUyxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQW9ILENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUN2K0M7QUFDZSxTQUFTSyxVQUFVQSxDQUFDcEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3FCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdULEtBQUssQ0FBQ1U7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBeEIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS3RCLEtBQUs7SUFBQWUsUUFBQSxlQUFFLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNsQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDdUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}