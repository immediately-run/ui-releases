"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Vitest config for the space-manager unit tests (R3-91 invitations UI). jsdom DOM
// + Testing Library; the SDK is mocked per test so the UI renders without a live host.
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _pluginReact.default)()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.ts"],
    include: ["src/**/*.test.{ts,tsx}"],
    // R3-256: process real CSS imports instead of stubbing them to empty. jsdom
    // does not lay out, but it DOES cascade a stylesheet into `getComputedStyle`,
    // so this lets a test assert the shipped stylesheet's effect on the shipped
    // markup — the only way to pin a CSS-only regression in this harness. With the
    // default (`css: false`) every CSS import is an empty string and such a test
    // passes vacuously against any stylesheet at all.
    css: true
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZpbmVDb25maWciLCJwbHVnaW5zIiwicmVhY3QiLCJ0ZXN0IiwiZW52aXJvbm1lbnQiLCJnbG9iYWxzIiwic2V0dXBGaWxlcyIsImluY2x1ZGUiLCJjc3MiXSwic291cmNlcyI6WyJ2aXRlc3QuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gXCJ2aXRlc3QvY29uZmlnXCI7XG5pbXBvcnQgcmVhY3QgZnJvbSBcIkB2aXRlanMvcGx1Z2luLXJlYWN0XCI7XG5cbi8vIFZpdGVzdCBjb25maWcgZm9yIHRoZSBzcGFjZS1tYW5hZ2VyIHVuaXQgdGVzdHMgKFIzLTkxIGludml0YXRpb25zIFVJKS4ganNkb20gRE9NXG4vLyArIFRlc3RpbmcgTGlicmFyeTsgdGhlIFNESyBpcyBtb2NrZWQgcGVyIHRlc3Qgc28gdGhlIFVJIHJlbmRlcnMgd2l0aG91dCBhIGxpdmUgaG9zdC5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtyZWFjdCgpXSxcbiAgdGVzdDoge1xuICAgIGVudmlyb25tZW50OiBcImpzZG9tXCIsXG4gICAgZ2xvYmFsczogdHJ1ZSxcbiAgICBzZXR1cEZpbGVzOiBbXCIuL3NyYy90ZXN0L3NldHVwLnRzXCJdLFxuICAgIGluY2x1ZGU6IFtcInNyYy8qKi8qLnRlc3Que3RzLHRzeH1cIl0sXG4gICAgLy8gUjMtMjU2OiBwcm9jZXNzIHJlYWwgQ1NTIGltcG9ydHMgaW5zdGVhZCBvZiBzdHViYmluZyB0aGVtIHRvIGVtcHR5LiBqc2RvbVxuICAgIC8vIGRvZXMgbm90IGxheSBvdXQsIGJ1dCBpdCBET0VTIGNhc2NhZGUgYSBzdHlsZXNoZWV0IGludG8gYGdldENvbXB1dGVkU3R5bGVgLFxuICAgIC8vIHNvIHRoaXMgbGV0cyBhIHRlc3QgYXNzZXJ0IHRoZSBzaGlwcGVkIHN0eWxlc2hlZXQncyBlZmZlY3Qgb24gdGhlIHNoaXBwZWRcbiAgICAvLyBtYXJrdXAg4oCUIHRoZSBvbmx5IHdheSB0byBwaW4gYSBDU1Mtb25seSByZWdyZXNzaW9uIGluIHRoaXMgaGFybmVzcy4gV2l0aCB0aGVcbiAgICAvLyBkZWZhdWx0IChgY3NzOiBmYWxzZWApIGV2ZXJ5IENTUyBpbXBvcnQgaXMgYW4gZW1wdHkgc3RyaW5nIGFuZCBzdWNoIGEgdGVzdFxuICAgIC8vIHBhc3NlcyB2YWN1b3VzbHkgYWdhaW5zdCBhbnkgc3R5bGVzaGVldCBhdCBhbGwuXG4gICAgY3NzOiB0cnVlLFxuICB9LFxufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUF5QyxTQUFBRSx1QkFBQUMsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUV6QztBQUNBO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFGLE9BQUEsR0FDZSxJQUFBRyxvQkFBWSxFQUFDO0VBQzFCQyxPQUFPLEVBQUUsQ0FBQyxJQUFBQyxvQkFBSyxFQUFDLENBQUMsQ0FBQztFQUNsQkMsSUFBSSxFQUFFO0lBQ0pDLFdBQVcsRUFBRSxPQUFPO0lBQ3BCQyxPQUFPLEVBQUUsSUFBSTtJQUNiQyxVQUFVLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQztJQUNuQ0MsT0FBTyxFQUFFLENBQUMsd0JBQXdCLENBQUM7SUFDbkM7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0FDLEdBQUcsRUFBRTtFQUNQO0FBQ0YsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119