var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SpaceManager;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _sandboxUtils = require("@immediately-run/sdk/sandboxUtils");
require("./SpaceManager.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$(),
  _s4 = $RefreshSig$(),
  _s5 = $RefreshSig$(),
  _s6 = $RefreshSig$(); // The space manager (UI_AS_APPS_SPEC §5.2). Lists the user's spaces (spaces:user),
// surfaces the user's live Invitations inbox (Accept/Decline — FILE_SHARING §6.4/§9.8),
// and, for owned spaces, manages sharing (spaces:admin): INVITE a user by provider
// handle (a pull-based invitation, NOT an immediate membership write — the recipient
// accepts), revoke a pending invite, change a member's role, remove a member. The host
// resolves handles and enforces the owner-lockout invariant (a space always keeps an
// owner) — this app just drives the flow and shows the result.
// The wire-level escape hatch, from the SDK's own subpath. `connectSource` is not on
// the pinned typed surface yet (R3-206 adds the host verb; the SDK export follows on
// its next release), and `protocolRequest` is exactly the seam for that gap — the
// method name is the contract either way.
const ROLES = ["owner", "writer", "reader"];
const uidOf = principal => principal.replace(/^user:/, "");

// appKey = enc(provider)__enc(namespace)__enc(repository) (§spaceId.ts).
const decodeApp = appKey => {
  try {
    const [, ns, repo] = appKey.split("__").map(decodeURIComponent);
    return ns && repo ? `${ns}/${repo}` : appKey;
  } catch {
    return appKey;
  }
};
const labelOf = m => m.login ? `@${m.login}` : `#${uidOf(m.grantee).split(":").slice(1).join(":") || uidOf(m.grantee)}`;

// Owner-written display fields (login/name/avatarUrl on invites + members) are
// UNTRUSTED (FILE_SHARING §3/§6.4). React escapes text children, so name/handle are
// safe as `{...}`; an avatarUrl, however, becomes a URL — accept only `https:` so a
// crafted `javascript:`/`data:` value can never reach an `<img src>`.
const httpsAvatar = url => {
  if (!url) return undefined;
  try {
    return new URL(url).protocol === "https:" ? url : undefined;
  } catch {
    return undefined;
  }
};
function SpaceManager() {
  _s();
  const [spaces, setSpaces] = (0, _react.useState)(null);
  const [error, setError] = (0, _react.useState)(null);
  const [selected, setSelected] = (0, _react.useState)(null);
  // SPACES_UI_SPEC §5 / R-SPACES-7: this app renders in two surfaces. The narrow
  // `panel.spaces` column inside the workbench, and — at its own deep-linkable route
  // (`/spaces`) — a standalone full-tab surface bound as `page.spaces`. Any region
  // that is not the narrow panel (the full-tab binding, a fork, or `null` for plain
  // `vite dev`) gets the roomier full-screen layout.
  const region = (0, _sdk.useRegion)();
  // PRINCIPALS §9 B3 / R3-96: the narrow `panel.spaces` rail is browse/open/mount-only
  // and holds `spaces:user` but NOT `spaces:admin` (see site-main `registry/defaults.ts`).
  // So the admin surfaces below — the per-space "Manage" modal (invite/role/remove) and
  // the grant AuditView, all `spaces:admin`-gated host-side — are rendered ONLY on the
  // non-panel surface (`page.spaces` full tab). In the rail they'd only fire `forbidden`,
  // and the exit criterion is "the rail exposes no admin verb." Browse (list spaces,
  // `spaces:user`) and the invitee-side Invitations inbox (accept/decline own invites,
  // also `spaces:user`) stay in both surfaces.
  const fullTab = region !== "panel.spaces";
  const loadSpaces = (0, _react.useCallback)(async () => {
    setError(null);
    try {
      setSpaces(await (0, _sdk.listAllSpaces)());
    } catch (e) {
      const code = e?.code;
      setError(code === "auth-required" ? "Sign in to manage your spaces." : "Couldn’t load spaces.");
      setSpaces([]);
    }
  }, []);
  (0, _react.useEffect)(() => {
    const run = async () => {
      await loadSpaces();
    };
    void run();
  }, [loadSpaces]);

  // R3-269 D4: the host's `open-space` boot hint — `/spaces?space=<id>` (the file
  // explorer's "Manage sharing →" deep link) auto-opens the Manage modal AT that
  // space. Untrusted display/navigation data: it is only ever MATCHED against the
  // spaces this user actually has (and only where the admin surface renders — the
  // full tab, on an owned space). Consumed once, so closing the modal stays closed.
  const taskInput = (0, _sdk.useTaskInput)();
  const hintConsumed = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    if (hintConsumed.current || !fullTab || !spaces) return;
    if (taskInput?.task !== "open-space") return;
    const spaceId = taskInput.params?.spaceId;
    if (typeof spaceId !== "string") return;
    hintConsumed.current = true;
    const target = spaces.find(s => s.spaceId === spaceId);
    // Deferred so the selection isn't a synchronous set-state inside the effect
    // (react-hooks/set-state-in-effect); the ref above makes it one-shot.
    if (target && target.role === "owner") queueMicrotask(() => setSelected(target));
  }, [fullTab, spaces, taskInput]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: fullTab ? "sm sm-full" : "sm",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "sm-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "sm-title",
        children: "Spaces"
      }), fullTab && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "sm-create",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(ConnectSourceEntry, {
          onConnected: loadSpaces
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(CreateSpaceEntry, {
          onCreated: loadSpaces
        })]
      })]
    }), error && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "sm-msg",
      children: error
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(InvitationsInbox, {
      onAccepted: loadSpaces
    }), spaces === null ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "sm-msg",
      children: "Loading\u2026"
    }) : spaces.length === 0 && !error ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "sm-msg",
      children: "No spaces yet. Apps create them on demand."
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "sm-list",
      children: spaces.map(s => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        className: "sm-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "sm-row-main",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-name",
            children: s.name ?? "Untitled space"
          }), kindOf(s) === "shared" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-kind",
            "data-kind": "shared",
            children: "shared"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-role",
            "data-role": s.role,
            children: s.role
          })]
        }), fullTab && s.role === "owner" && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "sm-manage",
          onClick: () => setSelected(s),
          children: "Manage"
        })]
      }, s.spaceId))
    }), fullTab && selected && /*#__PURE__*/(0, _jsxRuntime.jsx)(ManageModal, {
      space: selected,
      onClose: () => setSelected(null),
      onSpacesChanged: loadSpaces
    }), fullTab && /*#__PURE__*/(0, _jsxRuntime.jsx)(AuditView, {})]
  });
}

// FILE_SHARING §6.4/§9.8 Invitations inbox: the invitee's pull-based accept surface.
// A pending invite confers NO access — the user opts in here. The list is LIVE via
// `useInvites()` (the host pushes the inbox on the `spaces:user` channel), so an
// arriving/accepted/declined invite reflects within one snapshot — no reload. Accept
// materializes membership; the accepted space then appears once we refresh the spaces
// list (spaces aren't live-pushed to the app), while the invite leaves the inbox on
// its own via the live channel. All owner-written fields are escaped as text (React
// children) — never `dangerouslySetInnerHTML`, and an avatar only if it is `https:`.
_s(SpaceManager, "jN8oS79YR5+N5Ffuw5gflU25+j4=", false, function () {
  return [_sdk.useRegion, _sdk.useTaskInput];
});
_c = SpaceManager;
function InvitationsInbox({
  onAccepted
}) {
  _s2();
  const invites = (0, _sdk.useInvites)();
  const [busy, setBusy] = (0, _react.useState)(null);
  const onAccept = async inv => {
    setBusy(inv.spaceId);
    try {
      await (0, _sdk.acceptInvite)(inv.spaceId);
      // The invite leaves the inbox via the live channel; refresh the spaces list so
      // the newly-accepted space appears in the same interaction (§6.4).
      await onAccepted();
    } catch {
      /* leave the row; the user can retry */
    } finally {
      setBusy(null);
    }
  };
  const onDecline = async inv => {
    setBusy(inv.spaceId);
    try {
      await (0, _sdk.declineInvite)(inv.spaceId);
      // The row leaves the inbox via the live channel.
    } catch {
      /* leave the row */
    } finally {
      setBusy(null);
    }
  };
  if (invites.length === 0) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "sm-invites",
    "aria-label": "Invitations",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
      className: "sm-invites-h",
      children: "Invitations"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      className: "sm-invite-list",
      children: invites.map(inv => {
        const avatar = httpsAvatar(inv.avatarUrl);
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
          className: "sm-invite-row",
          children: [avatar ? /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
            className: "sm-av",
            src: avatar,
            alt: ""
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-av sm-av-ph"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "sm-invite-text",
            children: [inv.invitedBy, " invited you to", " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "sm-name",
              children: inv.name ?? "Untitled space"
            }), " as ", inv.role]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "sm-accept",
            disabled: busy === inv.spaceId,
            onClick: () => onAccept(inv),
            children: busy === inv.spaceId ? "…" : "Accept"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "sm-remove",
            disabled: busy === inv.spaceId,
            onClick: () => onDecline(inv),
            children: "Decline"
          })]
        }, inv.spaceId);
      })
    })]
  });
}

// SPACES_UI_SPEC §5 (R-SPACES-7) "create a space" entry — only on the full-tab
// surface (the in-workbench modal is the other entry point). It drives the SAME host
// `createSpace()` consent path (FILE_SHARING §6/§9.3): the host owns the quota gate,
// the first-create-per-app consent, and the write ordering. This app does NOT paint
// any authorization chrome — it just calls `createSpace()` and reflects the result.
// Gated on signed-in: creating storage in the user's account needs an account.
//
// R3-259 — the create-time KIND. Personal (default) is the safe,
// reversible-until-converted state; Shared is shared from the first byte (the host
// latches it at birth). The wire param is additive (the pinned typed wrapper passes
// opts straight through — the cast is the local widening until the SDK export
// catches up; the HOST validates the literal either way).
_s2(InvitationsInbox, "WZQahq26nfEc1n52TaSPJ70TJZI=", false, function () {
  return [_sdk.useInvites];
});
_c2 = InvitationsInbox;
function CreateSpaceEntry({
  onCreated
}) {
  _s3();
  const {
    status
  } = (0, _sdk.useAuth)();
  const [busy, setBusy] = (0, _react.useState)(false);
  const [err, setErr] = (0, _react.useState)(null);
  const [kind, setKind] = (0, _react.useState)("personal");

  // Until the host reports auth, render nothing rather than a button that can't work.
  if (status !== "signed-in") return null;
  const onCreate = async () => {
    setBusy(true);
    setErr(null);
    try {
      // The wire param is additive (the pinned typed wrapper passes opts straight
      // through — the double cast is the local widening until the SDK export
      // catches up; the HOST validates the literal either way).
      await (0, _sdk.createSpace)({
        kind
      });
      await onCreated();
    } catch (e) {
      const code = e?.code;
      // `cancelled` is the user dismissing the host consent — calm, not an error.
      if (code === "cancelled") return;
      setErr(code === "quota-exceeded" ? "Space limit reached." : "Couldn’t create a space.");
    } finally {
      setBusy(false);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "sm-create-kind",
      role: "radiogroup",
      "aria-label": "Space kind",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "sm-create-kind",
          checked: kind === "personal",
          onChange: () => setKind("personal")
        }), "Personal"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "sm-create-kind",
          checked: kind === "shared",
          onChange: () => setKind("shared")
        }), "Shared"]
      }), kind === "shared" && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "sm-create-note",
        children: "More than one person will be able to change it."
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "sm-add",
      onClick: onCreate,
      disabled: busy,
      children: busy ? "Creating…" : "Create a space"
    }), err && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "sm-err",
      children: err
    })]
  });
}

// R3-259 — the DERIVED kind the host lists (`SpaceInfo` gains `kind` on the wire;
// read defensively so the pinned SDK type doesn't gate the badge).
_s3(CreateSpaceEntry, "5IPJ3d1slVrdRSuprd7yW5hE1xM=", false, function () {
  return [_sdk.useAuth];
});
_c3 = CreateSpaceEntry;
const kindOf = s => s.kind;

// R3-206 / SPACES_UI_SPEC §4–§5 (R-SPACES-6) — "Connect a new source → Google Drive".
//
// CONNECT IS NOT SELECT, and that is why this is a second entry point rather than a
// row in the powerbox. `requestMount()` picks from sources the user ALREADY has;
// this SETS ONE UP — an incremental Google consent, a folder pick, an access choice.
// Putting a provider OAuth flow inside the powerbox would mean the picker sometimes
// navigates the whole page to Google, which is exactly what §8.2 rules out.
//
// Every step is drawn by the HOST: the scope request, the folder browser, the ro|rw
// choice and the single-writer disclosure. This app supplies the SCHEME and nothing
// else — it never sees the user's Drive, the granted scope, or any of the wording.
// That is the same discipline as `createSpace()` above: drive the flow, reflect the
// result, paint no authorization chrome.
//
// Called through `protocolRequest` rather than a typed SDK verb because the SDK's
// pinned surface has no `connectSource` yet; the wire method is the contract either
// way, and swapping to the typed export when it ships is a one-line change.
function ConnectSourceEntry({
  onConnected
}) {
  _s4();
  const {
    status
  } = (0, _sdk.useAuth)();
  const [busy, setBusy] = (0, _react.useState)(false);
  const [err, setErr] = (0, _react.useState)(null);

  // Connecting a source in the user's account needs an account.
  if (status !== "signed-in") return null;
  const onConnect = async () => {
    setBusy(true);
    setErr(null);
    try {
      await (0, _sandboxUtils.protocolRequest)("protocol-spaces", "connectSource", [{
        scheme: "drive"
      }]);
      await onConnected();
    } catch (e) {
      const code = e?.code;
      // `cancelled` is the user backing out of the host flow — calm, not an error.
      if (code === "cancelled") return;
      setErr(code === "auth-required" ? "Sign in to connect a source." : code === "unsupported-scheme" ? "Google Drive isn’t available on this deployment." : code === "google_reauth_required" ? "Reconnect Google in Settings → Connections, then try again." : "Couldn’t connect that source.");
    } finally {
      setBusy(false);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "sm-manage",
      onClick: onConnect,
      disabled: busy,
      children: busy ? "Connecting…" : "Connect Google Drive"
    }), err && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "sm-err",
      children: err
    })]
  });
}

// §8.11 capability audit view: which apps hold which mount grants, with one-click
// revoke (durable + best-effort live teardown, host-side).
_s4(ConnectSourceEntry, "gqxwHvhOtJbKVoNW72gV/A6ihhA=", false, function () {
  return [_sdk.useAuth];
});
_c4 = ConnectSourceEntry;
function AuditView() {
  _s5();
  const [grants, setGrants] = (0, _react.useState)(null);
  const [busy, setBusy] = (0, _react.useState)(null);
  const load = (0, _react.useCallback)(async () => {
    try {
      setGrants(await (0, _sdk.listGrants)());
    } catch {
      setGrants([]);
    }
  }, []);
  (0, _react.useEffect)(() => {
    const run = async () => {
      await load();
    };
    void run();
  }, [load]);
  const onRevoke = async g => {
    const key = g.appKey + g.spaceId;
    setBusy(key);
    try {
      await (0, _sdk.revokeGrant)(g.appKey, g.spaceId);
      await load();
    } catch {
      /* leave the row; the user can retry */
    } finally {
      setBusy(null);
    }
  };
  if (!grants || grants.length === 0) return null;

  // Group by app for a readable "this app can reach these spaces" view.
  const byApp = new Map();
  for (const g of grants) byApp.set(g.appKey, [...(byApp.get(g.appKey) ?? []), g]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "sm-audit",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
      className: "sm-audit-h",
      children: "App access"
    }), [...byApp.entries()].map(([appKey, list]) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "sm-audit-app",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "sm-audit-name",
        children: decodeApp(appKey)
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "sm-audit-grants",
        children: list.map(g => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
          className: "sm-audit-grant",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-audit-space",
            children: g.name ?? g.spaceId.slice(0, 8)
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "sm-audit-scope",
            children: [g.mode === "ro" ? "read-only" : "read-write", g.subtree ? ` · ${g.subtree}` : ""]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "sm-remove",
            disabled: busy === g.appKey + g.spaceId,
            onClick: () => onRevoke(g),
            children: busy === g.appKey + g.spaceId ? "…" : "Revoke"
          })]
        }, g.spaceId))
      })]
    }, appKey))]
  });
}
_s5(AuditView, "mdE8CKPERGjyRYQBPTXz/sSY3M0=");
_c5 = AuditView;
function ManageModal({
  space,
  onClose,
  onSpacesChanged
}) {
  _s6();
  const [members, setMembers] = (0, _react.useState)(null);
  const [pending, setPending] = (0, _react.useState)([]);
  const [handle, setHandle] = (0, _react.useState)("");
  const [addRole, setAddRole] = (0, _react.useState)("writer");
  const [busy, setBusy] = (0, _react.useState)(false);
  const [revoking, setRevoking] = (0, _react.useState)(null);
  const [err, setErr] = (0, _react.useState)(null);
  // R3-259 — the Convert arm-then-confirm state (the same two-click shape the
  // contribute panel's reset uses). The IRREVERSIBILITY copy lives HERE, in the
  // manager, per the item; the wire additionally carries `confirm: true` as
  // belt-and-braces and the host owner-checks the verb.
  const [convertArmed, setConvertArmed] = (0, _react.useState)(false);
  const [converting, setConverting] = (0, _react.useState)(false);
  const refresh = (0, _react.useCallback)(async () => {
    try {
      // Members (accepted) and pending invitations (offered, not yet accepted) are
      // disjoint surfaces — a pending invitee is NOT a member (§6.4), so we list
      // them separately and never double-list.
      const [m, p] = await Promise.all([(0, _sdk.getSpaceMembers)(space.spaceId), (0, _sdk.listPendingInvites)(space.spaceId).catch(() => [])]);
      setMembers(m);
      setPending(p);
    } catch {
      setErr("Couldn’t load members.");
    }
  }, [space.spaceId]);
  (0, _react.useEffect)(() => {
    const run = async () => {
      await refresh();
    };
    void run();
  }, [refresh]);
  const ownerCount = (members ?? []).filter(m => m.role === "owner").length;
  const onInvite = async () => {
    const h = handle.trim().replace(/^@/, "");
    if (!h) return;
    setBusy(true);
    setErr(null);
    try {
      // §6.4: create an INVITATION (not a membership). The offer shows under Pending
      // until the recipient accepts — refresh reflects it there, not under Members.
      await (0, _sdk.inviteToSpace)(space.spaceId, h, addRole);
      setHandle("");
      await refresh();
    } catch (e) {
      const code = e?.code;
      setErr(code === "not-found" ? `No user “@${h}”.` : code === "forbidden" ? "Not allowed." : code === "quota-exceeded" ? "Too many pending invites." : "Couldn’t invite.");
    } finally {
      setBusy(false);
    }
  };
  const onRevokeInvite = async inv => {
    setRevoking(inv.uid);
    setErr(null);
    try {
      await (0, _sdk.revokeInvite)(space.spaceId, inv.uid);
      await refresh();
    } catch {
      setErr("Couldn’t revoke the invite.");
    } finally {
      setRevoking(null);
    }
  };
  const onRole = async (m, role) => {
    setErr(null);
    try {
      await (0, _sdk.setSpaceRole)(space.spaceId, uidOf(m.grantee), role);
      await refresh();
    } catch (e) {
      setErr(e?.code === "owner-lockout" ? "A space must keep an owner." : "Couldn’t change role.");
    }
  };
  const onRemove = async m => {
    setErr(null);
    try {
      await (0, _sdk.unshareSpace)(space.spaceId, uidOf(m.grantee));
      await refresh();
    } catch (e) {
      setErr(e?.code === "owner-lockout" ? "A space must keep an owner." : "Couldn’t remove.");
    }
  };

  // R3-259 — the deliberate one-way conversion. First click arms; the second (the
  // button that now says what it does) performs it. The verb rides the
  // `protocolRequest` seam like `connectSource` above: the host gate holds
  // `spaces:admin` + the confirm literal, and the host checks ownership.
  const onConvert = async () => {
    if (!convertArmed) {
      setConvertArmed(true);
      return;
    }
    setConverting(true);
    setErr(null);
    try {
      await (0, _sandboxUtils.protocolRequest)("protocol-spaces", "convertToShared", [{
        spaceId: space.spaceId,
        confirm: true
      }]);
      setConvertArmed(false);
      await Promise.all([refresh(), onSpacesChanged?.()]);
    } catch (e) {
      const code = e?.code;
      setErr(code === "forbidden" ? "Only the owner can convert this space." : "Couldn’t convert the space.");
    } finally {
      setConverting(false);
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "sm-overlay",
    onClick: onClose,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "sm-modal",
      onClick: e => e.stopPropagation(),
      role: "dialog",
      "aria-label": "Manage space",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "sm-x",
        onClick: onClose,
        "aria-label": "Close",
        children: "\xD7"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("h2", {
        className: "sm-modal-title",
        children: ["Share \u201C", space.name ?? "Untitled space", "\u201D"]
      }), space.role === "owner" && kindOf(space) === "personal" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "sm-convert",
        children: [convertArmed ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
          className: "sm-convert-note",
          children: ["Converting ", /*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
            children: space.name ?? "this space"
          }), " to shared cannot be undone. Apps and agents will treat it more cautiously, because more than one person can change what is in it."]
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          className: "sm-convert-note",
          children: "This is a personal space \u2014 only you can change it. You can convert it to shared if others will work in it too."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: convertArmed ? "sm-convert-confirm" : "sm-convert-btn",
          disabled: converting,
          onClick: () => void onConvert(),
          children: converting ? "Converting…" : convertArmed ? "Convert to shared — cannot be undone" : "Convert to shared…"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "sm-invite",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          className: "sm-input",
          placeholder: "handle",
          value: handle,
          onChange: e => setHandle(e.target.value),
          onKeyDown: e => e.key === "Enter" && !busy && onInvite(),
          disabled: busy
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("select", {
          className: "sm-select",
          value: addRole,
          onChange: e => setAddRole(e.target.value),
          disabled: busy,
          children: ROLES.map(r => /*#__PURE__*/(0, _jsxRuntime.jsx)("option", {
            value: r,
            children: r
          }, r))
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "sm-add",
          onClick: onInvite,
          disabled: busy,
          children: busy ? "Inviting…" : "Invite"
        })]
      }), err && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "sm-err",
        children: err
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "sm-members",
        children: members === null ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "sm-msg",
          children: "Loading members\u2026"
        }) : members.map(m => {
          const lastOwner = m.role === "owner" && ownerCount <= 1;
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "sm-member",
            children: [m.avatarUrl ? /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
              className: "sm-av",
              src: m.avatarUrl,
              alt: ""
            }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "sm-av sm-av-ph"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "sm-member-name",
              children: labelOf(m)
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("select", {
              className: "sm-select",
              value: m.role,
              disabled: lastOwner,
              title: lastOwner ? "A space must keep an owner" : undefined,
              onChange: e => onRole(m, e.target.value),
              children: ROLES.map(r => /*#__PURE__*/(0, _jsxRuntime.jsx)("option", {
                value: r,
                children: r
              }, r))
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
              type: "button",
              className: "sm-remove",
              disabled: lastOwner,
              onClick: () => onRemove(m),
              children: "Remove"
            })]
          }, m.grantee);
        })
      }), pending.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "sm-pending",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
          className: "sm-pending-h",
          children: "Pending invites"
        }), pending.map(inv => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "sm-member",
          children: [httpsAvatar(inv.avatarUrl) ? /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
            className: "sm-av",
            src: httpsAvatar(inv.avatarUrl),
            alt: ""
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-av sm-av-ph"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-member-name",
            children: inv.login ? `@${inv.login}` : `#${inv.uid}`
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "sm-role",
            "data-role": inv.role,
            children: inv.role
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "sm-remove",
            disabled: revoking === inv.uid,
            onClick: () => onRevokeInvite(inv),
            children: revoking === inv.uid ? "…" : "Revoke"
          })]
        }, inv.uid))]
      })]
    })
  });
}
_s6(ManageModal, "RVyF6r+eZQSaD+L0Q/XrrrahMBM=");
_c6 = ManageModal;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "SpaceManager");
$RefreshReg$(_c2, "InvitationsInbox");
$RefreshReg$(_c3, "CreateSpaceEntry");
$RefreshReg$(_c4, "ConnectSourceEntry");
$RefreshReg$(_c5, "AuditView");
$RefreshReg$(_c6, "ManageModal");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9zYW5kYm94VXRpbHMiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiX3MzIiwiX3M0IiwiX3M1IiwiX3M2IiwiUk9MRVMiLCJ1aWRPZiIsInByaW5jaXBhbCIsInJlcGxhY2UiLCJkZWNvZGVBcHAiLCJhcHBLZXkiLCJucyIsInJlcG8iLCJzcGxpdCIsIm1hcCIsImRlY29kZVVSSUNvbXBvbmVudCIsImxhYmVsT2YiLCJtIiwibG9naW4iLCJncmFudGVlIiwic2xpY2UiLCJqb2luIiwiaHR0cHNBdmF0YXIiLCJ1cmwiLCJ1bmRlZmluZWQiLCJVUkwiLCJwcm90b2NvbCIsIlNwYWNlTWFuYWdlciIsInNwYWNlcyIsInNldFNwYWNlcyIsInVzZVN0YXRlIiwiZXJyb3IiLCJzZXRFcnJvciIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJyZWdpb24iLCJ1c2VSZWdpb24iLCJmdWxsVGFiIiwibG9hZFNwYWNlcyIsInVzZUNhbGxiYWNrIiwibGlzdEFsbFNwYWNlcyIsImUiLCJjb2RlIiwidXNlRWZmZWN0IiwicnVuIiwidGFza0lucHV0IiwidXNlVGFza0lucHV0IiwiaGludENvbnN1bWVkIiwidXNlUmVmIiwiY3VycmVudCIsInRhc2siLCJzcGFjZUlkIiwicGFyYW1zIiwidGFyZ2V0IiwiZmluZCIsInMiLCJyb2xlIiwicXVldWVNaWNyb3Rhc2siLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJDb25uZWN0U291cmNlRW50cnkiLCJvbkNvbm5lY3RlZCIsIkNyZWF0ZVNwYWNlRW50cnkiLCJvbkNyZWF0ZWQiLCJJbnZpdGF0aW9uc0luYm94Iiwib25BY2NlcHRlZCIsImxlbmd0aCIsIm5hbWUiLCJraW5kT2YiLCJ0eXBlIiwib25DbGljayIsIk1hbmFnZU1vZGFsIiwic3BhY2UiLCJvbkNsb3NlIiwib25TcGFjZXNDaGFuZ2VkIiwiQXVkaXRWaWV3IiwiX2MiLCJpbnZpdGVzIiwidXNlSW52aXRlcyIsImJ1c3kiLCJzZXRCdXN5Iiwib25BY2NlcHQiLCJpbnYiLCJhY2NlcHRJbnZpdGUiLCJvbkRlY2xpbmUiLCJkZWNsaW5lSW52aXRlIiwiYXZhdGFyIiwiYXZhdGFyVXJsIiwic3JjIiwiYWx0IiwiaW52aXRlZEJ5IiwiZGlzYWJsZWQiLCJfYzIiLCJzdGF0dXMiLCJ1c2VBdXRoIiwiZXJyIiwic2V0RXJyIiwia2luZCIsInNldEtpbmQiLCJvbkNyZWF0ZSIsImNyZWF0ZVNwYWNlIiwiRnJhZ21lbnQiLCJjaGVja2VkIiwib25DaGFuZ2UiLCJfYzMiLCJvbkNvbm5lY3QiLCJwcm90b2NvbFJlcXVlc3QiLCJzY2hlbWUiLCJfYzQiLCJncmFudHMiLCJzZXRHcmFudHMiLCJsb2FkIiwibGlzdEdyYW50cyIsIm9uUmV2b2tlIiwiZyIsImtleSIsInJldm9rZUdyYW50IiwiYnlBcHAiLCJNYXAiLCJzZXQiLCJnZXQiLCJlbnRyaWVzIiwibGlzdCIsIm1vZGUiLCJzdWJ0cmVlIiwiX2M1IiwibWVtYmVycyIsInNldE1lbWJlcnMiLCJwZW5kaW5nIiwic2V0UGVuZGluZyIsImhhbmRsZSIsInNldEhhbmRsZSIsImFkZFJvbGUiLCJzZXRBZGRSb2xlIiwicmV2b2tpbmciLCJzZXRSZXZva2luZyIsImNvbnZlcnRBcm1lZCIsInNldENvbnZlcnRBcm1lZCIsImNvbnZlcnRpbmciLCJzZXRDb252ZXJ0aW5nIiwicmVmcmVzaCIsInAiLCJQcm9taXNlIiwiYWxsIiwiZ2V0U3BhY2VNZW1iZXJzIiwibGlzdFBlbmRpbmdJbnZpdGVzIiwiY2F0Y2giLCJvd25lckNvdW50IiwiZmlsdGVyIiwib25JbnZpdGUiLCJoIiwidHJpbSIsImludml0ZVRvU3BhY2UiLCJvblJldm9rZUludml0ZSIsInVpZCIsInJldm9rZUludml0ZSIsIm9uUm9sZSIsInNldFNwYWNlUm9sZSIsIm9uUmVtb3ZlIiwidW5zaGFyZVNwYWNlIiwib25Db252ZXJ0IiwiY29uZmlybSIsInN0b3BQcm9wYWdhdGlvbiIsInBsYWNlaG9sZGVyIiwidmFsdWUiLCJvbktleURvd24iLCJyIiwibGFzdE93bmVyIiwidGl0bGUiLCJfYzYiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTcGFjZU1hbmFnZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBzcGFjZSBtYW5hZ2VyIChVSV9BU19BUFBTX1NQRUMgwqc1LjIpLiBMaXN0cyB0aGUgdXNlcidzIHNwYWNlcyAoc3BhY2VzOnVzZXIpLFxuLy8gc3VyZmFjZXMgdGhlIHVzZXIncyBsaXZlIEludml0YXRpb25zIGluYm94IChBY2NlcHQvRGVjbGluZSDigJQgRklMRV9TSEFSSU5HIMKnNi40L8KnOS44KSxcbi8vIGFuZCwgZm9yIG93bmVkIHNwYWNlcywgbWFuYWdlcyBzaGFyaW5nIChzcGFjZXM6YWRtaW4pOiBJTlZJVEUgYSB1c2VyIGJ5IHByb3ZpZGVyXG4vLyBoYW5kbGUgKGEgcHVsbC1iYXNlZCBpbnZpdGF0aW9uLCBOT1QgYW4gaW1tZWRpYXRlIG1lbWJlcnNoaXAgd3JpdGUg4oCUIHRoZSByZWNpcGllbnRcbi8vIGFjY2VwdHMpLCByZXZva2UgYSBwZW5kaW5nIGludml0ZSwgY2hhbmdlIGEgbWVtYmVyJ3Mgcm9sZSwgcmVtb3ZlIGEgbWVtYmVyLiBUaGUgaG9zdFxuLy8gcmVzb2x2ZXMgaGFuZGxlcyBhbmQgZW5mb3JjZXMgdGhlIG93bmVyLWxvY2tvdXQgaW52YXJpYW50IChhIHNwYWNlIGFsd2F5cyBrZWVwcyBhblxuLy8gb3duZXIpIOKAlCB0aGlzIGFwcCBqdXN0IGRyaXZlcyB0aGUgZmxvdyBhbmQgc2hvd3MgdGhlIHJlc3VsdC5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIGxpc3RBbGxTcGFjZXMsXG4gIGdldFNwYWNlTWVtYmVycyxcbiAgaW52aXRlVG9TcGFjZSxcbiAgbGlzdFBlbmRpbmdJbnZpdGVzLFxuICByZXZva2VJbnZpdGUsXG4gIHVzZUludml0ZXMsXG4gIGFjY2VwdEludml0ZSxcbiAgZGVjbGluZUludml0ZSxcbiAgdW5zaGFyZVNwYWNlLFxuICBzZXRTcGFjZVJvbGUsXG4gIGxpc3RHcmFudHMsXG4gIHJldm9rZUdyYW50LFxuICBjcmVhdGVTcGFjZSxcbiAgdXNlQXV0aCxcbiAgdXNlUmVnaW9uLFxuICB1c2VUYXNrSW5wdXQsXG4gIHR5cGUgU3BhY2VJbmZvLFxuICB0eXBlIE1lbWJlcixcbiAgdHlwZSBJbnZpdGUsXG4gIHR5cGUgUm9sZSxcbiAgdHlwZSBHcmFudFJlY29yZCxcbn0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG4vLyBUaGUgd2lyZS1sZXZlbCBlc2NhcGUgaGF0Y2gsIGZyb20gdGhlIFNESydzIG93biBzdWJwYXRoLiBgY29ubmVjdFNvdXJjZWAgaXMgbm90IG9uXG4vLyB0aGUgcGlubmVkIHR5cGVkIHN1cmZhY2UgeWV0IChSMy0yMDYgYWRkcyB0aGUgaG9zdCB2ZXJiOyB0aGUgU0RLIGV4cG9ydCBmb2xsb3dzIG9uXG4vLyBpdHMgbmV4dCByZWxlYXNlKSwgYW5kIGBwcm90b2NvbFJlcXVlc3RgIGlzIGV4YWN0bHkgdGhlIHNlYW0gZm9yIHRoYXQgZ2FwIOKAlCB0aGVcbi8vIG1ldGhvZCBuYW1lIGlzIHRoZSBjb250cmFjdCBlaXRoZXIgd2F5LlxuaW1wb3J0IHsgcHJvdG9jb2xSZXF1ZXN0IH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL3NhbmRib3hVdGlsc1wiO1xuaW1wb3J0IFwiLi9TcGFjZU1hbmFnZXIuY3NzXCI7XG5cbmNvbnN0IFJPTEVTOiBSb2xlW10gPSBbXCJvd25lclwiLCBcIndyaXRlclwiLCBcInJlYWRlclwiXTtcblxuY29uc3QgdWlkT2YgPSAocHJpbmNpcGFsOiBzdHJpbmcpOiBzdHJpbmcgPT4gcHJpbmNpcGFsLnJlcGxhY2UoL151c2VyOi8sIFwiXCIpO1xuXG4vLyBhcHBLZXkgPSBlbmMocHJvdmlkZXIpX19lbmMobmFtZXNwYWNlKV9fZW5jKHJlcG9zaXRvcnkpICjCp3NwYWNlSWQudHMpLlxuY29uc3QgZGVjb2RlQXBwID0gKGFwcEtleTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBbLCBucywgcmVwb10gPSBhcHBLZXkuc3BsaXQoXCJfX1wiKS5tYXAoZGVjb2RlVVJJQ29tcG9uZW50KTtcbiAgICByZXR1cm4gbnMgJiYgcmVwbyA/IGAke25zfS8ke3JlcG99YCA6IGFwcEtleTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGFwcEtleTtcbiAgfVxufTtcbmNvbnN0IGxhYmVsT2YgPSAobTogTWVtYmVyKTogc3RyaW5nID0+IChtLmxvZ2luID8gYEAke20ubG9naW59YCA6IGAjJHt1aWRPZihtLmdyYW50ZWUpLnNwbGl0KFwiOlwiKS5zbGljZSgxKS5qb2luKFwiOlwiKSB8fCB1aWRPZihtLmdyYW50ZWUpfWApO1xuXG4vLyBPd25lci13cml0dGVuIGRpc3BsYXkgZmllbGRzIChsb2dpbi9uYW1lL2F2YXRhclVybCBvbiBpbnZpdGVzICsgbWVtYmVycykgYXJlXG4vLyBVTlRSVVNURUQgKEZJTEVfU0hBUklORyDCpzMvwqc2LjQpLiBSZWFjdCBlc2NhcGVzIHRleHQgY2hpbGRyZW4sIHNvIG5hbWUvaGFuZGxlIGFyZVxuLy8gc2FmZSBhcyBgey4uLn1gOyBhbiBhdmF0YXJVcmwsIGhvd2V2ZXIsIGJlY29tZXMgYSBVUkwg4oCUIGFjY2VwdCBvbmx5IGBodHRwczpgIHNvIGFcbi8vIGNyYWZ0ZWQgYGphdmFzY3JpcHQ6YC9gZGF0YTpgIHZhbHVlIGNhbiBuZXZlciByZWFjaCBhbiBgPGltZyBzcmM+YC5cbmNvbnN0IGh0dHBzQXZhdGFyID0gKHVybDogc3RyaW5nIHwgdW5kZWZpbmVkKTogc3RyaW5nIHwgdW5kZWZpbmVkID0+IHtcbiAgaWYgKCF1cmwpIHJldHVybiB1bmRlZmluZWQ7XG4gIHRyeSB7XG4gICAgcmV0dXJuIG5ldyBVUkwodXJsKS5wcm90b2NvbCA9PT0gXCJodHRwczpcIiA/IHVybCA6IHVuZGVmaW5lZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3BhY2VNYW5hZ2VyKCkge1xuICBjb25zdCBbc3BhY2VzLCBzZXRTcGFjZXNdID0gdXNlU3RhdGU8U3BhY2VJbmZvW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxTcGFjZUluZm8gfCBudWxsPihudWxsKTtcbiAgLy8gU1BBQ0VTX1VJX1NQRUMgwqc1IC8gUi1TUEFDRVMtNzogdGhpcyBhcHAgcmVuZGVycyBpbiB0d28gc3VyZmFjZXMuIFRoZSBuYXJyb3dcbiAgLy8gYHBhbmVsLnNwYWNlc2AgY29sdW1uIGluc2lkZSB0aGUgd29ya2JlbmNoLCBhbmQg4oCUIGF0IGl0cyBvd24gZGVlcC1saW5rYWJsZSByb3V0ZVxuICAvLyAoYC9zcGFjZXNgKSDigJQgYSBzdGFuZGFsb25lIGZ1bGwtdGFiIHN1cmZhY2UgYm91bmQgYXMgYHBhZ2Uuc3BhY2VzYC4gQW55IHJlZ2lvblxuICAvLyB0aGF0IGlzIG5vdCB0aGUgbmFycm93IHBhbmVsICh0aGUgZnVsbC10YWIgYmluZGluZywgYSBmb3JrLCBvciBgbnVsbGAgZm9yIHBsYWluXG4gIC8vIGB2aXRlIGRldmApIGdldHMgdGhlIHJvb21pZXIgZnVsbC1zY3JlZW4gbGF5b3V0LlxuICBjb25zdCByZWdpb24gPSB1c2VSZWdpb24oKTtcbiAgLy8gUFJJTkNJUEFMUyDCpzkgQjMgLyBSMy05NjogdGhlIG5hcnJvdyBgcGFuZWwuc3BhY2VzYCByYWlsIGlzIGJyb3dzZS9vcGVuL21vdW50LW9ubHlcbiAgLy8gYW5kIGhvbGRzIGBzcGFjZXM6dXNlcmAgYnV0IE5PVCBgc3BhY2VzOmFkbWluYCAoc2VlIHNpdGUtbWFpbiBgcmVnaXN0cnkvZGVmYXVsdHMudHNgKS5cbiAgLy8gU28gdGhlIGFkbWluIHN1cmZhY2VzIGJlbG93IOKAlCB0aGUgcGVyLXNwYWNlIFwiTWFuYWdlXCIgbW9kYWwgKGludml0ZS9yb2xlL3JlbW92ZSkgYW5kXG4gIC8vIHRoZSBncmFudCBBdWRpdFZpZXcsIGFsbCBgc3BhY2VzOmFkbWluYC1nYXRlZCBob3N0LXNpZGUg4oCUIGFyZSByZW5kZXJlZCBPTkxZIG9uIHRoZVxuICAvLyBub24tcGFuZWwgc3VyZmFjZSAoYHBhZ2Uuc3BhY2VzYCBmdWxsIHRhYikuIEluIHRoZSByYWlsIHRoZXknZCBvbmx5IGZpcmUgYGZvcmJpZGRlbmAsXG4gIC8vIGFuZCB0aGUgZXhpdCBjcml0ZXJpb24gaXMgXCJ0aGUgcmFpbCBleHBvc2VzIG5vIGFkbWluIHZlcmIuXCIgQnJvd3NlIChsaXN0IHNwYWNlcyxcbiAgLy8gYHNwYWNlczp1c2VyYCkgYW5kIHRoZSBpbnZpdGVlLXNpZGUgSW52aXRhdGlvbnMgaW5ib3ggKGFjY2VwdC9kZWNsaW5lIG93biBpbnZpdGVzLFxuICAvLyBhbHNvIGBzcGFjZXM6dXNlcmApIHN0YXkgaW4gYm90aCBzdXJmYWNlcy5cbiAgY29uc3QgZnVsbFRhYiA9IHJlZ2lvbiAhPT0gXCJwYW5lbC5zcGFjZXNcIjtcblxuICBjb25zdCBsb2FkU3BhY2VzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBzZXRTcGFjZXMoYXdhaXQgbGlzdEFsbFNwYWNlcygpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgc2V0RXJyb3IoY29kZSA9PT0gXCJhdXRoLXJlcXVpcmVkXCIgPyBcIlNpZ24gaW4gdG8gbWFuYWdlIHlvdXIgc3BhY2VzLlwiIDogXCJDb3VsZG7igJl0IGxvYWQgc3BhY2VzLlwiKTtcbiAgICAgIHNldFNwYWNlcyhbXSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBsb2FkU3BhY2VzKCk7XG4gICAgfTtcbiAgICB2b2lkIHJ1bigpO1xuICB9LCBbbG9hZFNwYWNlc10pO1xuXG4gIC8vIFIzLTI2OSBENDogdGhlIGhvc3QncyBgb3Blbi1zcGFjZWAgYm9vdCBoaW50IOKAlCBgL3NwYWNlcz9zcGFjZT08aWQ+YCAodGhlIGZpbGVcbiAgLy8gZXhwbG9yZXIncyBcIk1hbmFnZSBzaGFyaW5nIOKGklwiIGRlZXAgbGluaykgYXV0by1vcGVucyB0aGUgTWFuYWdlIG1vZGFsIEFUIHRoYXRcbiAgLy8gc3BhY2UuIFVudHJ1c3RlZCBkaXNwbGF5L25hdmlnYXRpb24gZGF0YTogaXQgaXMgb25seSBldmVyIE1BVENIRUQgYWdhaW5zdCB0aGVcbiAgLy8gc3BhY2VzIHRoaXMgdXNlciBhY3R1YWxseSBoYXMgKGFuZCBvbmx5IHdoZXJlIHRoZSBhZG1pbiBzdXJmYWNlIHJlbmRlcnMg4oCUIHRoZVxuICAvLyBmdWxsIHRhYiwgb24gYW4gb3duZWQgc3BhY2UpLiBDb25zdW1lZCBvbmNlLCBzbyBjbG9zaW5nIHRoZSBtb2RhbCBzdGF5cyBjbG9zZWQuXG4gIGNvbnN0IHRhc2tJbnB1dCA9IHVzZVRhc2tJbnB1dCgpO1xuICBjb25zdCBoaW50Q29uc3VtZWQgPSB1c2VSZWYoZmFsc2UpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChoaW50Q29uc3VtZWQuY3VycmVudCB8fCAhZnVsbFRhYiB8fCAhc3BhY2VzKSByZXR1cm47XG4gICAgaWYgKHRhc2tJbnB1dD8udGFzayAhPT0gXCJvcGVuLXNwYWNlXCIpIHJldHVybjtcbiAgICBjb25zdCBzcGFjZUlkID0gdGFza0lucHV0LnBhcmFtcz8uc3BhY2VJZDtcbiAgICBpZiAodHlwZW9mIHNwYWNlSWQgIT09IFwic3RyaW5nXCIpIHJldHVybjtcbiAgICBoaW50Q29uc3VtZWQuY3VycmVudCA9IHRydWU7XG4gICAgY29uc3QgdGFyZ2V0ID0gc3BhY2VzLmZpbmQoKHMpID0+IHMuc3BhY2VJZCA9PT0gc3BhY2VJZCk7XG4gICAgLy8gRGVmZXJyZWQgc28gdGhlIHNlbGVjdGlvbiBpc24ndCBhIHN5bmNocm9ub3VzIHNldC1zdGF0ZSBpbnNpZGUgdGhlIGVmZmVjdFxuICAgIC8vIChyZWFjdC1ob29rcy9zZXQtc3RhdGUtaW4tZWZmZWN0KTsgdGhlIHJlZiBhYm92ZSBtYWtlcyBpdCBvbmUtc2hvdC5cbiAgICBpZiAodGFyZ2V0ICYmIHRhcmdldC5yb2xlID09PSBcIm93bmVyXCIpIHF1ZXVlTWljcm90YXNrKCgpID0+IHNldFNlbGVjdGVkKHRhcmdldCkpO1xuICB9LCBbZnVsbFRhYiwgc3BhY2VzLCB0YXNrSW5wdXRdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtmdWxsVGFiID8gXCJzbSBzbS1mdWxsXCIgOiBcInNtXCJ9PlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJzbS1oZFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzbS10aXRsZVwiPlNwYWNlczwvc3Bhbj5cbiAgICAgICAge2Z1bGxUYWIgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLWNyZWF0ZVwiPlxuICAgICAgICAgICAgPENvbm5lY3RTb3VyY2VFbnRyeSBvbkNvbm5lY3RlZD17bG9hZFNwYWNlc30gLz5cbiAgICAgICAgICAgIDxDcmVhdGVTcGFjZUVudHJ5IG9uQ3JlYXRlZD17bG9hZFNwYWNlc30gLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2hlYWRlcj5cbiAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInNtLW1zZ1wiPntlcnJvcn08L2Rpdj59XG4gICAgICA8SW52aXRhdGlvbnNJbmJveCBvbkFjY2VwdGVkPXtsb2FkU3BhY2VzfSAvPlxuICAgICAge3NwYWNlcyA9PT0gbnVsbCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbS1tc2dcIj5Mb2FkaW5n4oCmPC9kaXY+XG4gICAgICApIDogc3BhY2VzLmxlbmd0aCA9PT0gMCAmJiAhZXJyb3IgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20tbXNnXCI+Tm8gc3BhY2VzIHlldC4gQXBwcyBjcmVhdGUgdGhlbSBvbiBkZW1hbmQuPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwic20tbGlzdFwiPlxuICAgICAgICAgIHtzcGFjZXMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICA8bGkga2V5PXtzLnNwYWNlSWR9IGNsYXNzTmFtZT1cInNtLXJvd1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtLXJvdy1tYWluXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic20tbmFtZVwiPntzLm5hbWUgPz8gXCJVbnRpdGxlZCBzcGFjZVwifTwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7LyogUjMtMjU5IOKAlCBvbmx5IFNIQVJFRCBpcyBiYWRnZWQ6IHBlcnNvbmFsIGlzIHRoZSB1bm1hcmtlZCBkZWZhdWx0XG4gICAgICAgICAgICAgICAgICAgICh0aGUgc2FtZSBcImFic2VuY2UgaXMgdGhlIHF1aWV0IGNhc2VcIiBydWxlIHRoZSBwdWJsaXNoZXIgYmFkZ2VcbiAgICAgICAgICAgICAgICAgICAgdXNlcyksIGFuZCB0aGUga2luZCBzaG93biBpcyB0aGUgaG9zdCdzIERFUklWRUQgb25lLiAqL31cbiAgICAgICAgICAgICAgICB7a2luZE9mKHMpID09PSBcInNoYXJlZFwiICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLWtpbmRcIiBkYXRhLWtpbmQ9XCJzaGFyZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgc2hhcmVkXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzbS1yb2xlXCIgZGF0YS1yb2xlPXtzLnJvbGV9PntzLnJvbGV9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge2Z1bGxUYWIgJiYgcy5yb2xlID09PSBcIm93bmVyXCIgJiYgKFxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNtLW1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHMpfT5cbiAgICAgICAgICAgICAgICAgIE1hbmFnZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG4gICAgICB7ZnVsbFRhYiAmJiBzZWxlY3RlZCAmJiAoXG4gICAgICAgIDxNYW5hZ2VNb2RhbCBzcGFjZT17c2VsZWN0ZWR9IG9uQ2xvc2U9eygpID0+IHNldFNlbGVjdGVkKG51bGwpfSBvblNwYWNlc0NoYW5nZWQ9e2xvYWRTcGFjZXN9IC8+XG4gICAgICApfVxuICAgICAge2Z1bGxUYWIgJiYgPEF1ZGl0VmlldyAvPn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8gRklMRV9TSEFSSU5HIMKnNi40L8KnOS44IEludml0YXRpb25zIGluYm94OiB0aGUgaW52aXRlZSdzIHB1bGwtYmFzZWQgYWNjZXB0IHN1cmZhY2UuXG4vLyBBIHBlbmRpbmcgaW52aXRlIGNvbmZlcnMgTk8gYWNjZXNzIOKAlCB0aGUgdXNlciBvcHRzIGluIGhlcmUuIFRoZSBsaXN0IGlzIExJVkUgdmlhXG4vLyBgdXNlSW52aXRlcygpYCAodGhlIGhvc3QgcHVzaGVzIHRoZSBpbmJveCBvbiB0aGUgYHNwYWNlczp1c2VyYCBjaGFubmVsKSwgc28gYW5cbi8vIGFycml2aW5nL2FjY2VwdGVkL2RlY2xpbmVkIGludml0ZSByZWZsZWN0cyB3aXRoaW4gb25lIHNuYXBzaG90IOKAlCBubyByZWxvYWQuIEFjY2VwdFxuLy8gbWF0ZXJpYWxpemVzIG1lbWJlcnNoaXA7IHRoZSBhY2NlcHRlZCBzcGFjZSB0aGVuIGFwcGVhcnMgb25jZSB3ZSByZWZyZXNoIHRoZSBzcGFjZXNcbi8vIGxpc3QgKHNwYWNlcyBhcmVuJ3QgbGl2ZS1wdXNoZWQgdG8gdGhlIGFwcCksIHdoaWxlIHRoZSBpbnZpdGUgbGVhdmVzIHRoZSBpbmJveCBvblxuLy8gaXRzIG93biB2aWEgdGhlIGxpdmUgY2hhbm5lbC4gQWxsIG93bmVyLXdyaXR0ZW4gZmllbGRzIGFyZSBlc2NhcGVkIGFzIHRleHQgKFJlYWN0XG4vLyBjaGlsZHJlbikg4oCUIG5ldmVyIGBkYW5nZXJvdXNseVNldElubmVySFRNTGAsIGFuZCBhbiBhdmF0YXIgb25seSBpZiBpdCBpcyBgaHR0cHM6YC5cbmZ1bmN0aW9uIEludml0YXRpb25zSW5ib3goeyBvbkFjY2VwdGVkIH06IHsgb25BY2NlcHRlZDogKCkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD4gfSkge1xuICBjb25zdCBpbnZpdGVzID0gdXNlSW52aXRlcygpO1xuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBvbkFjY2VwdCA9IGFzeW5jIChpbnY6IEludml0ZSkgPT4ge1xuICAgIHNldEJ1c3koaW52LnNwYWNlSWQpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhY2NlcHRJbnZpdGUoaW52LnNwYWNlSWQpO1xuICAgICAgLy8gVGhlIGludml0ZSBsZWF2ZXMgdGhlIGluYm94IHZpYSB0aGUgbGl2ZSBjaGFubmVsOyByZWZyZXNoIHRoZSBzcGFjZXMgbGlzdCBzb1xuICAgICAgLy8gdGhlIG5ld2x5LWFjY2VwdGVkIHNwYWNlIGFwcGVhcnMgaW4gdGhlIHNhbWUgaW50ZXJhY3Rpb24gKMKnNi40KS5cbiAgICAgIGF3YWl0IG9uQWNjZXB0ZWQoKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIGxlYXZlIHRoZSByb3c7IHRoZSB1c2VyIGNhbiByZXRyeSAqL1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5KG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBvbkRlY2xpbmUgPSBhc3luYyAoaW52OiBJbnZpdGUpID0+IHtcbiAgICBzZXRCdXN5KGludi5zcGFjZUlkKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgZGVjbGluZUludml0ZShpbnYuc3BhY2VJZCk7XG4gICAgICAvLyBUaGUgcm93IGxlYXZlcyB0aGUgaW5ib3ggdmlhIHRoZSBsaXZlIGNoYW5uZWwuXG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiBsZWF2ZSB0aGUgcm93ICovXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3kobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIGlmIChpbnZpdGVzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzbS1pbnZpdGVzXCIgYXJpYS1sYWJlbD1cIkludml0YXRpb25zXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwic20taW52aXRlcy1oXCI+SW52aXRhdGlvbnM8L2gzPlxuICAgICAgPHVsIGNsYXNzTmFtZT1cInNtLWludml0ZS1saXN0XCI+XG4gICAgICAgIHtpbnZpdGVzLm1hcCgoaW52KSA9PiB7XG4gICAgICAgICAgY29uc3QgYXZhdGFyID0gaHR0cHNBdmF0YXIoaW52LmF2YXRhclVybCk7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e2ludi5zcGFjZUlkfSBjbGFzc05hbWU9XCJzbS1pbnZpdGUtcm93XCI+XG4gICAgICAgICAgICAgIHthdmF0YXIgPyA8aW1nIGNsYXNzTmFtZT1cInNtLWF2XCIgc3JjPXthdmF0YXJ9IGFsdD1cIlwiIC8+IDogPHNwYW4gY2xhc3NOYW1lPVwic20tYXYgc20tYXYtcGhcIiAvPn1cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic20taW52aXRlLXRleHRcIj5cbiAgICAgICAgICAgICAgICB7aW52Lmludml0ZWRCeX0gaW52aXRlZCB5b3UgdG97XCIgXCJ9XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic20tbmFtZVwiPntpbnYubmFtZSA/PyBcIlVudGl0bGVkIHNwYWNlXCJ9PC9zcGFuPiBhcyB7aW52LnJvbGV9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNtLWFjY2VwdFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3kgPT09IGludi5zcGFjZUlkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQWNjZXB0KGludil9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7YnVzeSA9PT0gaW52LnNwYWNlSWQgPyBcIuKAplwiIDogXCJBY2NlcHRcIn1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzbS1yZW1vdmVcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5ID09PSBpbnYuc3BhY2VJZH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlY2xpbmUoaW52KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERlY2xpbmVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC91bD5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbi8vIFNQQUNFU19VSV9TUEVDIMKnNSAoUi1TUEFDRVMtNykgXCJjcmVhdGUgYSBzcGFjZVwiIGVudHJ5IOKAlCBvbmx5IG9uIHRoZSBmdWxsLXRhYlxuLy8gc3VyZmFjZSAodGhlIGluLXdvcmtiZW5jaCBtb2RhbCBpcyB0aGUgb3RoZXIgZW50cnkgcG9pbnQpLiBJdCBkcml2ZXMgdGhlIFNBTUUgaG9zdFxuLy8gYGNyZWF0ZVNwYWNlKClgIGNvbnNlbnQgcGF0aCAoRklMRV9TSEFSSU5HIMKnNi/CpzkuMyk6IHRoZSBob3N0IG93bnMgdGhlIHF1b3RhIGdhdGUsXG4vLyB0aGUgZmlyc3QtY3JlYXRlLXBlci1hcHAgY29uc2VudCwgYW5kIHRoZSB3cml0ZSBvcmRlcmluZy4gVGhpcyBhcHAgZG9lcyBOT1QgcGFpbnRcbi8vIGFueSBhdXRob3JpemF0aW9uIGNocm9tZSDigJQgaXQganVzdCBjYWxscyBgY3JlYXRlU3BhY2UoKWAgYW5kIHJlZmxlY3RzIHRoZSByZXN1bHQuXG4vLyBHYXRlZCBvbiBzaWduZWQtaW46IGNyZWF0aW5nIHN0b3JhZ2UgaW4gdGhlIHVzZXIncyBhY2NvdW50IG5lZWRzIGFuIGFjY291bnQuXG4vL1xuLy8gUjMtMjU5IOKAlCB0aGUgY3JlYXRlLXRpbWUgS0lORC4gUGVyc29uYWwgKGRlZmF1bHQpIGlzIHRoZSBzYWZlLFxuLy8gcmV2ZXJzaWJsZS11bnRpbC1jb252ZXJ0ZWQgc3RhdGU7IFNoYXJlZCBpcyBzaGFyZWQgZnJvbSB0aGUgZmlyc3QgYnl0ZSAodGhlIGhvc3Rcbi8vIGxhdGNoZXMgaXQgYXQgYmlydGgpLiBUaGUgd2lyZSBwYXJhbSBpcyBhZGRpdGl2ZSAodGhlIHBpbm5lZCB0eXBlZCB3cmFwcGVyIHBhc3Nlc1xuLy8gb3B0cyBzdHJhaWdodCB0aHJvdWdoIOKAlCB0aGUgY2FzdCBpcyB0aGUgbG9jYWwgd2lkZW5pbmcgdW50aWwgdGhlIFNESyBleHBvcnRcbi8vIGNhdGNoZXMgdXA7IHRoZSBIT1NUIHZhbGlkYXRlcyB0aGUgbGl0ZXJhbCBlaXRoZXIgd2F5KS5cbnR5cGUgQ3JlYXRlS2luZCA9IFwicGVyc29uYWxcIiB8IFwic2hhcmVkXCI7XG5cbmZ1bmN0aW9uIENyZWF0ZVNwYWNlRW50cnkoeyBvbkNyZWF0ZWQgfTogeyBvbkNyZWF0ZWQ6ICgpID0+IHZvaWQgfCBQcm9taXNlPHZvaWQ+IH0pIHtcbiAgY29uc3QgeyBzdGF0dXMgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyLCBzZXRFcnJdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtraW5kLCBzZXRLaW5kXSA9IHVzZVN0YXRlPENyZWF0ZUtpbmQ+KFwicGVyc29uYWxcIik7XG5cbiAgLy8gVW50aWwgdGhlIGhvc3QgcmVwb3J0cyBhdXRoLCByZW5kZXIgbm90aGluZyByYXRoZXIgdGhhbiBhIGJ1dHRvbiB0aGF0IGNhbid0IHdvcmsuXG4gIGlmIChzdGF0dXMgIT09IFwic2lnbmVkLWluXCIpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IG9uQ3JlYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldEJ1c3kodHJ1ZSk7XG4gICAgc2V0RXJyKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICAvLyBUaGUgd2lyZSBwYXJhbSBpcyBhZGRpdGl2ZSAodGhlIHBpbm5lZCB0eXBlZCB3cmFwcGVyIHBhc3NlcyBvcHRzIHN0cmFpZ2h0XG4gICAgICAvLyB0aHJvdWdoIOKAlCB0aGUgZG91YmxlIGNhc3QgaXMgdGhlIGxvY2FsIHdpZGVuaW5nIHVudGlsIHRoZSBTREsgZXhwb3J0XG4gICAgICAvLyBjYXRjaGVzIHVwOyB0aGUgSE9TVCB2YWxpZGF0ZXMgdGhlIGxpdGVyYWwgZWl0aGVyIHdheSkuXG4gICAgICBhd2FpdCBjcmVhdGVTcGFjZSh7IGtpbmQgfSBhcyB1bmtub3duIGFzIFBhcmFtZXRlcnM8dHlwZW9mIGNyZWF0ZVNwYWNlPlswXSk7XG4gICAgICBhd2FpdCBvbkNyZWF0ZWQoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgLy8gYGNhbmNlbGxlZGAgaXMgdGhlIHVzZXIgZGlzbWlzc2luZyB0aGUgaG9zdCBjb25zZW50IOKAlCBjYWxtLCBub3QgYW4gZXJyb3IuXG4gICAgICBpZiAoY29kZSA9PT0gXCJjYW5jZWxsZWRcIikgcmV0dXJuO1xuICAgICAgc2V0RXJyKGNvZGUgPT09IFwicXVvdGEtZXhjZWVkZWRcIiA/IFwiU3BhY2UgbGltaXQgcmVhY2hlZC5cIiA6IFwiQ291bGRu4oCZdCBjcmVhdGUgYSBzcGFjZS5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtLWNyZWF0ZS1raW5kXCIgcm9sZT1cInJhZGlvZ3JvdXBcIiBhcmlhLWxhYmVsPVwiU3BhY2Uga2luZFwiPlxuICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgbmFtZT1cInNtLWNyZWF0ZS1raW5kXCJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2tpbmQgPT09IFwicGVyc29uYWxcIn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXRLaW5kKFwicGVyc29uYWxcIil9XG4gICAgICAgICAgLz5cbiAgICAgICAgICBQZXJzb25hbFxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgbmFtZT1cInNtLWNyZWF0ZS1raW5kXCJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2tpbmQgPT09IFwic2hhcmVkXCJ9XG4gICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gc2V0S2luZChcInNoYXJlZFwiKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIFNoYXJlZFxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICB7a2luZCA9PT0gXCJzaGFyZWRcIiAmJiAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic20tY3JlYXRlLW5vdGVcIj5Nb3JlIHRoYW4gb25lIHBlcnNvbiB3aWxsIGJlIGFibGUgdG8gY2hhbmdlIGl0Ljwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwic20tYWRkXCIgb25DbGljaz17b25DcmVhdGV9IGRpc2FibGVkPXtidXN5fT5cbiAgICAgICAge2J1c3kgPyBcIkNyZWF0aW5n4oCmXCIgOiBcIkNyZWF0ZSBhIHNwYWNlXCJ9XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIHtlcnIgJiYgPHNwYW4gY2xhc3NOYW1lPVwic20tZXJyXCI+e2Vycn08L3NwYW4+fVxuICAgIDwvPlxuICApO1xufVxuXG4vLyBSMy0yNTkg4oCUIHRoZSBERVJJVkVEIGtpbmQgdGhlIGhvc3QgbGlzdHMgKGBTcGFjZUluZm9gIGdhaW5zIGBraW5kYCBvbiB0aGUgd2lyZTtcbi8vIHJlYWQgZGVmZW5zaXZlbHkgc28gdGhlIHBpbm5lZCBTREsgdHlwZSBkb2Vzbid0IGdhdGUgdGhlIGJhZGdlKS5cbmNvbnN0IGtpbmRPZiA9IChzOiBTcGFjZUluZm8pOiBDcmVhdGVLaW5kIHwgdW5kZWZpbmVkID0+IChzIGFzIHsga2luZD86IENyZWF0ZUtpbmQgfSkua2luZDtcblxuLy8gUjMtMjA2IC8gU1BBQ0VTX1VJX1NQRUMgwqc04oCTwqc1IChSLVNQQUNFUy02KSDigJQgXCJDb25uZWN0IGEgbmV3IHNvdXJjZSDihpIgR29vZ2xlIERyaXZlXCIuXG4vL1xuLy8gQ09OTkVDVCBJUyBOT1QgU0VMRUNULCBhbmQgdGhhdCBpcyB3aHkgdGhpcyBpcyBhIHNlY29uZCBlbnRyeSBwb2ludCByYXRoZXIgdGhhbiBhXG4vLyByb3cgaW4gdGhlIHBvd2VyYm94LiBgcmVxdWVzdE1vdW50KClgIHBpY2tzIGZyb20gc291cmNlcyB0aGUgdXNlciBBTFJFQURZIGhhcztcbi8vIHRoaXMgU0VUUyBPTkUgVVAg4oCUIGFuIGluY3JlbWVudGFsIEdvb2dsZSBjb25zZW50LCBhIGZvbGRlciBwaWNrLCBhbiBhY2Nlc3MgY2hvaWNlLlxuLy8gUHV0dGluZyBhIHByb3ZpZGVyIE9BdXRoIGZsb3cgaW5zaWRlIHRoZSBwb3dlcmJveCB3b3VsZCBtZWFuIHRoZSBwaWNrZXIgc29tZXRpbWVzXG4vLyBuYXZpZ2F0ZXMgdGhlIHdob2xlIHBhZ2UgdG8gR29vZ2xlLCB3aGljaCBpcyBleGFjdGx5IHdoYXQgwqc4LjIgcnVsZXMgb3V0LlxuLy9cbi8vIEV2ZXJ5IHN0ZXAgaXMgZHJhd24gYnkgdGhlIEhPU1Q6IHRoZSBzY29wZSByZXF1ZXN0LCB0aGUgZm9sZGVyIGJyb3dzZXIsIHRoZSByb3xyd1xuLy8gY2hvaWNlIGFuZCB0aGUgc2luZ2xlLXdyaXRlciBkaXNjbG9zdXJlLiBUaGlzIGFwcCBzdXBwbGllcyB0aGUgU0NIRU1FIGFuZCBub3RoaW5nXG4vLyBlbHNlIOKAlCBpdCBuZXZlciBzZWVzIHRoZSB1c2VyJ3MgRHJpdmUsIHRoZSBncmFudGVkIHNjb3BlLCBvciBhbnkgb2YgdGhlIHdvcmRpbmcuXG4vLyBUaGF0IGlzIHRoZSBzYW1lIGRpc2NpcGxpbmUgYXMgYGNyZWF0ZVNwYWNlKClgIGFib3ZlOiBkcml2ZSB0aGUgZmxvdywgcmVmbGVjdCB0aGVcbi8vIHJlc3VsdCwgcGFpbnQgbm8gYXV0aG9yaXphdGlvbiBjaHJvbWUuXG4vL1xuLy8gQ2FsbGVkIHRocm91Z2ggYHByb3RvY29sUmVxdWVzdGAgcmF0aGVyIHRoYW4gYSB0eXBlZCBTREsgdmVyYiBiZWNhdXNlIHRoZSBTREsnc1xuLy8gcGlubmVkIHN1cmZhY2UgaGFzIG5vIGBjb25uZWN0U291cmNlYCB5ZXQ7IHRoZSB3aXJlIG1ldGhvZCBpcyB0aGUgY29udHJhY3QgZWl0aGVyXG4vLyB3YXksIGFuZCBzd2FwcGluZyB0byB0aGUgdHlwZWQgZXhwb3J0IHdoZW4gaXQgc2hpcHMgaXMgYSBvbmUtbGluZSBjaGFuZ2UuXG5mdW5jdGlvbiBDb25uZWN0U291cmNlRW50cnkoeyBvbkNvbm5lY3RlZCB9OiB7IG9uQ29ubmVjdGVkOiAoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPiB9KSB7XG4gIGNvbnN0IHsgc3RhdHVzIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vyciwgc2V0RXJyXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIENvbm5lY3RpbmcgYSBzb3VyY2UgaW4gdGhlIHVzZXIncyBhY2NvdW50IG5lZWRzIGFuIGFjY291bnQuXG4gIGlmIChzdGF0dXMgIT09IFwic2lnbmVkLWluXCIpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IG9uQ29ubmVjdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRCdXN5KHRydWUpO1xuICAgIHNldEVycihudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcHJvdG9jb2xSZXF1ZXN0KFwicHJvdG9jb2wtc3BhY2VzXCIsIFwiY29ubmVjdFNvdXJjZVwiLCBbeyBzY2hlbWU6IFwiZHJpdmVcIiB9XSk7XG4gICAgICBhd2FpdCBvbkNvbm5lY3RlZCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSAoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGU7XG4gICAgICAvLyBgY2FuY2VsbGVkYCBpcyB0aGUgdXNlciBiYWNraW5nIG91dCBvZiB0aGUgaG9zdCBmbG93IOKAlCBjYWxtLCBub3QgYW4gZXJyb3IuXG4gICAgICBpZiAoY29kZSA9PT0gXCJjYW5jZWxsZWRcIikgcmV0dXJuO1xuICAgICAgc2V0RXJyKFxuICAgICAgICBjb2RlID09PSBcImF1dGgtcmVxdWlyZWRcIlxuICAgICAgICAgID8gXCJTaWduIGluIHRvIGNvbm5lY3QgYSBzb3VyY2UuXCJcbiAgICAgICAgICA6IGNvZGUgPT09IFwidW5zdXBwb3J0ZWQtc2NoZW1lXCJcbiAgICAgICAgICAgID8gXCJHb29nbGUgRHJpdmUgaXNu4oCZdCBhdmFpbGFibGUgb24gdGhpcyBkZXBsb3ltZW50LlwiXG4gICAgICAgICAgICA6IGNvZGUgPT09IFwiZ29vZ2xlX3JlYXV0aF9yZXF1aXJlZFwiXG4gICAgICAgICAgICAgID8gXCJSZWNvbm5lY3QgR29vZ2xlIGluIFNldHRpbmdzIOKGkiBDb25uZWN0aW9ucywgdGhlbiB0cnkgYWdhaW4uXCJcbiAgICAgICAgICAgICAgOiBcIkNvdWxkbuKAmXQgY29ubmVjdCB0aGF0IHNvdXJjZS5cIixcbiAgICAgICk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJzbS1tYW5hZ2VcIiBvbkNsaWNrPXtvbkNvbm5lY3R9IGRpc2FibGVkPXtidXN5fT5cbiAgICAgICAge2J1c3kgPyBcIkNvbm5lY3RpbmfigKZcIiA6IFwiQ29ubmVjdCBHb29nbGUgRHJpdmVcIn1cbiAgICAgIDwvYnV0dG9uPlxuICAgICAge2VyciAmJiA8c3BhbiBjbGFzc05hbWU9XCJzbS1lcnJcIj57ZXJyfTwvc3Bhbj59XG4gICAgPC8+XG4gICk7XG59XG5cbi8vIMKnOC4xMSBjYXBhYmlsaXR5IGF1ZGl0IHZpZXc6IHdoaWNoIGFwcHMgaG9sZCB3aGljaCBtb3VudCBncmFudHMsIHdpdGggb25lLWNsaWNrXG4vLyByZXZva2UgKGR1cmFibGUgKyBiZXN0LWVmZm9ydCBsaXZlIHRlYXJkb3duLCBob3N0LXNpZGUpLlxuZnVuY3Rpb24gQXVkaXRWaWV3KCkge1xuICBjb25zdCBbZ3JhbnRzLCBzZXRHcmFudHNdID0gdXNlU3RhdGU8R3JhbnRSZWNvcmRbXSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBsb2FkID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRHcmFudHMoYXdhaXQgbGlzdEdyYW50cygpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldEdyYW50cyhbXSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBsb2FkKCk7XG4gICAgfTtcbiAgICB2b2lkIHJ1bigpO1xuICB9LCBbbG9hZF0pO1xuXG4gIGNvbnN0IG9uUmV2b2tlID0gYXN5bmMgKGc6IEdyYW50UmVjb3JkKSA9PiB7XG4gICAgY29uc3Qga2V5ID0gZy5hcHBLZXkgKyBnLnNwYWNlSWQ7XG4gICAgc2V0QnVzeShrZXkpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZXZva2VHcmFudChnLmFwcEtleSwgZy5zcGFjZUlkKTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIGxlYXZlIHRoZSByb3c7IHRoZSB1c2VyIGNhbiByZXRyeSAqL1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5KG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoIWdyYW50cyB8fCBncmFudHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcblxuICAvLyBHcm91cCBieSBhcHAgZm9yIGEgcmVhZGFibGUgXCJ0aGlzIGFwcCBjYW4gcmVhY2ggdGhlc2Ugc3BhY2VzXCIgdmlldy5cbiAgY29uc3QgYnlBcHAgPSBuZXcgTWFwPHN0cmluZywgR3JhbnRSZWNvcmRbXT4oKTtcbiAgZm9yIChjb25zdCBnIG9mIGdyYW50cykgYnlBcHAuc2V0KGcuYXBwS2V5LCBbLi4uKGJ5QXBwLmdldChnLmFwcEtleSkgPz8gW10pLCBnXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzbS1hdWRpdFwiPlxuICAgICAgPGgzIGNsYXNzTmFtZT1cInNtLWF1ZGl0LWhcIj5BcHAgYWNjZXNzPC9oMz5cbiAgICAgIHtbLi4uYnlBcHAuZW50cmllcygpXS5tYXAoKFthcHBLZXksIGxpc3RdKSA9PiAoXG4gICAgICAgIDxkaXYga2V5PXthcHBLZXl9IGNsYXNzTmFtZT1cInNtLWF1ZGl0LWFwcFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20tYXVkaXQtbmFtZVwiPntkZWNvZGVBcHAoYXBwS2V5KX08L2Rpdj5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic20tYXVkaXQtZ3JhbnRzXCI+XG4gICAgICAgICAgICB7bGlzdC5tYXAoKGcpID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17Zy5zcGFjZUlkfSBjbGFzc05hbWU9XCJzbS1hdWRpdC1ncmFudFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLWF1ZGl0LXNwYWNlXCI+e2cubmFtZSA/PyBnLnNwYWNlSWQuc2xpY2UoMCwgOCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLWF1ZGl0LXNjb3BlXCI+XG4gICAgICAgICAgICAgICAgICB7Zy5tb2RlID09PSBcInJvXCIgPyBcInJlYWQtb25seVwiIDogXCJyZWFkLXdyaXRlXCJ9XG4gICAgICAgICAgICAgICAgICB7Zy5zdWJ0cmVlID8gYCDCtyAke2cuc3VidHJlZX1gIDogXCJcIn1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzbS1yZW1vdmVcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3kgPT09IGcuYXBwS2V5ICsgZy5zcGFjZUlkfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25SZXZva2UoZyl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2J1c3kgPT09IGcuYXBwS2V5ICsgZy5zcGFjZUlkID8gXCLigKZcIiA6IFwiUmV2b2tlXCJ9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkpfVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gTWFuYWdlTW9kYWwoe1xuICBzcGFjZSxcbiAgb25DbG9zZSxcbiAgb25TcGFjZXNDaGFuZ2VkLFxufToge1xuICBzcGFjZTogU3BhY2VJbmZvO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAvKiogUjMtMjU5IOKAlCB0aGUgY29udmVyc2lvbiBjaGFuZ2VzIHRoZSBMSVNUIGJhZGdlLCBub3QganVzdCBtZW1iZXJzLiAqL1xuICBvblNwYWNlc0NoYW5nZWQ/OiAoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPjtcbn0pIHtcbiAgY29uc3QgW21lbWJlcnMsIHNldE1lbWJlcnNdID0gdXNlU3RhdGU8TWVtYmVyW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGU8SW52aXRlW10+KFtdKTtcbiAgY29uc3QgW2hhbmRsZSwgc2V0SGFuZGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYWRkUm9sZSwgc2V0QWRkUm9sZV0gPSB1c2VTdGF0ZTxSb2xlPihcIndyaXRlclwiKTtcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcmV2b2tpbmcsIHNldFJldm9raW5nXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZXJyLCBzZXRFcnJdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIC8vIFIzLTI1OSDigJQgdGhlIENvbnZlcnQgYXJtLXRoZW4tY29uZmlybSBzdGF0ZSAodGhlIHNhbWUgdHdvLWNsaWNrIHNoYXBlIHRoZVxuICAvLyBjb250cmlidXRlIHBhbmVsJ3MgcmVzZXQgdXNlcykuIFRoZSBJUlJFVkVSU0lCSUxJVFkgY29weSBsaXZlcyBIRVJFLCBpbiB0aGVcbiAgLy8gbWFuYWdlciwgcGVyIHRoZSBpdGVtOyB0aGUgd2lyZSBhZGRpdGlvbmFsbHkgY2FycmllcyBgY29uZmlybTogdHJ1ZWAgYXNcbiAgLy8gYmVsdC1hbmQtYnJhY2VzIGFuZCB0aGUgaG9zdCBvd25lci1jaGVja3MgdGhlIHZlcmIuXG4gIGNvbnN0IFtjb252ZXJ0QXJtZWQsIHNldENvbnZlcnRBcm1lZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjb252ZXJ0aW5nLCBzZXRDb252ZXJ0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCByZWZyZXNoID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICAvLyBNZW1iZXJzIChhY2NlcHRlZCkgYW5kIHBlbmRpbmcgaW52aXRhdGlvbnMgKG9mZmVyZWQsIG5vdCB5ZXQgYWNjZXB0ZWQpIGFyZVxuICAgICAgLy8gZGlzam9pbnQgc3VyZmFjZXMg4oCUIGEgcGVuZGluZyBpbnZpdGVlIGlzIE5PVCBhIG1lbWJlciAowqc2LjQpLCBzbyB3ZSBsaXN0XG4gICAgICAvLyB0aGVtIHNlcGFyYXRlbHkgYW5kIG5ldmVyIGRvdWJsZS1saXN0LlxuICAgICAgY29uc3QgW20sIHBdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBnZXRTcGFjZU1lbWJlcnMoc3BhY2Uuc3BhY2VJZCksXG4gICAgICAgIGxpc3RQZW5kaW5nSW52aXRlcyhzcGFjZS5zcGFjZUlkKS5jYXRjaCgoKSA9PiBbXSBhcyBJbnZpdGVbXSksXG4gICAgICBdKTtcbiAgICAgIHNldE1lbWJlcnMobSk7XG4gICAgICBzZXRQZW5kaW5nKHApO1xuICAgIH0gY2F0Y2gge1xuICAgICAgc2V0RXJyKFwiQ291bGRu4oCZdCBsb2FkIG1lbWJlcnMuXCIpO1xuICAgIH1cbiAgfSwgW3NwYWNlLnNwYWNlSWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICB9O1xuICAgIHZvaWQgcnVuKCk7XG4gIH0sIFtyZWZyZXNoXSk7XG5cbiAgY29uc3Qgb3duZXJDb3VudCA9IChtZW1iZXJzID8/IFtdKS5maWx0ZXIoKG0pID0+IG0ucm9sZSA9PT0gXCJvd25lclwiKS5sZW5ndGg7XG5cbiAgY29uc3Qgb25JbnZpdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgaCA9IGhhbmRsZS50cmltKCkucmVwbGFjZSgvXkAvLCBcIlwiKTtcbiAgICBpZiAoIWgpIHJldHVybjtcbiAgICBzZXRCdXN5KHRydWUpO1xuICAgIHNldEVycihudWxsKTtcbiAgICB0cnkge1xuICAgICAgLy8gwqc2LjQ6IGNyZWF0ZSBhbiBJTlZJVEFUSU9OIChub3QgYSBtZW1iZXJzaGlwKS4gVGhlIG9mZmVyIHNob3dzIHVuZGVyIFBlbmRpbmdcbiAgICAgIC8vIHVudGlsIHRoZSByZWNpcGllbnQgYWNjZXB0cyDigJQgcmVmcmVzaCByZWZsZWN0cyBpdCB0aGVyZSwgbm90IHVuZGVyIE1lbWJlcnMuXG4gICAgICBhd2FpdCBpbnZpdGVUb1NwYWNlKHNwYWNlLnNwYWNlSWQsIGgsIGFkZFJvbGUpO1xuICAgICAgc2V0SGFuZGxlKFwiXCIpO1xuICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSAoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGU7XG4gICAgICBzZXRFcnIoXG4gICAgICAgIGNvZGUgPT09IFwibm90LWZvdW5kXCJcbiAgICAgICAgICA/IGBObyB1c2VyIOKAnEAke2h94oCdLmBcbiAgICAgICAgICA6IGNvZGUgPT09IFwiZm9yYmlkZGVuXCJcbiAgICAgICAgICAgID8gXCJOb3QgYWxsb3dlZC5cIlxuICAgICAgICAgICAgOiBjb2RlID09PSBcInF1b3RhLWV4Y2VlZGVkXCJcbiAgICAgICAgICAgICAgPyBcIlRvbyBtYW55IHBlbmRpbmcgaW52aXRlcy5cIlxuICAgICAgICAgICAgICA6IFwiQ291bGRu4oCZdCBpbnZpdGUuXCIsXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5KGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3Qgb25SZXZva2VJbnZpdGUgPSBhc3luYyAoaW52OiBJbnZpdGUpID0+IHtcbiAgICBzZXRSZXZva2luZyhpbnYudWlkKTtcbiAgICBzZXRFcnIobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJldm9rZUludml0ZShzcGFjZS5zcGFjZUlkLCBpbnYudWlkKTtcbiAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldEVycihcIkNvdWxkbuKAmXQgcmV2b2tlIHRoZSBpbnZpdGUuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRSZXZva2luZyhudWxsKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3Qgb25Sb2xlID0gYXN5bmMgKG06IE1lbWJlciwgcm9sZTogUm9sZSkgPT4ge1xuICAgIHNldEVycihudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2V0U3BhY2VSb2xlKHNwYWNlLnNwYWNlSWQsIHVpZE9mKG0uZ3JhbnRlZSksIHJvbGUpO1xuICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycigoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGUgPT09IFwib3duZXItbG9ja291dFwiID8gXCJBIHNwYWNlIG11c3Qga2VlcCBhbiBvd25lci5cIiA6IFwiQ291bGRu4oCZdCBjaGFuZ2Ugcm9sZS5cIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IG9uUmVtb3ZlID0gYXN5bmMgKG06IE1lbWJlcikgPT4ge1xuICAgIHNldEVycihudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdW5zaGFyZVNwYWNlKHNwYWNlLnNwYWNlSWQsIHVpZE9mKG0uZ3JhbnRlZSkpO1xuICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycigoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGUgPT09IFwib3duZXItbG9ja291dFwiID8gXCJBIHNwYWNlIG11c3Qga2VlcCBhbiBvd25lci5cIiA6IFwiQ291bGRu4oCZdCByZW1vdmUuXCIpO1xuICAgIH1cbiAgfTtcblxuICAvLyBSMy0yNTkg4oCUIHRoZSBkZWxpYmVyYXRlIG9uZS13YXkgY29udmVyc2lvbi4gRmlyc3QgY2xpY2sgYXJtczsgdGhlIHNlY29uZCAodGhlXG4gIC8vIGJ1dHRvbiB0aGF0IG5vdyBzYXlzIHdoYXQgaXQgZG9lcykgcGVyZm9ybXMgaXQuIFRoZSB2ZXJiIHJpZGVzIHRoZVxuICAvLyBgcHJvdG9jb2xSZXF1ZXN0YCBzZWFtIGxpa2UgYGNvbm5lY3RTb3VyY2VgIGFib3ZlOiB0aGUgaG9zdCBnYXRlIGhvbGRzXG4gIC8vIGBzcGFjZXM6YWRtaW5gICsgdGhlIGNvbmZpcm0gbGl0ZXJhbCwgYW5kIHRoZSBob3N0IGNoZWNrcyBvd25lcnNoaXAuXG4gIGNvbnN0IG9uQ29udmVydCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWNvbnZlcnRBcm1lZCkge1xuICAgICAgc2V0Q29udmVydEFybWVkKHRydWUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRDb252ZXJ0aW5nKHRydWUpO1xuICAgIHNldEVycihudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcHJvdG9jb2xSZXF1ZXN0KFwicHJvdG9jb2wtc3BhY2VzXCIsIFwiY29udmVydFRvU2hhcmVkXCIsIFt7IHNwYWNlSWQ6IHNwYWNlLnNwYWNlSWQsIGNvbmZpcm06IHRydWUgfV0pO1xuICAgICAgc2V0Q29udmVydEFybWVkKGZhbHNlKTtcbiAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtyZWZyZXNoKCksIG9uU3BhY2VzQ2hhbmdlZD8uKCldKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgc2V0RXJyKGNvZGUgPT09IFwiZm9yYmlkZGVuXCIgPyBcIk9ubHkgdGhlIG93bmVyIGNhbiBjb252ZXJ0IHRoaXMgc3BhY2UuXCIgOiBcIkNvdWxkbuKAmXQgY29udmVydCB0aGUgc3BhY2UuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRDb252ZXJ0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNtLW92ZXJsYXlcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20tbW9kYWxcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0gcm9sZT1cImRpYWxvZ1wiIGFyaWEtbGFiZWw9XCJNYW5hZ2Ugc3BhY2VcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwic20teFwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJDbG9zZVwiPsOXPC9idXR0b24+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJzbS1tb2RhbC10aXRsZVwiPlNoYXJlIOKAnHtzcGFjZS5uYW1lID8/IFwiVW50aXRsZWQgc3BhY2VcIn3igJ08L2gyPlxuXG4gICAgICAgIHsvKiBSMy0yNTkg4oCUIHRoZSBuYW1lZCwgb25lLXdheSBjb252ZXJzaW9uLiBPZmZlcmVkIG9ubHkgd2hlcmUgaXQgaXMgcmVhbDpcbiAgICAgICAgICAgIHRoZSBvd25lcidzIHZpZXcgb2YgYSBzcGFjZSB3aG9zZSBkZXJpdmVkIGtpbmQgaXMgc3RpbGwgcGVyc29uYWwgKHRoZVxuICAgICAgICAgICAgaG9zdCdzIGRlcml2YXRpb24g4oCUIGEgbGF0Y2hlZCBzcGFjZSBuZXZlciBzaG93cyBpdCkuICovfVxuICAgICAgICB7c3BhY2Uucm9sZSA9PT0gXCJvd25lclwiICYmIGtpbmRPZihzcGFjZSkgPT09IFwicGVyc29uYWxcIiAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbS1jb252ZXJ0XCI+XG4gICAgICAgICAgICB7Y29udmVydEFybWVkID8gKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzbS1jb252ZXJ0LW5vdGVcIj5cbiAgICAgICAgICAgICAgICBDb252ZXJ0aW5nIDxzdHJvbmc+e3NwYWNlLm5hbWUgPz8gXCJ0aGlzIHNwYWNlXCJ9PC9zdHJvbmc+IHRvIHNoYXJlZCBjYW5ub3QgYmUgdW5kb25lLiBBcHBzIGFuZCBhZ2VudHNcbiAgICAgICAgICAgICAgICB3aWxsIHRyZWF0IGl0IG1vcmUgY2F1dGlvdXNseSwgYmVjYXVzZSBtb3JlIHRoYW4gb25lIHBlcnNvbiBjYW4gY2hhbmdlIHdoYXQgaXMgaW4gaXQuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNtLWNvbnZlcnQtbm90ZVwiPlxuICAgICAgICAgICAgICAgIFRoaXMgaXMgYSBwZXJzb25hbCBzcGFjZSDigJQgb25seSB5b3UgY2FuIGNoYW5nZSBpdC4gWW91IGNhbiBjb252ZXJ0IGl0IHRvIHNoYXJlZCBpZiBvdGhlcnMgd2lsbCB3b3JrIGluXG4gICAgICAgICAgICAgICAgaXQgdG9vLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjb252ZXJ0QXJtZWQgPyBcInNtLWNvbnZlcnQtY29uZmlybVwiIDogXCJzbS1jb252ZXJ0LWJ0blwifVxuICAgICAgICAgICAgICBkaXNhYmxlZD17Y29udmVydGluZ31cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBvbkNvbnZlcnQoKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2NvbnZlcnRpbmcgPyBcIkNvbnZlcnRpbmfigKZcIiA6IGNvbnZlcnRBcm1lZCA/IFwiQ29udmVydCB0byBzaGFyZWQg4oCUIGNhbm5vdCBiZSB1bmRvbmVcIiA6IFwiQ29udmVydCB0byBzaGFyZWTigKZcIn1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20taW52aXRlXCI+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzbS1pbnB1dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImhhbmRsZVwiXG4gICAgICAgICAgICB2YWx1ZT17aGFuZGxlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRIYW5kbGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09IFwiRW50ZXJcIiAmJiAhYnVzeSAmJiBvbkludml0ZSgpfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNtLXNlbGVjdFwiIHZhbHVlPXthZGRSb2xlfSBvbkNoYW5nZT17KGUpID0+IHNldEFkZFJvbGUoZS50YXJnZXQudmFsdWUgYXMgUm9sZSl9IGRpc2FibGVkPXtidXN5fT5cbiAgICAgICAgICAgIHtST0xFUy5tYXAoKHIpID0+IDxvcHRpb24ga2V5PXtyfSB2YWx1ZT17cn0+e3J9PC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJzbS1hZGRcIiBvbkNsaWNrPXtvbkludml0ZX0gZGlzYWJsZWQ9e2J1c3l9PlxuICAgICAgICAgICAge2J1c3kgPyBcIkludml0aW5n4oCmXCIgOiBcIkludml0ZVwifVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2VyciAmJiA8ZGl2IGNsYXNzTmFtZT1cInNtLWVyclwiPntlcnJ9PC9kaXY+fVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20tbWVtYmVyc1wiPlxuICAgICAgICAgIHttZW1iZXJzID09PSBudWxsID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbS1tc2dcIj5Mb2FkaW5nIG1lbWJlcnPigKY8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgbWVtYmVycy5tYXAoKG0pID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgbGFzdE93bmVyID0gbS5yb2xlID09PSBcIm93bmVyXCIgJiYgb3duZXJDb3VudCA8PSAxO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXttLmdyYW50ZWV9IGNsYXNzTmFtZT1cInNtLW1lbWJlclwiPlxuICAgICAgICAgICAgICAgICAge20uYXZhdGFyVXJsID8gPGltZyBjbGFzc05hbWU9XCJzbS1hdlwiIHNyYz17bS5hdmF0YXJVcmx9IGFsdD1cIlwiIC8+IDogPHNwYW4gY2xhc3NOYW1lPVwic20tYXYgc20tYXYtcGhcIiAvPn1cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLW1lbWJlci1uYW1lXCI+e2xhYmVsT2YobSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzbS1zZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bS5yb2xlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bGFzdE93bmVyfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17bGFzdE93bmVyID8gXCJBIHNwYWNlIG11c3Qga2VlcCBhbiBvd25lclwiIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uUm9sZShtLCBlLnRhcmdldC52YWx1ZSBhcyBSb2xlKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge1JPTEVTLm1hcCgocikgPT4gPG9wdGlvbiBrZXk9e3J9IHZhbHVlPXtyfT57cn08L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJzbS1yZW1vdmVcIiBkaXNhYmxlZD17bGFzdE93bmVyfSBvbkNsaWNrPXsoKSA9PiBvblJlbW92ZShtKX0+XG4gICAgICAgICAgICAgICAgICAgIFJlbW92ZVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtwZW5kaW5nLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic20tcGVuZGluZ1wiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInNtLXBlbmRpbmctaFwiPlBlbmRpbmcgaW52aXRlczwvaDM+XG4gICAgICAgICAgICB7cGVuZGluZy5tYXAoKGludikgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17aW52LnVpZH0gY2xhc3NOYW1lPVwic20tbWVtYmVyXCI+XG4gICAgICAgICAgICAgICAge2h0dHBzQXZhdGFyKGludi5hdmF0YXJVcmwpID8gKFxuICAgICAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9XCJzbS1hdlwiIHNyYz17aHR0cHNBdmF0YXIoaW52LmF2YXRhclVybCl9IGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLWF2IHNtLWF2LXBoXCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLW1lbWJlci1uYW1lXCI+e2ludi5sb2dpbiA/IGBAJHtpbnYubG9naW59YCA6IGAjJHtpbnYudWlkfWB9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNtLXJvbGVcIiBkYXRhLXJvbGU9e2ludi5yb2xlfT57aW52LnJvbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic20tcmVtb3ZlXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZXZva2luZyA9PT0gaW52LnVpZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUmV2b2tlSW52aXRlKGludil9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge3Jldm9raW5nID09PSBpbnYudWlkID8gXCLigKZcIiA6IFwiUmV2b2tlXCJ9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQU9BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQTJCQSxJQUFBRSxhQUFBLEdBQUFGLE9BQUE7QUFDQUEsT0FBQTtBQUE0QixJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUE7RUFBQUMsR0FBQSxHQUFBRCxZQUFBO0VBQUFFLEdBQUEsR0FBQUYsWUFBQTtFQUFBRyxHQUFBLEdBQUFILFlBQUE7RUFBQUksR0FBQSxHQUFBSixZQUFBO0VBQUFLLEdBQUEsR0FBQUwsWUFBQSxJQXBDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF5QkE7QUFDQTtBQUNBO0FBQ0E7QUFJQSxNQUFNTSxLQUFhLEdBQUcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsQ0FBQztBQUVuRCxNQUFNQyxLQUFLLEdBQUlDLFNBQWlCLElBQWFBLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7O0FBRTVFO0FBQ0EsTUFBTUMsU0FBUyxHQUFJQyxNQUFjLElBQWE7RUFDNUMsSUFBSTtJQUNGLE1BQU0sR0FBR0MsRUFBRSxFQUFFQyxJQUFJLENBQUMsR0FBR0YsTUFBTSxDQUFDRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUNDLEdBQUcsQ0FBQ0Msa0JBQWtCLENBQUM7SUFDL0QsT0FBT0osRUFBRSxJQUFJQyxJQUFJLEdBQUcsR0FBR0QsRUFBRSxJQUFJQyxJQUFJLEVBQUUsR0FBR0YsTUFBTTtFQUM5QyxDQUFDLENBQUMsTUFBTTtJQUNOLE9BQU9BLE1BQU07RUFDZjtBQUNGLENBQUM7QUFDRCxNQUFNTSxPQUFPLEdBQUlDLENBQVMsSUFBY0EsQ0FBQyxDQUFDQyxLQUFLLEdBQUcsSUFBSUQsQ0FBQyxDQUFDQyxLQUFLLEVBQUUsR0FBRyxJQUFJWixLQUFLLENBQUNXLENBQUMsQ0FBQ0UsT0FBTyxDQUFDLENBQUNOLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ08sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUlmLEtBQUssQ0FBQ1csQ0FBQyxDQUFDRSxPQUFPLENBQUMsRUFBRzs7QUFFM0k7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNRyxXQUFXLEdBQUlDLEdBQXVCLElBQXlCO0VBQ25FLElBQUksQ0FBQ0EsR0FBRyxFQUFFLE9BQU9DLFNBQVM7RUFDMUIsSUFBSTtJQUNGLE9BQU8sSUFBSUMsR0FBRyxDQUFDRixHQUFHLENBQUMsQ0FBQ0csUUFBUSxLQUFLLFFBQVEsR0FBR0gsR0FBRyxHQUFHQyxTQUFTO0VBQzdELENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBT0EsU0FBUztFQUNsQjtBQUNGLENBQUM7QUFFYyxTQUFTRyxZQUFZQSxDQUFBLEVBQUc7RUFBQTdCLEVBQUE7RUFDckMsTUFBTSxDQUFDOEIsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQXFCLElBQUksQ0FBQztFQUM5RCxNQUFNLENBQUNDLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDdkQsTUFBTSxDQUFDRyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBbUIsSUFBSSxDQUFDO0VBQ2hFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNSyxNQUFNLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUM7RUFDMUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBR0YsTUFBTSxLQUFLLGNBQWM7RUFFekMsTUFBTUcsVUFBVSxHQUFHLElBQUFDLGtCQUFXLEVBQUMsWUFBWTtJQUN6Q1AsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNkLElBQUk7TUFDRkgsU0FBUyxDQUFDLE1BQU0sSUFBQVcsa0JBQWEsRUFBQyxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9DLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSTtNQUMzQ1YsUUFBUSxDQUFDVSxJQUFJLEtBQUssZUFBZSxHQUFHLGdDQUFnQyxHQUFHLHVCQUF1QixDQUFDO01BQy9GYixTQUFTLENBQUMsRUFBRSxDQUFDO0lBQ2Y7RUFDRixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sSUFBQWMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTUMsR0FBRyxHQUFHLE1BQUFBLENBQUEsS0FBWTtNQUN0QixNQUFNTixVQUFVLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBQ0QsS0FBS00sR0FBRyxDQUFDLENBQUM7RUFDWixDQUFDLEVBQUUsQ0FBQ04sVUFBVSxDQUFDLENBQUM7O0VBRWhCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNTyxTQUFTLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDO0VBQ2hDLE1BQU1DLFlBQVksR0FBRyxJQUFBQyxhQUFNLEVBQUMsS0FBSyxDQUFDO0VBQ2xDLElBQUFMLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlJLFlBQVksQ0FBQ0UsT0FBTyxJQUFJLENBQUNaLE9BQU8sSUFBSSxDQUFDVCxNQUFNLEVBQUU7SUFDakQsSUFBSWlCLFNBQVMsRUFBRUssSUFBSSxLQUFLLFlBQVksRUFBRTtJQUN0QyxNQUFNQyxPQUFPLEdBQUdOLFNBQVMsQ0FBQ08sTUFBTSxFQUFFRCxPQUFPO0lBQ3pDLElBQUksT0FBT0EsT0FBTyxLQUFLLFFBQVEsRUFBRTtJQUNqQ0osWUFBWSxDQUFDRSxPQUFPLEdBQUcsSUFBSTtJQUMzQixNQUFNSSxNQUFNLEdBQUd6QixNQUFNLENBQUMwQixJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixPQUFPLEtBQUtBLE9BQU8sQ0FBQztJQUN4RDtJQUNBO0lBQ0EsSUFBSUUsTUFBTSxJQUFJQSxNQUFNLENBQUNHLElBQUksS0FBSyxPQUFPLEVBQUVDLGNBQWMsQ0FBQyxNQUFNdkIsV0FBVyxDQUFDbUIsTUFBTSxDQUFDLENBQUM7RUFDbEYsQ0FBQyxFQUFFLENBQUNoQixPQUFPLEVBQUVULE1BQU0sRUFBRWlCLFNBQVMsQ0FBQyxDQUFDO0VBRWhDLG9CQUNFLElBQUFoRCxXQUFBLENBQUE2RCxJQUFBO0lBQUtDLFNBQVMsRUFBRXRCLE9BQU8sR0FBRyxZQUFZLEdBQUcsSUFBSztJQUFBdUIsUUFBQSxnQkFDNUMsSUFBQS9ELFdBQUEsQ0FBQTZELElBQUE7TUFBUUMsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxnQkFDdkIsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQU0sQ0FBTSxDQUFDLEVBQ3ZDdkIsT0FBTyxpQkFDTixJQUFBeEMsV0FBQSxDQUFBNkQsSUFBQTtRQUFNQyxTQUFTLEVBQUMsV0FBVztRQUFBQyxRQUFBLGdCQUN6QixJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQSxFQUFDQyxrQkFBa0I7VUFBQ0MsV0FBVyxFQUFFekI7UUFBVyxDQUFFLENBQUMsZUFDL0MsSUFBQXpDLFdBQUEsQ0FBQWdFLEdBQUEsRUFBQ0csZ0JBQWdCO1VBQUNDLFNBQVMsRUFBRTNCO1FBQVcsQ0FBRSxDQUFDO01BQUEsQ0FDdkMsQ0FDUDtJQUFBLENBQ0ssQ0FBQyxFQUNSUCxLQUFLLGlCQUFJLElBQUFsQyxXQUFBLENBQUFnRSxHQUFBO01BQUtGLFNBQVMsRUFBQyxRQUFRO01BQUFDLFFBQUEsRUFBRTdCO0lBQUssQ0FBTSxDQUFDLGVBQy9DLElBQUFsQyxXQUFBLENBQUFnRSxHQUFBLEVBQUNLLGdCQUFnQjtNQUFDQyxVQUFVLEVBQUU3QjtJQUFXLENBQUUsQ0FBQyxFQUMzQ1YsTUFBTSxLQUFLLElBQUksZ0JBQ2QsSUFBQS9CLFdBQUEsQ0FBQWdFLEdBQUE7TUFBS0YsU0FBUyxFQUFDLFFBQVE7TUFBQUMsUUFBQSxFQUFDO0lBQVEsQ0FBSyxDQUFDLEdBQ3BDaEMsTUFBTSxDQUFDd0MsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDckMsS0FBSyxnQkFDL0IsSUFBQWxDLFdBQUEsQ0FBQWdFLEdBQUE7TUFBS0YsU0FBUyxFQUFDLFFBQVE7TUFBQUMsUUFBQSxFQUFDO0lBQTBDLENBQUssQ0FBQyxnQkFFeEUsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7TUFBSUYsU0FBUyxFQUFDLFNBQVM7TUFBQUMsUUFBQSxFQUNwQmhDLE1BQU0sQ0FBQ2QsR0FBRyxDQUFFeUMsQ0FBQyxpQkFDWixJQUFBMUQsV0FBQSxDQUFBNkQsSUFBQTtRQUFvQkMsU0FBUyxFQUFDLFFBQVE7UUFBQUMsUUFBQSxnQkFDcEMsSUFBQS9ELFdBQUEsQ0FBQTZELElBQUE7VUFBS0MsU0FBUyxFQUFDLGFBQWE7VUFBQUMsUUFBQSxnQkFDMUIsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7WUFBTUYsU0FBUyxFQUFDLFNBQVM7WUFBQUMsUUFBQSxFQUFFTCxDQUFDLENBQUNjLElBQUksSUFBSTtVQUFnQixDQUFPLENBQUMsRUFJNURDLE1BQU0sQ0FBQ2YsQ0FBQyxDQUFDLEtBQUssUUFBUSxpQkFDckIsSUFBQTFELFdBQUEsQ0FBQWdFLEdBQUE7WUFBTUYsU0FBUyxFQUFDLFNBQVM7WUFBQyxhQUFVLFFBQVE7WUFBQUMsUUFBQSxFQUFDO1VBRTdDLENBQU0sQ0FDUCxlQUNELElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1lBQU1GLFNBQVMsRUFBQyxTQUFTO1lBQUMsYUFBV0osQ0FBQyxDQUFDQyxJQUFLO1lBQUFJLFFBQUEsRUFBRUwsQ0FBQyxDQUFDQztVQUFJLENBQU8sQ0FBQztRQUFBLENBQ3pELENBQUMsRUFDTG5CLE9BQU8sSUFBSWtCLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLE9BQU8saUJBQzVCLElBQUEzRCxXQUFBLENBQUFnRSxHQUFBO1VBQVFVLElBQUksRUFBQyxRQUFRO1VBQUNaLFNBQVMsRUFBQyxXQUFXO1VBQUNhLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdEMsV0FBVyxDQUFDcUIsQ0FBQyxDQUFFO1VBQUFLLFFBQUEsRUFBQztRQUUzRSxDQUFRLENBQ1Q7TUFBQSxHQWpCTUwsQ0FBQyxDQUFDSixPQWtCUCxDQUNMO0lBQUMsQ0FDQSxDQUNMLEVBQ0FkLE9BQU8sSUFBSUosUUFBUSxpQkFDbEIsSUFBQXBDLFdBQUEsQ0FBQWdFLEdBQUEsRUFBQ1ksV0FBVztNQUFDQyxLQUFLLEVBQUV6QyxRQUFTO01BQUMwQyxPQUFPLEVBQUVBLENBQUEsS0FBTXpDLFdBQVcsQ0FBQyxJQUFJLENBQUU7TUFBQzBDLGVBQWUsRUFBRXRDO0lBQVcsQ0FBRSxDQUMvRixFQUNBRCxPQUFPLGlCQUFJLElBQUF4QyxXQUFBLENBQUFnRSxHQUFBLEVBQUNnQixTQUFTLElBQUUsQ0FBQztFQUFBLENBQ3RCLENBQUM7QUFFVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEvRSxFQUFBLENBbEh3QjZCLFlBQVk7RUFBQSxRQVNuQlMsY0FBUyxFQWtDTlUsaUJBQVk7QUFBQTtBQUFBZ0MsRUFBQSxHQTNDUm5ELFlBQVk7QUFtSHBDLFNBQVN1QyxnQkFBZ0JBLENBQUM7RUFBRUM7QUFBdUQsQ0FBQyxFQUFFO0VBQUFuRSxHQUFBO0VBQ3BGLE1BQU0rRSxPQUFPLEdBQUcsSUFBQUMsZUFBVSxFQUFDLENBQUM7RUFDNUIsTUFBTSxDQUFDQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFwRCxlQUFRLEVBQWdCLElBQUksQ0FBQztFQUVyRCxNQUFNcUQsUUFBUSxHQUFHLE1BQU9DLEdBQVcsSUFBSztJQUN0Q0YsT0FBTyxDQUFDRSxHQUFHLENBQUNqQyxPQUFPLENBQUM7SUFDcEIsSUFBSTtNQUNGLE1BQU0sSUFBQWtDLGlCQUFZLEVBQUNELEdBQUcsQ0FBQ2pDLE9BQU8sQ0FBQztNQUMvQjtNQUNBO01BQ0EsTUFBTWdCLFVBQVUsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsQ0FBQyxNQUFNO01BQ047SUFBQSxDQUNELFNBQVM7TUFDUmUsT0FBTyxDQUFDLElBQUksQ0FBQztJQUNmO0VBQ0YsQ0FBQztFQUVELE1BQU1JLFNBQVMsR0FBRyxNQUFPRixHQUFXLElBQUs7SUFDdkNGLE9BQU8sQ0FBQ0UsR0FBRyxDQUFDakMsT0FBTyxDQUFDO0lBQ3BCLElBQUk7TUFDRixNQUFNLElBQUFvQyxrQkFBYSxFQUFDSCxHQUFHLENBQUNqQyxPQUFPLENBQUM7TUFDaEM7SUFDRixDQUFDLENBQUMsTUFBTTtNQUNOO0lBQUEsQ0FDRCxTQUFTO01BQ1IrQixPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ2Y7RUFDRixDQUFDO0VBRUQsSUFBSUgsT0FBTyxDQUFDWCxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUVyQyxvQkFDRSxJQUFBdkUsV0FBQSxDQUFBNkQsSUFBQTtJQUFTQyxTQUFTLEVBQUMsWUFBWTtJQUFDLGNBQVcsYUFBYTtJQUFBQyxRQUFBLGdCQUN0RCxJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtNQUFJRixTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLEVBQUM7SUFBVyxDQUFJLENBQUMsZUFDN0MsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7TUFBSUYsU0FBUyxFQUFDLGdCQUFnQjtNQUFBQyxRQUFBLEVBQzNCbUIsT0FBTyxDQUFDakUsR0FBRyxDQUFFc0UsR0FBRyxJQUFLO1FBQ3BCLE1BQU1JLE1BQU0sR0FBR2xFLFdBQVcsQ0FBQzhELEdBQUcsQ0FBQ0ssU0FBUyxDQUFDO1FBQ3pDLG9CQUNFLElBQUE1RixXQUFBLENBQUE2RCxJQUFBO1VBQXNCQyxTQUFTLEVBQUMsZUFBZTtVQUFBQyxRQUFBLEdBQzVDNEIsTUFBTSxnQkFBRyxJQUFBM0YsV0FBQSxDQUFBZ0UsR0FBQTtZQUFLRixTQUFTLEVBQUMsT0FBTztZQUFDK0IsR0FBRyxFQUFFRixNQUFPO1lBQUNHLEdBQUcsRUFBQztVQUFFLENBQUUsQ0FBQyxnQkFBRyxJQUFBOUYsV0FBQSxDQUFBZ0UsR0FBQTtZQUFNRixTQUFTLEVBQUM7VUFBZ0IsQ0FBRSxDQUFDLGVBQzdGLElBQUE5RCxXQUFBLENBQUE2RCxJQUFBO1lBQU1DLFNBQVMsRUFBQyxnQkFBZ0I7WUFBQUMsUUFBQSxHQUM3QndCLEdBQUcsQ0FBQ1EsU0FBUyxFQUFDLGlCQUFlLEVBQUMsR0FBRyxlQUNsQyxJQUFBL0YsV0FBQSxDQUFBZ0UsR0FBQTtjQUFNRixTQUFTLEVBQUMsU0FBUztjQUFBQyxRQUFBLEVBQUV3QixHQUFHLENBQUNmLElBQUksSUFBSTtZQUFnQixDQUFPLENBQUMsUUFBSSxFQUFDZSxHQUFHLENBQUM1QixJQUFJO1VBQUEsQ0FDeEUsQ0FBQyxlQUNQLElBQUEzRCxXQUFBLENBQUFnRSxHQUFBO1lBQ0VVLElBQUksRUFBQyxRQUFRO1lBQ2JaLFNBQVMsRUFBQyxXQUFXO1lBQ3JCa0MsUUFBUSxFQUFFWixJQUFJLEtBQUtHLEdBQUcsQ0FBQ2pDLE9BQVE7WUFDL0JxQixPQUFPLEVBQUVBLENBQUEsS0FBTVcsUUFBUSxDQUFDQyxHQUFHLENBQUU7WUFBQXhCLFFBQUEsRUFFNUJxQixJQUFJLEtBQUtHLEdBQUcsQ0FBQ2pDLE9BQU8sR0FBRyxHQUFHLEdBQUc7VUFBUSxDQUNoQyxDQUFDLGVBQ1QsSUFBQXRELFdBQUEsQ0FBQWdFLEdBQUE7WUFDRVUsSUFBSSxFQUFDLFFBQVE7WUFDYlosU0FBUyxFQUFDLFdBQVc7WUFDckJrQyxRQUFRLEVBQUVaLElBQUksS0FBS0csR0FBRyxDQUFDakMsT0FBUTtZQUMvQnFCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNYyxTQUFTLENBQUNGLEdBQUcsQ0FBRTtZQUFBeEIsUUFBQSxFQUMvQjtVQUVELENBQVEsQ0FBQztRQUFBLEdBckJGd0IsR0FBRyxDQUFDakMsT0FzQlQsQ0FBQztNQUVULENBQUM7SUFBQyxDQUNBLENBQUM7RUFBQSxDQUNFLENBQUM7QUFFZDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQW5ELEdBQUEsQ0FoRlNrRSxnQkFBZ0I7RUFBQSxRQUNQYyxlQUFVO0FBQUE7QUFBQWMsR0FBQSxHQURuQjVCLGdCQUFnQjtBQW1GekIsU0FBU0YsZ0JBQWdCQSxDQUFDO0VBQUVDO0FBQXFELENBQUMsRUFBRTtFQUFBaEUsR0FBQTtFQUNsRixNQUFNO0lBQUU4RjtFQUFPLENBQUMsR0FBRyxJQUFBQyxZQUFPLEVBQUMsQ0FBQztFQUM1QixNQUFNLENBQUNmLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQXBELGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDdkMsTUFBTSxDQUFDbUUsR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBcEUsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDbkQsTUFBTSxDQUFDcUUsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBdEUsZUFBUSxFQUFhLFVBQVUsQ0FBQzs7RUFFeEQ7RUFDQSxJQUFJaUUsTUFBTSxLQUFLLFdBQVcsRUFBRSxPQUFPLElBQUk7RUFFdkMsTUFBTU0sUUFBUSxHQUFHLE1BQUFBLENBQUEsS0FBWTtJQUMzQm5CLE9BQU8sQ0FBQyxJQUFJLENBQUM7SUFDYmdCLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJO01BQ0Y7TUFDQTtNQUNBO01BQ0EsTUFBTSxJQUFBSSxnQkFBVyxFQUFDO1FBQUVIO01BQUssQ0FBaUQsQ0FBQztNQUMzRSxNQUFNbEMsU0FBUyxDQUFDLENBQUM7SUFDbkIsQ0FBQyxDQUFDLE9BQU94QixDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUk7TUFDM0M7TUFDQSxJQUFJQSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQzFCd0QsTUFBTSxDQUFDeEQsSUFBSSxLQUFLLGdCQUFnQixHQUFHLHNCQUFzQixHQUFHLDBCQUEwQixDQUFDO0lBQ3pGLENBQUMsU0FBUztNQUNSd0MsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUNoQjtFQUNGLENBQUM7RUFFRCxvQkFDRSxJQUFBckYsV0FBQSxDQUFBNkQsSUFBQSxFQUFBN0QsV0FBQSxDQUFBMEcsUUFBQTtJQUFBM0MsUUFBQSxnQkFDRSxJQUFBL0QsV0FBQSxDQUFBNkQsSUFBQTtNQUFLQyxTQUFTLEVBQUMsZ0JBQWdCO01BQUNILElBQUksRUFBQyxZQUFZO01BQUMsY0FBVyxZQUFZO01BQUFJLFFBQUEsZ0JBQ3ZFLElBQUEvRCxXQUFBLENBQUE2RCxJQUFBO1FBQUFFLFFBQUEsZ0JBQ0UsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7VUFDRVUsSUFBSSxFQUFDLE9BQU87VUFDWkYsSUFBSSxFQUFDLGdCQUFnQjtVQUNyQm1DLE9BQU8sRUFBRUwsSUFBSSxLQUFLLFVBQVc7VUFDN0JNLFFBQVEsRUFBRUEsQ0FBQSxLQUFNTCxPQUFPLENBQUMsVUFBVTtRQUFFLENBQ3JDLENBQUMsWUFFSjtNQUFBLENBQU8sQ0FBQyxlQUNSLElBQUF2RyxXQUFBLENBQUE2RCxJQUFBO1FBQUFFLFFBQUEsZ0JBQ0UsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7VUFDRVUsSUFBSSxFQUFDLE9BQU87VUFDWkYsSUFBSSxFQUFDLGdCQUFnQjtVQUNyQm1DLE9BQU8sRUFBRUwsSUFBSSxLQUFLLFFBQVM7VUFDM0JNLFFBQVEsRUFBRUEsQ0FBQSxLQUFNTCxPQUFPLENBQUMsUUFBUTtRQUFFLENBQ25DLENBQUMsVUFFSjtNQUFBLENBQU8sQ0FBQyxFQUNQRCxJQUFJLEtBQUssUUFBUSxpQkFDaEIsSUFBQXRHLFdBQUEsQ0FBQWdFLEdBQUE7UUFBTUYsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLEVBQUM7TUFBK0MsQ0FBTSxDQUN2RjtJQUFBLENBQ0UsQ0FBQyxlQUNOLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO01BQVFVLElBQUksRUFBQyxRQUFRO01BQUNaLFNBQVMsRUFBQyxRQUFRO01BQUNhLE9BQU8sRUFBRTZCLFFBQVM7TUFBQ1IsUUFBUSxFQUFFWixJQUFLO01BQUFyQixRQUFBLEVBQ3hFcUIsSUFBSSxHQUFHLFdBQVcsR0FBRztJQUFnQixDQUNoQyxDQUFDLEVBQ1JnQixHQUFHLGlCQUFJLElBQUFwRyxXQUFBLENBQUFnRSxHQUFBO01BQU1GLFNBQVMsRUFBQyxRQUFRO01BQUFDLFFBQUEsRUFBRXFDO0lBQUcsQ0FBTyxDQUFDO0VBQUEsQ0FDN0MsQ0FBQztBQUVQOztBQUVBO0FBQ0E7QUFBQWhHLEdBQUEsQ0E5RFMrRCxnQkFBZ0I7RUFBQSxRQUNKZ0MsWUFBTztBQUFBO0FBQUFVLEdBQUEsR0FEbkIxQyxnQkFBZ0I7QUErRHpCLE1BQU1NLE1BQU0sR0FBSWYsQ0FBWSxJQUE4QkEsQ0FBQyxDQUEyQjRDLElBQUk7O0FBRTFGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTckMsa0JBQWtCQSxDQUFDO0VBQUVDO0FBQXlELENBQUMsRUFBRTtFQUFBN0QsR0FBQTtFQUN4RixNQUFNO0lBQUU2RjtFQUFPLENBQUMsR0FBRyxJQUFBQyxZQUFPLEVBQUMsQ0FBQztFQUM1QixNQUFNLENBQUNmLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQXBELGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDdkMsTUFBTSxDQUFDbUUsR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBcEUsZUFBUSxFQUFnQixJQUFJLENBQUM7O0VBRW5EO0VBQ0EsSUFBSWlFLE1BQU0sS0FBSyxXQUFXLEVBQUUsT0FBTyxJQUFJO0VBRXZDLE1BQU1ZLFNBQVMsR0FBRyxNQUFBQSxDQUFBLEtBQVk7SUFDNUJ6QixPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ2JnQixNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSTtNQUNGLE1BQU0sSUFBQVUsNkJBQWUsRUFBQyxpQkFBaUIsRUFBRSxlQUFlLEVBQUUsQ0FBQztRQUFFQyxNQUFNLEVBQUU7TUFBUSxDQUFDLENBQUMsQ0FBQztNQUNoRixNQUFNOUMsV0FBVyxDQUFDLENBQUM7SUFDckIsQ0FBQyxDQUFDLE9BQU90QixDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUk7TUFDM0M7TUFDQSxJQUFJQSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQzFCd0QsTUFBTSxDQUNKeEQsSUFBSSxLQUFLLGVBQWUsR0FDcEIsOEJBQThCLEdBQzlCQSxJQUFJLEtBQUssb0JBQW9CLEdBQzNCLGtEQUFrRCxHQUNsREEsSUFBSSxLQUFLLHdCQUF3QixHQUMvQiw2REFBNkQsR0FDN0QsK0JBQ1YsQ0FBQztJQUNILENBQUMsU0FBUztNQUNSd0MsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUNoQjtFQUNGLENBQUM7RUFFRCxvQkFDRSxJQUFBckYsV0FBQSxDQUFBNkQsSUFBQSxFQUFBN0QsV0FBQSxDQUFBMEcsUUFBQTtJQUFBM0MsUUFBQSxnQkFDRSxJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtNQUFRVSxJQUFJLEVBQUMsUUFBUTtNQUFDWixTQUFTLEVBQUMsV0FBVztNQUFDYSxPQUFPLEVBQUVtQyxTQUFVO01BQUNkLFFBQVEsRUFBRVosSUFBSztNQUFBckIsUUFBQSxFQUM1RXFCLElBQUksR0FBRyxhQUFhLEdBQUc7SUFBc0IsQ0FDeEMsQ0FBQyxFQUNSZ0IsR0FBRyxpQkFBSSxJQUFBcEcsV0FBQSxDQUFBZ0UsR0FBQTtNQUFNRixTQUFTLEVBQUMsUUFBUTtNQUFBQyxRQUFBLEVBQUVxQztJQUFHLENBQU8sQ0FBQztFQUFBLENBQzdDLENBQUM7QUFFUDs7QUFFQTtBQUNBO0FBQUEvRixHQUFBLENBM0NTNEQsa0JBQWtCO0VBQUEsUUFDTmtDLFlBQU87QUFBQTtBQUFBYyxHQUFBLEdBRG5CaEQsa0JBQWtCO0FBNEMzQixTQUFTZSxTQUFTQSxDQUFBLEVBQUc7RUFBQTFFLEdBQUE7RUFDbkIsTUFBTSxDQUFDNEcsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBbEYsZUFBUSxFQUF1QixJQUFJLENBQUM7RUFDaEUsTUFBTSxDQUFDbUQsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBcEQsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFFckQsTUFBTW1GLElBQUksR0FBRyxJQUFBMUUsa0JBQVcsRUFBQyxZQUFZO0lBQ25DLElBQUk7TUFDRnlFLFNBQVMsQ0FBQyxNQUFNLElBQUFFLGVBQVUsRUFBQyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLE1BQU07TUFDTkYsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUNmO0VBQ0YsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLElBQUFyRSxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNQyxHQUFHLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO01BQ3RCLE1BQU1xRSxJQUFJLENBQUMsQ0FBQztJQUNkLENBQUM7SUFDRCxLQUFLckUsR0FBRyxDQUFDLENBQUM7RUFDWixDQUFDLEVBQUUsQ0FBQ3FFLElBQUksQ0FBQyxDQUFDO0VBRVYsTUFBTUUsUUFBUSxHQUFHLE1BQU9DLENBQWMsSUFBSztJQUN6QyxNQUFNQyxHQUFHLEdBQUdELENBQUMsQ0FBQzFHLE1BQU0sR0FBRzBHLENBQUMsQ0FBQ2pFLE9BQU87SUFDaEMrQixPQUFPLENBQUNtQyxHQUFHLENBQUM7SUFDWixJQUFJO01BQ0YsTUFBTSxJQUFBQyxnQkFBVyxFQUFDRixDQUFDLENBQUMxRyxNQUFNLEVBQUUwRyxDQUFDLENBQUNqRSxPQUFPLENBQUM7TUFDdEMsTUFBTThELElBQUksQ0FBQyxDQUFDO0lBQ2QsQ0FBQyxDQUFDLE1BQU07TUFDTjtJQUFBLENBQ0QsU0FBUztNQUNSL0IsT0FBTyxDQUFDLElBQUksQ0FBQztJQUNmO0VBQ0YsQ0FBQztFQUVELElBQUksQ0FBQzZCLE1BQU0sSUFBSUEsTUFBTSxDQUFDM0MsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLElBQUk7O0VBRS9DO0VBQ0EsTUFBTW1ELEtBQUssR0FBRyxJQUFJQyxHQUFHLENBQXdCLENBQUM7RUFDOUMsS0FBSyxNQUFNSixDQUFDLElBQUlMLE1BQU0sRUFBRVEsS0FBSyxDQUFDRSxHQUFHLENBQUNMLENBQUMsQ0FBQzFHLE1BQU0sRUFBRSxDQUFDLElBQUk2RyxLQUFLLENBQUNHLEdBQUcsQ0FBQ04sQ0FBQyxDQUFDMUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUwRyxDQUFDLENBQUMsQ0FBQztFQUVoRixvQkFDRSxJQUFBdkgsV0FBQSxDQUFBNkQsSUFBQTtJQUFTQyxTQUFTLEVBQUMsVUFBVTtJQUFBQyxRQUFBLGdCQUMzQixJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtNQUFJRixTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLEVBQUM7SUFBVSxDQUFJLENBQUMsRUFDekMsQ0FBQyxHQUFHMkQsS0FBSyxDQUFDSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM3RyxHQUFHLENBQUMsQ0FBQyxDQUFDSixNQUFNLEVBQUVrSCxJQUFJLENBQUMsa0JBQ3ZDLElBQUEvSCxXQUFBLENBQUE2RCxJQUFBO01BQWtCQyxTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLGdCQUN4QyxJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtRQUFLRixTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEVBQUVuRCxTQUFTLENBQUNDLE1BQU07TUFBQyxDQUFNLENBQUMsZUFDeEQsSUFBQWIsV0FBQSxDQUFBZ0UsR0FBQTtRQUFJRixTQUFTLEVBQUMsaUJBQWlCO1FBQUFDLFFBQUEsRUFDNUJnRSxJQUFJLENBQUM5RyxHQUFHLENBQUVzRyxDQUFDLGlCQUNWLElBQUF2SCxXQUFBLENBQUE2RCxJQUFBO1VBQW9CQyxTQUFTLEVBQUMsZ0JBQWdCO1VBQUFDLFFBQUEsZ0JBQzVDLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1lBQU1GLFNBQVMsRUFBQyxnQkFBZ0I7WUFBQUMsUUFBQSxFQUFFd0QsQ0FBQyxDQUFDL0MsSUFBSSxJQUFJK0MsQ0FBQyxDQUFDakUsT0FBTyxDQUFDL0IsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO1VBQUMsQ0FBTyxDQUFDLGVBQ3pFLElBQUF2QixXQUFBLENBQUE2RCxJQUFBO1lBQU1DLFNBQVMsRUFBQyxnQkFBZ0I7WUFBQUMsUUFBQSxHQUM3QndELENBQUMsQ0FBQ1MsSUFBSSxLQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsWUFBWSxFQUM1Q1QsQ0FBQyxDQUFDVSxPQUFPLEdBQUcsTUFBTVYsQ0FBQyxDQUFDVSxPQUFPLEVBQUUsR0FBRyxFQUFFO1VBQUEsQ0FDL0IsQ0FBQyxlQUNQLElBQUFqSSxXQUFBLENBQUFnRSxHQUFBO1lBQ0VVLElBQUksRUFBQyxRQUFRO1lBQ2JaLFNBQVMsRUFBQyxXQUFXO1lBQ3JCa0MsUUFBUSxFQUFFWixJQUFJLEtBQUttQyxDQUFDLENBQUMxRyxNQUFNLEdBQUcwRyxDQUFDLENBQUNqRSxPQUFRO1lBQ3hDcUIsT0FBTyxFQUFFQSxDQUFBLEtBQU0yQyxRQUFRLENBQUNDLENBQUMsQ0FBRTtZQUFBeEQsUUFBQSxFQUUxQnFCLElBQUksS0FBS21DLENBQUMsQ0FBQzFHLE1BQU0sR0FBRzBHLENBQUMsQ0FBQ2pFLE9BQU8sR0FBRyxHQUFHLEdBQUc7VUFBUSxDQUN6QyxDQUFDO1FBQUEsR0FiRmlFLENBQUMsQ0FBQ2pFLE9BY1AsQ0FDTDtNQUFDLENBQ0EsQ0FBQztJQUFBLEdBcEJHekMsTUFxQkwsQ0FDTixDQUFDO0VBQUEsQ0FDSyxDQUFDO0FBRWQ7QUFBQ1AsR0FBQSxDQW5FUTBFLFNBQVM7QUFBQWtELEdBQUEsR0FBVGxELFNBQVM7QUFxRWxCLFNBQVNKLFdBQVdBLENBQUM7RUFDbkJDLEtBQUs7RUFDTEMsT0FBTztFQUNQQztBQU1GLENBQUMsRUFBRTtFQUFBeEUsR0FBQTtFQUNELE1BQU0sQ0FBQzRILE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQW5HLGVBQVEsRUFBa0IsSUFBSSxDQUFDO0VBQzdELE1BQU0sQ0FBQ29HLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQXJHLGVBQVEsRUFBVyxFQUFFLENBQUM7RUFDcEQsTUFBTSxDQUFDc0csTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBdkcsZUFBUSxFQUFDLEVBQUUsQ0FBQztFQUN4QyxNQUFNLENBQUN3RyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUF6RyxlQUFRLEVBQU8sUUFBUSxDQUFDO0VBQ3RELE1BQU0sQ0FBQ21ELElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQXBELGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDdkMsTUFBTSxDQUFDMEcsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBM0csZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDN0QsTUFBTSxDQUFDbUUsR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBcEUsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDbkQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUM0RyxZQUFZLEVBQUVDLGVBQWUsQ0FBQyxHQUFHLElBQUE3RyxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ3ZELE1BQU0sQ0FBQzhHLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQS9HLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFFbkQsTUFBTWdILE9BQU8sR0FBRyxJQUFBdkcsa0JBQVcsRUFBQyxZQUFZO0lBQ3RDLElBQUk7TUFDRjtNQUNBO01BQ0E7TUFDQSxNQUFNLENBQUN0QixDQUFDLEVBQUU4SCxDQUFDLENBQUMsR0FBRyxNQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUMvQixJQUFBQyxvQkFBZSxFQUFDeEUsS0FBSyxDQUFDdkIsT0FBTyxDQUFDLEVBQzlCLElBQUFnRyx1QkFBa0IsRUFBQ3pFLEtBQUssQ0FBQ3ZCLE9BQU8sQ0FBQyxDQUFDaUcsS0FBSyxDQUFDLE1BQU0sRUFBYyxDQUFDLENBQzlELENBQUM7TUFDRm5CLFVBQVUsQ0FBQ2hILENBQUMsQ0FBQztNQUNia0gsVUFBVSxDQUFDWSxDQUFDLENBQUM7SUFDZixDQUFDLENBQUMsTUFBTTtNQUNON0MsTUFBTSxDQUFDLHdCQUF3QixDQUFDO0lBQ2xDO0VBQ0YsQ0FBQyxFQUFFLENBQUN4QixLQUFLLENBQUN2QixPQUFPLENBQUMsQ0FBQztFQUVuQixJQUFBUixnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNQyxHQUFHLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO01BQ3RCLE1BQU1rRyxPQUFPLENBQUMsQ0FBQztJQUNqQixDQUFDO0lBQ0QsS0FBS2xHLEdBQUcsQ0FBQyxDQUFDO0VBQ1osQ0FBQyxFQUFFLENBQUNrRyxPQUFPLENBQUMsQ0FBQztFQUViLE1BQU1PLFVBQVUsR0FBRyxDQUFDckIsT0FBTyxJQUFJLEVBQUUsRUFBRXNCLE1BQU0sQ0FBRXJJLENBQUMsSUFBS0EsQ0FBQyxDQUFDdUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDWSxNQUFNO0VBRTNFLE1BQU1tRixRQUFRLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO0lBQzNCLE1BQU1DLENBQUMsR0FBR3BCLE1BQU0sQ0FBQ3FCLElBQUksQ0FBQyxDQUFDLENBQUNqSixPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztJQUN6QyxJQUFJLENBQUNnSixDQUFDLEVBQUU7SUFDUnRFLE9BQU8sQ0FBQyxJQUFJLENBQUM7SUFDYmdCLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJO01BQ0Y7TUFDQTtNQUNBLE1BQU0sSUFBQXdELGtCQUFhLEVBQUNoRixLQUFLLENBQUN2QixPQUFPLEVBQUVxRyxDQUFDLEVBQUVsQixPQUFPLENBQUM7TUFDOUNELFNBQVMsQ0FBQyxFQUFFLENBQUM7TUFDYixNQUFNUyxPQUFPLENBQUMsQ0FBQztJQUNqQixDQUFDLENBQUMsT0FBT3JHLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSTtNQUMzQ3dELE1BQU0sQ0FDSnhELElBQUksS0FBSyxXQUFXLEdBQ2hCLGFBQWE4RyxDQUFDLElBQUksR0FDbEI5RyxJQUFJLEtBQUssV0FBVyxHQUNsQixjQUFjLEdBQ2RBLElBQUksS0FBSyxnQkFBZ0IsR0FDdkIsMkJBQTJCLEdBQzNCLGtCQUNWLENBQUM7SUFDSCxDQUFDLFNBQVM7TUFDUndDLE9BQU8sQ0FBQyxLQUFLLENBQUM7SUFDaEI7RUFDRixDQUFDO0VBRUQsTUFBTXlFLGNBQWMsR0FBRyxNQUFPdkUsR0FBVyxJQUFLO0lBQzVDcUQsV0FBVyxDQUFDckQsR0FBRyxDQUFDd0UsR0FBRyxDQUFDO0lBQ3BCMUQsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUk7TUFDRixNQUFNLElBQUEyRCxpQkFBWSxFQUFDbkYsS0FBSyxDQUFDdkIsT0FBTyxFQUFFaUMsR0FBRyxDQUFDd0UsR0FBRyxDQUFDO01BQzFDLE1BQU1kLE9BQU8sQ0FBQyxDQUFDO0lBQ2pCLENBQUMsQ0FBQyxNQUFNO01BQ041QyxNQUFNLENBQUMsNkJBQTZCLENBQUM7SUFDdkMsQ0FBQyxTQUFTO01BQ1J1QyxXQUFXLENBQUMsSUFBSSxDQUFDO0lBQ25CO0VBQ0YsQ0FBQztFQUVELE1BQU1xQixNQUFNLEdBQUcsTUFBQUEsQ0FBTzdJLENBQVMsRUFBRXVDLElBQVUsS0FBSztJQUM5QzBDLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJO01BQ0YsTUFBTSxJQUFBNkQsaUJBQVksRUFBQ3JGLEtBQUssQ0FBQ3ZCLE9BQU8sRUFBRTdDLEtBQUssQ0FBQ1csQ0FBQyxDQUFDRSxPQUFPLENBQUMsRUFBRXFDLElBQUksQ0FBQztNQUN6RCxNQUFNc0YsT0FBTyxDQUFDLENBQUM7SUFDakIsQ0FBQyxDQUFDLE9BQU9yRyxDQUFDLEVBQUU7TUFDVnlELE1BQU0sQ0FBRXpELENBQUMsRUFBd0JDLElBQUksS0FBSyxlQUFlLEdBQUcsNkJBQTZCLEdBQUcsdUJBQXVCLENBQUM7SUFDdEg7RUFDRixDQUFDO0VBRUQsTUFBTXNILFFBQVEsR0FBRyxNQUFPL0ksQ0FBUyxJQUFLO0lBQ3BDaUYsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUk7TUFDRixNQUFNLElBQUErRCxpQkFBWSxFQUFDdkYsS0FBSyxDQUFDdkIsT0FBTyxFQUFFN0MsS0FBSyxDQUFDVyxDQUFDLENBQUNFLE9BQU8sQ0FBQyxDQUFDO01BQ25ELE1BQU0ySCxPQUFPLENBQUMsQ0FBQztJQUNqQixDQUFDLENBQUMsT0FBT3JHLENBQUMsRUFBRTtNQUNWeUQsTUFBTSxDQUFFekQsQ0FBQyxFQUF3QkMsSUFBSSxLQUFLLGVBQWUsR0FBRyw2QkFBNkIsR0FBRyxrQkFBa0IsQ0FBQztJQUNqSDtFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNd0gsU0FBUyxHQUFHLE1BQUFBLENBQUEsS0FBWTtJQUM1QixJQUFJLENBQUN4QixZQUFZLEVBQUU7TUFDakJDLGVBQWUsQ0FBQyxJQUFJLENBQUM7TUFDckI7SUFDRjtJQUNBRSxhQUFhLENBQUMsSUFBSSxDQUFDO0lBQ25CM0MsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUk7TUFDRixNQUFNLElBQUFVLDZCQUFlLEVBQUMsaUJBQWlCLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQztRQUFFekQsT0FBTyxFQUFFdUIsS0FBSyxDQUFDdkIsT0FBTztRQUFFZ0gsT0FBTyxFQUFFO01BQUssQ0FBQyxDQUFDLENBQUM7TUFDeEd4QixlQUFlLENBQUMsS0FBSyxDQUFDO01BQ3RCLE1BQU1LLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUNILE9BQU8sQ0FBQyxDQUFDLEVBQUVsRSxlQUFlLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDckQsQ0FBQyxDQUFDLE9BQU9uQyxDQUFDLEVBQUU7TUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUk7TUFDM0N3RCxNQUFNLENBQUN4RCxJQUFJLEtBQUssV0FBVyxHQUFHLHdDQUF3QyxHQUFHLDZCQUE2QixDQUFDO0lBQ3pHLENBQUMsU0FBUztNQUNSbUcsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUN0QjtFQUNGLENBQUM7RUFFRCxvQkFDRSxJQUFBaEosV0FBQSxDQUFBZ0UsR0FBQTtJQUFLRixTQUFTLEVBQUMsWUFBWTtJQUFDYSxPQUFPLEVBQUVHLE9BQVE7SUFBQWYsUUFBQSxlQUMzQyxJQUFBL0QsV0FBQSxDQUFBNkQsSUFBQTtNQUFLQyxTQUFTLEVBQUMsVUFBVTtNQUFDYSxPQUFPLEVBQUcvQixDQUFDLElBQUtBLENBQUMsQ0FBQzJILGVBQWUsQ0FBQyxDQUFFO01BQUM1RyxJQUFJLEVBQUMsUUFBUTtNQUFDLGNBQVcsY0FBYztNQUFBSSxRQUFBLGdCQUNwRyxJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtRQUFRVSxJQUFJLEVBQUMsUUFBUTtRQUFDWixTQUFTLEVBQUMsTUFBTTtRQUFDYSxPQUFPLEVBQUVHLE9BQVE7UUFBQyxjQUFXLE9BQU87UUFBQWYsUUFBQSxFQUFDO01BQUMsQ0FBUSxDQUFDLGVBQ3RGLElBQUEvRCxXQUFBLENBQUE2RCxJQUFBO1FBQUlDLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUMsUUFBQSxHQUFDLGNBQU8sRUFBQ2MsS0FBSyxDQUFDTCxJQUFJLElBQUksZ0JBQWdCLEVBQUMsUUFBQztNQUFBLENBQUksQ0FBQyxFQUszRUssS0FBSyxDQUFDbEIsSUFBSSxLQUFLLE9BQU8sSUFBSWMsTUFBTSxDQUFDSSxLQUFLLENBQUMsS0FBSyxVQUFVLGlCQUNyRCxJQUFBN0UsV0FBQSxDQUFBNkQsSUFBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLEdBQ3hCOEUsWUFBWSxnQkFDWCxJQUFBN0ksV0FBQSxDQUFBNkQsSUFBQTtVQUFHQyxTQUFTLEVBQUMsaUJBQWlCO1VBQUFDLFFBQUEsR0FBQyxhQUNsQixtQkFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7WUFBQUQsUUFBQSxFQUFTYyxLQUFLLENBQUNMLElBQUksSUFBSTtVQUFZLENBQVMsQ0FBQyxzSUFFMUQ7UUFBQSxDQUFHLENBQUMsZ0JBRUosSUFBQXhFLFdBQUEsQ0FBQWdFLEdBQUE7VUFBR0YsU0FBUyxFQUFDLGlCQUFpQjtVQUFBQyxRQUFBLEVBQUM7UUFHL0IsQ0FBRyxDQUNKLGVBQ0QsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7VUFDRVUsSUFBSSxFQUFDLFFBQVE7VUFDYlosU0FBUyxFQUFFK0UsWUFBWSxHQUFHLG9CQUFvQixHQUFHLGdCQUFpQjtVQUNsRTdDLFFBQVEsRUFBRStDLFVBQVc7VUFDckJwRSxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLMEYsU0FBUyxDQUFDLENBQUU7VUFBQXRHLFFBQUEsRUFFL0JnRixVQUFVLEdBQUcsYUFBYSxHQUFHRixZQUFZLEdBQUcsc0NBQXNDLEdBQUc7UUFBb0IsQ0FDcEcsQ0FBQztNQUFBLENBQ04sQ0FDTixlQUVELElBQUE3SSxXQUFBLENBQUE2RCxJQUFBO1FBQUtDLFNBQVMsRUFBQyxXQUFXO1FBQUFDLFFBQUEsZ0JBQ3hCLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1VBQ0VGLFNBQVMsRUFBQyxVQUFVO1VBQ3BCMEcsV0FBVyxFQUFDLFFBQVE7VUFDcEJDLEtBQUssRUFBRWxDLE1BQU87VUFDZDNCLFFBQVEsRUFBR2hFLENBQUMsSUFBSzRGLFNBQVMsQ0FBQzVGLENBQUMsQ0FBQ1ksTUFBTSxDQUFDaUgsS0FBSyxDQUFFO1VBQzNDQyxTQUFTLEVBQUc5SCxDQUFDLElBQUtBLENBQUMsQ0FBQzRFLEdBQUcsS0FBSyxPQUFPLElBQUksQ0FBQ3BDLElBQUksSUFBSXNFLFFBQVEsQ0FBQyxDQUFFO1VBQzNEMUQsUUFBUSxFQUFFWjtRQUFLLENBQ2hCLENBQUMsZUFDRixJQUFBcEYsV0FBQSxDQUFBZ0UsR0FBQTtVQUFRRixTQUFTLEVBQUMsV0FBVztVQUFDMkcsS0FBSyxFQUFFaEMsT0FBUTtVQUFDN0IsUUFBUSxFQUFHaEUsQ0FBQyxJQUFLOEYsVUFBVSxDQUFDOUYsQ0FBQyxDQUFDWSxNQUFNLENBQUNpSCxLQUFhLENBQUU7VUFBQ3pFLFFBQVEsRUFBRVosSUFBSztVQUFBckIsUUFBQSxFQUMvR3ZELEtBQUssQ0FBQ1MsR0FBRyxDQUFFMEosQ0FBQyxpQkFBSyxJQUFBM0ssV0FBQSxDQUFBZ0UsR0FBQTtZQUFnQnlHLEtBQUssRUFBRUUsQ0FBRTtZQUFBNUcsUUFBQSxFQUFFNEc7VUFBQyxHQUFmQSxDQUF3QixDQUFDO1FBQUMsQ0FDbkQsQ0FBQyxlQUNULElBQUEzSyxXQUFBLENBQUFnRSxHQUFBO1VBQVFVLElBQUksRUFBQyxRQUFRO1VBQUNaLFNBQVMsRUFBQyxRQUFRO1VBQUNhLE9BQU8sRUFBRStFLFFBQVM7VUFBQzFELFFBQVEsRUFBRVosSUFBSztVQUFBckIsUUFBQSxFQUN4RXFCLElBQUksR0FBRyxXQUFXLEdBQUc7UUFBUSxDQUN4QixDQUFDO01BQUEsQ0FDTixDQUFDLEVBQ0xnQixHQUFHLGlCQUFJLElBQUFwRyxXQUFBLENBQUFnRSxHQUFBO1FBQUtGLFNBQVMsRUFBQyxRQUFRO1FBQUFDLFFBQUEsRUFBRXFDO01BQUcsQ0FBTSxDQUFDLGVBRTNDLElBQUFwRyxXQUFBLENBQUFnRSxHQUFBO1FBQUtGLFNBQVMsRUFBQyxZQUFZO1FBQUFDLFFBQUEsRUFDeEJvRSxPQUFPLEtBQUssSUFBSSxnQkFDZixJQUFBbkksV0FBQSxDQUFBZ0UsR0FBQTtVQUFLRixTQUFTLEVBQUMsUUFBUTtVQUFBQyxRQUFBLEVBQUM7UUFBZ0IsQ0FBSyxDQUFDLEdBRTlDb0UsT0FBTyxDQUFDbEgsR0FBRyxDQUFFRyxDQUFDLElBQUs7VUFDakIsTUFBTXdKLFNBQVMsR0FBR3hKLENBQUMsQ0FBQ3VDLElBQUksS0FBSyxPQUFPLElBQUk2RixVQUFVLElBQUksQ0FBQztVQUN2RCxvQkFDRSxJQUFBeEosV0FBQSxDQUFBNkQsSUFBQTtZQUFxQkMsU0FBUyxFQUFDLFdBQVc7WUFBQUMsUUFBQSxHQUN2QzNDLENBQUMsQ0FBQ3dFLFNBQVMsZ0JBQUcsSUFBQTVGLFdBQUEsQ0FBQWdFLEdBQUE7Y0FBS0YsU0FBUyxFQUFDLE9BQU87Y0FBQytCLEdBQUcsRUFBRXpFLENBQUMsQ0FBQ3dFLFNBQVU7Y0FBQ0UsR0FBRyxFQUFDO1lBQUUsQ0FBRSxDQUFDLGdCQUFHLElBQUE5RixXQUFBLENBQUFnRSxHQUFBO2NBQU1GLFNBQVMsRUFBQztZQUFnQixDQUFFLENBQUMsZUFDdkcsSUFBQTlELFdBQUEsQ0FBQWdFLEdBQUE7Y0FBTUYsU0FBUyxFQUFDLGdCQUFnQjtjQUFBQyxRQUFBLEVBQUU1QyxPQUFPLENBQUNDLENBQUM7WUFBQyxDQUFPLENBQUMsZUFDcEQsSUFBQXBCLFdBQUEsQ0FBQWdFLEdBQUE7Y0FDRUYsU0FBUyxFQUFDLFdBQVc7Y0FDckIyRyxLQUFLLEVBQUVySixDQUFDLENBQUN1QyxJQUFLO2NBQ2RxQyxRQUFRLEVBQUU0RSxTQUFVO2NBQ3BCQyxLQUFLLEVBQUVELFNBQVMsR0FBRyw0QkFBNEIsR0FBR2pKLFNBQVU7Y0FDNURpRixRQUFRLEVBQUdoRSxDQUFDLElBQUtxSCxNQUFNLENBQUM3SSxDQUFDLEVBQUV3QixDQUFDLENBQUNZLE1BQU0sQ0FBQ2lILEtBQWEsQ0FBRTtjQUFBMUcsUUFBQSxFQUVsRHZELEtBQUssQ0FBQ1MsR0FBRyxDQUFFMEosQ0FBQyxpQkFBSyxJQUFBM0ssV0FBQSxDQUFBZ0UsR0FBQTtnQkFBZ0J5RyxLQUFLLEVBQUVFLENBQUU7Z0JBQUE1RyxRQUFBLEVBQUU0RztjQUFDLEdBQWZBLENBQXdCLENBQUM7WUFBQyxDQUNuRCxDQUFDLGVBQ1QsSUFBQTNLLFdBQUEsQ0FBQWdFLEdBQUE7Y0FBUVUsSUFBSSxFQUFDLFFBQVE7Y0FBQ1osU0FBUyxFQUFDLFdBQVc7Y0FBQ2tDLFFBQVEsRUFBRTRFLFNBQVU7Y0FBQ2pHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNd0YsUUFBUSxDQUFDL0ksQ0FBQyxDQUFFO2NBQUEyQyxRQUFBLEVBQUM7WUFFN0YsQ0FBUSxDQUFDO1VBQUEsR0FkRDNDLENBQUMsQ0FBQ0UsT0FlUCxDQUFDO1FBRVYsQ0FBQztNQUNGLENBQ0UsQ0FBQyxFQUVMK0csT0FBTyxDQUFDOUQsTUFBTSxHQUFHLENBQUMsaUJBQ2pCLElBQUF2RSxXQUFBLENBQUE2RCxJQUFBO1FBQUtDLFNBQVMsRUFBQyxZQUFZO1FBQUFDLFFBQUEsZ0JBQ3pCLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1VBQUlGLFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsRUFBQztRQUFlLENBQUksQ0FBQyxFQUNoRHNFLE9BQU8sQ0FBQ3BILEdBQUcsQ0FBRXNFLEdBQUcsaUJBQ2YsSUFBQXZGLFdBQUEsQ0FBQTZELElBQUE7VUFBbUJDLFNBQVMsRUFBQyxXQUFXO1VBQUFDLFFBQUEsR0FDckN0QyxXQUFXLENBQUM4RCxHQUFHLENBQUNLLFNBQVMsQ0FBQyxnQkFDekIsSUFBQTVGLFdBQUEsQ0FBQWdFLEdBQUE7WUFBS0YsU0FBUyxFQUFDLE9BQU87WUFBQytCLEdBQUcsRUFBRXBFLFdBQVcsQ0FBQzhELEdBQUcsQ0FBQ0ssU0FBUyxDQUFFO1lBQUNFLEdBQUcsRUFBQztVQUFFLENBQUUsQ0FBQyxnQkFFakUsSUFBQTlGLFdBQUEsQ0FBQWdFLEdBQUE7WUFBTUYsU0FBUyxFQUFDO1VBQWdCLENBQUUsQ0FDbkMsZUFDRCxJQUFBOUQsV0FBQSxDQUFBZ0UsR0FBQTtZQUFNRixTQUFTLEVBQUMsZ0JBQWdCO1lBQUFDLFFBQUEsRUFBRXdCLEdBQUcsQ0FBQ2xFLEtBQUssR0FBRyxJQUFJa0UsR0FBRyxDQUFDbEUsS0FBSyxFQUFFLEdBQUcsSUFBSWtFLEdBQUcsQ0FBQ3dFLEdBQUc7VUFBRSxDQUFPLENBQUMsZUFDckYsSUFBQS9KLFdBQUEsQ0FBQWdFLEdBQUE7WUFBTUYsU0FBUyxFQUFDLFNBQVM7WUFBQyxhQUFXeUIsR0FBRyxDQUFDNUIsSUFBSztZQUFBSSxRQUFBLEVBQUV3QixHQUFHLENBQUM1QjtVQUFJLENBQU8sQ0FBQyxlQUNoRSxJQUFBM0QsV0FBQSxDQUFBZ0UsR0FBQTtZQUNFVSxJQUFJLEVBQUMsUUFBUTtZQUNiWixTQUFTLEVBQUMsV0FBVztZQUNyQmtDLFFBQVEsRUFBRTJDLFFBQVEsS0FBS3BELEdBQUcsQ0FBQ3dFLEdBQUk7WUFDL0JwRixPQUFPLEVBQUVBLENBQUEsS0FBTW1GLGNBQWMsQ0FBQ3ZFLEdBQUcsQ0FBRTtZQUFBeEIsUUFBQSxFQUVsQzRFLFFBQVEsS0FBS3BELEdBQUcsQ0FBQ3dFLEdBQUcsR0FBRyxHQUFHLEdBQUc7VUFBUSxDQUNoQyxDQUFDO1FBQUEsR0FmRHhFLEdBQUcsQ0FBQ3dFLEdBZ0JULENBQ04sQ0FBQztNQUFBLENBQ0MsQ0FDTjtJQUFBLENBQ0U7RUFBQyxDQUNILENBQUM7QUFFVjtBQUFDeEosR0FBQSxDQTlPUXFFLFdBQVc7QUFBQWtHLEdBQUEsR0FBWGxHLFdBQVc7QUFBQSxJQUFBSyxFQUFBLEVBQUFnQixHQUFBLEVBQUFZLEdBQUEsRUFBQUksR0FBQSxFQUFBaUIsR0FBQSxFQUFBNEMsR0FBQTtBQUFBQyxZQUFBLENBQUE5RixFQUFBO0FBQUE4RixZQUFBLENBQUE5RSxHQUFBO0FBQUE4RSxZQUFBLENBQUFsRSxHQUFBO0FBQUFrRSxZQUFBLENBQUE5RCxHQUFBO0FBQUE4RCxZQUFBLENBQUE3QyxHQUFBO0FBQUE2QyxZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}