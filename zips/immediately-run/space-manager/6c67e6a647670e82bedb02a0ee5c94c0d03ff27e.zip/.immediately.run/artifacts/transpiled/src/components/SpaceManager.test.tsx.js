var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _SpaceManager = _interopRequireDefault(require("./SpaceManager.css?raw"));
var _SpaceManager2 = _interopRequireDefault(require("./SpaceManager"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// R3-91 (FILE_SHARING §6.4/§9.7/§9.8) — the space-manager Invitations UI. Driven
// against a mocked SDK: inviting creates a PENDING offer (not a member); the invitee
// inbox Accepts/Declines; the owner Revokes a pending invite; owner-written strings
// render inert.

// The REAL shipped stylesheet, as text, so the R3-256 layout test asserts against
// what ships rather than a copy of the rules. `vitest.config.ts` sets `css: true`;
// without it this import is an empty string and that test passes vacuously.

// --- controllable SDK doubles ------------------------------------------------
const listAllSpaces = _vitest.vi.fn();
const getSpaceMembers = _vitest.vi.fn();
const listPendingInvites = _vitest.vi.fn();
const inviteToSpace = _vitest.vi.fn();
const acceptInvite = _vitest.vi.fn();
const declineInvite = _vitest.vi.fn();
const revokeInvite = _vitest.vi.fn();
// R3-259 — the create verb's params are under test (the create-time kind).
const createSpaceMock = _vitest.vi.fn();

// A controllable `useInvites()` live channel: the host pushes the inbox and the hook
// re-renders. `setInvites(list)` simulates a host push (an invite arriving/leaving).
const inviteState = _vitest.vi.hoisted(() => ({
  current: [],
  listeners: new Set()
}));

// A controllable `useRegion()`: admin verbs only render on the non-panel (full-tab)
// surface (R3-96 / PRINCIPALS §9 B3). Default to `page.spaces` so the admin-flow tests
// below exercise the Manage modal; the R3-96 test overrides it to `panel.spaces`.
const regionState = _vitest.vi.hoisted(() => ({
  current: "page.spaces"
}));

// A controllable `useTaskInput()`: the R3-269 `open-space` boot hint
// (/spaces?space=<id> → auto-open the Manage modal at that space). Default null.
const taskInputState = _vitest.vi.hoisted(() => ({
  current: null
}));

// R3-206 — the wire call behind "Connect Google Drive". Mocked at the SUBPATH the
// component imports from: the real `sandboxUtils.js` reaches a host runtime that does
// not exist under vitest (and ships extensionless specifiers vitest cannot resolve).
const protocolRequest = _vitest.vi.fn();
_vitest.vi.mock("@immediately-run/sdk/sandboxUtils", () => ({
  protocolRequest: (...a) => protocolRequest(...a)
}));
_vitest.vi.mock("@immediately-run/sdk", () => {
  var _s = $RefreshSig$();
  return {
    listAllSpaces: () => listAllSpaces(),
    getSpaceMembers: () => getSpaceMembers(),
    listPendingInvites: () => listPendingInvites(),
    useInvites: _s(() => {
      _s();
      const [, force] = React.useReducer(x => x + 1, 0);
      React.useEffect(() => {
        inviteState.listeners.add(force);
        return () => {
          inviteState.listeners.delete(force);
        };
      }, []);
      return inviteState.current;
    }, "zgF3pR5uiDbwGwax6iyVLT/Tpzs="),
    inviteToSpace: (...a) => inviteToSpace(...a),
    acceptInvite: (...a) => acceptInvite(...a),
    declineInvite: (...a) => declineInvite(...a),
    revokeInvite: (...a) => revokeInvite(...a),
    unshareSpace: _vitest.vi.fn(),
    setSpaceRole: _vitest.vi.fn(),
    listGrants: _vitest.vi.fn(async () => []),
    revokeGrant: _vitest.vi.fn(),
    createSpace: (...a) => createSpaceMock(...a),
    useAuth: () => ({
      status: "signed-in"
    }),
    useRegion: () => regionState.current,
    useTaskInput: () => taskInputState.current
  };
});
const ownedSpace = {
  spaceId: "s1",
  name: "My space",
  role: "owner"
};

/** Simulate a host push on the live invitations channel. */
const pushInvites = list => (0, _react2.act)(() => {
  inviteState.current = list;
  inviteState.listeners.forEach(l => l());
});
(0, _vitest.beforeEach)(() => {
  for (const m of [listAllSpaces, getSpaceMembers, listPendingInvites, inviteToSpace, acceptInvite, declineInvite, revokeInvite]) m.mockReset();
  inviteState.current = [];
  regionState.current = "page.spaces"; // full-tab by default; the R3-96 test sets panel.spaces
  taskInputState.current = null;
  // sensible empty defaults; individual tests override.
  listAllSpaces.mockResolvedValue([]);
  getSpaceMembers.mockResolvedValue([]);
  listPendingInvites.mockResolvedValue([]);
  inviteToSpace.mockResolvedValue(undefined);
  acceptInvite.mockResolvedValue(undefined);
  declineInvite.mockResolvedValue(undefined);
  revokeInvite.mockResolvedValue(undefined);
});
(0, _vitest.describe)("SpaceManager — invitations (R3-91)", () => {
  (0, _vitest.it)("inviting calls inviteToSpace and the offer lands under Pending, not Members", async () => {
    const user = _userEvent.default.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);
    // First manage-open load: no members, no pending. After invite: one pending.
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites.mockResolvedValueOnce([]).mockResolvedValue([{
      spaceId: "s1",
      uid: "uid-of-bob",
      role: "writer",
      owner: "u-me",
      invitedBy: "u-me",
      login: "bob"
    }]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await user.click(await _react2.screen.findByText("Manage"));
    const dialog = await _react2.screen.findByRole("dialog");
    await (0, _react2.within)(dialog).findByText(/No members|Loading members/i).catch(() => {});
    await user.type((0, _react2.within)(dialog).getByPlaceholderText("handle"), "bob");
    await user.click((0, _react2.within)(dialog).getByRole("button", {
      name: "Invite"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(inviteToSpace).toHaveBeenCalledWith("s1", "bob", "writer"));
    // The offer appears under Pending invites — and is NOT a member row.
    await (0, _react2.within)(dialog).findByText("Pending invites");
    (0, _vitest.expect)((0, _react2.within)(dialog).getByText("@bob")).toBeInTheDocument();
  });
  (0, _vitest.it)("the inbox renders a live invite; Accept calls acceptInvite, then the row is gone (live) and the space appears", async () => {
    const user = _userEvent.default.setup();
    // After accept, the host pushes the emptied inbox (simulated in the mock) and the
    // spaces list gains the accepted space.
    acceptInvite.mockImplementation(async () => {
      inviteState.current = [];
      inviteState.listeners.forEach(l => l());
    });
    listAllSpaces.mockResolvedValueOnce([]).mockResolvedValue([{
      spaceId: "s9",
      name: "Shared docs",
      role: "reader"
    }]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await pushInvites([{
      spaceId: "s9",
      uid: "u-me",
      role: "reader",
      owner: "u-owner",
      invitedBy: "u-owner",
      name: "Shared docs"
    }]);
    await _react2.screen.findByText("Invitations");
    (0, _vitest.expect)(_react2.screen.getByText(/invited you to/i)).toBeInTheDocument();
    await user.click(_react2.screen.getByRole("button", {
      name: "Accept"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(acceptInvite).toHaveBeenCalledWith("s9"));
    // The inbox row is gone (live) and the space now appears in the list.
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(_react2.screen.queryByText("Invitations")).not.toBeInTheDocument());
    (0, _vitest.expect)(await _react2.screen.findByText("Shared docs")).toBeInTheDocument();
  });
  (0, _vitest.it)("Decline calls declineInvite and the row leaves the inbox (live) with no space added", async () => {
    const user = _userEvent.default.setup();
    declineInvite.mockImplementation(async () => {
      inviteState.current = [];
      inviteState.listeners.forEach(l => l());
    });
    listAllSpaces.mockResolvedValue([]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await pushInvites([{
      spaceId: "s9",
      uid: "u-me",
      role: "reader",
      owner: "u-owner",
      invitedBy: "u-owner",
      name: "Shared docs"
    }]);
    await _react2.screen.findByText("Invitations");
    await user.click(_react2.screen.getByRole("button", {
      name: "Decline"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(declineInvite).toHaveBeenCalledWith("s9"));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(_react2.screen.queryByText("Invitations")).not.toBeInTheDocument());
    (0, _vitest.expect)(_react2.screen.queryByText("Shared docs")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("owner Revoke calls revokeInvite and drops the pending row", async () => {
    const user = _userEvent.default.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites.mockResolvedValueOnce([{
      spaceId: "s1",
      uid: "uid-of-bob",
      role: "writer",
      owner: "u-me",
      invitedBy: "u-me",
      login: "bob"
    }]).mockResolvedValue([]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await user.click(await _react2.screen.findByText("Manage"));
    const dialog = await _react2.screen.findByRole("dialog");
    await (0, _react2.within)(dialog).findByText("Pending invites");
    await user.click((0, _react2.within)(dialog).getByRole("button", {
      name: "Revoke"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(revokeInvite).toHaveBeenCalledWith("s1", "uid-of-bob"));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)((0, _react2.within)(dialog).queryByText("Pending invites")).not.toBeInTheDocument());
  });
  (0, _vitest.it)("the narrow panel.spaces rail exposes NO admin verb, but still browses + shows invitations (R3-96 / §9 B3)", async () => {
    regionState.current = "panel.spaces";
    listAllSpaces.mockResolvedValue([ownedSpace]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    // Browse still works — the owned space is listed (spaces:user).
    (0, _vitest.expect)(await _react2.screen.findByText("My space")).toBeInTheDocument();
    // ...but the admin affordance is absent on the rail (no spaces:admin here).
    (0, _vitest.expect)(_react2.screen.queryByText("Manage")).not.toBeInTheDocument();
    // The invitee-side inbox (spaces:user) is retained — a pushed invite renders.
    await pushInvites([{
      spaceId: "s9",
      uid: "u-me",
      role: "reader",
      owner: "u-owner",
      invitedBy: "u-owner",
      name: "Shared docs"
    }]);
    (0, _vitest.expect)(await _react2.screen.findByText("Invitations")).toBeInTheDocument();
  });
  (0, _vitest.it)("the full-tab surface DOES expose Manage for an owned space (page.spaces)", async () => {
    regionState.current = "page.spaces";
    listAllSpaces.mockResolvedValue([ownedSpace]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    (0, _vitest.expect)(await _react2.screen.findByText("Manage")).toBeInTheDocument();
  });
  (0, _vitest.it)("R3-269: an `open-space` boot hint auto-opens Manage at that owned space", async () => {
    regionState.current = "page.spaces";
    taskInputState.current = {
      task: "open-space",
      params: {
        spaceId: "s1"
      }
    };
    listAllSpaces.mockResolvedValue([ownedSpace]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    const dialog = await _react2.screen.findByRole("dialog", {
      name: "Manage space"
    });
    (0, _vitest.expect)(dialog).toHaveTextContent("My space");
  });
  (0, _vitest.it)("R3-269: an `open-space` hint for a non-owned / unknown space opens nothing", async () => {
    regionState.current = "page.spaces";
    taskInputState.current = {
      task: "open-space",
      params: {
        spaceId: "not-mine"
      }
    };
    listAllSpaces.mockResolvedValue([ownedSpace]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _react2.screen.findByText("Manage"); // list rendered
    (0, _vitest.expect)(_react2.screen.queryByRole("dialog", {
      name: "Manage space"
    })).not.toBeInTheDocument();
  });
  (0, _vitest.it)("the invite row cannot push a control outside the dialog (R3-256 / drill F4)", async () => {
    // The reported failure: on a narrow dialog the role select spilled outside and
    // the submit button was "clipped/invisible; only reachable by Tab". jsdom does
    // not lay out, so this cannot be asserted in pixels — but it DOES cascade a
    // stylesheet into getComputedStyle, so the two properties that make the
    // overflow impossible are asserted on the REAL rendered controls with the REAL
    // shipped stylesheet, not by grepping the CSS file:
    //
    //   · the row wraps  ⇒ a control that will not fit moves to the next line
    //                      instead of being pushed past the modal edge;
    //   · the growing input can shrink below its content width ⇒ it gives way
    //                      first, so the row only wraps when it genuinely must.
    //
    // A flex item defaults to `min-width: auto` (its CONTENT minimum), which is
    // precisely why `flex: 1` alone was not enough and the row overflowed.
    // RESIDUAL: the true geometric check ("nothing is clipped at 320px") needs a
    // browser; this repo has no layout-capable harness.
    const user = _userEvent.default.setup();
    listAllSpaces.mockResolvedValue([ownedSpace]);

    // Guard against the vacuous pass: if CSS processing is ever disabled again,
    // the sheet is empty, every computed value falls back to its initial value,
    // and the assertions below would "pass" while testing nothing.
    (0, _vitest.expect)(_SpaceManager.default.length).toBeGreaterThan(0);
    const style = document.createElement("style");
    style.textContent = _SpaceManager.default;
    document.head.appendChild(style);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await user.click(await _react2.screen.findByText("Manage"));
    const dialog = await _react2.screen.findByRole("dialog");
    const input = (0, _react2.within)(dialog).getByPlaceholderText("handle");
    const row = input.parentElement;
    const select = (0, _react2.within)(dialog).getAllByRole("combobox")[0];
    const submit = (0, _react2.within)(dialog).getByRole("button", {
      name: "Invite"
    });

    // All three controls really are in one row — the premise of the failure.
    (0, _vitest.expect)(row).toContainElement(select);
    (0, _vitest.expect)(row).toContainElement(submit);
    (0, _vitest.expect)(getComputedStyle(row).flexWrap).toBe("wrap");
    (0, _vitest.expect)(getComputedStyle(input).minWidth).toBe("0px");
    style.remove();
  });
  (0, _vitest.it)("an invite whose name/invitedBy contains markup renders as inert text (escaped)", async () => {
    const markup = '<img src=x onerror="alert(1)">';
    listAllSpaces.mockResolvedValue([]);
    const {
      container
    } = (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await pushInvites([{
      spaceId: "s9",
      uid: "u-me",
      role: "reader",
      owner: "u-owner",
      invitedBy: markup,
      name: markup
    }]);
    await _react2.screen.findByText("Invitations");
    // The markup is present as TEXT, and produced no injected <img> element.
    (0, _vitest.expect)(_react2.screen.getByText(/invited you to/i).textContent).toContain(markup);
    (0, _vitest.expect)(container.querySelector('img[src="x"]')).toBeNull();
  });
});

// R3-206 (GOOGLE_IDENTITY_AND_DRIVE_SPEC §8.2; SPACES_UI_SPEC §4/§5 R-SPACES-6) —
// "Connect a new source → Google Drive".
//
// What this app is responsible for is small and the tests say so: it names the
// SCHEME, and it reflects the result. Every authority step — the incremental Google
// consent, the folder browser, the ro|rw choice, the single-writer disclosure — is
// drawn by the HOST, and its tests live there (`ConnectSourceDialog.test.tsx`). The
// thing worth pinning HERE is that this app paints none of it: a forked space-manager
// that tried to would be drawing its own consent, which §8.3 forbids.
(0, _vitest.describe)("connecting a new source (R3-206)", () => {
  (0, _vitest.beforeEach)(() => {
    listAllSpaces.mockResolvedValue([]);
    protocolRequest.mockReset();
    protocolRequest.mockResolvedValue({
      id: "drive:folder-1"
    });
    regionState.current = "page.spaces";
  });
  (0, _vitest.it)("CONNECT is a distinct action from CREATE — both are offered, and they are not the same button", async () => {
    // `requestMount()` selects from what the user already has; connect SETS ONE UP.
    // Collapsing them is the shape §8.2 rules out, because a picker that sometimes
    // navigates the page to Google is not a picker.
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    (0, _vitest.expect)(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react2.screen.getByRole("button", {
      name: "Create a space"
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("names only the SCHEME — no scope, no folder, no wording", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(protocolRequest).toHaveBeenCalledTimes(1));
    (0, _vitest.expect)(protocolRequest).toHaveBeenCalledWith("protocol-spaces", "connectSource", [{
      scheme: "drive"
    }]);
  });
  (0, _vitest.it)("paints NO authorization chrome of its own", async () => {
    // The whole §8.3 rule in one assertion: after the click, this app shows a busy
    // label and nothing else. No scope text, no folder list, no ro/rw choice — those
    // exist only in host chrome, which a fork cannot replace.
    let resolve = () => {};
    protocolRequest.mockReturnValue(new Promise(r => {
      resolve = r;
    }));
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    }));
    (0, _vitest.expect)(await _react2.screen.findByRole("button", {
      name: "Connecting…"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react2.screen.queryByText(/drive\.file/)).not.toBeInTheDocument();
    (0, _vitest.expect)(_react2.screen.queryByText(/single-writer/i)).not.toBeInTheDocument();
    (0, _vitest.expect)(_react2.screen.queryByRole("button", {
      name: /Read and write/
    })).not.toBeInTheDocument();
    await (0, _react2.act)(async () => {
      resolve({});
    });
  });
  (0, _vitest.it)("treats `cancelled` as calm — the user backed out, nothing failed", async () => {
    protocolRequest.mockRejectedValue(Object.assign(new Error("cancelled"), {
      code: "cancelled"
    }));
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)(_react2.screen.getByRole("button", {
      name: "Connect Google Drive"
    })).toBeEnabled());
    (0, _vitest.expect)(document.querySelector(".sm-err")).toBeNull();
  });
  (0, _vitest.it)("says what to DO when the Google connection needs re-authorizing", async () => {
    // `google_reauth_required` is not "something went wrong": the remedy is a
    // specific page, and a generic message would leave the user with no next step.
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), {
      code: "google_reauth_required"
    }));
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    }));
    (0, _vitest.expect)(await _react2.screen.findByText(/Reconnect Google in Settings/)).toBeInTheDocument();
  });
  (0, _vitest.it)("says so plainly when the deployment has no Drive connector", async () => {
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), {
      code: "unsupported-scheme"
    }));
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Connect Google Drive"
    }));
    (0, _vitest.expect)(await _react2.screen.findByText(/isn’t available on this deployment/)).toBeInTheDocument();
  });
  (0, _vitest.it)("is absent from the narrow panel — the rail exposes no setup verb", async () => {
    // Same rule as the admin surfaces (R3-96 / PRINCIPALS §9 B3): the rail is
    // browse/open/mount-only.
    regionState.current = "panel.spaces";
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _react2.screen.findByText("Spaces");
    (0, _vitest.expect)(_react2.screen.queryByRole("button", {
      name: "Connect Google Drive"
    })).not.toBeInTheDocument();
  });
});

// R3-259 — the space's KIND: chosen at create, visible in the list, converted
// once via a named arm-then-confirm act. `kind` rides the wire additively (the
// host derives/validates it); these tests pin what the app sends and shows.
(0, _vitest.describe)("R3-259 — a space's kind", () => {
  (0, _vitest.beforeEach)(() => {
    _vitest.vi.clearAllMocks();
    regionState.current = "page.spaces";
    taskInputState.current = null;
    inviteState.current = [];
    listAllSpaces.mockResolvedValue([]);
    getSpaceMembers.mockResolvedValue([]);
    listPendingInvites.mockResolvedValue([]);
    createSpaceMock.mockResolvedValue(undefined);
    protocolRequest.mockResolvedValue({
      ok: true
    });
  });
  (0, _vitest.it)("create defaults to personal and sends the kind", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Create a space"
    }));
    (0, _vitest.expect)(createSpaceMock).toHaveBeenCalledWith({
      kind: "personal"
    });
  });
  (0, _vitest.it)("choosing Shared sends shared", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("radio", {
      name: "Shared"
    }));
    await _userEvent.default.click(_react2.screen.getByRole("button", {
      name: "Create a space"
    }));
    (0, _vitest.expect)(createSpaceMock).toHaveBeenCalledWith({
      kind: "shared"
    });
  });
  (0, _vitest.it)("badges only SHARED spaces — personal is the unmarked default", async () => {
    listAllSpaces.mockResolvedValue([{
      spaceId: "s1",
      name: "Mine",
      role: "owner",
      kind: "personal"
    }, {
      spaceId: "s2",
      name: "Ours",
      role: "owner",
      kind: "shared"
    }, {
      spaceId: "s3",
      name: "Legacy",
      role: "owner"
    } // pre-R3-259 row: unbadged
    ]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    const ours = (await _react2.screen.findByText("Ours")).closest("li");
    (0, _vitest.expect)((0, _react2.within)(ours).getByText("shared")).toBeInTheDocument();
    const mine = _react2.screen.getByText("Mine").closest("li");
    (0, _vitest.expect)((0, _react2.within)(mine).queryByText("shared")).not.toBeInTheDocument();
    const legacy = _react2.screen.getByText("Legacy").closest("li");
    (0, _vitest.expect)((0, _react2.within)(legacy).queryByText("shared")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("the owner's personal space offers Convert; arming shows the irreversibility; confirming hits the verb once", async () => {
    listAllSpaces.mockResolvedValue([{
      spaceId: "s1",
      name: "Mine",
      role: "owner",
      kind: "personal"
    }]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Manage"
    }));
    const arm = await _react2.screen.findByRole("button", {
      name: /Convert to shared…/
    });
    await _userEvent.default.click(arm); // first click ARMS
    (0, _vitest.expect)(protocolRequest).not.toHaveBeenCalled();
    // The armed state is the button that now SAYS what it does.
    (0, _vitest.expect)(_react2.screen.getByRole("button", {
      name: /Convert to shared — cannot be undone/
    })).toBeInTheDocument();
    await _userEvent.default.click(_react2.screen.getByRole("button", {
      name: /Convert to shared — cannot be undone/
    }));
    (0, _vitest.expect)(protocolRequest).toHaveBeenCalledWith("protocol-spaces", "convertToShared", [{
      spaceId: "s1",
      confirm: true
    }]);
    (0, _vitest.expect)(protocolRequest).toHaveBeenCalledTimes(1);
  });
  (0, _vitest.it)("after converting, the refreshed list shows the shared badge", async () => {
    let kind = "personal";
    listAllSpaces.mockImplementation(async () => [{
      spaceId: "s1",
      name: "Mine",
      role: "owner",
      kind
    }]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Manage"
    }));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: /Convert to shared…/
    }));
    // The verb resolving flips what the (mock) host lists next.
    protocolRequest.mockImplementation(async () => {
      kind = "shared";
      return {
        ok: true
      };
    });
    await _userEvent.default.click(_react2.screen.getByRole("button", {
      name: /Convert to shared — cannot be undone/
    }));
    await (0, _react2.waitFor)(() => (0, _vitest.expect)((0, _react2.within)(_react2.screen.getByText("Mine").closest("li")).getByText("shared")).toBeInTheDocument());
  });
  (0, _vitest.it)("a SHARED space's Manage modal offers no conversion — there is no way back", async () => {
    listAllSpaces.mockResolvedValue([{
      spaceId: "s2",
      name: "Ours",
      role: "owner",
      kind: "shared"
    }]);
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Manage"
    }));
    await _react2.screen.findByText(/Share “Ours”/);
    (0, _vitest.expect)(_react2.screen.queryByRole("button", {
      name: /Convert to shared/
    })).not.toBeInTheDocument();
  });
  (0, _vitest.it)("a forbidden conversion surfaces the owner-only message", async () => {
    listAllSpaces.mockResolvedValue([{
      spaceId: "s1",
      name: "Mine",
      role: "owner",
      kind: "personal"
    }]);
    protocolRequest.mockRejectedValue(Object.assign(new Error("x"), {
      code: "forbidden"
    }));
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager2.default, {}));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: "Manage"
    }));
    await _userEvent.default.click(await _react2.screen.findByRole("button", {
      name: /Convert to shared…/
    }));
    await _userEvent.default.click(_react2.screen.getByRole("button", {
      name: /Convert to shared — cannot be undone/
    }));
    (0, _vitest.expect)(await _react2.screen.findByText(/Only the owner can convert this space/)).toBeInTheDocument();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJSZWFjdCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwicmVxdWlyZSIsIl9yZWFjdDIiLCJfdXNlckV2ZW50IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl92aXRlc3QiLCJfU3BhY2VNYW5hZ2VyIiwiX1NwYWNlTWFuYWdlcjIiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIldlYWtNYXAiLCJyIiwidCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsImxpc3RBbGxTcGFjZXMiLCJ2aSIsImZuIiwiZ2V0U3BhY2VNZW1iZXJzIiwibGlzdFBlbmRpbmdJbnZpdGVzIiwiaW52aXRlVG9TcGFjZSIsImFjY2VwdEludml0ZSIsImRlY2xpbmVJbnZpdGUiLCJyZXZva2VJbnZpdGUiLCJjcmVhdGVTcGFjZU1vY2siLCJpbnZpdGVTdGF0ZSIsImhvaXN0ZWQiLCJjdXJyZW50IiwibGlzdGVuZXJzIiwiU2V0IiwicmVnaW9uU3RhdGUiLCJ0YXNrSW5wdXRTdGF0ZSIsInByb3RvY29sUmVxdWVzdCIsIm1vY2siLCJfcyIsIiRSZWZyZXNoU2lnJCIsInVzZUludml0ZXMiLCJmb3JjZSIsInVzZVJlZHVjZXIiLCJ4IiwidXNlRWZmZWN0IiwiYWRkIiwiZGVsZXRlIiwidW5zaGFyZVNwYWNlIiwic2V0U3BhY2VSb2xlIiwibGlzdEdyYW50cyIsInJldm9rZUdyYW50IiwiY3JlYXRlU3BhY2UiLCJ1c2VBdXRoIiwic3RhdHVzIiwidXNlUmVnaW9uIiwidXNlVGFza0lucHV0Iiwib3duZWRTcGFjZSIsInNwYWNlSWQiLCJuYW1lIiwicm9sZSIsInB1c2hJbnZpdGVzIiwibGlzdCIsImFjdCIsImZvckVhY2giLCJsIiwiYmVmb3JlRWFjaCIsIm0iLCJtb2NrUmVzZXQiLCJtb2NrUmVzb2x2ZWRWYWx1ZSIsInVuZGVmaW5lZCIsImRlc2NyaWJlIiwiaXQiLCJ1c2VyIiwidXNlckV2ZW50Iiwic2V0dXAiLCJtb2NrUmVzb2x2ZWRWYWx1ZU9uY2UiLCJ1aWQiLCJvd25lciIsImludml0ZWRCeSIsImxvZ2luIiwicmVuZGVyIiwianN4IiwiY2xpY2siLCJzY3JlZW4iLCJmaW5kQnlUZXh0IiwiZGlhbG9nIiwiZmluZEJ5Um9sZSIsIndpdGhpbiIsImNhdGNoIiwidHlwZSIsImdldEJ5UGxhY2Vob2xkZXJUZXh0IiwiZ2V0QnlSb2xlIiwid2FpdEZvciIsImV4cGVjdCIsInRvSGF2ZUJlZW5DYWxsZWRXaXRoIiwiZ2V0QnlUZXh0IiwidG9CZUluVGhlRG9jdW1lbnQiLCJtb2NrSW1wbGVtZW50YXRpb24iLCJxdWVyeUJ5VGV4dCIsIm5vdCIsInRhc2siLCJwYXJhbXMiLCJ0b0hhdmVUZXh0Q29udGVudCIsInF1ZXJ5QnlSb2xlIiwic3BhY2VNYW5hZ2VyQ3NzIiwibGVuZ3RoIiwidG9CZUdyZWF0ZXJUaGFuIiwic3R5bGUiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJ0ZXh0Q29udGVudCIsImhlYWQiLCJhcHBlbmRDaGlsZCIsImlucHV0Iiwicm93IiwicGFyZW50RWxlbWVudCIsInNlbGVjdCIsImdldEFsbEJ5Um9sZSIsInN1Ym1pdCIsInRvQ29udGFpbkVsZW1lbnQiLCJnZXRDb21wdXRlZFN0eWxlIiwiZmxleFdyYXAiLCJ0b0JlIiwibWluV2lkdGgiLCJyZW1vdmUiLCJtYXJrdXAiLCJjb250YWluZXIiLCJ0b0NvbnRhaW4iLCJxdWVyeVNlbGVjdG9yIiwidG9CZU51bGwiLCJpZCIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsInNjaGVtZSIsInJlc29sdmUiLCJtb2NrUmV0dXJuVmFsdWUiLCJQcm9taXNlIiwibW9ja1JlamVjdGVkVmFsdWUiLCJhc3NpZ24iLCJFcnJvciIsImNvZGUiLCJ0b0JlRW5hYmxlZCIsImNsZWFyQWxsTW9ja3MiLCJvayIsImtpbmQiLCJvdXJzIiwiY2xvc2VzdCIsIm1pbmUiLCJsZWdhY3kiLCJhcm0iLCJ0b0hhdmVCZWVuQ2FsbGVkIiwiY29uZmlybSJdLCJzb3VyY2VzIjpbIlNwYWNlTWFuYWdlci50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy05MSAoRklMRV9TSEFSSU5HIMKnNi40L8KnOS43L8KnOS44KSDigJQgdGhlIHNwYWNlLW1hbmFnZXIgSW52aXRhdGlvbnMgVUkuIERyaXZlblxuLy8gYWdhaW5zdCBhIG1vY2tlZCBTREs6IGludml0aW5nIGNyZWF0ZXMgYSBQRU5ESU5HIG9mZmVyIChub3QgYSBtZW1iZXIpOyB0aGUgaW52aXRlZVxuLy8gaW5ib3ggQWNjZXB0cy9EZWNsaW5lczsgdGhlIG93bmVyIFJldm9rZXMgYSBwZW5kaW5nIGludml0ZTsgb3duZXItd3JpdHRlbiBzdHJpbmdzXG4vLyByZW5kZXIgaW5lcnQuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHJlbmRlciwgc2NyZWVuLCB3YWl0Rm9yLCB3aXRoaW4sIGFjdCB9IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3JlYWN0XCI7XG5pbXBvcnQgdXNlckV2ZW50IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3VzZXItZXZlbnRcIjtcbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCBiZWZvcmVFYWNoLCB2aSB9IGZyb20gXCJ2aXRlc3RcIjtcbmltcG9ydCB0eXBlIHsgSW52aXRlLCBNZW1iZXIsIFNwYWNlSW5mbyB9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuLy8gVGhlIFJFQUwgc2hpcHBlZCBzdHlsZXNoZWV0LCBhcyB0ZXh0LCBzbyB0aGUgUjMtMjU2IGxheW91dCB0ZXN0IGFzc2VydHMgYWdhaW5zdFxuLy8gd2hhdCBzaGlwcyByYXRoZXIgdGhhbiBhIGNvcHkgb2YgdGhlIHJ1bGVzLiBgdml0ZXN0LmNvbmZpZy50c2Agc2V0cyBgY3NzOiB0cnVlYDtcbi8vIHdpdGhvdXQgaXQgdGhpcyBpbXBvcnQgaXMgYW4gZW1wdHkgc3RyaW5nIGFuZCB0aGF0IHRlc3QgcGFzc2VzIHZhY3VvdXNseS5cbmltcG9ydCBzcGFjZU1hbmFnZXJDc3MgZnJvbSBcIi4vU3BhY2VNYW5hZ2VyLmNzcz9yYXdcIjtcblxuLy8gLS0tIGNvbnRyb2xsYWJsZSBTREsgZG91YmxlcyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmNvbnN0IGxpc3RBbGxTcGFjZXMgPSB2aS5mbjwoKSA9PiBQcm9taXNlPFNwYWNlSW5mb1tdPj4oKTtcbmNvbnN0IGdldFNwYWNlTWVtYmVycyA9IHZpLmZuPCgpID0+IFByb21pc2U8TWVtYmVyW10+PigpO1xuY29uc3QgbGlzdFBlbmRpbmdJbnZpdGVzID0gdmkuZm48KCkgPT4gUHJvbWlzZTxJbnZpdGVbXT4+KCk7XG5jb25zdCBpbnZpdGVUb1NwYWNlID0gdmkuZm48KCkgPT4gUHJvbWlzZTx2b2lkPj4oKTtcbmNvbnN0IGFjY2VwdEludml0ZSA9IHZpLmZuPCgpID0+IFByb21pc2U8dm9pZD4+KCk7XG5jb25zdCBkZWNsaW5lSW52aXRlID0gdmkuZm48KCkgPT4gUHJvbWlzZTx2b2lkPj4oKTtcbmNvbnN0IHJldm9rZUludml0ZSA9IHZpLmZuPCgpID0+IFByb21pc2U8dm9pZD4+KCk7XG4vLyBSMy0yNTkg4oCUIHRoZSBjcmVhdGUgdmVyYidzIHBhcmFtcyBhcmUgdW5kZXIgdGVzdCAodGhlIGNyZWF0ZS10aW1lIGtpbmQpLlxuY29uc3QgY3JlYXRlU3BhY2VNb2NrID0gdmkuZm48KG9wdHM/OiB1bmtub3duKSA9PiBQcm9taXNlPHZvaWQ+PigpO1xuXG4vLyBBIGNvbnRyb2xsYWJsZSBgdXNlSW52aXRlcygpYCBsaXZlIGNoYW5uZWw6IHRoZSBob3N0IHB1c2hlcyB0aGUgaW5ib3ggYW5kIHRoZSBob29rXG4vLyByZS1yZW5kZXJzLiBgc2V0SW52aXRlcyhsaXN0KWAgc2ltdWxhdGVzIGEgaG9zdCBwdXNoIChhbiBpbnZpdGUgYXJyaXZpbmcvbGVhdmluZykuXG5jb25zdCBpbnZpdGVTdGF0ZSA9IHZpLmhvaXN0ZWQoKCkgPT4gKHsgY3VycmVudDogW10gYXMgdW5rbm93bltdLCBsaXN0ZW5lcnM6IG5ldyBTZXQ8KCkgPT4gdm9pZD4oKSB9KSk7XG5cbi8vIEEgY29udHJvbGxhYmxlIGB1c2VSZWdpb24oKWA6IGFkbWluIHZlcmJzIG9ubHkgcmVuZGVyIG9uIHRoZSBub24tcGFuZWwgKGZ1bGwtdGFiKVxuLy8gc3VyZmFjZSAoUjMtOTYgLyBQUklOQ0lQQUxTIMKnOSBCMykuIERlZmF1bHQgdG8gYHBhZ2Uuc3BhY2VzYCBzbyB0aGUgYWRtaW4tZmxvdyB0ZXN0c1xuLy8gYmVsb3cgZXhlcmNpc2UgdGhlIE1hbmFnZSBtb2RhbDsgdGhlIFIzLTk2IHRlc3Qgb3ZlcnJpZGVzIGl0IHRvIGBwYW5lbC5zcGFjZXNgLlxuY29uc3QgcmVnaW9uU3RhdGUgPSB2aS5ob2lzdGVkKCgpID0+ICh7IGN1cnJlbnQ6IFwicGFnZS5zcGFjZXNcIiBhcyBzdHJpbmcgfSkpO1xuXG4vLyBBIGNvbnRyb2xsYWJsZSBgdXNlVGFza0lucHV0KClgOiB0aGUgUjMtMjY5IGBvcGVuLXNwYWNlYCBib290IGhpbnRcbi8vICgvc3BhY2VzP3NwYWNlPTxpZD4g4oaSIGF1dG8tb3BlbiB0aGUgTWFuYWdlIG1vZGFsIGF0IHRoYXQgc3BhY2UpLiBEZWZhdWx0IG51bGwuXG5jb25zdCB0YXNrSW5wdXRTdGF0ZSA9IHZpLmhvaXN0ZWQoKCkgPT4gKHtcbiAgY3VycmVudDogbnVsbCBhcyB7IHRhc2s6IHN0cmluZzsgcGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB9IHwgbnVsbCxcbn0pKTtcblxuLy8gUjMtMjA2IOKAlCB0aGUgd2lyZSBjYWxsIGJlaGluZCBcIkNvbm5lY3QgR29vZ2xlIERyaXZlXCIuIE1vY2tlZCBhdCB0aGUgU1VCUEFUSCB0aGVcbi8vIGNvbXBvbmVudCBpbXBvcnRzIGZyb206IHRoZSByZWFsIGBzYW5kYm94VXRpbHMuanNgIHJlYWNoZXMgYSBob3N0IHJ1bnRpbWUgdGhhdCBkb2VzXG4vLyBub3QgZXhpc3QgdW5kZXIgdml0ZXN0IChhbmQgc2hpcHMgZXh0ZW5zaW9ubGVzcyBzcGVjaWZpZXJzIHZpdGVzdCBjYW5ub3QgcmVzb2x2ZSkuXG5jb25zdCBwcm90b2NvbFJlcXVlc3QgPSB2aS5mbjwocDogc3RyaW5nLCBtOiBzdHJpbmcsIGFyZ3M6IHVua25vd25bXSkgPT4gUHJvbWlzZTx1bmtub3duPj4oKTtcbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9zYW5kYm94VXRpbHNcIiwgKCkgPT4gKHsgcHJvdG9jb2xSZXF1ZXN0OiAoLi4uYTogdW5rbm93bltdKSA9PiBwcm90b2NvbFJlcXVlc3QoLi4uKGEgYXMgW3N0cmluZywgc3RyaW5nLCB1bmtub3duW11dKSkgfSkpO1xuXG52aS5tb2NrKFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIiwgKCkgPT4gKHtcbiAgbGlzdEFsbFNwYWNlczogKCkgPT4gbGlzdEFsbFNwYWNlcygpLFxuICBnZXRTcGFjZU1lbWJlcnM6ICgpID0+IGdldFNwYWNlTWVtYmVycygpLFxuICBsaXN0UGVuZGluZ0ludml0ZXM6ICgpID0+IGxpc3RQZW5kaW5nSW52aXRlcygpLFxuICB1c2VJbnZpdGVzOiAoKSA9PiB7XG4gICAgY29uc3QgWywgZm9yY2VdID0gUmVhY3QudXNlUmVkdWNlcigoeDogbnVtYmVyKSA9PiB4ICsgMSwgMCk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGludml0ZVN0YXRlLmxpc3RlbmVycy5hZGQoZm9yY2UpO1xuICAgICAgcmV0dXJuICgpID0+IHsgaW52aXRlU3RhdGUubGlzdGVuZXJzLmRlbGV0ZShmb3JjZSk7IH07XG4gICAgfSwgW10pO1xuICAgIHJldHVybiBpbnZpdGVTdGF0ZS5jdXJyZW50O1xuICB9LFxuICBpbnZpdGVUb1NwYWNlOiAoLi4uYTogdW5rbm93bltdKSA9PiBpbnZpdGVUb1NwYWNlKC4uLihhIGFzIFtdKSksXG4gIGFjY2VwdEludml0ZTogKC4uLmE6IHVua25vd25bXSkgPT4gYWNjZXB0SW52aXRlKC4uLihhIGFzIFtdKSksXG4gIGRlY2xpbmVJbnZpdGU6ICguLi5hOiB1bmtub3duW10pID0+IGRlY2xpbmVJbnZpdGUoLi4uKGEgYXMgW10pKSxcbiAgcmV2b2tlSW52aXRlOiAoLi4uYTogdW5rbm93bltdKSA9PiByZXZva2VJbnZpdGUoLi4uKGEgYXMgW10pKSxcbiAgdW5zaGFyZVNwYWNlOiB2aS5mbigpLFxuICBzZXRTcGFjZVJvbGU6IHZpLmZuKCksXG4gIGxpc3RHcmFudHM6IHZpLmZuKGFzeW5jICgpID0+IFtdKSxcbiAgcmV2b2tlR3JhbnQ6IHZpLmZuKCksXG4gIGNyZWF0ZVNwYWNlOiAoLi4uYTogdW5rbm93bltdKSA9PiBjcmVhdGVTcGFjZU1vY2soLi4uKGEgYXMgW29wdHM/OiB1bmtub3duXSkpLFxuICB1c2VBdXRoOiAoKSA9PiAoeyBzdGF0dXM6IFwic2lnbmVkLWluXCIgfSksXG4gIHVzZVJlZ2lvbjogKCkgPT4gcmVnaW9uU3RhdGUuY3VycmVudCxcbiAgdXNlVGFza0lucHV0OiAoKSA9PiB0YXNrSW5wdXRTdGF0ZS5jdXJyZW50LFxufSkpO1xuXG5pbXBvcnQgU3BhY2VNYW5hZ2VyIGZyb20gXCIuL1NwYWNlTWFuYWdlclwiO1xuXG5jb25zdCBvd25lZFNwYWNlOiBTcGFjZUluZm8gPSB7IHNwYWNlSWQ6IFwiczFcIiwgbmFtZTogXCJNeSBzcGFjZVwiLCByb2xlOiBcIm93bmVyXCIgfSBhcyBTcGFjZUluZm87XG5cbi8qKiBTaW11bGF0ZSBhIGhvc3QgcHVzaCBvbiB0aGUgbGl2ZSBpbnZpdGF0aW9ucyBjaGFubmVsLiAqL1xuY29uc3QgcHVzaEludml0ZXMgPSAobGlzdDogSW52aXRlW10pID0+XG4gIGFjdCgoKSA9PiB7XG4gICAgaW52aXRlU3RhdGUuY3VycmVudCA9IGxpc3Q7XG4gICAgaW52aXRlU3RhdGUubGlzdGVuZXJzLmZvckVhY2goKGwpID0+IGwoKSk7XG4gIH0pO1xuXG5iZWZvcmVFYWNoKCgpID0+IHtcbiAgZm9yIChjb25zdCBtIG9mIFtcbiAgICBsaXN0QWxsU3BhY2VzLCBnZXRTcGFjZU1lbWJlcnMsIGxpc3RQZW5kaW5nSW52aXRlcyxcbiAgICBpbnZpdGVUb1NwYWNlLCBhY2NlcHRJbnZpdGUsIGRlY2xpbmVJbnZpdGUsIHJldm9rZUludml0ZSxcbiAgXSkgbS5tb2NrUmVzZXQoKTtcbiAgaW52aXRlU3RhdGUuY3VycmVudCA9IFtdO1xuICByZWdpb25TdGF0ZS5jdXJyZW50ID0gXCJwYWdlLnNwYWNlc1wiOyAvLyBmdWxsLXRhYiBieSBkZWZhdWx0OyB0aGUgUjMtOTYgdGVzdCBzZXRzIHBhbmVsLnNwYWNlc1xuICB0YXNrSW5wdXRTdGF0ZS5jdXJyZW50ID0gbnVsbDtcbiAgLy8gc2Vuc2libGUgZW1wdHkgZGVmYXVsdHM7IGluZGl2aWR1YWwgdGVzdHMgb3ZlcnJpZGUuXG4gIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICBnZXRTcGFjZU1lbWJlcnMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICBsaXN0UGVuZGluZ0ludml0ZXMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICBpbnZpdGVUb1NwYWNlLm1vY2tSZXNvbHZlZFZhbHVlKHVuZGVmaW5lZCk7XG4gIGFjY2VwdEludml0ZS5tb2NrUmVzb2x2ZWRWYWx1ZSh1bmRlZmluZWQpO1xuICBkZWNsaW5lSW52aXRlLm1vY2tSZXNvbHZlZFZhbHVlKHVuZGVmaW5lZCk7XG4gIHJldm9rZUludml0ZS5tb2NrUmVzb2x2ZWRWYWx1ZSh1bmRlZmluZWQpO1xufSk7XG5cbmRlc2NyaWJlKFwiU3BhY2VNYW5hZ2VyIOKAlCBpbnZpdGF0aW9ucyAoUjMtOTEpXCIsICgpID0+IHtcbiAgaXQoXCJpbnZpdGluZyBjYWxscyBpbnZpdGVUb1NwYWNlIGFuZCB0aGUgb2ZmZXIgbGFuZHMgdW5kZXIgUGVuZGluZywgbm90IE1lbWJlcnNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtvd25lZFNwYWNlXSk7XG4gICAgLy8gRmlyc3QgbWFuYWdlLW9wZW4gbG9hZDogbm8gbWVtYmVycywgbm8gcGVuZGluZy4gQWZ0ZXIgaW52aXRlOiBvbmUgcGVuZGluZy5cbiAgICBnZXRTcGFjZU1lbWJlcnMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIGxpc3RQZW5kaW5nSW52aXRlc1xuICAgICAgLm1vY2tSZXNvbHZlZFZhbHVlT25jZShbXSlcbiAgICAgIC5tb2NrUmVzb2x2ZWRWYWx1ZShbeyBzcGFjZUlkOiBcInMxXCIsIHVpZDogXCJ1aWQtb2YtYm9iXCIsIHJvbGU6IFwid3JpdGVyXCIsIG93bmVyOiBcInUtbWVcIiwgaW52aXRlZEJ5OiBcInUtbWVcIiwgbG9naW46IFwiYm9iXCIgfV0pO1xuXG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJNYW5hZ2VcIikpO1xuXG4gICAgY29uc3QgZGlhbG9nID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJkaWFsb2dcIik7XG4gICAgYXdhaXQgd2l0aGluKGRpYWxvZykuZmluZEJ5VGV4dCgvTm8gbWVtYmVyc3xMb2FkaW5nIG1lbWJlcnMvaSkuY2F0Y2goKCkgPT4ge30pO1xuICAgIGF3YWl0IHVzZXIudHlwZSh3aXRoaW4oZGlhbG9nKS5nZXRCeVBsYWNlaG9sZGVyVGV4dChcImhhbmRsZVwiKSwgXCJib2JcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4oZGlhbG9nKS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkludml0ZVwiIH0pKTtcblxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGludml0ZVRvU3BhY2UpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiczFcIiwgXCJib2JcIiwgXCJ3cml0ZXJcIikpO1xuICAgIC8vIFRoZSBvZmZlciBhcHBlYXJzIHVuZGVyIFBlbmRpbmcgaW52aXRlcyDigJQgYW5kIGlzIE5PVCBhIG1lbWJlciByb3cuXG4gICAgYXdhaXQgd2l0aGluKGRpYWxvZykuZmluZEJ5VGV4dChcIlBlbmRpbmcgaW52aXRlc1wiKTtcbiAgICBleHBlY3Qod2l0aGluKGRpYWxvZykuZ2V0QnlUZXh0KFwiQGJvYlwiKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgaW5ib3ggcmVuZGVycyBhIGxpdmUgaW52aXRlOyBBY2NlcHQgY2FsbHMgYWNjZXB0SW52aXRlLCB0aGVuIHRoZSByb3cgaXMgZ29uZSAobGl2ZSkgYW5kIHRoZSBzcGFjZSBhcHBlYXJzXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgLy8gQWZ0ZXIgYWNjZXB0LCB0aGUgaG9zdCBwdXNoZXMgdGhlIGVtcHRpZWQgaW5ib3ggKHNpbXVsYXRlZCBpbiB0aGUgbW9jaykgYW5kIHRoZVxuICAgIC8vIHNwYWNlcyBsaXN0IGdhaW5zIHRoZSBhY2NlcHRlZCBzcGFjZS5cbiAgICBhY2NlcHRJbnZpdGUubW9ja0ltcGxlbWVudGF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGludml0ZVN0YXRlLmN1cnJlbnQgPSBbXTtcbiAgICAgIGludml0ZVN0YXRlLmxpc3RlbmVycy5mb3JFYWNoKChsKSA9PiBsKCkpO1xuICAgIH0pO1xuICAgIGxpc3RBbGxTcGFjZXNcbiAgICAgIC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoW10pXG4gICAgICAubW9ja1Jlc29sdmVkVmFsdWUoW3sgc3BhY2VJZDogXCJzOVwiLCBuYW1lOiBcIlNoYXJlZCBkb2NzXCIsIHJvbGU6IFwicmVhZGVyXCIgfSBhcyBTcGFjZUluZm9dKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCBwdXNoSW52aXRlcyhbeyBzcGFjZUlkOiBcInM5XCIsIHVpZDogXCJ1LW1lXCIsIHJvbGU6IFwicmVhZGVyXCIsIG93bmVyOiBcInUtb3duZXJcIiwgaW52aXRlZEJ5OiBcInUtb3duZXJcIiwgbmFtZTogXCJTaGFyZWQgZG9jc1wiIH1dKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcIkludml0YXRpb25zXCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KC9pbnZpdGVkIHlvdSB0by9pKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcblxuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQWNjZXB0XCIgfSkpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGFjY2VwdEludml0ZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCJzOVwiKSk7XG4gICAgLy8gVGhlIGluYm94IHJvdyBpcyBnb25lIChsaXZlKSBhbmQgdGhlIHNwYWNlIG5vdyBhcHBlYXJzIGluIHRoZSBsaXN0LlxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcIkludml0YXRpb25zXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiU2hhcmVkIGRvY3NcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KFwiRGVjbGluZSBjYWxscyBkZWNsaW5lSW52aXRlIGFuZCB0aGUgcm93IGxlYXZlcyB0aGUgaW5ib3ggKGxpdmUpIHdpdGggbm8gc3BhY2UgYWRkZWRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBkZWNsaW5lSW52aXRlLm1vY2tJbXBsZW1lbnRhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBpbnZpdGVTdGF0ZS5jdXJyZW50ID0gW107XG4gICAgICBpbnZpdGVTdGF0ZS5saXN0ZW5lcnMuZm9yRWFjaCgobCkgPT4gbCgpKTtcbiAgICB9KTtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCBwdXNoSW52aXRlcyhbeyBzcGFjZUlkOiBcInM5XCIsIHVpZDogXCJ1LW1lXCIsIHJvbGU6IFwicmVhZGVyXCIsIG93bmVyOiBcInUtb3duZXJcIiwgaW52aXRlZEJ5OiBcInUtb3duZXJcIiwgbmFtZTogXCJTaGFyZWQgZG9jc1wiIH1dKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcIkludml0YXRpb25zXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiRGVjbGluZVwiIH0pKTtcblxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGRlY2xpbmVJbnZpdGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiczlcIikpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcIkludml0YXRpb25zXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcIlNoYXJlZCBkb2NzXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJvd25lciBSZXZva2UgY2FsbHMgcmV2b2tlSW52aXRlIGFuZCBkcm9wcyB0aGUgcGVuZGluZyByb3dcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtvd25lZFNwYWNlXSk7XG4gICAgZ2V0U3BhY2VNZW1iZXJzLm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcbiAgICBsaXN0UGVuZGluZ0ludml0ZXNcbiAgICAgIC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoW3sgc3BhY2VJZDogXCJzMVwiLCB1aWQ6IFwidWlkLW9mLWJvYlwiLCByb2xlOiBcIndyaXRlclwiLCBvd25lcjogXCJ1LW1lXCIsIGludml0ZWRCeTogXCJ1LW1lXCIsIGxvZ2luOiBcImJvYlwiIH1dKVxuICAgICAgLm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiTWFuYWdlXCIpKTtcbiAgICBjb25zdCBkaWFsb2cgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImRpYWxvZ1wiKTtcbiAgICBhd2FpdCB3aXRoaW4oZGlhbG9nKS5maW5kQnlUZXh0KFwiUGVuZGluZyBpbnZpdGVzXCIpO1xuXG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4oZGlhbG9nKS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlJldm9rZVwiIH0pKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChyZXZva2VJbnZpdGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiczFcIiwgXCJ1aWQtb2YtYm9iXCIpKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdCh3aXRoaW4oZGlhbG9nKS5xdWVyeUJ5VGV4dChcIlBlbmRpbmcgaW52aXRlc1wiKSkubm90LnRvQmVJblRoZURvY3VtZW50KCkpO1xuICB9KTtcblxuICBpdChcInRoZSBuYXJyb3cgcGFuZWwuc3BhY2VzIHJhaWwgZXhwb3NlcyBOTyBhZG1pbiB2ZXJiLCBidXQgc3RpbGwgYnJvd3NlcyArIHNob3dzIGludml0YXRpb25zIChSMy05NiAvIMKnOSBCMylcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlZ2lvblN0YXRlLmN1cnJlbnQgPSBcInBhbmVsLnNwYWNlc1wiO1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW293bmVkU3BhY2VdKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICAvLyBCcm93c2Ugc3RpbGwgd29ya3Mg4oCUIHRoZSBvd25lZCBzcGFjZSBpcyBsaXN0ZWQgKHNwYWNlczp1c2VyKS5cbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJNeSBzcGFjZVwiKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICAvLyAuLi5idXQgdGhlIGFkbWluIGFmZm9yZGFuY2UgaXMgYWJzZW50IG9uIHRoZSByYWlsIChubyBzcGFjZXM6YWRtaW4gaGVyZSkuXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcIk1hbmFnZVwiKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgLy8gVGhlIGludml0ZWUtc2lkZSBpbmJveCAoc3BhY2VzOnVzZXIpIGlzIHJldGFpbmVkIOKAlCBhIHB1c2hlZCBpbnZpdGUgcmVuZGVycy5cbiAgICBhd2FpdCBwdXNoSW52aXRlcyhbeyBzcGFjZUlkOiBcInM5XCIsIHVpZDogXCJ1LW1lXCIsIHJvbGU6IFwicmVhZGVyXCIsIG93bmVyOiBcInUtb3duZXJcIiwgaW52aXRlZEJ5OiBcInUtb3duZXJcIiwgbmFtZTogXCJTaGFyZWQgZG9jc1wiIH0gYXMgSW52aXRlXSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiSW52aXRhdGlvbnNcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KFwidGhlIGZ1bGwtdGFiIHN1cmZhY2UgRE9FUyBleHBvc2UgTWFuYWdlIGZvciBhbiBvd25lZCBzcGFjZSAocGFnZS5zcGFjZXMpXCIsIGFzeW5jICgpID0+IHtcbiAgICByZWdpb25TdGF0ZS5jdXJyZW50ID0gXCJwYWdlLnNwYWNlc1wiO1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW293bmVkU3BhY2VdKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJNYW5hZ2VcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KFwiUjMtMjY5OiBhbiBgb3Blbi1zcGFjZWAgYm9vdCBoaW50IGF1dG8tb3BlbnMgTWFuYWdlIGF0IHRoYXQgb3duZWQgc3BhY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlZ2lvblN0YXRlLmN1cnJlbnQgPSBcInBhZ2Uuc3BhY2VzXCI7XG4gICAgdGFza0lucHV0U3RhdGUuY3VycmVudCA9IHsgdGFzazogXCJvcGVuLXNwYWNlXCIsIHBhcmFtczogeyBzcGFjZUlkOiBcInMxXCIgfSB9O1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW293bmVkU3BhY2VdKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBjb25zdCBkaWFsb2cgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImRpYWxvZ1wiLCB7IG5hbWU6IFwiTWFuYWdlIHNwYWNlXCIgfSk7XG4gICAgZXhwZWN0KGRpYWxvZykudG9IYXZlVGV4dENvbnRlbnQoXCJNeSBzcGFjZVwiKTtcbiAgfSk7XG5cbiAgaXQoXCJSMy0yNjk6IGFuIGBvcGVuLXNwYWNlYCBoaW50IGZvciBhIG5vbi1vd25lZCAvIHVua25vd24gc3BhY2Ugb3BlbnMgbm90aGluZ1wiLCBhc3luYyAoKSA9PiB7XG4gICAgcmVnaW9uU3RhdGUuY3VycmVudCA9IFwicGFnZS5zcGFjZXNcIjtcbiAgICB0YXNrSW5wdXRTdGF0ZS5jdXJyZW50ID0geyB0YXNrOiBcIm9wZW4tc3BhY2VcIiwgcGFyYW1zOiB7IHNwYWNlSWQ6IFwibm90LW1pbmVcIiB9IH07XG4gICAgbGlzdEFsbFNwYWNlcy5tb2NrUmVzb2x2ZWRWYWx1ZShbb3duZWRTcGFjZV0pO1xuXG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiTWFuYWdlXCIpOyAvLyBsaXN0IHJlbmRlcmVkXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcImRpYWxvZ1wiLCB7IG5hbWU6IFwiTWFuYWdlIHNwYWNlXCIgfSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcInRoZSBpbnZpdGUgcm93IGNhbm5vdCBwdXNoIGEgY29udHJvbCBvdXRzaWRlIHRoZSBkaWFsb2cgKFIzLTI1NiAvIGRyaWxsIEY0KVwiLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gVGhlIHJlcG9ydGVkIGZhaWx1cmU6IG9uIGEgbmFycm93IGRpYWxvZyB0aGUgcm9sZSBzZWxlY3Qgc3BpbGxlZCBvdXRzaWRlIGFuZFxuICAgIC8vIHRoZSBzdWJtaXQgYnV0dG9uIHdhcyBcImNsaXBwZWQvaW52aXNpYmxlOyBvbmx5IHJlYWNoYWJsZSBieSBUYWJcIi4ganNkb20gZG9lc1xuICAgIC8vIG5vdCBsYXkgb3V0LCBzbyB0aGlzIGNhbm5vdCBiZSBhc3NlcnRlZCBpbiBwaXhlbHMg4oCUIGJ1dCBpdCBET0VTIGNhc2NhZGUgYVxuICAgIC8vIHN0eWxlc2hlZXQgaW50byBnZXRDb21wdXRlZFN0eWxlLCBzbyB0aGUgdHdvIHByb3BlcnRpZXMgdGhhdCBtYWtlIHRoZVxuICAgIC8vIG92ZXJmbG93IGltcG9zc2libGUgYXJlIGFzc2VydGVkIG9uIHRoZSBSRUFMIHJlbmRlcmVkIGNvbnRyb2xzIHdpdGggdGhlIFJFQUxcbiAgICAvLyBzaGlwcGVkIHN0eWxlc2hlZXQsIG5vdCBieSBncmVwcGluZyB0aGUgQ1NTIGZpbGU6XG4gICAgLy9cbiAgICAvLyAgIMK3IHRoZSByb3cgd3JhcHMgIOKHkiBhIGNvbnRyb2wgdGhhdCB3aWxsIG5vdCBmaXQgbW92ZXMgdG8gdGhlIG5leHQgbGluZVxuICAgIC8vICAgICAgICAgICAgICAgICAgICAgIGluc3RlYWQgb2YgYmVpbmcgcHVzaGVkIHBhc3QgdGhlIG1vZGFsIGVkZ2U7XG4gICAgLy8gICDCtyB0aGUgZ3Jvd2luZyBpbnB1dCBjYW4gc2hyaW5rIGJlbG93IGl0cyBjb250ZW50IHdpZHRoIOKHkiBpdCBnaXZlcyB3YXlcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICBmaXJzdCwgc28gdGhlIHJvdyBvbmx5IHdyYXBzIHdoZW4gaXQgZ2VudWluZWx5IG11c3QuXG4gICAgLy9cbiAgICAvLyBBIGZsZXggaXRlbSBkZWZhdWx0cyB0byBgbWluLXdpZHRoOiBhdXRvYCAoaXRzIENPTlRFTlQgbWluaW11bSksIHdoaWNoIGlzXG4gICAgLy8gcHJlY2lzZWx5IHdoeSBgZmxleDogMWAgYWxvbmUgd2FzIG5vdCBlbm91Z2ggYW5kIHRoZSByb3cgb3ZlcmZsb3dlZC5cbiAgICAvLyBSRVNJRFVBTDogdGhlIHRydWUgZ2VvbWV0cmljIGNoZWNrIChcIm5vdGhpbmcgaXMgY2xpcHBlZCBhdCAzMjBweFwiKSBuZWVkcyBhXG4gICAgLy8gYnJvd3NlcjsgdGhpcyByZXBvIGhhcyBubyBsYXlvdXQtY2FwYWJsZSBoYXJuZXNzLlxuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtvd25lZFNwYWNlXSk7XG5cbiAgICAvLyBHdWFyZCBhZ2FpbnN0IHRoZSB2YWN1b3VzIHBhc3M6IGlmIENTUyBwcm9jZXNzaW5nIGlzIGV2ZXIgZGlzYWJsZWQgYWdhaW4sXG4gICAgLy8gdGhlIHNoZWV0IGlzIGVtcHR5LCBldmVyeSBjb21wdXRlZCB2YWx1ZSBmYWxscyBiYWNrIHRvIGl0cyBpbml0aWFsIHZhbHVlLFxuICAgIC8vIGFuZCB0aGUgYXNzZXJ0aW9ucyBiZWxvdyB3b3VsZCBcInBhc3NcIiB3aGlsZSB0ZXN0aW5nIG5vdGhpbmcuXG4gICAgZXhwZWN0KHNwYWNlTWFuYWdlckNzcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgICBjb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKTtcbiAgICBzdHlsZS50ZXh0Q29udGVudCA9IHNwYWNlTWFuYWdlckNzcztcbiAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKTtcblxuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiTWFuYWdlXCIpKTtcbiAgICBjb25zdCBkaWFsb2cgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImRpYWxvZ1wiKTtcblxuICAgIGNvbnN0IGlucHV0ID0gd2l0aGluKGRpYWxvZykuZ2V0QnlQbGFjZWhvbGRlclRleHQoXCJoYW5kbGVcIik7XG4gICAgY29uc3Qgcm93ID0gaW5wdXQucGFyZW50RWxlbWVudCBhcyBIVE1MRWxlbWVudDtcbiAgICBjb25zdCBzZWxlY3QgPSB3aXRoaW4oZGlhbG9nKS5nZXRBbGxCeVJvbGUoXCJjb21ib2JveFwiKVswXTtcbiAgICBjb25zdCBzdWJtaXQgPSB3aXRoaW4oZGlhbG9nKS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkludml0ZVwiIH0pO1xuXG4gICAgLy8gQWxsIHRocmVlIGNvbnRyb2xzIHJlYWxseSBhcmUgaW4gb25lIHJvdyDigJQgdGhlIHByZW1pc2Ugb2YgdGhlIGZhaWx1cmUuXG4gICAgZXhwZWN0KHJvdykudG9Db250YWluRWxlbWVudChzZWxlY3QpO1xuICAgIGV4cGVjdChyb3cpLnRvQ29udGFpbkVsZW1lbnQoc3VibWl0KTtcblxuICAgIGV4cGVjdChnZXRDb21wdXRlZFN0eWxlKHJvdykuZmxleFdyYXApLnRvQmUoXCJ3cmFwXCIpO1xuICAgIGV4cGVjdChnZXRDb21wdXRlZFN0eWxlKGlucHV0KS5taW5XaWR0aCkudG9CZShcIjBweFwiKTtcblxuICAgIHN0eWxlLnJlbW92ZSgpO1xuICB9KTtcblxuICBpdChcImFuIGludml0ZSB3aG9zZSBuYW1lL2ludml0ZWRCeSBjb250YWlucyBtYXJrdXAgcmVuZGVycyBhcyBpbmVydCB0ZXh0IChlc2NhcGVkKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgbWFya3VwID0gJzxpbWcgc3JjPXggb25lcnJvcj1cImFsZXJ0KDEpXCI+JztcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcblxuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSByZW5kZXIoPFNwYWNlTWFuYWdlciAvPik7XG4gICAgYXdhaXQgcHVzaEludml0ZXMoW1xuICAgICAgeyBzcGFjZUlkOiBcInM5XCIsIHVpZDogXCJ1LW1lXCIsIHJvbGU6IFwicmVhZGVyXCIsIG93bmVyOiBcInUtb3duZXJcIiwgaW52aXRlZEJ5OiBtYXJrdXAsIG5hbWU6IG1hcmt1cCB9LFxuICAgIF0pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiSW52aXRhdGlvbnNcIik7XG4gICAgLy8gVGhlIG1hcmt1cCBpcyBwcmVzZW50IGFzIFRFWFQsIGFuZCBwcm9kdWNlZCBubyBpbmplY3RlZCA8aW1nPiBlbGVtZW50LlxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KC9pbnZpdGVkIHlvdSB0by9pKS50ZXh0Q29udGVudCkudG9Db250YWluKG1hcmt1cCk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCdpbWdbc3JjPVwieFwiXScpKS50b0JlTnVsbCgpO1xuICB9KTtcbn0pO1xuXG4vLyBSMy0yMDYgKEdPT0dMRV9JREVOVElUWV9BTkRfRFJJVkVfU1BFQyDCpzguMjsgU1BBQ0VTX1VJX1NQRUMgwqc0L8KnNSBSLVNQQUNFUy02KSDigJRcbi8vIFwiQ29ubmVjdCBhIG5ldyBzb3VyY2Ug4oaSIEdvb2dsZSBEcml2ZVwiLlxuLy9cbi8vIFdoYXQgdGhpcyBhcHAgaXMgcmVzcG9uc2libGUgZm9yIGlzIHNtYWxsIGFuZCB0aGUgdGVzdHMgc2F5IHNvOiBpdCBuYW1lcyB0aGVcbi8vIFNDSEVNRSwgYW5kIGl0IHJlZmxlY3RzIHRoZSByZXN1bHQuIEV2ZXJ5IGF1dGhvcml0eSBzdGVwIOKAlCB0aGUgaW5jcmVtZW50YWwgR29vZ2xlXG4vLyBjb25zZW50LCB0aGUgZm9sZGVyIGJyb3dzZXIsIHRoZSByb3xydyBjaG9pY2UsIHRoZSBzaW5nbGUtd3JpdGVyIGRpc2Nsb3N1cmUg4oCUIGlzXG4vLyBkcmF3biBieSB0aGUgSE9TVCwgYW5kIGl0cyB0ZXN0cyBsaXZlIHRoZXJlIChgQ29ubmVjdFNvdXJjZURpYWxvZy50ZXN0LnRzeGApLiBUaGVcbi8vIHRoaW5nIHdvcnRoIHBpbm5pbmcgSEVSRSBpcyB0aGF0IHRoaXMgYXBwIHBhaW50cyBub25lIG9mIGl0OiBhIGZvcmtlZCBzcGFjZS1tYW5hZ2VyXG4vLyB0aGF0IHRyaWVkIHRvIHdvdWxkIGJlIGRyYXdpbmcgaXRzIG93biBjb25zZW50LCB3aGljaCDCpzguMyBmb3JiaWRzLlxuZGVzY3JpYmUoXCJjb25uZWN0aW5nIGEgbmV3IHNvdXJjZSAoUjMtMjA2KVwiLCAoKSA9PiB7XG4gIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIHByb3RvY29sUmVxdWVzdC5tb2NrUmVzZXQoKTtcbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja1Jlc29sdmVkVmFsdWUoeyBpZDogXCJkcml2ZTpmb2xkZXItMVwiIH0pO1xuICAgIHJlZ2lvblN0YXRlLmN1cnJlbnQgPSBcInBhZ2Uuc3BhY2VzXCI7XG4gIH0pO1xuXG4gIGl0KFwiQ09OTkVDVCBpcyBhIGRpc3RpbmN0IGFjdGlvbiBmcm9tIENSRUFURSDigJQgYm90aCBhcmUgb2ZmZXJlZCwgYW5kIHRoZXkgYXJlIG5vdCB0aGUgc2FtZSBidXR0b25cIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIGByZXF1ZXN0TW91bnQoKWAgc2VsZWN0cyBmcm9tIHdoYXQgdGhlIHVzZXIgYWxyZWFkeSBoYXM7IGNvbm5lY3QgU0VUUyBPTkUgVVAuXG4gICAgLy8gQ29sbGFwc2luZyB0aGVtIGlzIHRoZSBzaGFwZSDCpzguMiBydWxlcyBvdXQsIGJlY2F1c2UgYSBwaWNrZXIgdGhhdCBzb21ldGltZXNcbiAgICAvLyBuYXZpZ2F0ZXMgdGhlIHBhZ2UgdG8gR29vZ2xlIGlzIG5vdCBhIHBpY2tlci5cbiAgICByZW5kZXIoPFNwYWNlTWFuYWdlciAvPik7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJDb25uZWN0IEdvb2dsZSBEcml2ZVwiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJDcmVhdGUgYSBzcGFjZVwiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcIm5hbWVzIG9ubHkgdGhlIFNDSEVNRSDigJQgbm8gc2NvcGUsIG5vIGZvbGRlciwgbm8gd29yZGluZ1wiLCBhc3luYyAoKSA9PiB7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQ29ubmVjdCBHb29nbGUgRHJpdmVcIiB9KSk7XG5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChwcm90b2NvbFJlcXVlc3QpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKSk7XG4gICAgZXhwZWN0KHByb3RvY29sUmVxdWVzdCkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCJwcm90b2NvbC1zcGFjZXNcIiwgXCJjb25uZWN0U291cmNlXCIsIFt7IHNjaGVtZTogXCJkcml2ZVwiIH1dKTtcbiAgfSk7XG5cbiAgaXQoXCJwYWludHMgTk8gYXV0aG9yaXphdGlvbiBjaHJvbWUgb2YgaXRzIG93blwiLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gVGhlIHdob2xlIMKnOC4zIHJ1bGUgaW4gb25lIGFzc2VydGlvbjogYWZ0ZXIgdGhlIGNsaWNrLCB0aGlzIGFwcCBzaG93cyBhIGJ1c3lcbiAgICAvLyBsYWJlbCBhbmQgbm90aGluZyBlbHNlLiBObyBzY29wZSB0ZXh0LCBubyBmb2xkZXIgbGlzdCwgbm8gcm8vcncgY2hvaWNlIOKAlCB0aG9zZVxuICAgIC8vIGV4aXN0IG9ubHkgaW4gaG9zdCBjaHJvbWUsIHdoaWNoIGEgZm9yayBjYW5ub3QgcmVwbGFjZS5cbiAgICBsZXQgcmVzb2x2ZTogKHY6IHVua25vd24pID0+IHZvaWQgPSAoKSA9PiB7fTtcbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja1JldHVyblZhbHVlKG5ldyBQcm9taXNlKChyKSA9PiB7IHJlc29sdmUgPSByOyB9KSk7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQ29ubmVjdCBHb29nbGUgRHJpdmVcIiB9KSk7XG5cbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkNvbm5lY3RpbmfigKZcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KC9kcml2ZVxcLmZpbGUvKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dCgvc2luZ2xlLXdyaXRlci9pKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9SZWFkIGFuZCB3cml0ZS8gfSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7IHJlc29sdmUoe30pOyB9KTtcbiAgfSk7XG5cbiAgaXQoXCJ0cmVhdHMgYGNhbmNlbGxlZGAgYXMgY2FsbSDigJQgdGhlIHVzZXIgYmFja2VkIG91dCwgbm90aGluZyBmYWlsZWRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHByb3RvY29sUmVxdWVzdC5tb2NrUmVqZWN0ZWRWYWx1ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcImNhbmNlbGxlZFwiKSwgeyBjb2RlOiBcImNhbmNlbGxlZFwiIH0pKTtcbiAgICByZW5kZXIoPFNwYWNlTWFuYWdlciAvPik7XG4gICAgYXdhaXQgdXNlckV2ZW50LmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJDb25uZWN0IEdvb2dsZSBEcml2ZVwiIH0pKTtcblxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkNvbm5lY3QgR29vZ2xlIERyaXZlXCIgfSkpLnRvQmVFbmFibGVkKCkpO1xuICAgIGV4cGVjdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnNtLWVyclwiKSkudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoXCJzYXlzIHdoYXQgdG8gRE8gd2hlbiB0aGUgR29vZ2xlIGNvbm5lY3Rpb24gbmVlZHMgcmUtYXV0aG9yaXppbmdcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIGBnb29nbGVfcmVhdXRoX3JlcXVpcmVkYCBpcyBub3QgXCJzb21ldGhpbmcgd2VudCB3cm9uZ1wiOiB0aGUgcmVtZWR5IGlzIGFcbiAgICAvLyBzcGVjaWZpYyBwYWdlLCBhbmQgYSBnZW5lcmljIG1lc3NhZ2Ugd291bGQgbGVhdmUgdGhlIHVzZXIgd2l0aCBubyBuZXh0IHN0ZXAuXG4gICAgcHJvdG9jb2xSZXF1ZXN0Lm1vY2tSZWplY3RlZFZhbHVlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwieFwiKSwgeyBjb2RlOiBcImdvb2dsZV9yZWF1dGhfcmVxdWlyZWRcIiB9KSk7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQ29ubmVjdCBHb29nbGUgRHJpdmVcIiB9KSk7XG5cbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoL1JlY29ubmVjdCBHb29nbGUgaW4gU2V0dGluZ3MvKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJzYXlzIHNvIHBsYWlubHkgd2hlbiB0aGUgZGVwbG95bWVudCBoYXMgbm8gRHJpdmUgY29ubmVjdG9yXCIsIGFzeW5jICgpID0+IHtcbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja1JlamVjdGVkVmFsdWUoT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoXCJ4XCIpLCB7IGNvZGU6IFwidW5zdXBwb3J0ZWQtc2NoZW1lXCIgfSkpO1xuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkNvbm5lY3QgR29vZ2xlIERyaXZlXCIgfSkpO1xuXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KC9pc27igJl0IGF2YWlsYWJsZSBvbiB0aGlzIGRlcGxveW1lbnQvKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJpcyBhYnNlbnQgZnJvbSB0aGUgbmFycm93IHBhbmVsIOKAlCB0aGUgcmFpbCBleHBvc2VzIG5vIHNldHVwIHZlcmJcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFNhbWUgcnVsZSBhcyB0aGUgYWRtaW4gc3VyZmFjZXMgKFIzLTk2IC8gUFJJTkNJUEFMUyDCpzkgQjMpOiB0aGUgcmFpbCBpc1xuICAgIC8vIGJyb3dzZS9vcGVuL21vdW50LW9ubHkuXG4gICAgcmVnaW9uU3RhdGUuY3VycmVudCA9IFwicGFuZWwuc3BhY2VzXCI7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiU3BhY2VzXCIpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkNvbm5lY3QgR29vZ2xlIERyaXZlXCIgfSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcbn0pO1xuXG4vLyBSMy0yNTkg4oCUIHRoZSBzcGFjZSdzIEtJTkQ6IGNob3NlbiBhdCBjcmVhdGUsIHZpc2libGUgaW4gdGhlIGxpc3QsIGNvbnZlcnRlZFxuLy8gb25jZSB2aWEgYSBuYW1lZCBhcm0tdGhlbi1jb25maXJtIGFjdC4gYGtpbmRgIHJpZGVzIHRoZSB3aXJlIGFkZGl0aXZlbHkgKHRoZVxuLy8gaG9zdCBkZXJpdmVzL3ZhbGlkYXRlcyBpdCk7IHRoZXNlIHRlc3RzIHBpbiB3aGF0IHRoZSBhcHAgc2VuZHMgYW5kIHNob3dzLlxuZGVzY3JpYmUoXCJSMy0yNTkg4oCUIGEgc3BhY2UncyBraW5kXCIsICgpID0+IHtcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgdmkuY2xlYXJBbGxNb2NrcygpO1xuICAgIHJlZ2lvblN0YXRlLmN1cnJlbnQgPSBcInBhZ2Uuc3BhY2VzXCI7XG4gICAgdGFza0lucHV0U3RhdGUuY3VycmVudCA9IG51bGw7XG4gICAgaW52aXRlU3RhdGUuY3VycmVudCA9IFtdO1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIGdldFNwYWNlTWVtYmVycy5tb2NrUmVzb2x2ZWRWYWx1ZShbXSk7XG4gICAgbGlzdFBlbmRpbmdJbnZpdGVzLm1vY2tSZXNvbHZlZFZhbHVlKFtdKTtcbiAgICBjcmVhdGVTcGFjZU1vY2subW9ja1Jlc29sdmVkVmFsdWUodW5kZWZpbmVkKTtcbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja1Jlc29sdmVkVmFsdWUoeyBvazogdHJ1ZSB9KTtcbiAgfSk7XG5cbiAgaXQoXCJjcmVhdGUgZGVmYXVsdHMgdG8gcGVyc29uYWwgYW5kIHNlbmRzIHRoZSBraW5kXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPFNwYWNlTWFuYWdlciAvPik7XG4gICAgYXdhaXQgdXNlckV2ZW50LmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJDcmVhdGUgYSBzcGFjZVwiIH0pKTtcbiAgICBleHBlY3QoY3JlYXRlU3BhY2VNb2NrKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh7IGtpbmQ6IFwicGVyc29uYWxcIiB9KTtcbiAgfSk7XG5cbiAgaXQoXCJjaG9vc2luZyBTaGFyZWQgc2VuZHMgc2hhcmVkXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPFNwYWNlTWFuYWdlciAvPik7XG4gICAgYXdhaXQgdXNlckV2ZW50LmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlNoYXJlZFwiIH0pKTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQ3JlYXRlIGEgc3BhY2VcIiB9KSk7XG4gICAgZXhwZWN0KGNyZWF0ZVNwYWNlTW9jaykudG9IYXZlQmVlbkNhbGxlZFdpdGgoeyBraW5kOiBcInNoYXJlZFwiIH0pO1xuICB9KTtcblxuICBpdChcImJhZGdlcyBvbmx5IFNIQVJFRCBzcGFjZXMg4oCUIHBlcnNvbmFsIGlzIHRoZSB1bm1hcmtlZCBkZWZhdWx0XCIsIGFzeW5jICgpID0+IHtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFtcbiAgICAgIHsgc3BhY2VJZDogXCJzMVwiLCBuYW1lOiBcIk1pbmVcIiwgcm9sZTogXCJvd25lclwiLCBraW5kOiBcInBlcnNvbmFsXCIgfSBhcyBTcGFjZUluZm8sXG4gICAgICB7IHNwYWNlSWQ6IFwiczJcIiwgbmFtZTogXCJPdXJzXCIsIHJvbGU6IFwib3duZXJcIiwga2luZDogXCJzaGFyZWRcIiB9IGFzIFNwYWNlSW5mbyxcbiAgICAgIHsgc3BhY2VJZDogXCJzM1wiLCBuYW1lOiBcIkxlZ2FjeVwiLCByb2xlOiBcIm93bmVyXCIgfSBhcyBTcGFjZUluZm8sIC8vIHByZS1SMy0yNTkgcm93OiB1bmJhZGdlZFxuICAgIF0pO1xuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBjb25zdCBvdXJzID0gKGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiT3Vyc1wiKSkuY2xvc2VzdChcImxpXCIpITtcbiAgICBleHBlY3Qod2l0aGluKG91cnMgYXMgSFRNTEVsZW1lbnQpLmdldEJ5VGV4dChcInNoYXJlZFwiKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBjb25zdCBtaW5lID0gc2NyZWVuLmdldEJ5VGV4dChcIk1pbmVcIikuY2xvc2VzdChcImxpXCIpITtcbiAgICBleHBlY3Qod2l0aGluKG1pbmUgYXMgSFRNTEVsZW1lbnQpLnF1ZXJ5QnlUZXh0KFwic2hhcmVkXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBjb25zdCBsZWdhY3kgPSBzY3JlZW4uZ2V0QnlUZXh0KFwiTGVnYWN5XCIpLmNsb3Nlc3QoXCJsaVwiKSE7XG4gICAgZXhwZWN0KHdpdGhpbihsZWdhY3kgYXMgSFRNTEVsZW1lbnQpLnF1ZXJ5QnlUZXh0KFwic2hhcmVkXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgb3duZXIncyBwZXJzb25hbCBzcGFjZSBvZmZlcnMgQ29udmVydDsgYXJtaW5nIHNob3dzIHRoZSBpcnJldmVyc2liaWxpdHk7IGNvbmZpcm1pbmcgaGl0cyB0aGUgdmVyYiBvbmNlXCIsIGFzeW5jICgpID0+IHtcbiAgICBsaXN0QWxsU3BhY2VzLm1vY2tSZXNvbHZlZFZhbHVlKFt7IHNwYWNlSWQ6IFwiczFcIiwgbmFtZTogXCJNaW5lXCIsIHJvbGU6IFwib3duZXJcIiwga2luZDogXCJwZXJzb25hbFwiIH0gYXMgU3BhY2VJbmZvXSk7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTWFuYWdlXCIgfSkpO1xuXG4gICAgY29uc3QgYXJtID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvQ29udmVydCB0byBzaGFyZWTigKYvIH0pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhcm0pOyAvLyBmaXJzdCBjbGljayBBUk1TXG4gICAgZXhwZWN0KHByb3RvY29sUmVxdWVzdCkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAvLyBUaGUgYXJtZWQgc3RhdGUgaXMgdGhlIGJ1dHRvbiB0aGF0IG5vdyBTQVlTIHdoYXQgaXQgZG9lcy5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9Db252ZXJ0IHRvIHNoYXJlZCDigJQgY2Fubm90IGJlIHVuZG9uZS8gfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG5cbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9Db252ZXJ0IHRvIHNoYXJlZCDigJQgY2Fubm90IGJlIHVuZG9uZS8gfSkpO1xuICAgIGV4cGVjdChwcm90b2NvbFJlcXVlc3QpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwicHJvdG9jb2wtc3BhY2VzXCIsIFwiY29udmVydFRvU2hhcmVkXCIsIFt7IHNwYWNlSWQ6IFwiczFcIiwgY29uZmlybTogdHJ1ZSB9XSk7XG4gICAgZXhwZWN0KHByb3RvY29sUmVxdWVzdCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICB9KTtcblxuICBpdChcImFmdGVyIGNvbnZlcnRpbmcsIHRoZSByZWZyZXNoZWQgbGlzdCBzaG93cyB0aGUgc2hhcmVkIGJhZGdlXCIsIGFzeW5jICgpID0+IHtcbiAgICBsZXQga2luZDogc3RyaW5nIHwgdW5kZWZpbmVkID0gXCJwZXJzb25hbFwiO1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja0ltcGxlbWVudGF0aW9uKGFzeW5jICgpID0+IFt7IHNwYWNlSWQ6IFwiczFcIiwgbmFtZTogXCJNaW5lXCIsIHJvbGU6IFwib3duZXJcIiwga2luZCB9IGFzIFNwYWNlSW5mb10pO1xuICAgIHJlbmRlcig8U3BhY2VNYW5hZ2VyIC8+KTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIk1hbmFnZVwiIH0pKTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvQ29udmVydCB0byBzaGFyZWTigKYvIH0pKTtcbiAgICAvLyBUaGUgdmVyYiByZXNvbHZpbmcgZmxpcHMgd2hhdCB0aGUgKG1vY2spIGhvc3QgbGlzdHMgbmV4dC5cbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja0ltcGxlbWVudGF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGtpbmQgPSBcInNoYXJlZFwiO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9KTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9Db252ZXJ0IHRvIHNoYXJlZCDigJQgY2Fubm90IGJlIHVuZG9uZS8gfSkpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT5cbiAgICAgIGV4cGVjdCh3aXRoaW4oc2NyZWVuLmdldEJ5VGV4dChcIk1pbmVcIikuY2xvc2VzdChcImxpXCIpIGFzIEhUTUxFbGVtZW50KS5nZXRCeVRleHQoXCJzaGFyZWRcIikpLnRvQmVJblRoZURvY3VtZW50KCksXG4gICAgKTtcbiAgfSk7XG5cbiAgaXQoXCJhIFNIQVJFRCBzcGFjZSdzIE1hbmFnZSBtb2RhbCBvZmZlcnMgbm8gY29udmVyc2lvbiDigJQgdGhlcmUgaXMgbm8gd2F5IGJhY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGxpc3RBbGxTcGFjZXMubW9ja1Jlc29sdmVkVmFsdWUoW3sgc3BhY2VJZDogXCJzMlwiLCBuYW1lOiBcIk91cnNcIiwgcm9sZTogXCJvd25lclwiLCBraW5kOiBcInNoYXJlZFwiIH0gYXMgU3BhY2VJbmZvXSk7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTWFuYWdlXCIgfSkpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KC9TaGFyZSDigJxPdXJz4oCdLyk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9Db252ZXJ0IHRvIHNoYXJlZC8gfSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcImEgZm9yYmlkZGVuIGNvbnZlcnNpb24gc3VyZmFjZXMgdGhlIG93bmVyLW9ubHkgbWVzc2FnZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgbGlzdEFsbFNwYWNlcy5tb2NrUmVzb2x2ZWRWYWx1ZShbeyBzcGFjZUlkOiBcInMxXCIsIG5hbWU6IFwiTWluZVwiLCByb2xlOiBcIm93bmVyXCIsIGtpbmQ6IFwicGVyc29uYWxcIiB9IGFzIFNwYWNlSW5mb10pO1xuICAgIHByb3RvY29sUmVxdWVzdC5tb2NrUmVqZWN0ZWRWYWx1ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcInhcIiksIHsgY29kZTogXCJmb3JiaWRkZW5cIiB9KSk7XG4gICAgcmVuZGVyKDxTcGFjZU1hbmFnZXIgLz4pO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTWFuYWdlXCIgfSkpO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9Db252ZXJ0IHRvIHNoYXJlZOKApi8gfSkpO1xuICAgIGF3YWl0IHVzZXJFdmVudC5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogL0NvbnZlcnQgdG8gc2hhcmVkIOKAlCBjYW5ub3QgYmUgdW5kb25lLyB9KSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KC9Pbmx5IHRoZSBvd25lciBjYW4gY29udmVydCB0aGlzIHNwYWNlLykpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFJQSxJQUFBQSxLQUFBLEdBQUFDLHVCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxVQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSSxPQUFBLEdBQUFKLE9BQUE7QUFLQSxJQUFBSyxhQUFBLEdBQUFGLHNCQUFBLENBQUFILE9BQUE7QUE0REEsSUFBQU0sY0FBQSxHQUFBSCxzQkFBQSxDQUFBSCxPQUFBO0FBQTBDLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLFNBQUFHLHVCQUFBSyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBQUEsU0FBQUcseUJBQUFILENBQUEsNkJBQUFJLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUQsd0JBQUEsWUFBQUEsQ0FBQUgsQ0FBQSxXQUFBQSxDQUFBLEdBQUFNLENBQUEsR0FBQUQsQ0FBQSxLQUFBTCxDQUFBO0FBQUEsU0FBQVQsd0JBQUFTLENBQUEsRUFBQUssQ0FBQSxTQUFBQSxDQUFBLElBQUFMLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLFNBQUFELENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBRSxPQUFBLEVBQUFGLENBQUEsUUFBQU0sQ0FBQSxHQUFBSCx3QkFBQSxDQUFBRSxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxHQUFBLENBQUFQLENBQUEsVUFBQU0sQ0FBQSxDQUFBRSxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBUCxPQUFBLEdBQUFGLENBQUEsRUFBQU0sQ0FBQSxJQUFBQSxDQUFBLENBQUFhLEdBQUEsQ0FBQW5CLENBQUEsRUFBQVMsQ0FBQSxHQUFBQSxDQUFBO0FBeEUxQztBQUNBO0FBQ0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQSxNQUFNVyxhQUFhLEdBQUdDLFVBQUUsQ0FBQ0MsRUFBRSxDQUE2QixDQUFDO0FBQ3pELE1BQU1DLGVBQWUsR0FBR0YsVUFBRSxDQUFDQyxFQUFFLENBQTBCLENBQUM7QUFDeEQsTUFBTUUsa0JBQWtCLEdBQUdILFVBQUUsQ0FBQ0MsRUFBRSxDQUEwQixDQUFDO0FBQzNELE1BQU1HLGFBQWEsR0FBR0osVUFBRSxDQUFDQyxFQUFFLENBQXNCLENBQUM7QUFDbEQsTUFBTUksWUFBWSxHQUFHTCxVQUFFLENBQUNDLEVBQUUsQ0FBc0IsQ0FBQztBQUNqRCxNQUFNSyxhQUFhLEdBQUdOLFVBQUUsQ0FBQ0MsRUFBRSxDQUFzQixDQUFDO0FBQ2xELE1BQU1NLFlBQVksR0FBR1AsVUFBRSxDQUFDQyxFQUFFLENBQXNCLENBQUM7QUFDakQ7QUFDQSxNQUFNTyxlQUFlLEdBQUdSLFVBQUUsQ0FBQ0MsRUFBRSxDQUFvQyxDQUFDOztBQUVsRTtBQUNBO0FBQ0EsTUFBTVEsV0FBVyxHQUFHVCxVQUFFLENBQUNVLE9BQU8sQ0FBQyxPQUFPO0VBQUVDLE9BQU8sRUFBRSxFQUFlO0VBQUVDLFNBQVMsRUFBRSxJQUFJQyxHQUFHLENBQWE7QUFBRSxDQUFDLENBQUMsQ0FBQzs7QUFFdEc7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsV0FBVyxHQUFHZCxVQUFFLENBQUNVLE9BQU8sQ0FBQyxPQUFPO0VBQUVDLE9BQU8sRUFBRTtBQUF3QixDQUFDLENBQUMsQ0FBQzs7QUFFNUU7QUFDQTtBQUNBLE1BQU1JLGNBQWMsR0FBR2YsVUFBRSxDQUFDVSxPQUFPLENBQUMsT0FBTztFQUN2Q0MsT0FBTyxFQUFFO0FBQ1gsQ0FBQyxDQUFDLENBQUM7O0FBRUg7QUFDQTtBQUNBO0FBQ0EsTUFBTUssZUFBZSxHQUFHaEIsVUFBRSxDQUFDQyxFQUFFLENBQThELENBQUM7QUFDNUZELFVBQUUsQ0FBQ2lCLElBQUksQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPO0VBQUVELGVBQWUsRUFBRUEsQ0FBQyxHQUFHMUIsQ0FBWSxLQUFLMEIsZUFBZSxDQUFDLEdBQUkxQixDQUFpQztBQUFFLENBQUMsQ0FBQyxDQUFDO0FBRXRKVSxVQUFFLENBQUNpQixJQUFJLENBQUMsc0JBQXNCLEVBQUU7RUFBQSxJQUFBQyxFQUFBLEdBQUFDLFlBQUE7RUFBQSxPQUFPO0lBQ3JDcEIsYUFBYSxFQUFFQSxDQUFBLEtBQU1BLGFBQWEsQ0FBQyxDQUFDO0lBQ3BDRyxlQUFlLEVBQUVBLENBQUEsS0FBTUEsZUFBZSxDQUFDLENBQUM7SUFDeENDLGtCQUFrQixFQUFFQSxDQUFBLEtBQU1BLGtCQUFrQixDQUFDLENBQUM7SUFDOUNpQixVQUFVLEVBQUFGLEVBQUEsQ0FBRSxNQUFNO01BQUFBLEVBQUE7TUFDaEIsTUFBTSxHQUFHRyxLQUFLLENBQUMsR0FBR3BELEtBQUssQ0FBQ3FELFVBQVUsQ0FBRUMsQ0FBUyxJQUFLQSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztNQUMzRHRELEtBQUssQ0FBQ3VELFNBQVMsQ0FBQyxNQUFNO1FBQ3BCZixXQUFXLENBQUNHLFNBQVMsQ0FBQ2EsR0FBRyxDQUFDSixLQUFLLENBQUM7UUFDaEMsT0FBTyxNQUFNO1VBQUVaLFdBQVcsQ0FBQ0csU0FBUyxDQUFDYyxNQUFNLENBQUNMLEtBQUssQ0FBQztRQUFFLENBQUM7TUFDdkQsQ0FBQyxFQUFFLEVBQUUsQ0FBQztNQUNOLE9BQU9aLFdBQVcsQ0FBQ0UsT0FBTztJQUM1QixDQUFDO0lBQ0RQLGFBQWEsRUFBRUEsQ0FBQyxHQUFHZCxDQUFZLEtBQUtjLGFBQWEsQ0FBQyxHQUFJZCxDQUFRLENBQUM7SUFDL0RlLFlBQVksRUFBRUEsQ0FBQyxHQUFHZixDQUFZLEtBQUtlLFlBQVksQ0FBQyxHQUFJZixDQUFRLENBQUM7SUFDN0RnQixhQUFhLEVBQUVBLENBQUMsR0FBR2hCLENBQVksS0FBS2dCLGFBQWEsQ0FBQyxHQUFJaEIsQ0FBUSxDQUFDO0lBQy9EaUIsWUFBWSxFQUFFQSxDQUFDLEdBQUdqQixDQUFZLEtBQUtpQixZQUFZLENBQUMsR0FBSWpCLENBQVEsQ0FBQztJQUM3RHFDLFlBQVksRUFBRTNCLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDckIyQixZQUFZLEVBQUU1QixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3JCNEIsVUFBVSxFQUFFN0IsVUFBRSxDQUFDQyxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDakM2QixXQUFXLEVBQUU5QixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3BCOEIsV0FBVyxFQUFFQSxDQUFDLEdBQUd6QyxDQUFZLEtBQUtrQixlQUFlLENBQUMsR0FBSWxCLENBQXNCLENBQUM7SUFDN0UwQyxPQUFPLEVBQUVBLENBQUEsTUFBTztNQUFFQyxNQUFNLEVBQUU7SUFBWSxDQUFDLENBQUM7SUFDeENDLFNBQVMsRUFBRUEsQ0FBQSxLQUFNcEIsV0FBVyxDQUFDSCxPQUFPO0lBQ3BDd0IsWUFBWSxFQUFFQSxDQUFBLEtBQU1wQixjQUFjLENBQUNKO0VBQ3JDLENBQUM7QUFBQSxDQUFDLENBQUM7QUFJSCxNQUFNeUIsVUFBcUIsR0FBRztFQUFFQyxPQUFPLEVBQUUsSUFBSTtFQUFFQyxJQUFJLEVBQUUsVUFBVTtFQUFFQyxJQUFJLEVBQUU7QUFBUSxDQUFjOztBQUU3RjtBQUNBLE1BQU1DLFdBQVcsR0FBSUMsSUFBYyxJQUNqQyxJQUFBQyxXQUFHLEVBQUMsTUFBTTtFQUNSakMsV0FBVyxDQUFDRSxPQUFPLEdBQUc4QixJQUFJO0VBQzFCaEMsV0FBVyxDQUFDRyxTQUFTLENBQUMrQixPQUFPLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUM7QUFFSixJQUFBQyxrQkFBVSxFQUFDLE1BQU07RUFDZixLQUFLLE1BQU1DLENBQUMsSUFBSSxDQUNkL0MsYUFBYSxFQUFFRyxlQUFlLEVBQUVDLGtCQUFrQixFQUNsREMsYUFBYSxFQUFFQyxZQUFZLEVBQUVDLGFBQWEsRUFBRUMsWUFBWSxDQUN6RCxFQUFFdUMsQ0FBQyxDQUFDQyxTQUFTLENBQUMsQ0FBQztFQUNoQnRDLFdBQVcsQ0FBQ0UsT0FBTyxHQUFHLEVBQUU7RUFDeEJHLFdBQVcsQ0FBQ0gsT0FBTyxHQUFHLGFBQWEsQ0FBQyxDQUFDO0VBQ3JDSSxjQUFjLENBQUNKLE9BQU8sR0FBRyxJQUFJO0VBQzdCO0VBQ0FaLGFBQWEsQ0FBQ2lELGlCQUFpQixDQUFDLEVBQUUsQ0FBQztFQUNuQzlDLGVBQWUsQ0FBQzhDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztFQUNyQzdDLGtCQUFrQixDQUFDNkMsaUJBQWlCLENBQUMsRUFBRSxDQUFDO0VBQ3hDNUMsYUFBYSxDQUFDNEMsaUJBQWlCLENBQUNDLFNBQVMsQ0FBQztFQUMxQzVDLFlBQVksQ0FBQzJDLGlCQUFpQixDQUFDQyxTQUFTLENBQUM7RUFDekMzQyxhQUFhLENBQUMwQyxpQkFBaUIsQ0FBQ0MsU0FBUyxDQUFDO0VBQzFDMUMsWUFBWSxDQUFDeUMsaUJBQWlCLENBQUNDLFNBQVMsQ0FBQztBQUMzQyxDQUFDLENBQUM7QUFFRixJQUFBQyxnQkFBUSxFQUFDLG9DQUFvQyxFQUFFLE1BQU07RUFDbkQsSUFBQUMsVUFBRSxFQUFDLDZFQUE2RSxFQUFFLFlBQVk7SUFDNUYsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QnZELGFBQWEsQ0FBQ2lELGlCQUFpQixDQUFDLENBQUNaLFVBQVUsQ0FBQyxDQUFDO0lBQzdDO0lBQ0FsQyxlQUFlLENBQUM4QyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7SUFDckM3QyxrQkFBa0IsQ0FDZm9ELHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUN6QlAsaUJBQWlCLENBQUMsQ0FBQztNQUFFWCxPQUFPLEVBQUUsSUFBSTtNQUFFbUIsR0FBRyxFQUFFLFlBQVk7TUFBRWpCLElBQUksRUFBRSxRQUFRO01BQUVrQixLQUFLLEVBQUUsTUFBTTtNQUFFQyxTQUFTLEVBQUUsTUFBTTtNQUFFQyxLQUFLLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQztJQUU1SCxJQUFBQyxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNdUUsSUFBSSxDQUFDVSxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFbkQsTUFBTUMsTUFBTSxHQUFHLE1BQU1GLGNBQU0sQ0FBQ0csVUFBVSxDQUFDLFFBQVEsQ0FBQztJQUNoRCxNQUFNLElBQUFDLGNBQU0sRUFBQ0YsTUFBTSxDQUFDLENBQUNELFVBQVUsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDSSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUM5RSxNQUFNaEIsSUFBSSxDQUFDaUIsSUFBSSxDQUFDLElBQUFGLGNBQU0sRUFBQ0YsTUFBTSxDQUFDLENBQUNLLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssQ0FBQztJQUNyRSxNQUFNbEIsSUFBSSxDQUFDVSxLQUFLLENBQUMsSUFBQUssY0FBTSxFQUFDRixNQUFNLENBQUMsQ0FBQ00sU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFakMsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDLENBQUM7SUFFeEUsTUFBTSxJQUFBa0MsZUFBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDckUsYUFBYSxDQUFDLENBQUNzRSxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3RGO0lBQ0EsTUFBTSxJQUFBUCxjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDRCxVQUFVLENBQUMsaUJBQWlCLENBQUM7SUFDbEQsSUFBQVMsY0FBTSxFQUFDLElBQUFOLGNBQU0sRUFBQ0YsTUFBTSxDQUFDLENBQUNVLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDO0VBQzlELENBQUMsQ0FBQztFQUVGLElBQUF6QixVQUFFLEVBQUMsK0dBQStHLEVBQUUsWUFBWTtJQUM5SCxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCO0lBQ0E7SUFDQWpELFlBQVksQ0FBQ3dFLGtCQUFrQixDQUFDLFlBQVk7TUFDMUNwRSxXQUFXLENBQUNFLE9BQU8sR0FBRyxFQUFFO01BQ3hCRixXQUFXLENBQUNHLFNBQVMsQ0FBQytCLE9BQU8sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzNDLENBQUMsQ0FBQztJQUNGN0MsYUFBYSxDQUNWd0QscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQ3pCUCxpQkFBaUIsQ0FBQyxDQUFDO01BQUVYLE9BQU8sRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBYyxDQUFDO0lBRTNGLElBQUFxQixjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMkQsV0FBVyxDQUFDLENBQUM7TUFBRUgsT0FBTyxFQUFFLElBQUk7TUFBRW1CLEdBQUcsRUFBRSxNQUFNO01BQUVqQixJQUFJLEVBQUUsUUFBUTtNQUFFa0IsS0FBSyxFQUFFLFNBQVM7TUFBRUMsU0FBUyxFQUFFLFNBQVM7TUFBRXBCLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDO0lBQ2hJLE1BQU15QixjQUFNLENBQUNDLFVBQVUsQ0FBQyxhQUFhLENBQUM7SUFDdEMsSUFBQVMsY0FBTSxFQUFDVixjQUFNLENBQUNZLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNDLGlCQUFpQixDQUFDLENBQUM7SUFFL0QsTUFBTXhCLElBQUksQ0FBQ1UsS0FBSyxDQUFDQyxjQUFNLENBQUNRLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRWpDLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLE1BQU0sSUFBQWtDLGVBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ3BFLFlBQVksQ0FBQyxDQUFDcUUsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEU7SUFDQSxNQUFNLElBQUFGLGVBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ1YsY0FBTSxDQUFDZSxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDSCxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7SUFDdEYsSUFBQUgsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNZLGlCQUFpQixDQUFDLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyxxRkFBcUYsRUFBRSxZQUFZO0lBQ3BHLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUJoRCxhQUFhLENBQUN1RSxrQkFBa0IsQ0FBQyxZQUFZO01BQzNDcEUsV0FBVyxDQUFDRSxPQUFPLEdBQUcsRUFBRTtNQUN4QkYsV0FBVyxDQUFDRyxTQUFTLENBQUMrQixPQUFPLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDLENBQUM7SUFDRjdDLGFBQWEsQ0FBQ2lELGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUVuQyxJQUFBWSxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMkQsV0FBVyxDQUFDLENBQUM7TUFBRUgsT0FBTyxFQUFFLElBQUk7TUFBRW1CLEdBQUcsRUFBRSxNQUFNO01BQUVqQixJQUFJLEVBQUUsUUFBUTtNQUFFa0IsS0FBSyxFQUFFLFNBQVM7TUFBRUMsU0FBUyxFQUFFLFNBQVM7TUFBRXBCLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDO0lBQ2hJLE1BQU15QixjQUFNLENBQUNDLFVBQVUsQ0FBQyxhQUFhLENBQUM7SUFDdEMsTUFBTVosSUFBSSxDQUFDVSxLQUFLLENBQUNDLGNBQU0sQ0FBQ1EsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFakMsSUFBSSxFQUFFO0lBQVUsQ0FBQyxDQUFDLENBQUM7SUFFakUsTUFBTSxJQUFBa0MsZUFBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDbkUsYUFBYSxDQUFDLENBQUNvRSxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNyRSxNQUFNLElBQUFGLGVBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQ1YsY0FBTSxDQUFDZSxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDSCxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7SUFDdEYsSUFBQUgsY0FBTSxFQUFDVixjQUFNLENBQUNlLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUM7RUFDbkUsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQywyREFBMkQsRUFBRSxZQUFZO0lBQzFFLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUJ2RCxhQUFhLENBQUNpRCxpQkFBaUIsQ0FBQyxDQUFDWixVQUFVLENBQUMsQ0FBQztJQUM3Q2xDLGVBQWUsQ0FBQzhDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUNyQzdDLGtCQUFrQixDQUNmb0QscUJBQXFCLENBQUMsQ0FBQztNQUFFbEIsT0FBTyxFQUFFLElBQUk7TUFBRW1CLEdBQUcsRUFBRSxZQUFZO01BQUVqQixJQUFJLEVBQUUsUUFBUTtNQUFFa0IsS0FBSyxFQUFFLE1BQU07TUFBRUMsU0FBUyxFQUFFLE1BQU07TUFBRUMsS0FBSyxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FDN0hYLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUV4QixJQUFBWSxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNdUUsSUFBSSxDQUFDVSxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDbkQsTUFBTUMsTUFBTSxHQUFHLE1BQU1GLGNBQU0sQ0FBQ0csVUFBVSxDQUFDLFFBQVEsQ0FBQztJQUNoRCxNQUFNLElBQUFDLGNBQU0sRUFBQ0YsTUFBTSxDQUFDLENBQUNELFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQztJQUVsRCxNQUFNWixJQUFJLENBQUNVLEtBQUssQ0FBQyxJQUFBSyxjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDTSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVqQyxJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUN4RSxNQUFNLElBQUFrQyxlQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUNsRSxZQUFZLENBQUMsQ0FBQ21FLG9CQUFvQixDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNsRixNQUFNLElBQUFGLGVBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQyxJQUFBTixjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDYSxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUMsQ0FBQztFQUNwRyxDQUFDLENBQUM7RUFFRixJQUFBekIsVUFBRSxFQUFDLDJHQUEyRyxFQUFFLFlBQVk7SUFDMUhyQyxXQUFXLENBQUNILE9BQU8sR0FBRyxjQUFjO0lBQ3BDWixhQUFhLENBQUNpRCxpQkFBaUIsQ0FBQyxDQUFDWixVQUFVLENBQUMsQ0FBQztJQUU3QyxJQUFBd0IsY0FBTSxlQUFDLElBQUFsRixXQUFBLENBQUFtRixHQUFBLEVBQUNwRixjQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEI7SUFDQSxJQUFBNEYsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNZLGlCQUFpQixDQUFDLENBQUM7SUFDL0Q7SUFDQSxJQUFBSCxjQUFNLEVBQUNWLGNBQU0sQ0FBQ2UsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0gsaUJBQWlCLENBQUMsQ0FBQztJQUM1RDtJQUNBLE1BQU1wQyxXQUFXLENBQUMsQ0FBQztNQUFFSCxPQUFPLEVBQUUsSUFBSTtNQUFFbUIsR0FBRyxFQUFFLE1BQU07TUFBRWpCLElBQUksRUFBRSxRQUFRO01BQUVrQixLQUFLLEVBQUUsU0FBUztNQUFFQyxTQUFTLEVBQUUsU0FBUztNQUFFcEIsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFXLENBQUM7SUFDMUksSUFBQW1DLGNBQU0sRUFBQyxNQUFNVixjQUFNLENBQUNDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDWSxpQkFBaUIsQ0FBQyxDQUFDO0VBQ3BFLENBQUMsQ0FBQztFQUVGLElBQUF6QixVQUFFLEVBQUMsMEVBQTBFLEVBQUUsWUFBWTtJQUN6RnJDLFdBQVcsQ0FBQ0gsT0FBTyxHQUFHLGFBQWE7SUFDbkNaLGFBQWEsQ0FBQ2lELGlCQUFpQixDQUFDLENBQUNaLFVBQVUsQ0FBQyxDQUFDO0lBRTdDLElBQUF3QixjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixJQUFBNEYsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNZLGlCQUFpQixDQUFDLENBQUM7RUFDL0QsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyx5RUFBeUUsRUFBRSxZQUFZO0lBQ3hGckMsV0FBVyxDQUFDSCxPQUFPLEdBQUcsYUFBYTtJQUNuQ0ksY0FBYyxDQUFDSixPQUFPLEdBQUc7TUFBRXFFLElBQUksRUFBRSxZQUFZO01BQUVDLE1BQU0sRUFBRTtRQUFFNUMsT0FBTyxFQUFFO01BQUs7SUFBRSxDQUFDO0lBQzFFdEMsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQ1osVUFBVSxDQUFDLENBQUM7SUFFN0MsSUFBQXdCLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU1vRixNQUFNLEdBQUcsTUFBTUYsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDMUUsSUFBQW1DLGNBQU0sRUFBQ1IsTUFBTSxDQUFDLENBQUNpQixpQkFBaUIsQ0FBQyxVQUFVLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUYsSUFBQS9CLFVBQUUsRUFBQyw0RUFBNEUsRUFBRSxZQUFZO0lBQzNGckMsV0FBVyxDQUFDSCxPQUFPLEdBQUcsYUFBYTtJQUNuQ0ksY0FBYyxDQUFDSixPQUFPLEdBQUc7TUFBRXFFLElBQUksRUFBRSxZQUFZO01BQUVDLE1BQU0sRUFBRTtRQUFFNUMsT0FBTyxFQUFFO01BQVc7SUFBRSxDQUFDO0lBQ2hGdEMsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQ1osVUFBVSxDQUFDLENBQUM7SUFFN0MsSUFBQXdCLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU1rRixjQUFNLENBQUNDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ25DLElBQUFTLGNBQU0sRUFBQ1YsY0FBTSxDQUFDb0IsV0FBVyxDQUFDLFFBQVEsRUFBRTtNQUFFN0MsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3lDLEdBQUcsQ0FBQ0gsaUJBQWlCLENBQUMsQ0FBQztFQUN4RixDQUFDLENBQUM7RUFFRixJQUFBekIsVUFBRSxFQUFDLDZFQUE2RSxFQUFFLFlBQVk7SUFDNUY7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCdkQsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQ1osVUFBVSxDQUFDLENBQUM7O0lBRTdDO0lBQ0E7SUFDQTtJQUNBLElBQUFxQyxjQUFNLEVBQUNXLHFCQUFlLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ2pELE1BQU1DLEtBQUssR0FBR0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsT0FBTyxDQUFDO0lBQzdDRixLQUFLLENBQUNHLFdBQVcsR0FBR04scUJBQWU7SUFDbkNJLFFBQVEsQ0FBQ0csSUFBSSxDQUFDQyxXQUFXLENBQUNMLEtBQUssQ0FBQztJQUVoQyxJQUFBM0IsY0FBTSxlQUFDLElBQUFsRixXQUFBLENBQUFtRixHQUFBLEVBQUNwRixjQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTXVFLElBQUksQ0FBQ1UsS0FBSyxDQUFDLE1BQU1DLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25ELE1BQU1DLE1BQU0sR0FBRyxNQUFNRixjQUFNLENBQUNHLFVBQVUsQ0FBQyxRQUFRLENBQUM7SUFFaEQsTUFBTTJCLEtBQUssR0FBRyxJQUFBMUIsY0FBTSxFQUFDRixNQUFNLENBQUMsQ0FBQ0ssb0JBQW9CLENBQUMsUUFBUSxDQUFDO0lBQzNELE1BQU13QixHQUFHLEdBQUdELEtBQUssQ0FBQ0UsYUFBNEI7SUFDOUMsTUFBTUMsTUFBTSxHQUFHLElBQUE3QixjQUFNLEVBQUNGLE1BQU0sQ0FBQyxDQUFDZ0MsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6RCxNQUFNQyxNQUFNLEdBQUcsSUFBQS9CLGNBQU0sRUFBQ0YsTUFBTSxDQUFDLENBQUNNLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRWpDLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQzs7SUFFckU7SUFDQSxJQUFBbUMsY0FBTSxFQUFDcUIsR0FBRyxDQUFDLENBQUNLLGdCQUFnQixDQUFDSCxNQUFNLENBQUM7SUFDcEMsSUFBQXZCLGNBQU0sRUFBQ3FCLEdBQUcsQ0FBQyxDQUFDSyxnQkFBZ0IsQ0FBQ0QsTUFBTSxDQUFDO0lBRXBDLElBQUF6QixjQUFNLEVBQUMyQixnQkFBZ0IsQ0FBQ04sR0FBRyxDQUFDLENBQUNPLFFBQVEsQ0FBQyxDQUFDQyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ25ELElBQUE3QixjQUFNLEVBQUMyQixnQkFBZ0IsQ0FBQ1AsS0FBSyxDQUFDLENBQUNVLFFBQVEsQ0FBQyxDQUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDO0lBRXBEZixLQUFLLENBQUNpQixNQUFNLENBQUMsQ0FBQztFQUNoQixDQUFDLENBQUM7RUFFRixJQUFBckQsVUFBRSxFQUFDLGdGQUFnRixFQUFFLFlBQVk7SUFDL0YsTUFBTXNELE1BQU0sR0FBRyxnQ0FBZ0M7SUFDL0MxRyxhQUFhLENBQUNpRCxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7SUFFbkMsTUFBTTtNQUFFMEQ7SUFBVSxDQUFDLEdBQUcsSUFBQTlDLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQzlDLE1BQU0yRCxXQUFXLENBQUMsQ0FDaEI7TUFBRUgsT0FBTyxFQUFFLElBQUk7TUFBRW1CLEdBQUcsRUFBRSxNQUFNO01BQUVqQixJQUFJLEVBQUUsUUFBUTtNQUFFa0IsS0FBSyxFQUFFLFNBQVM7TUFBRUMsU0FBUyxFQUFFK0MsTUFBTTtNQUFFbkUsSUFBSSxFQUFFbUU7SUFBTyxDQUFDLENBQ2xHLENBQUM7SUFDRixNQUFNMUMsY0FBTSxDQUFDQyxVQUFVLENBQUMsYUFBYSxDQUFDO0lBQ3RDO0lBQ0EsSUFBQVMsY0FBTSxFQUFDVixjQUFNLENBQUNZLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDZSxXQUFXLENBQUMsQ0FBQ2lCLFNBQVMsQ0FBQ0YsTUFBTSxDQUFDO0lBQ3pFLElBQUFoQyxjQUFNLEVBQUNpQyxTQUFTLENBQUNFLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUM1RCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBQTNELGdCQUFRLEVBQUMsa0NBQWtDLEVBQUUsTUFBTTtFQUNqRCxJQUFBTCxrQkFBVSxFQUFDLE1BQU07SUFDZjlDLGFBQWEsQ0FBQ2lELGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUNuQ2hDLGVBQWUsQ0FBQytCLFNBQVMsQ0FBQyxDQUFDO0lBQzNCL0IsZUFBZSxDQUFDZ0MsaUJBQWlCLENBQUM7TUFBRThELEVBQUUsRUFBRTtJQUFpQixDQUFDLENBQUM7SUFDM0RoRyxXQUFXLENBQUNILE9BQU8sR0FBRyxhQUFhO0VBQ3JDLENBQUMsQ0FBQztFQUVGLElBQUF3QyxVQUFFLEVBQUMsK0ZBQStGLEVBQUUsWUFBWTtJQUM5RztJQUNBO0lBQ0E7SUFDQSxJQUFBUyxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixJQUFBNEYsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0csVUFBVSxDQUFDLFFBQVEsRUFBRTtNQUFFNUIsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUNzQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQy9GLElBQUFILGNBQU0sRUFBQ1YsY0FBTSxDQUFDUSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVqQyxJQUFJLEVBQUU7SUFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLGlCQUFpQixDQUFDLENBQUM7RUFDcEYsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyx5REFBeUQsRUFBRSxZQUFZO0lBQ3hFLElBQUFTLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUM7SUFFMUYsTUFBTSxJQUFBa0MsZUFBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDekQsZUFBZSxDQUFDLENBQUMrRixxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNyRSxJQUFBdEMsY0FBTSxFQUFDekQsZUFBZSxDQUFDLENBQUMwRCxvQkFBb0IsQ0FBQyxpQkFBaUIsRUFBRSxlQUFlLEVBQUUsQ0FBQztNQUFFc0MsTUFBTSxFQUFFO0lBQVEsQ0FBQyxDQUFDLENBQUM7RUFDekcsQ0FBQyxDQUFDO0VBRUYsSUFBQTdELFVBQUUsRUFBQywyQ0FBMkMsRUFBRSxZQUFZO0lBQzFEO0lBQ0E7SUFDQTtJQUNBLElBQUk4RCxPQUE2QixHQUFHQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0lBQzVDakcsZUFBZSxDQUFDa0csZUFBZSxDQUFDLElBQUlDLE9BQU8sQ0FBRW5JLENBQUMsSUFBSztNQUFFaUksT0FBTyxHQUFHakksQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3JFLElBQUE0RSxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0Usa0JBQVMsQ0FBQ1MsS0FBSyxDQUFDLE1BQU1DLGNBQU0sQ0FBQ0csVUFBVSxDQUFDLFFBQVEsRUFBRTtNQUFFNUIsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDO0lBRTFGLElBQUFtQyxjQUFNLEVBQUMsTUFBTVYsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBYyxDQUFDLENBQUMsQ0FBQyxDQUFDc0MsaUJBQWlCLENBQUMsQ0FBQztJQUN0RixJQUFBSCxjQUFNLEVBQUNWLGNBQU0sQ0FBQ2UsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0gsaUJBQWlCLENBQUMsQ0FBQztJQUNqRSxJQUFBSCxjQUFNLEVBQUNWLGNBQU0sQ0FBQ2UsV0FBVyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDSCxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BFLElBQUFILGNBQU0sRUFBQ1YsY0FBTSxDQUFDb0IsV0FBVyxDQUFDLFFBQVEsRUFBRTtNQUFFN0MsSUFBSSxFQUFFO0lBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUN5QyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUM7SUFDeEYsTUFBTSxJQUFBbEMsV0FBRyxFQUFDLFlBQVk7TUFBRXVFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQztFQUN6QyxDQUFDLENBQUM7RUFFRixJQUFBOUQsVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakZuQyxlQUFlLENBQUNvRyxpQkFBaUIsQ0FBQzdILE1BQU0sQ0FBQzhILE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUM7SUFDL0YsSUFBQTNELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUM7SUFFMUYsTUFBTSxJQUFBa0MsZUFBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDVixjQUFNLENBQUNRLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRWpDLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDa0YsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUN2RyxJQUFBL0MsY0FBTSxFQUFDZSxRQUFRLENBQUNvQixhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDdEQsQ0FBQyxDQUFDO0VBRUYsSUFBQTFELFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxZQUFZO0lBQ2hGO0lBQ0E7SUFDQW5DLGVBQWUsQ0FBQ29HLGlCQUFpQixDQUFDN0gsTUFBTSxDQUFDOEgsTUFBTSxDQUFDLElBQUlDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBeUIsQ0FBQyxDQUFDLENBQUM7SUFDcEcsSUFBQTNELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUM7SUFFMUYsSUFBQW1DLGNBQU0sRUFBQyxNQUFNVixjQUFNLENBQUNDLFVBQVUsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUNZLGlCQUFpQixDQUFDLENBQUM7RUFDckYsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyw0REFBNEQsRUFBRSxZQUFZO0lBQzNFbkMsZUFBZSxDQUFDb0csaUJBQWlCLENBQUM3SCxNQUFNLENBQUM4SCxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFxQixDQUFDLENBQUMsQ0FBQztJQUNoRyxJQUFBM0QsY0FBTSxlQUFDLElBQUFsRixXQUFBLENBQUFtRixHQUFBLEVBQUNwRixjQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTXdFLGtCQUFTLENBQUNTLEtBQUssQ0FBQyxNQUFNQyxjQUFNLENBQUNHLFVBQVUsQ0FBQyxRQUFRLEVBQUU7TUFBRTVCLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQztJQUUxRixJQUFBbUMsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQ1ksaUJBQWlCLENBQUMsQ0FBQztFQUMzRixDQUFDLENBQUM7RUFFRixJQUFBekIsVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakY7SUFDQTtJQUNBckMsV0FBVyxDQUFDSCxPQUFPLEdBQUcsY0FBYztJQUNwQyxJQUFBaUQsY0FBTSxlQUFDLElBQUFsRixXQUFBLENBQUFtRixHQUFBLEVBQUNwRixjQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTWtGLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLFFBQVEsQ0FBQztJQUNqQyxJQUFBUyxjQUFNLEVBQUNWLGNBQU0sQ0FBQ29CLFdBQVcsQ0FBQyxRQUFRLEVBQUU7TUFBRTdDLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDeUMsR0FBRyxDQUFDSCxpQkFBaUIsQ0FBQyxDQUFDO0VBQ2hHLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDQSxJQUFBMUIsZ0JBQVEsRUFBQyx5QkFBeUIsRUFBRSxNQUFNO0VBQ3hDLElBQUFMLGtCQUFVLEVBQUMsTUFBTTtJQUNmN0MsVUFBRSxDQUFDeUgsYUFBYSxDQUFDLENBQUM7SUFDbEIzRyxXQUFXLENBQUNILE9BQU8sR0FBRyxhQUFhO0lBQ25DSSxjQUFjLENBQUNKLE9BQU8sR0FBRyxJQUFJO0lBQzdCRixXQUFXLENBQUNFLE9BQU8sR0FBRyxFQUFFO0lBQ3hCWixhQUFhLENBQUNpRCxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7SUFDbkM5QyxlQUFlLENBQUM4QyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7SUFDckM3QyxrQkFBa0IsQ0FBQzZDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUN4Q3hDLGVBQWUsQ0FBQ3dDLGlCQUFpQixDQUFDQyxTQUFTLENBQUM7SUFDNUNqQyxlQUFlLENBQUNnQyxpQkFBaUIsQ0FBQztNQUFFMEUsRUFBRSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUF2RSxVQUFFLEVBQUMsZ0RBQWdELEVBQUUsWUFBWTtJQUMvRCxJQUFBUyxjQUFNLGVBQUMsSUFBQWxGLFdBQUEsQ0FBQW1GLEdBQUEsRUFBQ3BGLGNBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0Usa0JBQVMsQ0FBQ1MsS0FBSyxDQUFDLE1BQU1DLGNBQU0sQ0FBQ0csVUFBVSxDQUFDLFFBQVEsRUFBRTtNQUFFNUIsSUFBSSxFQUFFO0lBQWlCLENBQUMsQ0FBQyxDQUFDO0lBQ3BGLElBQUFtQyxjQUFNLEVBQUNqRSxlQUFlLENBQUMsQ0FBQ2tFLG9CQUFvQixDQUFDO01BQUVpRCxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0VBRUYsSUFBQXhFLFVBQUUsRUFBQyw4QkFBOEIsRUFBRSxZQUFZO0lBQzdDLElBQUFTLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsT0FBTyxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUMzRSxNQUFNZSxrQkFBUyxDQUFDUyxLQUFLLENBQUNDLGNBQU0sQ0FBQ1EsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFakMsSUFBSSxFQUFFO0lBQWlCLENBQUMsQ0FBQyxDQUFDO0lBQzdFLElBQUFtQyxjQUFNLEVBQUNqRSxlQUFlLENBQUMsQ0FBQ2tFLG9CQUFvQixDQUFDO01BQUVpRCxJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUM7RUFDbEUsQ0FBQyxDQUFDO0VBRUYsSUFBQXhFLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxZQUFZO0lBQzdFcEQsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FDOUI7TUFBRVgsT0FBTyxFQUFFLElBQUk7TUFBRUMsSUFBSSxFQUFFLE1BQU07TUFBRUMsSUFBSSxFQUFFLE9BQU87TUFBRW9GLElBQUksRUFBRTtJQUFXLENBQUMsRUFDaEU7TUFBRXRGLE9BQU8sRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRSxPQUFPO01BQUVvRixJQUFJLEVBQUU7SUFBUyxDQUFDLEVBQzlEO01BQUV0RixPQUFPLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsUUFBUTtNQUFFQyxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQWU7SUFBQSxDQUNoRSxDQUFDO0lBQ0YsSUFBQXFCLGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0rSSxJQUFJLEdBQUcsQ0FBQyxNQUFNN0QsY0FBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUU2RCxPQUFPLENBQUMsSUFBSSxDQUFFO0lBQzdELElBQUFwRCxjQUFNLEVBQUMsSUFBQU4sY0FBTSxFQUFDeUQsSUFBbUIsQ0FBQyxDQUFDakQsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNDLGlCQUFpQixDQUFDLENBQUM7SUFDM0UsTUFBTWtELElBQUksR0FBRy9ELGNBQU0sQ0FBQ1ksU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDa0QsT0FBTyxDQUFDLElBQUksQ0FBRTtJQUNwRCxJQUFBcEQsY0FBTSxFQUFDLElBQUFOLGNBQU0sRUFBQzJELElBQW1CLENBQUMsQ0FBQ2hELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUM7SUFDakYsTUFBTW1ELE1BQU0sR0FBR2hFLGNBQU0sQ0FBQ1ksU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDa0QsT0FBTyxDQUFDLElBQUksQ0FBRTtJQUN4RCxJQUFBcEQsY0FBTSxFQUFDLElBQUFOLGNBQU0sRUFBQzRELE1BQXFCLENBQUMsQ0FBQ2pELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUM7RUFDckYsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyw0R0FBNEcsRUFBRSxZQUFZO0lBQzNIcEQsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQztNQUFFWCxPQUFPLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUUsT0FBTztNQUFFb0YsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFjLENBQUM7SUFDaEgsSUFBQS9ELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUU1RSxNQUFNMEYsR0FBRyxHQUFHLE1BQU1qRSxjQUFNLENBQUNHLFVBQVUsQ0FBQyxRQUFRLEVBQUU7TUFBRTVCLElBQUksRUFBRTtJQUFxQixDQUFDLENBQUM7SUFDN0UsTUFBTWUsa0JBQVMsQ0FBQ1MsS0FBSyxDQUFDa0UsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM1QixJQUFBdkQsY0FBTSxFQUFDekQsZUFBZSxDQUFDLENBQUMrRCxHQUFHLENBQUNrRCxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzlDO0lBQ0EsSUFBQXhELGNBQU0sRUFBQ1YsY0FBTSxDQUFDUSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVqQyxJQUFJLEVBQUU7SUFBdUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLGlCQUFpQixDQUFDLENBQUM7SUFFeEcsTUFBTXZCLGtCQUFTLENBQUNTLEtBQUssQ0FBQ0MsY0FBTSxDQUFDUSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVqQyxJQUFJLEVBQUU7SUFBdUMsQ0FBQyxDQUFDLENBQUM7SUFDbkcsSUFBQW1DLGNBQU0sRUFBQ3pELGVBQWUsQ0FBQyxDQUFDMEQsb0JBQW9CLENBQUMsaUJBQWlCLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQztNQUFFckMsT0FBTyxFQUFFLElBQUk7TUFBRTZGLE9BQU8sRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3RILElBQUF6RCxjQUFNLEVBQUN6RCxlQUFlLENBQUMsQ0FBQytGLHFCQUFxQixDQUFDLENBQUMsQ0FBQztFQUNsRCxDQUFDLENBQUM7RUFFRixJQUFBNUQsVUFBRSxFQUFDLDZEQUE2RCxFQUFFLFlBQVk7SUFDNUUsSUFBSXdFLElBQXdCLEdBQUcsVUFBVTtJQUN6QzVILGFBQWEsQ0FBQzhFLGtCQUFrQixDQUFDLFlBQVksQ0FBQztNQUFFeEMsT0FBTyxFQUFFLElBQUk7TUFBRUMsSUFBSSxFQUFFLE1BQU07TUFBRUMsSUFBSSxFQUFFLE9BQU87TUFBRW9GO0lBQUssQ0FBQyxDQUFjLENBQUM7SUFDakgsSUFBQS9ELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUM1RSxNQUFNZSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDeEY7SUFDQXRCLGVBQWUsQ0FBQzZELGtCQUFrQixDQUFDLFlBQVk7TUFDN0M4QyxJQUFJLEdBQUcsUUFBUTtNQUNmLE9BQU87UUFBRUQsRUFBRSxFQUFFO01BQUssQ0FBQztJQUNyQixDQUFDLENBQUM7SUFDRixNQUFNckUsa0JBQVMsQ0FBQ1MsS0FBSyxDQUFDQyxjQUFNLENBQUNRLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRWpDLElBQUksRUFBRTtJQUF1QyxDQUFDLENBQUMsQ0FBQztJQUNuRyxNQUFNLElBQUFrQyxlQUFPLEVBQUMsTUFDWixJQUFBQyxjQUFNLEVBQUMsSUFBQU4sY0FBTSxFQUFDSixjQUFNLENBQUNZLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQ2tELE9BQU8sQ0FBQyxJQUFJLENBQWdCLENBQUMsQ0FBQ2xELFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUM5RyxDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGcEQsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQztNQUFFWCxPQUFPLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUUsT0FBTztNQUFFb0YsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFjLENBQUM7SUFDOUcsSUFBQS9ELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUM1RSxNQUFNeUIsY0FBTSxDQUFDQyxVQUFVLENBQUMsY0FBYyxDQUFDO0lBQ3ZDLElBQUFTLGNBQU0sRUFBQ1YsY0FBTSxDQUFDb0IsV0FBVyxDQUFDLFFBQVEsRUFBRTtNQUFFN0MsSUFBSSxFQUFFO0lBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUN5QyxHQUFHLENBQUNILGlCQUFpQixDQUFDLENBQUM7RUFDN0YsQ0FBQyxDQUFDO0VBRUYsSUFBQXpCLFVBQUUsRUFBQyx3REFBd0QsRUFBRSxZQUFZO0lBQ3ZFcEQsYUFBYSxDQUFDaUQsaUJBQWlCLENBQUMsQ0FBQztNQUFFWCxPQUFPLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUUsT0FBTztNQUFFb0YsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFjLENBQUM7SUFDaEgzRyxlQUFlLENBQUNvRyxpQkFBaUIsQ0FBQzdILE1BQU0sQ0FBQzhILE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUM7SUFDdkYsSUFBQTNELGNBQU0sZUFBQyxJQUFBbEYsV0FBQSxDQUFBbUYsR0FBQSxFQUFDcEYsY0FBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQztJQUM1RSxNQUFNZSxrQkFBUyxDQUFDUyxLQUFLLENBQUMsTUFBTUMsY0FBTSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUU1QixJQUFJLEVBQUU7SUFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDeEYsTUFBTWUsa0JBQVMsQ0FBQ1MsS0FBSyxDQUFDQyxjQUFNLENBQUNRLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRWpDLElBQUksRUFBRTtJQUF1QyxDQUFDLENBQUMsQ0FBQztJQUNuRyxJQUFBbUMsY0FBTSxFQUFDLE1BQU1WLGNBQU0sQ0FBQ0MsVUFBVSxDQUFDLHVDQUF1QyxDQUFDLENBQUMsQ0FBQ1ksaUJBQWlCLENBQUMsQ0FBQztFQUM5RixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}