var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _SpaceManager = _interopRequireDefault(require("./components/SpaceManager"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The space manager as an app (UI_AS_APPS_SPEC §5.2): lists the user's spaces,
// and for spaces they own, manages membership — invite by handle, change roles,
// remove members. Elevated `spaces:user` (enumerate) + `spaces:admin` (mutate).
// The host enforces the owner-lockout invariant and owns the handle lookup; the
// identity token never reaches this app.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_SpaceManager.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX1NwYWNlTWFuYWdlciIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIFRoZSBzcGFjZSBtYW5hZ2VyIGFzIGFuIGFwcCAoVUlfQVNfQVBQU19TUEVDIMKnNS4yKTogbGlzdHMgdGhlIHVzZXIncyBzcGFjZXMsXG4vLyBhbmQgZm9yIHNwYWNlcyB0aGV5IG93biwgbWFuYWdlcyBtZW1iZXJzaGlwIOKAlCBpbnZpdGUgYnkgaGFuZGxlLCBjaGFuZ2Ugcm9sZXMsXG4vLyByZW1vdmUgbWVtYmVycy4gRWxldmF0ZWQgYHNwYWNlczp1c2VyYCAoZW51bWVyYXRlKSArIGBzcGFjZXM6YWRtaW5gIChtdXRhdGUpLlxuLy8gVGhlIGhvc3QgZW5mb3JjZXMgdGhlIG93bmVyLWxvY2tvdXQgaW52YXJpYW50IGFuZCBvd25zIHRoZSBoYW5kbGUgbG9va3VwOyB0aGVcbi8vIGlkZW50aXR5IHRva2VuIG5ldmVyIHJlYWNoZXMgdGhpcyBhcHAuXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IFNwYWNlTWFuYWdlciBmcm9tIFwiLi9jb21wb25lbnRzL1NwYWNlTWFuYWdlclwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiA8U3BhY2VNYW5hZ2VyIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU1BQSxPQUFBO0FBQ0EsSUFBQUMsYUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQXFELElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUHJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxTQUFTRyxHQUFHQSxDQUFBLEVBQUc7RUFDYixvQkFBTyxJQUFBSixXQUFBLENBQUFLLEdBQUEsRUFBQ1AsYUFBQSxDQUFBSyxPQUFZLElBQUUsQ0FBQztBQUN6QjtBQUFDRyxFQUFBLEdBRlFGLEdBQUc7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUwsT0FBQSxHQUlHQyxHQUFHO0FBQUEsSUFBQUUsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}