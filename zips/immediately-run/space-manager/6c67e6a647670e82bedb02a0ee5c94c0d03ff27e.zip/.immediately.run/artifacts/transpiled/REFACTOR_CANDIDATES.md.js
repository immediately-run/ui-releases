var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "refactor-findings-space-manager",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "refactor-findings-space-manager"
      }), "REFACTOR / FINDINGS — space-manager"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Recorded by the 2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ").\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Record only — no symbol renamed in this pass."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "rename-sm-1-load-bearing-coordinated-memberprincipal-grantee",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "rename-sm-1-load-bearing-coordinated-memberprincipal-grantee"
      }), "RENAME-SM-1 (load-bearing, coordinated) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Member.principal"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grantee"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/components/SpaceManager.tsx"
      }), " reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "m.principal"
      }), " (and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "principal"
      }), " param in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "uidOf"
      }), ") at lines ~24, 35, 199, 209, 247. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Member.principal"
      }), " field is a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "grantee"
      }), " (a space member, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "user:<uid>"
      }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " the authority-context\nPrincipal (core_concepts §4 reserved-word note; SPEC_CODE_DEBT §7.1). This is the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "consumer side"
      }), " of the SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Member.principal"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grantee"
      }), " rename."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Type origin:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Member"
        }), " is imported from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " — the field\nrename must land in the SDK first (filed as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "02-sdk.md"
        }), " RENAME-1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Blast radius (this repo):"
        }), " every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "m.principal"
        }), " read above + the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "uidOf"
        }), "\nparameter name. spaces-panel and file-commander were re-grepped — neither reads\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".principal"
        }), ", so this is the only consumer app affected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Gate:"
        }), " part of the overview §6 ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["shared cross-repo ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "principal"
          }), "→", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "grantee"
          }), "\ntrack"]
        }), " (SDK type + Firestore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "spaces/{id}/members/{principal}"
        }), " + site-main +\nsandbox). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Do NOT land piecemeal"
        }), " — this app's edit ships with the SDK + host\nhalves; per-repo gate is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build && npm run lint"
        }), " once the SDK type lands."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "spec-refs-phase-1-verified-current",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "spec-refs-phase-1-verified-current"
      }), "Spec-refs (Phase 1 — verified current)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SpaceManager.tsx:1"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx:2"
        }), " cite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC §5.2"
        }), " (Spaces\nmanagement) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "current"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SpaceManager.tsx:90"
        }), " cites ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.11"
        }), " for the capability audit view (which apps\nhold which mount grants + revoke). The UI_AS_APPS §8.11 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "header"
        }), " reads \"Prior art\n& positioning\", BUT the spec ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "body"
        }), " repeatedly refers to \"the audit view\n(§8.11)\" (e.g. lines 460, 525, 1388, 1697, 1908). The code's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.11"
        }), " therefore\nmatches how the spec cross-references the audit view — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "left as-is"
        }), "; the §\nheader/body mismatch is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "spec-side"
        }), " issue → see DOCS DELTA in the pass report,\nnot a code fix."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SpaceManager.tsx:26"
        }), " cites ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§spaceId.ts"
        }), " for the appKey encoding — an\nintra-repo helper pointer, fine."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sdk-version-skew-record-only",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sdk-version-skew-record-only"
      }), "SDK-version skew (record only)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.2.8"
        })
      }), " (oldest fleet tier). Coordinated bump\nowed; do not bump here."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "vocabulary-phase-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "vocabulary-phase-2"
      }), "Vocabulary (Phase 2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "role"
      }), " (owner/writer/reader) is the FILE_SHARING grant-role, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " a principal —\ncorrect per core_concepts §11; left intact. No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "kernel"
      }), " in comments."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/REFACTOR_CANDIDATES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVGQUNUT1JfQ0FORElEQVRFUy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJyZWZhY3Rvci1maW5kaW5ncy1zcGFjZS1tYW5hZ2VyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWZhY3Rvci1maW5kaW5ncy1zcGFjZS1tYW5hZ2VyXCIgLz57XCJSRUZBQ1RPUiAvIEZJTkRJTkdTIOKAlCBzcGFjZS1tYW5hZ2VyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNvcmRlZCBieSB0aGUgMjAyNi0wNiBjb2RlLXZlcmlmaWNhdGlvbiBwYXNzIChSMy0xMjQ7IHBsYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMDgtc3lzdGVtLWFwcHMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlY29yZCBvbmx5IOKAlCBubyBzeW1ib2wgcmVuYW1lZCBpbiB0aGlzIHBhc3MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlbmFtZS1zbS0xLWxvYWQtYmVhcmluZy1jb29yZGluYXRlZC1tZW1iZXJwcmluY2lwYWwtZ3JhbnRlZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVuYW1lLXNtLTEtbG9hZC1iZWFyaW5nLWNvb3JkaW5hdGVkLW1lbWJlcnByaW5jaXBhbC1ncmFudGVlXCIgLz57XCJSRU5BTUUtU00tMSAobG9hZC1iZWFyaW5nLCBjb29yZGluYXRlZCkg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1lbWJlci5wcmluY2lwYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncmFudGVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvU3BhY2VNYW5hZ2VyLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVhZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibS5wcmluY2lwYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcmluY2lwYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhcmFtIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widWlkT2ZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhdCBsaW5lcyB+MjQsIDM1LCAxOTksIDIwOSwgMjQ3LiBUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTWVtYmVyLnByaW5jaXBhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmllbGQgaXMgYVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZ3JhbnRlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBzcGFjZSBtZW1iZXIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZXI6PHVpZD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGF1dGhvcml0eS1jb250ZXh0XFxuUHJpbmNpcGFsIChjb3JlX2NvbmNlcHRzIMKnNCByZXNlcnZlZC13b3JkIG5vdGU7IFNQRUNfQ09ERV9ERUJUIMKnNy4xKS4gVGhpcyBpcyB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnN1bWVyIHNpZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2YgdGhlIFNESydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1lbWJlci5wcmluY2lwYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncmFudGVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5hbWUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUeXBlIG9yaWdpbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTWVtYmVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBpbXBvcnRlZCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGZpZWxkXFxucmVuYW1lIG11c3QgbGFuZCBpbiB0aGUgU0RLIGZpcnN0IChmaWxlZCBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwMi1zZGsubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFJFTkFNRS0xKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJsYXN0IHJhZGl1cyAodGhpcyByZXBvKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZXZlcnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibS5wcmluY2lwYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlYWQgYWJvdmUgKyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widWlkT2ZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucGFyYW1ldGVyIG5hbWUuIHNwYWNlcy1wYW5lbCBhbmQgZmlsZS1jb21tYW5kZXIgd2VyZSByZS1ncmVwcGVkIOKAlCBuZWl0aGVyIHJlYWRzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLnByaW5jaXBhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIHRoaXMgaXMgdGhlIG9ubHkgY29uc3VtZXIgYXBwIGFmZmVjdGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2F0ZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcGFydCBvZiB0aGUgb3ZlcnZpZXcgwqc2IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2hhcmVkIGNyb3NzLXJlcG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJpbmNpcGFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIuKGklwifTxfY29tcG9uZW50cy5jb2RlPntcImdyYW50ZWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxudHJhY2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFNESyB0eXBlICsgRmlyZXN0b3JlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYWNlcy97aWR9L21lbWJlcnMve3ByaW5jaXBhbH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgc2l0ZS1tYWluICtcXG5zYW5kYm94KS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJEbyBOT1QgbGFuZCBwaWVjZW1lYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoaXMgYXBwJ3MgZWRpdCBzaGlwcyB3aXRoIHRoZSBTREsgKyBob3N0XFxuaGFsdmVzOyBwZXItcmVwbyBnYXRlIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGQgJiYgbnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbmNlIHRoZSBTREsgdHlwZSBsYW5kcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3BlYy1yZWZzLXBoYXNlLTEtdmVyaWZpZWQtY3VycmVudFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3BlYy1yZWZzLXBoYXNlLTEtdmVyaWZpZWQtY3VycmVudFwiIC8+e1wiU3BlYy1yZWZzIChQaGFzZSAxIOKAlCB2ZXJpZmllZCBjdXJyZW50KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJTcGFjZU1hbmFnZXIudHN4OjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeDoyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlVJX0FTX0FQUFNfU1BFQyDCpzUuMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFNwYWNlc1xcbm1hbmFnZW1lbnQpIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImN1cnJlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiU3BhY2VNYW5hZ2VyLnRzeDo5MFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2l0ZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc4LjExXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGhlIGNhcGFiaWxpdHkgYXVkaXQgdmlldyAod2hpY2ggYXBwc1xcbmhvbGQgd2hpY2ggbW91bnQgZ3JhbnRzICsgcmV2b2tlKS4gVGhlIFVJX0FTX0FQUFMgwqc4LjExIFwifTxfY29tcG9uZW50cy5lbT57XCJoZWFkZXJcIn08L19jb21wb25lbnRzLmVtPntcIiByZWFkcyBcXFwiUHJpb3IgYXJ0XFxuJiBwb3NpdGlvbmluZ1xcXCIsIEJVVCB0aGUgc3BlYyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJvZHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVwZWF0ZWRseSByZWZlcnMgdG8gXFxcInRoZSBhdWRpdCB2aWV3XFxuKMKnOC4xMSlcXFwiIChlLmcuIGxpbmVzIDQ2MCwgNTI1LCAxMzg4LCAxNjk3LCAxOTA4KS4gVGhlIGNvZGUncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCLCpzguMTFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRoZXJlZm9yZVxcbm1hdGNoZXMgaG93IHRoZSBzcGVjIGNyb3NzLXJlZmVyZW5jZXMgdGhlIGF1ZGl0IHZpZXcg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGVmdCBhcy1pc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgdGhlIMKnXFxuaGVhZGVyL2JvZHkgbWlzbWF0Y2ggaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNwZWMtc2lkZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpc3N1ZSDihpIgc2VlIERPQ1MgREVMVEEgaW4gdGhlIHBhc3MgcmVwb3J0LFxcbm5vdCBhIGNvZGUgZml4LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIlNwYWNlTWFuYWdlci50c3g6MjZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNpdGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnc3BhY2VJZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBhcHBLZXkgZW5jb2Rpbmcg4oCUIGFuXFxuaW50cmEtcmVwbyBoZWxwZXIgcG9pbnRlciwgZmluZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2RrLXZlcnNpb24tc2tldy1yZWNvcmQtb25seVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2RrLXZlcnNpb24tc2tldy1yZWNvcmQtb25seVwiIC8+e1wiU0RLLXZlcnNpb24gc2tldyAocmVjb3JkIG9ubHkpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQaW5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIjAuMi44XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAob2xkZXN0IGZsZWV0IHRpZXIpLiBDb29yZGluYXRlZCBidW1wXFxub3dlZDsgZG8gbm90IGJ1bXAgaGVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidm9jYWJ1bGFyeS1waGFzZS0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ2b2NhYnVsYXJ5LXBoYXNlLTJcIiAvPntcIlZvY2FidWxhcnkgKFBoYXNlIDIpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJyb2xlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3duZXIvd3JpdGVyL3JlYWRlcikgaXMgdGhlIEZJTEVfU0hBUklORyBncmFudC1yb2xlLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhIHByaW5jaXBhbCDigJRcXG5jb3JyZWN0IHBlciBjb3JlX2NvbmNlcHRzIMKnMTE7IGxlZnQgaW50YWN0LiBObyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJrZXJuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGNvbW1lbnRzLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVGQUNUT1JfQ0FORElEQVRFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdWLEtBQUssQ0FBQ1c7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdYLFdBQVc7RUFDaEMsSUFBSSxDQUFDVyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWYsV0FBQSxDQUFBZ0IsSUFBQSxFQUFBaEIsV0FBQSxDQUFBaUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYSxFQUFFLEVBQUMsaUNBQWlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUMsQ0FBRSxDQUFDLEVBQUMscUNBQXFDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxHQUFFLCtEQUErRCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBK0MsQ0FBcUIsQ0FBQztJQUFBLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLDhEQUE4RDtNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThELENBQUUsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFpQyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsNkdBQTZHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNRLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWE7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsOENBQThDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyxTQUFTO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWlDLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLG9DQUFvQztNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9DLENBQUUsQ0FBQyxFQUFDLHdDQUF3QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDUSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsRUFBRTtVQUFBYSxRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsd0dBQXdHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMscUVBQXFFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsOERBQThEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLDhCQUE4QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThCLENBQUUsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLGlFQUFpRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO01BQUNZLEVBQUUsRUFBQyxvQkFBb0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ00sQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3hoTDtBQUNlLFNBQVNHLFVBQVVBLENBQUNuQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDb0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1YsS0FBSyxDQUFDVztFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUF2QixXQUFBLENBQUFvQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLckIsS0FBSztJQUFBZ0IsUUFBQSxlQUFFLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNuQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDc0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxvQ0FBb0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM5UDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}