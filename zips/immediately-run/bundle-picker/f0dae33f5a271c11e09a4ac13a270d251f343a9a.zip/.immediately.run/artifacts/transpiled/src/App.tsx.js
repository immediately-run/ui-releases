var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _navigation = require("./lib/navigation");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The open-bundle picker app (OPEN_BUNDLE_SPEC §2/§3, R3-499) — the default
// provider bound at `task.open-bundle`. A transient task app: read the invocation
// (`kinds`), let the user navigate (paste a repo location — the host's runtime
// mount verb mounts it `ro` after per-repo consent — then browse), reveal bundles
// by marker `kind`, and complete with ONE `{ location }` — a pointer, never
// authority. The host independently re-probes the pick (G-OB-7); our job is an
// honest, bounded UI.
/** The chrome both render states share: the head block and the Cancel footer. */
function Chrome({
  title,
  sub,
  done,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("main", {
    className: "bp-root",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "bp-head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
        children: title
      }), sub]
    }), children, /*#__PURE__*/(0, _jsxRuntime.jsx)("footer", {
      className: "bp-foot",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "bp-cancel",
        onClick: () => (0, _sdk.cancelTask)(),
        disabled: done,
        children: "Cancel"
      })
    })]
  });
}
_c = Chrome;
function App() {
  _s();
  // The invocation arrives as a host→frame `task-input` push whose delivery is
  // observed-unreliable at mount (site-main's taskInputDelivery, R3-550 — the
  // replayable poll is R3-787). Read it reactively (`useTaskInput`, the SDK's
  // hook for exactly this) so a delivery landing after first render still
  // reaches the UI; a one-shot `getTaskInput()` in a useMemo froze `kinds` at
  // [] forever and rendered every marker-bearing directory unpickable (found
  // live on the venue, R3-518's round-trip 2026-09-29).
  const input = (0, _sdk.useTaskInput)();
  const kinds = (0, _react.useMemo)(() => Array.isArray(input?.params?.kinds) ? (input?.params).kinds ?? [] : [], [input]);
  const [state, setState] = (0, _react.useState)({
    mount: null,
    navToken: {},
    source: null,
    locator: '',
    segments: [],
    step: null,
    busy: null,
    error: null,
    done: false
  });

  // The spaces leg (spec §4): the host's spaces strip pushes a scoped `ro`
  // navigation root into this frame per pick, announced as an ordinary
  // mount-add; `useMounts()` is how we see it. We never enumerate spaces — the
  // strip (host chrome) did that; we navigate only what we were handed.
  const mounts = (0, _sdk.useMounts)();
  const spaceRoots = (0, _react.useMemo)(() => (0, _navigation.spaceRootsOf)(mounts), [mounts]);

  // A granted root can vanish mid-task (the space was unshared — the host
  // tears the mount down within one snapshot). Derived at RENDER, not an
  // effect: while the navigated root is gone the nav is not rendered and the
  // loss is named; in-flight listings of the dead root are dropped by the
  // token + the still-held check in loadStep (its reads reject at the revoked
  // port anyway).
  const currentSpaceId = state.source?.kind === 'space' ? state.source.spaceId : null;
  const currentRootGone = currentSpaceId !== null && !spaceRoots.some(m => m.id === currentSpaceId);
  const shownError = currentRootGone ? 'That space is no longer available.' : state.error;

  // Staleness: every navigation issues a fresh token, and a resolving listing
  // applies only while it still holds it — a slow read of space A must never
  // render under space B's source (a pick would then return B's spaceId with
  // A's path — the misdirection class the host's G-OB-7 re-probe exists to
  // catch, and this app refuses to produce in the first place). A REVOKED
  // root's late reads need no check here: the host's export boundary rejects
  // them terminally, they land in the catch, and the render-derived
  // `currentRootGone` wording ('no longer available') is what the user sees.
  const loadStep = (0, _react.useCallback)(async (m, segments) => {
    const token = {};
    setState(s => ({
      ...s,
      navToken: token,
      busy: 'listing',
      error: null
    }));
    try {
      const step = await (0, _navigation.navigationStep)((0, _sdk.openFs)(m), (0, _navigation.pathFromSegments)(segments), segments.length);
      setState(s => s.navToken === token ? {
        ...s,
        segments,
        step,
        busy: null
      } : s);
    } catch (e) {
      const message = String(e?.message ?? e);
      setState(s => s.navToken === token ? {
        ...s,
        busy: null,
        error: message
      } : s);
    }
  }, []);
  const openRepo = (0, _react.useCallback)(async () => {
    const locator = state.locator.trim();
    if (!locator) return;
    // Rotate the staleness token and drop the previous tree NOW: a listing
    // still in flight from the old source must not resolve mid-mount (it would
    // clobber busy:'mounting' and re-enable the controls — R-IX-2 — and paint
    // the old root's entries over the incoming one).
    setState(s => ({
      ...s,
      navToken: {},
      step: null,
      busy: 'mounting',
      error: null
    }));
    try {
      // The host's runtime mount verb: `ro` mount + per-repo consent (L1).
      const m = await (0, _sdk.mount)(locator);
      setState(s => ({
        ...s,
        mount: m,
        source: {
          kind: 'repo',
          locator
        },
        segments: [],
        step: null,
        busy: null
      }));
      await loadStep(m, []);
    } catch (e) {
      const err = e;
      setState(s => ({
        ...s,
        busy: null,
        error: err.code ? `${err.code}: ${err.message}` : err.message
      }));
    }
  }, [state.locator, loadStep]);

  // Navigate a strip-granted space root (the host already consented this pick —
  // the strip IS the user's gesture; nothing here prompts again).
  const openSpace = (0, _react.useCallback)(m => {
    const spaceId = m.id;
    if (typeof spaceId !== 'string' || state.done) return;
    setState(s => ({
      ...s,
      mount: m,
      source: {
        kind: 'space',
        spaceId
      },
      segments: [],
      step: null,
      error: null
    }));
    void loadStep(m, []);
  }, [loadStep, state.done]);
  const enter = (0, _react.useCallback)(entry => {
    if (!entry.isDir || !state.mount || state.segments.length >= _navigation.MAX_DEPTH) return;
    void loadStep(state.mount, [...state.segments, entry.name]);
  }, [state.segments, state.mount, loadStep]);
  const jump = (0, _react.useCallback)(depth => {
    if (!state.mount) return;
    void loadStep(state.mount, state.segments.slice(0, depth));
  }, [state.segments, state.mount, loadStep]);
  const pick = (0, _react.useCallback)(entry => {
    if (!(0, _navigation.pickable)(entry, kinds) || !state.mount || !state.source) return;
    const bundlePath = (0, _navigation.pathFromSegments)([...state.segments, entry.name]);
    // ONE pick = ONE bundle (spec §3): the location names the picked directory
    // under the source it was actually navigated from (repo — with its ref —
    // or the strip-granted space), so the host's re-probe checks the SAME
    // bytes the user saw (G-OB-7).
    (0, _sdk.completeTask)({
      location: (0, _navigation.locationForPick)(state.source, bundlePath)
    });
    setState(s => ({
      ...s,
      done: true
    }));
  }, [state.segments, state.mount, state.source, kinds]);

  // No invocation yet: say so, with an escape — never the generic picker chrome,
  // which made a dead/late invocation indistinguishable from `kinds: []`
  // (nothing pickable, no explanation). Off-host (`vite dev`) this state simply
  // persists: there is no host to invoke this app as a callee.
  if (input === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(Chrome, {
      title: "Open a bundle",
      sub: /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "bp-sub",
        role: "status",
        children: "Waiting for the invocation\u2026"
      })
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(Chrome, {
    title: `Open ${kinds.join(' / ') || 'a bundle'}`,
    sub: /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "bp-sub",
      children: "Pick one bundle of a requested kind. Everything else stays where it is."
    }),
    done: state.done,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "bp-paste",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        value: state.locator,
        placeholder: "github:owner/repository@ref",
        onChange: e => setState(s => ({
          ...s,
          locator: e.target.value
        })),
        onKeyDown: e => e.key === 'Enter' && void openRepo(),
        disabled: state.busy === 'mounting' || state.done,
        "aria-label": "Repository location"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        onClick: () => void openRepo(),
        disabled: state.busy === 'mounting' || state.done || !state.locator.trim(),
        children: state.busy === 'mounting' ? 'Opening…' : 'Open repository'
      })]
    }), spaceRoots.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "bp-spaces",
      "aria-label": "Spaces you picked",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "bp-spaces-sub",
        children: "From your spaces (read-only, this task only):"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "bp-spaces-list",
        children: spaceRoots.map(m => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            onClick: () => openSpace(m),
            disabled: state.done || state.busy !== null,
            "aria-current": state.source?.kind === 'space' && state.source.spaceId === m.id ? 'true' : undefined,
            children: m.name ?? m.id ?? 'a granted root'
          })
        }, m.id))
      })]
    }), shownError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "bp-error",
      role: "alert",
      children: shownError
    }), state.busy === 'listing' && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "bp-busy",
      children: "Listing\u2026"
    }), state.step && !currentRootGone && /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "bp-nav",
      "aria-busy": state.busy === 'listing',
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
        className: "bp-crumbs",
        "aria-label": "Location",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          onClick: () => jump(0),
          children: state.mount?.name ?? 'root'
        }), state.segments.map((seg, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          onClick: () => jump(i + 1),
          children: seg
        }, i))]
      }), state.step.truncated && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "bp-truncated",
        children: ["Showing the first ", state.step.entries.length, " entries of a large directory."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "bp-list",
        children: state.step.entries.map(e => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
          className: (0, _navigation.pickable)(e, kinds) ? 'bp-bundle' : undefined,
          children: [e.isDir ? (0, _navigation.pickable)(e, kinds) ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            type: "button",
            className: "bp-pick",
            onClick: () => pick(e),
            disabled: state.done,
            children: ["Open this ", e.kind]
          }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            type: "button",
            onClick: () => enter(e),
            disabled: state.done,
            children: [e.name, "/"]
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "bp-file",
            children: e.name
          }), e.isDir && !(0, _navigation.pickable)(e, kinds) && e.kind && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "bp-kind",
            children: e.kind
          })]
        }, e.name))
      })]
    })]
  });
}
_s(App, "93d+oW2AKWq2TouWBcJaShDMjeY=", false, function () {
  return [_sdk.useTaskInput, _sdk.useMounts];
});
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "Chrome");
$RefreshReg$(_c2, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9uYXZpZ2F0aW9uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkNocm9tZSIsInRpdGxlIiwic3ViIiwiZG9uZSIsImNoaWxkcmVuIiwianN4cyIsImNsYXNzTmFtZSIsImpzeCIsInR5cGUiLCJvbkNsaWNrIiwiY2FuY2VsVGFzayIsImRpc2FibGVkIiwiX2MiLCJBcHAiLCJpbnB1dCIsInVzZVRhc2tJbnB1dCIsImtpbmRzIiwidXNlTWVtbyIsIkFycmF5IiwiaXNBcnJheSIsInBhcmFtcyIsInN0YXRlIiwic2V0U3RhdGUiLCJ1c2VTdGF0ZSIsIm1vdW50IiwibmF2VG9rZW4iLCJzb3VyY2UiLCJsb2NhdG9yIiwic2VnbWVudHMiLCJzdGVwIiwiYnVzeSIsImVycm9yIiwibW91bnRzIiwidXNlTW91bnRzIiwic3BhY2VSb290cyIsInNwYWNlUm9vdHNPZiIsImN1cnJlbnRTcGFjZUlkIiwia2luZCIsInNwYWNlSWQiLCJjdXJyZW50Um9vdEdvbmUiLCJzb21lIiwibSIsImlkIiwic2hvd25FcnJvciIsImxvYWRTdGVwIiwidXNlQ2FsbGJhY2siLCJ0b2tlbiIsInMiLCJuYXZpZ2F0aW9uU3RlcCIsIm9wZW5GcyIsInBhdGhGcm9tU2VnbWVudHMiLCJsZW5ndGgiLCJlIiwibWVzc2FnZSIsIlN0cmluZyIsIm9wZW5SZXBvIiwidHJpbSIsImVyciIsImNvZGUiLCJvcGVuU3BhY2UiLCJlbnRlciIsImVudHJ5IiwiaXNEaXIiLCJNQVhfREVQVEgiLCJuYW1lIiwianVtcCIsImRlcHRoIiwic2xpY2UiLCJwaWNrIiwicGlja2FibGUiLCJidW5kbGVQYXRoIiwiY29tcGxldGVUYXNrIiwibG9jYXRpb24iLCJsb2NhdGlvbkZvclBpY2siLCJyb2xlIiwiam9pbiIsInZhbHVlIiwicGxhY2Vob2xkZXIiLCJvbkNoYW5nZSIsInRhcmdldCIsIm9uS2V5RG93biIsImtleSIsIm1hcCIsInVuZGVmaW5lZCIsInNlZyIsImkiLCJ0cnVuY2F0ZWQiLCJlbnRyaWVzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgb3Blbi1idW5kbGUgcGlja2VyIGFwcCAoT1BFTl9CVU5ETEVfU1BFQyDCpzIvwqczLCBSMy00OTkpIOKAlCB0aGUgZGVmYXVsdFxuLy8gcHJvdmlkZXIgYm91bmQgYXQgYHRhc2sub3Blbi1idW5kbGVgLiBBIHRyYW5zaWVudCB0YXNrIGFwcDogcmVhZCB0aGUgaW52b2NhdGlvblxuLy8gKGBraW5kc2ApLCBsZXQgdGhlIHVzZXIgbmF2aWdhdGUgKHBhc3RlIGEgcmVwbyBsb2NhdGlvbiDigJQgdGhlIGhvc3QncyBydW50aW1lXG4vLyBtb3VudCB2ZXJiIG1vdW50cyBpdCBgcm9gIGFmdGVyIHBlci1yZXBvIGNvbnNlbnQg4oCUIHRoZW4gYnJvd3NlKSwgcmV2ZWFsIGJ1bmRsZXNcbi8vIGJ5IG1hcmtlciBga2luZGAsIGFuZCBjb21wbGV0ZSB3aXRoIE9ORSBgeyBsb2NhdGlvbiB9YCDigJQgYSBwb2ludGVyLCBuZXZlclxuLy8gYXV0aG9yaXR5LiBUaGUgaG9zdCBpbmRlcGVuZGVudGx5IHJlLXByb2JlcyB0aGUgcGljayAoRy1PQi03KTsgb3VyIGpvYiBpcyBhblxuLy8gaG9uZXN0LCBib3VuZGVkIFVJLlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNhbmNlbFRhc2ssIGNvbXBsZXRlVGFzaywgbW91bnQsIG9wZW5GcywgdXNlTW91bnRzLCB1c2VUYXNrSW5wdXQsIHR5cGUgU2FuZGJveE1vdW50IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHtcbiAgTUFYX0RFUFRILFxuICBsb2NhdGlvbkZvclBpY2ssXG4gIG5hdmlnYXRpb25TdGVwLFxuICBwYXRoRnJvbVNlZ21lbnRzLFxuICBwaWNrYWJsZSxcbiAgc3BhY2VSb290c09mLFxuICB0eXBlIFBpY2tlclNvdXJjZSxcbiAgdHlwZSBSZXZlYWxlZEVudHJ5LFxuICB0eXBlIFN0ZXBSZXN1bHQsXG59IGZyb20gJy4vbGliL25hdmlnYXRpb24nO1xuXG5pbnRlcmZhY2UgUGlja2VyU3RhdGUge1xuICBtb3VudDogU2FuZGJveE1vdW50IHwgbnVsbDtcbiAgLyoqIElkZW50aXR5IHRva2VuIG9mIHRoZSBMQVRFU1QgaXNzdWVkIG5hdmlnYXRpb247IGEgcmVzb2x2aW5nIGxpc3RpbmdcbiAgICogIGFwcGxpZXMgb25seSB3aGVuIGl0IHN0aWxsIGhvbGRzIHRoZSB0b2tlbiAoc3RhbGVuZXNzIGd1YXJkKS4gKi9cbiAgbmF2VG9rZW46IG9iamVjdDtcbiAgLyoqIFdoYXQgYG1vdW50YCBpczogdGhlIHBhc3RlZCByZXBvLCBvciBhIHNwYWNlIHRoZSB1c2VyIHBpY2tlZCBpbiB0aGUgaG9zdCdzXG4gICAqICBzcGFjZXMgc3RyaXAgKGFubm91bmNlZCBtaWQtdGFzaywgYHJvYCwgZGllcyB3aXRoIHRoZSBpbnZvY2F0aW9uKS4gKi9cbiAgc291cmNlOiBQaWNrZXJTb3VyY2UgfCBudWxsO1xuICAvKiogVGhlIHJlcG8gbG9jYXRvciB0aGUgdXNlciBwYXN0ZWQgKGBnaXRodWI6bnMvcmVwb1tAcmVmXWApLiAqL1xuICBsb2NhdG9yOiBzdHJpbmc7XG4gIHNlZ21lbnRzOiBzdHJpbmdbXTtcbiAgc3RlcDogU3RlcFJlc3VsdCB8IG51bGw7XG4gIGJ1c3k6IHN0cmluZyB8IG51bGw7XG4gIGVycm9yOiBzdHJpbmcgfCBudWxsO1xuICBkb25lOiBib29sZWFuO1xufVxuXG4vKiogVGhlIGNocm9tZSBib3RoIHJlbmRlciBzdGF0ZXMgc2hhcmU6IHRoZSBoZWFkIGJsb2NrIGFuZCB0aGUgQ2FuY2VsIGZvb3Rlci4gKi9cbmZ1bmN0aW9uIENocm9tZSh7IHRpdGxlLCBzdWIsIGRvbmUsIGNoaWxkcmVuIH06IHsgdGl0bGU6IHN0cmluZzsgc3ViOiBSZWFjdE5vZGU7IGRvbmU/OiBib29sZWFuOyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYnAtcm9vdFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJicC1oZWFkXCI+XG4gICAgICAgIDxoMT57dGl0bGV9PC9oMT5cbiAgICAgICAge3N1Yn1cbiAgICAgIDwvaGVhZGVyPlxuICAgICAge2NoaWxkcmVufVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJicC1mb290XCI+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJwLWNhbmNlbFwiIG9uQ2xpY2s9eygpID0+IGNhbmNlbFRhc2soKX0gZGlzYWJsZWQ9e2RvbmV9PlxuICAgICAgICAgIENhbmNlbFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9vdGVyPlxuICAgIDwvbWFpbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICAvLyBUaGUgaW52b2NhdGlvbiBhcnJpdmVzIGFzIGEgaG9zdOKGkmZyYW1lIGB0YXNrLWlucHV0YCBwdXNoIHdob3NlIGRlbGl2ZXJ5IGlzXG4gIC8vIG9ic2VydmVkLXVucmVsaWFibGUgYXQgbW91bnQgKHNpdGUtbWFpbidzIHRhc2tJbnB1dERlbGl2ZXJ5LCBSMy01NTAg4oCUIHRoZVxuICAvLyByZXBsYXlhYmxlIHBvbGwgaXMgUjMtNzg3KS4gUmVhZCBpdCByZWFjdGl2ZWx5IChgdXNlVGFza0lucHV0YCwgdGhlIFNESydzXG4gIC8vIGhvb2sgZm9yIGV4YWN0bHkgdGhpcykgc28gYSBkZWxpdmVyeSBsYW5kaW5nIGFmdGVyIGZpcnN0IHJlbmRlciBzdGlsbFxuICAvLyByZWFjaGVzIHRoZSBVSTsgYSBvbmUtc2hvdCBgZ2V0VGFza0lucHV0KClgIGluIGEgdXNlTWVtbyBmcm96ZSBga2luZHNgIGF0XG4gIC8vIFtdIGZvcmV2ZXIgYW5kIHJlbmRlcmVkIGV2ZXJ5IG1hcmtlci1iZWFyaW5nIGRpcmVjdG9yeSB1bnBpY2thYmxlIChmb3VuZFxuICAvLyBsaXZlIG9uIHRoZSB2ZW51ZSwgUjMtNTE4J3Mgcm91bmQtdHJpcCAyMDI2LTA5LTI5KS5cbiAgY29uc3QgaW5wdXQgPSB1c2VUYXNrSW5wdXQoKTtcbiAgY29uc3Qga2luZHM6IHJlYWRvbmx5IHN0cmluZ1tdID0gdXNlTWVtbyhcbiAgICAoKSA9PiAoQXJyYXkuaXNBcnJheSgoaW5wdXQ/LnBhcmFtcyBhcyB7IGtpbmRzPzogdW5rbm93biB9KT8ua2luZHMpID8gKChpbnB1dD8ucGFyYW1zIGFzIHsga2luZHM/OiBzdHJpbmdbXSB9KS5raW5kcyA/PyBbXSkgOiBbXSksXG4gICAgW2lucHV0XSxcbiAgKTtcbiAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZTxQaWNrZXJTdGF0ZT4oe1xuICAgIG1vdW50OiBudWxsLFxuICAgIG5hdlRva2VuOiB7fSxcbiAgICBzb3VyY2U6IG51bGwsXG4gICAgbG9jYXRvcjogJycsXG4gICAgc2VnbWVudHM6IFtdLFxuICAgIHN0ZXA6IG51bGwsXG4gICAgYnVzeTogbnVsbCxcbiAgICBlcnJvcjogbnVsbCxcbiAgICBkb25lOiBmYWxzZSxcbiAgfSk7XG5cbiAgLy8gVGhlIHNwYWNlcyBsZWcgKHNwZWMgwqc0KTogdGhlIGhvc3QncyBzcGFjZXMgc3RyaXAgcHVzaGVzIGEgc2NvcGVkIGByb2BcbiAgLy8gbmF2aWdhdGlvbiByb290IGludG8gdGhpcyBmcmFtZSBwZXIgcGljaywgYW5ub3VuY2VkIGFzIGFuIG9yZGluYXJ5XG4gIC8vIG1vdW50LWFkZDsgYHVzZU1vdW50cygpYCBpcyBob3cgd2Ugc2VlIGl0LiBXZSBuZXZlciBlbnVtZXJhdGUgc3BhY2VzIOKAlCB0aGVcbiAgLy8gc3RyaXAgKGhvc3QgY2hyb21lKSBkaWQgdGhhdDsgd2UgbmF2aWdhdGUgb25seSB3aGF0IHdlIHdlcmUgaGFuZGVkLlxuICBjb25zdCBtb3VudHMgPSB1c2VNb3VudHMoKTtcbiAgY29uc3Qgc3BhY2VSb290cyA9IHVzZU1lbW8oKCkgPT4gc3BhY2VSb290c09mKG1vdW50cyksIFttb3VudHNdKTtcblxuICAvLyBBIGdyYW50ZWQgcm9vdCBjYW4gdmFuaXNoIG1pZC10YXNrICh0aGUgc3BhY2Ugd2FzIHVuc2hhcmVkIOKAlCB0aGUgaG9zdFxuICAvLyB0ZWFycyB0aGUgbW91bnQgZG93biB3aXRoaW4gb25lIHNuYXBzaG90KS4gRGVyaXZlZCBhdCBSRU5ERVIsIG5vdCBhblxuICAvLyBlZmZlY3Q6IHdoaWxlIHRoZSBuYXZpZ2F0ZWQgcm9vdCBpcyBnb25lIHRoZSBuYXYgaXMgbm90IHJlbmRlcmVkIGFuZCB0aGVcbiAgLy8gbG9zcyBpcyBuYW1lZDsgaW4tZmxpZ2h0IGxpc3RpbmdzIG9mIHRoZSBkZWFkIHJvb3QgYXJlIGRyb3BwZWQgYnkgdGhlXG4gIC8vIHRva2VuICsgdGhlIHN0aWxsLWhlbGQgY2hlY2sgaW4gbG9hZFN0ZXAgKGl0cyByZWFkcyByZWplY3QgYXQgdGhlIHJldm9rZWRcbiAgLy8gcG9ydCBhbnl3YXkpLlxuICBjb25zdCBjdXJyZW50U3BhY2VJZCA9IHN0YXRlLnNvdXJjZT8ua2luZCA9PT0gJ3NwYWNlJyA/IHN0YXRlLnNvdXJjZS5zcGFjZUlkIDogbnVsbDtcbiAgY29uc3QgY3VycmVudFJvb3RHb25lID0gY3VycmVudFNwYWNlSWQgIT09IG51bGwgJiYgIXNwYWNlUm9vdHMuc29tZSgobSkgPT4gbS5pZCA9PT0gY3VycmVudFNwYWNlSWQpO1xuICBjb25zdCBzaG93bkVycm9yID0gY3VycmVudFJvb3RHb25lID8gJ1RoYXQgc3BhY2UgaXMgbm8gbG9uZ2VyIGF2YWlsYWJsZS4nIDogc3RhdGUuZXJyb3I7XG5cbiAgLy8gU3RhbGVuZXNzOiBldmVyeSBuYXZpZ2F0aW9uIGlzc3VlcyBhIGZyZXNoIHRva2VuLCBhbmQgYSByZXNvbHZpbmcgbGlzdGluZ1xuICAvLyBhcHBsaWVzIG9ubHkgd2hpbGUgaXQgc3RpbGwgaG9sZHMgaXQg4oCUIGEgc2xvdyByZWFkIG9mIHNwYWNlIEEgbXVzdCBuZXZlclxuICAvLyByZW5kZXIgdW5kZXIgc3BhY2UgQidzIHNvdXJjZSAoYSBwaWNrIHdvdWxkIHRoZW4gcmV0dXJuIEIncyBzcGFjZUlkIHdpdGhcbiAgLy8gQSdzIHBhdGgg4oCUIHRoZSBtaXNkaXJlY3Rpb24gY2xhc3MgdGhlIGhvc3QncyBHLU9CLTcgcmUtcHJvYmUgZXhpc3RzIHRvXG4gIC8vIGNhdGNoLCBhbmQgdGhpcyBhcHAgcmVmdXNlcyB0byBwcm9kdWNlIGluIHRoZSBmaXJzdCBwbGFjZSkuIEEgUkVWT0tFRFxuICAvLyByb290J3MgbGF0ZSByZWFkcyBuZWVkIG5vIGNoZWNrIGhlcmU6IHRoZSBob3N0J3MgZXhwb3J0IGJvdW5kYXJ5IHJlamVjdHNcbiAgLy8gdGhlbSB0ZXJtaW5hbGx5LCB0aGV5IGxhbmQgaW4gdGhlIGNhdGNoLCBhbmQgdGhlIHJlbmRlci1kZXJpdmVkXG4gIC8vIGBjdXJyZW50Um9vdEdvbmVgIHdvcmRpbmcgKCdubyBsb25nZXIgYXZhaWxhYmxlJykgaXMgd2hhdCB0aGUgdXNlciBzZWVzLlxuICBjb25zdCBsb2FkU3RlcCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChtOiBTYW5kYm94TW91bnQsIHNlZ21lbnRzOiBzdHJpbmdbXSkgPT4ge1xuICAgICAgY29uc3QgdG9rZW4gPSB7fTtcbiAgICAgIHNldFN0YXRlKChzKSA9PiAoeyAuLi5zLCBuYXZUb2tlbjogdG9rZW4sIGJ1c3k6ICdsaXN0aW5nJywgZXJyb3I6IG51bGwgfSkpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc3RlcCA9IGF3YWl0IG5hdmlnYXRpb25TdGVwKG9wZW5GcyhtKSwgcGF0aEZyb21TZWdtZW50cyhzZWdtZW50cyksIHNlZ21lbnRzLmxlbmd0aCk7XG4gICAgICAgIHNldFN0YXRlKChzKSA9PiAocy5uYXZUb2tlbiA9PT0gdG9rZW4gPyB7IC4uLnMsIHNlZ21lbnRzLCBzdGVwLCBidXN5OiBudWxsIH0gOiBzKSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBTdHJpbmcoKGUgYXMgRXJyb3IpPy5tZXNzYWdlID8/IGUpO1xuICAgICAgICBzZXRTdGF0ZSgocykgPT4gKHMubmF2VG9rZW4gPT09IHRva2VuID8geyAuLi5zLCBidXN5OiBudWxsLCBlcnJvcjogbWVzc2FnZSB9IDogcykpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW10sXG4gICk7XG5cbiAgY29uc3Qgb3BlblJlcG8gPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgbG9jYXRvciA9IHN0YXRlLmxvY2F0b3IudHJpbSgpO1xuICAgIGlmICghbG9jYXRvcikgcmV0dXJuO1xuICAgIC8vIFJvdGF0ZSB0aGUgc3RhbGVuZXNzIHRva2VuIGFuZCBkcm9wIHRoZSBwcmV2aW91cyB0cmVlIE5PVzogYSBsaXN0aW5nXG4gICAgLy8gc3RpbGwgaW4gZmxpZ2h0IGZyb20gdGhlIG9sZCBzb3VyY2UgbXVzdCBub3QgcmVzb2x2ZSBtaWQtbW91bnQgKGl0IHdvdWxkXG4gICAgLy8gY2xvYmJlciBidXN5Oidtb3VudGluZycgYW5kIHJlLWVuYWJsZSB0aGUgY29udHJvbHMg4oCUIFItSVgtMiDigJQgYW5kIHBhaW50XG4gICAgLy8gdGhlIG9sZCByb290J3MgZW50cmllcyBvdmVyIHRoZSBpbmNvbWluZyBvbmUpLlxuICAgIHNldFN0YXRlKChzKSA9PiAoeyAuLi5zLCBuYXZUb2tlbjoge30sIHN0ZXA6IG51bGwsIGJ1c3k6ICdtb3VudGluZycsIGVycm9yOiBudWxsIH0pKTtcbiAgICB0cnkge1xuICAgICAgLy8gVGhlIGhvc3QncyBydW50aW1lIG1vdW50IHZlcmI6IGByb2AgbW91bnQgKyBwZXItcmVwbyBjb25zZW50IChMMSkuXG4gICAgICBjb25zdCBtID0gYXdhaXQgbW91bnQobG9jYXRvcik7XG4gICAgICBzZXRTdGF0ZSgocykgPT4gKHsgLi4ucywgbW91bnQ6IG0sIHNvdXJjZTogeyBraW5kOiAncmVwbycsIGxvY2F0b3IgfSwgc2VnbWVudHM6IFtdLCBzdGVwOiBudWxsLCBidXN5OiBudWxsIH0pKTtcbiAgICAgIGF3YWl0IGxvYWRTdGVwKG0sIFtdKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBlcnIgPSBlIGFzIEVycm9yICYgeyBjb2RlPzogc3RyaW5nIH07XG4gICAgICBzZXRTdGF0ZSgocykgPT4gKHsgLi4ucywgYnVzeTogbnVsbCwgZXJyb3I6IGVyci5jb2RlID8gYCR7ZXJyLmNvZGV9OiAke2Vyci5tZXNzYWdlfWAgOiBlcnIubWVzc2FnZSB9KSk7XG4gICAgfVxuICB9LCBbc3RhdGUubG9jYXRvciwgbG9hZFN0ZXBdKTtcblxuICAvLyBOYXZpZ2F0ZSBhIHN0cmlwLWdyYW50ZWQgc3BhY2Ugcm9vdCAodGhlIGhvc3QgYWxyZWFkeSBjb25zZW50ZWQgdGhpcyBwaWNrIOKAlFxuICAvLyB0aGUgc3RyaXAgSVMgdGhlIHVzZXIncyBnZXN0dXJlOyBub3RoaW5nIGhlcmUgcHJvbXB0cyBhZ2FpbikuXG4gIGNvbnN0IG9wZW5TcGFjZSA9IHVzZUNhbGxiYWNrKFxuICAgIChtOiBTYW5kYm94TW91bnQpID0+IHtcbiAgICAgIGNvbnN0IHNwYWNlSWQgPSBtLmlkO1xuICAgICAgaWYgKHR5cGVvZiBzcGFjZUlkICE9PSAnc3RyaW5nJyB8fCBzdGF0ZS5kb25lKSByZXR1cm47XG4gICAgICBzZXRTdGF0ZSgocykgPT4gKHsgLi4ucywgbW91bnQ6IG0sIHNvdXJjZTogeyBraW5kOiAnc3BhY2UnLCBzcGFjZUlkIH0sIHNlZ21lbnRzOiBbXSwgc3RlcDogbnVsbCwgZXJyb3I6IG51bGwgfSkpO1xuICAgICAgdm9pZCBsb2FkU3RlcChtLCBbXSk7XG4gICAgfSxcbiAgICBbbG9hZFN0ZXAsIHN0YXRlLmRvbmVdLFxuICApO1xuXG4gIGNvbnN0IGVudGVyID0gdXNlQ2FsbGJhY2soXG4gICAgKGVudHJ5OiBSZXZlYWxlZEVudHJ5KSA9PiB7XG4gICAgICBpZiAoIWVudHJ5LmlzRGlyIHx8ICFzdGF0ZS5tb3VudCB8fCBzdGF0ZS5zZWdtZW50cy5sZW5ndGggPj0gTUFYX0RFUFRIKSByZXR1cm47XG4gICAgICB2b2lkIGxvYWRTdGVwKHN0YXRlLm1vdW50LCBbLi4uc3RhdGUuc2VnbWVudHMsIGVudHJ5Lm5hbWVdKTtcbiAgICB9LFxuICAgIFtzdGF0ZS5zZWdtZW50cywgc3RhdGUubW91bnQsIGxvYWRTdGVwXSxcbiAgKTtcblxuICBjb25zdCBqdW1wID0gdXNlQ2FsbGJhY2soXG4gICAgKGRlcHRoOiBudW1iZXIpID0+IHtcbiAgICAgIGlmICghc3RhdGUubW91bnQpIHJldHVybjtcbiAgICAgIHZvaWQgbG9hZFN0ZXAoc3RhdGUubW91bnQsIHN0YXRlLnNlZ21lbnRzLnNsaWNlKDAsIGRlcHRoKSk7XG4gICAgfSxcbiAgICBbc3RhdGUuc2VnbWVudHMsIHN0YXRlLm1vdW50LCBsb2FkU3RlcF0sXG4gICk7XG5cbiAgY29uc3QgcGljayA9IHVzZUNhbGxiYWNrKFxuICAgIChlbnRyeTogUmV2ZWFsZWRFbnRyeSkgPT4ge1xuICAgICAgaWYgKCFwaWNrYWJsZShlbnRyeSwga2luZHMpIHx8ICFzdGF0ZS5tb3VudCB8fCAhc3RhdGUuc291cmNlKSByZXR1cm47XG4gICAgICBjb25zdCBidW5kbGVQYXRoID0gcGF0aEZyb21TZWdtZW50cyhbLi4uc3RhdGUuc2VnbWVudHMsIGVudHJ5Lm5hbWVdKTtcbiAgICAgIC8vIE9ORSBwaWNrID0gT05FIGJ1bmRsZSAoc3BlYyDCpzMpOiB0aGUgbG9jYXRpb24gbmFtZXMgdGhlIHBpY2tlZCBkaXJlY3RvcnlcbiAgICAgIC8vIHVuZGVyIHRoZSBzb3VyY2UgaXQgd2FzIGFjdHVhbGx5IG5hdmlnYXRlZCBmcm9tIChyZXBvIOKAlCB3aXRoIGl0cyByZWYg4oCUXG4gICAgICAvLyBvciB0aGUgc3RyaXAtZ3JhbnRlZCBzcGFjZSksIHNvIHRoZSBob3N0J3MgcmUtcHJvYmUgY2hlY2tzIHRoZSBTQU1FXG4gICAgICAvLyBieXRlcyB0aGUgdXNlciBzYXcgKEctT0ItNykuXG4gICAgICBjb21wbGV0ZVRhc2soeyBsb2NhdGlvbjogbG9jYXRpb25Gb3JQaWNrKHN0YXRlLnNvdXJjZSwgYnVuZGxlUGF0aCkgfSk7XG4gICAgICBzZXRTdGF0ZSgocykgPT4gKHsgLi4ucywgZG9uZTogdHJ1ZSB9KSk7XG4gICAgfSxcbiAgICBbc3RhdGUuc2VnbWVudHMsIHN0YXRlLm1vdW50LCBzdGF0ZS5zb3VyY2UsIGtpbmRzXSxcbiAgKTtcblxuICAvLyBObyBpbnZvY2F0aW9uIHlldDogc2F5IHNvLCB3aXRoIGFuIGVzY2FwZSDigJQgbmV2ZXIgdGhlIGdlbmVyaWMgcGlja2VyIGNocm9tZSxcbiAgLy8gd2hpY2ggbWFkZSBhIGRlYWQvbGF0ZSBpbnZvY2F0aW9uIGluZGlzdGluZ3Vpc2hhYmxlIGZyb20gYGtpbmRzOiBbXWBcbiAgLy8gKG5vdGhpbmcgcGlja2FibGUsIG5vIGV4cGxhbmF0aW9uKS4gT2ZmLWhvc3QgKGB2aXRlIGRldmApIHRoaXMgc3RhdGUgc2ltcGx5XG4gIC8vIHBlcnNpc3RzOiB0aGVyZSBpcyBubyBob3N0IHRvIGludm9rZSB0aGlzIGFwcCBhcyBhIGNhbGxlZS5cbiAgaWYgKGlucHV0ID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxDaHJvbWVcbiAgICAgICAgdGl0bGU9XCJPcGVuIGEgYnVuZGxlXCJcbiAgICAgICAgc3ViPXtcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJicC1zdWJcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICBXYWl0aW5nIGZvciB0aGUgaW52b2NhdGlvbuKAplxuICAgICAgICAgIDwvcD5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Q2hyb21lXG4gICAgICB0aXRsZT17YE9wZW4gJHtraW5kcy5qb2luKCcgLyAnKSB8fCAnYSBidW5kbGUnfWB9XG4gICAgICBzdWI9ezxwIGNsYXNzTmFtZT1cImJwLXN1YlwiPlBpY2sgb25lIGJ1bmRsZSBvZiBhIHJlcXVlc3RlZCBraW5kLiBFdmVyeXRoaW5nIGVsc2Ugc3RheXMgd2hlcmUgaXQgaXMuPC9wPn1cbiAgICAgIGRvbmU9e3N0YXRlLmRvbmV9XG4gICAgPlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYnAtcGFzdGVcIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdmFsdWU9e3N0YXRlLmxvY2F0b3J9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJnaXRodWI6b3duZXIvcmVwb3NpdG9yeUByZWZcIlxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhdGUoKHMpID0+ICh7IC4uLnMsIGxvY2F0b3I6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICBvbktleURvd249eyhlKSA9PiBlLmtleSA9PT0gJ0VudGVyJyAmJiB2b2lkIG9wZW5SZXBvKCl9XG4gICAgICAgICAgZGlzYWJsZWQ9e3N0YXRlLmJ1c3kgPT09ICdtb3VudGluZycgfHwgc3RhdGUuZG9uZX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUmVwb3NpdG9yeSBsb2NhdGlvblwiXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHZvaWQgb3BlblJlcG8oKX0gZGlzYWJsZWQ9e3N0YXRlLmJ1c3kgPT09ICdtb3VudGluZycgfHwgc3RhdGUuZG9uZSB8fCAhc3RhdGUubG9jYXRvci50cmltKCl9PlxuICAgICAgICAgIHtzdGF0ZS5idXN5ID09PSAnbW91bnRpbmcnID8gJ09wZW5pbmfigKYnIDogJ09wZW4gcmVwb3NpdG9yeSd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7c3BhY2VSb290cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYnAtc3BhY2VzXCIgYXJpYS1sYWJlbD1cIlNwYWNlcyB5b3UgcGlja2VkXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYnAtc3BhY2VzLXN1YlwiPkZyb20geW91ciBzcGFjZXMgKHJlYWQtb25seSwgdGhpcyB0YXNrIG9ubHkpOjwvcD5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYnAtc3BhY2VzLWxpc3RcIj5cbiAgICAgICAgICAgIHtzcGFjZVJvb3RzLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgICA8bGkga2V5PXttLmlkfT5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5TcGFjZShtKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdGF0ZS5kb25lIHx8IHN0YXRlLmJ1c3kgIT09IG51bGx9XG4gICAgICAgICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e3N0YXRlLnNvdXJjZT8ua2luZCA9PT0gJ3NwYWNlJyAmJiBzdGF0ZS5zb3VyY2Uuc3BhY2VJZCA9PT0gbS5pZCA/ICd0cnVlJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7LyogVHdvIG5hbWVsZXNzIHNwYWNlcyBtdXN0IG5vdCByZW5kZXIgaWRlbnRpY2FsIGJ1dHRvbnMg4oCUXG4gICAgICAgICAgICAgICAgICAgICAgZmFsbCBiYWNrIHRvIHRoZSBtb3VudCdzIGlkLCBub3QgYSBjb25zdGFudC4gKi99XG4gICAgICAgICAgICAgICAgICB7bS5uYW1lID8/IG0uaWQgPz8gJ2EgZ3JhbnRlZCByb290J31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICl9XG5cbiAgICAgIHtzaG93bkVycm9yICYmIDxwIGNsYXNzTmFtZT1cImJwLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3Nob3duRXJyb3J9PC9wPn1cbiAgICAgIHtzdGF0ZS5idXN5ID09PSAnbGlzdGluZycgJiYgPHAgY2xhc3NOYW1lPVwiYnAtYnVzeVwiPkxpc3RpbmfigKY8L3A+fVxuXG4gICAgICB7c3RhdGUuc3RlcCAmJiAhY3VycmVudFJvb3RHb25lICYmIChcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYnAtbmF2XCIgYXJpYS1idXN5PXtzdGF0ZS5idXN5ID09PSAnbGlzdGluZyd9PlxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiYnAtY3J1bWJzXCIgYXJpYS1sYWJlbD1cIkxvY2F0aW9uXCI+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBqdW1wKDApfT5cbiAgICAgICAgICAgICAge3N0YXRlLm1vdW50Py5uYW1lID8/ICdyb290J31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAge3N0YXRlLnNlZ21lbnRzLm1hcCgoc2VnLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b24ga2V5PXtpfSB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4ganVtcChpICsgMSl9PlxuICAgICAgICAgICAgICAgIHtzZWd9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9uYXY+XG4gICAgICAgICAge3N0YXRlLnN0ZXAudHJ1bmNhdGVkICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJwLXRydW5jYXRlZFwiPlNob3dpbmcgdGhlIGZpcnN0IHtzdGF0ZS5zdGVwLmVudHJpZXMubGVuZ3RofSBlbnRyaWVzIG9mIGEgbGFyZ2UgZGlyZWN0b3J5LjwvcD5cbiAgICAgICAgICApfVxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJicC1saXN0XCI+XG4gICAgICAgICAgICB7c3RhdGUuc3RlcC5lbnRyaWVzLm1hcCgoZSkgPT4gKFxuICAgICAgICAgICAgICA8bGkga2V5PXtlLm5hbWV9IGNsYXNzTmFtZT17cGlja2FibGUoZSwga2luZHMpID8gJ2JwLWJ1bmRsZScgOiB1bmRlZmluZWR9PlxuICAgICAgICAgICAgICAgIHtlLmlzRGlyID8gKFxuICAgICAgICAgICAgICAgICAgcGlja2FibGUoZSwga2luZHMpID8gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJicC1waWNrXCIgb25DbGljaz17KCkgPT4gcGljayhlKX0gZGlzYWJsZWQ9e3N0YXRlLmRvbmV9PlxuICAgICAgICAgICAgICAgICAgICAgIE9wZW4gdGhpcyB7ZS5raW5kfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGVudGVyKGUpfSBkaXNhYmxlZD17c3RhdGUuZG9uZX0+XG4gICAgICAgICAgICAgICAgICAgICAge2UubmFtZX0vXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicC1maWxlXCI+e2UubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7ZS5pc0RpciAmJiAhcGlja2FibGUoZSwga2luZHMpICYmIGUua2luZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJicC1raW5kXCI+e2Uua2luZH08L3NwYW4+fVxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgKX1cbiAgICA8L0Nocm9tZT5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBT0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBVTBCLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLElBQUFJLEVBQUEsR0FBQUMsWUFBQSxJQW5CMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFnQ0E7QUFDQSxTQUFTQyxNQUFNQSxDQUFDO0VBQUVDLEtBQUs7RUFBRUMsR0FBRztFQUFFQyxJQUFJO0VBQUVDO0FBQWtGLENBQUMsRUFBRTtFQUN2SCxvQkFDRSxJQUFBUCxXQUFBLENBQUFRLElBQUE7SUFBTUMsU0FBUyxFQUFDLFNBQVM7SUFBQUYsUUFBQSxnQkFDdkIsSUFBQVAsV0FBQSxDQUFBUSxJQUFBO01BQVFDLFNBQVMsRUFBQyxTQUFTO01BQUFGLFFBQUEsZ0JBQ3pCLElBQUFQLFdBQUEsQ0FBQVUsR0FBQTtRQUFBSCxRQUFBLEVBQUtIO01BQUssQ0FBSyxDQUFDLEVBQ2ZDLEdBQUc7SUFBQSxDQUNFLENBQUMsRUFDUkUsUUFBUSxlQUNULElBQUFQLFdBQUEsQ0FBQVUsR0FBQTtNQUFRRCxTQUFTLEVBQUMsU0FBUztNQUFBRixRQUFBLGVBQ3pCLElBQUFQLFdBQUEsQ0FBQVUsR0FBQTtRQUFRQyxJQUFJLEVBQUMsUUFBUTtRQUFDRixTQUFTLEVBQUMsV0FBVztRQUFDRyxPQUFPLEVBQUVBLENBQUEsS0FBTSxJQUFBQyxlQUFVLEVBQUMsQ0FBRTtRQUFDQyxRQUFRLEVBQUVSLElBQUs7UUFBQUMsUUFBQSxFQUFDO01BRXpGLENBQVE7SUFBQyxDQUNILENBQUM7RUFBQSxDQUNMLENBQUM7QUFFWDtBQUFDUSxFQUFBLEdBZlFaLE1BQU07QUFpQkEsU0FBU2EsR0FBR0EsQ0FBQSxFQUFHO0VBQUFmLEVBQUE7RUFDNUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNZ0IsS0FBSyxHQUFHLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztFQUM1QixNQUFNQyxLQUF3QixHQUFHLElBQUFDLGNBQU8sRUFDdEMsTUFBT0MsS0FBSyxDQUFDQyxPQUFPLENBQUVMLEtBQUssRUFBRU0sTUFBTSxFQUEwQkosS0FBSyxDQUFDLEdBQUksQ0FBQ0YsS0FBSyxFQUFFTSxNQUFNLEVBQTBCSixLQUFLLElBQUksRUFBRSxHQUFJLEVBQUcsRUFDakksQ0FBQ0YsS0FBSyxDQUNSLENBQUM7RUFDRCxNQUFNLENBQUNPLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFjO0lBQzlDQyxLQUFLLEVBQUUsSUFBSTtJQUNYQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ1pDLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLE9BQU8sRUFBRSxFQUFFO0lBQ1hDLFFBQVEsRUFBRSxFQUFFO0lBQ1pDLElBQUksRUFBRSxJQUFJO0lBQ1ZDLElBQUksRUFBRSxJQUFJO0lBQ1ZDLEtBQUssRUFBRSxJQUFJO0lBQ1g1QixJQUFJLEVBQUU7RUFDUixDQUFDLENBQUM7O0VBRUY7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNNkIsTUFBTSxHQUFHLElBQUFDLGNBQVMsRUFBQyxDQUFDO0VBQzFCLE1BQU1DLFVBQVUsR0FBRyxJQUFBakIsY0FBTyxFQUFDLE1BQU0sSUFBQWtCLHdCQUFZLEVBQUNILE1BQU0sQ0FBQyxFQUFFLENBQUNBLE1BQU0sQ0FBQyxDQUFDOztFQUVoRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNSSxjQUFjLEdBQUdmLEtBQUssQ0FBQ0ssTUFBTSxFQUFFVyxJQUFJLEtBQUssT0FBTyxHQUFHaEIsS0FBSyxDQUFDSyxNQUFNLENBQUNZLE9BQU8sR0FBRyxJQUFJO0VBQ25GLE1BQU1DLGVBQWUsR0FBR0gsY0FBYyxLQUFLLElBQUksSUFBSSxDQUFDRixVQUFVLENBQUNNLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBS04sY0FBYyxDQUFDO0VBQ25HLE1BQU1PLFVBQVUsR0FBR0osZUFBZSxHQUFHLG9DQUFvQyxHQUFHbEIsS0FBSyxDQUFDVSxLQUFLOztFQUV2RjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTWEsUUFBUSxHQUFHLElBQUFDLGtCQUFXLEVBQzFCLE9BQU9KLENBQWUsRUFBRWIsUUFBa0IsS0FBSztJQUM3QyxNQUFNa0IsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUNoQnhCLFFBQVEsQ0FBRXlCLENBQUMsS0FBTTtNQUFFLEdBQUdBLENBQUM7TUFBRXRCLFFBQVEsRUFBRXFCLEtBQUs7TUFBRWhCLElBQUksRUFBRSxTQUFTO01BQUVDLEtBQUssRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDO0lBQzFFLElBQUk7TUFDRixNQUFNRixJQUFJLEdBQUcsTUFBTSxJQUFBbUIsMEJBQWMsRUFBQyxJQUFBQyxXQUFNLEVBQUNSLENBQUMsQ0FBQyxFQUFFLElBQUFTLDRCQUFnQixFQUFDdEIsUUFBUSxDQUFDLEVBQUVBLFFBQVEsQ0FBQ3VCLE1BQU0sQ0FBQztNQUN6RjdCLFFBQVEsQ0FBRXlCLENBQUMsSUFBTUEsQ0FBQyxDQUFDdEIsUUFBUSxLQUFLcUIsS0FBSyxHQUFHO1FBQUUsR0FBR0MsQ0FBQztRQUFFbkIsUUFBUTtRQUFFQyxJQUFJO1FBQUVDLElBQUksRUFBRTtNQUFLLENBQUMsR0FBR2lCLENBQUUsQ0FBQztJQUNwRixDQUFDLENBQUMsT0FBT0ssQ0FBQyxFQUFFO01BQ1YsTUFBTUMsT0FBTyxHQUFHQyxNQUFNLENBQUVGLENBQUMsRUFBWUMsT0FBTyxJQUFJRCxDQUFDLENBQUM7TUFDbEQ5QixRQUFRLENBQUV5QixDQUFDLElBQU1BLENBQUMsQ0FBQ3RCLFFBQVEsS0FBS3FCLEtBQUssR0FBRztRQUFFLEdBQUdDLENBQUM7UUFBRWpCLElBQUksRUFBRSxJQUFJO1FBQUVDLEtBQUssRUFBRXNCO01BQVEsQ0FBQyxHQUFHTixDQUFFLENBQUM7SUFDcEY7RUFDRixDQUFDLEVBQ0QsRUFDRixDQUFDO0VBRUQsTUFBTVEsUUFBUSxHQUFHLElBQUFWLGtCQUFXLEVBQUMsWUFBWTtJQUN2QyxNQUFNbEIsT0FBTyxHQUFHTixLQUFLLENBQUNNLE9BQU8sQ0FBQzZCLElBQUksQ0FBQyxDQUFDO0lBQ3BDLElBQUksQ0FBQzdCLE9BQU8sRUFBRTtJQUNkO0lBQ0E7SUFDQTtJQUNBO0lBQ0FMLFFBQVEsQ0FBRXlCLENBQUMsS0FBTTtNQUFFLEdBQUdBLENBQUM7TUFBRXRCLFFBQVEsRUFBRSxDQUFDLENBQUM7TUFBRUksSUFBSSxFQUFFLElBQUk7TUFBRUMsSUFBSSxFQUFFLFVBQVU7TUFBRUMsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUM7SUFDcEYsSUFBSTtNQUNGO01BQ0EsTUFBTVUsQ0FBQyxHQUFHLE1BQU0sSUFBQWpCLFVBQUssRUFBQ0csT0FBTyxDQUFDO01BQzlCTCxRQUFRLENBQUV5QixDQUFDLEtBQU07UUFBRSxHQUFHQSxDQUFDO1FBQUV2QixLQUFLLEVBQUVpQixDQUFDO1FBQUVmLE1BQU0sRUFBRTtVQUFFVyxJQUFJLEVBQUUsTUFBTTtVQUFFVjtRQUFRLENBQUM7UUFBRUMsUUFBUSxFQUFFLEVBQUU7UUFBRUMsSUFBSSxFQUFFLElBQUk7UUFBRUMsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDLENBQUM7TUFDOUcsTUFBTWMsUUFBUSxDQUFDSCxDQUFDLEVBQUUsRUFBRSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQyxPQUFPVyxDQUFDLEVBQUU7TUFDVixNQUFNSyxHQUFHLEdBQUdMLENBQThCO01BQzFDOUIsUUFBUSxDQUFFeUIsQ0FBQyxLQUFNO1FBQUUsR0FBR0EsQ0FBQztRQUFFakIsSUFBSSxFQUFFLElBQUk7UUFBRUMsS0FBSyxFQUFFMEIsR0FBRyxDQUFDQyxJQUFJLEdBQUcsR0FBR0QsR0FBRyxDQUFDQyxJQUFJLEtBQUtELEdBQUcsQ0FBQ0osT0FBTyxFQUFFLEdBQUdJLEdBQUcsQ0FBQ0o7TUFBUSxDQUFDLENBQUMsQ0FBQztJQUN4RztFQUNGLENBQUMsRUFBRSxDQUFDaEMsS0FBSyxDQUFDTSxPQUFPLEVBQUVpQixRQUFRLENBQUMsQ0FBQzs7RUFFN0I7RUFDQTtFQUNBLE1BQU1lLFNBQVMsR0FBRyxJQUFBZCxrQkFBVyxFQUMxQkosQ0FBZSxJQUFLO0lBQ25CLE1BQU1ILE9BQU8sR0FBR0csQ0FBQyxDQUFDQyxFQUFFO0lBQ3BCLElBQUksT0FBT0osT0FBTyxLQUFLLFFBQVEsSUFBSWpCLEtBQUssQ0FBQ2xCLElBQUksRUFBRTtJQUMvQ21CLFFBQVEsQ0FBRXlCLENBQUMsS0FBTTtNQUFFLEdBQUdBLENBQUM7TUFBRXZCLEtBQUssRUFBRWlCLENBQUM7TUFBRWYsTUFBTSxFQUFFO1FBQUVXLElBQUksRUFBRSxPQUFPO1FBQUVDO01BQVEsQ0FBQztNQUFFVixRQUFRLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsSUFBSTtNQUFFRSxLQUFLLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQztJQUNoSCxLQUFLYSxRQUFRLENBQUNILENBQUMsRUFBRSxFQUFFLENBQUM7RUFDdEIsQ0FBQyxFQUNELENBQUNHLFFBQVEsRUFBRXZCLEtBQUssQ0FBQ2xCLElBQUksQ0FDdkIsQ0FBQztFQUVELE1BQU15RCxLQUFLLEdBQUcsSUFBQWYsa0JBQVcsRUFDdEJnQixLQUFvQixJQUFLO0lBQ3hCLElBQUksQ0FBQ0EsS0FBSyxDQUFDQyxLQUFLLElBQUksQ0FBQ3pDLEtBQUssQ0FBQ0csS0FBSyxJQUFJSCxLQUFLLENBQUNPLFFBQVEsQ0FBQ3VCLE1BQU0sSUFBSVkscUJBQVMsRUFBRTtJQUN4RSxLQUFLbkIsUUFBUSxDQUFDdkIsS0FBSyxDQUFDRyxLQUFLLEVBQUUsQ0FBQyxHQUFHSCxLQUFLLENBQUNPLFFBQVEsRUFBRWlDLEtBQUssQ0FBQ0csSUFBSSxDQUFDLENBQUM7RUFDN0QsQ0FBQyxFQUNELENBQUMzQyxLQUFLLENBQUNPLFFBQVEsRUFBRVAsS0FBSyxDQUFDRyxLQUFLLEVBQUVvQixRQUFRLENBQ3hDLENBQUM7RUFFRCxNQUFNcUIsSUFBSSxHQUFHLElBQUFwQixrQkFBVyxFQUNyQnFCLEtBQWEsSUFBSztJQUNqQixJQUFJLENBQUM3QyxLQUFLLENBQUNHLEtBQUssRUFBRTtJQUNsQixLQUFLb0IsUUFBUSxDQUFDdkIsS0FBSyxDQUFDRyxLQUFLLEVBQUVILEtBQUssQ0FBQ08sUUFBUSxDQUFDdUMsS0FBSyxDQUFDLENBQUMsRUFBRUQsS0FBSyxDQUFDLENBQUM7RUFDNUQsQ0FBQyxFQUNELENBQUM3QyxLQUFLLENBQUNPLFFBQVEsRUFBRVAsS0FBSyxDQUFDRyxLQUFLLEVBQUVvQixRQUFRLENBQ3hDLENBQUM7RUFFRCxNQUFNd0IsSUFBSSxHQUFHLElBQUF2QixrQkFBVyxFQUNyQmdCLEtBQW9CLElBQUs7SUFDeEIsSUFBSSxDQUFDLElBQUFRLG9CQUFRLEVBQUNSLEtBQUssRUFBRTdDLEtBQUssQ0FBQyxJQUFJLENBQUNLLEtBQUssQ0FBQ0csS0FBSyxJQUFJLENBQUNILEtBQUssQ0FBQ0ssTUFBTSxFQUFFO0lBQzlELE1BQU00QyxVQUFVLEdBQUcsSUFBQXBCLDRCQUFnQixFQUFDLENBQUMsR0FBRzdCLEtBQUssQ0FBQ08sUUFBUSxFQUFFaUMsS0FBSyxDQUFDRyxJQUFJLENBQUMsQ0FBQztJQUNwRTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUFPLGlCQUFZLEVBQUM7TUFBRUMsUUFBUSxFQUFFLElBQUFDLDJCQUFlLEVBQUNwRCxLQUFLLENBQUNLLE1BQU0sRUFBRTRDLFVBQVU7SUFBRSxDQUFDLENBQUM7SUFDckVoRCxRQUFRLENBQUV5QixDQUFDLEtBQU07TUFBRSxHQUFHQSxDQUFDO01BQUU1QyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQztFQUN6QyxDQUFDLEVBQ0QsQ0FBQ2tCLEtBQUssQ0FBQ08sUUFBUSxFQUFFUCxLQUFLLENBQUNHLEtBQUssRUFBRUgsS0FBSyxDQUFDSyxNQUFNLEVBQUVWLEtBQUssQ0FDbkQsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlGLEtBQUssS0FBSyxJQUFJLEVBQUU7SUFDbEIsb0JBQ0UsSUFBQWpCLFdBQUEsQ0FBQVUsR0FBQSxFQUFDUCxNQUFNO01BQ0xDLEtBQUssRUFBQyxlQUFlO01BQ3JCQyxHQUFHLGVBQ0QsSUFBQUwsV0FBQSxDQUFBVSxHQUFBO1FBQUdELFNBQVMsRUFBQyxRQUFRO1FBQUNvRSxJQUFJLEVBQUMsUUFBUTtRQUFBdEUsUUFBQSxFQUFDO01BRXBDLENBQUc7SUFDSixDQUNGLENBQUM7RUFFTjtFQUVBLG9CQUNFLElBQUFQLFdBQUEsQ0FBQVEsSUFBQSxFQUFDTCxNQUFNO0lBQ0xDLEtBQUssRUFBRSxRQUFRZSxLQUFLLENBQUMyRCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksVUFBVSxFQUFHO0lBQ2pEekUsR0FBRyxlQUFFLElBQUFMLFdBQUEsQ0FBQVUsR0FBQTtNQUFHRCxTQUFTLEVBQUMsUUFBUTtNQUFBRixRQUFBLEVBQUM7SUFBdUUsQ0FBRyxDQUFFO0lBQ3ZHRCxJQUFJLEVBQUVrQixLQUFLLENBQUNsQixJQUFLO0lBQUFDLFFBQUEsZ0JBRWpCLElBQUFQLFdBQUEsQ0FBQVEsSUFBQTtNQUFTQyxTQUFTLEVBQUMsVUFBVTtNQUFBRixRQUFBLGdCQUMzQixJQUFBUCxXQUFBLENBQUFVLEdBQUE7UUFDRXFFLEtBQUssRUFBRXZELEtBQUssQ0FBQ00sT0FBUTtRQUNyQmtELFdBQVcsRUFBQyw2QkFBNkI7UUFDekNDLFFBQVEsRUFBRzFCLENBQUMsSUFBSzlCLFFBQVEsQ0FBRXlCLENBQUMsS0FBTTtVQUFFLEdBQUdBLENBQUM7VUFBRXBCLE9BQU8sRUFBRXlCLENBQUMsQ0FBQzJCLE1BQU0sQ0FBQ0g7UUFBTSxDQUFDLENBQUMsQ0FBRTtRQUN0RUksU0FBUyxFQUFHNUIsQ0FBQyxJQUFLQSxDQUFDLENBQUM2QixHQUFHLEtBQUssT0FBTyxJQUFJLEtBQUsxQixRQUFRLENBQUMsQ0FBRTtRQUN2RDVDLFFBQVEsRUFBRVUsS0FBSyxDQUFDUyxJQUFJLEtBQUssVUFBVSxJQUFJVCxLQUFLLENBQUNsQixJQUFLO1FBQ2xELGNBQVc7TUFBcUIsQ0FDakMsQ0FBQyxlQUNGLElBQUFOLFdBQUEsQ0FBQVUsR0FBQTtRQUFRQyxJQUFJLEVBQUMsUUFBUTtRQUFDQyxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLOEMsUUFBUSxDQUFDLENBQUU7UUFBQzVDLFFBQVEsRUFBRVUsS0FBSyxDQUFDUyxJQUFJLEtBQUssVUFBVSxJQUFJVCxLQUFLLENBQUNsQixJQUFJLElBQUksQ0FBQ2tCLEtBQUssQ0FBQ00sT0FBTyxDQUFDNkIsSUFBSSxDQUFDLENBQUU7UUFBQXBELFFBQUEsRUFDOUhpQixLQUFLLENBQUNTLElBQUksS0FBSyxVQUFVLEdBQUcsVUFBVSxHQUFHO01BQWlCLENBQ3JELENBQUM7SUFBQSxDQUNGLENBQUMsRUFFVEksVUFBVSxDQUFDaUIsTUFBTSxHQUFHLENBQUMsaUJBQ3BCLElBQUF0RCxXQUFBLENBQUFRLElBQUE7TUFBU0MsU0FBUyxFQUFDLFdBQVc7TUFBQyxjQUFXLG1CQUFtQjtNQUFBRixRQUFBLGdCQUMzRCxJQUFBUCxXQUFBLENBQUFVLEdBQUE7UUFBR0QsU0FBUyxFQUFDLGVBQWU7UUFBQUYsUUFBQSxFQUFDO01BQTZDLENBQUcsQ0FBQyxlQUM5RSxJQUFBUCxXQUFBLENBQUFVLEdBQUE7UUFBSUQsU0FBUyxFQUFDLGdCQUFnQjtRQUFBRixRQUFBLEVBQzNCOEIsVUFBVSxDQUFDZ0QsR0FBRyxDQUFFekMsQ0FBQyxpQkFDaEIsSUFBQTVDLFdBQUEsQ0FBQVUsR0FBQTtVQUFBSCxRQUFBLGVBQ0UsSUFBQVAsV0FBQSxDQUFBVSxHQUFBO1lBQ0VDLElBQUksRUFBQyxRQUFRO1lBQ2JDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNa0QsU0FBUyxDQUFDbEIsQ0FBQyxDQUFFO1lBQzVCOUIsUUFBUSxFQUFFVSxLQUFLLENBQUNsQixJQUFJLElBQUlrQixLQUFLLENBQUNTLElBQUksS0FBSyxJQUFLO1lBQzVDLGdCQUFjVCxLQUFLLENBQUNLLE1BQU0sRUFBRVcsSUFBSSxLQUFLLE9BQU8sSUFBSWhCLEtBQUssQ0FBQ0ssTUFBTSxDQUFDWSxPQUFPLEtBQUtHLENBQUMsQ0FBQ0MsRUFBRSxHQUFHLE1BQU0sR0FBR3lDLFNBQVU7WUFBQS9FLFFBQUEsRUFJbEdxQyxDQUFDLENBQUN1QixJQUFJLElBQUl2QixDQUFDLENBQUNDLEVBQUUsSUFBSTtVQUFnQixDQUM3QjtRQUFDLEdBVkZELENBQUMsQ0FBQ0MsRUFXUCxDQUNMO01BQUMsQ0FDQSxDQUFDO0lBQUEsQ0FDRSxDQUNWLEVBRUFDLFVBQVUsaUJBQUksSUFBQTlDLFdBQUEsQ0FBQVUsR0FBQTtNQUFHRCxTQUFTLEVBQUMsVUFBVTtNQUFDb0UsSUFBSSxFQUFDLE9BQU87TUFBQXRFLFFBQUEsRUFBRXVDO0lBQVUsQ0FBSSxDQUFDLEVBQ25FdEIsS0FBSyxDQUFDUyxJQUFJLEtBQUssU0FBUyxpQkFBSSxJQUFBakMsV0FBQSxDQUFBVSxHQUFBO01BQUdELFNBQVMsRUFBQyxTQUFTO01BQUFGLFFBQUEsRUFBQztJQUFRLENBQUcsQ0FBQyxFQUUvRGlCLEtBQUssQ0FBQ1EsSUFBSSxJQUFJLENBQUNVLGVBQWUsaUJBQzdCLElBQUExQyxXQUFBLENBQUFRLElBQUE7TUFBU0MsU0FBUyxFQUFDLFFBQVE7TUFBQyxhQUFXZSxLQUFLLENBQUNTLElBQUksS0FBSyxTQUFVO01BQUExQixRQUFBLGdCQUM5RCxJQUFBUCxXQUFBLENBQUFRLElBQUE7UUFBS0MsU0FBUyxFQUFDLFdBQVc7UUFBQyxjQUFXLFVBQVU7UUFBQUYsUUFBQSxnQkFDOUMsSUFBQVAsV0FBQSxDQUFBVSxHQUFBO1VBQVFDLElBQUksRUFBQyxRQUFRO1VBQUNDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNd0QsSUFBSSxDQUFDLENBQUMsQ0FBRTtVQUFBN0QsUUFBQSxFQUMxQ2lCLEtBQUssQ0FBQ0csS0FBSyxFQUFFd0MsSUFBSSxJQUFJO1FBQU0sQ0FDdEIsQ0FBQyxFQUNSM0MsS0FBSyxDQUFDTyxRQUFRLENBQUNzRCxHQUFHLENBQUMsQ0FBQ0UsR0FBRyxFQUFFQyxDQUFDLGtCQUN6QixJQUFBeEYsV0FBQSxDQUFBVSxHQUFBO1VBQWdCQyxJQUFJLEVBQUMsUUFBUTtVQUFDQyxPQUFPLEVBQUVBLENBQUEsS0FBTXdELElBQUksQ0FBQ29CLENBQUMsR0FBRyxDQUFDLENBQUU7VUFBQWpGLFFBQUEsRUFDdERnRjtRQUFHLEdBRE9DLENBRUwsQ0FDVCxDQUFDO01BQUEsQ0FDQyxDQUFDLEVBQ0xoRSxLQUFLLENBQUNRLElBQUksQ0FBQ3lELFNBQVMsaUJBQ25CLElBQUF6RixXQUFBLENBQUFRLElBQUE7UUFBR0MsU0FBUyxFQUFDLGNBQWM7UUFBQUYsUUFBQSxHQUFDLG9CQUFrQixFQUFDaUIsS0FBSyxDQUFDUSxJQUFJLENBQUMwRCxPQUFPLENBQUNwQyxNQUFNLEVBQUMsZ0NBQThCO01BQUEsQ0FBRyxDQUMzRyxlQUNELElBQUF0RCxXQUFBLENBQUFVLEdBQUE7UUFBSUQsU0FBUyxFQUFDLFNBQVM7UUFBQUYsUUFBQSxFQUNwQmlCLEtBQUssQ0FBQ1EsSUFBSSxDQUFDMEQsT0FBTyxDQUFDTCxHQUFHLENBQUU5QixDQUFDLGlCQUN4QixJQUFBdkQsV0FBQSxDQUFBUSxJQUFBO1VBQWlCQyxTQUFTLEVBQUUsSUFBQStELG9CQUFRLEVBQUNqQixDQUFDLEVBQUVwQyxLQUFLLENBQUMsR0FBRyxXQUFXLEdBQUdtRSxTQUFVO1VBQUEvRSxRQUFBLEdBQ3RFZ0QsQ0FBQyxDQUFDVSxLQUFLLEdBQ04sSUFBQU8sb0JBQVEsRUFBQ2pCLENBQUMsRUFBRXBDLEtBQUssQ0FBQyxnQkFDaEIsSUFBQW5CLFdBQUEsQ0FBQVEsSUFBQTtZQUFRRyxJQUFJLEVBQUMsUUFBUTtZQUFDRixTQUFTLEVBQUMsU0FBUztZQUFDRyxPQUFPLEVBQUVBLENBQUEsS0FBTTJELElBQUksQ0FBQ2hCLENBQUMsQ0FBRTtZQUFDekMsUUFBUSxFQUFFVSxLQUFLLENBQUNsQixJQUFLO1lBQUFDLFFBQUEsR0FBQyxZQUM1RSxFQUFDZ0QsQ0FBQyxDQUFDZixJQUFJO1VBQUEsQ0FDWCxDQUFDLGdCQUVULElBQUF4QyxXQUFBLENBQUFRLElBQUE7WUFBUUcsSUFBSSxFQUFDLFFBQVE7WUFBQ0MsT0FBTyxFQUFFQSxDQUFBLEtBQU1tRCxLQUFLLENBQUNSLENBQUMsQ0FBRTtZQUFDekMsUUFBUSxFQUFFVSxLQUFLLENBQUNsQixJQUFLO1lBQUFDLFFBQUEsR0FDakVnRCxDQUFDLENBQUNZLElBQUksRUFBQyxHQUNWO1VBQUEsQ0FBUSxDQUNULGdCQUVELElBQUFuRSxXQUFBLENBQUFVLEdBQUE7WUFBTUQsU0FBUyxFQUFDLFNBQVM7WUFBQUYsUUFBQSxFQUFFZ0QsQ0FBQyxDQUFDWTtVQUFJLENBQU8sQ0FDekMsRUFDQVosQ0FBQyxDQUFDVSxLQUFLLElBQUksQ0FBQyxJQUFBTyxvQkFBUSxFQUFDakIsQ0FBQyxFQUFFcEMsS0FBSyxDQUFDLElBQUlvQyxDQUFDLENBQUNmLElBQUksaUJBQUksSUFBQXhDLFdBQUEsQ0FBQVUsR0FBQTtZQUFNRCxTQUFTLEVBQUMsU0FBUztZQUFBRixRQUFBLEVBQUVnRCxDQUFDLENBQUNmO1VBQUksQ0FBTyxDQUFDO1FBQUEsR0FkL0VlLENBQUMsQ0FBQ1ksSUFlUCxDQUNMO01BQUMsQ0FDQSxDQUFDO0lBQUEsQ0FDRSxDQUNWO0VBQUEsQ0FDSyxDQUFDO0FBRWI7QUFBQ2xFLEVBQUEsQ0FuT3VCZSxHQUFHO0VBQUEsUUFRWEUsaUJBQVksRUFxQlhrQixjQUFTO0FBQUE7QUFBQXVELEdBQUEsR0E3QkYzRSxHQUFHO0FBQUEsSUFBQUQsRUFBQSxFQUFBNEUsR0FBQTtBQUFBQyxZQUFBLENBQUE3RSxFQUFBO0FBQUE2RSxZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}