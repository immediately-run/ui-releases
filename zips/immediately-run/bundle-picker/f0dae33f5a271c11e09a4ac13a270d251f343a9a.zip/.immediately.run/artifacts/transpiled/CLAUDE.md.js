var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "bundle-picker",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "bundle-picker"
      }), "bundle-picker"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The default provider for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "open-bundle"
      }), " task contract (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "OPEN_BUNDLE_SPEC"
      }), ",\nR3-499): a transient, forkable picker app. Invoked with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ kinds }"
      }), "; the user\npastes a repo location (mounted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), " by the host's runtime mount verb, per-repo\nconsent) and navigates; bundles reveal by their ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run.json"
      }), " marker\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "kind"
      }), "; one pick completes with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ location }"
      }), " — a pointer, never authority. The\nhost independently re-probes every result (G-OB-7); this app's job is an honest,\nbounded UI."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Navigation is bounded: ≤ 256 children probed / ≤ 100 rendered per step, depth\n≤ 16 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/navigation.ts"
        }), ", tested — G-OB-2). Never a tree scan."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Labels come from the marker's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kind"
        }), ", never a task name."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The spaces leg (host-drawn strip, spec §4): the host strip grants this\ninstance a scoped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), " navigation root per picked space, announced mid-task\nas an ordinary ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mount-add"
        }), "; the app surfaces those roots (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "spaceRootsOf"
        }), " over\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useMounts()"
        }), ") and a pick under one returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ kind: 'space', spaceId, path }"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "locationForPick"
        }), "). The app never enumerates spaces — it navigates only the\nroots it was handed."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "commands",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "commands"
      }), "Commands"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run dev"
        }), " — vite dev server (sandbox: host it via the platform CLI)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " — typecheck + build."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm test"
        }), " — vitest (bounds + pickability rules)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " — eslint."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-immediatelyrun-stanza",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-immediatelyrun-stanza"
      }), "The immediately.run stanza"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " declares ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides: [{ task: \"open-bundle\", version: \"1.0\" }]"
      }), " —\nthe binding (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task.open-bundle"
      }), " in site-main's registry) resolves this repo by\ndefault and is user-overridable like any binding."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsImxpIiwicCIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNMQVVERS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJidW5kbGUtcGlja2VyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJidW5kbGUtcGlja2VyXCIgLz57XCJidW5kbGUtcGlja2VyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZGVmYXVsdCBwcm92aWRlciBmb3IgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW4tYnVuZGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrIGNvbnRyYWN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJPUEVOX0JVTkRMRV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5SMy00OTkpOiBhIHRyYW5zaWVudCwgZm9ya2FibGUgcGlja2VyIGFwcC4gSW52b2tlZCB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsga2luZHMgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHRoZSB1c2VyXFxucGFzdGVzIGEgcmVwbyBsb2NhdGlvbiAobW91bnRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYnkgdGhlIGhvc3QncyBydW50aW1lIG1vdW50IHZlcmIsIHBlci1yZXBvXFxuY29uc2VudCkgYW5kIG5hdmlnYXRlczsgYnVuZGxlcyByZXZlYWwgYnkgdGhlaXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcmtlclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImtpbmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBvbmUgcGljayBjb21wbGV0ZXMgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IGxvY2F0aW9uIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhIHBvaW50ZXIsIG5ldmVyIGF1dGhvcml0eS4gVGhlXFxuaG9zdCBpbmRlcGVuZGVudGx5IHJlLXByb2JlcyBldmVyeSByZXN1bHQgKEctT0ItNyk7IHRoaXMgYXBwJ3Mgam9iIGlzIGFuIGhvbmVzdCxcXG5ib3VuZGVkIFVJLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIk5hdmlnYXRpb24gaXMgYm91bmRlZDog4omkIDI1NiBjaGlsZHJlbiBwcm9iZWQgLyDiiaQgMTAwIHJlbmRlcmVkIHBlciBzdGVwLCBkZXB0aFxcbuKJpCAxNiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9uYXZpZ2F0aW9uLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGVzdGVkIOKAlCBHLU9CLTIpLiBOZXZlciBhIHRyZWUgc2Nhbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJMYWJlbHMgY29tZSBmcm9tIHRoZSBtYXJrZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJraW5kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbmV2ZXIgYSB0YXNrIG5hbWUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHNwYWNlcyBsZWcgKGhvc3QtZHJhd24gc3RyaXAsIHNwZWMgwqc0KTogdGhlIGhvc3Qgc3RyaXAgZ3JhbnRzIHRoaXNcXG5pbnN0YW5jZSBhIHNjb3BlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbmF2aWdhdGlvbiByb290IHBlciBwaWNrZWQgc3BhY2UsIGFubm91bmNlZCBtaWQtdGFza1xcbmFzIGFuIG9yZGluYXJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50LWFkZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHRoZSBhcHAgc3VyZmFjZXMgdGhvc2Ugcm9vdHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYWNlUm9vdHNPZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ZlclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZU1vdW50cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIGEgcGljayB1bmRlciBvbmUgcmV0dXJucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IGtpbmQ6ICdzcGFjZScsIHNwYWNlSWQsIHBhdGggfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYXRpb25Gb3JQaWNrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFRoZSBhcHAgbmV2ZXIgZW51bWVyYXRlcyBzcGFjZXMg4oCUIGl0IG5hdmlnYXRlcyBvbmx5IHRoZVxcbnJvb3RzIGl0IHdhcyBoYW5kZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNvbW1hbmRzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb21tYW5kc1wiIC8+e1wiQ29tbWFuZHNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB2aXRlIGRldiBzZXJ2ZXIgKHNhbmRib3g6IGhvc3QgaXQgdmlhIHRoZSBwbGF0Zm9ybSBDTEkpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0eXBlY2hlY2sgKyBidWlsZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHZpdGVzdCAoYm91bmRzICsgcGlja2FiaWxpdHkgcnVsZXMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGVzbGludC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWltbWVkaWF0ZWx5cnVuLXN0YW56YVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWltbWVkaWF0ZWx5cnVuLXN0YW56YVwiIC8+e1wiVGhlIGltbWVkaWF0ZWx5LnJ1biBzdGFuemFcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmlkZXM6IFt7IHRhc2s6IFxcXCJvcGVuLWJ1bmRsZVxcXCIsIHZlcnNpb246IFxcXCIxLjBcXFwiIH1dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJRcXG50aGUgYmluZGluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzay5vcGVuLWJ1bmRsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gc2l0ZS1tYWluJ3MgcmVnaXN0cnkpIHJlc29sdmVzIHRoaXMgcmVwbyBieVxcbmRlZmF1bHQgYW5kIGlzIHVzZXItb3ZlcnJpZGFibGUgbGlrZSBhbnkgYmluZGluZy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NMQVVERS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1IsS0FBSyxDQUFDUztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1QsV0FBVztFQUNoQyxJQUFJLENBQUNTLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBYixXQUFBLENBQUFjLElBQUEsRUFBQWQsV0FBQSxDQUFBZSxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNFLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSyxDQUFDO01BQUFRLFFBQUEsR0FBRSwrQkFBK0IsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQywrRkFBK0YsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLG1JQUFtSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNNLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBUyxRQUFBLEdBQUUsdUZBQXVGLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsd0NBQXdDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBUyxRQUFBLEdBQUUsZ0NBQWdDLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxzQkFBc0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO1FBQUFTLFFBQUEsR0FBRSw0RkFBNEYsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLHdFQUF3RSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBWSxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQWtDLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsa0ZBQWtGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO01BQUNXLEVBQUUsRUFBQyxVQUFVO01BQUFELFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBVSxDQUFFLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ00sRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO1FBQUFTLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyw2REFBNkQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO1FBQUFTLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx1QkFBdUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO1FBQUFTLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO1FBQUFTLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxZQUFZO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO01BQUNXLEVBQUUsRUFBQywyQkFBMkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEyQixDQUFFLENBQUMsRUFBQyw0QkFBNEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSyxDQUFDO01BQUFRLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUF5RCxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsb0dBQW9HO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUMxckc7QUFDZSxTQUFTRyxVQUFVQSxDQUFDakIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2tCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdSLEtBQUssQ0FBQ1M7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBckIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS25CLEtBQUs7SUFBQWMsUUFBQSxlQUFFLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNqQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDb0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}