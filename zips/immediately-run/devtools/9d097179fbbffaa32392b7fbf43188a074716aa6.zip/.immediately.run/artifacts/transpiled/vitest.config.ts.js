"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Unit tests for the devtools app. jsdom DOM + Testing Library; the SDK is
// mocked per test so a region renders without a live host.
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _pluginReact.default)()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/**/*.test.{ts,tsx}']
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZpbmVDb25maWciLCJwbHVnaW5zIiwicmVhY3QiLCJ0ZXN0IiwiZW52aXJvbm1lbnQiLCJnbG9iYWxzIiwic2V0dXBGaWxlcyIsImluY2x1ZGUiXSwic291cmNlcyI6WyJ2aXRlc3QuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gJ3ZpdGVzdC9jb25maWcnO1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0JztcblxuLy8gVW5pdCB0ZXN0cyBmb3IgdGhlIGRldnRvb2xzIGFwcC4ganNkb20gRE9NICsgVGVzdGluZyBMaWJyYXJ5OyB0aGUgU0RLIGlzXG4vLyBtb2NrZWQgcGVyIHRlc3Qgc28gYSByZWdpb24gcmVuZGVycyB3aXRob3V0IGEgbGl2ZSBob3N0LlxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcbiAgcGx1Z2luczogW3JlYWN0KCldLFxuICB0ZXN0OiB7XG4gICAgZW52aXJvbm1lbnQ6ICdqc2RvbScsXG4gICAgZ2xvYmFsczogdHJ1ZSxcbiAgICBzZXR1cEZpbGVzOiBbJy4vc3JjL3Rlc3Qvc2V0dXAudHMnXSxcbiAgICBpbmNsdWRlOiBbJ3NyYy8qKi8qLnRlc3Que3RzLHRzeH0nXSxcbiAgfSxcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBeUMsU0FBQUUsdUJBQUFDLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFekM7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsb0JBQVksRUFBQztFQUMxQkMsT0FBTyxFQUFFLENBQUMsSUFBQUMsb0JBQUssRUFBQyxDQUFDLENBQUM7RUFDbEJDLElBQUksRUFBRTtJQUNKQyxXQUFXLEVBQUUsT0FBTztJQUNwQkMsT0FBTyxFQUFFLElBQUk7SUFDYkMsVUFBVSxFQUFFLENBQUMscUJBQXFCLENBQUM7SUFDbkNDLE9BQU8sRUFBRSxDQUFDLHdCQUF3QjtFQUNwQztBQUNGLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==