var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      p: "p",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "code-spec-references",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "code-spec-references"
      }), "Code ↔ spec references"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Where this repo's behaviour is specified. Keep this current: a reader who finds code\nthat contradicts a spec should be able to tell which one is wrong."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Here"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Specified in"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Two regions from one entry point, branching on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useRegion()"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Why not two entry points (one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), ", one grant set)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §2.1; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "PRINCIPALS_SPEC"
            }), " §4"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The unified diagnostic model over three sources (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/lib/diagnostics.ts"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §3"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Severity, and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "note"
            }), " level that means \"not a problem\""]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §3.2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A relative coverage note makes the run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "partial"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "run.ts"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "relative-coverage"
            }), "); an ASSET import (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".css"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".svg"
            }), ", …) is classified ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "asset"
            }), " and does not — a refinement this app adds, since no typecheck could ever check it"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §3.2 (rule); refinement recorded in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_STATUS"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Dedup after path normalization; \"not file-located\" group (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "diagnostics.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "dedupe"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "groupByFile"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §3.3"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Scope fallback changed → open → project, always reported (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scope.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "resolveScope"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §7.2 (\"the default that would lie\")"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openDiagnostic"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openInEditor(path, selection, { reveal: true })"
            }), " (sdk 0.56.0): one gated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "protocol-editor open"
            }), " carrying the caret target and the cross-activity reveal"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §4, §5.2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The runner: tabs per source, run bar, read-only code frame with a tsc-only caret span, the explicit Open in editor control (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/components/RunnerPane.tsx"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/lib/codeFrame.ts"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §8.2, §3.1 rule 2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Staleness: covered paths + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "onChange"
            }), " → debounce → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "refreshDiff()"
            }), "; a stale run stays on screen, dimmed and labelled (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/hooks/useStaleness.ts"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §7.3 (G-TOOL-6)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The two halves are two frames kept in step over ONE IPC edge to each other — hello / run-result / select, payload re-validated (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/lib/sync.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/hooks/useSiblingSync.ts"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §2, §9 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ipc"
            }), " row), §12 decision \"two frames, one edge\""]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Manual tsc/eslint; ONE automatic run when the activity is first opened (the panel); the runner never auto-runs"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §7.1"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Keyboard: J / K, F8 / ⇧F8, Enter in the runner; arrows / Home / End / Enter in the panel — checked against the host's ⌘K / ⌘B / ⌘. / Escape and the editor's CodeMirror default keymap"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §8.1, §13 (keyboard bindings)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Navigation to a diagnostic's line"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §4"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The cross-activity reveal and its gesture gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §5.2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Run scopes, bounds and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "partial"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §7.2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Staleness"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §7.3"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The capabilities this app's bindings hold"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TOOLS_ACTIVITY_SPEC"
            }), " §9"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "App.tsx"
            }), " is the host's boot path, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "main.tsx"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "UI_AS_APPS_SPEC"
            }), " (region app loading)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The cache zip this repo publishes to its own Pages"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ZIP_CACHE_AUTOMATION_SPEC"
            })
          })]
        })]
      })]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CODE_SPEC_REFERENCES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJwIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNPREVfU1BFQ19SRUZFUkVOQ0VTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgcDogXCJwXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvZGUtc3BlYy1yZWZlcmVuY2VzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb2RlLXNwZWMtcmVmZXJlbmNlc1wiIC8+e1wiQ29kZSDihpQgc3BlYyByZWZlcmVuY2VzXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJXaGVyZSB0aGlzIHJlcG8ncyBiZWhhdmlvdXIgaXMgc3BlY2lmaWVkLiBLZWVwIHRoaXMgY3VycmVudDogYSByZWFkZXIgd2hvIGZpbmRzIGNvZGVcXG50aGF0IGNvbnRyYWRpY3RzIGEgc3BlYyBzaG91bGQgYmUgYWJsZSB0byB0ZWxsIHdoaWNoIG9uZSBpcyB3cm9uZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkhlcmVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJTcGVjaWZpZWQgaW5cIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUd28gcmVnaW9ucyBmcm9tIG9uZSBlbnRyeSBwb2ludCwgYnJhbmNoaW5nIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVJlZ2lvbigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlRPT0xTX0FDVElWSVRZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIldoeSBub3QgdHdvIGVudHJ5IHBvaW50cyAob25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9uZSBncmFudCBzZXQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyLjE7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBSSU5DSVBBTFNfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHVuaWZpZWQgZGlhZ25vc3RpYyBtb2RlbCBvdmVyIHRocmVlIHNvdXJjZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWIvZGlhZ25vc3RpY3MudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlRPT0xTX0FDVElWSVRZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlNldmVyaXR5LCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGxldmVsIHRoYXQgbWVhbnMgXFxcIm5vdCBhIHByb2JsZW1cXFwiXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczLjJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIHJlbGF0aXZlIGNvdmVyYWdlIG5vdGUgbWFrZXMgdGhlIHJ1biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJ0aWFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVuLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVsYXRpdmUtY292ZXJhZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgYW4gQVNTRVQgaW1wb3J0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCIuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLnN2Z1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikgaXMgY2xhc3NpZmllZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhc3NldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGRvZXMgbm90IOKAlCBhIHJlZmluZW1lbnQgdGhpcyBhcHAgYWRkcywgc2luY2Ugbm8gdHlwZWNoZWNrIGNvdWxkIGV2ZXIgY2hlY2sgaXRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMuMiAocnVsZSk7IHJlZmluZW1lbnQgcmVjb3JkZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1RBVFVTXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRlZHVwIGFmdGVyIHBhdGggbm9ybWFsaXphdGlvbjsgXFxcIm5vdCBmaWxlLWxvY2F0ZWRcXFwiIGdyb3VwIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaWFnbm9zdGljcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVkdXBlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3VwQnlGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMuM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlNjb3BlIGZhbGxiYWNrIGNoYW5nZWQg4oaSIG9wZW4g4oaSIHByb2plY3QsIGFsd2F5cyByZXBvcnRlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NvcGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlc29sdmVTY29wZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc3LjIgKFxcXCJ0aGUgZGVmYXVsdCB0aGF0IHdvdWxkIGxpZVxcXCIpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkRpYWdub3N0aWNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuSW5FZGl0b3IocGF0aCwgc2VsZWN0aW9uLCB7IHJldmVhbDogdHJ1ZSB9KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNkayAwLjU2LjApOiBvbmUgZ2F0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdG9jb2wtZWRpdG9yIG9wZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJ5aW5nIHRoZSBjYXJldCB0YXJnZXQgYW5kIHRoZSBjcm9zcy1hY3Rpdml0eSByZXZlYWxcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzQsIMKnNS4yXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHJ1bm5lcjogdGFicyBwZXIgc291cmNlLCBydW4gYmFyLCByZWFkLW9ubHkgY29kZSBmcmFtZSB3aXRoIGEgdHNjLW9ubHkgY2FyZXQgc3BhbiwgdGhlIGV4cGxpY2l0IE9wZW4gaW4gZWRpdG9yIGNvbnRyb2wgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL1J1bm5lclBhbmUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9jb2RlRnJhbWUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlRPT0xTX0FDVElWSVRZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOC4yLCDCpzMuMSBydWxlIDJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTdGFsZW5lc3M6IGNvdmVyZWQgcGF0aHMgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvbkNoYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIGRlYm91bmNlIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoRGlmZigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYSBzdGFsZSBydW4gc3RheXMgb24gc2NyZWVuLCBkaW1tZWQgYW5kIGxhYmVsbGVkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvdXNlU3RhbGVuZXNzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzcuMyAoRy1UT09MLTYpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHR3byBoYWx2ZXMgYXJlIHR3byBmcmFtZXMga2VwdCBpbiBzdGVwIG92ZXIgT05FIElQQyBlZGdlIHRvIGVhY2ggb3RoZXIg4oCUIGhlbGxvIC8gcnVuLXJlc3VsdCAvIHNlbGVjdCwgcGF5bG9hZCByZS12YWxpZGF0ZWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWIvc3luYy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy91c2VTaWJsaW5nU3luYy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyLCDCpzkgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImlwY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcm93KSwgwqcxMiBkZWNpc2lvbiBcXFwidHdvIGZyYW1lcywgb25lIGVkZ2VcXFwiXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTWFudWFsIHRzYy9lc2xpbnQ7IE9ORSBhdXRvbWF0aWMgcnVuIHdoZW4gdGhlIGFjdGl2aXR5IGlzIGZpcnN0IG9wZW5lZCAodGhlIHBhbmVsKTsgdGhlIHJ1bm5lciBuZXZlciBhdXRvLXJ1bnNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzcuMVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIktleWJvYXJkOiBKIC8gSywgRjggLyDih6dGOCwgRW50ZXIgaW4gdGhlIHJ1bm5lcjsgYXJyb3dzIC8gSG9tZSAvIEVuZCAvIEVudGVyIGluIHRoZSBwYW5lbCDigJQgY2hlY2tlZCBhZ2FpbnN0IHRoZSBob3N0J3Mg4oyYSyAvIOKMmEIgLyDijJguIC8gRXNjYXBlIGFuZCB0aGUgZWRpdG9yJ3MgQ29kZU1pcnJvciBkZWZhdWx0IGtleW1hcFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlRPT0xTX0FDVElWSVRZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOC4xLCDCpzEzIChrZXlib2FyZCBiaW5kaW5ncylcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJOYXZpZ2F0aW9uIHRvIGEgZGlhZ25vc3RpYydzIGxpbmVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgY3Jvc3MtYWN0aXZpdHkgcmV2ZWFsIGFuZCBpdHMgZ2VzdHVyZSBnYXRlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc1LjJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJSdW4gc2NvcGVzLCBib3VuZHMgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcnRpYWxcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc3LjJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTdGFsZW5lc3NcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJUT09MU19BQ1RJVklUWV9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzcuM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBjYXBhYmlsaXRpZXMgdGhpcyBhcHAncyBiaW5kaW5ncyBob2xkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc5XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIGhvc3QncyBib290IHBhdGgsIG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChyZWdpb24gYXBwIGxvYWRpbmcpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGNhY2hlIHppcCB0aGlzIHJlcG8gcHVibGlzaGVzIHRvIGl0cyBvd24gUGFnZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJaSVBfQ0FDSEVfQVVUT01BVElPTl9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NPREVfU1BFQ19SRUZFUkVOQ0VTLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWCxLQUFLLENBQUNZO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHWixXQUFXO0VBQ2hDLElBQUksQ0FBQ1ksYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFoQixXQUFBLENBQUFpQixJQUFBLEVBQUFqQixXQUFBLENBQUFrQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDRSxFQUFFO01BQUNlLEVBQUUsRUFBQyxzQkFBc0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQixDQUFFLENBQUMsRUFBQyx3QkFBd0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNHLENBQUM7TUFBQWEsUUFBQSxFQUFFO0lBQTBKLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxLQUFLO01BQUFZLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsS0FBSztRQUFBUSxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtZQUFBUyxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDTyxFQUFFO1lBQUFTLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssS0FBSztRQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsaURBQWlELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUs7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsR0FBRSxnQ0FBZ0MsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsS0FBSztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztVQUFBLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUseUNBQXlDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRjtVQUFBLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsOERBQThELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsNERBQTRELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsd0NBQXdDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBaUQsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQywwREFBMEQ7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsV0FBVztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxHQUFFLDhIQUE4SCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQStCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsb0JBQW9CO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsNkJBQTZCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsa0JBQWtCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEdBQUUsa0lBQWtJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUE2QixDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsOENBQThDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWdILENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXdMLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0M7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBbUMsQ0FBaUIsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUs7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZ0QsQ0FBaUIsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLE9BQU87VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsT0FBTztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTJDLENBQWlCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxLQUFLO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyx1QkFBdUI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBb0QsQ0FBaUIsQ0FBQyxtQkFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3B3TztBQUNlLFNBQVNHLFVBQVVBLENBQUNwQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDcUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1gsS0FBSyxDQUFDWTtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUF4QixXQUFBLENBQUFxQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLdEIsS0FBSztJQUFBaUIsUUFBQSxlQUFFLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNwQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDdUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}