var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
var _react = require("@testing-library/react");
var _vitest = require("vitest");
var _useStaleness = require("./useStaleness");
// G-TOOL-6 at the hook: a write to a covered path marks the run stale (after the
// debounce), a write elsewhere does not, `refreshDiff` runs on any write, and a new
// run is fresh by definition.

function fakeWatch() {
  const listeners = new Set();
  const refreshDiff = _vitest.vi.fn(async () => {});
  const ports = {
    watch: cb => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    refreshDiff
  };
  return {
    ports,
    refreshDiff,
    write: paths => listeners.forEach(l => l(paths)),
    listeners
  };
}
(0, _vitest.describe)('useStaleness', () => {
  var _s2 = $RefreshSig$(),
    _s4 = $RefreshSig$(),
    _s6 = $RefreshSig$(),
    _s8 = $RefreshSig$();
  _s2((0, _vitest.it)('marks the run stale when a COVERED path is written, after the debounce', _s2(() => {
    var _s = $RefreshSig$();
    _s2();
    _vitest.vi.useFakeTimers();
    const w = fakeWatch();
    const covered = ['src/a.ts', 'src/b.ts'];
    const {
      result
    } = _s((0, _react.renderHook)(_s(() => {
      _s();
      return (0, _useStaleness.useStaleness)(covered, w.ports, 100);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _vitest.expect)(result.current).toEqual([]);
    (0, _react.act)(() => w.write(['/src/b.ts']));
    (0, _vitest.expect)(result.current).toEqual([]); // not yet — debounced
    (0, _react.act)(() => {
      _vitest.vi.advanceTimersByTime(100);
    });
    (0, _vitest.expect)(result.current).toEqual(['src/b.ts']);
    (0, _vitest.expect)(w.refreshDiff).toHaveBeenCalledTimes(1);
    _vitest.vi.useRealTimers();
  }, "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  })), "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  });
  _s4((0, _vitest.it)('a write OUTSIDE the covered set does not stale the run, but still refreshes the diff', _s4(() => {
    var _s3 = $RefreshSig$();
    _s4();
    _vitest.vi.useFakeTimers();
    const w = fakeWatch();
    const covered = ['src/a.ts'];
    const {
      result
    } = _s3((0, _react.renderHook)(_s3(() => {
      _s3();
      return (0, _useStaleness.useStaleness)(covered, w.ports, 100);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _react.act)(() => w.write(['src/other.ts']));
    (0, _react.act)(() => {
      _vitest.vi.advanceTimersByTime(100);
    });
    (0, _vitest.expect)(result.current).toEqual([]);
    (0, _vitest.expect)(w.refreshDiff).toHaveBeenCalledTimes(1);
    _vitest.vi.useRealTimers();
  }, "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  })), "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  });
  _s6((0, _vitest.it)('coalesces a burst into one flush and dedupes the hits', _s6(() => {
    var _s5 = $RefreshSig$();
    _s6();
    _vitest.vi.useFakeTimers();
    const w = fakeWatch();
    // Hoisted: the hook keys its hits by the covered array's IDENTITY (a new run is a
    // new array), so an inline literal would read as a new run on every render.
    const covered = ['src/a.ts', 'src/b.ts'];
    const {
      result
    } = _s5((0, _react.renderHook)(_s5(() => {
      _s5();
      return (0, _useStaleness.useStaleness)(covered, w.ports, 100);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _react.act)(() => {
      w.write(['src/a.ts']);
      _vitest.vi.advanceTimersByTime(50);
      w.write(['src/a.ts', 'src/b.ts']);
      _vitest.vi.advanceTimersByTime(99);
    });
    (0, _vitest.expect)(result.current).toEqual([]);
    (0, _react.act)(() => {
      _vitest.vi.advanceTimersByTime(1);
    });
    (0, _vitest.expect)(result.current).toEqual(['src/a.ts', 'src/b.ts']);
    (0, _vitest.expect)(w.refreshDiff).toHaveBeenCalledTimes(1);
    _vitest.vi.useRealTimers();
  }, "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  })), "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  });
  _s8((0, _vitest.it)('a new run (new covered identity) is fresh; the old hits do not carry over', _s8(() => {
    var _s7 = $RefreshSig$();
    _s8();
    _vitest.vi.useFakeTimers();
    const w = fakeWatch();
    let covered = ['src/a.ts'];
    const {
      result,
      rerender
    } = _s7((0, _react.renderHook)(_s7(() => {
      _s7();
      return (0, _useStaleness.useStaleness)(covered, w.ports, 100);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _react.act)(() => w.write(['src/a.ts']));
    (0, _react.act)(() => {
      _vitest.vi.advanceTimersByTime(100);
    });
    (0, _vitest.expect)(result.current).toEqual(['src/a.ts']);
    covered = ['src/a.ts'];
    rerender();
    (0, _vitest.expect)(result.current).toEqual([]);
    _vitest.vi.useRealTimers();
  }, "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  })), "n7Jjq7TLETFHTTDoHEgM/QJ19yk=", false, function () {
    return [_vitest.vi.useFakeTimers, _vitest.vi.useRealTimers];
  });
  (0, _vitest.it)('unsubscribes on unmount and never fires without a run or ports', () => {
    var _s9 = $RefreshSig$(),
      _s10 = $RefreshSig$();
    const w = fakeWatch();
    const covered = ['src/a.ts'];
    const {
      unmount
    } = _s9((0, _react.renderHook)(_s9(() => {
      _s9();
      return (0, _useStaleness.useStaleness)(covered, w.ports);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _vitest.expect)(w.listeners.size).toBe(1);
    unmount();
    (0, _vitest.expect)(w.listeners.size).toBe(0);
    const none = _s10((0, _react.renderHook)(_s10(() => {
      _s10();
      return (0, _useStaleness.useStaleness)(null, w.ports);
    }, "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [_useStaleness.useStaleness];
    })), "024+/REA6EMyNxpWV8EIqXUswGI=", false, function () {
      return [useStaleness];
    });
    (0, _vitest.expect)(none.result.current).toEqual([]);
    (0, _vitest.expect)(w.listeners.size).toBe(0);
  });
});

// R3-442 — the leg that survives a remount. On desktop both Tools frames are unmounted
// while the user edits, so no watcher exists at the moment of the write; the run is
// re-validated against the host's changed set instead of observed.
(0, _vitest.describe)('changedSinceRun', () => {
  const covered = ['src/a.ts', 'src/b.ts'];
  (0, _vitest.it)('marks a covered file that BECAME changed since the run', () => {
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(covered, [], ['/src/b.ts'])).toEqual(['src/b.ts']);
  });
  (0, _vitest.it)('ignores a file that was ALREADY changed when the run happened', () => {
    // The run checked it in that state; nothing says it moved since.
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(covered, ['src/b.ts'], ['src/b.ts'])).toEqual([]);
  });
  (0, _vitest.it)('ignores a change outside the run scope', () => {
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(covered, [], ['src/elsewhere.ts'])).toEqual([]);
  });
  (0, _vitest.it)('normalizes both snapshots, so the leading slash never decides the answer', () => {
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(['/src/a.ts'], ['/src/a.ts'], ['src/a.ts'])).toEqual([]);
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(['src/a.ts'], undefined, ['/src/a.ts'])).toEqual(['src/a.ts']);
  });
  (0, _vitest.it)('is empty with no run, no changes, or an older sibling that sent no baseline', () => {
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(null, [], ['src/a.ts'])).toEqual([]);
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(covered, [], [])).toEqual([]);
    (0, _vitest.expect)((0, _useStaleness.changedSinceRun)(covered, undefined, undefined)).toEqual([]);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZpdGVzdCIsIl91c2VTdGFsZW5lc3MiLCJmYWtlV2F0Y2giLCJsaXN0ZW5lcnMiLCJTZXQiLCJyZWZyZXNoRGlmZiIsInZpIiwiZm4iLCJwb3J0cyIsIndhdGNoIiwiY2IiLCJhZGQiLCJkZWxldGUiLCJ3cml0ZSIsInBhdGhzIiwiZm9yRWFjaCIsImwiLCJkZXNjcmliZSIsIl9zMiIsIiRSZWZyZXNoU2lnJCIsIl9zNCIsIl9zNiIsIl9zOCIsIml0IiwiX3MiLCJ1c2VGYWtlVGltZXJzIiwidyIsImNvdmVyZWQiLCJyZXN1bHQiLCJyZW5kZXJIb29rIiwidXNlU3RhbGVuZXNzIiwiZXhwZWN0IiwiY3VycmVudCIsInRvRXF1YWwiLCJhY3QiLCJhZHZhbmNlVGltZXJzQnlUaW1lIiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIiwidXNlUmVhbFRpbWVycyIsIl9zMyIsIl9zNSIsIl9zNyIsInJlcmVuZGVyIiwiX3M5IiwiX3MxMCIsInVubW91bnQiLCJzaXplIiwidG9CZSIsIm5vbmUiLCJjaGFuZ2VkU2luY2VSdW4iLCJ1bmRlZmluZWQiXSwic291cmNlcyI6WyJ1c2VTdGFsZW5lc3MudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRy1UT09MLTYgYXQgdGhlIGhvb2s6IGEgd3JpdGUgdG8gYSBjb3ZlcmVkIHBhdGggbWFya3MgdGhlIHJ1biBzdGFsZSAoYWZ0ZXIgdGhlXG4vLyBkZWJvdW5jZSksIGEgd3JpdGUgZWxzZXdoZXJlIGRvZXMgbm90LCBgcmVmcmVzaERpZmZgIHJ1bnMgb24gYW55IHdyaXRlLCBhbmQgYSBuZXdcbi8vIHJ1biBpcyBmcmVzaCBieSBkZWZpbml0aW9uLlxuaW1wb3J0IHsgYWN0LCByZW5kZXJIb29rIH0gZnJvbSAnQHRlc3RpbmctbGlicmFyeS9yZWFjdCc7XG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgdHlwZSBTdGFsZW5lc3NQb3J0cywgY2hhbmdlZFNpbmNlUnVuLCB1c2VTdGFsZW5lc3MgfSBmcm9tICcuL3VzZVN0YWxlbmVzcyc7XG5cbmZ1bmN0aW9uIGZha2VXYXRjaCgpIHtcbiAgY29uc3QgbGlzdGVuZXJzID0gbmV3IFNldDwocGF0aHM6IHN0cmluZ1tdKSA9PiB2b2lkPigpO1xuICBjb25zdCByZWZyZXNoRGlmZiA9IHZpLmZuKGFzeW5jICgpID0+IHt9KTtcbiAgY29uc3QgcG9ydHM6IFN0YWxlbmVzc1BvcnRzID0ge1xuICAgIHdhdGNoOiAoY2IpID0+IHtcbiAgICAgIGxpc3RlbmVycy5hZGQoY2IpO1xuICAgICAgcmV0dXJuICgpID0+IGxpc3RlbmVycy5kZWxldGUoY2IpO1xuICAgIH0sXG4gICAgcmVmcmVzaERpZmYsXG4gIH07XG4gIHJldHVybiB7IHBvcnRzLCByZWZyZXNoRGlmZiwgd3JpdGU6IChwYXRoczogc3RyaW5nW10pID0+IGxpc3RlbmVycy5mb3JFYWNoKChsKSA9PiBsKHBhdGhzKSksIGxpc3RlbmVycyB9O1xufVxuXG5kZXNjcmliZSgndXNlU3RhbGVuZXNzJywgKCkgPT4ge1xuICBpdCgnbWFya3MgdGhlIHJ1biBzdGFsZSB3aGVuIGEgQ09WRVJFRCBwYXRoIGlzIHdyaXR0ZW4sIGFmdGVyIHRoZSBkZWJvdW5jZScsICgpID0+IHtcbiAgICB2aS51c2VGYWtlVGltZXJzKCk7XG4gICAgY29uc3QgdyA9IGZha2VXYXRjaCgpO1xuICAgIGNvbnN0IGNvdmVyZWQgPSBbJ3NyYy9hLnRzJywgJ3NyYy9iLnRzJ107XG4gICAgY29uc3QgeyByZXN1bHQgfSA9IHJlbmRlckhvb2soKCkgPT4gdXNlU3RhbGVuZXNzKGNvdmVyZWQsIHcucG9ydHMsIDEwMCkpO1xuICAgIGV4cGVjdChyZXN1bHQuY3VycmVudCkudG9FcXVhbChbXSk7XG4gICAgYWN0KCgpID0+IHcud3JpdGUoWycvc3JjL2IudHMnXSkpO1xuICAgIGV4cGVjdChyZXN1bHQuY3VycmVudCkudG9FcXVhbChbXSk7IC8vIG5vdCB5ZXQg4oCUIGRlYm91bmNlZFxuICAgIGFjdCgoKSA9PiB7XG4gICAgICB2aS5hZHZhbmNlVGltZXJzQnlUaW1lKDEwMCk7XG4gICAgfSk7XG4gICAgZXhwZWN0KHJlc3VsdC5jdXJyZW50KS50b0VxdWFsKFsnc3JjL2IudHMnXSk7XG4gICAgZXhwZWN0KHcucmVmcmVzaERpZmYpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICB2aS51c2VSZWFsVGltZXJzKCk7XG4gIH0pO1xuXG4gIGl0KCdhIHdyaXRlIE9VVFNJREUgdGhlIGNvdmVyZWQgc2V0IGRvZXMgbm90IHN0YWxlIHRoZSBydW4sIGJ1dCBzdGlsbCByZWZyZXNoZXMgdGhlIGRpZmYnLCAoKSA9PiB7XG4gICAgdmkudXNlRmFrZVRpbWVycygpO1xuICAgIGNvbnN0IHcgPSBmYWtlV2F0Y2goKTtcbiAgICBjb25zdCBjb3ZlcmVkID0gWydzcmMvYS50cyddO1xuICAgIGNvbnN0IHsgcmVzdWx0IH0gPSByZW5kZXJIb29rKCgpID0+IHVzZVN0YWxlbmVzcyhjb3ZlcmVkLCB3LnBvcnRzLCAxMDApKTtcbiAgICBhY3QoKCkgPT4gdy53cml0ZShbJ3NyYy9vdGhlci50cyddKSk7XG4gICAgYWN0KCgpID0+IHtcbiAgICAgIHZpLmFkdmFuY2VUaW1lcnNCeVRpbWUoMTAwKTtcbiAgICB9KTtcbiAgICBleHBlY3QocmVzdWx0LmN1cnJlbnQpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdCh3LnJlZnJlc2hEaWZmKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgdmkudXNlUmVhbFRpbWVycygpO1xuICB9KTtcblxuICBpdCgnY29hbGVzY2VzIGEgYnVyc3QgaW50byBvbmUgZmx1c2ggYW5kIGRlZHVwZXMgdGhlIGhpdHMnLCAoKSA9PiB7XG4gICAgdmkudXNlRmFrZVRpbWVycygpO1xuICAgIGNvbnN0IHcgPSBmYWtlV2F0Y2goKTtcbiAgICAvLyBIb2lzdGVkOiB0aGUgaG9vayBrZXlzIGl0cyBoaXRzIGJ5IHRoZSBjb3ZlcmVkIGFycmF5J3MgSURFTlRJVFkgKGEgbmV3IHJ1biBpcyBhXG4gICAgLy8gbmV3IGFycmF5KSwgc28gYW4gaW5saW5lIGxpdGVyYWwgd291bGQgcmVhZCBhcyBhIG5ldyBydW4gb24gZXZlcnkgcmVuZGVyLlxuICAgIGNvbnN0IGNvdmVyZWQgPSBbJ3NyYy9hLnRzJywgJ3NyYy9iLnRzJ107XG4gICAgY29uc3QgeyByZXN1bHQgfSA9IHJlbmRlckhvb2soKCkgPT4gdXNlU3RhbGVuZXNzKGNvdmVyZWQsIHcucG9ydHMsIDEwMCkpO1xuICAgIGFjdCgoKSA9PiB7XG4gICAgICB3LndyaXRlKFsnc3JjL2EudHMnXSk7XG4gICAgICB2aS5hZHZhbmNlVGltZXJzQnlUaW1lKDUwKTtcbiAgICAgIHcud3JpdGUoWydzcmMvYS50cycsICdzcmMvYi50cyddKTtcbiAgICAgIHZpLmFkdmFuY2VUaW1lcnNCeVRpbWUoOTkpO1xuICAgIH0pO1xuICAgIGV4cGVjdChyZXN1bHQuY3VycmVudCkudG9FcXVhbChbXSk7XG4gICAgYWN0KCgpID0+IHtcbiAgICAgIHZpLmFkdmFuY2VUaW1lcnNCeVRpbWUoMSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KHJlc3VsdC5jdXJyZW50KS50b0VxdWFsKFsnc3JjL2EudHMnLCAnc3JjL2IudHMnXSk7XG4gICAgZXhwZWN0KHcucmVmcmVzaERpZmYpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICB2aS51c2VSZWFsVGltZXJzKCk7XG4gIH0pO1xuXG4gIGl0KCdhIG5ldyBydW4gKG5ldyBjb3ZlcmVkIGlkZW50aXR5KSBpcyBmcmVzaDsgdGhlIG9sZCBoaXRzIGRvIG5vdCBjYXJyeSBvdmVyJywgKCkgPT4ge1xuICAgIHZpLnVzZUZha2VUaW1lcnMoKTtcbiAgICBjb25zdCB3ID0gZmFrZVdhdGNoKCk7XG4gICAgbGV0IGNvdmVyZWQgPSBbJ3NyYy9hLnRzJ107XG4gICAgY29uc3QgeyByZXN1bHQsIHJlcmVuZGVyIH0gPSByZW5kZXJIb29rKCgpID0+IHVzZVN0YWxlbmVzcyhjb3ZlcmVkLCB3LnBvcnRzLCAxMDApKTtcbiAgICBhY3QoKCkgPT4gdy53cml0ZShbJ3NyYy9hLnRzJ10pKTtcbiAgICBhY3QoKCkgPT4ge1xuICAgICAgdmkuYWR2YW5jZVRpbWVyc0J5VGltZSgxMDApO1xuICAgIH0pO1xuICAgIGV4cGVjdChyZXN1bHQuY3VycmVudCkudG9FcXVhbChbJ3NyYy9hLnRzJ10pO1xuICAgIGNvdmVyZWQgPSBbJ3NyYy9hLnRzJ107XG4gICAgcmVyZW5kZXIoKTtcbiAgICBleHBlY3QocmVzdWx0LmN1cnJlbnQpLnRvRXF1YWwoW10pO1xuICAgIHZpLnVzZVJlYWxUaW1lcnMoKTtcbiAgfSk7XG5cbiAgaXQoJ3Vuc3Vic2NyaWJlcyBvbiB1bm1vdW50IGFuZCBuZXZlciBmaXJlcyB3aXRob3V0IGEgcnVuIG9yIHBvcnRzJywgKCkgPT4ge1xuICAgIGNvbnN0IHcgPSBmYWtlV2F0Y2goKTtcbiAgICBjb25zdCBjb3ZlcmVkID0gWydzcmMvYS50cyddO1xuICAgIGNvbnN0IHsgdW5tb3VudCB9ID0gcmVuZGVySG9vaygoKSA9PiB1c2VTdGFsZW5lc3MoY292ZXJlZCwgdy5wb3J0cykpO1xuICAgIGV4cGVjdCh3Lmxpc3RlbmVycy5zaXplKS50b0JlKDEpO1xuICAgIHVubW91bnQoKTtcbiAgICBleHBlY3Qody5saXN0ZW5lcnMuc2l6ZSkudG9CZSgwKTtcbiAgICBjb25zdCBub25lID0gcmVuZGVySG9vaygoKSA9PiB1c2VTdGFsZW5lc3MobnVsbCwgdy5wb3J0cykpO1xuICAgIGV4cGVjdChub25lLnJlc3VsdC5jdXJyZW50KS50b0VxdWFsKFtdKTtcbiAgICBleHBlY3Qody5saXN0ZW5lcnMuc2l6ZSkudG9CZSgwKTtcbiAgfSk7XG59KTtcblxuLy8gUjMtNDQyIOKAlCB0aGUgbGVnIHRoYXQgc3Vydml2ZXMgYSByZW1vdW50LiBPbiBkZXNrdG9wIGJvdGggVG9vbHMgZnJhbWVzIGFyZSB1bm1vdW50ZWRcbi8vIHdoaWxlIHRoZSB1c2VyIGVkaXRzLCBzbyBubyB3YXRjaGVyIGV4aXN0cyBhdCB0aGUgbW9tZW50IG9mIHRoZSB3cml0ZTsgdGhlIHJ1biBpc1xuLy8gcmUtdmFsaWRhdGVkIGFnYWluc3QgdGhlIGhvc3QncyBjaGFuZ2VkIHNldCBpbnN0ZWFkIG9mIG9ic2VydmVkLlxuZGVzY3JpYmUoJ2NoYW5nZWRTaW5jZVJ1bicsICgpID0+IHtcbiAgY29uc3QgY292ZXJlZCA9IFsnc3JjL2EudHMnLCAnc3JjL2IudHMnXTtcblxuICBpdCgnbWFya3MgYSBjb3ZlcmVkIGZpbGUgdGhhdCBCRUNBTUUgY2hhbmdlZCBzaW5jZSB0aGUgcnVuJywgKCkgPT4ge1xuICAgIGV4cGVjdChjaGFuZ2VkU2luY2VSdW4oY292ZXJlZCwgW10sIFsnL3NyYy9iLnRzJ10pKS50b0VxdWFsKFsnc3JjL2IudHMnXSk7XG4gIH0pO1xuXG4gIGl0KCdpZ25vcmVzIGEgZmlsZSB0aGF0IHdhcyBBTFJFQURZIGNoYW5nZWQgd2hlbiB0aGUgcnVuIGhhcHBlbmVkJywgKCkgPT4ge1xuICAgIC8vIFRoZSBydW4gY2hlY2tlZCBpdCBpbiB0aGF0IHN0YXRlOyBub3RoaW5nIHNheXMgaXQgbW92ZWQgc2luY2UuXG4gICAgZXhwZWN0KGNoYW5nZWRTaW5jZVJ1bihjb3ZlcmVkLCBbJ3NyYy9iLnRzJ10sIFsnc3JjL2IudHMnXSkpLnRvRXF1YWwoW10pO1xuICB9KTtcblxuICBpdCgnaWdub3JlcyBhIGNoYW5nZSBvdXRzaWRlIHRoZSBydW4gc2NvcGUnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGNoYW5nZWRTaW5jZVJ1bihjb3ZlcmVkLCBbXSwgWydzcmMvZWxzZXdoZXJlLnRzJ10pKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgaXQoJ25vcm1hbGl6ZXMgYm90aCBzbmFwc2hvdHMsIHNvIHRoZSBsZWFkaW5nIHNsYXNoIG5ldmVyIGRlY2lkZXMgdGhlIGFuc3dlcicsICgpID0+IHtcbiAgICBleHBlY3QoY2hhbmdlZFNpbmNlUnVuKFsnL3NyYy9hLnRzJ10sIFsnL3NyYy9hLnRzJ10sIFsnc3JjL2EudHMnXSkpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChjaGFuZ2VkU2luY2VSdW4oWydzcmMvYS50cyddLCB1bmRlZmluZWQsIFsnL3NyYy9hLnRzJ10pKS50b0VxdWFsKFsnc3JjL2EudHMnXSk7XG4gIH0pO1xuXG4gIGl0KCdpcyBlbXB0eSB3aXRoIG5vIHJ1biwgbm8gY2hhbmdlcywgb3IgYW4gb2xkZXIgc2libGluZyB0aGF0IHNlbnQgbm8gYmFzZWxpbmUnLCAoKSA9PiB7XG4gICAgZXhwZWN0KGNoYW5nZWRTaW5jZVJ1bihudWxsLCBbXSwgWydzcmMvYS50cyddKSkudG9FcXVhbChbXSk7XG4gICAgZXhwZWN0KGNoYW5nZWRTaW5jZVJ1bihjb3ZlcmVkLCBbXSwgW10pKS50b0VxdWFsKFtdKTtcbiAgICBleHBlY3QoY2hhbmdlZFNpbmNlUnVuKGNvdmVyZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkKSkudG9FcXVhbChbXSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxhQUFBLEdBQUFGLE9BQUE7QUFMQTtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csU0FBU0EsQ0FBQSxFQUFHO0VBQ25CLE1BQU1DLFNBQVMsR0FBRyxJQUFJQyxHQUFHLENBQTRCLENBQUM7RUFDdEQsTUFBTUMsV0FBVyxHQUFHQyxVQUFFLENBQUNDLEVBQUUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ3pDLE1BQU1DLEtBQXFCLEdBQUc7SUFDNUJDLEtBQUssRUFBR0MsRUFBRSxJQUFLO01BQ2JQLFNBQVMsQ0FBQ1EsR0FBRyxDQUFDRCxFQUFFLENBQUM7TUFDakIsT0FBTyxNQUFNUCxTQUFTLENBQUNTLE1BQU0sQ0FBQ0YsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFDREw7RUFDRixDQUFDO0VBQ0QsT0FBTztJQUFFRyxLQUFLO0lBQUVILFdBQVc7SUFBRVEsS0FBSyxFQUFHQyxLQUFlLElBQUtYLFNBQVMsQ0FBQ1ksT0FBTyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0YsS0FBSyxDQUFDLENBQUM7SUFBRVg7RUFBVSxDQUFDO0FBQzFHO0FBRUEsSUFBQWMsZ0JBQVEsRUFBQyxjQUFjLEVBQUUsTUFBTTtFQUFBLElBQUFDLEdBQUEsR0FBQUMsWUFBQTtJQUFBQyxHQUFBLEdBQUFELFlBQUE7SUFBQUUsR0FBQSxHQUFBRixZQUFBO0lBQUFHLEdBQUEsR0FBQUgsWUFBQTtFQUM3QkQsR0FBQSxLQUFBSyxVQUFFLEVBQUMsd0VBQXdFLEVBQUFMLEdBQUEsQ0FBRSxNQUFNO0lBQUEsSUFBQU0sRUFBQSxHQUFBTCxZQUFBO0lBQUFELEdBQUE7SUFDakZaLFVBQUUsQ0FBQ21CLGFBQWEsQ0FBQyxDQUFDO0lBQ2xCLE1BQU1DLENBQUMsR0FBR3hCLFNBQVMsQ0FBQyxDQUFDO0lBQ3JCLE1BQU15QixPQUFPLEdBQUcsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0lBQ3hDLE1BQU07TUFBRUM7SUFBTyxDQUFDLEdBQUFKLEVBQUEsQ0FBRyxJQUFBSyxpQkFBVSxFQUFBTCxFQUFBLENBQUM7TUFBQUEsRUFBQTtNQUFBLE9BQU0sSUFBQU0sMEJBQVksRUFBQ0gsT0FBTyxFQUFFRCxDQUFDLENBQUNsQixLQUFLLEVBQUUsR0FBRyxDQUFDO0lBQUE7TUFBQSxRQUFuQ3NCLDBCQUFZO0lBQUEsRUFBdUIsQ0FBQztNQUFBLFFBQXBDQSxZQUFZO0lBQUEsRUFBd0I7SUFDeEUsSUFBQUMsY0FBTSxFQUFDSCxNQUFNLENBQUNJLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ2xDLElBQUFDLFVBQUcsRUFBQyxNQUFNUixDQUFDLENBQUNiLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDakMsSUFBQWtCLGNBQU0sRUFBQ0gsTUFBTSxDQUFDSSxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEMsSUFBQUMsVUFBRyxFQUFDLE1BQU07TUFDUjVCLFVBQUUsQ0FBQzZCLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztJQUM3QixDQUFDLENBQUM7SUFDRixJQUFBSixjQUFNLEVBQUNILE1BQU0sQ0FBQ0ksT0FBTyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzVDLElBQUFGLGNBQU0sRUFBQ0wsQ0FBQyxDQUFDckIsV0FBVyxDQUFDLENBQUMrQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDOUM5QixVQUFFLENBQUMrQixhQUFhLENBQUMsQ0FBQztFQUNwQixDQUFDO0lBQUEsUUFiQy9CLFVBQUUsQ0FBQ21CLGFBQWEsRUFZaEJuQixVQUFFLENBQUMrQixhQUFhO0VBQUEsRUFDakIsQ0FBQztJQUFBLFFBYkEvQixVQUFFLENBQUNtQixhQUFhLEVBWWhCbkIsVUFBRSxDQUFDK0IsYUFBYTtFQUFBO0VBR2xCakIsR0FBQSxLQUFBRyxVQUFFLEVBQUMsc0ZBQXNGLEVBQUFILEdBQUEsQ0FBRSxNQUFNO0lBQUEsSUFBQWtCLEdBQUEsR0FBQW5CLFlBQUE7SUFBQUMsR0FBQTtJQUMvRmQsVUFBRSxDQUFDbUIsYUFBYSxDQUFDLENBQUM7SUFDbEIsTUFBTUMsQ0FBQyxHQUFHeEIsU0FBUyxDQUFDLENBQUM7SUFDckIsTUFBTXlCLE9BQU8sR0FBRyxDQUFDLFVBQVUsQ0FBQztJQUM1QixNQUFNO01BQUVDO0lBQU8sQ0FBQyxHQUFBVSxHQUFBLENBQUcsSUFBQVQsaUJBQVUsRUFBQVMsR0FBQSxDQUFDO01BQUFBLEdBQUE7TUFBQSxPQUFNLElBQUFSLDBCQUFZLEVBQUNILE9BQU8sRUFBRUQsQ0FBQyxDQUFDbEIsS0FBSyxFQUFFLEdBQUcsQ0FBQztJQUFBO01BQUEsUUFBbkNzQiwwQkFBWTtJQUFBLEVBQXVCLENBQUM7TUFBQSxRQUFwQ0EsWUFBWTtJQUFBLEVBQXdCO0lBQ3hFLElBQUFJLFVBQUcsRUFBQyxNQUFNUixDQUFDLENBQUNiLEtBQUssQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7SUFDcEMsSUFBQXFCLFVBQUcsRUFBQyxNQUFNO01BQ1I1QixVQUFFLENBQUM2QixtQkFBbUIsQ0FBQyxHQUFHLENBQUM7SUFDN0IsQ0FBQyxDQUFDO0lBQ0YsSUFBQUosY0FBTSxFQUFDSCxNQUFNLENBQUNJLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ2xDLElBQUFGLGNBQU0sRUFBQ0wsQ0FBQyxDQUFDckIsV0FBVyxDQUFDLENBQUMrQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDOUM5QixVQUFFLENBQUMrQixhQUFhLENBQUMsQ0FBQztFQUNwQixDQUFDO0lBQUEsUUFYQy9CLFVBQUUsQ0FBQ21CLGFBQWEsRUFVaEJuQixVQUFFLENBQUMrQixhQUFhO0VBQUEsRUFDakIsQ0FBQztJQUFBLFFBWEEvQixVQUFFLENBQUNtQixhQUFhLEVBVWhCbkIsVUFBRSxDQUFDK0IsYUFBYTtFQUFBO0VBR2xCaEIsR0FBQSxLQUFBRSxVQUFFLEVBQUMsdURBQXVELEVBQUFGLEdBQUEsQ0FBRSxNQUFNO0lBQUEsSUFBQWtCLEdBQUEsR0FBQXBCLFlBQUE7SUFBQUUsR0FBQTtJQUNoRWYsVUFBRSxDQUFDbUIsYUFBYSxDQUFDLENBQUM7SUFDbEIsTUFBTUMsQ0FBQyxHQUFHeEIsU0FBUyxDQUFDLENBQUM7SUFDckI7SUFDQTtJQUNBLE1BQU15QixPQUFPLEdBQUcsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0lBQ3hDLE1BQU07TUFBRUM7SUFBTyxDQUFDLEdBQUFXLEdBQUEsQ0FBRyxJQUFBVixpQkFBVSxFQUFBVSxHQUFBLENBQUM7TUFBQUEsR0FBQTtNQUFBLE9BQU0sSUFBQVQsMEJBQVksRUFBQ0gsT0FBTyxFQUFFRCxDQUFDLENBQUNsQixLQUFLLEVBQUUsR0FBRyxDQUFDO0lBQUE7TUFBQSxRQUFuQ3NCLDBCQUFZO0lBQUEsRUFBdUIsQ0FBQztNQUFBLFFBQXBDQSxZQUFZO0lBQUEsRUFBd0I7SUFDeEUsSUFBQUksVUFBRyxFQUFDLE1BQU07TUFDUlIsQ0FBQyxDQUFDYixLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztNQUNyQlAsVUFBRSxDQUFDNkIsbUJBQW1CLENBQUMsRUFBRSxDQUFDO01BQzFCVCxDQUFDLENBQUNiLEtBQUssQ0FBQyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztNQUNqQ1AsVUFBRSxDQUFDNkIsbUJBQW1CLENBQUMsRUFBRSxDQUFDO0lBQzVCLENBQUMsQ0FBQztJQUNGLElBQUFKLGNBQU0sRUFBQ0gsTUFBTSxDQUFDSSxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUNsQyxJQUFBQyxVQUFHLEVBQUMsTUFBTTtNQUNSNUIsVUFBRSxDQUFDNkIsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0lBQzNCLENBQUMsQ0FBQztJQUNGLElBQUFKLGNBQU0sRUFBQ0gsTUFBTSxDQUFDSSxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ3hELElBQUFGLGNBQU0sRUFBQ0wsQ0FBQyxDQUFDckIsV0FBVyxDQUFDLENBQUMrQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDOUM5QixVQUFFLENBQUMrQixhQUFhLENBQUMsQ0FBQztFQUNwQixDQUFDO0lBQUEsUUFuQkMvQixVQUFFLENBQUNtQixhQUFhLEVBa0JoQm5CLFVBQUUsQ0FBQytCLGFBQWE7RUFBQSxFQUNqQixDQUFDO0lBQUEsUUFuQkEvQixVQUFFLENBQUNtQixhQUFhLEVBa0JoQm5CLFVBQUUsQ0FBQytCLGFBQWE7RUFBQTtFQUdsQmYsR0FBQSxLQUFBQyxVQUFFLEVBQUMsMkVBQTJFLEVBQUFELEdBQUEsQ0FBRSxNQUFNO0lBQUEsSUFBQWtCLEdBQUEsR0FBQXJCLFlBQUE7SUFBQUcsR0FBQTtJQUNwRmhCLFVBQUUsQ0FBQ21CLGFBQWEsQ0FBQyxDQUFDO0lBQ2xCLE1BQU1DLENBQUMsR0FBR3hCLFNBQVMsQ0FBQyxDQUFDO0lBQ3JCLElBQUl5QixPQUFPLEdBQUcsQ0FBQyxVQUFVLENBQUM7SUFDMUIsTUFBTTtNQUFFQyxNQUFNO01BQUVhO0lBQVMsQ0FBQyxHQUFBRCxHQUFBLENBQUcsSUFBQVgsaUJBQVUsRUFBQVcsR0FBQSxDQUFDO01BQUFBLEdBQUE7TUFBQSxPQUFNLElBQUFWLDBCQUFZLEVBQUNILE9BQU8sRUFBRUQsQ0FBQyxDQUFDbEIsS0FBSyxFQUFFLEdBQUcsQ0FBQztJQUFBO01BQUEsUUFBbkNzQiwwQkFBWTtJQUFBLEVBQXVCLENBQUM7TUFBQSxRQUFwQ0EsWUFBWTtJQUFBLEVBQXdCO0lBQ2xGLElBQUFJLFVBQUcsRUFBQyxNQUFNUixDQUFDLENBQUNiLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDaEMsSUFBQXFCLFVBQUcsRUFBQyxNQUFNO01BQ1I1QixVQUFFLENBQUM2QixtQkFBbUIsQ0FBQyxHQUFHLENBQUM7SUFDN0IsQ0FBQyxDQUFDO0lBQ0YsSUFBQUosY0FBTSxFQUFDSCxNQUFNLENBQUNJLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM1Q04sT0FBTyxHQUFHLENBQUMsVUFBVSxDQUFDO0lBQ3RCYyxRQUFRLENBQUMsQ0FBQztJQUNWLElBQUFWLGNBQU0sRUFBQ0gsTUFBTSxDQUFDSSxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUNsQzNCLFVBQUUsQ0FBQytCLGFBQWEsQ0FBQyxDQUFDO0VBQ3BCLENBQUM7SUFBQSxRQWJDL0IsVUFBRSxDQUFDbUIsYUFBYSxFQVloQm5CLFVBQUUsQ0FBQytCLGFBQWE7RUFBQSxFQUNqQixDQUFDO0lBQUEsUUFiQS9CLFVBQUUsQ0FBQ21CLGFBQWEsRUFZaEJuQixVQUFFLENBQUMrQixhQUFhO0VBQUE7RUFHbEIsSUFBQWQsVUFBRSxFQUFDLGdFQUFnRSxFQUFFLE1BQU07SUFBQSxJQUFBbUIsR0FBQSxHQUFBdkIsWUFBQTtNQUFBd0IsSUFBQSxHQUFBeEIsWUFBQTtJQUN6RSxNQUFNTyxDQUFDLEdBQUd4QixTQUFTLENBQUMsQ0FBQztJQUNyQixNQUFNeUIsT0FBTyxHQUFHLENBQUMsVUFBVSxDQUFDO0lBQzVCLE1BQU07TUFBRWlCO0lBQVEsQ0FBQyxHQUFBRixHQUFBLENBQUcsSUFBQWIsaUJBQVUsRUFBQWEsR0FBQSxDQUFDO01BQUFBLEdBQUE7TUFBQSxPQUFNLElBQUFaLDBCQUFZLEVBQUNILE9BQU8sRUFBRUQsQ0FBQyxDQUFDbEIsS0FBSyxDQUFDO0lBQUE7TUFBQSxRQUE5QnNCLDBCQUFZO0lBQUEsRUFBa0IsQ0FBQztNQUFBLFFBQS9CQSxZQUFZO0lBQUEsRUFBbUI7SUFDcEUsSUFBQUMsY0FBTSxFQUFDTCxDQUFDLENBQUN2QixTQUFTLENBQUMwQyxJQUFJLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNoQ0YsT0FBTyxDQUFDLENBQUM7SUFDVCxJQUFBYixjQUFNLEVBQUNMLENBQUMsQ0FBQ3ZCLFNBQVMsQ0FBQzBDLElBQUksQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ2hDLE1BQU1DLElBQUksR0FBQUosSUFBQSxDQUFHLElBQUFkLGlCQUFVLEVBQUFjLElBQUEsQ0FBQztNQUFBQSxJQUFBO01BQUEsT0FBTSxJQUFBYiwwQkFBWSxFQUFDLElBQUksRUFBRUosQ0FBQyxDQUFDbEIsS0FBSyxDQUFDO0lBQUE7TUFBQSxRQUEzQnNCLDBCQUFZO0lBQUEsRUFBZSxDQUFDO01BQUEsUUFBNUJBLFlBQVk7SUFBQSxFQUFnQjtJQUMxRCxJQUFBQyxjQUFNLEVBQUNnQixJQUFJLENBQUNuQixNQUFNLENBQUNJLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ3ZDLElBQUFGLGNBQU0sRUFBQ0wsQ0FBQyxDQUFDdkIsU0FBUyxDQUFDMEMsSUFBSSxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDbEMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBLElBQUE3QixnQkFBUSxFQUFDLGlCQUFpQixFQUFFLE1BQU07RUFDaEMsTUFBTVUsT0FBTyxHQUFHLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQztFQUV4QyxJQUFBSixVQUFFLEVBQUMsd0RBQXdELEVBQUUsTUFBTTtJQUNqRSxJQUFBUSxjQUFNLEVBQUMsSUFBQWlCLDZCQUFlLEVBQUNyQixPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDTSxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUMzRSxDQUFDLENBQUM7RUFFRixJQUFBVixVQUFFLEVBQUMsK0RBQStELEVBQUUsTUFBTTtJQUN4RTtJQUNBLElBQUFRLGNBQU0sRUFBQyxJQUFBaUIsNkJBQWUsRUFBQ3JCLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDTSxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzFFLENBQUMsQ0FBQztFQUVGLElBQUFWLFVBQUUsRUFBQyx3Q0FBd0MsRUFBRSxNQUFNO0lBQ2pELElBQUFRLGNBQU0sRUFBQyxJQUFBaUIsNkJBQWUsRUFBQ3JCLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ00sT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUN4RSxDQUFDLENBQUM7RUFFRixJQUFBVixVQUFFLEVBQUMsMEVBQTBFLEVBQUUsTUFBTTtJQUNuRixJQUFBUSxjQUFNLEVBQUMsSUFBQWlCLDZCQUFlLEVBQUMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDZixPQUFPLENBQUMsRUFBRSxDQUFDO0lBQy9FLElBQUFGLGNBQU0sRUFBQyxJQUFBaUIsNkJBQWUsRUFBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNoQixPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUN2RixDQUFDLENBQUM7RUFFRixJQUFBVixVQUFFLEVBQUMsNkVBQTZFLEVBQUUsTUFBTTtJQUN0RixJQUFBUSxjQUFNLEVBQUMsSUFBQWlCLDZCQUFlLEVBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQ2YsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUMzRCxJQUFBRixjQUFNLEVBQUMsSUFBQWlCLDZCQUFlLEVBQUNyQixPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUNNLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDcEQsSUFBQUYsY0FBTSxFQUFDLElBQUFpQiw2QkFBZSxFQUFDckIsT0FBTyxFQUFFc0IsU0FBUyxFQUFFQSxTQUFTLENBQUMsQ0FBQyxDQUFDaEIsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUNwRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}