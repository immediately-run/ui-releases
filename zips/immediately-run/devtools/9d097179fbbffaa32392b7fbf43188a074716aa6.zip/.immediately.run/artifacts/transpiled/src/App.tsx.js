var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _Placeholder = _interopRequireDefault(require("./components/Placeholder"));
var _ProblemsPanel = _interopRequireDefault(require("./components/ProblemsPanel"));
var _RunnerPane = _interopRequireDefault(require("./components/RunnerPane"));
var _host = require("./lib/host");
var _useToolsSession = require("./hooks/useToolsSession");
var _useWorkingTree = require("./hooks/useWorkingTree");
require("./index.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$(),
  _s4 = $RefreshSig$(),
  _s5 = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file, booted
// at the literal path `files/src/App.tsx`. `main.tsx` is never loaded by the host.
//
// The Tools activity occupies TWO regions from this one repo, and the platform has
// no way to bind a region to a specific entry point (`RegionBinding` carries no
// `entryPoint`, and program-identity `appKey` is written but unwired). So one
// program serves both halves and branches on `useRegion()` — the shipped idiom,
// with two precedents: `agent-demo` (panel.agent + stage.conversation) and
// `file-explorer` (panel.files + page.commander), which PRINCIPALS_SPEC §4 calls
// one-repo-many-bindings.
//
// The two halves are two FRAMES: the host mounts each region in its own sandboxed
// iframe, so they share no memory. They keep one session in step over their single
// IPC edge to each other (`hooks/useSiblingSync.ts`, protocol in `lib/sync.ts`).
/** The host's theme reaches this frame over the SDK channel, not as CSS — mirror it
 *  onto the root element so the stylesheet's `html[data-theme]` block applies. */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function useMirroredTheme() {
  _s();
  const theme = (0, _sdk.useHostTheme)();
  (0, _react.useEffect)(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
}

/** Resolve once the host has pushed vcs state (so the default scope sees the changed
 *  files), or after a short deadline when there is no contribute session to push. */
_s(useMirroredTheme, "s/fCWdnl0aS9PKe5owjfeMHSkpQ=", false, function () {
  return [_sdk.useHostTheme];
});
const awaitHost = () => new Promise(resolve => {
  let done = false;
  // The channel REPLAYS its current value to a late subscriber synchronously, so the
  // listener can run before `subscribe` has even returned — `off` must exist first.
  // (Caught live by this very panel: its first build row was the TDZ error here.)
  let off = () => {};
  const finish = () => {
    if (done) return;
    done = true;
    off();
    resolve();
  };
  off = (0, _sdk.onVcsStateChange)(() => finish());
  if (done) off();
  setTimeout(finish, 1500);
});
const onOpen = d => (0, _host.openDiagnostic)(d, {
  reveal: true
});

/** Everything both halves share: the working tree, the staleness legs, the sibling
 *  edge, and the session over them. The panel does the one automatic first-open run
 *  (§7.1); the runner asks the panel for the current state instead. */
function useHalf(autoRun) {
  _s2();
  useMirroredTheme();
  const tree = (0, _useWorkingTree.useWorkingTree)();
  const staleness = (0, _react.useMemo)(() => tree ? (0, _host.stalenessPorts)(tree.mount) : null, [tree]);
  // The live changed set, for the re-validation leg (R3-442). A deleted path is not a
  // write to a covered file in any useful sense — the run's own scope excludes them.
  const vcs = (0, _sdk.useVcsState)();
  const changedNow = (0, _react.useMemo)(() => vcs.changes.filter(c => c.status !== 'deleted').map(c => c.path), [vcs.changes]);
  const sibling = (0, _react.useMemo)(() => (0, _host.siblingPorts)(), []);
  const session = (0, _useToolsSession.useToolsSession)({
    ports: tree === undefined ? undefined : tree?.ports ?? null,
    staleness,
    sibling,
    autoRun,
    awaitHost,
    changedNow
  });
  const readFile = (0, _react.useMemo)(() => tree ? path => tree.ports.readFile(path) : null, [tree]);
  return {
    session,
    readFile
  };
}
_s2(useHalf, "xyAAFOqEhYGNv8OkxmMC16FPZJY=", false, function () {
  return [useMirroredTheme, _useWorkingTree.useWorkingTree, _sdk.useVcsState, _useToolsSession.useToolsSession];
});
function ProblemsHalf() {
  _s3();
  const {
    session
  } = useHalf(true);
  const {
    buildErrors
  } = (0, _sdk.useDiagnostics)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ProblemsPanel.default, {
    session: session,
    buildErrors: buildErrors,
    onOpen: onOpen
  });
}
_s3(ProblemsHalf, "sOjPbfJw+D2HbHQDe+sXNNVq2LU=", false, function () {
  return [useHalf, _sdk.useDiagnostics];
});
_c = ProblemsHalf;
function RunnerHalf() {
  _s4();
  const {
    session,
    readFile
  } = useHalf(false);
  const {
    buildErrors
  } = (0, _sdk.useDiagnostics)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_RunnerPane.default, {
    session: session,
    buildErrors: buildErrors,
    onOpen: onOpen,
    readFile: readFile
  });
}
_s4(RunnerHalf, "NoP3yB2N293tuH/KwXRCE2MSUHE=", false, function () {
  return [useHalf, _sdk.useDiagnostics];
});
_c2 = RunnerHalf;
function App() {
  _s5();
  const region = (0, _sdk.useRegion)();
  if (region === 'panel.tools') return /*#__PURE__*/(0, _jsxRuntime.jsx)(ProblemsHalf, {});
  if (region === 'mainpane.tools') return /*#__PURE__*/(0, _jsxRuntime.jsx)(RunnerHalf, {});

  // Standalone (no region): loaded from a URL or a dev server rather than bound
  // into the workbench. There is no working-tree mount here and no editor session,
  // so there is nothing to report on — say that rather than render an empty shell.
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Placeholder.default, {
    region: null,
    title: "Tools",
    detail: "This app is a workbench surface. Open it from the Tools activity inside the immediately.run editor, where it can see the working tree it reports on.",
    item: "R3-387"
  });
}
_s5(App, "Ppkt00pAC6N/60HFSwQrnIuv9kM=", false, function () {
  return [_sdk.useRegion];
});
_c3 = App;
var _c, _c2, _c3;
$RefreshReg$(_c, "ProblemsHalf");
$RefreshReg$(_c2, "RunnerHalf");
$RefreshReg$(_c3, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9QbGFjZWhvbGRlciIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfUHJvYmxlbXNQYW5lbCIsIl9SdW5uZXJQYW5lIiwiX2hvc3QiLCJfdXNlVG9vbHNTZXNzaW9uIiwiX3VzZVdvcmtpbmdUcmVlIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsIl9zMyIsIl9zNCIsIl9zNSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInVzZU1pcnJvcmVkVGhlbWUiLCJ0aGVtZSIsInVzZUhvc3RUaGVtZSIsInVzZUVmZmVjdCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiZGF0YXNldCIsImF3YWl0SG9zdCIsIlByb21pc2UiLCJyZXNvbHZlIiwiZG9uZSIsIm9mZiIsImZpbmlzaCIsIm9uVmNzU3RhdGVDaGFuZ2UiLCJzZXRUaW1lb3V0Iiwib25PcGVuIiwiZCIsIm9wZW5EaWFnbm9zdGljIiwicmV2ZWFsIiwidXNlSGFsZiIsImF1dG9SdW4iLCJ0cmVlIiwidXNlV29ya2luZ1RyZWUiLCJzdGFsZW5lc3MiLCJ1c2VNZW1vIiwic3RhbGVuZXNzUG9ydHMiLCJtb3VudCIsInZjcyIsInVzZVZjc1N0YXRlIiwiY2hhbmdlZE5vdyIsImNoYW5nZXMiLCJmaWx0ZXIiLCJjIiwic3RhdHVzIiwibWFwIiwicGF0aCIsInNpYmxpbmciLCJzaWJsaW5nUG9ydHMiLCJzZXNzaW9uIiwidXNlVG9vbHNTZXNzaW9uIiwicG9ydHMiLCJ1bmRlZmluZWQiLCJyZWFkRmlsZSIsIlByb2JsZW1zSGFsZiIsImJ1aWxkRXJyb3JzIiwidXNlRGlhZ25vc3RpY3MiLCJqc3giLCJfYyIsIlJ1bm5lckhhbGYiLCJfYzIiLCJBcHAiLCJyZWdpb24iLCJ1c2VSZWdpb24iLCJ0aXRsZSIsImRldGFpbCIsIml0ZW0iLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLCBib290ZWRcbi8vIGF0IHRoZSBsaXRlcmFsIHBhdGggYGZpbGVzL3NyYy9BcHAudHN4YC4gYG1haW4udHN4YCBpcyBuZXZlciBsb2FkZWQgYnkgdGhlIGhvc3QuXG4vL1xuLy8gVGhlIFRvb2xzIGFjdGl2aXR5IG9jY3VwaWVzIFRXTyByZWdpb25zIGZyb20gdGhpcyBvbmUgcmVwbywgYW5kIHRoZSBwbGF0Zm9ybSBoYXNcbi8vIG5vIHdheSB0byBiaW5kIGEgcmVnaW9uIHRvIGEgc3BlY2lmaWMgZW50cnkgcG9pbnQgKGBSZWdpb25CaW5kaW5nYCBjYXJyaWVzIG5vXG4vLyBgZW50cnlQb2ludGAsIGFuZCBwcm9ncmFtLWlkZW50aXR5IGBhcHBLZXlgIGlzIHdyaXR0ZW4gYnV0IHVud2lyZWQpLiBTbyBvbmVcbi8vIHByb2dyYW0gc2VydmVzIGJvdGggaGFsdmVzIGFuZCBicmFuY2hlcyBvbiBgdXNlUmVnaW9uKClgIOKAlCB0aGUgc2hpcHBlZCBpZGlvbSxcbi8vIHdpdGggdHdvIHByZWNlZGVudHM6IGBhZ2VudC1kZW1vYCAocGFuZWwuYWdlbnQgKyBzdGFnZS5jb252ZXJzYXRpb24pIGFuZFxuLy8gYGZpbGUtZXhwbG9yZXJgIChwYW5lbC5maWxlcyArIHBhZ2UuY29tbWFuZGVyKSwgd2hpY2ggUFJJTkNJUEFMU19TUEVDIMKnNCBjYWxsc1xuLy8gb25lLXJlcG8tbWFueS1iaW5kaW5ncy5cbi8vXG4vLyBUaGUgdHdvIGhhbHZlcyBhcmUgdHdvIEZSQU1FUzogdGhlIGhvc3QgbW91bnRzIGVhY2ggcmVnaW9uIGluIGl0cyBvd24gc2FuZGJveGVkXG4vLyBpZnJhbWUsIHNvIHRoZXkgc2hhcmUgbm8gbWVtb3J5LiBUaGV5IGtlZXAgb25lIHNlc3Npb24gaW4gc3RlcCBvdmVyIHRoZWlyIHNpbmdsZVxuLy8gSVBDIGVkZ2UgdG8gZWFjaCBvdGhlciAoYGhvb2tzL3VzZVNpYmxpbmdTeW5jLnRzYCwgcHJvdG9jb2wgaW4gYGxpYi9zeW5jLnRzYCkuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VEaWFnbm9zdGljcywgdXNlSG9zdFRoZW1lLCB1c2VSZWdpb24sIG9uVmNzU3RhdGVDaGFuZ2UsIHVzZVZjc1N0YXRlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IFBsYWNlaG9sZGVyIGZyb20gJy4vY29tcG9uZW50cy9QbGFjZWhvbGRlcic7XG5pbXBvcnQgUHJvYmxlbXNQYW5lbCBmcm9tICcuL2NvbXBvbmVudHMvUHJvYmxlbXNQYW5lbCc7XG5pbXBvcnQgUnVubmVyUGFuZSBmcm9tICcuL2NvbXBvbmVudHMvUnVubmVyUGFuZSc7XG5pbXBvcnQgeyBvcGVuRGlhZ25vc3RpYywgc2libGluZ1BvcnRzLCBzdGFsZW5lc3NQb3J0cyB9IGZyb20gJy4vbGliL2hvc3QnO1xuaW1wb3J0IHR5cGUgeyBEaWFnbm9zdGljIH0gZnJvbSAnLi9saWIvZGlhZ25vc3RpY3MnO1xuaW1wb3J0IHsgdXNlVG9vbHNTZXNzaW9uIH0gZnJvbSAnLi9ob29rcy91c2VUb29sc1Nlc3Npb24nO1xuaW1wb3J0IHsgdXNlV29ya2luZ1RyZWUgfSBmcm9tICcuL2hvb2tzL3VzZVdvcmtpbmdUcmVlJztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuXG4vKiogVGhlIGhvc3QncyB0aGVtZSByZWFjaGVzIHRoaXMgZnJhbWUgb3ZlciB0aGUgU0RLIGNoYW5uZWwsIG5vdCBhcyBDU1Mg4oCUIG1pcnJvciBpdFxuICogIG9udG8gdGhlIHJvb3QgZWxlbWVudCBzbyB0aGUgc3R5bGVzaGVldCdzIGBodG1sW2RhdGEtdGhlbWVdYCBibG9jayBhcHBsaWVzLiAqL1xuZnVuY3Rpb24gdXNlTWlycm9yZWRUaGVtZSgpIHtcbiAgY29uc3QgdGhlbWUgPSB1c2VIb3N0VGhlbWUoKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGF0YXNldC50aGVtZSA9IHRoZW1lO1xuICB9LCBbdGhlbWVdKTtcbn1cblxuLyoqIFJlc29sdmUgb25jZSB0aGUgaG9zdCBoYXMgcHVzaGVkIHZjcyBzdGF0ZSAoc28gdGhlIGRlZmF1bHQgc2NvcGUgc2VlcyB0aGUgY2hhbmdlZFxuICogIGZpbGVzKSwgb3IgYWZ0ZXIgYSBzaG9ydCBkZWFkbGluZSB3aGVuIHRoZXJlIGlzIG5vIGNvbnRyaWJ1dGUgc2Vzc2lvbiB0byBwdXNoLiAqL1xuY29uc3QgYXdhaXRIb3N0ID0gKCk6IFByb21pc2U8dm9pZD4gPT5cbiAgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBsZXQgZG9uZSA9IGZhbHNlO1xuICAgIC8vIFRoZSBjaGFubmVsIFJFUExBWVMgaXRzIGN1cnJlbnQgdmFsdWUgdG8gYSBsYXRlIHN1YnNjcmliZXIgc3luY2hyb25vdXNseSwgc28gdGhlXG4gICAgLy8gbGlzdGVuZXIgY2FuIHJ1biBiZWZvcmUgYHN1YnNjcmliZWAgaGFzIGV2ZW4gcmV0dXJuZWQg4oCUIGBvZmZgIG11c3QgZXhpc3QgZmlyc3QuXG4gICAgLy8gKENhdWdodCBsaXZlIGJ5IHRoaXMgdmVyeSBwYW5lbDogaXRzIGZpcnN0IGJ1aWxkIHJvdyB3YXMgdGhlIFREWiBlcnJvciBoZXJlLilcbiAgICBsZXQgb2ZmOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG4gICAgY29uc3QgZmluaXNoID0gKCkgPT4ge1xuICAgICAgaWYgKGRvbmUpIHJldHVybjtcbiAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgb2ZmKCk7XG4gICAgICByZXNvbHZlKCk7XG4gICAgfTtcbiAgICBvZmYgPSBvblZjc1N0YXRlQ2hhbmdlKCgpID0+IGZpbmlzaCgpKTtcbiAgICBpZiAoZG9uZSkgb2ZmKCk7XG4gICAgc2V0VGltZW91dChmaW5pc2gsIDE1MDApO1xuICB9KTtcblxuY29uc3Qgb25PcGVuID0gKGQ6IERpYWdub3N0aWMpID0+IG9wZW5EaWFnbm9zdGljKGQsIHsgcmV2ZWFsOiB0cnVlIH0pO1xuXG4vKiogRXZlcnl0aGluZyBib3RoIGhhbHZlcyBzaGFyZTogdGhlIHdvcmtpbmcgdHJlZSwgdGhlIHN0YWxlbmVzcyBsZWdzLCB0aGUgc2libGluZ1xuICogIGVkZ2UsIGFuZCB0aGUgc2Vzc2lvbiBvdmVyIHRoZW0uIFRoZSBwYW5lbCBkb2VzIHRoZSBvbmUgYXV0b21hdGljIGZpcnN0LW9wZW4gcnVuXG4gKiAgKMKnNy4xKTsgdGhlIHJ1bm5lciBhc2tzIHRoZSBwYW5lbCBmb3IgdGhlIGN1cnJlbnQgc3RhdGUgaW5zdGVhZC4gKi9cbmZ1bmN0aW9uIHVzZUhhbGYoYXV0b1J1bjogYm9vbGVhbikge1xuICB1c2VNaXJyb3JlZFRoZW1lKCk7XG4gIGNvbnN0IHRyZWUgPSB1c2VXb3JraW5nVHJlZSgpO1xuICBjb25zdCBzdGFsZW5lc3MgPSB1c2VNZW1vKCgpID0+ICh0cmVlID8gc3RhbGVuZXNzUG9ydHModHJlZS5tb3VudCkgOiBudWxsKSwgW3RyZWVdKTtcbiAgLy8gVGhlIGxpdmUgY2hhbmdlZCBzZXQsIGZvciB0aGUgcmUtdmFsaWRhdGlvbiBsZWcgKFIzLTQ0MikuIEEgZGVsZXRlZCBwYXRoIGlzIG5vdCBhXG4gIC8vIHdyaXRlIHRvIGEgY292ZXJlZCBmaWxlIGluIGFueSB1c2VmdWwgc2Vuc2Ug4oCUIHRoZSBydW4ncyBvd24gc2NvcGUgZXhjbHVkZXMgdGhlbS5cbiAgY29uc3QgdmNzID0gdXNlVmNzU3RhdGUoKTtcbiAgY29uc3QgY2hhbmdlZE5vdyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gdmNzLmNoYW5nZXMuZmlsdGVyKChjKSA9PiBjLnN0YXR1cyAhPT0gJ2RlbGV0ZWQnKS5tYXAoKGMpID0+IGMucGF0aCksXG4gICAgW3Zjcy5jaGFuZ2VzXSxcbiAgKTtcbiAgY29uc3Qgc2libGluZyA9IHVzZU1lbW8oKCkgPT4gc2libGluZ1BvcnRzKCksIFtdKTtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVRvb2xzU2Vzc2lvbih7IHBvcnRzOiB0cmVlID09PSB1bmRlZmluZWQgPyB1bmRlZmluZWQgOiAodHJlZT8ucG9ydHMgPz8gbnVsbCksIHN0YWxlbmVzcywgc2libGluZywgYXV0b1J1biwgYXdhaXRIb3N0LCBjaGFuZ2VkTm93IH0pO1xuICBjb25zdCByZWFkRmlsZSA9IHVzZU1lbW8oKCkgPT4gKHRyZWUgPyAocGF0aDogc3RyaW5nKSA9PiB0cmVlLnBvcnRzLnJlYWRGaWxlKHBhdGgpIDogbnVsbCksIFt0cmVlXSk7XG4gIHJldHVybiB7IHNlc3Npb24sIHJlYWRGaWxlIH07XG59XG5cbmZ1bmN0aW9uIFByb2JsZW1zSGFsZigpIHtcbiAgY29uc3QgeyBzZXNzaW9uIH0gPSB1c2VIYWxmKHRydWUpO1xuICBjb25zdCB7IGJ1aWxkRXJyb3JzIH0gPSB1c2VEaWFnbm9zdGljcygpO1xuICByZXR1cm4gPFByb2JsZW1zUGFuZWwgc2Vzc2lvbj17c2Vzc2lvbn0gYnVpbGRFcnJvcnM9e2J1aWxkRXJyb3JzfSBvbk9wZW49e29uT3Blbn0gLz47XG59XG5cbmZ1bmN0aW9uIFJ1bm5lckhhbGYoKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiwgcmVhZEZpbGUgfSA9IHVzZUhhbGYoZmFsc2UpO1xuICBjb25zdCB7IGJ1aWxkRXJyb3JzIH0gPSB1c2VEaWFnbm9zdGljcygpO1xuICByZXR1cm4gPFJ1bm5lclBhbmUgc2Vzc2lvbj17c2Vzc2lvbn0gYnVpbGRFcnJvcnM9e2J1aWxkRXJyb3JzfSBvbk9wZW49e29uT3Blbn0gcmVhZEZpbGU9e3JlYWRGaWxlfSAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCByZWdpb24gPSB1c2VSZWdpb24oKTtcblxuICBpZiAocmVnaW9uID09PSAncGFuZWwudG9vbHMnKSByZXR1cm4gPFByb2JsZW1zSGFsZiAvPjtcbiAgaWYgKHJlZ2lvbiA9PT0gJ21haW5wYW5lLnRvb2xzJykgcmV0dXJuIDxSdW5uZXJIYWxmIC8+O1xuXG4gIC8vIFN0YW5kYWxvbmUgKG5vIHJlZ2lvbik6IGxvYWRlZCBmcm9tIGEgVVJMIG9yIGEgZGV2IHNlcnZlciByYXRoZXIgdGhhbiBib3VuZFxuICAvLyBpbnRvIHRoZSB3b3JrYmVuY2guIFRoZXJlIGlzIG5vIHdvcmtpbmctdHJlZSBtb3VudCBoZXJlIGFuZCBubyBlZGl0b3Igc2Vzc2lvbixcbiAgLy8gc28gdGhlcmUgaXMgbm90aGluZyB0byByZXBvcnQgb24g4oCUIHNheSB0aGF0IHJhdGhlciB0aGFuIHJlbmRlciBhbiBlbXB0eSBzaGVsbC5cbiAgcmV0dXJuIChcbiAgICA8UGxhY2Vob2xkZXJcbiAgICAgIHJlZ2lvbj17bnVsbH1cbiAgICAgIHRpdGxlPVwiVG9vbHNcIlxuICAgICAgZGV0YWlsPVwiVGhpcyBhcHAgaXMgYSB3b3JrYmVuY2ggc3VyZmFjZS4gT3BlbiBpdCBmcm9tIHRoZSBUb29scyBhY3Rpdml0eSBpbnNpZGUgdGhlIGltbWVkaWF0ZWx5LnJ1biBlZGl0b3IsIHdoZXJlIGl0IGNhbiBzZWUgdGhlIHdvcmtpbmcgdHJlZSBpdCByZXBvcnRzIG9uLlwiXG4gICAgICBpdGVtPVwiUjMtMzg3XCJcbiAgICAvPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFjQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxZQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSSxjQUFBLEdBQUFELHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSyxXQUFBLEdBQUFGLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBTSxLQUFBLEdBQUFOLE9BQUE7QUFFQSxJQUFBTyxnQkFBQSxHQUFBUCxPQUFBO0FBQ0EsSUFBQVEsZUFBQSxHQUFBUixPQUFBO0FBQ0FBLE9BQUE7QUFBcUIsSUFBQVMsV0FBQSxHQUFBVCxPQUFBO0FBQUEsSUFBQVUsRUFBQSxHQUFBQyxZQUFBO0VBQUFDLEdBQUEsR0FBQUQsWUFBQTtFQUFBRSxHQUFBLEdBQUFGLFlBQUE7RUFBQUcsR0FBQSxHQUFBSCxZQUFBO0VBQUFJLEdBQUEsR0FBQUosWUFBQSxJQXZCckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVlBO0FBQ0E7QUFEQSxTQUFBUix1QkFBQWEsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUVBLFNBQVNHLGdCQUFnQkEsQ0FBQSxFQUFHO0VBQUFULEVBQUE7RUFDMUIsTUFBTVUsS0FBSyxHQUFHLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztFQUM1QixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZEMsUUFBUSxDQUFDQyxlQUFlLENBQUNDLE9BQU8sQ0FBQ0wsS0FBSyxHQUFHQSxLQUFLO0VBQ2hELENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztBQUNiOztBQUVBO0FBQ0E7QUFEQVYsRUFBQSxDQVBTUyxnQkFBZ0I7RUFBQSxRQUNURSxpQkFBWTtBQUFBO0FBUTVCLE1BQU1LLFNBQVMsR0FBR0EsQ0FBQSxLQUNoQixJQUFJQyxPQUFPLENBQUVDLE9BQU8sSUFBSztFQUN2QixJQUFJQyxJQUFJLEdBQUcsS0FBSztFQUNoQjtFQUNBO0VBQ0E7RUFDQSxJQUFJQyxHQUFlLEdBQUdBLENBQUEsS0FBTSxDQUFDLENBQUM7RUFDOUIsTUFBTUMsTUFBTSxHQUFHQSxDQUFBLEtBQU07SUFDbkIsSUFBSUYsSUFBSSxFQUFFO0lBQ1ZBLElBQUksR0FBRyxJQUFJO0lBQ1hDLEdBQUcsQ0FBQyxDQUFDO0lBQ0xGLE9BQU8sQ0FBQyxDQUFDO0VBQ1gsQ0FBQztFQUNERSxHQUFHLEdBQUcsSUFBQUUscUJBQWdCLEVBQUMsTUFBTUQsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUN0QyxJQUFJRixJQUFJLEVBQUVDLEdBQUcsQ0FBQyxDQUFDO0VBQ2ZHLFVBQVUsQ0FBQ0YsTUFBTSxFQUFFLElBQUksQ0FBQztBQUMxQixDQUFDLENBQUM7QUFFSixNQUFNRyxNQUFNLEdBQUlDLENBQWEsSUFBSyxJQUFBQyxvQkFBYyxFQUFDRCxDQUFDLEVBQUU7RUFBRUUsTUFBTSxFQUFFO0FBQUssQ0FBQyxDQUFDOztBQUVyRTtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxPQUFPQSxDQUFDQyxPQUFnQixFQUFFO0VBQUEzQixHQUFBO0VBQ2pDTyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQ2xCLE1BQU1xQixJQUFJLEdBQUcsSUFBQUMsOEJBQWMsRUFBQyxDQUFDO0VBQzdCLE1BQU1DLFNBQVMsR0FBRyxJQUFBQyxjQUFPLEVBQUMsTUFBT0gsSUFBSSxHQUFHLElBQUFJLG9CQUFjLEVBQUNKLElBQUksQ0FBQ0ssS0FBSyxDQUFDLEdBQUcsSUFBSyxFQUFFLENBQUNMLElBQUksQ0FBQyxDQUFDO0VBQ25GO0VBQ0E7RUFDQSxNQUFNTSxHQUFHLEdBQUcsSUFBQUMsZ0JBQVcsRUFBQyxDQUFDO0VBQ3pCLE1BQU1DLFVBQVUsR0FBRyxJQUFBTCxjQUFPLEVBQ3hCLE1BQU1HLEdBQUcsQ0FBQ0csT0FBTyxDQUFDQyxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUNDLEdBQUcsQ0FBRUYsQ0FBQyxJQUFLQSxDQUFDLENBQUNHLElBQUksQ0FBQyxFQUMxRSxDQUFDUixHQUFHLENBQUNHLE9BQU8sQ0FDZCxDQUFDO0VBQ0QsTUFBTU0sT0FBTyxHQUFHLElBQUFaLGNBQU8sRUFBQyxNQUFNLElBQUFhLGtCQUFZLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNqRCxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsZ0NBQWUsRUFBQztJQUFFQyxLQUFLLEVBQUVuQixJQUFJLEtBQUtvQixTQUFTLEdBQUdBLFNBQVMsR0FBSXBCLElBQUksRUFBRW1CLEtBQUssSUFBSSxJQUFLO0lBQUVqQixTQUFTO0lBQUVhLE9BQU87SUFBRWhCLE9BQU87SUFBRWIsU0FBUztJQUFFc0I7RUFBVyxDQUFDLENBQUM7RUFDdEosTUFBTWEsUUFBUSxHQUFHLElBQUFsQixjQUFPLEVBQUMsTUFBT0gsSUFBSSxHQUFJYyxJQUFZLElBQUtkLElBQUksQ0FBQ21CLEtBQUssQ0FBQ0UsUUFBUSxDQUFDUCxJQUFJLENBQUMsR0FBRyxJQUFLLEVBQUUsQ0FBQ2QsSUFBSSxDQUFDLENBQUM7RUFDbkcsT0FBTztJQUFFaUIsT0FBTztJQUFFSTtFQUFTLENBQUM7QUFDOUI7QUFBQ2pELEdBQUEsQ0FmUTBCLE9BQU87RUFBQSxRQUNkbkIsZ0JBQWdCLEVBQ0hzQiw4QkFBYyxFQUlmTSxnQkFBVyxFQU1QVyxnQ0FBZTtBQUFBO0FBS2pDLFNBQVNJLFlBQVlBLENBQUEsRUFBRztFQUFBakQsR0FBQTtFQUN0QixNQUFNO0lBQUU0QztFQUFRLENBQUMsR0FBR25CLE9BQU8sQ0FBQyxJQUFJLENBQUM7RUFDakMsTUFBTTtJQUFFeUI7RUFBWSxDQUFDLEdBQUcsSUFBQUMsbUJBQWMsRUFBQyxDQUFDO0VBQ3hDLG9CQUFPLElBQUF2RCxXQUFBLENBQUF3RCxHQUFBLEVBQUM3RCxjQUFBLENBQUFjLE9BQWE7SUFBQ3VDLE9BQU8sRUFBRUEsT0FBUTtJQUFDTSxXQUFXLEVBQUVBLFdBQVk7SUFBQzdCLE1BQU0sRUFBRUE7RUFBTyxDQUFFLENBQUM7QUFDdEY7QUFBQ3JCLEdBQUEsQ0FKUWlELFlBQVk7RUFBQSxRQUNDeEIsT0FBTyxFQUNIMEIsbUJBQWM7QUFBQTtBQUFBRSxFQUFBLEdBRi9CSixZQUFZO0FBTXJCLFNBQVNLLFVBQVVBLENBQUEsRUFBRztFQUFBckQsR0FBQTtFQUNwQixNQUFNO0lBQUUyQyxPQUFPO0lBQUVJO0VBQVMsQ0FBQyxHQUFHdkIsT0FBTyxDQUFDLEtBQUssQ0FBQztFQUM1QyxNQUFNO0lBQUV5QjtFQUFZLENBQUMsR0FBRyxJQUFBQyxtQkFBYyxFQUFDLENBQUM7RUFDeEMsb0JBQU8sSUFBQXZELFdBQUEsQ0FBQXdELEdBQUEsRUFBQzVELFdBQUEsQ0FBQWEsT0FBVTtJQUFDdUMsT0FBTyxFQUFFQSxPQUFRO0lBQUNNLFdBQVcsRUFBRUEsV0FBWTtJQUFDN0IsTUFBTSxFQUFFQSxNQUFPO0lBQUMyQixRQUFRLEVBQUVBO0VBQVMsQ0FBRSxDQUFDO0FBQ3ZHO0FBQUMvQyxHQUFBLENBSlFxRCxVQUFVO0VBQUEsUUFDYTdCLE9BQU8sRUFDYjBCLG1CQUFjO0FBQUE7QUFBQUksR0FBQSxHQUYvQkQsVUFBVTtBQU1KLFNBQVNFLEdBQUdBLENBQUEsRUFBRztFQUFBdEQsR0FBQTtFQUM1QixNQUFNdUQsTUFBTSxHQUFHLElBQUFDLGNBQVMsRUFBQyxDQUFDO0VBRTFCLElBQUlELE1BQU0sS0FBSyxhQUFhLEVBQUUsb0JBQU8sSUFBQTdELFdBQUEsQ0FBQXdELEdBQUEsRUFBQ0gsWUFBWSxJQUFFLENBQUM7RUFDckQsSUFBSVEsTUFBTSxLQUFLLGdCQUFnQixFQUFFLG9CQUFPLElBQUE3RCxXQUFBLENBQUF3RCxHQUFBLEVBQUNFLFVBQVUsSUFBRSxDQUFDOztFQUV0RDtFQUNBO0VBQ0E7RUFDQSxvQkFDRSxJQUFBMUQsV0FBQSxDQUFBd0QsR0FBQSxFQUFDL0QsWUFBQSxDQUFBZ0IsT0FBVztJQUNWb0QsTUFBTSxFQUFFLElBQUs7SUFDYkUsS0FBSyxFQUFDLE9BQU87SUFDYkMsTUFBTSxFQUFDLHNKQUFzSjtJQUM3SkMsSUFBSSxFQUFDO0VBQVEsQ0FDZCxDQUFDO0FBRU47QUFBQzNELEdBQUEsQ0FqQnVCc0QsR0FBRztFQUFBLFFBQ1ZFLGNBQVM7QUFBQTtBQUFBSSxHQUFBLEdBREZOLEdBQUc7QUFBQSxJQUFBSCxFQUFBLEVBQUFFLEdBQUEsRUFBQU8sR0FBQTtBQUFBQyxZQUFBLENBQUFWLEVBQUE7QUFBQVUsWUFBQSxDQUFBUixHQUFBO0FBQUFRLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}