var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = CodeFrame;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _codeFrame = require("../lib/codeFrame");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The read-only code frame (§8.2): the selected diagnostic in source context, the hit
// line marked, and a caret row under the span (tsc) or at the point (everything else).
// Read-only on purpose — two editable views of one file is the conflict surface
// EDITOR_AS_APP_SPEC §6 exists to keep small. The file is read from the working-tree
// mount at selection time, so a stale run shows the CURRENT text, which is the honest
// thing: the caret may no longer point at the problem, and the stale banner says so.
/** The last completed read, keyed by the diagnostic it was for — so a switch of
 *  selection renders "reading…" (a key mismatch) rather than the previous file. */
function CodeFrame({
  diagnostic,
  readFile
}) {
  _s();
  const [loaded, setLoaded] = (0, _react.useState)(null);
  const {
    id: key,
    path,
    line,
    severity
  } = diagnostic;

  // Derived, not state: the two cases that need no read.
  const unavailable = path === null || line === null ? 'This problem is not located in a file.' : !readFile ? 'No working tree to read from.' : null;
  (0, _react.useEffect)(() => {
    if (unavailable || !readFile || path === null) return;
    let cancelled = false;
    readFile(path).then(content => {
      if (!cancelled) setLoaded({
        key,
        rows: (0, _codeFrame.buildFrame)(diagnostic, content)
      });
    }, () => {
      if (!cancelled) setLoaded({
        key,
        error: 'That file is no longer in the working tree.'
      });
    });
    return () => {
      cancelled = true;
    };
    // `key` (the diagnostic id) is what a re-read follows; the object identity is not.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, path, readFile, unavailable]);
  if (unavailable) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "frame-code",
      "data-severity": severity,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "frame-empty",
        children: unavailable
      })
    });
  }
  if (!loaded || loaded.key !== key) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "frame-code",
      "data-severity": severity,
      "aria-busy": "true",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "frame-empty",
        children: ["Reading ", path, "\u2026"]
      })
    });
  }
  if ('error' in loaded) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "frame-code",
      "data-severity": severity,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "frame-empty",
        children: loaded.error
      })
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "frame-code",
    "data-severity": severity,
    role: "figure",
    "aria-label": `${path} around line ${line}`,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("table", {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("tbody", {
        children: loaded.rows.map((r, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
          className: r.kind === 'hit' ? 'hit' : r.kind === 'caret' ? 'caret' : undefined,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
            className: "ln",
            children: r.line ?? ' '
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
            children: r.text || ' '
          })]
        }, i))
      })
    })
  });
}
_s(CodeFrame, "t8wQi0jscww/hrcKAaZRAfoHuBQ=");
_c = CodeFrame;
var _c;
$RefreshReg$(_c, "CodeFrame");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NvZGVGcmFtZSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJDb2RlRnJhbWUiLCJkaWFnbm9zdGljIiwicmVhZEZpbGUiLCJsb2FkZWQiLCJzZXRMb2FkZWQiLCJ1c2VTdGF0ZSIsImlkIiwia2V5IiwicGF0aCIsImxpbmUiLCJzZXZlcml0eSIsInVuYXZhaWxhYmxlIiwidXNlRWZmZWN0IiwiY2FuY2VsbGVkIiwidGhlbiIsImNvbnRlbnQiLCJyb3dzIiwiYnVpbGRGcmFtZSIsImVycm9yIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3hzIiwicm9sZSIsIm1hcCIsInIiLCJpIiwia2luZCIsInVuZGVmaW5lZCIsInRleHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvZGVGcmFtZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHJlYWQtb25seSBjb2RlIGZyYW1lICjCpzguMik6IHRoZSBzZWxlY3RlZCBkaWFnbm9zdGljIGluIHNvdXJjZSBjb250ZXh0LCB0aGUgaGl0XG4vLyBsaW5lIG1hcmtlZCwgYW5kIGEgY2FyZXQgcm93IHVuZGVyIHRoZSBzcGFuICh0c2MpIG9yIGF0IHRoZSBwb2ludCAoZXZlcnl0aGluZyBlbHNlKS5cbi8vIFJlYWQtb25seSBvbiBwdXJwb3NlIOKAlCB0d28gZWRpdGFibGUgdmlld3Mgb2Ygb25lIGZpbGUgaXMgdGhlIGNvbmZsaWN0IHN1cmZhY2Vcbi8vIEVESVRPUl9BU19BUFBfU1BFQyDCpzYgZXhpc3RzIHRvIGtlZXAgc21hbGwuIFRoZSBmaWxlIGlzIHJlYWQgZnJvbSB0aGUgd29ya2luZy10cmVlXG4vLyBtb3VudCBhdCBzZWxlY3Rpb24gdGltZSwgc28gYSBzdGFsZSBydW4gc2hvd3MgdGhlIENVUlJFTlQgdGV4dCwgd2hpY2ggaXMgdGhlIGhvbmVzdFxuLy8gdGhpbmc6IHRoZSBjYXJldCBtYXkgbm8gbG9uZ2VyIHBvaW50IGF0IHRoZSBwcm9ibGVtLCBhbmQgdGhlIHN0YWxlIGJhbm5lciBzYXlzIHNvLlxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgRGlhZ25vc3RpYyB9IGZyb20gJy4uL2xpYi9kaWFnbm9zdGljcyc7XG5pbXBvcnQgeyB0eXBlIEZyYW1lUm93LCBidWlsZEZyYW1lIH0gZnJvbSAnLi4vbGliL2NvZGVGcmFtZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29kZUZyYW1lUHJvcHMge1xuICBkaWFnbm9zdGljOiBEaWFnbm9zdGljO1xuICByZWFkRmlsZTogKChwYXRoOiBzdHJpbmcpID0+IFByb21pc2U8c3RyaW5nPikgfCBudWxsO1xufVxuXG4vKiogVGhlIGxhc3QgY29tcGxldGVkIHJlYWQsIGtleWVkIGJ5IHRoZSBkaWFnbm9zdGljIGl0IHdhcyBmb3Ig4oCUIHNvIGEgc3dpdGNoIG9mXG4gKiAgc2VsZWN0aW9uIHJlbmRlcnMgXCJyZWFkaW5n4oCmXCIgKGEga2V5IG1pc21hdGNoKSByYXRoZXIgdGhhbiB0aGUgcHJldmlvdXMgZmlsZS4gKi9cbnR5cGUgTG9hZGVkID0geyBrZXk6IHN0cmluZzsgcm93czogRnJhbWVSb3dbXSB9IHwgeyBrZXk6IHN0cmluZzsgZXJyb3I6IHN0cmluZyB9O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb2RlRnJhbWUoeyBkaWFnbm9zdGljLCByZWFkRmlsZSB9OiBDb2RlRnJhbWVQcm9wcykge1xuICBjb25zdCBbbG9hZGVkLCBzZXRMb2FkZWRdID0gdXNlU3RhdGU8TG9hZGVkIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHsgaWQ6IGtleSwgcGF0aCwgbGluZSwgc2V2ZXJpdHkgfSA9IGRpYWdub3N0aWM7XG5cbiAgLy8gRGVyaXZlZCwgbm90IHN0YXRlOiB0aGUgdHdvIGNhc2VzIHRoYXQgbmVlZCBubyByZWFkLlxuICBjb25zdCB1bmF2YWlsYWJsZSA9IHBhdGggPT09IG51bGwgfHwgbGluZSA9PT0gbnVsbCA/ICdUaGlzIHByb2JsZW0gaXMgbm90IGxvY2F0ZWQgaW4gYSBmaWxlLicgOiAhcmVhZEZpbGUgPyAnTm8gd29ya2luZyB0cmVlIHRvIHJlYWQgZnJvbS4nIDogbnVsbDtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh1bmF2YWlsYWJsZSB8fCAhcmVhZEZpbGUgfHwgcGF0aCA9PT0gbnVsbCkgcmV0dXJuO1xuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICByZWFkRmlsZShwYXRoKS50aGVuKFxuICAgICAgKGNvbnRlbnQpID0+IHtcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldExvYWRlZCh7IGtleSwgcm93czogYnVpbGRGcmFtZShkaWFnbm9zdGljLCBjb250ZW50KSB9KTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICghY2FuY2VsbGVkKSBzZXRMb2FkZWQoeyBrZXksIGVycm9yOiAnVGhhdCBmaWxlIGlzIG5vIGxvbmdlciBpbiB0aGUgd29ya2luZyB0cmVlLicgfSk7XG4gICAgICB9LFxuICAgICk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgfTtcbiAgICAvLyBga2V5YCAodGhlIGRpYWdub3N0aWMgaWQpIGlzIHdoYXQgYSByZS1yZWFkIGZvbGxvd3M7IHRoZSBvYmplY3QgaWRlbnRpdHkgaXMgbm90LlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2tleSwgcGF0aCwgcmVhZEZpbGUsIHVuYXZhaWxhYmxlXSk7XG5cbiAgaWYgKHVuYXZhaWxhYmxlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnJhbWUtY29kZVwiIGRhdGEtc2V2ZXJpdHk9e3NldmVyaXR5fT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZnJhbWUtZW1wdHlcIj57dW5hdmFpbGFibGV9PC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuICBpZiAoIWxvYWRlZCB8fCBsb2FkZWQua2V5ICE9PSBrZXkpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmcmFtZS1jb2RlXCIgZGF0YS1zZXZlcml0eT17c2V2ZXJpdHl9IGFyaWEtYnVzeT1cInRydWVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZnJhbWUtZW1wdHlcIj5SZWFkaW5nIHtwYXRofeKApjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cbiAgaWYgKCdlcnJvcicgaW4gbG9hZGVkKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnJhbWUtY29kZVwiIGRhdGEtc2V2ZXJpdHk9e3NldmVyaXR5fT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZnJhbWUtZW1wdHlcIj57bG9hZGVkLmVycm9yfTwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZyYW1lLWNvZGVcIiBkYXRhLXNldmVyaXR5PXtzZXZlcml0eX0gcm9sZT1cImZpZ3VyZVwiIGFyaWEtbGFiZWw9e2Ake3BhdGh9IGFyb3VuZCBsaW5lICR7bGluZX1gfT5cbiAgICAgIDx0YWJsZT5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIHtsb2FkZWQucm93cy5tYXAoKHIsIGkpID0+IChcbiAgICAgICAgICAgIDx0ciBrZXk9e2l9IGNsYXNzTmFtZT17ci5raW5kID09PSAnaGl0JyA/ICdoaXQnIDogci5raW5kID09PSAnY2FyZXQnID8gJ2NhcmV0JyA6IHVuZGVmaW5lZH0+XG4gICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJsblwiPntyLmxpbmUgPz8gJyAnfTwvdGQ+XG4gICAgICAgICAgICAgIDx0ZD57ci50ZXh0IHx8ICcgJ308L3RkPlxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBTUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsVUFBQSxHQUFBRCxPQUFBO0FBQTZELElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUFBLElBQUFHLEVBQUEsR0FBQUMsWUFBQSxJQVI3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFVQTtBQUNBO0FBR2UsU0FBU0MsU0FBU0EsQ0FBQztFQUFFQyxVQUFVO0VBQUVDO0FBQXlCLENBQUMsRUFBRTtFQUFBSixFQUFBO0VBQzFFLE1BQU0sQ0FBQ0ssTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQWdCLElBQUksQ0FBQztFQUN6RCxNQUFNO0lBQUVDLEVBQUUsRUFBRUMsR0FBRztJQUFFQyxJQUFJO0lBQUVDLElBQUk7SUFBRUM7RUFBUyxDQUFDLEdBQUdULFVBQVU7O0VBRXBEO0VBQ0EsTUFBTVUsV0FBVyxHQUFHSCxJQUFJLEtBQUssSUFBSSxJQUFJQyxJQUFJLEtBQUssSUFBSSxHQUFHLHdDQUF3QyxHQUFHLENBQUNQLFFBQVEsR0FBRywrQkFBK0IsR0FBRyxJQUFJO0VBRWxKLElBQUFVLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlELFdBQVcsSUFBSSxDQUFDVCxRQUFRLElBQUlNLElBQUksS0FBSyxJQUFJLEVBQUU7SUFDL0MsSUFBSUssU0FBUyxHQUFHLEtBQUs7SUFDckJYLFFBQVEsQ0FBQ00sSUFBSSxDQUFDLENBQUNNLElBQUksQ0FDaEJDLE9BQU8sSUFBSztNQUNYLElBQUksQ0FBQ0YsU0FBUyxFQUFFVCxTQUFTLENBQUM7UUFBRUcsR0FBRztRQUFFUyxJQUFJLEVBQUUsSUFBQUMscUJBQVUsRUFBQ2hCLFVBQVUsRUFBRWMsT0FBTztNQUFFLENBQUMsQ0FBQztJQUMzRSxDQUFDLEVBQ0QsTUFBTTtNQUNKLElBQUksQ0FBQ0YsU0FBUyxFQUFFVCxTQUFTLENBQUM7UUFBRUcsR0FBRztRQUFFVyxLQUFLLEVBQUU7TUFBOEMsQ0FBQyxDQUFDO0lBQzFGLENBQ0YsQ0FBQztJQUNELE9BQU8sTUFBTTtNQUNYTCxTQUFTLEdBQUcsSUFBSTtJQUNsQixDQUFDO0lBQ0Q7SUFDQTtFQUNGLENBQUMsRUFBRSxDQUFDTixHQUFHLEVBQUVDLElBQUksRUFBRU4sUUFBUSxFQUFFUyxXQUFXLENBQUMsQ0FBQztFQUV0QyxJQUFJQSxXQUFXLEVBQUU7SUFDZixvQkFDRSxJQUFBZCxXQUFBLENBQUFzQixHQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUMsaUJBQWVWLFFBQVM7TUFBQVcsUUFBQSxlQUNsRCxJQUFBeEIsV0FBQSxDQUFBc0IsR0FBQTtRQUFHQyxTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLEVBQUVWO01BQVcsQ0FBSTtJQUFDLENBQ3pDLENBQUM7RUFFVjtFQUNBLElBQUksQ0FBQ1IsTUFBTSxJQUFJQSxNQUFNLENBQUNJLEdBQUcsS0FBS0EsR0FBRyxFQUFFO0lBQ2pDLG9CQUNFLElBQUFWLFdBQUEsQ0FBQXNCLEdBQUE7TUFBS0MsU0FBUyxFQUFDLFlBQVk7TUFBQyxpQkFBZVYsUUFBUztNQUFDLGFBQVUsTUFBTTtNQUFBVyxRQUFBLGVBQ25FLElBQUF4QixXQUFBLENBQUF5QixJQUFBO1FBQUdGLFNBQVMsRUFBQyxhQUFhO1FBQUFDLFFBQUEsR0FBQyxVQUFRLEVBQUNiLElBQUksRUFBQyxRQUFDO01BQUEsQ0FBRztJQUFDLENBQzNDLENBQUM7RUFFVjtFQUNBLElBQUksT0FBTyxJQUFJTCxNQUFNLEVBQUU7SUFDckIsb0JBQ0UsSUFBQU4sV0FBQSxDQUFBc0IsR0FBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFDLGlCQUFlVixRQUFTO01BQUFXLFFBQUEsZUFDbEQsSUFBQXhCLFdBQUEsQ0FBQXNCLEdBQUE7UUFBR0MsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQUFFbEIsTUFBTSxDQUFDZTtNQUFLLENBQUk7SUFBQyxDQUMxQyxDQUFDO0VBRVY7RUFDQSxvQkFDRSxJQUFBckIsV0FBQSxDQUFBc0IsR0FBQTtJQUFLQyxTQUFTLEVBQUMsWUFBWTtJQUFDLGlCQUFlVixRQUFTO0lBQUNhLElBQUksRUFBQyxRQUFRO0lBQUMsY0FBWSxHQUFHZixJQUFJLGdCQUFnQkMsSUFBSSxFQUFHO0lBQUFZLFFBQUEsZUFDM0csSUFBQXhCLFdBQUEsQ0FBQXNCLEdBQUE7TUFBQUUsUUFBQSxlQUNFLElBQUF4QixXQUFBLENBQUFzQixHQUFBO1FBQUFFLFFBQUEsRUFDR2xCLE1BQU0sQ0FBQ2EsSUFBSSxDQUFDUSxHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLGtCQUNwQixJQUFBN0IsV0FBQSxDQUFBeUIsSUFBQTtVQUFZRixTQUFTLEVBQUVLLENBQUMsQ0FBQ0UsSUFBSSxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUdGLENBQUMsQ0FBQ0UsSUFBSSxLQUFLLE9BQU8sR0FBRyxPQUFPLEdBQUdDLFNBQVU7VUFBQVAsUUFBQSxnQkFDekYsSUFBQXhCLFdBQUEsQ0FBQXNCLEdBQUE7WUFBSUMsU0FBUyxFQUFDLElBQUk7WUFBQUMsUUFBQSxFQUFFSSxDQUFDLENBQUNoQixJQUFJLElBQUk7VUFBRyxDQUFLLENBQUMsZUFDdkMsSUFBQVosV0FBQSxDQUFBc0IsR0FBQTtZQUFBRSxRQUFBLEVBQUtJLENBQUMsQ0FBQ0ksSUFBSSxJQUFJO1VBQUcsQ0FBSyxDQUFDO1FBQUEsR0FGakJILENBR0wsQ0FDTDtNQUFDLENBQ0c7SUFBQyxDQUNIO0VBQUMsQ0FDTCxDQUFDO0FBRVY7QUFBQzVCLEVBQUEsQ0E1RHVCRSxTQUFTO0FBQUE4QixFQUFBLEdBQVQ5QixTQUFTO0FBQUEsSUFBQThCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}