var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _useToolsSession = require("../hooks/useToolsSession");
var _ProblemsPanel = _interopRequireDefault(require("./ProblemsPanel"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The panel over the shared session, an in-memory tree and canned service replies —
// no SDK mock, the ports ARE the seam. What is asserted here is the surface's honesty:
// the partial treatment, the clean-bill gate, the chips not counting notes, the row
// click being the (only) thing that asks the host to open, and the stale label.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const RELATIVE_NOTE = "'./lib' was not included in this typecheck request, so its exports are unchecked. This is not an error: include the file to check it.";
const BUNDLED_NOTE = "No bundled type declarations for 'zod', so its exports are unchecked. This is not an error: the typecheck runs against a fixed kernel type set, not node_modules.";
const FILES = {
  'src/use.ts': "import { greet } from './lib';\nexport const x = greet(42);",
  'src/lib.ts': 'export const greet = (n: string) => n.length;',
  'src/hooks/useTheme.ts': 'let stored = null;\nexport default stored;'
};
function ports(replies = {}) {
  return {
    readFile: async p => {
      if (p in FILES) return FILES[p];
      throw new Error('ENOENT');
    },
    listSourceFiles: async () => Object.keys(FILES),
    changedPaths: () => ['src/use.ts', 'src/hooks/useTheme.ts'],
    openPaths: () => [],
    invoke: async name => {
      if (name === 'authoring:typecheck') return replies.typecheck ?? {
        diagnostics: [],
        truncated: false,
        total: 0
      };
      return replies.lint ?? {
        diagnostics: [],
        truncated: false,
        total: 0,
        skipped: []
      };
    }
  };
}
const TYPICAL = {
  typecheck: {
    diagnostics: [{
      path: '/src/use.ts',
      start: 54,
      length: 2,
      category: 'error',
      code: 2345,
      messageText: "Argument of type 'number' is not assignable to parameter of type 'string'."
    }, {
      path: '/src/hooks/useTheme.ts',
      start: 4,
      length: 6,
      category: 'error',
      code: 2339,
      messageText: "Property 'getItem' does not exist on type 'never'."
    }, {
      path: '/src/use.ts',
      start: 22,
      length: 7,
      category: 'message',
      code: 2307,
      messageText: BUNDLED_NOTE
    }],
    truncated: false,
    total: 3
  },
  lint: {
    diagnostics: [{
      path: '/src/hooks/useTheme.ts',
      line: 1,
      column: 5,
      ruleId: 'prefer-const',
      severity: 'warning',
      messageText: "'stored' is never reassigned. Use 'const' instead."
    }],
    truncated: false,
    total: 1,
    skipped: []
  }
};
function Harness({
  p,
  onOpen,
  buildErrors = [],
  autoRun = true,
  staleness = null
}) {
  _s();
  const session = (0, _useToolsSession.useToolsSession)({
    ports: p,
    autoRun,
    staleness,
    staleDebounceMs: 1
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ProblemsPanel.default, {
    session: session,
    buildErrors: buildErrors,
    onOpen: onOpen
  });
}
_s(Harness, "N4dloAGRUnEg8obTGsRbPKuttzs=", false, function () {
  return [_useToolsSession.useToolsSession];
});
_c = Harness;
const setup = (replies, extra = {}) => {
  const onOpen = _vitest.vi.fn().mockResolvedValue(undefined);
  const utils = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
    p: ports(replies),
    onOpen: onOpen,
    ...extra
  }));
  return {
    onOpen,
    ...utils
  };
};
(0, _vitest.describe)('ProblemsPanel', () => {
  (0, _vitest.it)('runs once on open and lists three sources grouped by file, with positions', async () => {
    setup(TYPICAL, {
      buildErrors: [{
        message: 'Unexpected token',
        path: '/src/App.tsx',
        line: 28,
        column: 46
      }]
    });
    const list = await _react.screen.findByRole('listbox', {
      name: /problems by file/i
    });
    const groups = (0, _react.within)(list).getAllByRole('group');
    // A→Z by path: src/App.tsx (build), src/hooks/useTheme.ts, src/use.ts. The notes
    // group is not rendered until the Notes chip is on (see the chips test).
    (0, _vitest.expect)(groups.map(g => g.querySelector('summary')?.textContent)).toEqual(['src/App.tsx1', 'src/hooks/useTheme.ts2', 'src/use.ts1']);
    (0, _vitest.expect)((0, _react.within)(groups[0]).getByRole('option').textContent).toContain('build');
    (0, _vitest.expect)((0, _react.within)(groups[0]).getByRole('option').textContent).toContain('28:46');
    const useTheme = (0, _react.within)(groups[1]).getAllByRole('option');
    (0, _vitest.expect)(useTheme[0].textContent).toContain('tsc · TS2339');
    (0, _vitest.expect)(useTheme[0].textContent).toContain('1:5');
    (0, _vitest.expect)(useTheme[1].textContent).toContain('eslint · prefer-const');
    (0, _vitest.expect)((0, _react.within)(groups[2]).getByRole('option').textContent).toContain('2:24');
  });
  (0, _vitest.it)('G-TOOL-7 — the chips count problems, never notes; notes are off by default and toggle on', async () => {
    const user = _userEvent.default.setup();
    setup(TYPICAL);
    await _react.screen.findByRole('listbox');
    const chips = _react.screen.getByRole('group', {
      name: /filter by severity/i
    });
    (0, _vitest.expect)((0, _react.within)(chips).getByRole('button', {
      name: /errors 2/i
    })).toHaveAttribute('aria-pressed', 'true');
    (0, _vitest.expect)((0, _react.within)(chips).getByRole('button', {
      name: /warnings 1/i
    })).toHaveAttribute('aria-pressed', 'true');
    const notes = (0, _react.within)(chips).getByRole('button', {
      name: /notes 1/i
    });
    (0, _vitest.expect)(notes).toHaveAttribute('aria-pressed', 'false');
    (0, _vitest.expect)(_react.screen.queryByText(/coverage note/)).not.toBeInTheDocument();
    await user.click(notes);
    (0, _vitest.expect)(_react.screen.getByText(/1 coverage note/)).toBeInTheDocument();
    await user.click((0, _react.within)(chips).getByRole('button', {
      name: /errors 2/i
    }));
    (0, _vitest.expect)(_react.screen.queryByText(/TS2345/)).not.toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(chips).getByRole('button', {
      name: /errors 2/i
    })).toHaveAttribute('aria-pressed', 'false');
  });
  (0, _vitest.it)('the substring filter narrows by path or message', async () => {
    const user = _userEvent.default.setup();
    setup(TYPICAL);
    await _react.screen.findByRole('listbox');
    await user.type(_react.screen.getByRole('textbox', {
      name: /filter problems/i
    }), 'usetheme');
    (0, _vitest.expect)(_react.screen.getAllByRole('option')).toHaveLength(2);
    await user.clear(_react.screen.getByRole('textbox', {
      name: /filter problems/i
    }));
    await user.type(_react.screen.getByRole('textbox', {
      name: /filter problems/i
    }), 'zzz-nothing');
    (0, _vitest.expect)(_react.screen.queryAllByRole('option')).toHaveLength(0);
    (0, _vitest.expect)(_react.screen.getByText(/nothing matches/i)).toBeInTheDocument();
  });
  (0, _vitest.it)('a row click asks the host to open THAT diagnostic — the click is the gesture', async () => {
    const user = _userEvent.default.setup();
    const {
      onOpen
    } = setup(TYPICAL);
    const list = await _react.screen.findByRole('listbox');
    await user.click((0, _react.within)(list).getByText(/TS2345/).closest('button'));
    (0, _vitest.expect)(onOpen).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(onOpen.mock.calls[0][0]).toMatchObject({
      source: 'tsc',
      path: 'src/use.ts',
      line: 2,
      column: 24
    });
  });
  (0, _vitest.it)('keyboard: arrows move the selection, Enter opens', async () => {
    const user = _userEvent.default.setup();
    const {
      onOpen
    } = setup(TYPICAL);
    const list = await _react.screen.findByRole('listbox');
    const rows = (0, _react.within)(list).getAllByRole('option');
    rows[0].focus();
    await user.keyboard('{ArrowDown}');
    (0, _vitest.expect)(rows[1]).toHaveFocus();
    (0, _vitest.expect)(rows[1]).toHaveAttribute('aria-selected', 'true');
    await user.keyboard('{Enter}');
    (0, _vitest.expect)(onOpen).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(onOpen.mock.calls[0][0].id).toBe(rows[1].dataset.id);
    await user.keyboard('{End}');
    (0, _vitest.expect)(rows[rows.length - 1]).toHaveFocus();
  });
  (0, _vitest.it)('a clean run says "No problems" — and names the scope and file count it checked', async () => {
    setup();
    const clean = (await _react.screen.findByText(/no problems/i)).closest('p');
    (0, _vitest.expect)(clean).toHaveAttribute('data-clean', 'true');
    (0, _vitest.expect)(clean.textContent).toMatch(/changed files \+ imports/i);
    (0, _vitest.expect)(clean.textContent).toMatch(/3 files checked/i);
    (0, _vitest.expect)(_react.screen.queryByRole('note')).not.toBeInTheDocument();
  });
  (0, _vitest.it)('G-TOOL-5b — a relative coverage note makes the run partial: the banner names it and "No problems" never renders', async () => {
    setup({
      typecheck: {
        diagnostics: [{
          path: '/src/use.ts',
          start: 22,
          length: 7,
          category: 'message',
          code: 2307,
          messageText: RELATIVE_NOTE
        }],
        truncated: false,
        total: 1
      }
    });
    const banner = await _react.screen.findByRole('note', {
      name: /partial/i
    });
    (0, _vitest.expect)(banner.textContent).toMatch(/1 import was not checked/);
    (0, _vitest.expect)(_react.screen.queryByText(/no problems/i)).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByText(/nothing found in the files that were checked/i)).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole('status').textContent).toMatch(/partial/);
  });
  (0, _vitest.it)('G-TOOL-5 — input truncation names the dropped count and marks the run partial', async () => {
    setup({
      typecheck: {
        diagnostics: [],
        truncated: true,
        total: 240
      }
    });
    const banner = await _react.screen.findByRole('note', {
      name: /partial/i
    });
    (0, _vitest.expect)(banner.textContent).toMatch(/240 diagnostics \(service cap\)/);
    (0, _vitest.expect)(_react.screen.queryByText(/no problems/i)).not.toBeInTheDocument();
  });
  (0, _vitest.it)('G-TOOL-6 — a write to a covered file marks the run stale: labelled, dimmed, and "No problems" withdrawn', async () => {
    const listeners = new Set();
    const staleness = {
      watch: cb => (listeners.add(cb), () => listeners.delete(cb)),
      refreshDiff: async () => {}
    };
    setup({}, {
      staleness
    });
    (0, _vitest.expect)(await _react.screen.findByText(/no problems/i)).toBeInTheDocument();
    await (0, _react.waitFor)(() => (0, _vitest.expect)(listeners.size).toBe(1)); // the run committed and the watcher is on
    (0, _react.act)(() => listeners.forEach(l => l(['src/lib.ts'])));
    (0, _vitest.expect)(await _react.screen.findByText(/out of date/i)).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByText(/no problems/i)).not.toBeInTheDocument();
  });
  (0, _vitest.it)('a build error alone (no run yet) still shows, live', () => {
    setup({}, {
      autoRun: false,
      buildErrors: [{
        message: 'ReferenceError: x is not defined'
      }]
    });
    (0, _vitest.expect)(_react.screen.getByText(/not file-located/i)).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole('option').textContent).toContain('ReferenceError');
  });
  (0, _vitest.it)('a failed open is reported, not swallowed', async () => {
    const user = _userEvent.default.setup();
    const onOpen = _vitest.vi.fn().mockRejectedValue(Object.assign(new Error('gone'), {
      code: 'not-found'
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      p: ports(TYPICAL),
      onOpen: onOpen
    }));
    const list = await _react.screen.findByRole('listbox');
    await user.click((0, _react.within)(list).getAllByRole('option')[0]);
    (0, _vitest.expect)(await _react.screen.findByRole('alert')).toHaveTextContent(/no longer in the working tree/i);
  });
  (0, _vitest.it)('without a working tree it says so instead of running', () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      p: null,
      onOpen: _vitest.vi.fn()
    }));
    (0, _vitest.expect)(_react.screen.getByText(/no working tree here/i)).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole('button', {
      name: /run/i
    })).toBeDisabled();
  });
});
var _c;
$RefreshReg$(_c, "Harness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZXJFdmVudCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfdml0ZXN0IiwiX3VzZVRvb2xzU2Vzc2lvbiIsIl9Qcm9ibGVtc1BhbmVsIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlJFTEFUSVZFX05PVEUiLCJCVU5ETEVEX05PVEUiLCJGSUxFUyIsInBvcnRzIiwicmVwbGllcyIsInJlYWRGaWxlIiwicCIsIkVycm9yIiwibGlzdFNvdXJjZUZpbGVzIiwiT2JqZWN0Iiwia2V5cyIsImNoYW5nZWRQYXRocyIsIm9wZW5QYXRocyIsImludm9rZSIsIm5hbWUiLCJ0eXBlY2hlY2siLCJkaWFnbm9zdGljcyIsInRydW5jYXRlZCIsInRvdGFsIiwibGludCIsInNraXBwZWQiLCJUWVBJQ0FMIiwicGF0aCIsInN0YXJ0IiwibGVuZ3RoIiwiY2F0ZWdvcnkiLCJjb2RlIiwibWVzc2FnZVRleHQiLCJsaW5lIiwiY29sdW1uIiwicnVsZUlkIiwic2V2ZXJpdHkiLCJIYXJuZXNzIiwib25PcGVuIiwiYnVpbGRFcnJvcnMiLCJhdXRvUnVuIiwic3RhbGVuZXNzIiwic2Vzc2lvbiIsInVzZVRvb2xzU2Vzc2lvbiIsInN0YWxlRGVib3VuY2VNcyIsImpzeCIsIl9jIiwic2V0dXAiLCJleHRyYSIsInZpIiwiZm4iLCJtb2NrUmVzb2x2ZWRWYWx1ZSIsInVuZGVmaW5lZCIsInV0aWxzIiwicmVuZGVyIiwiZGVzY3JpYmUiLCJpdCIsIm1lc3NhZ2UiLCJsaXN0Iiwic2NyZWVuIiwiZmluZEJ5Um9sZSIsImdyb3VwcyIsIndpdGhpbiIsImdldEFsbEJ5Um9sZSIsImV4cGVjdCIsIm1hcCIsImciLCJxdWVyeVNlbGVjdG9yIiwidGV4dENvbnRlbnQiLCJ0b0VxdWFsIiwiZ2V0QnlSb2xlIiwidG9Db250YWluIiwidXNlVGhlbWUiLCJ1c2VyIiwidXNlckV2ZW50IiwiY2hpcHMiLCJ0b0hhdmVBdHRyaWJ1dGUiLCJub3RlcyIsInF1ZXJ5QnlUZXh0Iiwibm90IiwidG9CZUluVGhlRG9jdW1lbnQiLCJjbGljayIsImdldEJ5VGV4dCIsInR5cGUiLCJ0b0hhdmVMZW5ndGgiLCJjbGVhciIsInF1ZXJ5QWxsQnlSb2xlIiwiY2xvc2VzdCIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsIm1vY2siLCJjYWxscyIsInRvTWF0Y2hPYmplY3QiLCJzb3VyY2UiLCJyb3dzIiwiZm9jdXMiLCJrZXlib2FyZCIsInRvSGF2ZUZvY3VzIiwiaWQiLCJ0b0JlIiwiZGF0YXNldCIsImNsZWFuIiwiZmluZEJ5VGV4dCIsInRvTWF0Y2giLCJxdWVyeUJ5Um9sZSIsImJhbm5lciIsImxpc3RlbmVycyIsIlNldCIsIndhdGNoIiwiY2IiLCJhZGQiLCJkZWxldGUiLCJyZWZyZXNoRGlmZiIsIndhaXRGb3IiLCJzaXplIiwiYWN0IiwiZm9yRWFjaCIsImwiLCJtb2NrUmVqZWN0ZWRWYWx1ZSIsImFzc2lnbiIsInRvSGF2ZVRleHRDb250ZW50IiwidG9CZURpc2FibGVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvYmxlbXNQYW5lbC50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgcGFuZWwgb3ZlciB0aGUgc2hhcmVkIHNlc3Npb24sIGFuIGluLW1lbW9yeSB0cmVlIGFuZCBjYW5uZWQgc2VydmljZSByZXBsaWVzIOKAlFxuLy8gbm8gU0RLIG1vY2ssIHRoZSBwb3J0cyBBUkUgdGhlIHNlYW0uIFdoYXQgaXMgYXNzZXJ0ZWQgaGVyZSBpcyB0aGUgc3VyZmFjZSdzIGhvbmVzdHk6XG4vLyB0aGUgcGFydGlhbCB0cmVhdG1lbnQsIHRoZSBjbGVhbi1iaWxsIGdhdGUsIHRoZSBjaGlwcyBub3QgY291bnRpbmcgbm90ZXMsIHRoZSByb3dcbi8vIGNsaWNrIGJlaW5nIHRoZSAob25seSkgdGhpbmcgdGhhdCBhc2tzIHRoZSBob3N0IHRvIG9wZW4sIGFuZCB0aGUgc3RhbGUgbGFiZWwuXG5pbXBvcnQgeyBhY3QsIHJlbmRlciwgc2NyZWVuLCB3YWl0Rm9yLCB3aXRoaW4gfSBmcm9tICdAdGVzdGluZy1saWJyYXJ5L3JlYWN0JztcbmltcG9ydCB1c2VyRXZlbnQgZnJvbSAnQHRlc3RpbmctbGlicmFyeS91c2VyLWV2ZW50JztcbmltcG9ydCB7IGRlc2NyaWJlLCBleHBlY3QsIGl0LCB2aSB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgdHlwZSB7IERpYWdub3N0aWMsIEJ1aWxkRXJyb3JMaWtlIH0gZnJvbSAnLi4vbGliL2RpYWdub3N0aWNzJztcbmltcG9ydCB0eXBlIHsgUnVuUG9ydHMgfSBmcm9tICcuLi9saWIvcnVuJztcbmltcG9ydCB0eXBlIHsgU3RhbGVuZXNzUG9ydHMgfSBmcm9tICcuLi9ob29rcy91c2VTdGFsZW5lc3MnO1xuaW1wb3J0IHsgdXNlVG9vbHNTZXNzaW9uIH0gZnJvbSAnLi4vaG9va3MvdXNlVG9vbHNTZXNzaW9uJztcbmltcG9ydCBQcm9ibGVtc1BhbmVsIGZyb20gJy4vUHJvYmxlbXNQYW5lbCc7XG5cbmNvbnN0IFJFTEFUSVZFX05PVEUgPSBcIicuL2xpYicgd2FzIG5vdCBpbmNsdWRlZCBpbiB0aGlzIHR5cGVjaGVjayByZXF1ZXN0LCBzbyBpdHMgZXhwb3J0cyBhcmUgdW5jaGVja2VkLiBUaGlzIGlzIG5vdCBhbiBlcnJvcjogaW5jbHVkZSB0aGUgZmlsZSB0byBjaGVjayBpdC5cIjtcbmNvbnN0IEJVTkRMRURfTk9URSA9IFwiTm8gYnVuZGxlZCB0eXBlIGRlY2xhcmF0aW9ucyBmb3IgJ3pvZCcsIHNvIGl0cyBleHBvcnRzIGFyZSB1bmNoZWNrZWQuIFRoaXMgaXMgbm90IGFuIGVycm9yOiB0aGUgdHlwZWNoZWNrIHJ1bnMgYWdhaW5zdCBhIGZpeGVkIGtlcm5lbCB0eXBlIHNldCwgbm90IG5vZGVfbW9kdWxlcy5cIjtcblxuY29uc3QgRklMRVM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICdzcmMvdXNlLnRzJzogXCJpbXBvcnQgeyBncmVldCB9IGZyb20gJy4vbGliJztcXG5leHBvcnQgY29uc3QgeCA9IGdyZWV0KDQyKTtcIixcbiAgJ3NyYy9saWIudHMnOiAnZXhwb3J0IGNvbnN0IGdyZWV0ID0gKG46IHN0cmluZykgPT4gbi5sZW5ndGg7JyxcbiAgJ3NyYy9ob29rcy91c2VUaGVtZS50cyc6ICdsZXQgc3RvcmVkID0gbnVsbDtcXG5leHBvcnQgZGVmYXVsdCBzdG9yZWQ7Jyxcbn07XG5cbmZ1bmN0aW9uIHBvcnRzKHJlcGxpZXM6IHsgdHlwZWNoZWNrPzogdW5rbm93bjsgbGludD86IHVua25vd24gfSA9IHt9KTogUnVuUG9ydHMge1xuICByZXR1cm4ge1xuICAgIHJlYWRGaWxlOiBhc3luYyAocCkgPT4ge1xuICAgICAgaWYgKHAgaW4gRklMRVMpIHJldHVybiBGSUxFU1twXTtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRU5PRU5UJyk7XG4gICAgfSxcbiAgICBsaXN0U291cmNlRmlsZXM6IGFzeW5jICgpID0+IE9iamVjdC5rZXlzKEZJTEVTKSxcbiAgICBjaGFuZ2VkUGF0aHM6ICgpID0+IFsnc3JjL3VzZS50cycsICdzcmMvaG9va3MvdXNlVGhlbWUudHMnXSxcbiAgICBvcGVuUGF0aHM6ICgpID0+IFtdLFxuICAgIGludm9rZTogYXN5bmMgPFQsPihuYW1lOiBzdHJpbmcpOiBQcm9taXNlPFQ+ID0+IHtcbiAgICAgIGlmIChuYW1lID09PSAnYXV0aG9yaW5nOnR5cGVjaGVjaycpIHJldHVybiAocmVwbGllcy50eXBlY2hlY2sgPz8geyBkaWFnbm9zdGljczogW10sIHRydW5jYXRlZDogZmFsc2UsIHRvdGFsOiAwIH0pIGFzIFQ7XG4gICAgICByZXR1cm4gKHJlcGxpZXMubGludCA/PyB7IGRpYWdub3N0aWNzOiBbXSwgdHJ1bmNhdGVkOiBmYWxzZSwgdG90YWw6IDAsIHNraXBwZWQ6IFtdIH0pIGFzIFQ7XG4gICAgfSxcbiAgfTtcbn1cblxuY29uc3QgVFlQSUNBTCA9IHtcbiAgdHlwZWNoZWNrOiB7XG4gICAgZGlhZ25vc3RpY3M6IFtcbiAgICAgIHsgcGF0aDogJy9zcmMvdXNlLnRzJywgc3RhcnQ6IDU0LCBsZW5ndGg6IDIsIGNhdGVnb3J5OiAnZXJyb3InLCBjb2RlOiAyMzQ1LCBtZXNzYWdlVGV4dDogXCJBcmd1bWVudCBvZiB0eXBlICdudW1iZXInIGlzIG5vdCBhc3NpZ25hYmxlIHRvIHBhcmFtZXRlciBvZiB0eXBlICdzdHJpbmcnLlwiIH0sXG4gICAgICB7IHBhdGg6ICcvc3JjL2hvb2tzL3VzZVRoZW1lLnRzJywgc3RhcnQ6IDQsIGxlbmd0aDogNiwgY2F0ZWdvcnk6ICdlcnJvcicsIGNvZGU6IDIzMzksIG1lc3NhZ2VUZXh0OiBcIlByb3BlcnR5ICdnZXRJdGVtJyBkb2VzIG5vdCBleGlzdCBvbiB0eXBlICduZXZlcicuXCIgfSxcbiAgICAgIHsgcGF0aDogJy9zcmMvdXNlLnRzJywgc3RhcnQ6IDIyLCBsZW5ndGg6IDcsIGNhdGVnb3J5OiAnbWVzc2FnZScsIGNvZGU6IDIzMDcsIG1lc3NhZ2VUZXh0OiBCVU5ETEVEX05PVEUgfSxcbiAgICBdLFxuICAgIHRydW5jYXRlZDogZmFsc2UsXG4gICAgdG90YWw6IDMsXG4gIH0sXG4gIGxpbnQ6IHtcbiAgICBkaWFnbm9zdGljczogW3sgcGF0aDogJy9zcmMvaG9va3MvdXNlVGhlbWUudHMnLCBsaW5lOiAxLCBjb2x1bW46IDUsIHJ1bGVJZDogJ3ByZWZlci1jb25zdCcsIHNldmVyaXR5OiAnd2FybmluZycsIG1lc3NhZ2VUZXh0OiBcIidzdG9yZWQnIGlzIG5ldmVyIHJlYXNzaWduZWQuIFVzZSAnY29uc3QnIGluc3RlYWQuXCIgfV0sXG4gICAgdHJ1bmNhdGVkOiBmYWxzZSxcbiAgICB0b3RhbDogMSxcbiAgICBza2lwcGVkOiBbXSxcbiAgfSxcbn07XG5cbmZ1bmN0aW9uIEhhcm5lc3Moe1xuICBwLFxuICBvbk9wZW4sXG4gIGJ1aWxkRXJyb3JzID0gW10sXG4gIGF1dG9SdW4gPSB0cnVlLFxuICBzdGFsZW5lc3MgPSBudWxsLFxufToge1xuICBwOiBSdW5Qb3J0cyB8IG51bGw7XG4gIG9uT3BlbjogKGQ6IERpYWdub3N0aWMpID0+IFByb21pc2U8dm9pZD47XG4gIGJ1aWxkRXJyb3JzPzogQnVpbGRFcnJvckxpa2VbXTtcbiAgYXV0b1J1bj86IGJvb2xlYW47XG4gIHN0YWxlbmVzcz86IFN0YWxlbmVzc1BvcnRzIHwgbnVsbDtcbn0pIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVRvb2xzU2Vzc2lvbih7IHBvcnRzOiBwLCBhdXRvUnVuLCBzdGFsZW5lc3MsIHN0YWxlRGVib3VuY2VNczogMSB9KTtcbiAgcmV0dXJuIDxQcm9ibGVtc1BhbmVsIHNlc3Npb249e3Nlc3Npb259IGJ1aWxkRXJyb3JzPXtidWlsZEVycm9yc30gb25PcGVuPXtvbk9wZW59IC8+O1xufVxuXG5jb25zdCBzZXR1cCA9IChyZXBsaWVzPzogUGFyYW1ldGVyczx0eXBlb2YgcG9ydHM+WzBdLCBleHRyYTogUGFydGlhbDxSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgSGFybmVzcz4+ID0ge30pID0+IHtcbiAgY29uc3Qgb25PcGVuID0gdmkuZm48KGQ6IERpYWdub3N0aWMpID0+IFByb21pc2U8dm9pZD4+KCkubW9ja1Jlc29sdmVkVmFsdWUodW5kZWZpbmVkKTtcbiAgY29uc3QgdXRpbHMgPSByZW5kZXIoPEhhcm5lc3MgcD17cG9ydHMocmVwbGllcyl9IG9uT3Blbj17b25PcGVufSB7Li4uZXh0cmF9IC8+KTtcbiAgcmV0dXJuIHsgb25PcGVuLCAuLi51dGlscyB9O1xufTtcblxuZGVzY3JpYmUoJ1Byb2JsZW1zUGFuZWwnLCAoKSA9PiB7XG4gIGl0KCdydW5zIG9uY2Ugb24gb3BlbiBhbmQgbGlzdHMgdGhyZWUgc291cmNlcyBncm91cGVkIGJ5IGZpbGUsIHdpdGggcG9zaXRpb25zJywgYXN5bmMgKCkgPT4ge1xuICAgIHNldHVwKFRZUElDQUwsIHsgYnVpbGRFcnJvcnM6IFt7IG1lc3NhZ2U6ICdVbmV4cGVjdGVkIHRva2VuJywgcGF0aDogJy9zcmMvQXBwLnRzeCcsIGxpbmU6IDI4LCBjb2x1bW46IDQ2IH1dIH0pO1xuICAgIGNvbnN0IGxpc3QgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZSgnbGlzdGJveCcsIHsgbmFtZTogL3Byb2JsZW1zIGJ5IGZpbGUvaSB9KTtcbiAgICBjb25zdCBncm91cHMgPSB3aXRoaW4obGlzdCkuZ2V0QWxsQnlSb2xlKCdncm91cCcpO1xuICAgIC8vIEHihpJaIGJ5IHBhdGg6IHNyYy9BcHAudHN4IChidWlsZCksIHNyYy9ob29rcy91c2VUaGVtZS50cywgc3JjL3VzZS50cy4gVGhlIG5vdGVzXG4gICAgLy8gZ3JvdXAgaXMgbm90IHJlbmRlcmVkIHVudGlsIHRoZSBOb3RlcyBjaGlwIGlzIG9uIChzZWUgdGhlIGNoaXBzIHRlc3QpLlxuICAgIGV4cGVjdChncm91cHMubWFwKChnKSA9PiBnLnF1ZXJ5U2VsZWN0b3IoJ3N1bW1hcnknKT8udGV4dENvbnRlbnQpKS50b0VxdWFsKFsnc3JjL0FwcC50c3gxJywgJ3NyYy9ob29rcy91c2VUaGVtZS50czInLCAnc3JjL3VzZS50czEnXSk7XG4gICAgZXhwZWN0KHdpdGhpbihncm91cHNbMF0pLmdldEJ5Um9sZSgnb3B0aW9uJykudGV4dENvbnRlbnQpLnRvQ29udGFpbignYnVpbGQnKTtcbiAgICBleHBlY3Qod2l0aGluKGdyb3Vwc1swXSkuZ2V0QnlSb2xlKCdvcHRpb24nKS50ZXh0Q29udGVudCkudG9Db250YWluKCcyODo0NicpO1xuICAgIGNvbnN0IHVzZVRoZW1lID0gd2l0aGluKGdyb3Vwc1sxXSkuZ2V0QWxsQnlSb2xlKCdvcHRpb24nKTtcbiAgICBleHBlY3QodXNlVGhlbWVbMF0udGV4dENvbnRlbnQpLnRvQ29udGFpbigndHNjIMK3IFRTMjMzOScpO1xuICAgIGV4cGVjdCh1c2VUaGVtZVswXS50ZXh0Q29udGVudCkudG9Db250YWluKCcxOjUnKTtcbiAgICBleHBlY3QodXNlVGhlbWVbMV0udGV4dENvbnRlbnQpLnRvQ29udGFpbignZXNsaW50IMK3IHByZWZlci1jb25zdCcpO1xuICAgIGV4cGVjdCh3aXRoaW4oZ3JvdXBzWzJdKS5nZXRCeVJvbGUoJ29wdGlvbicpLnRleHRDb250ZW50KS50b0NvbnRhaW4oJzI6MjQnKTtcbiAgfSk7XG5cbiAgaXQoJ0ctVE9PTC03IOKAlCB0aGUgY2hpcHMgY291bnQgcHJvYmxlbXMsIG5ldmVyIG5vdGVzOyBub3RlcyBhcmUgb2ZmIGJ5IGRlZmF1bHQgYW5kIHRvZ2dsZSBvbicsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgc2V0dXAoVFlQSUNBTCk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoJ2xpc3Rib3gnKTtcbiAgICBjb25zdCBjaGlwcyA9IHNjcmVlbi5nZXRCeVJvbGUoJ2dyb3VwJywgeyBuYW1lOiAvZmlsdGVyIGJ5IHNldmVyaXR5L2kgfSk7XG4gICAgZXhwZWN0KHdpdGhpbihjaGlwcykuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IC9lcnJvcnMgMi9pIH0pKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtcHJlc3NlZCcsICd0cnVlJyk7XG4gICAgZXhwZWN0KHdpdGhpbihjaGlwcykuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IC93YXJuaW5ncyAxL2kgfSkpLnRvSGF2ZUF0dHJpYnV0ZSgnYXJpYS1wcmVzc2VkJywgJ3RydWUnKTtcbiAgICBjb25zdCBub3RlcyA9IHdpdGhpbihjaGlwcykuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IC9ub3RlcyAxL2kgfSk7XG4gICAgZXhwZWN0KG5vdGVzKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtcHJlc3NlZCcsICdmYWxzZScpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoL2NvdmVyYWdlIG5vdGUvKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgYXdhaXQgdXNlci5jbGljayhub3Rlcyk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoLzEgY292ZXJhZ2Ugbm90ZS8pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKGNoaXBzKS5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogL2Vycm9ycyAyL2kgfSkpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoL1RTMjM0NS8pKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qod2l0aGluKGNoaXBzKS5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogL2Vycm9ycyAyL2kgfSkpLnRvSGF2ZUF0dHJpYnV0ZSgnYXJpYS1wcmVzc2VkJywgJ2ZhbHNlJyk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgc3Vic3RyaW5nIGZpbHRlciBuYXJyb3dzIGJ5IHBhdGggb3IgbWVzc2FnZScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgc2V0dXAoVFlQSUNBTCk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoJ2xpc3Rib3gnKTtcbiAgICBhd2FpdCB1c2VyLnR5cGUoc2NyZWVuLmdldEJ5Um9sZSgndGV4dGJveCcsIHsgbmFtZTogL2ZpbHRlciBwcm9ibGVtcy9pIH0pLCAndXNldGhlbWUnKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEFsbEJ5Um9sZSgnb3B0aW9uJykpLnRvSGF2ZUxlbmd0aCgyKTtcbiAgICBhd2FpdCB1c2VyLmNsZWFyKHNjcmVlbi5nZXRCeVJvbGUoJ3RleHRib3gnLCB7IG5hbWU6IC9maWx0ZXIgcHJvYmxlbXMvaSB9KSk7XG4gICAgYXdhaXQgdXNlci50eXBlKHNjcmVlbi5nZXRCeVJvbGUoJ3RleHRib3gnLCB7IG5hbWU6IC9maWx0ZXIgcHJvYmxlbXMvaSB9KSwgJ3p6ei1ub3RoaW5nJyk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUFsbEJ5Um9sZSgnb3B0aW9uJykpLnRvSGF2ZUxlbmd0aCgwKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgvbm90aGluZyBtYXRjaGVzL2kpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdCgnYSByb3cgY2xpY2sgYXNrcyB0aGUgaG9zdCB0byBvcGVuIFRIQVQgZGlhZ25vc3RpYyDigJQgdGhlIGNsaWNrIGlzIHRoZSBnZXN0dXJlJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCB7IG9uT3BlbiB9ID0gc2V0dXAoVFlQSUNBTCk7XG4gICAgY29uc3QgbGlzdCA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKCdsaXN0Ym94Jyk7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obGlzdCkuZ2V0QnlUZXh0KC9UUzIzNDUvKS5jbG9zZXN0KCdidXR0b24nKSEpO1xuICAgIGV4cGVjdChvbk9wZW4pLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3Qob25PcGVuLm1vY2suY2FsbHNbMF1bMF0pLnRvTWF0Y2hPYmplY3QoeyBzb3VyY2U6ICd0c2MnLCBwYXRoOiAnc3JjL3VzZS50cycsIGxpbmU6IDIsIGNvbHVtbjogMjQgfSk7XG4gIH0pO1xuXG4gIGl0KCdrZXlib2FyZDogYXJyb3dzIG1vdmUgdGhlIHNlbGVjdGlvbiwgRW50ZXIgb3BlbnMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGNvbnN0IHsgb25PcGVuIH0gPSBzZXR1cChUWVBJQ0FMKTtcbiAgICBjb25zdCBsaXN0ID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoJ2xpc3Rib3gnKTtcbiAgICBjb25zdCByb3dzID0gd2l0aGluKGxpc3QpLmdldEFsbEJ5Um9sZSgnb3B0aW9uJyk7XG4gICAgcm93c1swXS5mb2N1cygpO1xuICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoJ3tBcnJvd0Rvd259Jyk7XG4gICAgZXhwZWN0KHJvd3NbMV0pLnRvSGF2ZUZvY3VzKCk7XG4gICAgZXhwZWN0KHJvd3NbMV0pLnRvSGF2ZUF0dHJpYnV0ZSgnYXJpYS1zZWxlY3RlZCcsICd0cnVlJyk7XG4gICAgYXdhaXQgdXNlci5rZXlib2FyZCgne0VudGVyfScpO1xuICAgIGV4cGVjdChvbk9wZW4pLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3Qob25PcGVuLm1vY2suY2FsbHNbMF1bMF0uaWQpLnRvQmUocm93c1sxXS5kYXRhc2V0LmlkKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKCd7RW5kfScpO1xuICAgIGV4cGVjdChyb3dzW3Jvd3MubGVuZ3RoIC0gMV0pLnRvSGF2ZUZvY3VzKCk7XG4gIH0pO1xuXG4gIGl0KCdhIGNsZWFuIHJ1biBzYXlzIFwiTm8gcHJvYmxlbXNcIiDigJQgYW5kIG5hbWVzIHRoZSBzY29wZSBhbmQgZmlsZSBjb3VudCBpdCBjaGVja2VkJywgYXN5bmMgKCkgPT4ge1xuICAgIHNldHVwKCk7XG4gICAgY29uc3QgY2xlYW4gPSAoYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoL25vIHByb2JsZW1zL2kpKS5jbG9zZXN0KCdwJykhO1xuICAgIGV4cGVjdChjbGVhbikudG9IYXZlQXR0cmlidXRlKCdkYXRhLWNsZWFuJywgJ3RydWUnKTtcbiAgICBleHBlY3QoY2xlYW4udGV4dENvbnRlbnQpLnRvTWF0Y2goL2NoYW5nZWQgZmlsZXMgXFwrIGltcG9ydHMvaSk7XG4gICAgZXhwZWN0KGNsZWFuLnRleHRDb250ZW50KS50b01hdGNoKC8zIGZpbGVzIGNoZWNrZWQvaSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZSgnbm90ZScpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoJ0ctVE9PTC01YiDigJQgYSByZWxhdGl2ZSBjb3ZlcmFnZSBub3RlIG1ha2VzIHRoZSBydW4gcGFydGlhbDogdGhlIGJhbm5lciBuYW1lcyBpdCBhbmQgXCJObyBwcm9ibGVtc1wiIG5ldmVyIHJlbmRlcnMnLCBhc3luYyAoKSA9PiB7XG4gICAgc2V0dXAoe1xuICAgICAgdHlwZWNoZWNrOiB7IGRpYWdub3N0aWNzOiBbeyBwYXRoOiAnL3NyYy91c2UudHMnLCBzdGFydDogMjIsIGxlbmd0aDogNywgY2F0ZWdvcnk6ICdtZXNzYWdlJywgY29kZTogMjMwNywgbWVzc2FnZVRleHQ6IFJFTEFUSVZFX05PVEUgfV0sIHRydW5jYXRlZDogZmFsc2UsIHRvdGFsOiAxIH0sXG4gICAgfSk7XG4gICAgY29uc3QgYmFubmVyID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoJ25vdGUnLCB7IG5hbWU6IC9wYXJ0aWFsL2kgfSk7XG4gICAgZXhwZWN0KGJhbm5lci50ZXh0Q29udGVudCkudG9NYXRjaCgvMSBpbXBvcnQgd2FzIG5vdCBjaGVja2VkLyk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dCgvbm8gcHJvYmxlbXMvaSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KC9ub3RoaW5nIGZvdW5kIGluIHRoZSBmaWxlcyB0aGF0IHdlcmUgY2hlY2tlZC9pKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZSgnc3RhdHVzJykudGV4dENvbnRlbnQpLnRvTWF0Y2goL3BhcnRpYWwvKTtcbiAgfSk7XG5cbiAgaXQoJ0ctVE9PTC01IOKAlCBpbnB1dCB0cnVuY2F0aW9uIG5hbWVzIHRoZSBkcm9wcGVkIGNvdW50IGFuZCBtYXJrcyB0aGUgcnVuIHBhcnRpYWwnLCBhc3luYyAoKSA9PiB7XG4gICAgc2V0dXAoeyB0eXBlY2hlY2s6IHsgZGlhZ25vc3RpY3M6IFtdLCB0cnVuY2F0ZWQ6IHRydWUsIHRvdGFsOiAyNDAgfSB9KTtcbiAgICBjb25zdCBiYW5uZXIgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZSgnbm90ZScsIHsgbmFtZTogL3BhcnRpYWwvaSB9KTtcbiAgICBleHBlY3QoYmFubmVyLnRleHRDb250ZW50KS50b01hdGNoKC8yNDAgZGlhZ25vc3RpY3MgXFwoc2VydmljZSBjYXBcXCkvKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KC9ubyBwcm9ibGVtcy9pKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KCdHLVRPT0wtNiDigJQgYSB3cml0ZSB0byBhIGNvdmVyZWQgZmlsZSBtYXJrcyB0aGUgcnVuIHN0YWxlOiBsYWJlbGxlZCwgZGltbWVkLCBhbmQgXCJObyBwcm9ibGVtc1wiIHdpdGhkcmF3bicsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSBuZXcgU2V0PChwOiBzdHJpbmdbXSkgPT4gdm9pZD4oKTtcbiAgICBjb25zdCBzdGFsZW5lc3M6IFN0YWxlbmVzc1BvcnRzID0geyB3YXRjaDogKGNiKSA9PiAobGlzdGVuZXJzLmFkZChjYiksICgpID0+IGxpc3RlbmVycy5kZWxldGUoY2IpKSwgcmVmcmVzaERpZmY6IGFzeW5jICgpID0+IHt9IH07XG4gICAgc2V0dXAoe30sIHsgc3RhbGVuZXNzIH0pO1xuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dCgvbm8gcHJvYmxlbXMvaSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QobGlzdGVuZXJzLnNpemUpLnRvQmUoMSkpOyAvLyB0aGUgcnVuIGNvbW1pdHRlZCBhbmQgdGhlIHdhdGNoZXIgaXMgb25cbiAgICBhY3QoKCkgPT4gbGlzdGVuZXJzLmZvckVhY2goKGwpID0+IGwoWydzcmMvbGliLnRzJ10pKSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KC9vdXQgb2YgZGF0ZS9pKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KC9ubyBwcm9ibGVtcy9pKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KCdhIGJ1aWxkIGVycm9yIGFsb25lIChubyBydW4geWV0KSBzdGlsbCBzaG93cywgbGl2ZScsICgpID0+IHtcbiAgICBzZXR1cCh7fSwgeyBhdXRvUnVuOiBmYWxzZSwgYnVpbGRFcnJvcnM6IFt7IG1lc3NhZ2U6ICdSZWZlcmVuY2VFcnJvcjogeCBpcyBub3QgZGVmaW5lZCcgfV0gfSk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoL25vdCBmaWxlLWxvY2F0ZWQvaSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoJ29wdGlvbicpLnRleHRDb250ZW50KS50b0NvbnRhaW4oJ1JlZmVyZW5jZUVycm9yJyk7XG4gIH0pO1xuXG4gIGl0KCdhIGZhaWxlZCBvcGVuIGlzIHJlcG9ydGVkLCBub3Qgc3dhbGxvd2VkJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCBvbk9wZW4gPSB2aS5mbjwoZDogRGlhZ25vc3RpYykgPT4gUHJvbWlzZTx2b2lkPj4oKS5tb2NrUmVqZWN0ZWRWYWx1ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcignZ29uZScpLCB7IGNvZGU6ICdub3QtZm91bmQnIH0pKTtcbiAgICByZW5kZXIoPEhhcm5lc3MgcD17cG9ydHMoVFlQSUNBTCl9IG9uT3Blbj17b25PcGVufSAvPik7XG4gICAgY29uc3QgbGlzdCA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKCdsaXN0Ym94Jyk7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obGlzdCkuZ2V0QWxsQnlSb2xlKCdvcHRpb24nKVswXSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKCdhbGVydCcpKS50b0hhdmVUZXh0Q29udGVudCgvbm8gbG9uZ2VyIGluIHRoZSB3b3JraW5nIHRyZWUvaSk7XG4gIH0pO1xuXG4gIGl0KCd3aXRob3V0IGEgd29ya2luZyB0cmVlIGl0IHNheXMgc28gaW5zdGVhZCBvZiBydW5uaW5nJywgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyBwPXtudWxsfSBvbk9wZW49e3ZpLmZuKCl9IC8+KTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dCgvbm8gd29ya2luZyB0cmVlIGhlcmUvaSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogL3J1bi9pIH0pKS50b0JlRGlzYWJsZWQoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFJQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFJQSxJQUFBSSxnQkFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssY0FBQSxHQUFBSCxzQkFBQSxDQUFBRixPQUFBO0FBQTRDLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQVg1QztBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFOLHVCQUFBTyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBVUEsTUFBTUcsYUFBYSxHQUFHLHVJQUF1STtBQUM3SixNQUFNQyxZQUFZLEdBQUcsbUtBQW1LO0FBRXhMLE1BQU1DLEtBQTZCLEdBQUc7RUFDcEMsWUFBWSxFQUFFLDZEQUE2RDtFQUMzRSxZQUFZLEVBQUUsK0NBQStDO0VBQzdELHVCQUF1QixFQUFFO0FBQzNCLENBQUM7QUFFRCxTQUFTQyxLQUFLQSxDQUFDQyxPQUFnRCxHQUFHLENBQUMsQ0FBQyxFQUFZO0VBQzlFLE9BQU87SUFDTEMsUUFBUSxFQUFFLE1BQU9DLENBQUMsSUFBSztNQUNyQixJQUFJQSxDQUFDLElBQUlKLEtBQUssRUFBRSxPQUFPQSxLQUFLLENBQUNJLENBQUMsQ0FBQztNQUMvQixNQUFNLElBQUlDLEtBQUssQ0FBQyxRQUFRLENBQUM7SUFDM0IsQ0FBQztJQUNEQyxlQUFlLEVBQUUsTUFBQUEsQ0FBQSxLQUFZQyxNQUFNLENBQUNDLElBQUksQ0FBQ1IsS0FBSyxDQUFDO0lBQy9DUyxZQUFZLEVBQUVBLENBQUEsS0FBTSxDQUFDLFlBQVksRUFBRSx1QkFBdUIsQ0FBQztJQUMzREMsU0FBUyxFQUFFQSxDQUFBLEtBQU0sRUFBRTtJQUNuQkMsTUFBTSxFQUFFLE1BQVdDLElBQVksSUFBaUI7TUFDOUMsSUFBSUEsSUFBSSxLQUFLLHFCQUFxQixFQUFFLE9BQVFWLE9BQU8sQ0FBQ1csU0FBUyxJQUFJO1FBQUVDLFdBQVcsRUFBRSxFQUFFO1FBQUVDLFNBQVMsRUFBRSxLQUFLO1FBQUVDLEtBQUssRUFBRTtNQUFFLENBQUM7TUFDaEgsT0FBUWQsT0FBTyxDQUFDZSxJQUFJLElBQUk7UUFBRUgsV0FBVyxFQUFFLEVBQUU7UUFBRUMsU0FBUyxFQUFFLEtBQUs7UUFBRUMsS0FBSyxFQUFFLENBQUM7UUFBRUUsT0FBTyxFQUFFO01BQUcsQ0FBQztJQUN0RjtFQUNGLENBQUM7QUFDSDtBQUVBLE1BQU1DLE9BQU8sR0FBRztFQUNkTixTQUFTLEVBQUU7SUFDVEMsV0FBVyxFQUFFLENBQ1g7TUFBRU0sSUFBSSxFQUFFLGFBQWE7TUFBRUMsS0FBSyxFQUFFLEVBQUU7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsUUFBUSxFQUFFLE9BQU87TUFBRUMsSUFBSSxFQUFFLElBQUk7TUFBRUMsV0FBVyxFQUFFO0lBQTZFLENBQUMsRUFDdks7TUFBRUwsSUFBSSxFQUFFLHdCQUF3QjtNQUFFQyxLQUFLLEVBQUUsQ0FBQztNQUFFQyxNQUFNLEVBQUUsQ0FBQztNQUFFQyxRQUFRLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUUsSUFBSTtNQUFFQyxXQUFXLEVBQUU7SUFBcUQsQ0FBQyxFQUN6SjtNQUFFTCxJQUFJLEVBQUUsYUFBYTtNQUFFQyxLQUFLLEVBQUUsRUFBRTtNQUFFQyxNQUFNLEVBQUUsQ0FBQztNQUFFQyxRQUFRLEVBQUUsU0FBUztNQUFFQyxJQUFJLEVBQUUsSUFBSTtNQUFFQyxXQUFXLEVBQUUxQjtJQUFhLENBQUMsQ0FDMUc7SUFDRGdCLFNBQVMsRUFBRSxLQUFLO0lBQ2hCQyxLQUFLLEVBQUU7RUFDVCxDQUFDO0VBQ0RDLElBQUksRUFBRTtJQUNKSCxXQUFXLEVBQUUsQ0FBQztNQUFFTSxJQUFJLEVBQUUsd0JBQXdCO01BQUVNLElBQUksRUFBRSxDQUFDO01BQUVDLE1BQU0sRUFBRSxDQUFDO01BQUVDLE1BQU0sRUFBRSxjQUFjO01BQUVDLFFBQVEsRUFBRSxTQUFTO01BQUVKLFdBQVcsRUFBRTtJQUFxRCxDQUFDLENBQUM7SUFDckxWLFNBQVMsRUFBRSxLQUFLO0lBQ2hCQyxLQUFLLEVBQUUsQ0FBQztJQUNSRSxPQUFPLEVBQUU7RUFDWDtBQUNGLENBQUM7QUFFRCxTQUFTWSxPQUFPQSxDQUFDO0VBQ2YxQixDQUFDO0VBQ0QyQixNQUFNO0VBQ05DLFdBQVcsR0FBRyxFQUFFO0VBQ2hCQyxPQUFPLEdBQUcsSUFBSTtFQUNkQyxTQUFTLEdBQUc7QUFPZCxDQUFDLEVBQUU7RUFBQXpDLEVBQUE7RUFDRCxNQUFNMEMsT0FBTyxHQUFHLElBQUFDLGdDQUFlLEVBQUM7SUFBRW5DLEtBQUssRUFBRUcsQ0FBQztJQUFFNkIsT0FBTztJQUFFQyxTQUFTO0lBQUVHLGVBQWUsRUFBRTtFQUFFLENBQUMsQ0FBQztFQUNyRixvQkFBTyxJQUFBN0MsV0FBQSxDQUFBOEMsR0FBQSxFQUFDL0MsY0FBQSxDQUFBTSxPQUFhO0lBQUNzQyxPQUFPLEVBQUVBLE9BQVE7SUFBQ0gsV0FBVyxFQUFFQSxXQUFZO0lBQUNELE1BQU0sRUFBRUE7RUFBTyxDQUFFLENBQUM7QUFDdEY7QUFBQ3RDLEVBQUEsQ0FmUXFDLE9BQU87RUFBQSxRQWFFTSxnQ0FBZTtBQUFBO0FBQUFHLEVBQUEsR0FieEJULE9BQU87QUFpQmhCLE1BQU1VLEtBQUssR0FBR0EsQ0FBQ3RDLE9BQXFDLEVBQUV1QyxLQUFvRCxHQUFHLENBQUMsQ0FBQyxLQUFLO0VBQ2xILE1BQU1WLE1BQU0sR0FBR1csVUFBRSxDQUFDQyxFQUFFLENBQW1DLENBQUMsQ0FBQ0MsaUJBQWlCLENBQUNDLFNBQVMsQ0FBQztFQUNyRixNQUFNQyxLQUFLLEdBQUcsSUFBQUMsYUFBTSxlQUFDLElBQUF2RCxXQUFBLENBQUE4QyxHQUFBLEVBQUNSLE9BQU87SUFBQzFCLENBQUMsRUFBRUgsS0FBSyxDQUFDQyxPQUFPLENBQUU7SUFBQzZCLE1BQU0sRUFBRUEsTUFBTztJQUFBLEdBQUtVO0VBQUssQ0FBRyxDQUFDLENBQUM7RUFDL0UsT0FBTztJQUFFVixNQUFNO0lBQUUsR0FBR2U7RUFBTSxDQUFDO0FBQzdCLENBQUM7QUFFRCxJQUFBRSxnQkFBUSxFQUFDLGVBQWUsRUFBRSxNQUFNO0VBQzlCLElBQUFDLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGVCxLQUFLLENBQUNyQixPQUFPLEVBQUU7TUFBRWEsV0FBVyxFQUFFLENBQUM7UUFBRWtCLE9BQU8sRUFBRSxrQkFBa0I7UUFBRTlCLElBQUksRUFBRSxjQUFjO1FBQUVNLElBQUksRUFBRSxFQUFFO1FBQUVDLE1BQU0sRUFBRTtNQUFHLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDOUcsTUFBTXdCLElBQUksR0FBRyxNQUFNQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxTQUFTLEVBQUU7TUFBRXpDLElBQUksRUFBRTtJQUFvQixDQUFDLENBQUM7SUFDOUUsTUFBTTBDLE1BQU0sR0FBRyxJQUFBQyxhQUFNLEVBQUNKLElBQUksQ0FBQyxDQUFDSyxZQUFZLENBQUMsT0FBTyxDQUFDO0lBQ2pEO0lBQ0E7SUFDQSxJQUFBQyxjQUFNLEVBQUNILE1BQU0sQ0FBQ0ksR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsYUFBYSxDQUFDLFNBQVMsQ0FBQyxFQUFFQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxjQUFjLEVBQUUsd0JBQXdCLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDckksSUFBQUwsY0FBTSxFQUFDLElBQUFGLGFBQU0sRUFBQ0QsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNTLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0YsV0FBVyxDQUFDLENBQUNHLFNBQVMsQ0FBQyxPQUFPLENBQUM7SUFDNUUsSUFBQVAsY0FBTSxFQUFDLElBQUFGLGFBQU0sRUFBQ0QsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNTLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0YsV0FBVyxDQUFDLENBQUNHLFNBQVMsQ0FBQyxPQUFPLENBQUM7SUFDNUUsTUFBTUMsUUFBUSxHQUFHLElBQUFWLGFBQU0sRUFBQ0QsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLFlBQVksQ0FBQyxRQUFRLENBQUM7SUFDekQsSUFBQUMsY0FBTSxFQUFDUSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUNKLFdBQVcsQ0FBQyxDQUFDRyxTQUFTLENBQUMsY0FBYyxDQUFDO0lBQ3pELElBQUFQLGNBQU0sRUFBQ1EsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDSixXQUFXLENBQUMsQ0FBQ0csU0FBUyxDQUFDLEtBQUssQ0FBQztJQUNoRCxJQUFBUCxjQUFNLEVBQUNRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQ0osV0FBVyxDQUFDLENBQUNHLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQztJQUNsRSxJQUFBUCxjQUFNLEVBQUMsSUFBQUYsYUFBTSxFQUFDRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ1MsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDRixXQUFXLENBQUMsQ0FBQ0csU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUM3RSxDQUFDLENBQUM7RUFFRixJQUFBZixVQUFFLEVBQUMsMEZBQTBGLEVBQUUsWUFBWTtJQUN6RyxNQUFNaUIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDM0IsS0FBSyxDQUFDLENBQUM7SUFDOUJBLEtBQUssQ0FBQ3JCLE9BQU8sQ0FBQztJQUNkLE1BQU1pQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxTQUFTLENBQUM7SUFDbEMsTUFBTWUsS0FBSyxHQUFHaEIsYUFBTSxDQUFDVyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUVuRCxJQUFJLEVBQUU7SUFBc0IsQ0FBQyxDQUFDO0lBQ3hFLElBQUE2QyxjQUFNLEVBQUMsSUFBQUYsYUFBTSxFQUFDYSxLQUFLLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFbkQsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQ3lELGVBQWUsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDO0lBQ3hHLElBQUFaLGNBQU0sRUFBQyxJQUFBRixhQUFNLEVBQUNhLEtBQUssQ0FBQyxDQUFDTCxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVuRCxJQUFJLEVBQUU7SUFBYyxDQUFDLENBQUMsQ0FBQyxDQUFDeUQsZUFBZSxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUM7SUFDMUcsTUFBTUMsS0FBSyxHQUFHLElBQUFmLGFBQU0sRUFBQ2EsS0FBSyxDQUFDLENBQUNMLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRW5ELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUNyRSxJQUFBNkMsY0FBTSxFQUFDYSxLQUFLLENBQUMsQ0FBQ0QsZUFBZSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUM7SUFDdEQsSUFBQVosY0FBTSxFQUFDTCxhQUFNLENBQUNtQixXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ25FLE1BQU1QLElBQUksQ0FBQ1EsS0FBSyxDQUFDSixLQUFLLENBQUM7SUFDdkIsSUFBQWIsY0FBTSxFQUFDTCxhQUFNLENBQUN1QixTQUFTLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDRixpQkFBaUIsQ0FBQyxDQUFDO0lBQy9ELE1BQU1QLElBQUksQ0FBQ1EsS0FBSyxDQUFDLElBQUFuQixhQUFNLEVBQUNhLEtBQUssQ0FBQyxDQUFDTCxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVuRCxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQztJQUMxRSxJQUFBNkMsY0FBTSxFQUFDTCxhQUFNLENBQUNtQixXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzVELElBQUFoQixjQUFNLEVBQUMsSUFBQUYsYUFBTSxFQUFDYSxLQUFLLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFbkQsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQ3lELGVBQWUsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDO0VBQzNHLENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMsaURBQWlELEVBQUUsWUFBWTtJQUNoRSxNQUFNaUIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDM0IsS0FBSyxDQUFDLENBQUM7SUFDOUJBLEtBQUssQ0FBQ3JCLE9BQU8sQ0FBQztJQUNkLE1BQU1pQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxTQUFTLENBQUM7SUFDbEMsTUFBTWEsSUFBSSxDQUFDVSxJQUFJLENBQUN4QixhQUFNLENBQUNXLFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRW5ELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsRUFBRSxVQUFVLENBQUM7SUFDdEYsSUFBQTZDLGNBQU0sRUFBQ0wsYUFBTSxDQUFDSSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ3FCLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDckQsTUFBTVgsSUFBSSxDQUFDWSxLQUFLLENBQUMxQixhQUFNLENBQUNXLFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRW5ELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsQ0FBQztJQUMzRSxNQUFNc0QsSUFBSSxDQUFDVSxJQUFJLENBQUN4QixhQUFNLENBQUNXLFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRW5ELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsRUFBRSxhQUFhLENBQUM7SUFDekYsSUFBQTZDLGNBQU0sRUFBQ0wsYUFBTSxDQUFDMkIsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNGLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDdkQsSUFBQXBCLGNBQU0sRUFBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQ0YsaUJBQWlCLENBQUMsQ0FBQztFQUNsRSxDQUFDLENBQUM7RUFFRixJQUFBeEIsVUFBRSxFQUFDLDhFQUE4RSxFQUFFLFlBQVk7SUFDN0YsTUFBTWlCLElBQUksR0FBR0Msa0JBQVMsQ0FBQzNCLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU07TUFBRVQ7SUFBTyxDQUFDLEdBQUdTLEtBQUssQ0FBQ3JCLE9BQU8sQ0FBQztJQUNqQyxNQUFNZ0MsSUFBSSxHQUFHLE1BQU1DLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFNBQVMsQ0FBQztJQUMvQyxNQUFNYSxJQUFJLENBQUNRLEtBQUssQ0FBQyxJQUFBbkIsYUFBTSxFQUFDSixJQUFJLENBQUMsQ0FBQ3dCLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLFFBQVEsQ0FBRSxDQUFDO0lBQ3JFLElBQUF2QixjQUFNLEVBQUMxQixNQUFNLENBQUMsQ0FBQ2tELHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUN2QyxJQUFBeEIsY0FBTSxFQUFDMUIsTUFBTSxDQUFDbUQsSUFBSSxDQUFDQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsYUFBYSxDQUFDO01BQUVDLE1BQU0sRUFBRSxLQUFLO01BQUVqRSxJQUFJLEVBQUUsWUFBWTtNQUFFTSxJQUFJLEVBQUUsQ0FBQztNQUFFQyxNQUFNLEVBQUU7SUFBRyxDQUFDLENBQUM7RUFDM0csQ0FBQyxDQUFDO0VBRUYsSUFBQXNCLFVBQUUsRUFBQyxrREFBa0QsRUFBRSxZQUFZO0lBQ2pFLE1BQU1pQixJQUFJLEdBQUdDLGtCQUFTLENBQUMzQixLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNO01BQUVUO0lBQU8sQ0FBQyxHQUFHUyxLQUFLLENBQUNyQixPQUFPLENBQUM7SUFDakMsTUFBTWdDLElBQUksR0FBRyxNQUFNQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxTQUFTLENBQUM7SUFDL0MsTUFBTWlDLElBQUksR0FBRyxJQUFBL0IsYUFBTSxFQUFDSixJQUFJLENBQUMsQ0FBQ0ssWUFBWSxDQUFDLFFBQVEsQ0FBQztJQUNoRDhCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDZixNQUFNckIsSUFBSSxDQUFDc0IsUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUNsQyxJQUFBL0IsY0FBTSxFQUFDNkIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNHLFdBQVcsQ0FBQyxDQUFDO0lBQzdCLElBQUFoQyxjQUFNLEVBQUM2QixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ2pCLGVBQWUsQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDO0lBQ3hELE1BQU1ILElBQUksQ0FBQ3NCLFFBQVEsQ0FBQyxTQUFTLENBQUM7SUFDOUIsSUFBQS9CLGNBQU0sRUFBQzFCLE1BQU0sQ0FBQyxDQUFDa0QscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLElBQUF4QixjQUFNLEVBQUMxQixNQUFNLENBQUNtRCxJQUFJLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ08sRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQ0wsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDTSxPQUFPLENBQUNGLEVBQUUsQ0FBQztJQUMzRCxNQUFNeEIsSUFBSSxDQUFDc0IsUUFBUSxDQUFDLE9BQU8sQ0FBQztJQUM1QixJQUFBL0IsY0FBTSxFQUFDNkIsSUFBSSxDQUFDQSxJQUFJLENBQUNoRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ21FLFdBQVcsQ0FBQyxDQUFDO0VBQzdDLENBQUMsQ0FBQztFQUVGLElBQUF4QyxVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsWUFBWTtJQUMvRlQsS0FBSyxDQUFDLENBQUM7SUFDUCxNQUFNcUQsS0FBSyxHQUFHLENBQUMsTUFBTXpDLGFBQU0sQ0FBQzBDLFVBQVUsQ0FBQyxjQUFjLENBQUMsRUFBRWQsT0FBTyxDQUFDLEdBQUcsQ0FBRTtJQUNyRSxJQUFBdkIsY0FBTSxFQUFDb0MsS0FBSyxDQUFDLENBQUN4QixlQUFlLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQztJQUNuRCxJQUFBWixjQUFNLEVBQUNvQyxLQUFLLENBQUNoQyxXQUFXLENBQUMsQ0FBQ2tDLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQztJQUM5RCxJQUFBdEMsY0FBTSxFQUFDb0MsS0FBSyxDQUFDaEMsV0FBVyxDQUFDLENBQUNrQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7SUFDckQsSUFBQXRDLGNBQU0sRUFBQ0wsYUFBTSxDQUFDNEMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUN4QixHQUFHLENBQUNDLGlCQUFpQixDQUFDLENBQUM7RUFDNUQsQ0FBQyxDQUFDO0VBRUYsSUFBQXhCLFVBQUUsRUFBQyxpSEFBaUgsRUFBRSxZQUFZO0lBQ2hJVCxLQUFLLENBQUM7TUFDSjNCLFNBQVMsRUFBRTtRQUFFQyxXQUFXLEVBQUUsQ0FBQztVQUFFTSxJQUFJLEVBQUUsYUFBYTtVQUFFQyxLQUFLLEVBQUUsRUFBRTtVQUFFQyxNQUFNLEVBQUUsQ0FBQztVQUFFQyxRQUFRLEVBQUUsU0FBUztVQUFFQyxJQUFJLEVBQUUsSUFBSTtVQUFFQyxXQUFXLEVBQUUzQjtRQUFjLENBQUMsQ0FBQztRQUFFaUIsU0FBUyxFQUFFLEtBQUs7UUFBRUMsS0FBSyxFQUFFO01BQUU7SUFDckssQ0FBQyxDQUFDO0lBQ0YsTUFBTWlGLE1BQU0sR0FBRyxNQUFNN0MsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxFQUFFO01BQUV6QyxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFDcEUsSUFBQTZDLGNBQU0sRUFBQ3dDLE1BQU0sQ0FBQ3BDLFdBQVcsQ0FBQyxDQUFDa0MsT0FBTyxDQUFDLDBCQUEwQixDQUFDO0lBQzlELElBQUF0QyxjQUFNLEVBQUNMLGFBQU0sQ0FBQ21CLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNDLGlCQUFpQixDQUFDLENBQUM7SUFDbEUsSUFBQWhCLGNBQU0sRUFBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLCtDQUErQyxDQUFDLENBQUMsQ0FBQ0YsaUJBQWlCLENBQUMsQ0FBQztJQUM3RixJQUFBaEIsY0FBTSxFQUFDTCxhQUFNLENBQUNXLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0YsV0FBVyxDQUFDLENBQUNrQyxPQUFPLENBQUMsU0FBUyxDQUFDO0VBQ25FLENBQUMsQ0FBQztFQUVGLElBQUE5QyxVQUFFLEVBQUMsK0VBQStFLEVBQUUsWUFBWTtJQUM5RlQsS0FBSyxDQUFDO01BQUUzQixTQUFTLEVBQUU7UUFBRUMsV0FBVyxFQUFFLEVBQUU7UUFBRUMsU0FBUyxFQUFFLElBQUk7UUFBRUMsS0FBSyxFQUFFO01BQUk7SUFBRSxDQUFDLENBQUM7SUFDdEUsTUFBTWlGLE1BQU0sR0FBRyxNQUFNN0MsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxFQUFFO01BQUV6QyxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFDcEUsSUFBQTZDLGNBQU0sRUFBQ3dDLE1BQU0sQ0FBQ3BDLFdBQVcsQ0FBQyxDQUFDa0MsT0FBTyxDQUFDLGlDQUFpQyxDQUFDO0lBQ3JFLElBQUF0QyxjQUFNLEVBQUNMLGFBQU0sQ0FBQ21CLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNDLGlCQUFpQixDQUFDLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0VBRUYsSUFBQXhCLFVBQUUsRUFBQyx5R0FBeUcsRUFBRSxZQUFZO0lBQ3hILE1BQU1pRCxTQUFTLEdBQUcsSUFBSUMsR0FBRyxDQUF3QixDQUFDO0lBQ2xELE1BQU1qRSxTQUF5QixHQUFHO01BQUVrRSxLQUFLLEVBQUdDLEVBQUUsS0FBTUgsU0FBUyxDQUFDSSxHQUFHLENBQUNELEVBQUUsQ0FBQyxFQUFFLE1BQU1ILFNBQVMsQ0FBQ0ssTUFBTSxDQUFDRixFQUFFLENBQUMsQ0FBQztNQUFFRyxXQUFXLEVBQUUsTUFBQUEsQ0FBQSxLQUFZLENBQUM7SUFBRSxDQUFDO0lBQ2pJaEUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQUVOO0lBQVUsQ0FBQyxDQUFDO0lBQ3hCLElBQUF1QixjQUFNLEVBQUMsTUFBTUwsYUFBTSxDQUFDMEMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNyQixpQkFBaUIsQ0FBQyxDQUFDO0lBQ25FLE1BQU0sSUFBQWdDLGNBQU8sRUFBQyxNQUFNLElBQUFoRCxjQUFNLEVBQUN5QyxTQUFTLENBQUNRLElBQUksQ0FBQyxDQUFDZixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3JELElBQUFnQixVQUFHLEVBQUMsTUFBTVQsU0FBUyxDQUFDVSxPQUFPLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RELElBQUFwRCxjQUFNLEVBQUMsTUFBTUwsYUFBTSxDQUFDMEMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNyQixpQkFBaUIsQ0FBQyxDQUFDO0lBQ25FLElBQUFoQixjQUFNLEVBQUNMLGFBQU0sQ0FBQ21CLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUNDLGlCQUFpQixDQUFDLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0VBRUYsSUFBQXhCLFVBQUUsRUFBQyxvREFBb0QsRUFBRSxNQUFNO0lBQzdEVCxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFBRVAsT0FBTyxFQUFFLEtBQUs7TUFBRUQsV0FBVyxFQUFFLENBQUM7UUFBRWtCLE9BQU8sRUFBRTtNQUFtQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzdGLElBQUFPLGNBQU0sRUFBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ0YsaUJBQWlCLENBQUMsQ0FBQztJQUNqRSxJQUFBaEIsY0FBTSxFQUFDTCxhQUFNLENBQUNXLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0YsV0FBVyxDQUFDLENBQUNHLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztFQUM1RSxDQUFDLENBQUM7RUFFRixJQUFBZixVQUFFLEVBQUMsMENBQTBDLEVBQUUsWUFBWTtJQUN6RCxNQUFNaUIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDM0IsS0FBSyxDQUFDLENBQUM7SUFDOUIsTUFBTVQsTUFBTSxHQUFHVyxVQUFFLENBQUNDLEVBQUUsQ0FBbUMsQ0FBQyxDQUFDbUUsaUJBQWlCLENBQUN2RyxNQUFNLENBQUN3RyxNQUFNLENBQUMsSUFBSTFHLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtNQUFFbUIsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUM7SUFDbkksSUFBQXVCLGFBQU0sZUFBQyxJQUFBdkQsV0FBQSxDQUFBOEMsR0FBQSxFQUFDUixPQUFPO01BQUMxQixDQUFDLEVBQUVILEtBQUssQ0FBQ2tCLE9BQU8sQ0FBRTtNQUFDWSxNQUFNLEVBQUVBO0lBQU8sQ0FBRSxDQUFDLENBQUM7SUFDdEQsTUFBTW9CLElBQUksR0FBRyxNQUFNQyxhQUFNLENBQUNDLFVBQVUsQ0FBQyxTQUFTLENBQUM7SUFDL0MsTUFBTWEsSUFBSSxDQUFDUSxLQUFLLENBQUMsSUFBQW5CLGFBQU0sRUFBQ0osSUFBSSxDQUFDLENBQUNLLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4RCxJQUFBQyxjQUFNLEVBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzJELGlCQUFpQixDQUFDLGdDQUFnQyxDQUFDO0VBQzlGLENBQUMsQ0FBQztFQUVGLElBQUEvRCxVQUFFLEVBQUMsc0RBQXNELEVBQUUsTUFBTTtJQUMvRCxJQUFBRixhQUFNLGVBQUMsSUFBQXZELFdBQUEsQ0FBQThDLEdBQUEsRUFBQ1IsT0FBTztNQUFDMUIsQ0FBQyxFQUFFLElBQUs7TUFBQzJCLE1BQU0sRUFBRVcsVUFBRSxDQUFDQyxFQUFFLENBQUM7SUFBRSxDQUFFLENBQUMsQ0FBQztJQUM3QyxJQUFBYyxjQUFNLEVBQUNMLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUNGLGlCQUFpQixDQUFDLENBQUM7SUFDckUsSUFBQWhCLGNBQU0sRUFBQ0wsYUFBTSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVuRCxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQyxDQUFDcUcsWUFBWSxDQUFDLENBQUM7RUFDckUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQUMsSUFBQTFFLEVBQUE7QUFBQTJFLFlBQUEsQ0FBQTNFLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}