var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = StaleBanner;
var _Icons = require("./Icons");
var _jsxRuntime = require("react/jsx-runtime");
// The stale label (§7.3, G-TOOL-6): a run whose covered paths were written stays on
// screen, dimmed, and says so — never presented as current, never silently dropped.

function StaleBanner({
  stale,
  onRerun,
  running
}) {
  if (stale.length === 0) return null;
  const n = stale.length;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
    className: "stale",
    role: "status",
    "data-stale": "true",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icons.ClockIcon, {}), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
        children: "Out of date."
      }), " ", n, " ", n === 1 ? 'file' : 'files', " changed since this run", n <= 3 ? ` (${stale.join(', ')})` : '', ".", /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        onClick: onRerun,
        disabled: running,
        children: "Run again"
      })]
    })]
  });
}
_c = StaleBanner;
var _c;
$RefreshReg$(_c, "StaleBanner");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfSWNvbnMiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJTdGFsZUJhbm5lciIsInN0YWxlIiwib25SZXJ1biIsInJ1bm5pbmciLCJsZW5ndGgiLCJuIiwianN4cyIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsImpzeCIsIkNsb2NrSWNvbiIsImpvaW4iLCJ0eXBlIiwib25DbGljayIsImRpc2FibGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTdGFsZUJhbm5lci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHN0YWxlIGxhYmVsICjCpzcuMywgRy1UT09MLTYpOiBhIHJ1biB3aG9zZSBjb3ZlcmVkIHBhdGhzIHdlcmUgd3JpdHRlbiBzdGF5cyBvblxuLy8gc2NyZWVuLCBkaW1tZWQsIGFuZCBzYXlzIHNvIOKAlCBuZXZlciBwcmVzZW50ZWQgYXMgY3VycmVudCwgbmV2ZXIgc2lsZW50bHkgZHJvcHBlZC5cbmltcG9ydCB7IENsb2NrSWNvbiB9IGZyb20gJy4vSWNvbnMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdGFsZUJhbm5lcih7IHN0YWxlLCBvblJlcnVuLCBydW5uaW5nIH06IHsgc3RhbGU6IHJlYWRvbmx5IHN0cmluZ1tdOyBvblJlcnVuOiAoKSA9PiB2b2lkOyBydW5uaW5nOiBib29sZWFuIH0pIHtcbiAgaWYgKHN0YWxlLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBzdGFsZS5sZW5ndGg7XG4gIHJldHVybiAoXG4gICAgPHAgY2xhc3NOYW1lPVwic3RhbGVcIiByb2xlPVwic3RhdHVzXCIgZGF0YS1zdGFsZT1cInRydWVcIj5cbiAgICAgIDxDbG9ja0ljb24gLz5cbiAgICAgIDxzcGFuPlxuICAgICAgICA8Yj5PdXQgb2YgZGF0ZS48L2I+IHtufSB7biA9PT0gMSA/ICdmaWxlJyA6ICdmaWxlcyd9IGNoYW5nZWQgc2luY2UgdGhpcyBydW5cbiAgICAgICAge24gPD0gMyA/IGAgKCR7c3RhbGUuam9pbignLCAnKX0pYCA6ICcnfS5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25SZXJ1bn0gZGlzYWJsZWQ9e3J1bm5pbmd9PlxuICAgICAgICAgIFJ1biBhZ2FpblxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvc3Bhbj5cbiAgICA8L3A+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUFvQyxJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGcEM7QUFDQTs7QUFHZSxTQUFTRSxXQUFXQSxDQUFDO0VBQUVDLEtBQUs7RUFBRUMsT0FBTztFQUFFQztBQUE2RSxDQUFDLEVBQUU7RUFDcEksSUFBSUYsS0FBSyxDQUFDRyxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUNuQyxNQUFNQyxDQUFDLEdBQUdKLEtBQUssQ0FBQ0csTUFBTTtFQUN0QixvQkFDRSxJQUFBTCxXQUFBLENBQUFPLElBQUE7SUFBR0MsU0FBUyxFQUFDLE9BQU87SUFBQ0MsSUFBSSxFQUFDLFFBQVE7SUFBQyxjQUFXLE1BQU07SUFBQUMsUUFBQSxnQkFDbEQsSUFBQVYsV0FBQSxDQUFBVyxHQUFBLEVBQUNiLE1BQUEsQ0FBQWMsU0FBUyxJQUFFLENBQUMsZUFDYixJQUFBWixXQUFBLENBQUFPLElBQUE7TUFBQUcsUUFBQSxnQkFDRSxJQUFBVixXQUFBLENBQUFXLEdBQUE7UUFBQUQsUUFBQSxFQUFHO01BQVksQ0FBRyxDQUFDLEtBQUMsRUFBQ0osQ0FBQyxFQUFDLEdBQUMsRUFBQ0EsQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLEdBQUcsT0FBTyxFQUFDLHlCQUNwRCxFQUFDQSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUtKLEtBQUssQ0FBQ1csSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxFQUFDLEdBQ3hDLG1CQUFBYixXQUFBLENBQUFXLEdBQUE7UUFBUUcsSUFBSSxFQUFDLFFBQVE7UUFBQ0MsT0FBTyxFQUFFWixPQUFRO1FBQUNhLFFBQVEsRUFBRVosT0FBUTtRQUFBTSxRQUFBLEVBQUM7TUFFM0QsQ0FBUSxDQUFDO0lBQUEsQ0FDTCxDQUFDO0VBQUEsQ0FDTixDQUFDO0FBRVI7QUFBQ08sRUFBQSxHQWZ1QmhCLFdBQVc7QUFBQSxJQUFBZ0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}