var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("react");
var _client = require("react-dom/client");
var _App = _interopRequireDefault(require("./App"));
require("./index.css");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Local `vite dev` entry ONLY. immediately.run never loads this file: the host
// boots a region app at the literal path `files/src/App.tsx` and renders its
// default export, so anything the rendered tree needs must be reachable from
// App.tsx — not from here.

(0, _client.createRoot)(document.getElementById('root')).render(/*#__PURE__*/(0, _jsxRuntime.jsx)(_react.StrictMode, {
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NsaWVudCIsIl9BcHAiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsImpzeCIsIlN0cmljdE1vZGUiLCJjaGlsZHJlbiJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIExvY2FsIGB2aXRlIGRldmAgZW50cnkgT05MWS4gaW1tZWRpYXRlbHkucnVuIG5ldmVyIGxvYWRzIHRoaXMgZmlsZTogdGhlIGhvc3Rcbi8vIGJvb3RzIGEgcmVnaW9uIGFwcCBhdCB0aGUgbGl0ZXJhbCBwYXRoIGBmaWxlcy9zcmMvQXBwLnRzeGAgYW5kIHJlbmRlcnMgaXRzXG4vLyBkZWZhdWx0IGV4cG9ydCwgc28gYW55dGhpbmcgdGhlIHJlbmRlcmVkIHRyZWUgbmVlZHMgbXVzdCBiZSByZWFjaGFibGUgZnJvbVxuLy8gQXBwLnRzeCDigJQgbm90IGZyb20gaGVyZS5cbmltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwJztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykhKS5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9TdHJpY3RNb2RlPixcbik7XG4iXSwibWFwcGluZ3MiOiI7O0FBSUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsSUFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0FBLE9BQUE7QUFBcUIsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsU0FBQUcsdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFQckI7QUFDQTtBQUNBO0FBQ0E7O0FBTUEsSUFBQUcsa0JBQVUsRUFBQ0MsUUFBUSxDQUFDQyxjQUFjLENBQUMsTUFBTSxDQUFFLENBQUMsQ0FBQ0MsTUFBTSxjQUNqRCxJQUFBUCxXQUFBLENBQUFRLEdBQUEsRUFBQ2IsTUFBQSxDQUFBYyxVQUFVO0VBQUFDLFFBQUEsZUFDVCxJQUFBVixXQUFBLENBQUFRLEdBQUEsRUFBQ1YsSUFBQSxDQUFBSyxPQUFHLElBQUU7QUFBQyxDQUNHLENBQ2QsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}