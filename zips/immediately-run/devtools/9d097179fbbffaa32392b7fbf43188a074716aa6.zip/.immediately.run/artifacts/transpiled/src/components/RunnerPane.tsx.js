var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = RunnerPane;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.flat-map.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _diagnostics = require("../lib/diagnostics");
var _run = require("../lib/run");
var _scope = require("../lib/scope");
var _CodeFrame = _interopRequireDefault(require("./CodeFrame"));
var _StaleBanner = _interopRequireDefault(require("./StaleBanner"));
var _Icons = require("./Icons");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(); // `mainpane.tools` — the runner (TOOLS_ACTIVITY_SPEC §8.2, R3-391): tabs per source with
// counts, a run bar (scope, Run, run metadata, partial / stale state), the selected
// diagnostic in a read-only code frame with an explicit **Open in editor** control (the
// §5.2 fallback), and the run summary when nothing is selected.
//
// Keyboard (per frame — keys do not cross iframes): J / K and F8 / ⇧F8 move to the
// next / previous problem in the active tab's order, Enter opens. None of these
// collide with the host (⌘K palette, ⌘B panel, ⌘. mode, Escape) or the editor
// (CodeMirror's default keymap).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const TABS = [{
  id: 'overview',
  label: 'Overview'
}, {
  id: 'tsc',
  label: 'Typecheck'
}, {
  id: 'eslint',
  label: 'Lint'
}, {
  id: 'build',
  label: 'Build'
}];
const SCOPES = ['changed', 'open', 'project'];
const SCOPE_SHORT = {
  changed: 'Changed',
  open: 'Open files',
  project: 'Whole project'
};
const ago = ms => {
  const s = Math.round(ms / 1000);
  if (s < 5) return 'just now';
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  return m < 60 ? `${m}m ago` : `${Math.round(m / 60)}h ago`;
};
const kb = units => units < 1024 ? `${units} chars` : `${Math.round(units / 1024)} KB`;
function useNow(tickMs = 5000) {
  _s();
  const [now, setNow] = (0, _react.useState)(() => Date.now());
  (0, _react.useEffect)(() => {
    const id = setInterval(() => setNow(Date.now()), tickMs);
    return () => clearInterval(id);
  }, [tickMs]);
  return now;
}
_s(useNow, "2IU6yg86GfAIPaiHfn+vZjj7R4s=");
function RunnerPane({
  session,
  buildErrors,
  onOpen,
  readFile
}) {
  _s2();
  const {
    status,
    last,
    running,
    run,
    stale,
    selectedId,
    select,
    ports
  } = session;
  const [tab, setTab] = (0, _react.useState)('overview');
  const [scope, setScope] = (0, _react.useState)('changed');
  const [openError, setOpenError] = (0, _react.useState)(null);
  const now = useNow();
  const all = (0, _react.useMemo)(() => {
    const build = buildErrors.map((e, i) => (0, _diagnostics.fromBuild)(e, i));
    return (0, _diagnostics.dedupe)([...build, ...(last?.diagnostics ?? [])]);
  }, [buildErrors, last]);
  const counts = (0, _react.useMemo)(() => (0, _diagnostics.countBySeverity)(all), [all]);
  const perSource = (0, _react.useMemo)(() => {
    const n = {
      tsc: 0,
      eslint: 0,
      build: 0
    };
    for (const d of all) if (d.severity !== 'note') n[d.source] += 1;
    return n;
  }, [all]);

  // The traversal order the keyboard follows: the panel's order (by file, document
  // order), narrowed to the active tab's source. Notes are not problems (§3.2) and are
  // not traversed.
  const order = (0, _react.useMemo)(() => {
    const {
      groups
    } = (0, _diagnostics.groupByFile)(all);
    const rows = groups.flatMap(g => g.rows);
    return tab === 'overview' ? rows : rows.filter(d => d.source === tab);
  }, [all, tab]);
  const selected = (0, _react.useMemo)(() => all.find(d => d.id === selectedId) ?? null, [all, selectedId]);
  const open = (0, _react.useCallback)(d => {
    setOpenError(null);
    // From the click / Enter handler on purpose: `reveal` needs the gesture the host
    // reads for itself (§5.2). This button IS the fallback when a row click's reveal
    // was refused — it is a fresh gesture.
    void onOpen(d).catch(e => {
      const code = e?.code;
      setOpenError(code === 'not-found' ? 'That file is no longer in the working tree.' : `Could not open the file (${code ?? 'unknown'}).`);
    });
  }, [onOpen]);
  const step = (0, _react.useCallback)(delta => {
    if (order.length === 0) return;
    const i = order.findIndex(d => d.id === selectedId);
    const next = i === -1 ? delta === 1 ? 0 : order.length - 1 : (i + delta + order.length) % order.length;
    select(order[next].id);
  }, [order, selectedId, select]);
  const onKey = (0, _react.useCallback)(e => {
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
    if (e.key === 'F8') {
      e.preventDefault();
      step(e.shiftKey ? -1 : 1);
    } else if (e.key === 'j' || e.key === 'J') {
      e.preventDefault();
      step(1);
    } else if (e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      step(-1);
    } else if (e.key === 'Enter' && selected) {
      e.preventDefault();
      open(selected);
    }
  }, [step, selected, open]);
  const liveBuildErrors = all.filter(d => d.source === 'build').length;
  const clean = last !== null && status.state === 'done' && (0, _run.isCleanBill)(last, liveBuildErrors);
  const isStale = stale.length > 0;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "runner",
    "aria-label": "Tools runner",
    onKeyDown: onKey,
    tabIndex: -1,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "tabs",
      role: "tablist",
      "aria-label": "Tool",
      children: TABS.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "tab",
        className: "tab",
        "aria-selected": tab === t.id,
        onClick: () => setTab(t.id),
        children: [t.label, t.id !== 'overview' && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "n",
          children: perSource[t.id]
        })]
      }, t.id))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "runbar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "scope",
        role: "group",
        "aria-label": "Run scope",
        children: SCOPES.map(s => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          "aria-pressed": scope === s,
          onClick: () => setScope(s),
          title: _scope.SCOPE_LABEL[s],
          children: SCOPE_SHORT[s]
        }, s))
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "runbtn",
        onClick: () => void run(scope),
        disabled: running || !ports,
        "aria-busy": running,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icons.PlayIcon, {}), " ", running ? 'Running…' : 'Run']
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "meta",
        role: "status",
        children: [ports === undefined && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "Connecting to the working tree\u2026"
        }), ports === null && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "No working tree here."
        }), status.state === 'running' && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          children: ["Running ", _scope.SCOPE_LABEL[status.scope].toLowerCase(), "\u2026"]
        }), status.state === 'failed' && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "warn",
          children: ["\u2715 failed \u2014 ", status.error]
        }), last && status.state !== 'running' && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: isStale ? 'warn' : last.partial.length > 0 ? 'warn' : 'ok',
            children: [isStale ? '◔ stale' : last.partial.length > 0 ? '◐ partial' : '✓ ran', " ", ago(now - last.startedAt)]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            children: [last.files.count, " ", last.files.count === 1 ? 'file' : 'files', " \xB7 ", kb(last.files.units)]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            children: [(last.durationMs / 1000).toFixed(1), "s"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            children: [_scope.SCOPE_LABEL[last.scope].toLowerCase(), last.fellBackFrom ? ` (${_scope.SCOPE_LABEL[last.fellBackFrom].toLowerCase()} was empty)` : '']
          })]
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_StaleBanner.default, {
      stale: stale,
      onRerun: () => void run(scope),
      running: running
    }), openError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "partial",
      role: "alert",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        children: openError
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `pane${isStale ? ' pane--stale' : ''}`,
      children: selected ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "detail-hd",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: `sevmark sevmark--${selected.severity}`,
            "aria-hidden": "true",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icons.SeverityGlyph, {
              severity: selected.severity
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            style: {
              minWidth: 0
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
              children: selected.message
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
              className: "detail-sub",
              children: selected.path === null ? 'not file-located' : `${selected.path}:${selected.line}:${selected.column}`
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "tagrow",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "tag",
                children: selected.source
              }), selected.code && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "tag",
                children: selected.code
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "tag",
                children: selected.severity
              }), selected.note && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "tag",
                children: selected.note
              })]
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_CodeFrame.default, {
          diagnostic: selected,
          readFile: readFile
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "actions",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "btn btn--primary",
            onClick: () => open(selected),
            disabled: selected.path === null,
            children: "Open in editor"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "btn",
            onClick: () => {
              void navigator.clipboard?.writeText(`${selected.path ?? ''}${selected.line !== null ? `:${selected.line}:${selected.column}` : ''} ${selected.message}`.trim()).catch(() => {});
            },
            children: "Copy message"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "hint",
            children: "\u21B5 opens \xB7 J / K move \xB7 F8 / \u21E7F8 next / previous"
          })]
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(Summary, {
        session: session,
        counts: counts,
        clean: clean,
        tab: tab,
        perSource: perSource,
        order: order
      })
    })]
  });
}
_s2(RunnerPane, "WBHm9HuZtCP9F/ta33FOk6V0yrI=", false, function () {
  return [useNow];
});
_c = RunnerPane;
function Summary({
  session,
  counts,
  clean,
  tab,
  perSource,
  order
}) {
  const {
    status,
    last,
    ports
  } = session;
  if (ports === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
        children: "No working tree here."
      }), " Open this from the Tools activity inside the immediately.run editor, where it can see the files it reports on."]
    });
  }
  if (!last && status.state !== 'running') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "empty",
      children: "Run typecheck and lint to see a summary here. Build errors appear as they happen."
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "summary-grid",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "stat",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "lbl",
          children: "Errors"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "val err",
          children: counts.errors
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "stat",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "lbl",
          children: "Warnings"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "val warn",
          children: counts.warnings
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "stat",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "lbl",
          children: "Notes"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "val note",
          children: counts.notes
        })]
      })]
    }), clean && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty empty--ok",
      "data-clean": "true",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
        children: "No problems"
      }), " in ", last ? _scope.SCOPE_LABEL[last.scope].toLowerCase() : '', " \u2014 ", last?.files.count ?? 0, " ", last?.files.count === 1 ? 'file' : 'files', " checked."]
    }), last && last.partial.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
        className: "summary-title",
        children: "Partial run \u2014 not everything was checked"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        className: "summary-list",
        children: last.partial.map((p, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          "data-kind": p.kind,
          children: p.detail
        }, `${p.kind}-${i}`))
      })]
    }), tab !== 'overview' && /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty",
      children: [perSource[tab], " ", tab, " ", perSource[tab] === 1 ? 'problem' : 'problems', order.length > 0 ? ' — press J or F8 to step through them.' : '.']
    })]
  });
}
_c2 = Summary;
var _c, _c2;
$RefreshReg$(_c, "RunnerPane");
$RefreshReg$(_c2, "Summary");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2RpYWdub3N0aWNzIiwiX3J1biIsIl9zY29wZSIsIl9Db2RlRnJhbWUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1N0YWxlQmFubmVyIiwiX0ljb25zIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRBQlMiLCJpZCIsImxhYmVsIiwiU0NPUEVTIiwiU0NPUEVfU0hPUlQiLCJjaGFuZ2VkIiwib3BlbiIsInByb2plY3QiLCJhZ28iLCJtcyIsInMiLCJNYXRoIiwicm91bmQiLCJtIiwia2IiLCJ1bml0cyIsInVzZU5vdyIsInRpY2tNcyIsIm5vdyIsInNldE5vdyIsInVzZVN0YXRlIiwiRGF0ZSIsInVzZUVmZmVjdCIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsIlJ1bm5lclBhbmUiLCJzZXNzaW9uIiwiYnVpbGRFcnJvcnMiLCJvbk9wZW4iLCJyZWFkRmlsZSIsInN0YXR1cyIsImxhc3QiLCJydW5uaW5nIiwicnVuIiwic3RhbGUiLCJzZWxlY3RlZElkIiwic2VsZWN0IiwicG9ydHMiLCJ0YWIiLCJzZXRUYWIiLCJzY29wZSIsInNldFNjb3BlIiwib3BlbkVycm9yIiwic2V0T3BlbkVycm9yIiwiYWxsIiwidXNlTWVtbyIsImJ1aWxkIiwibWFwIiwiaSIsImZyb21CdWlsZCIsImRlZHVwZSIsImRpYWdub3N0aWNzIiwiY291bnRzIiwiY291bnRCeVNldmVyaXR5IiwicGVyU291cmNlIiwibiIsInRzYyIsImVzbGludCIsImQiLCJzZXZlcml0eSIsInNvdXJjZSIsIm9yZGVyIiwiZ3JvdXBzIiwiZ3JvdXBCeUZpbGUiLCJyb3dzIiwiZmxhdE1hcCIsImciLCJmaWx0ZXIiLCJzZWxlY3RlZCIsImZpbmQiLCJ1c2VDYWxsYmFjayIsImNhdGNoIiwiY29kZSIsInN0ZXAiLCJkZWx0YSIsImxlbmd0aCIsImZpbmRJbmRleCIsIm5leHQiLCJvbktleSIsInQiLCJ0YXJnZXQiLCJ0YWdOYW1lIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJzaGlmdEtleSIsImxpdmVCdWlsZEVycm9ycyIsImNsZWFuIiwic3RhdGUiLCJpc0NsZWFuQmlsbCIsImlzU3RhbGUiLCJqc3hzIiwiY2xhc3NOYW1lIiwib25LZXlEb3duIiwidGFiSW5kZXgiLCJjaGlsZHJlbiIsImpzeCIsInJvbGUiLCJ0eXBlIiwib25DbGljayIsInRpdGxlIiwiU0NPUEVfTEFCRUwiLCJkaXNhYmxlZCIsIlBsYXlJY29uIiwidW5kZWZpbmVkIiwidG9Mb3dlckNhc2UiLCJlcnJvciIsIkZyYWdtZW50IiwicGFydGlhbCIsInN0YXJ0ZWRBdCIsImZpbGVzIiwiY291bnQiLCJkdXJhdGlvbk1zIiwidG9GaXhlZCIsImZlbGxCYWNrRnJvbSIsIm9uUmVydW4iLCJTZXZlcml0eUdseXBoIiwic3R5bGUiLCJtaW5XaWR0aCIsIm1lc3NhZ2UiLCJwYXRoIiwibGluZSIsImNvbHVtbiIsIm5vdGUiLCJkaWFnbm9zdGljIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwidHJpbSIsIlN1bW1hcnkiLCJfYyIsImVycm9ycyIsIndhcm5pbmdzIiwibm90ZXMiLCJwIiwia2luZCIsImRldGFpbCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJ1bm5lclBhbmUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGBtYWlucGFuZS50b29sc2Ag4oCUIHRoZSBydW5uZXIgKFRPT0xTX0FDVElWSVRZX1NQRUMgwqc4LjIsIFIzLTM5MSk6IHRhYnMgcGVyIHNvdXJjZSB3aXRoXG4vLyBjb3VudHMsIGEgcnVuIGJhciAoc2NvcGUsIFJ1biwgcnVuIG1ldGFkYXRhLCBwYXJ0aWFsIC8gc3RhbGUgc3RhdGUpLCB0aGUgc2VsZWN0ZWRcbi8vIGRpYWdub3N0aWMgaW4gYSByZWFkLW9ubHkgY29kZSBmcmFtZSB3aXRoIGFuIGV4cGxpY2l0ICoqT3BlbiBpbiBlZGl0b3IqKiBjb250cm9sICh0aGVcbi8vIMKnNS4yIGZhbGxiYWNrKSwgYW5kIHRoZSBydW4gc3VtbWFyeSB3aGVuIG5vdGhpbmcgaXMgc2VsZWN0ZWQuXG4vL1xuLy8gS2V5Ym9hcmQgKHBlciBmcmFtZSDigJQga2V5cyBkbyBub3QgY3Jvc3MgaWZyYW1lcyk6IEogLyBLIGFuZCBGOCAvIOKHp0Y4IG1vdmUgdG8gdGhlXG4vLyBuZXh0IC8gcHJldmlvdXMgcHJvYmxlbSBpbiB0aGUgYWN0aXZlIHRhYidzIG9yZGVyLCBFbnRlciBvcGVucy4gTm9uZSBvZiB0aGVzZVxuLy8gY29sbGlkZSB3aXRoIHRoZSBob3N0ICjijJhLIHBhbGV0dGUsIOKMmEIgcGFuZWwsIOKMmC4gbW9kZSwgRXNjYXBlKSBvciB0aGUgZWRpdG9yXG4vLyAoQ29kZU1pcnJvcidzIGRlZmF1bHQga2V5bWFwKS5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdHlwZSBCdWlsZEVycm9yTGlrZSwgdHlwZSBEaWFnbm9zdGljLCB0eXBlIFNvdXJjZSwgY291bnRCeVNldmVyaXR5LCBkZWR1cGUsIGZyb21CdWlsZCwgZ3JvdXBCeUZpbGUgfSBmcm9tICcuLi9saWIvZGlhZ25vc3RpY3MnO1xuaW1wb3J0IHsgaXNDbGVhbkJpbGwgfSBmcm9tICcuLi9saWIvcnVuJztcbmltcG9ydCB7IFNDT1BFX0xBQkVMLCB0eXBlIFNjb3BlSWQgfSBmcm9tICcuLi9saWIvc2NvcGUnO1xuaW1wb3J0IHR5cGUgeyBUb29sc1Nlc3Npb24gfSBmcm9tICcuLi9ob29rcy91c2VUb29sc1Nlc3Npb24nO1xuaW1wb3J0IENvZGVGcmFtZSBmcm9tICcuL0NvZGVGcmFtZSc7XG5pbXBvcnQgU3RhbGVCYW5uZXIgZnJvbSAnLi9TdGFsZUJhbm5lcic7XG5pbXBvcnQgeyBQbGF5SWNvbiwgU2V2ZXJpdHlHbHlwaCB9IGZyb20gJy4vSWNvbnMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJ1bm5lclBhbmVQcm9wcyB7XG4gIHNlc3Npb246IFRvb2xzU2Vzc2lvbjtcbiAgYnVpbGRFcnJvcnM6IHJlYWRvbmx5IEJ1aWxkRXJyb3JMaWtlW107XG4gIC8qKiBSb3cgYWN0aXZhdGlvbiDigJQgdGhlIGdlc3R1cmUtY2FycnlpbmcgY2FsbCAoYG9wZW5EaWFnbm9zdGljYCBpbiB0aGUgbGl2ZSBhcHApLiAqL1xuICBvbk9wZW46IChkOiBEaWFnbm9zdGljKSA9PiBQcm9taXNlPHZvaWQ+O1xuICByZWFkRmlsZTogKChwYXRoOiBzdHJpbmcpID0+IFByb21pc2U8c3RyaW5nPikgfCBudWxsO1xufVxuXG50eXBlIFRhYiA9ICdvdmVydmlldycgfCBTb3VyY2U7XG5jb25zdCBUQUJTOiBBcnJheTx7IGlkOiBUYWI7IGxhYmVsOiBzdHJpbmcgfT4gPSBbXG4gIHsgaWQ6ICdvdmVydmlldycsIGxhYmVsOiAnT3ZlcnZpZXcnIH0sXG4gIHsgaWQ6ICd0c2MnLCBsYWJlbDogJ1R5cGVjaGVjaycgfSxcbiAgeyBpZDogJ2VzbGludCcsIGxhYmVsOiAnTGludCcgfSxcbiAgeyBpZDogJ2J1aWxkJywgbGFiZWw6ICdCdWlsZCcgfSxcbl07XG5jb25zdCBTQ09QRVM6IFNjb3BlSWRbXSA9IFsnY2hhbmdlZCcsICdvcGVuJywgJ3Byb2plY3QnXTtcbmNvbnN0IFNDT1BFX1NIT1JUOiBSZWNvcmQ8U2NvcGVJZCwgc3RyaW5nPiA9IHsgY2hhbmdlZDogJ0NoYW5nZWQnLCBvcGVuOiAnT3BlbiBmaWxlcycsIHByb2plY3Q6ICdXaG9sZSBwcm9qZWN0JyB9O1xuXG5jb25zdCBhZ28gPSAobXM6IG51bWJlcik6IHN0cmluZyA9PiB7XG4gIGNvbnN0IHMgPSBNYXRoLnJvdW5kKG1zIC8gMTAwMCk7XG4gIGlmIChzIDwgNSkgcmV0dXJuICdqdXN0IG5vdyc7XG4gIGlmIChzIDwgNjApIHJldHVybiBgJHtzfXMgYWdvYDtcbiAgY29uc3QgbSA9IE1hdGgucm91bmQocyAvIDYwKTtcbiAgcmV0dXJuIG0gPCA2MCA/IGAke219bSBhZ29gIDogYCR7TWF0aC5yb3VuZChtIC8gNjApfWggYWdvYDtcbn07XG5jb25zdCBrYiA9ICh1bml0czogbnVtYmVyKSA9PiAodW5pdHMgPCAxMDI0ID8gYCR7dW5pdHN9IGNoYXJzYCA6IGAke01hdGgucm91bmQodW5pdHMgLyAxMDI0KX0gS0JgKTtcblxuZnVuY3Rpb24gdXNlTm93KHRpY2tNcyA9IDUwMDApOiBudW1iZXIge1xuICBjb25zdCBbbm93LCBzZXROb3ddID0gdXNlU3RhdGUoKCkgPT4gRGF0ZS5ub3coKSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaWQgPSBzZXRJbnRlcnZhbCgoKSA9PiBzZXROb3coRGF0ZS5ub3coKSksIHRpY2tNcyk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaWQpO1xuICB9LCBbdGlja01zXSk7XG4gIHJldHVybiBub3c7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJ1bm5lclBhbmUoeyBzZXNzaW9uLCBidWlsZEVycm9ycywgb25PcGVuLCByZWFkRmlsZSB9OiBSdW5uZXJQYW5lUHJvcHMpIHtcbiAgY29uc3QgeyBzdGF0dXMsIGxhc3QsIHJ1bm5pbmcsIHJ1biwgc3RhbGUsIHNlbGVjdGVkSWQsIHNlbGVjdCwgcG9ydHMgfSA9IHNlc3Npb247XG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZTxUYWI+KCdvdmVydmlldycpO1xuICBjb25zdCBbc2NvcGUsIHNldFNjb3BlXSA9IHVzZVN0YXRlPFNjb3BlSWQ+KCdjaGFuZ2VkJyk7XG4gIGNvbnN0IFtvcGVuRXJyb3IsIHNldE9wZW5FcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3Qgbm93ID0gdXNlTm93KCk7XG5cbiAgY29uc3QgYWxsID0gdXNlTWVtbzxEaWFnbm9zdGljW10+KCgpID0+IHtcbiAgICBjb25zdCBidWlsZCA9IGJ1aWxkRXJyb3JzLm1hcCgoZSwgaSkgPT4gZnJvbUJ1aWxkKGUsIGkpKTtcbiAgICByZXR1cm4gZGVkdXBlKFsuLi5idWlsZCwgLi4uKGxhc3Q/LmRpYWdub3N0aWNzID8/IFtdKV0pO1xuICB9LCBbYnVpbGRFcnJvcnMsIGxhc3RdKTtcbiAgY29uc3QgY291bnRzID0gdXNlTWVtbygoKSA9PiBjb3VudEJ5U2V2ZXJpdHkoYWxsKSwgW2FsbF0pO1xuICBjb25zdCBwZXJTb3VyY2UgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBuOiBSZWNvcmQ8U291cmNlLCBudW1iZXI+ID0geyB0c2M6IDAsIGVzbGludDogMCwgYnVpbGQ6IDAgfTtcbiAgICBmb3IgKGNvbnN0IGQgb2YgYWxsKSBpZiAoZC5zZXZlcml0eSAhPT0gJ25vdGUnKSBuW2Quc291cmNlXSArPSAxO1xuICAgIHJldHVybiBuO1xuICB9LCBbYWxsXSk7XG5cbiAgLy8gVGhlIHRyYXZlcnNhbCBvcmRlciB0aGUga2V5Ym9hcmQgZm9sbG93czogdGhlIHBhbmVsJ3Mgb3JkZXIgKGJ5IGZpbGUsIGRvY3VtZW50XG4gIC8vIG9yZGVyKSwgbmFycm93ZWQgdG8gdGhlIGFjdGl2ZSB0YWIncyBzb3VyY2UuIE5vdGVzIGFyZSBub3QgcHJvYmxlbXMgKMKnMy4yKSBhbmQgYXJlXG4gIC8vIG5vdCB0cmF2ZXJzZWQuXG4gIGNvbnN0IG9yZGVyID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgeyBncm91cHMgfSA9IGdyb3VwQnlGaWxlKGFsbCk7XG4gICAgY29uc3Qgcm93cyA9IGdyb3Vwcy5mbGF0TWFwKChnKSA9PiBnLnJvd3MpO1xuICAgIHJldHVybiB0YWIgPT09ICdvdmVydmlldycgPyByb3dzIDogcm93cy5maWx0ZXIoKGQpID0+IGQuc291cmNlID09PSB0YWIpO1xuICB9LCBbYWxsLCB0YWJdKTtcbiAgY29uc3Qgc2VsZWN0ZWQgPSB1c2VNZW1vKCgpID0+IGFsbC5maW5kKChkKSA9PiBkLmlkID09PSBzZWxlY3RlZElkKSA/PyBudWxsLCBbYWxsLCBzZWxlY3RlZElkXSk7XG5cbiAgY29uc3Qgb3BlbiA9IHVzZUNhbGxiYWNrKFxuICAgIChkOiBEaWFnbm9zdGljKSA9PiB7XG4gICAgICBzZXRPcGVuRXJyb3IobnVsbCk7XG4gICAgICAvLyBGcm9tIHRoZSBjbGljayAvIEVudGVyIGhhbmRsZXIgb24gcHVycG9zZTogYHJldmVhbGAgbmVlZHMgdGhlIGdlc3R1cmUgdGhlIGhvc3RcbiAgICAgIC8vIHJlYWRzIGZvciBpdHNlbGYgKMKnNS4yKS4gVGhpcyBidXR0b24gSVMgdGhlIGZhbGxiYWNrIHdoZW4gYSByb3cgY2xpY2sncyByZXZlYWxcbiAgICAgIC8vIHdhcyByZWZ1c2VkIOKAlCBpdCBpcyBhIGZyZXNoIGdlc3R1cmUuXG4gICAgICB2b2lkIG9uT3BlbihkKS5jYXRjaCgoZTogdW5rbm93bikgPT4ge1xuICAgICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgICBzZXRPcGVuRXJyb3IoY29kZSA9PT0gJ25vdC1mb3VuZCcgPyAnVGhhdCBmaWxlIGlzIG5vIGxvbmdlciBpbiB0aGUgd29ya2luZyB0cmVlLicgOiBgQ291bGQgbm90IG9wZW4gdGhlIGZpbGUgKCR7Y29kZSA/PyAndW5rbm93bid9KS5gKTtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgW29uT3Blbl0sXG4gICk7XG5cbiAgY29uc3Qgc3RlcCA9IHVzZUNhbGxiYWNrKFxuICAgIChkZWx0YTogMSB8IC0xKSA9PiB7XG4gICAgICBpZiAob3JkZXIubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICBjb25zdCBpID0gb3JkZXIuZmluZEluZGV4KChkKSA9PiBkLmlkID09PSBzZWxlY3RlZElkKTtcbiAgICAgIGNvbnN0IG5leHQgPSBpID09PSAtMSA/IChkZWx0YSA9PT0gMSA/IDAgOiBvcmRlci5sZW5ndGggLSAxKSA6IChpICsgZGVsdGEgKyBvcmRlci5sZW5ndGgpICUgb3JkZXIubGVuZ3RoO1xuICAgICAgc2VsZWN0KG9yZGVyW25leHRdLmlkKTtcbiAgICB9LFxuICAgIFtvcmRlciwgc2VsZWN0ZWRJZCwgc2VsZWN0XSxcbiAgKTtcblxuICBjb25zdCBvbktleSA9IHVzZUNhbGxiYWNrKFxuICAgIChlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB0ID0gZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICAgICAgaWYgKHQgJiYgKHQudGFnTmFtZSA9PT0gJ0lOUFVUJyB8fCB0LnRhZ05hbWUgPT09ICdURVhUQVJFQScpKSByZXR1cm47XG4gICAgICBpZiAoZS5rZXkgPT09ICdGOCcpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzdGVwKGUuc2hpZnRLZXkgPyAtMSA6IDEpO1xuICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ2onIHx8IGUua2V5ID09PSAnSicpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzdGVwKDEpO1xuICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ2snIHx8IGUua2V5ID09PSAnSycpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzdGVwKC0xKTtcbiAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFbnRlcicgJiYgc2VsZWN0ZWQpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBvcGVuKHNlbGVjdGVkKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtzdGVwLCBzZWxlY3RlZCwgb3Blbl0sXG4gICk7XG5cbiAgY29uc3QgbGl2ZUJ1aWxkRXJyb3JzID0gYWxsLmZpbHRlcigoZCkgPT4gZC5zb3VyY2UgPT09ICdidWlsZCcpLmxlbmd0aDtcbiAgY29uc3QgY2xlYW4gPSBsYXN0ICE9PSBudWxsICYmIHN0YXR1cy5zdGF0ZSA9PT0gJ2RvbmUnICYmIGlzQ2xlYW5CaWxsKGxhc3QsIGxpdmVCdWlsZEVycm9ycyk7XG4gIGNvbnN0IGlzU3RhbGUgPSBzdGFsZS5sZW5ndGggPiAwO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicnVubmVyXCIgYXJpYS1sYWJlbD1cIlRvb2xzIHJ1bm5lclwiIG9uS2V5RG93bj17b25LZXl9IHRhYkluZGV4PXstMX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhYnNcIiByb2xlPVwidGFibGlzdFwiIGFyaWEtbGFiZWw9XCJUb29sXCI+XG4gICAgICAgIHtUQUJTLm1hcCgodCkgPT4gKFxuICAgICAgICAgIDxidXR0b24ga2V5PXt0LmlkfSB0eXBlPVwiYnV0dG9uXCIgcm9sZT1cInRhYlwiIGNsYXNzTmFtZT1cInRhYlwiIGFyaWEtc2VsZWN0ZWQ9e3RhYiA9PT0gdC5pZH0gb25DbGljaz17KCkgPT4gc2V0VGFiKHQuaWQpfT5cbiAgICAgICAgICAgIHt0LmxhYmVsfVxuICAgICAgICAgICAge3QuaWQgIT09ICdvdmVydmlldycgJiYgPHNwYW4gY2xhc3NOYW1lPVwiblwiPntwZXJTb3VyY2VbdC5pZF19PC9zcGFuPn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJydW5iYXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY29wZVwiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJSdW4gc2NvcGVcIj5cbiAgICAgICAgICB7U0NPUEVTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3N9IHR5cGU9XCJidXR0b25cIiBhcmlhLXByZXNzZWQ9e3Njb3BlID09PSBzfSBvbkNsaWNrPXsoKSA9PiBzZXRTY29wZShzKX0gdGl0bGU9e1NDT1BFX0xBQkVMW3NdfT5cbiAgICAgICAgICAgICAge1NDT1BFX1NIT1JUW3NdfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJydW5idG5cIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHJ1bihzY29wZSl9IGRpc2FibGVkPXtydW5uaW5nIHx8ICFwb3J0c30gYXJpYS1idXN5PXtydW5uaW5nfT5cbiAgICAgICAgICA8UGxheUljb24gLz4ge3J1bm5pbmcgPyAnUnVubmluZ+KApicgOiAnUnVuJ31cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWV0YVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICB7cG9ydHMgPT09IHVuZGVmaW5lZCAmJiA8c3Bhbj5Db25uZWN0aW5nIHRvIHRoZSB3b3JraW5nIHRyZWXigKY8L3NwYW4+fVxuICAgICAgICAgIHtwb3J0cyA9PT0gbnVsbCAmJiA8c3Bhbj5ObyB3b3JraW5nIHRyZWUgaGVyZS48L3NwYW4+fVxuICAgICAgICAgIHtzdGF0dXMuc3RhdGUgPT09ICdydW5uaW5nJyAmJiA8c3Bhbj5SdW5uaW5nIHtTQ09QRV9MQUJFTFtzdGF0dXMuc2NvcGVdLnRvTG93ZXJDYXNlKCl94oCmPC9zcGFuPn1cbiAgICAgICAgICB7c3RhdHVzLnN0YXRlID09PSAnZmFpbGVkJyAmJiA8c3BhbiBjbGFzc05hbWU9XCJ3YXJuXCI+4pyVIGZhaWxlZCDigJQge3N0YXR1cy5lcnJvcn08L3NwYW4+fVxuICAgICAgICAgIHtsYXN0ICYmIHN0YXR1cy5zdGF0ZSAhPT0gJ3J1bm5pbmcnICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17aXNTdGFsZSA/ICd3YXJuJyA6IGxhc3QucGFydGlhbC5sZW5ndGggPiAwID8gJ3dhcm4nIDogJ29rJ30+XG4gICAgICAgICAgICAgICAge2lzU3RhbGUgPyAn4peUIHN0YWxlJyA6IGxhc3QucGFydGlhbC5sZW5ndGggPiAwID8gJ+KXkCBwYXJ0aWFsJyA6ICfinJMgcmFuJ30ge2Fnbyhub3cgLSBsYXN0LnN0YXJ0ZWRBdCl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAge2xhc3QuZmlsZXMuY291bnR9IHtsYXN0LmZpbGVzLmNvdW50ID09PSAxID8gJ2ZpbGUnIDogJ2ZpbGVzJ30gwrcge2tiKGxhc3QuZmlsZXMudW5pdHMpfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPnsobGFzdC5kdXJhdGlvbk1zIC8gMTAwMCkudG9GaXhlZCgxKX1zPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICB7U0NPUEVfTEFCRUxbbGFzdC5zY29wZV0udG9Mb3dlckNhc2UoKX1cbiAgICAgICAgICAgICAgICB7bGFzdC5mZWxsQmFja0Zyb20gPyBgICgke1NDT1BFX0xBQkVMW2xhc3QuZmVsbEJhY2tGcm9tXS50b0xvd2VyQ2FzZSgpfSB3YXMgZW1wdHkpYCA6ICcnfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8U3RhbGVCYW5uZXIgc3RhbGU9e3N0YWxlfSBvblJlcnVuPXsoKSA9PiB2b2lkIHJ1bihzY29wZSl9IHJ1bm5pbmc9e3J1bm5pbmd9IC8+XG5cbiAgICAgIHtvcGVuRXJyb3IgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJwYXJ0aWFsXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgPHNwYW4+e29wZW5FcnJvcn08L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcGFuZSR7aXNTdGFsZSA/ICcgcGFuZS0tc3RhbGUnIDogJyd9YH0+XG4gICAgICAgIHtzZWxlY3RlZCA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZXRhaWwtaGRcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgc2V2bWFyayBzZXZtYXJrLS0ke3NlbGVjdGVkLnNldmVyaXR5fWB9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgIDxTZXZlcml0eUdseXBoIHNldmVyaXR5PXtzZWxlY3RlZC5zZXZlcml0eX0gLz5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1pbldpZHRoOiAwIH19PlxuICAgICAgICAgICAgICAgIDxoMj57c2VsZWN0ZWQubWVzc2FnZX08L2gyPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImRldGFpbC1zdWJcIj57c2VsZWN0ZWQucGF0aCA9PT0gbnVsbCA/ICdub3QgZmlsZS1sb2NhdGVkJyA6IGAke3NlbGVjdGVkLnBhdGh9OiR7c2VsZWN0ZWQubGluZX06JHtzZWxlY3RlZC5jb2x1bW59YH08L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWdyb3dcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhZ1wiPntzZWxlY3RlZC5zb3VyY2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLmNvZGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGFnXCI+e3NlbGVjdGVkLmNvZGV9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhZ1wiPntzZWxlY3RlZC5zZXZlcml0eX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubm90ZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0YWdcIj57c2VsZWN0ZWQubm90ZX08L3NwYW4+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPENvZGVGcmFtZSBkaWFnbm9zdGljPXtzZWxlY3RlZH0gcmVhZEZpbGU9e3JlYWRGaWxlfSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhY3Rpb25zXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tLXByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiBvcGVuKHNlbGVjdGVkKX0gZGlzYWJsZWQ9e3NlbGVjdGVkLnBhdGggPT09IG51bGx9PlxuICAgICAgICAgICAgICAgIE9wZW4gaW4gZWRpdG9yXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICB2b2lkIG5hdmlnYXRvci5jbGlwYm9hcmQ/LndyaXRlVGV4dChgJHtzZWxlY3RlZC5wYXRoID8/ICcnfSR7c2VsZWN0ZWQubGluZSAhPT0gbnVsbCA/IGA6JHtzZWxlY3RlZC5saW5lfToke3NlbGVjdGVkLmNvbHVtbn1gIDogJyd9ICR7c2VsZWN0ZWQubWVzc2FnZX1gLnRyaW0oKSkuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDb3B5IG1lc3NhZ2VcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpbnRcIj7ihrUgb3BlbnMgwrcgSiAvIEsgbW92ZSDCtyBGOCAvIOKHp0Y4IG5leHQgLyBwcmV2aW91czwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxTdW1tYXJ5IHNlc3Npb249e3Nlc3Npb259IGNvdW50cz17Y291bnRzfSBjbGVhbj17Y2xlYW59IHRhYj17dGFifSBwZXJTb3VyY2U9e3BlclNvdXJjZX0gb3JkZXI9e29yZGVyfSAvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuXG5mdW5jdGlvbiBTdW1tYXJ5KHtcbiAgc2Vzc2lvbixcbiAgY291bnRzLFxuICBjbGVhbixcbiAgdGFiLFxuICBwZXJTb3VyY2UsXG4gIG9yZGVyLFxufToge1xuICBzZXNzaW9uOiBUb29sc1Nlc3Npb247XG4gIGNvdW50czogUmV0dXJuVHlwZTx0eXBlb2YgY291bnRCeVNldmVyaXR5PjtcbiAgY2xlYW46IGJvb2xlYW47XG4gIHRhYjogVGFiO1xuICBwZXJTb3VyY2U6IFJlY29yZDxTb3VyY2UsIG51bWJlcj47XG4gIG9yZGVyOiBEaWFnbm9zdGljW107XG59KSB7XG4gIGNvbnN0IHsgc3RhdHVzLCBsYXN0LCBwb3J0cyB9ID0gc2Vzc2lvbjtcbiAgaWYgKHBvcnRzID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxwIGNsYXNzTmFtZT1cImVtcHR5XCI+XG4gICAgICAgIDxiPk5vIHdvcmtpbmcgdHJlZSBoZXJlLjwvYj4gT3BlbiB0aGlzIGZyb20gdGhlIFRvb2xzIGFjdGl2aXR5IGluc2lkZSB0aGUgaW1tZWRpYXRlbHkucnVuIGVkaXRvciwgd2hlcmUgaXQgY2FuIHNlZSB0aGUgZmlsZXMgaXQgcmVwb3J0cyBvbi5cbiAgICAgIDwvcD5cbiAgICApO1xuICB9XG4gIGlmICghbGFzdCAmJiBzdGF0dXMuc3RhdGUgIT09ICdydW5uaW5nJykge1xuICAgIHJldHVybiA8cCBjbGFzc05hbWU9XCJlbXB0eVwiPlJ1biB0eXBlY2hlY2sgYW5kIGxpbnQgdG8gc2VlIGEgc3VtbWFyeSBoZXJlLiBCdWlsZCBlcnJvcnMgYXBwZWFyIGFzIHRoZXkgaGFwcGVuLjwvcD47XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWdyaWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYmxcIj5FcnJvcnM8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZhbCBlcnJcIj57Y291bnRzLmVycm9yc308L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGJsXCI+V2FybmluZ3M8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZhbCB3YXJuXCI+e2NvdW50cy53YXJuaW5nc308L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGJsXCI+Tm90ZXM8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZhbCBub3RlXCI+e2NvdW50cy5ub3Rlc308L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtjbGVhbiAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImVtcHR5IGVtcHR5LS1va1wiIGRhdGEtY2xlYW49XCJ0cnVlXCI+XG4gICAgICAgICAgPGI+Tm8gcHJvYmxlbXM8L2I+IGluIHtsYXN0ID8gU0NPUEVfTEFCRUxbbGFzdC5zY29wZV0udG9Mb3dlckNhc2UoKSA6ICcnfSDigJQge2xhc3Q/LmZpbGVzLmNvdW50ID8/IDB9IHtsYXN0Py5maWxlcy5jb3VudCA9PT0gMSA/ICdmaWxlJyA6ICdmaWxlcyd9IGNoZWNrZWQuXG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgICB7bGFzdCAmJiBsYXN0LnBhcnRpYWwubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInN1bW1hcnktdGl0bGVcIj5QYXJ0aWFsIHJ1biDigJQgbm90IGV2ZXJ5dGhpbmcgd2FzIGNoZWNrZWQ8L2gzPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzdW1tYXJ5LWxpc3RcIj5cbiAgICAgICAgICAgIHtsYXN0LnBhcnRpYWwubWFwKChwLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2Ake3Aua2luZH0tJHtpfWB9IGRhdGEta2luZD17cC5raW5kfT5cbiAgICAgICAgICAgICAgICB7cC5kZXRhaWx9XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7dGFiICE9PSAnb3ZlcnZpZXcnICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZW1wdHlcIj5cbiAgICAgICAgICB7cGVyU291cmNlW3RhYl19IHt0YWJ9IHtwZXJTb3VyY2VbdGFiXSA9PT0gMSA/ICdwcm9ibGVtJyA6ICdwcm9ibGVtcyd9XG4gICAgICAgICAge29yZGVyLmxlbmd0aCA+IDAgPyAnIOKAlCBwcmVzcyBKIG9yIEY4IHRvIHN0ZXAgdGhyb3VnaCB0aGVtLicgOiAnLid9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgPC8+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBU0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsSUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsTUFBQSxHQUFBSCxPQUFBO0FBRUEsSUFBQUksVUFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU0sWUFBQSxHQUFBRCxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU8sTUFBQSxHQUFBUCxPQUFBO0FBQWtELElBQUFRLFdBQUEsR0FBQVIsT0FBQTtBQUFBLElBQUFTLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUEsSUFoQmxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFMLHVCQUFBTyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBbUJBLE1BQU1HLElBQXVDLEdBQUcsQ0FDOUM7RUFBRUMsRUFBRSxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFO0FBQVcsQ0FBQyxFQUNyQztFQUFFRCxFQUFFLEVBQUUsS0FBSztFQUFFQyxLQUFLLEVBQUU7QUFBWSxDQUFDLEVBQ2pDO0VBQUVELEVBQUUsRUFBRSxRQUFRO0VBQUVDLEtBQUssRUFBRTtBQUFPLENBQUMsRUFDL0I7RUFBRUQsRUFBRSxFQUFFLE9BQU87RUFBRUMsS0FBSyxFQUFFO0FBQVEsQ0FBQyxDQUNoQztBQUNELE1BQU1DLE1BQWlCLEdBQUcsQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQztBQUN4RCxNQUFNQyxXQUFvQyxHQUFHO0VBQUVDLE9BQU8sRUFBRSxTQUFTO0VBQUVDLElBQUksRUFBRSxZQUFZO0VBQUVDLE9BQU8sRUFBRTtBQUFnQixDQUFDO0FBRWpILE1BQU1DLEdBQUcsR0FBSUMsRUFBVSxJQUFhO0VBQ2xDLE1BQU1DLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUNILEVBQUUsR0FBRyxJQUFJLENBQUM7RUFDL0IsSUFBSUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLFVBQVU7RUFDNUIsSUFBSUEsQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEdBQUdBLENBQUMsT0FBTztFQUM5QixNQUFNRyxDQUFDLEdBQUdGLElBQUksQ0FBQ0MsS0FBSyxDQUFDRixDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQzVCLE9BQU9HLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBR0EsQ0FBQyxPQUFPLEdBQUcsR0FBR0YsSUFBSSxDQUFDQyxLQUFLLENBQUNDLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTztBQUM1RCxDQUFDO0FBQ0QsTUFBTUMsRUFBRSxHQUFJQyxLQUFhLElBQU1BLEtBQUssR0FBRyxJQUFJLEdBQUcsR0FBR0EsS0FBSyxRQUFRLEdBQUcsR0FBR0osSUFBSSxDQUFDQyxLQUFLLENBQUNHLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBTTtBQUVsRyxTQUFTQyxNQUFNQSxDQUFDQyxNQUFNLEdBQUcsSUFBSSxFQUFVO0VBQUF2QixFQUFBO0VBQ3JDLE1BQU0sQ0FBQ3dCLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLE1BQU1DLElBQUksQ0FBQ0gsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUNoRCxJQUFBSSxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNckIsRUFBRSxHQUFHc0IsV0FBVyxDQUFDLE1BQU1KLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDSCxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUVELE1BQU0sQ0FBQztJQUN4RCxPQUFPLE1BQU1PLGFBQWEsQ0FBQ3ZCLEVBQUUsQ0FBQztFQUNoQyxDQUFDLEVBQUUsQ0FBQ2dCLE1BQU0sQ0FBQyxDQUFDO0VBQ1osT0FBT0MsR0FBRztBQUNaO0FBQUN4QixFQUFBLENBUFFzQixNQUFNO0FBU0EsU0FBU1MsVUFBVUEsQ0FBQztFQUFFQyxPQUFPO0VBQUVDLFdBQVc7RUFBRUMsTUFBTTtFQUFFQztBQUEwQixDQUFDLEVBQUU7RUFBQWpDLEdBQUE7RUFDOUYsTUFBTTtJQUFFa0MsTUFBTTtJQUFFQyxJQUFJO0lBQUVDLE9BQU87SUFBRUMsR0FBRztJQUFFQyxLQUFLO0lBQUVDLFVBQVU7SUFBRUMsTUFBTTtJQUFFQztFQUFNLENBQUMsR0FBR1gsT0FBTztFQUNoRixNQUFNLENBQUNZLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQW5CLGVBQVEsRUFBTSxVQUFVLENBQUM7RUFDL0MsTUFBTSxDQUFDb0IsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBckIsZUFBUSxFQUFVLFNBQVMsQ0FBQztFQUN0RCxNQUFNLENBQUNzQixTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUF2QixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUMvRCxNQUFNRixHQUFHLEdBQUdGLE1BQU0sQ0FBQyxDQUFDO0VBRXBCLE1BQU00QixHQUFHLEdBQUcsSUFBQUMsY0FBTyxFQUFlLE1BQU07SUFDdEMsTUFBTUMsS0FBSyxHQUFHbkIsV0FBVyxDQUFDb0IsR0FBRyxDQUFDLENBQUNsRCxDQUFDLEVBQUVtRCxDQUFDLEtBQUssSUFBQUMsc0JBQVMsRUFBQ3BELENBQUMsRUFBRW1ELENBQUMsQ0FBQyxDQUFDO0lBQ3hELE9BQU8sSUFBQUUsbUJBQU0sRUFBQyxDQUFDLEdBQUdKLEtBQUssRUFBRSxJQUFJZixJQUFJLEVBQUVvQixXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztFQUN6RCxDQUFDLEVBQUUsQ0FBQ3hCLFdBQVcsRUFBRUksSUFBSSxDQUFDLENBQUM7RUFDdkIsTUFBTXFCLE1BQU0sR0FBRyxJQUFBUCxjQUFPLEVBQUMsTUFBTSxJQUFBUSw0QkFBZSxFQUFDVCxHQUFHLENBQUMsRUFBRSxDQUFDQSxHQUFHLENBQUMsQ0FBQztFQUN6RCxNQUFNVSxTQUFTLEdBQUcsSUFBQVQsY0FBTyxFQUFDLE1BQU07SUFDOUIsTUFBTVUsQ0FBeUIsR0FBRztNQUFFQyxHQUFHLEVBQUUsQ0FBQztNQUFFQyxNQUFNLEVBQUUsQ0FBQztNQUFFWCxLQUFLLEVBQUU7SUFBRSxDQUFDO0lBQ2pFLEtBQUssTUFBTVksQ0FBQyxJQUFJZCxHQUFHLEVBQUUsSUFBSWMsQ0FBQyxDQUFDQyxRQUFRLEtBQUssTUFBTSxFQUFFSixDQUFDLENBQUNHLENBQUMsQ0FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNoRSxPQUFPTCxDQUFDO0VBQ1YsQ0FBQyxFQUFFLENBQUNYLEdBQUcsQ0FBQyxDQUFDOztFQUVUO0VBQ0E7RUFDQTtFQUNBLE1BQU1pQixLQUFLLEdBQUcsSUFBQWhCLGNBQU8sRUFBQyxNQUFNO0lBQzFCLE1BQU07TUFBRWlCO0lBQU8sQ0FBQyxHQUFHLElBQUFDLHdCQUFXLEVBQUNuQixHQUFHLENBQUM7SUFDbkMsTUFBTW9CLElBQUksR0FBR0YsTUFBTSxDQUFDRyxPQUFPLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDRixJQUFJLENBQUM7SUFDMUMsT0FBTzFCLEdBQUcsS0FBSyxVQUFVLEdBQUcwQixJQUFJLEdBQUdBLElBQUksQ0FBQ0csTUFBTSxDQUFFVCxDQUFDLElBQUtBLENBQUMsQ0FBQ0UsTUFBTSxLQUFLdEIsR0FBRyxDQUFDO0VBQ3pFLENBQUMsRUFBRSxDQUFDTSxHQUFHLEVBQUVOLEdBQUcsQ0FBQyxDQUFDO0VBQ2QsTUFBTThCLFFBQVEsR0FBRyxJQUFBdkIsY0FBTyxFQUFDLE1BQU1ELEdBQUcsQ0FBQ3lCLElBQUksQ0FBRVgsQ0FBQyxJQUFLQSxDQUFDLENBQUN6RCxFQUFFLEtBQUtrQyxVQUFVLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQ1MsR0FBRyxFQUFFVCxVQUFVLENBQUMsQ0FBQztFQUUvRixNQUFNN0IsSUFBSSxHQUFHLElBQUFnRSxrQkFBVyxFQUNyQlosQ0FBYSxJQUFLO0lBQ2pCZixZQUFZLENBQUMsSUFBSSxDQUFDO0lBQ2xCO0lBQ0E7SUFDQTtJQUNBLEtBQUtmLE1BQU0sQ0FBQzhCLENBQUMsQ0FBQyxDQUFDYSxLQUFLLENBQUUxRSxDQUFVLElBQUs7TUFDbkMsTUFBTTJFLElBQUksR0FBSTNFLENBQUMsRUFBd0IyRSxJQUFJO01BQzNDN0IsWUFBWSxDQUFDNkIsSUFBSSxLQUFLLFdBQVcsR0FBRyw2Q0FBNkMsR0FBRyw0QkFBNEJBLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQztJQUN4SSxDQUFDLENBQUM7RUFDSixDQUFDLEVBQ0QsQ0FBQzVDLE1BQU0sQ0FDVCxDQUFDO0VBRUQsTUFBTTZDLElBQUksR0FBRyxJQUFBSCxrQkFBVyxFQUNyQkksS0FBYSxJQUFLO0lBQ2pCLElBQUliLEtBQUssQ0FBQ2MsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUN4QixNQUFNM0IsQ0FBQyxHQUFHYSxLQUFLLENBQUNlLFNBQVMsQ0FBRWxCLENBQUMsSUFBS0EsQ0FBQyxDQUFDekQsRUFBRSxLQUFLa0MsVUFBVSxDQUFDO0lBQ3JELE1BQU0wQyxJQUFJLEdBQUc3QixDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUkwQixLQUFLLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBR2IsS0FBSyxDQUFDYyxNQUFNLEdBQUcsQ0FBQyxHQUFJLENBQUMzQixDQUFDLEdBQUcwQixLQUFLLEdBQUdiLEtBQUssQ0FBQ2MsTUFBTSxJQUFJZCxLQUFLLENBQUNjLE1BQU07SUFDeEd2QyxNQUFNLENBQUN5QixLQUFLLENBQUNnQixJQUFJLENBQUMsQ0FBQzVFLEVBQUUsQ0FBQztFQUN4QixDQUFDLEVBQ0QsQ0FBQzRELEtBQUssRUFBRTFCLFVBQVUsRUFBRUMsTUFBTSxDQUM1QixDQUFDO0VBRUQsTUFBTTBDLEtBQUssR0FBRyxJQUFBUixrQkFBVyxFQUN0QnpFLENBQXNCLElBQUs7SUFDMUIsTUFBTWtGLENBQUMsR0FBR2xGLENBQUMsQ0FBQ21GLE1BQTRCO0lBQ3hDLElBQUlELENBQUMsS0FBS0EsQ0FBQyxDQUFDRSxPQUFPLEtBQUssT0FBTyxJQUFJRixDQUFDLENBQUNFLE9BQU8sS0FBSyxVQUFVLENBQUMsRUFBRTtJQUM5RCxJQUFJcEYsQ0FBQyxDQUFDcUYsR0FBRyxLQUFLLElBQUksRUFBRTtNQUNsQnJGLENBQUMsQ0FBQ3NGLGNBQWMsQ0FBQyxDQUFDO01BQ2xCVixJQUFJLENBQUM1RSxDQUFDLENBQUN1RixRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzNCLENBQUMsTUFBTSxJQUFJdkYsQ0FBQyxDQUFDcUYsR0FBRyxLQUFLLEdBQUcsSUFBSXJGLENBQUMsQ0FBQ3FGLEdBQUcsS0FBSyxHQUFHLEVBQUU7TUFDekNyRixDQUFDLENBQUNzRixjQUFjLENBQUMsQ0FBQztNQUNsQlYsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNULENBQUMsTUFBTSxJQUFJNUUsQ0FBQyxDQUFDcUYsR0FBRyxLQUFLLEdBQUcsSUFBSXJGLENBQUMsQ0FBQ3FGLEdBQUcsS0FBSyxHQUFHLEVBQUU7TUFDekNyRixDQUFDLENBQUNzRixjQUFjLENBQUMsQ0FBQztNQUNsQlYsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1YsQ0FBQyxNQUFNLElBQUk1RSxDQUFDLENBQUNxRixHQUFHLEtBQUssT0FBTyxJQUFJZCxRQUFRLEVBQUU7TUFDeEN2RSxDQUFDLENBQUNzRixjQUFjLENBQUMsQ0FBQztNQUNsQjdFLElBQUksQ0FBQzhELFFBQVEsQ0FBQztJQUNoQjtFQUNGLENBQUMsRUFDRCxDQUFDSyxJQUFJLEVBQUVMLFFBQVEsRUFBRTlELElBQUksQ0FDdkIsQ0FBQztFQUVELE1BQU0rRSxlQUFlLEdBQUd6QyxHQUFHLENBQUN1QixNQUFNLENBQUVULENBQUMsSUFBS0EsQ0FBQyxDQUFDRSxNQUFNLEtBQUssT0FBTyxDQUFDLENBQUNlLE1BQU07RUFDdEUsTUFBTVcsS0FBSyxHQUFHdkQsSUFBSSxLQUFLLElBQUksSUFBSUQsTUFBTSxDQUFDeUQsS0FBSyxLQUFLLE1BQU0sSUFBSSxJQUFBQyxnQkFBVyxFQUFDekQsSUFBSSxFQUFFc0QsZUFBZSxDQUFDO0VBQzVGLE1BQU1JLE9BQU8sR0FBR3ZELEtBQUssQ0FBQ3lDLE1BQU0sR0FBRyxDQUFDO0VBRWhDLG9CQUNFLElBQUFsRixXQUFBLENBQUFpRyxJQUFBO0lBQVNDLFNBQVMsRUFBQyxRQUFRO0lBQUMsY0FBVyxjQUFjO0lBQUNDLFNBQVMsRUFBRWQsS0FBTTtJQUFDZSxRQUFRLEVBQUUsQ0FBQyxDQUFFO0lBQUFDLFFBQUEsZ0JBQ25GLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO01BQUtKLFNBQVMsRUFBQyxNQUFNO01BQUNLLElBQUksRUFBQyxTQUFTO01BQUMsY0FBVyxNQUFNO01BQUFGLFFBQUEsRUFDbkQ5RixJQUFJLENBQUMrQyxHQUFHLENBQUVnQyxDQUFDLGlCQUNWLElBQUF0RixXQUFBLENBQUFpRyxJQUFBO1FBQW1CTyxJQUFJLEVBQUMsUUFBUTtRQUFDRCxJQUFJLEVBQUMsS0FBSztRQUFDTCxTQUFTLEVBQUMsS0FBSztRQUFDLGlCQUFlckQsR0FBRyxLQUFLeUMsQ0FBQyxDQUFDOUUsRUFBRztRQUFDaUcsT0FBTyxFQUFFQSxDQUFBLEtBQU0zRCxNQUFNLENBQUN3QyxDQUFDLENBQUM5RSxFQUFFLENBQUU7UUFBQTZGLFFBQUEsR0FDbEhmLENBQUMsQ0FBQzdFLEtBQUssRUFDUDZFLENBQUMsQ0FBQzlFLEVBQUUsS0FBSyxVQUFVLGlCQUFJLElBQUFSLFdBQUEsQ0FBQXNHLEdBQUE7VUFBTUosU0FBUyxFQUFDLEdBQUc7VUFBQUcsUUFBQSxFQUFFeEMsU0FBUyxDQUFDeUIsQ0FBQyxDQUFDOUUsRUFBRTtRQUFDLENBQU8sQ0FBQztNQUFBLEdBRnpEOEUsQ0FBQyxDQUFDOUUsRUFHUCxDQUNUO0lBQUMsQ0FDQyxDQUFDLGVBRU4sSUFBQVIsV0FBQSxDQUFBaUcsSUFBQTtNQUFLQyxTQUFTLEVBQUMsUUFBUTtNQUFBRyxRQUFBLGdCQUNyQixJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtRQUFLSixTQUFTLEVBQUMsT0FBTztRQUFDSyxJQUFJLEVBQUMsT0FBTztRQUFDLGNBQVcsV0FBVztRQUFBRixRQUFBLEVBQ3ZEM0YsTUFBTSxDQUFDNEMsR0FBRyxDQUFFckMsQ0FBQyxpQkFDWixJQUFBakIsV0FBQSxDQUFBc0csR0FBQTtVQUFnQkUsSUFBSSxFQUFDLFFBQVE7VUFBQyxnQkFBY3pELEtBQUssS0FBSzlCLENBQUU7VUFBQ3dGLE9BQU8sRUFBRUEsQ0FBQSxLQUFNekQsUUFBUSxDQUFDL0IsQ0FBQyxDQUFFO1VBQUN5RixLQUFLLEVBQUVDLGtCQUFXLENBQUMxRixDQUFDLENBQUU7VUFBQW9GLFFBQUEsRUFDeEcxRixXQUFXLENBQUNNLENBQUM7UUFBQyxHQURKQSxDQUVMLENBQ1Q7TUFBQyxDQUNDLENBQUMsZUFDTixJQUFBakIsV0FBQSxDQUFBaUcsSUFBQTtRQUFRTyxJQUFJLEVBQUMsUUFBUTtRQUFDTixTQUFTLEVBQUMsUUFBUTtRQUFDTyxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLakUsR0FBRyxDQUFDTyxLQUFLLENBQUU7UUFBQzZELFFBQVEsRUFBRXJFLE9BQU8sSUFBSSxDQUFDSyxLQUFNO1FBQUMsYUFBV0wsT0FBUTtRQUFBOEQsUUFBQSxnQkFDdkgsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUEsRUFBQ3ZHLE1BQUEsQ0FBQThHLFFBQVEsSUFBRSxDQUFDLEtBQUMsRUFBQ3RFLE9BQU8sR0FBRyxVQUFVLEdBQUcsS0FBSztNQUFBLENBQ3BDLENBQUMsZUFDVCxJQUFBdkMsV0FBQSxDQUFBaUcsSUFBQTtRQUFLQyxTQUFTLEVBQUMsTUFBTTtRQUFDSyxJQUFJLEVBQUMsUUFBUTtRQUFBRixRQUFBLEdBQ2hDekQsS0FBSyxLQUFLa0UsU0FBUyxpQkFBSSxJQUFBOUcsV0FBQSxDQUFBc0csR0FBQTtVQUFBRCxRQUFBLEVBQU07UUFBK0IsQ0FBTSxDQUFDLEVBQ25FekQsS0FBSyxLQUFLLElBQUksaUJBQUksSUFBQTVDLFdBQUEsQ0FBQXNHLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQXFCLENBQU0sQ0FBQyxFQUNwRGhFLE1BQU0sQ0FBQ3lELEtBQUssS0FBSyxTQUFTLGlCQUFJLElBQUE5RixXQUFBLENBQUFpRyxJQUFBO1VBQUFJLFFBQUEsR0FBTSxVQUFRLEVBQUNNLGtCQUFXLENBQUN0RSxNQUFNLENBQUNVLEtBQUssQ0FBQyxDQUFDZ0UsV0FBVyxDQUFDLENBQUMsRUFBQyxRQUFDO1FBQUEsQ0FBTSxDQUFDLEVBQzdGMUUsTUFBTSxDQUFDeUQsS0FBSyxLQUFLLFFBQVEsaUJBQUksSUFBQTlGLFdBQUEsQ0FBQWlHLElBQUE7VUFBTUMsU0FBUyxFQUFDLE1BQU07VUFBQUcsUUFBQSxHQUFDLHVCQUFXLEVBQUNoRSxNQUFNLENBQUMyRSxLQUFLO1FBQUEsQ0FBTyxDQUFDLEVBQ3BGMUUsSUFBSSxJQUFJRCxNQUFNLENBQUN5RCxLQUFLLEtBQUssU0FBUyxpQkFDakMsSUFBQTlGLFdBQUEsQ0FBQWlHLElBQUEsRUFBQWpHLFdBQUEsQ0FBQWlILFFBQUE7VUFBQVosUUFBQSxnQkFDRSxJQUFBckcsV0FBQSxDQUFBaUcsSUFBQTtZQUFNQyxTQUFTLEVBQUVGLE9BQU8sR0FBRyxNQUFNLEdBQUcxRCxJQUFJLENBQUM0RSxPQUFPLENBQUNoQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxJQUFLO1lBQUFtQixRQUFBLEdBQ3pFTCxPQUFPLEdBQUcsU0FBUyxHQUFHMUQsSUFBSSxDQUFDNEUsT0FBTyxDQUFDaEMsTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLEdBQUcsT0FBTyxFQUFDLEdBQUMsRUFBQ25FLEdBQUcsQ0FBQ1UsR0FBRyxHQUFHYSxJQUFJLENBQUM2RSxTQUFTLENBQUM7VUFBQSxDQUM5RixDQUFDLGVBQ1AsSUFBQW5ILFdBQUEsQ0FBQWlHLElBQUE7WUFBQUksUUFBQSxHQUNHL0QsSUFBSSxDQUFDOEUsS0FBSyxDQUFDQyxLQUFLLEVBQUMsR0FBQyxFQUFDL0UsSUFBSSxDQUFDOEUsS0FBSyxDQUFDQyxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPLEVBQUMsUUFBRyxFQUFDaEcsRUFBRSxDQUFDaUIsSUFBSSxDQUFDOEUsS0FBSyxDQUFDOUYsS0FBSyxDQUFDO1VBQUEsQ0FDbEYsQ0FBQyxlQUNQLElBQUF0QixXQUFBLENBQUFpRyxJQUFBO1lBQUFJLFFBQUEsR0FBTyxDQUFDL0QsSUFBSSxDQUFDZ0YsVUFBVSxHQUFHLElBQUksRUFBRUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUM7VUFBQSxDQUFNLENBQUMsZUFDbkQsSUFBQXZILFdBQUEsQ0FBQWlHLElBQUE7WUFBQUksUUFBQSxHQUNHTSxrQkFBVyxDQUFDckUsSUFBSSxDQUFDUyxLQUFLLENBQUMsQ0FBQ2dFLFdBQVcsQ0FBQyxDQUFDLEVBQ3JDekUsSUFBSSxDQUFDa0YsWUFBWSxHQUFHLEtBQUtiLGtCQUFXLENBQUNyRSxJQUFJLENBQUNrRixZQUFZLENBQUMsQ0FBQ1QsV0FBVyxDQUFDLENBQUMsYUFBYSxHQUFHLEVBQUU7VUFBQSxDQUNwRixDQUFDO1FBQUEsQ0FDUCxDQUNIO01BQUEsQ0FDRSxDQUFDO0lBQUEsQ0FDSCxDQUFDLGVBRU4sSUFBQS9HLFdBQUEsQ0FBQXNHLEdBQUEsRUFBQ3hHLFlBQUEsQ0FBQVEsT0FBVztNQUFDbUMsS0FBSyxFQUFFQSxLQUFNO01BQUNnRixPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLakYsR0FBRyxDQUFDTyxLQUFLLENBQUU7TUFBQ1IsT0FBTyxFQUFFQTtJQUFRLENBQUUsQ0FBQyxFQUU5RVUsU0FBUyxpQkFDUixJQUFBakQsV0FBQSxDQUFBc0csR0FBQTtNQUFHSixTQUFTLEVBQUMsU0FBUztNQUFDSyxJQUFJLEVBQUMsT0FBTztNQUFBRixRQUFBLGVBQ2pDLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO1FBQUFELFFBQUEsRUFBT3BEO01BQVMsQ0FBTztJQUFDLENBQ3ZCLENBQ0osZUFFRCxJQUFBakQsV0FBQSxDQUFBc0csR0FBQTtNQUFLSixTQUFTLEVBQUUsT0FBT0YsT0FBTyxHQUFHLGNBQWMsR0FBRyxFQUFFLEVBQUc7TUFBQUssUUFBQSxFQUNwRDFCLFFBQVEsZ0JBQ1AsSUFBQTNFLFdBQUEsQ0FBQWlHLElBQUEsRUFBQWpHLFdBQUEsQ0FBQWlILFFBQUE7UUFBQVosUUFBQSxnQkFDRSxJQUFBckcsV0FBQSxDQUFBaUcsSUFBQTtVQUFLQyxTQUFTLEVBQUMsV0FBVztVQUFBRyxRQUFBLGdCQUN4QixJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtZQUFNSixTQUFTLEVBQUUsb0JBQW9CdkIsUUFBUSxDQUFDVCxRQUFRLEVBQUc7WUFBQyxlQUFZLE1BQU07WUFBQW1DLFFBQUEsZUFDMUUsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUEsRUFBQ3ZHLE1BQUEsQ0FBQTJILGFBQWE7Y0FBQ3hELFFBQVEsRUFBRVMsUUFBUSxDQUFDVDtZQUFTLENBQUU7VUFBQyxDQUMxQyxDQUFDLGVBQ1AsSUFBQWxFLFdBQUEsQ0FBQWlHLElBQUE7WUFBSzBCLEtBQUssRUFBRTtjQUFFQyxRQUFRLEVBQUU7WUFBRSxDQUFFO1lBQUF2QixRQUFBLGdCQUMxQixJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtjQUFBRCxRQUFBLEVBQUsxQixRQUFRLENBQUNrRDtZQUFPLENBQUssQ0FBQyxlQUMzQixJQUFBN0gsV0FBQSxDQUFBc0csR0FBQTtjQUFHSixTQUFTLEVBQUMsWUFBWTtjQUFBRyxRQUFBLEVBQUUxQixRQUFRLENBQUNtRCxJQUFJLEtBQUssSUFBSSxHQUFHLGtCQUFrQixHQUFHLEdBQUduRCxRQUFRLENBQUNtRCxJQUFJLElBQUluRCxRQUFRLENBQUNvRCxJQUFJLElBQUlwRCxRQUFRLENBQUNxRCxNQUFNO1lBQUUsQ0FBSSxDQUFDLGVBQ3BJLElBQUFoSSxXQUFBLENBQUFpRyxJQUFBO2NBQUtDLFNBQVMsRUFBQyxRQUFRO2NBQUFHLFFBQUEsZ0JBQ3JCLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO2dCQUFNSixTQUFTLEVBQUMsS0FBSztnQkFBQUcsUUFBQSxFQUFFMUIsUUFBUSxDQUFDUjtjQUFNLENBQU8sQ0FBQyxFQUM3Q1EsUUFBUSxDQUFDSSxJQUFJLGlCQUFJLElBQUEvRSxXQUFBLENBQUFzRyxHQUFBO2dCQUFNSixTQUFTLEVBQUMsS0FBSztnQkFBQUcsUUFBQSxFQUFFMUIsUUFBUSxDQUFDSTtjQUFJLENBQU8sQ0FBQyxlQUM5RCxJQUFBL0UsV0FBQSxDQUFBc0csR0FBQTtnQkFBTUosU0FBUyxFQUFDLEtBQUs7Z0JBQUFHLFFBQUEsRUFBRTFCLFFBQVEsQ0FBQ1Q7Y0FBUSxDQUFPLENBQUMsRUFDL0NTLFFBQVEsQ0FBQ3NELElBQUksaUJBQUksSUFBQWpJLFdBQUEsQ0FBQXNHLEdBQUE7Z0JBQU1KLFNBQVMsRUFBQyxLQUFLO2dCQUFBRyxRQUFBLEVBQUUxQixRQUFRLENBQUNzRDtjQUFJLENBQU8sQ0FBQztZQUFBLENBQzNELENBQUM7VUFBQSxDQUNILENBQUM7UUFBQSxDQUNILENBQUMsZUFDTixJQUFBakksV0FBQSxDQUFBc0csR0FBQSxFQUFDMUcsVUFBQSxDQUFBVSxPQUFTO1VBQUM0SCxVQUFVLEVBQUV2RCxRQUFTO1VBQUN2QyxRQUFRLEVBQUVBO1FBQVMsQ0FBRSxDQUFDLGVBQ3ZELElBQUFwQyxXQUFBLENBQUFpRyxJQUFBO1VBQUtDLFNBQVMsRUFBQyxTQUFTO1VBQUFHLFFBQUEsZ0JBQ3RCLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO1lBQVFFLElBQUksRUFBQyxRQUFRO1lBQUNOLFNBQVMsRUFBQyxrQkFBa0I7WUFBQ08sT0FBTyxFQUFFQSxDQUFBLEtBQU01RixJQUFJLENBQUM4RCxRQUFRLENBQUU7WUFBQ2lDLFFBQVEsRUFBRWpDLFFBQVEsQ0FBQ21ELElBQUksS0FBSyxJQUFLO1lBQUF6QixRQUFBLEVBQUM7VUFFcEgsQ0FBUSxDQUFDLGVBQ1QsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUE7WUFDRUUsSUFBSSxFQUFDLFFBQVE7WUFDYk4sU0FBUyxFQUFDLEtBQUs7WUFDZk8sT0FBTyxFQUFFQSxDQUFBLEtBQU07Y0FDYixLQUFLMEIsU0FBUyxDQUFDQyxTQUFTLEVBQUVDLFNBQVMsQ0FBQyxHQUFHMUQsUUFBUSxDQUFDbUQsSUFBSSxJQUFJLEVBQUUsR0FBR25ELFFBQVEsQ0FBQ29ELElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSXBELFFBQVEsQ0FBQ29ELElBQUksSUFBSXBELFFBQVEsQ0FBQ3FELE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSXJELFFBQVEsQ0FBQ2tELE9BQU8sRUFBRSxDQUFDUyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUN4RCxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNqTCxDQUFFO1lBQUF1QixRQUFBLEVBQ0g7VUFFRCxDQUFRLENBQUMsZUFDVCxJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtZQUFNSixTQUFTLEVBQUMsTUFBTTtZQUFBRyxRQUFBLEVBQUM7VUFBK0MsQ0FBTSxDQUFDO1FBQUEsQ0FDMUUsQ0FBQztNQUFBLENBQ04sQ0FBQyxnQkFFSCxJQUFBckcsV0FBQSxDQUFBc0csR0FBQSxFQUFDaUMsT0FBTztRQUFDdEcsT0FBTyxFQUFFQSxPQUFRO1FBQUMwQixNQUFNLEVBQUVBLE1BQU87UUFBQ2tDLEtBQUssRUFBRUEsS0FBTTtRQUFDaEQsR0FBRyxFQUFFQSxHQUFJO1FBQUNnQixTQUFTLEVBQUVBLFNBQVU7UUFBQ08sS0FBSyxFQUFFQTtNQUFNLENBQUU7SUFDekcsQ0FDRSxDQUFDO0VBQUEsQ0FDQyxDQUFDO0FBRWQ7QUFBQ2pFLEdBQUEsQ0EzS3VCNkIsVUFBVTtFQUFBLFFBS3BCVCxNQUFNO0FBQUE7QUFBQWlILEVBQUEsR0FMSXhHLFVBQVU7QUE2S2xDLFNBQVN1RyxPQUFPQSxDQUFDO0VBQ2Z0RyxPQUFPO0VBQ1AwQixNQUFNO0VBQ05rQyxLQUFLO0VBQ0xoRCxHQUFHO0VBQ0hnQixTQUFTO0VBQ1RPO0FBUUYsQ0FBQyxFQUFFO0VBQ0QsTUFBTTtJQUFFL0IsTUFBTTtJQUFFQyxJQUFJO0lBQUVNO0VBQU0sQ0FBQyxHQUFHWCxPQUFPO0VBQ3ZDLElBQUlXLEtBQUssS0FBSyxJQUFJLEVBQUU7SUFDbEIsb0JBQ0UsSUFBQTVDLFdBQUEsQ0FBQWlHLElBQUE7TUFBR0MsU0FBUyxFQUFDLE9BQU87TUFBQUcsUUFBQSxnQkFDbEIsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUE7UUFBQUQsUUFBQSxFQUFHO01BQXFCLENBQUcsQ0FBQyxtSEFDOUI7SUFBQSxDQUFHLENBQUM7RUFFUjtFQUNBLElBQUksQ0FBQy9ELElBQUksSUFBSUQsTUFBTSxDQUFDeUQsS0FBSyxLQUFLLFNBQVMsRUFBRTtJQUN2QyxvQkFBTyxJQUFBOUYsV0FBQSxDQUFBc0csR0FBQTtNQUFHSixTQUFTLEVBQUMsT0FBTztNQUFBRyxRQUFBLEVBQUM7SUFBaUYsQ0FBRyxDQUFDO0VBQ25IO0VBQ0Esb0JBQ0UsSUFBQXJHLFdBQUEsQ0FBQWlHLElBQUEsRUFBQWpHLFdBQUEsQ0FBQWlILFFBQUE7SUFBQVosUUFBQSxnQkFDRSxJQUFBckcsV0FBQSxDQUFBaUcsSUFBQTtNQUFLQyxTQUFTLEVBQUMsY0FBYztNQUFBRyxRQUFBLGdCQUMzQixJQUFBckcsV0FBQSxDQUFBaUcsSUFBQTtRQUFLQyxTQUFTLEVBQUMsTUFBTTtRQUFBRyxRQUFBLGdCQUNuQixJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtVQUFLSixTQUFTLEVBQUMsS0FBSztVQUFBRyxRQUFBLEVBQUM7UUFBTSxDQUFLLENBQUMsZUFDakMsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUE7VUFBS0osU0FBUyxFQUFDLFNBQVM7VUFBQUcsUUFBQSxFQUFFMUMsTUFBTSxDQUFDOEU7UUFBTSxDQUFNLENBQUM7TUFBQSxDQUMzQyxDQUFDLGVBQ04sSUFBQXpJLFdBQUEsQ0FBQWlHLElBQUE7UUFBS0MsU0FBUyxFQUFDLE1BQU07UUFBQUcsUUFBQSxnQkFDbkIsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUE7VUFBS0osU0FBUyxFQUFDLEtBQUs7VUFBQUcsUUFBQSxFQUFDO1FBQVEsQ0FBSyxDQUFDLGVBQ25DLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO1VBQUtKLFNBQVMsRUFBQyxVQUFVO1VBQUFHLFFBQUEsRUFBRTFDLE1BQU0sQ0FBQytFO1FBQVEsQ0FBTSxDQUFDO01BQUEsQ0FDOUMsQ0FBQyxlQUNOLElBQUExSSxXQUFBLENBQUFpRyxJQUFBO1FBQUtDLFNBQVMsRUFBQyxNQUFNO1FBQUFHLFFBQUEsZ0JBQ25CLElBQUFyRyxXQUFBLENBQUFzRyxHQUFBO1VBQUtKLFNBQVMsRUFBQyxLQUFLO1VBQUFHLFFBQUEsRUFBQztRQUFLLENBQUssQ0FBQyxlQUNoQyxJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtVQUFLSixTQUFTLEVBQUMsVUFBVTtVQUFBRyxRQUFBLEVBQUUxQyxNQUFNLENBQUNnRjtRQUFLLENBQU0sQ0FBQztNQUFBLENBQzNDLENBQUM7SUFBQSxDQUNILENBQUMsRUFDTDlDLEtBQUssaUJBQ0osSUFBQTdGLFdBQUEsQ0FBQWlHLElBQUE7TUFBR0MsU0FBUyxFQUFDLGlCQUFpQjtNQUFDLGNBQVcsTUFBTTtNQUFBRyxRQUFBLGdCQUM5QyxJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtRQUFBRCxRQUFBLEVBQUc7TUFBVyxDQUFHLENBQUMsUUFBSSxFQUFDL0QsSUFBSSxHQUFHcUUsa0JBQVcsQ0FBQ3JFLElBQUksQ0FBQ1MsS0FBSyxDQUFDLENBQUNnRSxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBQyxVQUFHLEVBQUN6RSxJQUFJLEVBQUU4RSxLQUFLLENBQUNDLEtBQUssSUFBSSxDQUFDLEVBQUMsR0FBQyxFQUFDL0UsSUFBSSxFQUFFOEUsS0FBSyxDQUFDQyxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPLEVBQUMsV0FDbko7SUFBQSxDQUFHLENBQ0osRUFDQS9FLElBQUksSUFBSUEsSUFBSSxDQUFDNEUsT0FBTyxDQUFDaEMsTUFBTSxHQUFHLENBQUMsaUJBQzlCLElBQUFsRixXQUFBLENBQUFpRyxJQUFBO01BQUFJLFFBQUEsZ0JBQ0UsSUFBQXJHLFdBQUEsQ0FBQXNHLEdBQUE7UUFBSUosU0FBUyxFQUFDLGVBQWU7UUFBQUcsUUFBQSxFQUFDO01BQXdDLENBQUksQ0FBQyxlQUMzRSxJQUFBckcsV0FBQSxDQUFBc0csR0FBQTtRQUFJSixTQUFTLEVBQUMsY0FBYztRQUFBRyxRQUFBLEVBQ3pCL0QsSUFBSSxDQUFDNEUsT0FBTyxDQUFDNUQsR0FBRyxDQUFDLENBQUNzRixDQUFDLEVBQUVyRixDQUFDLGtCQUNyQixJQUFBdkQsV0FBQSxDQUFBc0csR0FBQTtVQUEyQixhQUFXc0MsQ0FBQyxDQUFDQyxJQUFLO1VBQUF4QyxRQUFBLEVBQzFDdUMsQ0FBQyxDQUFDRTtRQUFNLEdBREYsR0FBR0YsQ0FBQyxDQUFDQyxJQUFJLElBQUl0RixDQUFDLEVBRW5CLENBQ0w7TUFBQyxDQUNBLENBQUM7SUFBQSxDQUNGLENBQ04sRUFDQVYsR0FBRyxLQUFLLFVBQVUsaUJBQ2pCLElBQUE3QyxXQUFBLENBQUFpRyxJQUFBO01BQUdDLFNBQVMsRUFBQyxPQUFPO01BQUFHLFFBQUEsR0FDakJ4QyxTQUFTLENBQUNoQixHQUFHLENBQUMsRUFBQyxHQUFDLEVBQUNBLEdBQUcsRUFBQyxHQUFDLEVBQUNnQixTQUFTLENBQUNoQixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsU0FBUyxHQUFHLFVBQVUsRUFDcEV1QixLQUFLLENBQUNjLE1BQU0sR0FBRyxDQUFDLEdBQUcsd0NBQXdDLEdBQUcsR0FBRztJQUFBLENBQ2pFLENBQ0o7RUFBQSxDQUNELENBQUM7QUFFUDtBQUFDNkQsR0FBQSxHQW5FUVIsT0FBTztBQUFBLElBQUFDLEVBQUEsRUFBQU8sR0FBQTtBQUFBQyxZQUFBLENBQUFSLEVBQUE7QUFBQVEsWUFBQSxDQUFBRCxHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}