var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Placeholder;
var _jsxRuntime = require("react/jsx-runtime");
// A labelled placeholder. Deliberately says WHICH region rendered it and WHICH work
// item fills it in: the point of R3-386 is to prove the binding resolves and the
// right half renders in the right slot, and a blank panel cannot show either.
function Placeholder({
  region,
  title,
  detail,
  item
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "ph",
    "aria-labelledby": "ph-title",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ph-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
        className: "ph-title",
        id: "ph-title",
        children: title
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        className: "ph-region",
        children: region ?? 'standalone'
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "ph-detail",
      children: detail
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "ph-item",
      children: ["Not built yet \u2014 ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        children: item
      })]
    })]
  });
}
_c = Placeholder;
var _c;
$RefreshReg$(_c, "Placeholder");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQbGFjZWhvbGRlciIsInJlZ2lvbiIsInRpdGxlIiwiZGV0YWlsIiwiaXRlbSIsIl9qc3hSdW50aW1lIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBsYWNlaG9sZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBIGxhYmVsbGVkIHBsYWNlaG9sZGVyLiBEZWxpYmVyYXRlbHkgc2F5cyBXSElDSCByZWdpb24gcmVuZGVyZWQgaXQgYW5kIFdISUNIIHdvcmtcbi8vIGl0ZW0gZmlsbHMgaXQgaW46IHRoZSBwb2ludCBvZiBSMy0zODYgaXMgdG8gcHJvdmUgdGhlIGJpbmRpbmcgcmVzb2x2ZXMgYW5kIHRoZVxuLy8gcmlnaHQgaGFsZiByZW5kZXJzIGluIHRoZSByaWdodCBzbG90LCBhbmQgYSBibGFuayBwYW5lbCBjYW5ub3Qgc2hvdyBlaXRoZXIuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQbGFjZWhvbGRlcih7XG4gIHJlZ2lvbixcbiAgdGl0bGUsXG4gIGRldGFpbCxcbiAgaXRlbSxcbn06IHtcbiAgcmVnaW9uOiBzdHJpbmcgfCBudWxsO1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXRhaWw6IHN0cmluZztcbiAgaXRlbTogc3RyaW5nO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBoXCIgYXJpYS1sYWJlbGxlZGJ5PVwicGgtdGl0bGVcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicGgtaGRcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInBoLXRpdGxlXCIgaWQ9XCJwaC10aXRsZVwiPlxuICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgPC9oMT5cbiAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwicGgtcmVnaW9uXCI+e3JlZ2lvbiA/PyAnc3RhbmRhbG9uZSd9PC9jb2RlPlxuICAgICAgPC9oZWFkZXI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJwaC1kZXRhaWxcIj57ZGV0YWlsfTwvcD5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInBoLWl0ZW1cIj5cbiAgICAgICAgTm90IGJ1aWx0IHlldCDigJQgPGNvZGU+e2l0ZW19PC9jb2RlPlxuICAgICAgPC9wPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNlLFNBQVNBLFdBQVdBLENBQUM7RUFDbENDLE1BQU07RUFDTkMsS0FBSztFQUNMQyxNQUFNO0VBQ05DO0FBTUYsQ0FBQyxFQUFFO0VBQ0Qsb0JBQ0UsSUFBQUMsV0FBQSxDQUFBQyxJQUFBO0lBQVNDLFNBQVMsRUFBQyxJQUFJO0lBQUMsbUJBQWdCLFVBQVU7SUFBQUMsUUFBQSxnQkFDaEQsSUFBQUgsV0FBQSxDQUFBQyxJQUFBO01BQVFDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ3ZCLElBQUFILFdBQUEsQ0FBQUksR0FBQTtRQUFJRixTQUFTLEVBQUMsVUFBVTtRQUFDRyxFQUFFLEVBQUMsVUFBVTtRQUFBRixRQUFBLEVBQ25DTjtNQUFLLENBQ0osQ0FBQyxlQUNMLElBQUFHLFdBQUEsQ0FBQUksR0FBQTtRQUFNRixTQUFTLEVBQUMsV0FBVztRQUFBQyxRQUFBLEVBQUVQLE1BQU0sSUFBSTtNQUFZLENBQU8sQ0FBQztJQUFBLENBQ3JELENBQUMsZUFDVCxJQUFBSSxXQUFBLENBQUFJLEdBQUE7TUFBR0YsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxFQUFFTDtJQUFNLENBQUksQ0FBQyxlQUNyQyxJQUFBRSxXQUFBLENBQUFDLElBQUE7TUFBR0MsU0FBUyxFQUFDLFNBQVM7TUFBQUMsUUFBQSxHQUFDLHVCQUNMLG1CQUFBSCxXQUFBLENBQUFJLEdBQUE7UUFBQUQsUUFBQSxFQUFPSjtNQUFJLENBQU8sQ0FBQztJQUFBLENBQ2xDLENBQUM7RUFBQSxDQUNHLENBQUM7QUFFZDtBQUFDTyxFQUFBLEdBekJ1QlgsV0FBVztBQUFBLElBQUFXLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}