var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ClockIcon = ClockIcon;
exports.FilterIcon = FilterIcon;
exports.PlayIcon = PlayIcon;
exports.SeverityGlyph = SeverityGlyph;
exports.TriangleIcon = TriangleIcon;
var _jsxRuntime = require("react/jsx-runtime");
// Inline glyphs — the panel is an opaque-origin iframe, so nothing from the host's
// icon set is reachable; these mirror the approved design's strokes.

const stroke = {
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2
};
function PlayIcon() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("svg", {
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: "M7 4.5v15l13-7.5z"
    })
  });
}
_c = PlayIcon;
function FilterIcon() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("svg", {
    viewBox: "0 0 24 24",
    ...stroke,
    "aria-hidden": "true",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: "M4 5h16l-6 7v6l-4 2v-8z"
    })
  });
}
_c2 = FilterIcon;
function TriangleIcon() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("svg", {
    className: "tri",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: "M8 4l10 8-10 8z"
    })
  });
}
_c3 = TriangleIcon;
function ClockIcon() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
    viewBox: "0 0 24 24",
    ...stroke,
    "aria-hidden": "true",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: "M12 7v5l3 2"
    })]
  });
}
_c4 = ClockIcon;
function SeverityGlyph({
  severity
}) {
  if (severity === 'error') {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
      viewBox: "0 0 24 24",
      ...stroke,
      strokeWidth: 2.4,
      "aria-hidden": "true",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
        d: "M12 7v6M12 16.5v.5"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
        cx: "12",
        cy: "12",
        r: "9"
      })]
    });
  }
  if (severity === 'warning') {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
      viewBox: "0 0 24 24",
      ...stroke,
      strokeWidth: 2.4,
      "aria-hidden": "true",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
        d: "M12 3.5 21.5 20h-19z"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
        d: "M12 10v4M12 17v.5"
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
    viewBox: "0 0 24 24",
    ...stroke,
    strokeWidth: 2.4,
    "aria-hidden": "true",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: "M12 11v5M12 8v.5"
    })]
  });
}
_c5 = SeverityGlyph;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "PlayIcon");
$RefreshReg$(_c2, "FilterIcon");
$RefreshReg$(_c3, "TriangleIcon");
$RefreshReg$(_c4, "ClockIcon");
$RefreshReg$(_c5, "SeverityGlyph");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJzdHJva2UiLCJmaWxsIiwic3Ryb2tlV2lkdGgiLCJQbGF5SWNvbiIsIl9qc3hSdW50aW1lIiwianN4Iiwidmlld0JveCIsImNoaWxkcmVuIiwiZCIsIl9jIiwiRmlsdGVySWNvbiIsIl9jMiIsIlRyaWFuZ2xlSWNvbiIsImNsYXNzTmFtZSIsIl9jMyIsIkNsb2NrSWNvbiIsImpzeHMiLCJjeCIsImN5IiwiciIsIl9jNCIsIlNldmVyaXR5R2x5cGgiLCJzZXZlcml0eSIsIl9jNSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkljb25zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbmxpbmUgZ2x5cGhzIOKAlCB0aGUgcGFuZWwgaXMgYW4gb3BhcXVlLW9yaWdpbiBpZnJhbWUsIHNvIG5vdGhpbmcgZnJvbSB0aGUgaG9zdCdzXG4vLyBpY29uIHNldCBpcyByZWFjaGFibGU7IHRoZXNlIG1pcnJvciB0aGUgYXBwcm92ZWQgZGVzaWduJ3Mgc3Ryb2tlcy5cbmltcG9ydCB0eXBlIHsgU2V2ZXJpdHkgfSBmcm9tICcuLi9saWIvZGlhZ25vc3RpY3MnO1xuXG5jb25zdCBzdHJva2UgPSB7IGZpbGw6ICdub25lJywgc3Ryb2tlOiAnY3VycmVudENvbG9yJywgc3Ryb2tlV2lkdGg6IDIgfSBhcyBjb25zdDtcblxuZXhwb3J0IGZ1bmN0aW9uIFBsYXlJY29uKCkge1xuICByZXR1cm4gKFxuICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIDxwYXRoIGQ9XCJNNyA0LjV2MTVsMTMtNy41elwiIC8+XG4gICAgPC9zdmc+XG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJJY29uKCkge1xuICByZXR1cm4gKFxuICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIHsuLi5zdHJva2V9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgPHBhdGggZD1cIk00IDVoMTZsLTYgN3Y2bC00IDJ2LTh6XCIgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRyaWFuZ2xlSWNvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnIGNsYXNzTmFtZT1cInRyaVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwiY3VycmVudENvbG9yXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICA8cGF0aCBkPVwiTTggNGwxMCA4LTEwIDh6XCIgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENsb2NrSWNvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB7Li4uc3Ryb2tlfSBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOVwiIC8+XG4gICAgICA8cGF0aCBkPVwiTTEyIDd2NWwzIDJcIiAvPlxuICAgIDwvc3ZnPlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gU2V2ZXJpdHlHbHlwaCh7IHNldmVyaXR5IH06IHsgc2V2ZXJpdHk6IFNldmVyaXR5IH0pIHtcbiAgaWYgKHNldmVyaXR5ID09PSAnZXJyb3InKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIHsuLi5zdHJva2V9IHN0cm9rZVdpZHRoPXsyLjR9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICA8cGF0aCBkPVwiTTEyIDd2Nk0xMiAxNi41di41XCIgLz5cbiAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCI5XCIgLz5cbiAgICAgIDwvc3ZnPlxuICAgICk7XG4gIH1cbiAgaWYgKHNldmVyaXR5ID09PSAnd2FybmluZycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgey4uLnN0cm9rZX0gc3Ryb2tlV2lkdGg9ezIuNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgIDxwYXRoIGQ9XCJNMTIgMy41IDIxLjUgMjBoLTE5elwiIC8+XG4gICAgICAgIDxwYXRoIGQ9XCJNMTIgMTB2NE0xMiAxN3YuNVwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICApO1xuICB9XG4gIHJldHVybiAoXG4gICAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgey4uLnN0cm9rZX0gc3Ryb2tlV2lkdGg9ezIuNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjlcIiAvPlxuICAgICAgPHBhdGggZD1cIk0xMiAxMXY1TTEyIDh2LjVcIiAvPlxuICAgIDwvc3ZnPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBO0FBQ0E7O0FBR0EsTUFBTUEsTUFBTSxHQUFHO0VBQUVDLElBQUksRUFBRSxNQUFNO0VBQUVELE1BQU0sRUFBRSxjQUFjO0VBQUVFLFdBQVcsRUFBRTtBQUFFLENBQVU7QUFFekUsU0FBU0MsUUFBUUEsQ0FBQSxFQUFHO0VBQ3pCLG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFLQyxPQUFPLEVBQUMsV0FBVztJQUFDTCxJQUFJLEVBQUMsY0FBYztJQUFDLGVBQVksTUFBTTtJQUFBTSxRQUFBLGVBQzdELElBQUFILFdBQUEsQ0FBQUMsR0FBQTtNQUFNRyxDQUFDLEVBQUM7SUFBbUIsQ0FBRTtFQUFDLENBQzNCLENBQUM7QUFFVjtBQUFDQyxFQUFBLEdBTmVOLFFBQVE7QUFRakIsU0FBU08sVUFBVUEsQ0FBQSxFQUFHO0VBQzNCLG9CQUNFLElBQUFOLFdBQUEsQ0FBQUMsR0FBQTtJQUFLQyxPQUFPLEVBQUMsV0FBVztJQUFBLEdBQUtOLE1BQU07SUFBRSxlQUFZLE1BQU07SUFBQU8sUUFBQSxlQUNyRCxJQUFBSCxXQUFBLENBQUFDLEdBQUE7TUFBTUcsQ0FBQyxFQUFDO0lBQXlCLENBQUU7RUFBQyxDQUNqQyxDQUFDO0FBRVY7QUFBQ0csR0FBQSxHQU5lRCxVQUFVO0FBUW5CLFNBQVNFLFlBQVlBLENBQUEsRUFBRztFQUM3QixvQkFDRSxJQUFBUixXQUFBLENBQUFDLEdBQUE7SUFBS1EsU0FBUyxFQUFDLEtBQUs7SUFBQ1AsT0FBTyxFQUFDLFdBQVc7SUFBQ0wsSUFBSSxFQUFDLGNBQWM7SUFBQyxlQUFZLE1BQU07SUFBQU0sUUFBQSxlQUM3RSxJQUFBSCxXQUFBLENBQUFDLEdBQUE7TUFBTUcsQ0FBQyxFQUFDO0lBQWlCLENBQUU7RUFBQyxDQUN6QixDQUFDO0FBRVY7QUFBQ00sR0FBQSxHQU5lRixZQUFZO0FBUXJCLFNBQVNHLFNBQVNBLENBQUEsRUFBRztFQUMxQixvQkFDRSxJQUFBWCxXQUFBLENBQUFZLElBQUE7SUFBS1YsT0FBTyxFQUFDLFdBQVc7SUFBQSxHQUFLTixNQUFNO0lBQUUsZUFBWSxNQUFNO0lBQUFPLFFBQUEsZ0JBQ3JELElBQUFILFdBQUEsQ0FBQUMsR0FBQTtNQUFRWSxFQUFFLEVBQUMsSUFBSTtNQUFDQyxFQUFFLEVBQUMsSUFBSTtNQUFDQyxDQUFDLEVBQUM7SUFBRyxDQUFFLENBQUMsZUFDaEMsSUFBQWYsV0FBQSxDQUFBQyxHQUFBO01BQU1HLENBQUMsRUFBQztJQUFhLENBQUUsQ0FBQztFQUFBLENBQ3JCLENBQUM7QUFFVjtBQUFDWSxHQUFBLEdBUGVMLFNBQVM7QUFTbEIsU0FBU00sYUFBYUEsQ0FBQztFQUFFQztBQUFpQyxDQUFDLEVBQUU7RUFDbEUsSUFBSUEsUUFBUSxLQUFLLE9BQU8sRUFBRTtJQUN4QixvQkFDRSxJQUFBbEIsV0FBQSxDQUFBWSxJQUFBO01BQUtWLE9BQU8sRUFBQyxXQUFXO01BQUEsR0FBS04sTUFBTTtNQUFFRSxXQUFXLEVBQUUsR0FBSTtNQUFDLGVBQVksTUFBTTtNQUFBSyxRQUFBLGdCQUN2RSxJQUFBSCxXQUFBLENBQUFDLEdBQUE7UUFBTUcsQ0FBQyxFQUFDO01BQW9CLENBQUUsQ0FBQyxlQUMvQixJQUFBSixXQUFBLENBQUFDLEdBQUE7UUFBUVksRUFBRSxFQUFDLElBQUk7UUFBQ0MsRUFBRSxFQUFDLElBQUk7UUFBQ0MsQ0FBQyxFQUFDO01BQUcsQ0FBRSxDQUFDO0lBQUEsQ0FDN0IsQ0FBQztFQUVWO0VBQ0EsSUFBSUcsUUFBUSxLQUFLLFNBQVMsRUFBRTtJQUMxQixvQkFDRSxJQUFBbEIsV0FBQSxDQUFBWSxJQUFBO01BQUtWLE9BQU8sRUFBQyxXQUFXO01BQUEsR0FBS04sTUFBTTtNQUFFRSxXQUFXLEVBQUUsR0FBSTtNQUFDLGVBQVksTUFBTTtNQUFBSyxRQUFBLGdCQUN2RSxJQUFBSCxXQUFBLENBQUFDLEdBQUE7UUFBTUcsQ0FBQyxFQUFDO01BQXNCLENBQUUsQ0FBQyxlQUNqQyxJQUFBSixXQUFBLENBQUFDLEdBQUE7UUFBTUcsQ0FBQyxFQUFDO01BQW1CLENBQUUsQ0FBQztJQUFBLENBQzNCLENBQUM7RUFFVjtFQUNBLG9CQUNFLElBQUFKLFdBQUEsQ0FBQVksSUFBQTtJQUFLVixPQUFPLEVBQUMsV0FBVztJQUFBLEdBQUtOLE1BQU07SUFBRUUsV0FBVyxFQUFFLEdBQUk7SUFBQyxlQUFZLE1BQU07SUFBQUssUUFBQSxnQkFDdkUsSUFBQUgsV0FBQSxDQUFBQyxHQUFBO01BQVFZLEVBQUUsRUFBQyxJQUFJO01BQUNDLEVBQUUsRUFBQyxJQUFJO01BQUNDLENBQUMsRUFBQztJQUFHLENBQUUsQ0FBQyxlQUNoQyxJQUFBZixXQUFBLENBQUFDLEdBQUE7TUFBTUcsQ0FBQyxFQUFDO0lBQWtCLENBQUUsQ0FBQztFQUFBLENBQzFCLENBQUM7QUFFVjtBQUFDZSxHQUFBLEdBdkJlRixhQUFhO0FBQUEsSUFBQVosRUFBQSxFQUFBRSxHQUFBLEVBQUFHLEdBQUEsRUFBQU0sR0FBQSxFQUFBRyxHQUFBO0FBQUFDLFlBQUEsQ0FBQWYsRUFBQTtBQUFBZSxZQUFBLENBQUFiLEdBQUE7QUFBQWEsWUFBQSxDQUFBVixHQUFBO0FBQUFVLFlBQUEsQ0FBQUosR0FBQTtBQUFBSSxZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}