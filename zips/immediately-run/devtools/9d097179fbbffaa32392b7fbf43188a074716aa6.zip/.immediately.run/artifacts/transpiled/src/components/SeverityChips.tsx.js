var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SeverityChips;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _jsxRuntime = require("react/jsx-runtime");
// Severity filter chips carrying counts (§8.1). Toggling a chip hides its rows; the
// count stays, so what was filtered away is still visible. The default (notes off)
// lives in `lib/severityFilter.ts` — this file exports only the component (Fast Refresh).

const LABEL = {
  error: 'Errors',
  warning: 'Warnings',
  note: 'Notes'
};
const KEY = {
  error: 'errors',
  warning: 'warnings',
  note: 'notes'
};
function SeverityChips({
  counts,
  filter,
  onChange
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "counts",
    role: "group",
    "aria-label": "Filter by severity",
    children: ['error', 'warning', 'note'].map(sev => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      type: "button",
      className: "chip",
      "aria-pressed": filter[sev],
      "data-sev": sev,
      onClick: () => onChange({
        ...filter,
        [sev]: !filter[sev]
      }),
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: `dot dot--${sev}`,
        "aria-hidden": "true"
      }), LABEL[sev], " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "n",
        children: counts[KEY[sev]]
      })]
    }, sev))
  });
}
_c = SeverityChips;
var _c;
$RefreshReg$(_c, "SeverityChips");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJMQUJFTCIsImVycm9yIiwid2FybmluZyIsIm5vdGUiLCJLRVkiLCJTZXZlcml0eUNoaXBzIiwiY291bnRzIiwiZmlsdGVyIiwib25DaGFuZ2UiLCJfanN4UnVudGltZSIsImpzeCIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsIm1hcCIsInNldiIsImpzeHMiLCJ0eXBlIiwib25DbGljayIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2V2ZXJpdHlDaGlwcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gU2V2ZXJpdHkgZmlsdGVyIGNoaXBzIGNhcnJ5aW5nIGNvdW50cyAowqc4LjEpLiBUb2dnbGluZyBhIGNoaXAgaGlkZXMgaXRzIHJvd3M7IHRoZVxuLy8gY291bnQgc3RheXMsIHNvIHdoYXQgd2FzIGZpbHRlcmVkIGF3YXkgaXMgc3RpbGwgdmlzaWJsZS4gVGhlIGRlZmF1bHQgKG5vdGVzIG9mZilcbi8vIGxpdmVzIGluIGBsaWIvc2V2ZXJpdHlGaWx0ZXIudHNgIOKAlCB0aGlzIGZpbGUgZXhwb3J0cyBvbmx5IHRoZSBjb21wb25lbnQgKEZhc3QgUmVmcmVzaCkuXG5pbXBvcnQgdHlwZSB7IENvdW50cywgU2V2ZXJpdHkgfSBmcm9tICcuLi9saWIvZGlhZ25vc3RpY3MnO1xuaW1wb3J0IHR5cGUgeyBTZXZlcml0eUZpbHRlciB9IGZyb20gJy4uL2xpYi9zZXZlcml0eUZpbHRlcic7XG5cbmNvbnN0IExBQkVMOiBSZWNvcmQ8U2V2ZXJpdHksIHN0cmluZz4gPSB7IGVycm9yOiAnRXJyb3JzJywgd2FybmluZzogJ1dhcm5pbmdzJywgbm90ZTogJ05vdGVzJyB9O1xuY29uc3QgS0VZOiBSZWNvcmQ8U2V2ZXJpdHksIGtleW9mIENvdW50cz4gPSB7IGVycm9yOiAnZXJyb3JzJywgd2FybmluZzogJ3dhcm5pbmdzJywgbm90ZTogJ25vdGVzJyB9O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXZlcml0eUNoaXBzKHtcbiAgY291bnRzLFxuICBmaWx0ZXIsXG4gIG9uQ2hhbmdlLFxufToge1xuICBjb3VudHM6IENvdW50cztcbiAgZmlsdGVyOiBTZXZlcml0eUZpbHRlcjtcbiAgb25DaGFuZ2U6IChuZXh0OiBTZXZlcml0eUZpbHRlcikgPT4gdm9pZDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvdW50c1wiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJGaWx0ZXIgYnkgc2V2ZXJpdHlcIj5cbiAgICAgIHsoWydlcnJvcicsICd3YXJuaW5nJywgJ25vdGUnXSBhcyBTZXZlcml0eVtdKS5tYXAoKHNldikgPT4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAga2V5PXtzZXZ9XG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY2hpcFwiXG4gICAgICAgICAgYXJpYS1wcmVzc2VkPXtmaWx0ZXJbc2V2XX1cbiAgICAgICAgICBkYXRhLXNldj17c2V2fVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHsgLi4uZmlsdGVyLCBbc2V2XTogIWZpbHRlcltzZXZdIH0pfVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZG90IGRvdC0tJHtzZXZ9YH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICB7TEFCRUxbc2V2XX0gPHNwYW4gY2xhc3NOYW1lPVwiblwiPntjb3VudHNbS0VZW3Nldl1dfTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFJQSxNQUFNQSxLQUErQixHQUFHO0VBQUVDLEtBQUssRUFBRSxRQUFRO0VBQUVDLE9BQU8sRUFBRSxVQUFVO0VBQUVDLElBQUksRUFBRTtBQUFRLENBQUM7QUFDL0YsTUFBTUMsR0FBbUMsR0FBRztFQUFFSCxLQUFLLEVBQUUsUUFBUTtFQUFFQyxPQUFPLEVBQUUsVUFBVTtFQUFFQyxJQUFJLEVBQUU7QUFBUSxDQUFDO0FBRXBGLFNBQVNFLGFBQWFBLENBQUM7RUFDcENDLE1BQU07RUFDTkMsTUFBTTtFQUNOQztBQUtGLENBQUMsRUFBRTtFQUNELG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFLQyxTQUFTLEVBQUMsUUFBUTtJQUFDQyxJQUFJLEVBQUMsT0FBTztJQUFDLGNBQVcsb0JBQW9CO0lBQUFDLFFBQUEsRUFDaEUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFnQkMsR0FBRyxDQUFFQyxHQUFHLGlCQUNwRCxJQUFBTixXQUFBLENBQUFPLElBQUE7TUFFRUMsSUFBSSxFQUFDLFFBQVE7TUFDYk4sU0FBUyxFQUFDLE1BQU07TUFDaEIsZ0JBQWNKLE1BQU0sQ0FBQ1EsR0FBRyxDQUFFO01BQzFCLFlBQVVBLEdBQUk7TUFDZEcsT0FBTyxFQUFFQSxDQUFBLEtBQU1WLFFBQVEsQ0FBQztRQUFFLEdBQUdELE1BQU07UUFBRSxDQUFDUSxHQUFHLEdBQUcsQ0FBQ1IsTUFBTSxDQUFDUSxHQUFHO01BQUUsQ0FBQyxDQUFFO01BQUFGLFFBQUEsZ0JBRTVELElBQUFKLFdBQUEsQ0FBQUMsR0FBQTtRQUFNQyxTQUFTLEVBQUUsWUFBWUksR0FBRyxFQUFHO1FBQUMsZUFBWTtNQUFNLENBQUUsQ0FBQyxFQUN4RGYsS0FBSyxDQUFDZSxHQUFHLENBQUMsRUFBQyxHQUFDLG1CQUFBTixXQUFBLENBQUFDLEdBQUE7UUFBTUMsU0FBUyxFQUFDLEdBQUc7UUFBQUUsUUFBQSxFQUFFUCxNQUFNLENBQUNGLEdBQUcsQ0FBQ1csR0FBRyxDQUFDO01BQUMsQ0FBTyxDQUFDO0lBQUEsR0FSckRBLEdBU0MsQ0FDVDtFQUFDLENBQ0MsQ0FBQztBQUVWO0FBQUNJLEVBQUEsR0ExQnVCZCxhQUFhO0FBQUEsSUFBQWMsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}