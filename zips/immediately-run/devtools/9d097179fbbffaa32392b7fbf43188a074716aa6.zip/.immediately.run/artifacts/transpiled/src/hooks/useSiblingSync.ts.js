"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useSiblingSync = useSiblingSync;
var _react = require("react");
var _sync = require("../lib/sync");
// Keep the two halves in step over their one IPC edge (R3-391; protocol in
// `lib/sync.ts`). Pure over injected ports so the tests drive both ends with an
// in-memory bus and never touch the SDK.
//
// Semantics, both directions symmetric:
//   - on mount, send `hello`; on receiving `hello`, reply with the current run (if any)
//     and the current selection — a late-mounting half (the runner is unmounted while
//     another activity is active) catches up without re-running anything;
//   - a completed run is broadcast in full; an inbound one REPLACES ours only when it is
//     newer (`startedAt`), so two halves that both ran converge on the latest;
//   - a selection change is broadcast by id; an inbound id that is not in the run we
//     hold is ignored (the runs converge a moment later and the next select lands).

function useSiblingSync({
  ports,
  state,
  onRunResult,
  onSelect
}) {
  // Latest state/handlers for the subscription to read, updated after commit (never
  // during render — the React compiler rule), so a `hello` answered between renders
  // sees the last committed values.
  const stateRef = (0, _react.useRef)(state);
  const handlers = (0, _react.useRef)({
    onRunResult,
    onSelect
  });
  (0, _react.useEffect)(() => {
    stateRef.current = state;
  }, [state]);
  (0, _react.useEffect)(() => {
    handlers.current = {
      onRunResult,
      onSelect
    };
  }, [onRunResult, onSelect]);
  const send = (0, _react.useCallback)(data => {
    // Fire-and-forget: `forbidden` here means the sibling is not mounted, which is
    // the normal state whenever the activity is not the active one.
    if (ports) void ports.post(data).catch(() => {});
  }, [ports]);
  (0, _react.useEffect)(() => {
    if (!ports || !ports.self) return;
    const self = ports.self;
    const off = ports.onMessage(raw => {
      const msg = (0, _sync.accept)(raw, self);
      if (!msg) return;
      if (msg.kind === 'hello') {
        const s = stateRef.current;
        if (s.result) send({
          v: 1,
          kind: 'run-result',
          result: s.result,
          stale: s.stale
        });
        send({
          v: 1,
          kind: 'select',
          id: s.selectedId
        });
        return;
      }
      if (msg.kind === 'run-result') {
        const mine = stateRef.current.result;
        if (msg.result === null) {
          if (mine !== null) handlers.current.onRunResult(null, []);
          return;
        }
        if (mine === null || msg.result.startedAt > mine.startedAt) handlers.current.onRunResult(msg.result, msg.stale);
        return;
      }
      if (msg.kind === 'select') handlers.current.onSelect(msg.id);
    });
    send({
      v: 1,
      kind: 'hello'
    });
    return off;
  }, [ports, send]);
  return {
    /** Broadcast a completed run. */
    announceRun: (0, _react.useCallback)((result, stale) => send({
      v: 1,
      kind: 'run-result',
      result,
      stale
    }), [send]),
    /** Broadcast a selection. */
    announceSelect: (0, _react.useCallback)(id => send({
      v: 1,
      kind: 'select',
      id
    }), [send])
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3N5bmMiLCJ1c2VTaWJsaW5nU3luYyIsInBvcnRzIiwic3RhdGUiLCJvblJ1blJlc3VsdCIsIm9uU2VsZWN0Iiwic3RhdGVSZWYiLCJ1c2VSZWYiLCJoYW5kbGVycyIsInVzZUVmZmVjdCIsImN1cnJlbnQiLCJzZW5kIiwidXNlQ2FsbGJhY2siLCJkYXRhIiwicG9zdCIsImNhdGNoIiwic2VsZiIsIm9mZiIsIm9uTWVzc2FnZSIsInJhdyIsIm1zZyIsImFjY2VwdCIsImtpbmQiLCJzIiwicmVzdWx0IiwidiIsInN0YWxlIiwiaWQiLCJzZWxlY3RlZElkIiwibWluZSIsInN0YXJ0ZWRBdCIsImFubm91bmNlUnVuIiwiYW5ub3VuY2VTZWxlY3QiXSwic291cmNlcyI6WyJ1c2VTaWJsaW5nU3luYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBLZWVwIHRoZSB0d28gaGFsdmVzIGluIHN0ZXAgb3ZlciB0aGVpciBvbmUgSVBDIGVkZ2UgKFIzLTM5MTsgcHJvdG9jb2wgaW5cbi8vIGBsaWIvc3luYy50c2ApLiBQdXJlIG92ZXIgaW5qZWN0ZWQgcG9ydHMgc28gdGhlIHRlc3RzIGRyaXZlIGJvdGggZW5kcyB3aXRoIGFuXG4vLyBpbi1tZW1vcnkgYnVzIGFuZCBuZXZlciB0b3VjaCB0aGUgU0RLLlxuLy9cbi8vIFNlbWFudGljcywgYm90aCBkaXJlY3Rpb25zIHN5bW1ldHJpYzpcbi8vICAgLSBvbiBtb3VudCwgc2VuZCBgaGVsbG9gOyBvbiByZWNlaXZpbmcgYGhlbGxvYCwgcmVwbHkgd2l0aCB0aGUgY3VycmVudCBydW4gKGlmIGFueSlcbi8vICAgICBhbmQgdGhlIGN1cnJlbnQgc2VsZWN0aW9uIOKAlCBhIGxhdGUtbW91bnRpbmcgaGFsZiAodGhlIHJ1bm5lciBpcyB1bm1vdW50ZWQgd2hpbGVcbi8vICAgICBhbm90aGVyIGFjdGl2aXR5IGlzIGFjdGl2ZSkgY2F0Y2hlcyB1cCB3aXRob3V0IHJlLXJ1bm5pbmcgYW55dGhpbmc7XG4vLyAgIC0gYSBjb21wbGV0ZWQgcnVuIGlzIGJyb2FkY2FzdCBpbiBmdWxsOyBhbiBpbmJvdW5kIG9uZSBSRVBMQUNFUyBvdXJzIG9ubHkgd2hlbiBpdCBpc1xuLy8gICAgIG5ld2VyIChgc3RhcnRlZEF0YCksIHNvIHR3byBoYWx2ZXMgdGhhdCBib3RoIHJhbiBjb252ZXJnZSBvbiB0aGUgbGF0ZXN0O1xuLy8gICAtIGEgc2VsZWN0aW9uIGNoYW5nZSBpcyBicm9hZGNhc3QgYnkgaWQ7IGFuIGluYm91bmQgaWQgdGhhdCBpcyBub3QgaW4gdGhlIHJ1biB3ZVxuLy8gICAgIGhvbGQgaXMgaWdub3JlZCAodGhlIHJ1bnMgY29udmVyZ2UgYSBtb21lbnQgbGF0ZXIgYW5kIHRoZSBuZXh0IHNlbGVjdCBsYW5kcykuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB0eXBlIFN5bmNNZXNzYWdlLCBhY2NlcHQgfSBmcm9tICcuLi9saWIvc3luYyc7XG5pbXBvcnQgdHlwZSB7IFJ1blJlc3VsdCB9IGZyb20gJy4uL2xpYi9ydW4nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFNpYmxpbmdQb3J0cyB7XG4gIC8qKiBUaGlzIGZyYW1lJ3MgcmVnaW9uIGlkIChgZ2V0UmVnaW9uKClgKTsgYG51bGxgIHN0YW5kYWxvbmUuICovXG4gIHNlbGY6IHN0cmluZyB8IG51bGw7XG4gIC8qKiBQb3N0IHRvIHRoZSBzaWJsaW5nOyByZWplY3RzIGBmb3JiaWRkZW5gIHdoZW4gdGhlIGVkZ2UvdGFyZ2V0IGlzIGFic2VudC4gKi9cbiAgcG9zdChkYXRhOiBTeW5jTWVzc2FnZSk6IFByb21pc2U8dm9pZD47XG4gIC8qKiBJbmJvdW5kIG1lc3NhZ2VzICh0aGUgU0RLJ3MgYG9uUmVnaW9uTWVzc2FnZWApOyByZXR1cm5zIGFuIHVuc3Vic2NyaWJlLiAqL1xuICBvbk1lc3NhZ2UoY2I6IChtc2c6IHsgZnJvbTogc3RyaW5nOyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQpOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNpYmxpbmdTdGF0ZSB7XG4gIHJlc3VsdDogUnVuUmVzdWx0IHwgbnVsbDtcbiAgc3RhbGU6IHN0cmluZ1tdO1xuICBzZWxlY3RlZElkOiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFVzZVNpYmxpbmdTeW5jT3B0aW9ucyB7XG4gIHBvcnRzOiBTaWJsaW5nUG9ydHMgfCBudWxsO1xuICAvKiogVGhlIGN1cnJlbnQgbG9jYWwgc3RhdGUsIHJlYWQgd2hlbiBhIGBoZWxsb2AgYXJyaXZlcy4gKi9cbiAgc3RhdGU6IFNpYmxpbmdTdGF0ZTtcbiAgLyoqIEFwcGx5IGFuIGluYm91bmQgcnVuIChhbHJlYWR5IHZhbGlkYXRlZCBhbmQgbmV3ZXIgdGhhbiBvdXJzKS4gKi9cbiAgb25SdW5SZXN1bHQ6IChyZXN1bHQ6IFJ1blJlc3VsdCB8IG51bGwsIHN0YWxlOiBzdHJpbmdbXSkgPT4gdm9pZDtcbiAgLyoqIEFwcGx5IGFuIGluYm91bmQgc2VsZWN0aW9uLiAqL1xuICBvblNlbGVjdDogKGlkOiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlU2libGluZ1N5bmMoeyBwb3J0cywgc3RhdGUsIG9uUnVuUmVzdWx0LCBvblNlbGVjdCB9OiBVc2VTaWJsaW5nU3luY09wdGlvbnMpIHtcbiAgLy8gTGF0ZXN0IHN0YXRlL2hhbmRsZXJzIGZvciB0aGUgc3Vic2NyaXB0aW9uIHRvIHJlYWQsIHVwZGF0ZWQgYWZ0ZXIgY29tbWl0IChuZXZlclxuICAvLyBkdXJpbmcgcmVuZGVyIOKAlCB0aGUgUmVhY3QgY29tcGlsZXIgcnVsZSksIHNvIGEgYGhlbGxvYCBhbnN3ZXJlZCBiZXR3ZWVuIHJlbmRlcnNcbiAgLy8gc2VlcyB0aGUgbGFzdCBjb21taXR0ZWQgdmFsdWVzLlxuICBjb25zdCBzdGF0ZVJlZiA9IHVzZVJlZihzdGF0ZSk7XG4gIGNvbnN0IGhhbmRsZXJzID0gdXNlUmVmKHsgb25SdW5SZXN1bHQsIG9uU2VsZWN0IH0pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0YXRlUmVmLmN1cnJlbnQgPSBzdGF0ZTtcbiAgfSwgW3N0YXRlXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaGFuZGxlcnMuY3VycmVudCA9IHsgb25SdW5SZXN1bHQsIG9uU2VsZWN0IH07XG4gIH0sIFtvblJ1blJlc3VsdCwgb25TZWxlY3RdKTtcblxuICBjb25zdCBzZW5kID0gdXNlQ2FsbGJhY2soXG4gICAgKGRhdGE6IFN5bmNNZXNzYWdlKSA9PiB7XG4gICAgICAvLyBGaXJlLWFuZC1mb3JnZXQ6IGBmb3JiaWRkZW5gIGhlcmUgbWVhbnMgdGhlIHNpYmxpbmcgaXMgbm90IG1vdW50ZWQsIHdoaWNoIGlzXG4gICAgICAvLyB0aGUgbm9ybWFsIHN0YXRlIHdoZW5ldmVyIHRoZSBhY3Rpdml0eSBpcyBub3QgdGhlIGFjdGl2ZSBvbmUuXG4gICAgICBpZiAocG9ydHMpIHZvaWQgcG9ydHMucG9zdChkYXRhKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfSxcbiAgICBbcG9ydHNdLFxuICApO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwb3J0cyB8fCAhcG9ydHMuc2VsZikgcmV0dXJuO1xuICAgIGNvbnN0IHNlbGYgPSBwb3J0cy5zZWxmO1xuICAgIGNvbnN0IG9mZiA9IHBvcnRzLm9uTWVzc2FnZSgocmF3KSA9PiB7XG4gICAgICBjb25zdCBtc2cgPSBhY2NlcHQocmF3LCBzZWxmKTtcbiAgICAgIGlmICghbXNnKSByZXR1cm47XG4gICAgICBpZiAobXNnLmtpbmQgPT09ICdoZWxsbycpIHtcbiAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmIChzLnJlc3VsdCkgc2VuZCh7IHY6IDEsIGtpbmQ6ICdydW4tcmVzdWx0JywgcmVzdWx0OiBzLnJlc3VsdCwgc3RhbGU6IHMuc3RhbGUgfSk7XG4gICAgICAgIHNlbmQoeyB2OiAxLCBraW5kOiAnc2VsZWN0JywgaWQ6IHMuc2VsZWN0ZWRJZCB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKG1zZy5raW5kID09PSAncnVuLXJlc3VsdCcpIHtcbiAgICAgICAgY29uc3QgbWluZSA9IHN0YXRlUmVmLmN1cnJlbnQucmVzdWx0O1xuICAgICAgICBpZiAobXNnLnJlc3VsdCA9PT0gbnVsbCkge1xuICAgICAgICAgIGlmIChtaW5lICE9PSBudWxsKSBoYW5kbGVycy5jdXJyZW50Lm9uUnVuUmVzdWx0KG51bGwsIFtdKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1pbmUgPT09IG51bGwgfHwgbXNnLnJlc3VsdC5zdGFydGVkQXQgPiBtaW5lLnN0YXJ0ZWRBdCkgaGFuZGxlcnMuY3VycmVudC5vblJ1blJlc3VsdChtc2cucmVzdWx0LCBtc2cuc3RhbGUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAobXNnLmtpbmQgPT09ICdzZWxlY3QnKSBoYW5kbGVycy5jdXJyZW50Lm9uU2VsZWN0KG1zZy5pZCk7XG4gICAgfSk7XG4gICAgc2VuZCh7IHY6IDEsIGtpbmQ6ICdoZWxsbycgfSk7XG4gICAgcmV0dXJuIG9mZjtcbiAgfSwgW3BvcnRzLCBzZW5kXSk7XG5cbiAgcmV0dXJuIHtcbiAgICAvKiogQnJvYWRjYXN0IGEgY29tcGxldGVkIHJ1bi4gKi9cbiAgICBhbm5vdW5jZVJ1bjogdXNlQ2FsbGJhY2soKHJlc3VsdDogUnVuUmVzdWx0IHwgbnVsbCwgc3RhbGU6IHN0cmluZ1tdKSA9PiBzZW5kKHsgdjogMSwga2luZDogJ3J1bi1yZXN1bHQnLCByZXN1bHQsIHN0YWxlIH0pLCBbc2VuZF0pLFxuICAgIC8qKiBCcm9hZGNhc3QgYSBzZWxlY3Rpb24uICovXG4gICAgYW5ub3VuY2VTZWxlY3Q6IHVzZUNhbGxiYWNrKChpZDogc3RyaW5nIHwgbnVsbCkgPT4gc2VuZCh7IHY6IDEsIGtpbmQ6ICdzZWxlY3QnLCBpZCB9KSwgW3NlbmRdKSxcbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBWUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsS0FBQSxHQUFBRCxPQUFBO0FBYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQThCTyxTQUFTRSxjQUFjQSxDQUFDO0VBQUVDLEtBQUs7RUFBRUMsS0FBSztFQUFFQyxXQUFXO0VBQUVDO0FBQWdDLENBQUMsRUFBRTtFQUM3RjtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQUMsYUFBTSxFQUFDSixLQUFLLENBQUM7RUFDOUIsTUFBTUssUUFBUSxHQUFHLElBQUFELGFBQU0sRUFBQztJQUFFSCxXQUFXO0lBQUVDO0VBQVMsQ0FBQyxDQUFDO0VBQ2xELElBQUFJLGdCQUFTLEVBQUMsTUFBTTtJQUNkSCxRQUFRLENBQUNJLE9BQU8sR0FBR1AsS0FBSztFQUMxQixDQUFDLEVBQUUsQ0FBQ0EsS0FBSyxDQUFDLENBQUM7RUFDWCxJQUFBTSxnQkFBUyxFQUFDLE1BQU07SUFDZEQsUUFBUSxDQUFDRSxPQUFPLEdBQUc7TUFBRU4sV0FBVztNQUFFQztJQUFTLENBQUM7RUFDOUMsQ0FBQyxFQUFFLENBQUNELFdBQVcsRUFBRUMsUUFBUSxDQUFDLENBQUM7RUFFM0IsTUFBTU0sSUFBSSxHQUFHLElBQUFDLGtCQUFXLEVBQ3JCQyxJQUFpQixJQUFLO0lBQ3JCO0lBQ0E7SUFDQSxJQUFJWCxLQUFLLEVBQUUsS0FBS0EsS0FBSyxDQUFDWSxJQUFJLENBQUNELElBQUksQ0FBQyxDQUFDRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNsRCxDQUFDLEVBQ0QsQ0FBQ2IsS0FBSyxDQUNSLENBQUM7RUFFRCxJQUFBTyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNQLEtBQUssSUFBSSxDQUFDQSxLQUFLLENBQUNjLElBQUksRUFBRTtJQUMzQixNQUFNQSxJQUFJLEdBQUdkLEtBQUssQ0FBQ2MsSUFBSTtJQUN2QixNQUFNQyxHQUFHLEdBQUdmLEtBQUssQ0FBQ2dCLFNBQVMsQ0FBRUMsR0FBRyxJQUFLO01BQ25DLE1BQU1DLEdBQUcsR0FBRyxJQUFBQyxZQUFNLEVBQUNGLEdBQUcsRUFBRUgsSUFBSSxDQUFDO01BQzdCLElBQUksQ0FBQ0ksR0FBRyxFQUFFO01BQ1YsSUFBSUEsR0FBRyxDQUFDRSxJQUFJLEtBQUssT0FBTyxFQUFFO1FBQ3hCLE1BQU1DLENBQUMsR0FBR2pCLFFBQVEsQ0FBQ0ksT0FBTztRQUMxQixJQUFJYSxDQUFDLENBQUNDLE1BQU0sRUFBRWIsSUFBSSxDQUFDO1VBQUVjLENBQUMsRUFBRSxDQUFDO1VBQUVILElBQUksRUFBRSxZQUFZO1VBQUVFLE1BQU0sRUFBRUQsQ0FBQyxDQUFDQyxNQUFNO1VBQUVFLEtBQUssRUFBRUgsQ0FBQyxDQUFDRztRQUFNLENBQUMsQ0FBQztRQUNsRmYsSUFBSSxDQUFDO1VBQUVjLENBQUMsRUFBRSxDQUFDO1VBQUVILElBQUksRUFBRSxRQUFRO1VBQUVLLEVBQUUsRUFBRUosQ0FBQyxDQUFDSztRQUFXLENBQUMsQ0FBQztRQUNoRDtNQUNGO01BQ0EsSUFBSVIsR0FBRyxDQUFDRSxJQUFJLEtBQUssWUFBWSxFQUFFO1FBQzdCLE1BQU1PLElBQUksR0FBR3ZCLFFBQVEsQ0FBQ0ksT0FBTyxDQUFDYyxNQUFNO1FBQ3BDLElBQUlKLEdBQUcsQ0FBQ0ksTUFBTSxLQUFLLElBQUksRUFBRTtVQUN2QixJQUFJSyxJQUFJLEtBQUssSUFBSSxFQUFFckIsUUFBUSxDQUFDRSxPQUFPLENBQUNOLFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO1VBQ3pEO1FBQ0Y7UUFDQSxJQUFJeUIsSUFBSSxLQUFLLElBQUksSUFBSVQsR0FBRyxDQUFDSSxNQUFNLENBQUNNLFNBQVMsR0FBR0QsSUFBSSxDQUFDQyxTQUFTLEVBQUV0QixRQUFRLENBQUNFLE9BQU8sQ0FBQ04sV0FBVyxDQUFDZ0IsR0FBRyxDQUFDSSxNQUFNLEVBQUVKLEdBQUcsQ0FBQ00sS0FBSyxDQUFDO1FBQy9HO01BQ0Y7TUFDQSxJQUFJTixHQUFHLENBQUNFLElBQUksS0FBSyxRQUFRLEVBQUVkLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDTCxRQUFRLENBQUNlLEdBQUcsQ0FBQ08sRUFBRSxDQUFDO0lBQzlELENBQUMsQ0FBQztJQUNGaEIsSUFBSSxDQUFDO01BQUVjLENBQUMsRUFBRSxDQUFDO01BQUVILElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQztJQUM3QixPQUFPTCxHQUFHO0VBQ1osQ0FBQyxFQUFFLENBQUNmLEtBQUssRUFBRVMsSUFBSSxDQUFDLENBQUM7RUFFakIsT0FBTztJQUNMO0lBQ0FvQixXQUFXLEVBQUUsSUFBQW5CLGtCQUFXLEVBQUMsQ0FBQ1ksTUFBd0IsRUFBRUUsS0FBZSxLQUFLZixJQUFJLENBQUM7TUFBRWMsQ0FBQyxFQUFFLENBQUM7TUFBRUgsSUFBSSxFQUFFLFlBQVk7TUFBRUUsTUFBTTtNQUFFRTtJQUFNLENBQUMsQ0FBQyxFQUFFLENBQUNmLElBQUksQ0FBQyxDQUFDO0lBQ2xJO0lBQ0FxQixjQUFjLEVBQUUsSUFBQXBCLGtCQUFXLEVBQUVlLEVBQWlCLElBQUtoQixJQUFJLENBQUM7TUFBRWMsQ0FBQyxFQUFFLENBQUM7TUFBRUgsSUFBSSxFQUFFLFFBQVE7TUFBRUs7SUFBRyxDQUFDLENBQUMsRUFBRSxDQUFDaEIsSUFBSSxDQUFDO0VBQy9GLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==