var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ProblemsPanel;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _diagnostics = require("../lib/diagnostics");
var _run = require("../lib/run");
var _scope = require("../lib/scope");
var _severityFilter = require("../lib/severityFilter");
var _ProblemsList = _interopRequireDefault(require("./ProblemsList"));
var _RunStatus = _interopRequireDefault(require("./RunStatus"));
var _SeverityChips = _interopRequireDefault(require("./SeverityChips"));
var _StaleBanner = _interopRequireDefault(require("./StaleBanner"));
var _Icons = require("./Icons");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `panel.tools` — the problems list (TOOLS_ACTIVITY_SPEC §8.1, R3-390).
//
// Three sources in one list: `tsc` and `eslint` from the last run, `build` LIVE from
// the host's diagnostics channel (§7.1 — it is push-fed and costs nothing, so it is
// never manual). Everything is normalized to one path form before it is merged.
//
// The run, the selection and the staleness live in the shared `ToolsSession` (R3-391),
// which the runner in the other frame holds in step over the sibling edge; this
// component is one view of it. Props are the ports, so a test renders it over an
// in-memory tree and canned service replies and never mocks the SDK.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const NO_BUILD = [];
function ProblemsPanel({
  session,
  buildErrors = NO_BUILD,
  onOpen
}) {
  _s();
  const {
    status,
    last,
    run,
    running,
    stale,
    selectedId,
    select,
    ports
  } = session;
  const [filter, setFilter] = (0, _react.useState)(_severityFilter.DEFAULT_FILTER);
  const [needle, setNeedle] = (0, _react.useState)('');
  const [openError, setOpenError] = (0, _react.useState)(null);

  // The unified list: live build rows + the last run's rows, deduped (§3.3).
  const all = (0, _react.useMemo)(() => {
    const build = buildErrors.map((e, i) => (0, _diagnostics.fromBuild)(e, i));
    return (0, _diagnostics.dedupe)([...build, ...(last?.diagnostics ?? [])]);
  }, [buildErrors, last]);
  const counts = (0, _react.useMemo)(() => (0, _diagnostics.countBySeverity)(all), [all]);
  const visible = (0, _react.useMemo)(() => all.filter(d => filter[d.severity] && (0, _diagnostics.matchesFilter)(d, needle)), [all, filter, needle]);
  const {
    groups,
    notes
  } = (0, _react.useMemo)(() => (0, _diagnostics.groupByFile)(visible), [visible]);
  // A row that disappears (re-run, filter) drops the selection — derived, not synced.
  const effectiveSelectedId = selectedId !== null && visible.some(d => d.id === selectedId) ? selectedId : null;
  const open = (0, _react.useCallback)(d => {
    setOpenError(null);
    // Called from the click / Enter handler ON PURPOSE: `reveal` needs the gesture the
    // host reads for itself. Do not move this onto run completion (§5.2, G-TOOL-10).
    void onOpen(d).catch(e => {
      const code = e?.code;
      setOpenError(code === 'not-found' ? 'That file is no longer in the working tree.' : `Could not open the file (${code ?? 'unknown'}).`);
    });
  }, [onOpen]);
  const problems = counts.errors + counts.warnings;
  const visibleProblems = visible.filter(d => d.severity !== 'note').length;
  const liveBuildErrors = all.filter(d => d.source === 'build').length;
  const clean = last !== null && status.state === 'done' && (0, _run.isCleanBill)(last, liveBuildErrors) && stale.length === 0;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "problems",
    "aria-labelledby": "problems-title",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "panel-top",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "panel-title-row",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
          className: "panel-title",
          id: "problems-title",
          children: "Problems"
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "runbtn",
          onClick: () => void run('changed'),
          disabled: running || !ports,
          "aria-busy": running,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icons.PlayIcon, {}), " ", running ? 'Running…' : 'Run']
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_SeverityChips.default, {
        counts: counts,
        filter: filter,
        onChange: setFilter
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        className: "filter",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icons.FilterIcon, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "text",
          placeholder: "Filter by path or message\u2026",
          "aria-label": "Filter problems",
          value: needle,
          onChange: e => setNeedle(e.target.value)
        })]
      })]
    }), ports === undefined ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "runmeta",
      role: "status",
      children: "Connecting to the working tree\u2026"
    }) : ports === null ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
        children: "No working tree here."
      }), " Open this from the Tools activity inside the immediately.run editor, where it can see the files it reports on."]
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_RunStatus.default, {
      status: status
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_StaleBanner.default, {
      stale: stale,
      onRerun: () => void run('changed'),
      running: running
    }), openError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "partial",
      role: "alert",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        children: openError
      })
    }), ports && /*#__PURE__*/(0, _jsxRuntime.jsx)(EmptyState, {
      status: status,
      total: all.length,
      problems: problems,
      visibleProblems: visibleProblems,
      hiddenNotes: !filter.note ? counts.notes : 0,
      clean: clean
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ProblemsList.default, {
      groups: groups,
      notes: notes,
      selectedId: effectiveSelectedId,
      onSelect: d => select(d.id),
      onOpen: open,
      dimmed: stale.length > 0
    })]
  });
}
_s(ProblemsPanel, "DRvnp3svkJYY1b8RD1wsxJG5W2E=");
_c = ProblemsPanel;
function EmptyState({
  status,
  total,
  problems,
  visibleProblems,
  hiddenNotes,
  clean
}) {
  if (status.state === 'idle' && total === 0) return /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
    className: "empty",
    children: "Run typecheck and lint to see problems here. Build errors appear as they happen."
  });
  if (status.state === 'running' && total === 0) return null;
  if (status.state === 'done' && clean) {
    // The clean bill of health — reachable ONLY through `isCleanBill`, which refuses
    // while anything was left unchecked (G-TOOL-5 / 5b), and never while stale (G-TOOL-6).
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty empty--ok",
      "data-clean": "true",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
        children: "No problems"
      }), " in ", _scope.SCOPE_LABEL[status.result.scope].toLowerCase(), " \u2014 ", status.result.files.count, " ", status.result.files.count === 1 ? 'file' : 'files', " checked."]
    });
  }
  if (status.state === 'done' && problems === 0) {
    // Nothing found, but the run was partial, stale, or a service failed: say what it
    // was, never "no problems". Hidden notes are named so the list is not silently empty.
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "empty",
      children: ["Nothing found in the files that were checked.", hiddenNotes > 0 ? ` ${hiddenNotes} coverage ${hiddenNotes === 1 ? 'note is' : 'notes are'} hidden by the Notes chip.` : '']
    });
  }
  if (problems > 0 && visibleProblems === 0) return /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
    className: "empty",
    children: "Nothing matches the current filter."
  });
  return null;
}
_c2 = EmptyState;
var _c, _c2;
$RefreshReg$(_c, "ProblemsPanel");
$RefreshReg$(_c2, "EmptyState");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2RpYWdub3N0aWNzIiwiX3J1biIsIl9zY29wZSIsIl9zZXZlcml0eUZpbHRlciIsIl9Qcm9ibGVtc0xpc3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX1J1blN0YXR1cyIsIl9TZXZlcml0eUNoaXBzIiwiX1N0YWxlQmFubmVyIiwiX0ljb25zIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIk5PX0JVSUxEIiwiUHJvYmxlbXNQYW5lbCIsInNlc3Npb24iLCJidWlsZEVycm9ycyIsIm9uT3BlbiIsInN0YXR1cyIsImxhc3QiLCJydW4iLCJydW5uaW5nIiwic3RhbGUiLCJzZWxlY3RlZElkIiwic2VsZWN0IiwicG9ydHMiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJ1c2VTdGF0ZSIsIkRFRkFVTFRfRklMVEVSIiwibmVlZGxlIiwic2V0TmVlZGxlIiwib3BlbkVycm9yIiwic2V0T3BlbkVycm9yIiwiYWxsIiwidXNlTWVtbyIsImJ1aWxkIiwibWFwIiwiaSIsImZyb21CdWlsZCIsImRlZHVwZSIsImRpYWdub3N0aWNzIiwiY291bnRzIiwiY291bnRCeVNldmVyaXR5IiwidmlzaWJsZSIsImQiLCJzZXZlcml0eSIsIm1hdGNoZXNGaWx0ZXIiLCJncm91cHMiLCJub3RlcyIsImdyb3VwQnlGaWxlIiwiZWZmZWN0aXZlU2VsZWN0ZWRJZCIsInNvbWUiLCJpZCIsIm9wZW4iLCJ1c2VDYWxsYmFjayIsImNhdGNoIiwiY29kZSIsInByb2JsZW1zIiwiZXJyb3JzIiwid2FybmluZ3MiLCJ2aXNpYmxlUHJvYmxlbXMiLCJsZW5ndGgiLCJsaXZlQnVpbGRFcnJvcnMiLCJzb3VyY2UiLCJjbGVhbiIsInN0YXRlIiwiaXNDbGVhbkJpbGwiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwib25DbGljayIsImRpc2FibGVkIiwiUGxheUljb24iLCJvbkNoYW5nZSIsIkZpbHRlckljb24iLCJwbGFjZWhvbGRlciIsInZhbHVlIiwidGFyZ2V0IiwidW5kZWZpbmVkIiwicm9sZSIsIm9uUmVydW4iLCJFbXB0eVN0YXRlIiwidG90YWwiLCJoaWRkZW5Ob3RlcyIsIm5vdGUiLCJvblNlbGVjdCIsImRpbW1lZCIsIl9jIiwiU0NPUEVfTEFCRUwiLCJyZXN1bHQiLCJzY29wZSIsInRvTG93ZXJDYXNlIiwiZmlsZXMiLCJjb3VudCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2JsZW1zUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGBwYW5lbC50b29sc2Ag4oCUIHRoZSBwcm9ibGVtcyBsaXN0IChUT09MU19BQ1RJVklUWV9TUEVDIMKnOC4xLCBSMy0zOTApLlxuLy9cbi8vIFRocmVlIHNvdXJjZXMgaW4gb25lIGxpc3Q6IGB0c2NgIGFuZCBgZXNsaW50YCBmcm9tIHRoZSBsYXN0IHJ1biwgYGJ1aWxkYCBMSVZFIGZyb21cbi8vIHRoZSBob3N0J3MgZGlhZ25vc3RpY3MgY2hhbm5lbCAowqc3LjEg4oCUIGl0IGlzIHB1c2gtZmVkIGFuZCBjb3N0cyBub3RoaW5nLCBzbyBpdCBpc1xuLy8gbmV2ZXIgbWFudWFsKS4gRXZlcnl0aGluZyBpcyBub3JtYWxpemVkIHRvIG9uZSBwYXRoIGZvcm0gYmVmb3JlIGl0IGlzIG1lcmdlZC5cbi8vXG4vLyBUaGUgcnVuLCB0aGUgc2VsZWN0aW9uIGFuZCB0aGUgc3RhbGVuZXNzIGxpdmUgaW4gdGhlIHNoYXJlZCBgVG9vbHNTZXNzaW9uYCAoUjMtMzkxKSxcbi8vIHdoaWNoIHRoZSBydW5uZXIgaW4gdGhlIG90aGVyIGZyYW1lIGhvbGRzIGluIHN0ZXAgb3ZlciB0aGUgc2libGluZyBlZGdlOyB0aGlzXG4vLyBjb21wb25lbnQgaXMgb25lIHZpZXcgb2YgaXQuIFByb3BzIGFyZSB0aGUgcG9ydHMsIHNvIGEgdGVzdCByZW5kZXJzIGl0IG92ZXIgYW5cbi8vIGluLW1lbW9yeSB0cmVlIGFuZCBjYW5uZWQgc2VydmljZSByZXBsaWVzIGFuZCBuZXZlciBtb2NrcyB0aGUgU0RLLlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdHlwZSBCdWlsZEVycm9yTGlrZSwgdHlwZSBEaWFnbm9zdGljLCBjb3VudEJ5U2V2ZXJpdHksIGRlZHVwZSwgZnJvbUJ1aWxkLCBncm91cEJ5RmlsZSwgbWF0Y2hlc0ZpbHRlciB9IGZyb20gJy4uL2xpYi9kaWFnbm9zdGljcyc7XG5pbXBvcnQgeyBpc0NsZWFuQmlsbCB9IGZyb20gJy4uL2xpYi9ydW4nO1xuaW1wb3J0IHsgdHlwZSBSdW5TdGF0dXMgYXMgU3RhdHVzLCB0eXBlIFRvb2xzU2Vzc2lvbiB9IGZyb20gJy4uL2hvb2tzL3VzZVRvb2xzU2Vzc2lvbic7XG5pbXBvcnQgeyBTQ09QRV9MQUJFTCB9IGZyb20gJy4uL2xpYi9zY29wZSc7XG5pbXBvcnQgeyBERUZBVUxUX0ZJTFRFUiwgdHlwZSBTZXZlcml0eUZpbHRlciB9IGZyb20gJy4uL2xpYi9zZXZlcml0eUZpbHRlcic7XG5pbXBvcnQgUHJvYmxlbXNMaXN0IGZyb20gJy4vUHJvYmxlbXNMaXN0JztcbmltcG9ydCBSdW5TdGF0dXMgZnJvbSAnLi9SdW5TdGF0dXMnO1xuaW1wb3J0IFNldmVyaXR5Q2hpcHMgZnJvbSAnLi9TZXZlcml0eUNoaXBzJztcbmltcG9ydCBTdGFsZUJhbm5lciBmcm9tICcuL1N0YWxlQmFubmVyJztcbmltcG9ydCB7IEZpbHRlckljb24sIFBsYXlJY29uIH0gZnJvbSAnLi9JY29ucyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvYmxlbXNQYW5lbFByb3BzIHtcbiAgc2Vzc2lvbjogVG9vbHNTZXNzaW9uO1xuICAvKiogVGhlIGxpdmUgYGJ1aWxkYCByb3dzICh0aGUgU0RLJ3MgYHVzZURpYWdub3N0aWNzKCkuYnVpbGRFcnJvcnNgKS4gKi9cbiAgYnVpbGRFcnJvcnM6IHJlYWRvbmx5IEJ1aWxkRXJyb3JMaWtlW107XG4gIC8qKiBSb3cgYWN0aXZhdGlvbiDigJQgdGhlIGdlc3R1cmUtY2FycnlpbmcgY2FsbCAoYG9wZW5EaWFnbm9zdGljYCBpbiB0aGUgbGl2ZSBhcHApLiAqL1xuICBvbk9wZW46IChkOiBEaWFnbm9zdGljKSA9PiBQcm9taXNlPHZvaWQ+O1xufVxuXG5jb25zdCBOT19CVUlMRDogcmVhZG9ubHkgQnVpbGRFcnJvckxpa2VbXSA9IFtdO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9ibGVtc1BhbmVsKHsgc2Vzc2lvbiwgYnVpbGRFcnJvcnMgPSBOT19CVUlMRCwgb25PcGVuIH06IFByb2JsZW1zUGFuZWxQcm9wcykge1xuICBjb25zdCB7IHN0YXR1cywgbGFzdCwgcnVuLCBydW5uaW5nLCBzdGFsZSwgc2VsZWN0ZWRJZCwgc2VsZWN0LCBwb3J0cyB9ID0gc2Vzc2lvbjtcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPFNldmVyaXR5RmlsdGVyPihERUZBVUxUX0ZJTFRFUik7XG4gIGNvbnN0IFtuZWVkbGUsIHNldE5lZWRsZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtvcGVuRXJyb3IsIHNldE9wZW5FcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBUaGUgdW5pZmllZCBsaXN0OiBsaXZlIGJ1aWxkIHJvd3MgKyB0aGUgbGFzdCBydW4ncyByb3dzLCBkZWR1cGVkICjCpzMuMykuXG4gIGNvbnN0IGFsbCA9IHVzZU1lbW88RGlhZ25vc3RpY1tdPigoKSA9PiB7XG4gICAgY29uc3QgYnVpbGQgPSBidWlsZEVycm9ycy5tYXAoKGUsIGkpID0+IGZyb21CdWlsZChlLCBpKSk7XG4gICAgcmV0dXJuIGRlZHVwZShbLi4uYnVpbGQsIC4uLihsYXN0Py5kaWFnbm9zdGljcyA/PyBbXSldKTtcbiAgfSwgW2J1aWxkRXJyb3JzLCBsYXN0XSk7XG5cbiAgY29uc3QgY291bnRzID0gdXNlTWVtbygoKSA9PiBjb3VudEJ5U2V2ZXJpdHkoYWxsKSwgW2FsbF0pO1xuICBjb25zdCB2aXNpYmxlID0gdXNlTWVtbygoKSA9PiBhbGwuZmlsdGVyKChkKSA9PiBmaWx0ZXJbZC5zZXZlcml0eV0gJiYgbWF0Y2hlc0ZpbHRlcihkLCBuZWVkbGUpKSwgW2FsbCwgZmlsdGVyLCBuZWVkbGVdKTtcbiAgY29uc3QgeyBncm91cHMsIG5vdGVzIH0gPSB1c2VNZW1vKCgpID0+IGdyb3VwQnlGaWxlKHZpc2libGUpLCBbdmlzaWJsZV0pO1xuICAvLyBBIHJvdyB0aGF0IGRpc2FwcGVhcnMgKHJlLXJ1biwgZmlsdGVyKSBkcm9wcyB0aGUgc2VsZWN0aW9uIOKAlCBkZXJpdmVkLCBub3Qgc3luY2VkLlxuICBjb25zdCBlZmZlY3RpdmVTZWxlY3RlZElkID0gc2VsZWN0ZWRJZCAhPT0gbnVsbCAmJiB2aXNpYmxlLnNvbWUoKGQpID0+IGQuaWQgPT09IHNlbGVjdGVkSWQpID8gc2VsZWN0ZWRJZCA6IG51bGw7XG5cbiAgY29uc3Qgb3BlbiA9IHVzZUNhbGxiYWNrKFxuICAgIChkOiBEaWFnbm9zdGljKSA9PiB7XG4gICAgICBzZXRPcGVuRXJyb3IobnVsbCk7XG4gICAgICAvLyBDYWxsZWQgZnJvbSB0aGUgY2xpY2sgLyBFbnRlciBoYW5kbGVyIE9OIFBVUlBPU0U6IGByZXZlYWxgIG5lZWRzIHRoZSBnZXN0dXJlIHRoZVxuICAgICAgLy8gaG9zdCByZWFkcyBmb3IgaXRzZWxmLiBEbyBub3QgbW92ZSB0aGlzIG9udG8gcnVuIGNvbXBsZXRpb24gKMKnNS4yLCBHLVRPT0wtMTApLlxuICAgICAgdm9pZCBvbk9wZW4oZCkuY2F0Y2goKGU6IHVua25vd24pID0+IHtcbiAgICAgICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZTtcbiAgICAgICAgc2V0T3BlbkVycm9yKGNvZGUgPT09ICdub3QtZm91bmQnID8gJ1RoYXQgZmlsZSBpcyBubyBsb25nZXIgaW4gdGhlIHdvcmtpbmcgdHJlZS4nIDogYENvdWxkIG5vdCBvcGVuIHRoZSBmaWxlICgke2NvZGUgPz8gJ3Vua25vd24nfSkuYCk7XG4gICAgICB9KTtcbiAgICB9LFxuICAgIFtvbk9wZW5dLFxuICApO1xuXG4gIGNvbnN0IHByb2JsZW1zID0gY291bnRzLmVycm9ycyArIGNvdW50cy53YXJuaW5ncztcbiAgY29uc3QgdmlzaWJsZVByb2JsZW1zID0gdmlzaWJsZS5maWx0ZXIoKGQpID0+IGQuc2V2ZXJpdHkgIT09ICdub3RlJykubGVuZ3RoO1xuICBjb25zdCBsaXZlQnVpbGRFcnJvcnMgPSBhbGwuZmlsdGVyKChkKSA9PiBkLnNvdXJjZSA9PT0gJ2J1aWxkJykubGVuZ3RoO1xuICBjb25zdCBjbGVhbiA9IGxhc3QgIT09IG51bGwgJiYgc3RhdHVzLnN0YXRlID09PSAnZG9uZScgJiYgaXNDbGVhbkJpbGwobGFzdCwgbGl2ZUJ1aWxkRXJyb3JzKSAmJiBzdGFsZS5sZW5ndGggPT09IDA7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwcm9ibGVtc1wiIGFyaWEtbGFiZWxsZWRieT1cInByb2JsZW1zLXRpdGxlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLXRvcFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLXRpdGxlLXJvd1wiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJwYW5lbC10aXRsZVwiIGlkPVwicHJvYmxlbXMtdGl0bGVcIj5cbiAgICAgICAgICAgIFByb2JsZW1zXG4gICAgICAgICAgPC9oMT5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJydW5idG5cIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHJ1bignY2hhbmdlZCcpfSBkaXNhYmxlZD17cnVubmluZyB8fCAhcG9ydHN9IGFyaWEtYnVzeT17cnVubmluZ30+XG4gICAgICAgICAgICA8UGxheUljb24gLz4ge3J1bm5pbmcgPyAnUnVubmluZ+KApicgOiAnUnVuJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxTZXZlcml0eUNoaXBzIGNvdW50cz17Y291bnRzfSBmaWx0ZXI9e2ZpbHRlcn0gb25DaGFuZ2U9e3NldEZpbHRlcn0gLz5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpbHRlclwiPlxuICAgICAgICAgIDxGaWx0ZXJJY29uIC8+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJGaWx0ZXIgYnkgcGF0aCBvciBtZXNzYWdl4oCmXCIgYXJpYS1sYWJlbD1cIkZpbHRlciBwcm9ibGVtc1wiIHZhbHVlPXtuZWVkbGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmVlZGxlKGUudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7cG9ydHMgPT09IHVuZGVmaW5lZCA/IChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicnVubWV0YVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICBDb25uZWN0aW5nIHRvIHRoZSB3b3JraW5nIHRyZWXigKZcbiAgICAgICAgPC9wPlxuICAgICAgKSA6IHBvcnRzID09PSBudWxsID8gKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eVwiPlxuICAgICAgICAgIDxiPk5vIHdvcmtpbmcgdHJlZSBoZXJlLjwvYj4gT3BlbiB0aGlzIGZyb20gdGhlIFRvb2xzIGFjdGl2aXR5IGluc2lkZSB0aGUgaW1tZWRpYXRlbHkucnVuIGVkaXRvciwgd2hlcmUgaXQgY2FuIHNlZSB0aGUgZmlsZXMgaXQgcmVwb3J0cyBvbi5cbiAgICAgICAgPC9wPlxuICAgICAgKSA6IChcbiAgICAgICAgPFJ1blN0YXR1cyBzdGF0dXM9e3N0YXR1c30gLz5cbiAgICAgICl9XG5cbiAgICAgIDxTdGFsZUJhbm5lciBzdGFsZT17c3RhbGV9IG9uUmVydW49eygpID0+IHZvaWQgcnVuKCdjaGFuZ2VkJyl9IHJ1bm5pbmc9e3J1bm5pbmd9IC8+XG5cbiAgICAgIHtvcGVuRXJyb3IgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJwYXJ0aWFsXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgPHNwYW4+e29wZW5FcnJvcn08L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHtwb3J0cyAmJiAoXG4gICAgICAgIDxFbXB0eVN0YXRlIHN0YXR1cz17c3RhdHVzfSB0b3RhbD17YWxsLmxlbmd0aH0gcHJvYmxlbXM9e3Byb2JsZW1zfSB2aXNpYmxlUHJvYmxlbXM9e3Zpc2libGVQcm9ibGVtc30gaGlkZGVuTm90ZXM9eyFmaWx0ZXIubm90ZSA/IGNvdW50cy5ub3RlcyA6IDB9IGNsZWFuPXtjbGVhbn0gLz5cbiAgICAgICl9XG5cbiAgICAgIDxQcm9ibGVtc0xpc3QgZ3JvdXBzPXtncm91cHN9IG5vdGVzPXtub3Rlc30gc2VsZWN0ZWRJZD17ZWZmZWN0aXZlU2VsZWN0ZWRJZH0gb25TZWxlY3Q9eyhkKSA9PiBzZWxlY3QoZC5pZCl9IG9uT3Blbj17b3Blbn0gZGltbWVkPXtzdGFsZS5sZW5ndGggPiAwfSAvPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRW1wdHlTdGF0ZSh7XG4gIHN0YXR1cyxcbiAgdG90YWwsXG4gIHByb2JsZW1zLFxuICB2aXNpYmxlUHJvYmxlbXMsXG4gIGhpZGRlbk5vdGVzLFxuICBjbGVhbixcbn06IHtcbiAgc3RhdHVzOiBTdGF0dXM7XG4gIHRvdGFsOiBudW1iZXI7XG4gIHByb2JsZW1zOiBudW1iZXI7XG4gIHZpc2libGVQcm9ibGVtczogbnVtYmVyO1xuICBoaWRkZW5Ob3RlczogbnVtYmVyO1xuICBjbGVhbjogYm9vbGVhbjtcbn0pIHtcbiAgaWYgKHN0YXR1cy5zdGF0ZSA9PT0gJ2lkbGUnICYmIHRvdGFsID09PSAwKSByZXR1cm4gPHAgY2xhc3NOYW1lPVwiZW1wdHlcIj5SdW4gdHlwZWNoZWNrIGFuZCBsaW50IHRvIHNlZSBwcm9ibGVtcyBoZXJlLiBCdWlsZCBlcnJvcnMgYXBwZWFyIGFzIHRoZXkgaGFwcGVuLjwvcD47XG4gIGlmIChzdGF0dXMuc3RhdGUgPT09ICdydW5uaW5nJyAmJiB0b3RhbCA9PT0gMCkgcmV0dXJuIG51bGw7XG4gIGlmIChzdGF0dXMuc3RhdGUgPT09ICdkb25lJyAmJiBjbGVhbikge1xuICAgIC8vIFRoZSBjbGVhbiBiaWxsIG9mIGhlYWx0aCDigJQgcmVhY2hhYmxlIE9OTFkgdGhyb3VnaCBgaXNDbGVhbkJpbGxgLCB3aGljaCByZWZ1c2VzXG4gICAgLy8gd2hpbGUgYW55dGhpbmcgd2FzIGxlZnQgdW5jaGVja2VkIChHLVRPT0wtNSAvIDViKSwgYW5kIG5ldmVyIHdoaWxlIHN0YWxlIChHLVRPT0wtNikuXG4gICAgcmV0dXJuIChcbiAgICAgIDxwIGNsYXNzTmFtZT1cImVtcHR5IGVtcHR5LS1va1wiIGRhdGEtY2xlYW49XCJ0cnVlXCI+XG4gICAgICAgIDxiPk5vIHByb2JsZW1zPC9iPiBpbiB7U0NPUEVfTEFCRUxbc3RhdHVzLnJlc3VsdC5zY29wZV0udG9Mb3dlckNhc2UoKX0g4oCUIHtzdGF0dXMucmVzdWx0LmZpbGVzLmNvdW50fSB7c3RhdHVzLnJlc3VsdC5maWxlcy5jb3VudCA9PT0gMSA/ICdmaWxlJyA6ICdmaWxlcyd9IGNoZWNrZWQuXG4gICAgICA8L3A+XG4gICAgKTtcbiAgfVxuICBpZiAoc3RhdHVzLnN0YXRlID09PSAnZG9uZScgJiYgcHJvYmxlbXMgPT09IDApIHtcbiAgICAvLyBOb3RoaW5nIGZvdW5kLCBidXQgdGhlIHJ1biB3YXMgcGFydGlhbCwgc3RhbGUsIG9yIGEgc2VydmljZSBmYWlsZWQ6IHNheSB3aGF0IGl0XG4gICAgLy8gd2FzLCBuZXZlciBcIm5vIHByb2JsZW1zXCIuIEhpZGRlbiBub3RlcyBhcmUgbmFtZWQgc28gdGhlIGxpc3QgaXMgbm90IHNpbGVudGx5IGVtcHR5LlxuICAgIHJldHVybiAoXG4gICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eVwiPlxuICAgICAgICBOb3RoaW5nIGZvdW5kIGluIHRoZSBmaWxlcyB0aGF0IHdlcmUgY2hlY2tlZC5cbiAgICAgICAge2hpZGRlbk5vdGVzID4gMCA/IGAgJHtoaWRkZW5Ob3Rlc30gY292ZXJhZ2UgJHtoaWRkZW5Ob3RlcyA9PT0gMSA/ICdub3RlIGlzJyA6ICdub3RlcyBhcmUnfSBoaWRkZW4gYnkgdGhlIE5vdGVzIGNoaXAuYCA6ICcnfVxuICAgICAgPC9wPlxuICAgICk7XG4gIH1cbiAgaWYgKHByb2JsZW1zID4gMCAmJiB2aXNpYmxlUHJvYmxlbXMgPT09IDApIHJldHVybiA8cCBjbGFzc05hbWU9XCJlbXB0eVwiPk5vdGhpbmcgbWF0Y2hlcyB0aGUgY3VycmVudCBmaWx0ZXIuPC9wPjtcbiAgcmV0dXJuIG51bGw7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFVQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFFQSxJQUFBRyxNQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxlQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxhQUFBLEdBQUFDLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBTyxVQUFBLEdBQUFELHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBUSxjQUFBLEdBQUFGLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBUyxZQUFBLEdBQUFILHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBVSxNQUFBLEdBQUFWLE9BQUE7QUFBK0MsSUFBQVcsV0FBQSxHQUFBWCxPQUFBO0FBQUEsSUFBQVksRUFBQSxHQUFBQyxZQUFBLElBcEIvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFQLHVCQUFBUSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBcUJBLE1BQU1HLFFBQW1DLEdBQUcsRUFBRTtBQUUvQixTQUFTQyxhQUFhQSxDQUFDO0VBQUVDLE9BQU87RUFBRUMsV0FBVyxHQUFHSCxRQUFRO0VBQUVJO0FBQTJCLENBQUMsRUFBRTtFQUFBVCxFQUFBO0VBQ3JHLE1BQU07SUFBRVUsTUFBTTtJQUFFQyxJQUFJO0lBQUVDLEdBQUc7SUFBRUMsT0FBTztJQUFFQyxLQUFLO0lBQUVDLFVBQVU7SUFBRUMsTUFBTTtJQUFFQztFQUFNLENBQUMsR0FBR1YsT0FBTztFQUNoRixNQUFNLENBQUNXLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFpQkMsOEJBQWMsQ0FBQztFQUNwRSxNQUFNLENBQUNDLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUgsZUFBUSxFQUFDLEVBQUUsQ0FBQztFQUN4QyxNQUFNLENBQUNJLFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUcsSUFBQUwsZUFBUSxFQUFnQixJQUFJLENBQUM7O0VBRS9EO0VBQ0EsTUFBTU0sR0FBRyxHQUFHLElBQUFDLGNBQU8sRUFBZSxNQUFNO0lBQ3RDLE1BQU1DLEtBQUssR0FBR3BCLFdBQVcsQ0FBQ3FCLEdBQUcsQ0FBQyxDQUFDM0IsQ0FBQyxFQUFFNEIsQ0FBQyxLQUFLLElBQUFDLHNCQUFTLEVBQUM3QixDQUFDLEVBQUU0QixDQUFDLENBQUMsQ0FBQztJQUN4RCxPQUFPLElBQUFFLG1CQUFNLEVBQUMsQ0FBQyxHQUFHSixLQUFLLEVBQUUsSUFBSWpCLElBQUksRUFBRXNCLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3pELENBQUMsRUFBRSxDQUFDekIsV0FBVyxFQUFFRyxJQUFJLENBQUMsQ0FBQztFQUV2QixNQUFNdUIsTUFBTSxHQUFHLElBQUFQLGNBQU8sRUFBQyxNQUFNLElBQUFRLDRCQUFlLEVBQUNULEdBQUcsQ0FBQyxFQUFFLENBQUNBLEdBQUcsQ0FBQyxDQUFDO0VBQ3pELE1BQU1VLE9BQU8sR0FBRyxJQUFBVCxjQUFPLEVBQUMsTUFBTUQsR0FBRyxDQUFDUixNQUFNLENBQUVtQixDQUFDLElBQUtuQixNQUFNLENBQUNtQixDQUFDLENBQUNDLFFBQVEsQ0FBQyxJQUFJLElBQUFDLDBCQUFhLEVBQUNGLENBQUMsRUFBRWYsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDSSxHQUFHLEVBQUVSLE1BQU0sRUFBRUksTUFBTSxDQUFDLENBQUM7RUFDdkgsTUFBTTtJQUFFa0IsTUFBTTtJQUFFQztFQUFNLENBQUMsR0FBRyxJQUFBZCxjQUFPLEVBQUMsTUFBTSxJQUFBZSx3QkFBVyxFQUFDTixPQUFPLENBQUMsRUFBRSxDQUFDQSxPQUFPLENBQUMsQ0FBQztFQUN4RTtFQUNBLE1BQU1PLG1CQUFtQixHQUFHNUIsVUFBVSxLQUFLLElBQUksSUFBSXFCLE9BQU8sQ0FBQ1EsSUFBSSxDQUFFUCxDQUFDLElBQUtBLENBQUMsQ0FBQ1EsRUFBRSxLQUFLOUIsVUFBVSxDQUFDLEdBQUdBLFVBQVUsR0FBRyxJQUFJO0VBRS9HLE1BQU0rQixJQUFJLEdBQUcsSUFBQUMsa0JBQVcsRUFDckJWLENBQWEsSUFBSztJQUNqQlosWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQjtJQUNBO0lBQ0EsS0FBS2hCLE1BQU0sQ0FBQzRCLENBQUMsQ0FBQyxDQUFDVyxLQUFLLENBQUU5QyxDQUFVLElBQUs7TUFDbkMsTUFBTStDLElBQUksR0FBSS9DLENBQUMsRUFBd0IrQyxJQUFJO01BQzNDeEIsWUFBWSxDQUFDd0IsSUFBSSxLQUFLLFdBQVcsR0FBRyw2Q0FBNkMsR0FBRyw0QkFBNEJBLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQztJQUN4SSxDQUFDLENBQUM7RUFDSixDQUFDLEVBQ0QsQ0FBQ3hDLE1BQU0sQ0FDVCxDQUFDO0VBRUQsTUFBTXlDLFFBQVEsR0FBR2hCLE1BQU0sQ0FBQ2lCLE1BQU0sR0FBR2pCLE1BQU0sQ0FBQ2tCLFFBQVE7RUFDaEQsTUFBTUMsZUFBZSxHQUFHakIsT0FBTyxDQUFDbEIsTUFBTSxDQUFFbUIsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQ2dCLE1BQU07RUFDM0UsTUFBTUMsZUFBZSxHQUFHN0IsR0FBRyxDQUFDUixNQUFNLENBQUVtQixDQUFDLElBQUtBLENBQUMsQ0FBQ21CLE1BQU0sS0FBSyxPQUFPLENBQUMsQ0FBQ0YsTUFBTTtFQUN0RSxNQUFNRyxLQUFLLEdBQUc5QyxJQUFJLEtBQUssSUFBSSxJQUFJRCxNQUFNLENBQUNnRCxLQUFLLEtBQUssTUFBTSxJQUFJLElBQUFDLGdCQUFXLEVBQUNoRCxJQUFJLEVBQUU0QyxlQUFlLENBQUMsSUFBSXpDLEtBQUssQ0FBQ3dDLE1BQU0sS0FBSyxDQUFDO0VBRWxILG9CQUNFLElBQUF2RCxXQUFBLENBQUE2RCxJQUFBO0lBQVNDLFNBQVMsRUFBQyxVQUFVO0lBQUMsbUJBQWdCLGdCQUFnQjtJQUFBQyxRQUFBLGdCQUM1RCxJQUFBL0QsV0FBQSxDQUFBNkQsSUFBQTtNQUFLQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLGdCQUN4QixJQUFBL0QsV0FBQSxDQUFBNkQsSUFBQTtRQUFLQyxTQUFTLEVBQUMsaUJBQWlCO1FBQUFDLFFBQUEsZ0JBQzlCLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1VBQUlGLFNBQVMsRUFBQyxhQUFhO1VBQUNoQixFQUFFLEVBQUMsZ0JBQWdCO1VBQUFpQixRQUFBLEVBQUM7UUFFaEQsQ0FBSSxDQUFDLGVBQ0wsSUFBQS9ELFdBQUEsQ0FBQTZELElBQUE7VUFBUUksSUFBSSxFQUFDLFFBQVE7VUFBQ0gsU0FBUyxFQUFDLFFBQVE7VUFBQ0ksT0FBTyxFQUFFQSxDQUFBLEtBQU0sS0FBS3JELEdBQUcsQ0FBQyxTQUFTLENBQUU7VUFBQ3NELFFBQVEsRUFBRXJELE9BQU8sSUFBSSxDQUFDSSxLQUFNO1VBQUMsYUFBV0osT0FBUTtVQUFBaUQsUUFBQSxnQkFDM0gsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUEsRUFBQ2pFLE1BQUEsQ0FBQXFFLFFBQVEsSUFBRSxDQUFDLEtBQUMsRUFBQ3RELE9BQU8sR0FBRyxVQUFVLEdBQUcsS0FBSztRQUFBLENBQ3BDLENBQUM7TUFBQSxDQUNOLENBQUMsZUFDTixJQUFBZCxXQUFBLENBQUFnRSxHQUFBLEVBQUNuRSxjQUFBLENBQUFRLE9BQWE7UUFBQzhCLE1BQU0sRUFBRUEsTUFBTztRQUFDaEIsTUFBTSxFQUFFQSxNQUFPO1FBQUNrRCxRQUFRLEVBQUVqRDtNQUFVLENBQUUsQ0FBQyxlQUN0RSxJQUFBcEIsV0FBQSxDQUFBNkQsSUFBQTtRQUFPQyxTQUFTLEVBQUMsUUFBUTtRQUFBQyxRQUFBLGdCQUN2QixJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQSxFQUFDakUsTUFBQSxDQUFBdUUsVUFBVSxJQUFFLENBQUMsZUFDZCxJQUFBdEUsV0FBQSxDQUFBZ0UsR0FBQTtVQUFPQyxJQUFJLEVBQUMsTUFBTTtVQUFDTSxXQUFXLEVBQUMsaUNBQTRCO1VBQUMsY0FBVyxpQkFBaUI7VUFBQ0MsS0FBSyxFQUFFakQsTUFBTztVQUFDOEMsUUFBUSxFQUFHbEUsQ0FBQyxJQUFLcUIsU0FBUyxDQUFDckIsQ0FBQyxDQUFDc0UsTUFBTSxDQUFDRCxLQUFLO1FBQUUsQ0FBRSxDQUFDO01BQUEsQ0FDakosQ0FBQztJQUFBLENBQ0wsQ0FBQyxFQUVMdEQsS0FBSyxLQUFLd0QsU0FBUyxnQkFDbEIsSUFBQTFFLFdBQUEsQ0FBQWdFLEdBQUE7TUFBR0YsU0FBUyxFQUFDLFNBQVM7TUFBQ2EsSUFBSSxFQUFDLFFBQVE7TUFBQVosUUFBQSxFQUFDO0lBRXJDLENBQUcsQ0FBQyxHQUNGN0MsS0FBSyxLQUFLLElBQUksZ0JBQ2hCLElBQUFsQixXQUFBLENBQUE2RCxJQUFBO01BQUdDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ2xCLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBO1FBQUFELFFBQUEsRUFBRztNQUFxQixDQUFHLENBQUMsbUhBQzlCO0lBQUEsQ0FBRyxDQUFDLGdCQUVKLElBQUEvRCxXQUFBLENBQUFnRSxHQUFBLEVBQUNwRSxVQUFBLENBQUFTLE9BQVM7TUFBQ00sTUFBTSxFQUFFQTtJQUFPLENBQUUsQ0FDN0IsZUFFRCxJQUFBWCxXQUFBLENBQUFnRSxHQUFBLEVBQUNsRSxZQUFBLENBQUFPLE9BQVc7TUFBQ1UsS0FBSyxFQUFFQSxLQUFNO01BQUM2RCxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLL0QsR0FBRyxDQUFDLFNBQVMsQ0FBRTtNQUFDQyxPQUFPLEVBQUVBO0lBQVEsQ0FBRSxDQUFDLEVBRWxGVyxTQUFTLGlCQUNSLElBQUF6QixXQUFBLENBQUFnRSxHQUFBO01BQUdGLFNBQVMsRUFBQyxTQUFTO01BQUNhLElBQUksRUFBQyxPQUFPO01BQUFaLFFBQUEsZUFDakMsSUFBQS9ELFdBQUEsQ0FBQWdFLEdBQUE7UUFBQUQsUUFBQSxFQUFPdEM7TUFBUyxDQUFPO0lBQUMsQ0FDdkIsQ0FDSixFQUVBUCxLQUFLLGlCQUNKLElBQUFsQixXQUFBLENBQUFnRSxHQUFBLEVBQUNhLFVBQVU7TUFBQ2xFLE1BQU0sRUFBRUEsTUFBTztNQUFDbUUsS0FBSyxFQUFFbkQsR0FBRyxDQUFDNEIsTUFBTztNQUFDSixRQUFRLEVBQUVBLFFBQVM7TUFBQ0csZUFBZSxFQUFFQSxlQUFnQjtNQUFDeUIsV0FBVyxFQUFFLENBQUM1RCxNQUFNLENBQUM2RCxJQUFJLEdBQUc3QyxNQUFNLENBQUNPLEtBQUssR0FBRyxDQUFFO01BQUNnQixLQUFLLEVBQUVBO0lBQU0sQ0FBRSxDQUNuSyxlQUVELElBQUExRCxXQUFBLENBQUFnRSxHQUFBLEVBQUN0RSxhQUFBLENBQUFXLE9BQVk7TUFBQ29DLE1BQU0sRUFBRUEsTUFBTztNQUFDQyxLQUFLLEVBQUVBLEtBQU07TUFBQzFCLFVBQVUsRUFBRTRCLG1CQUFvQjtNQUFDcUMsUUFBUSxFQUFHM0MsQ0FBQyxJQUFLckIsTUFBTSxDQUFDcUIsQ0FBQyxDQUFDUSxFQUFFLENBQUU7TUFBQ3BDLE1BQU0sRUFBRXFDLElBQUs7TUFBQ21DLE1BQU0sRUFBRW5FLEtBQUssQ0FBQ3dDLE1BQU0sR0FBRztJQUFFLENBQUUsQ0FBQztFQUFBLENBQy9JLENBQUM7QUFFZDtBQUFDdEQsRUFBQSxDQWpGdUJNLGFBQWE7QUFBQTRFLEVBQUEsR0FBYjVFLGFBQWE7QUFtRnJDLFNBQVNzRSxVQUFVQSxDQUFDO0VBQ2xCbEUsTUFBTTtFQUNObUUsS0FBSztFQUNMM0IsUUFBUTtFQUNSRyxlQUFlO0VBQ2Z5QixXQUFXO0VBQ1hyQjtBQVFGLENBQUMsRUFBRTtFQUNELElBQUkvQyxNQUFNLENBQUNnRCxLQUFLLEtBQUssTUFBTSxJQUFJbUIsS0FBSyxLQUFLLENBQUMsRUFBRSxvQkFBTyxJQUFBOUUsV0FBQSxDQUFBZ0UsR0FBQTtJQUFHRixTQUFTLEVBQUMsT0FBTztJQUFBQyxRQUFBLEVBQUM7RUFBZ0YsQ0FBRyxDQUFDO0VBQzVKLElBQUlwRCxNQUFNLENBQUNnRCxLQUFLLEtBQUssU0FBUyxJQUFJbUIsS0FBSyxLQUFLLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDMUQsSUFBSW5FLE1BQU0sQ0FBQ2dELEtBQUssS0FBSyxNQUFNLElBQUlELEtBQUssRUFBRTtJQUNwQztJQUNBO0lBQ0Esb0JBQ0UsSUFBQTFELFdBQUEsQ0FBQTZELElBQUE7TUFBR0MsU0FBUyxFQUFDLGlCQUFpQjtNQUFDLGNBQVcsTUFBTTtNQUFBQyxRQUFBLGdCQUM5QyxJQUFBL0QsV0FBQSxDQUFBZ0UsR0FBQTtRQUFBRCxRQUFBLEVBQUc7TUFBVyxDQUFHLENBQUMsUUFBSSxFQUFDcUIsa0JBQVcsQ0FBQ3pFLE1BQU0sQ0FBQzBFLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsVUFBRyxFQUFDNUUsTUFBTSxDQUFDMEUsTUFBTSxDQUFDRyxLQUFLLENBQUNDLEtBQUssRUFBQyxHQUFDLEVBQUM5RSxNQUFNLENBQUMwRSxNQUFNLENBQUNHLEtBQUssQ0FBQ0MsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEdBQUcsT0FBTyxFQUFDLFdBQzNKO0lBQUEsQ0FBRyxDQUFDO0VBRVI7RUFDQSxJQUFJOUUsTUFBTSxDQUFDZ0QsS0FBSyxLQUFLLE1BQU0sSUFBSVIsUUFBUSxLQUFLLENBQUMsRUFBRTtJQUM3QztJQUNBO0lBQ0Esb0JBQ0UsSUFBQW5ELFdBQUEsQ0FBQTZELElBQUE7TUFBR0MsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxHQUFDLCtDQUVuQixFQUFDZ0IsV0FBVyxHQUFHLENBQUMsR0FBRyxJQUFJQSxXQUFXLGFBQWFBLFdBQVcsS0FBSyxDQUFDLEdBQUcsU0FBUyxHQUFHLFdBQVcsNEJBQTRCLEdBQUcsRUFBRTtJQUFBLENBQzFILENBQUM7RUFFUjtFQUNBLElBQUk1QixRQUFRLEdBQUcsQ0FBQyxJQUFJRyxlQUFlLEtBQUssQ0FBQyxFQUFFLG9CQUFPLElBQUF0RCxXQUFBLENBQUFnRSxHQUFBO0lBQUdGLFNBQVMsRUFBQyxPQUFPO0lBQUFDLFFBQUEsRUFBQztFQUFtQyxDQUFHLENBQUM7RUFDOUcsT0FBTyxJQUFJO0FBQ2I7QUFBQzJCLEdBQUEsR0F0Q1FiLFVBQVU7QUFBQSxJQUFBTSxFQUFBLEVBQUFPLEdBQUE7QUFBQUMsWUFBQSxDQUFBUixFQUFBO0FBQUFRLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}