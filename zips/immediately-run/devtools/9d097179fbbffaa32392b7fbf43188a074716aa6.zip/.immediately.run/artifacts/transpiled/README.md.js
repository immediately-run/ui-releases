var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "devtools-the-tools-activity-for-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "devtools-the-tools-activity-for-immediatelyrun"
      }), "devtools — the Tools activity for immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The workbench surface that shows a person what ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tsc"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "eslint"
      }), " and the bundler are\nsaying about the app they are editing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Those services have been live on the platform since R3-75 and, until this app, had\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no human-facing surface at all"
      }), ": the only caller was the model inside the coding\nagent, and the only rendering was a raw tool result printed into an agent transcript.\nThe surfaces a person actually watches — editor squiggles, the preview's error\noverlay — are fed only by the bundler, and transpilation strips types without\nchecking them. So an app could be green everywhere in the interface and still fail\nits own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tsc -b"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Design of record:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://github.com/immediately-run/docs",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TOOLS_ACTIVITY_SPEC"
        })
      }), "\nin the docs corpus. Read it before changing behaviour here; the closed decisions and\ntheir rejected alternatives live in its Decisions section."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "shape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "shape"
      }), "Shape"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "One repo, one entry point, two regions:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Region"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Half"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "panel.tools"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The problems list — three sources in one list, grouped by file"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mainpane.tools"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The runner — tool tabs, run scope and controls, the selected diagnostic in context"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/App.tsx"
      }), " branches on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useRegion()"
      }), ". It is not two entry points: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "RegionBinding"
      }), "\ncarries no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "entryPoint"
      }), ", and program-identity ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKey"
      }), " is written but unwired, so a\nbinding cannot name one. This is the shipped idiom — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "agent-demo"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "file-explorer"
      }), "\nboth do it, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PRINCIPALS_SPEC"
      }), " §4 calls it one-repo-many-bindings."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "state",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "state"
      }), "State"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Both halves are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "built"
      }), ": the problems list (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "R3-390"
      }), ") and the runner (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "R3-391"
      }), ").\nThe live drill (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "R3-392"
      }), ") is what remains."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "R3-387"
        }), " — bind the activity and both regions in the host — done"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "R3-390"
        }), " — the problems list — done"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "R3-391"
        }), " — the runner, staleness, sibling sync, keyboard — built"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "R3-392"
        }), " — the live drill — next"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-it-works",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-it-works"
      }), "How it works"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/diagnostics.ts   the unified model: tsc / eslint / build → one Diagnostic,\n                         path normalization, dedup, grouping, counts (notes excluded)\nsrc/lib/scope.ts         changed files + local import closure (default) · open files ·\n                         whole project — bounded to the service's 200 files / 1 MB,\n                         falling back changed → open → project and SAYING so\nsrc/lib/run.ts           one run: resolve scope → typecheck + lint → normalize →\n                         `partial` reasons (truncation, relative coverage notes,\n                         service failures); `isCleanBill` is the only door to \"No problems\"\nsrc/lib/codeFrame.ts     the read-only code frame rows: hit line + a caret SPAN for tsc\n                         (the one source with an end position), a point for the rest\nsrc/lib/sync.ts          the sibling protocol (hello / run-result / select) and its\n                         validation — the other frame's payload is data, not trust\nsrc/lib/host.ts          the SDK adapters (the edited repo's worktree mount, vcs/editor\n                         lists, staleness legs, the IPC edge, openInEditor) — the one\n                         module that touches the SDK for the session\nsrc/hooks/useToolsSession.ts  ONE session for both halves: run, selection, staleness,\n                         kept in step over the IPC edge (useSiblingSync / useStaleness)\nsrc/components/ProblemsPanel.tsx  panel.tools — chips, filter, grouped list, banners\nsrc/components/RunnerPane.tsx     mainpane.tools — tabs, run bar, code frame, actions\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Everything above ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "host.ts"
      }), " takes ports, so the pipeline and both halves are tested\nagainst an in-memory tree, an in-memory bus and canned service replies with no SDK mock."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The two halves are two frames."
      }), " The host mounts each region in its own sandboxed\niframe; they share no memory. They hold one session in step over their single §5.6\nIPC edge to each other (and to nothing else — the explorer reveal stays a consequence,\nnever a message). A half that mounts later sends ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hello"
      }), " and receives the current run\nand selection instead of re-running. The panel does the one automatic first-open run;\nthe runner never auto-runs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Staleness."
      }), " A run records the paths it covered; the worktree mount's change stream →\ndebounce → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "refreshDiff()"
      }), " → a write to a covered path marks the run stale. It stays on\nscreen, dimmed and labelled, and is never a clean bill."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Keyboard"
      }), ", per frame (keys do not cross iframes): the panel's list takes arrows /\nHome / End / Enter; the runner takes J / K and F8 / ⇧F8 (next / previous problem in the\nactive tab) and Enter. None collide with the host (⌘K palette, ⌘B panel, ⌘. mode,\nEscape) or the editor (CodeMirror's default keymap)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two rules a change here must keep:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A run with anything unchecked is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "partial"
          }), " and never renders \"No problems\"."]
        }), "\nRelative coverage notes (an import the request did not include) count as unchecked\n— a bare changed file whose imports are all outside the request would otherwise\nreport a clean run having checked almost nothing (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TOOLS_ACTIVITY_SPEC"
        }), " §3.2, §7.2)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The row click is the gesture."
        }), " Opening a diagnostic asks the host to switch the\nuser to the editor activity (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor:reveal"
        }), "), which the host only does under a real\nuser activation it reads itself. Never call it on run completion or from a timer;\nit is denied by design there."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The two regions are two sandboxed frames and share no memory; see \"The two halves are\ntwo frames\" above for how they stay in step."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "developing",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "developing"
      }), "Developing"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm ci\nnpm run dev     # standalone; no working tree, so the placeholder explains itself\nnpm test\nnpm run lint\nnpm run build\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "To run it inside the real workbench, serve the working tree and bind it to a region:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "immediately.run dev . --region panel.tools --origin https://local.immediately.run\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["That only works once the region exists in the host's build defaults (R3-387). Before\nthen it fails ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "silently"
      }), " — the page renders and the region loads nothing."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZGV2dG9vbHMtdGhlLXRvb2xzLWFjdGl2aXR5LWZvci1pbW1lZGlhdGVseXJ1blwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGV2dG9vbHMtdGhlLXRvb2xzLWFjdGl2aXR5LWZvci1pbW1lZGlhdGVseXJ1blwiIC8+e1wiZGV2dG9vbHMg4oCUIHRoZSBUb29scyBhY3Rpdml0eSBmb3IgaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgd29ya2JlbmNoIHN1cmZhY2UgdGhhdCBzaG93cyBhIHBlcnNvbiB3aGF0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInRzY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVzbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSBidW5kbGVyIGFyZVxcbnNheWluZyBhYm91dCB0aGUgYXBwIHRoZXkgYXJlIGVkaXRpbmcuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRob3NlIHNlcnZpY2VzIGhhdmUgYmVlbiBsaXZlIG9uIHRoZSBwbGF0Zm9ybSBzaW5jZSBSMy03NSBhbmQsIHVudGlsIHRoaXMgYXBwLCBoYWRcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIGh1bWFuLWZhY2luZyBzdXJmYWNlIGF0IGFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIG9ubHkgY2FsbGVyIHdhcyB0aGUgbW9kZWwgaW5zaWRlIHRoZSBjb2RpbmdcXG5hZ2VudCwgYW5kIHRoZSBvbmx5IHJlbmRlcmluZyB3YXMgYSByYXcgdG9vbCByZXN1bHQgcHJpbnRlZCBpbnRvIGFuIGFnZW50IHRyYW5zY3JpcHQuXFxuVGhlIHN1cmZhY2VzIGEgcGVyc29uIGFjdHVhbGx5IHdhdGNoZXMg4oCUIGVkaXRvciBzcXVpZ2dsZXMsIHRoZSBwcmV2aWV3J3MgZXJyb3JcXG5vdmVybGF5IOKAlCBhcmUgZmVkIG9ubHkgYnkgdGhlIGJ1bmRsZXIsIGFuZCB0cmFuc3BpbGF0aW9uIHN0cmlwcyB0eXBlcyB3aXRob3V0XFxuY2hlY2tpbmcgdGhlbS4gU28gYW4gYXBwIGNvdWxkIGJlIGdyZWVuIGV2ZXJ5d2hlcmUgaW4gdGhlIGludGVyZmFjZSBhbmQgc3RpbGwgZmFpbFxcbml0cyBvd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHNjIC1iXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXNpZ24gb2YgcmVjb3JkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL2ltbWVkaWF0ZWx5LXJ1bi9kb2NzXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiVE9PTFNfQUNUSVZJVFlfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiXFxuaW4gdGhlIGRvY3MgY29ycHVzLiBSZWFkIGl0IGJlZm9yZSBjaGFuZ2luZyBiZWhhdmlvdXIgaGVyZTsgdGhlIGNsb3NlZCBkZWNpc2lvbnMgYW5kXFxudGhlaXIgcmVqZWN0ZWQgYWx0ZXJuYXRpdmVzIGxpdmUgaW4gaXRzIERlY2lzaW9ucyBzZWN0aW9uLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzaGFwZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2hhcGVcIiAvPntcIlNoYXBlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJPbmUgcmVwbywgb25lIGVudHJ5IHBvaW50LCB0d28gcmVnaW9uczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIlJlZ2lvblwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkhhbGZcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJwYW5lbC50b29sc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgcHJvYmxlbXMgbGlzdCDigJQgdGhyZWUgc291cmNlcyBpbiBvbmUgbGlzdCwgZ3JvdXBlZCBieSBmaWxlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbnBhbmUudG9vbHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHJ1bm5lciDigJQgdG9vbCB0YWJzLCBydW4gc2NvcGUgYW5kIGNvbnRyb2xzLCB0aGUgc2VsZWN0ZWQgZGlhZ25vc3RpYyBpbiBjb250ZXh0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYnJhbmNoZXMgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlUmVnaW9uKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBJdCBpcyBub3QgdHdvIGVudHJ5IHBvaW50czogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmVnaW9uQmluZGluZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5jYXJyaWVzIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVudHJ5UG9pbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgcHJvZ3JhbS1pZGVudGl0eSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHdyaXR0ZW4gYnV0IHVud2lyZWQsIHNvIGFcXG5iaW5kaW5nIGNhbm5vdCBuYW1lIG9uZS4gVGhpcyBpcyB0aGUgc2hpcHBlZCBpZGlvbSDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWdlbnQtZGVtb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbGUtZXhwbG9yZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYm90aCBkbyBpdCwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBSSU5DSVBBTFNfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc0IGNhbGxzIGl0IG9uZS1yZXBvLW1hbnktYmluZGluZ3MuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0YXRlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdGF0ZVwiIC8+e1wiU3RhdGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkJvdGggaGFsdmVzIGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiB0aGUgcHJvYmxlbXMgbGlzdCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUjMtMzkwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIHRoZSBydW5uZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlIzLTM5MVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlxcblRoZSBsaXZlIGRyaWxsIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJSMy0zOTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBpcyB3aGF0IHJlbWFpbnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiUjMtMzg3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYmluZCB0aGUgYWN0aXZpdHkgYW5kIGJvdGggcmVnaW9ucyBpbiB0aGUgaG9zdCDigJQgZG9uZVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIlIzLTM5MFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBwcm9ibGVtcyBsaXN0IOKAlCBkb25lXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiUjMtMzkxXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHJ1bm5lciwgc3RhbGVuZXNzLCBzaWJsaW5nIHN5bmMsIGtleWJvYXJkIOKAlCBidWlsdFwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIlIzLTM5MlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBsaXZlIGRyaWxsIOKAlCBuZXh0XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImhvdy1pdC13b3Jrc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaG93LWl0LXdvcmtzXCIgLz57XCJIb3cgaXQgd29ya3NcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9kaWFnbm9zdGljcy50cyAgIHRoZSB1bmlmaWVkIG1vZGVsOiB0c2MgLyBlc2xpbnQgLyBidWlsZCDihpIgb25lIERpYWdub3N0aWMsXFxuICAgICAgICAgICAgICAgICAgICAgICAgIHBhdGggbm9ybWFsaXphdGlvbiwgZGVkdXAsIGdyb3VwaW5nLCBjb3VudHMgKG5vdGVzIGV4Y2x1ZGVkKVxcbnNyYy9saWIvc2NvcGUudHMgICAgICAgICBjaGFuZ2VkIGZpbGVzICsgbG9jYWwgaW1wb3J0IGNsb3N1cmUgKGRlZmF1bHQpIMK3IG9wZW4gZmlsZXMgwrdcXG4gICAgICAgICAgICAgICAgICAgICAgICAgd2hvbGUgcHJvamVjdCDigJQgYm91bmRlZCB0byB0aGUgc2VydmljZSdzIDIwMCBmaWxlcyAvIDEgTUIsXFxuICAgICAgICAgICAgICAgICAgICAgICAgIGZhbGxpbmcgYmFjayBjaGFuZ2VkIOKGkiBvcGVuIOKGkiBwcm9qZWN0IGFuZCBTQVlJTkcgc29cXG5zcmMvbGliL3J1bi50cyAgICAgICAgICAgb25lIHJ1bjogcmVzb2x2ZSBzY29wZSDihpIgdHlwZWNoZWNrICsgbGludCDihpIgbm9ybWFsaXplIOKGklxcbiAgICAgICAgICAgICAgICAgICAgICAgICBgcGFydGlhbGAgcmVhc29ucyAodHJ1bmNhdGlvbiwgcmVsYXRpdmUgY292ZXJhZ2Ugbm90ZXMsXFxuICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2UgZmFpbHVyZXMpOyBgaXNDbGVhbkJpbGxgIGlzIHRoZSBvbmx5IGRvb3IgdG8gXFxcIk5vIHByb2JsZW1zXFxcIlxcbnNyYy9saWIvY29kZUZyYW1lLnRzICAgICB0aGUgcmVhZC1vbmx5IGNvZGUgZnJhbWUgcm93czogaGl0IGxpbmUgKyBhIGNhcmV0IFNQQU4gZm9yIHRzY1xcbiAgICAgICAgICAgICAgICAgICAgICAgICAodGhlIG9uZSBzb3VyY2Ugd2l0aCBhbiBlbmQgcG9zaXRpb24pLCBhIHBvaW50IGZvciB0aGUgcmVzdFxcbnNyYy9saWIvc3luYy50cyAgICAgICAgICB0aGUgc2libGluZyBwcm90b2NvbCAoaGVsbG8gLyBydW4tcmVzdWx0IC8gc2VsZWN0KSBhbmQgaXRzXFxuICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRpb24g4oCUIHRoZSBvdGhlciBmcmFtZSdzIHBheWxvYWQgaXMgZGF0YSwgbm90IHRydXN0XFxuc3JjL2xpYi9ob3N0LnRzICAgICAgICAgIHRoZSBTREsgYWRhcHRlcnMgKHRoZSBlZGl0ZWQgcmVwbydzIHdvcmt0cmVlIG1vdW50LCB2Y3MvZWRpdG9yXFxuICAgICAgICAgICAgICAgICAgICAgICAgIGxpc3RzLCBzdGFsZW5lc3MgbGVncywgdGhlIElQQyBlZGdlLCBvcGVuSW5FZGl0b3IpIOKAlCB0aGUgb25lXFxuICAgICAgICAgICAgICAgICAgICAgICAgIG1vZHVsZSB0aGF0IHRvdWNoZXMgdGhlIFNESyBmb3IgdGhlIHNlc3Npb25cXG5zcmMvaG9va3MvdXNlVG9vbHNTZXNzaW9uLnRzICBPTkUgc2Vzc2lvbiBmb3IgYm90aCBoYWx2ZXM6IHJ1biwgc2VsZWN0aW9uLCBzdGFsZW5lc3MsXFxuICAgICAgICAgICAgICAgICAgICAgICAgIGtlcHQgaW4gc3RlcCBvdmVyIHRoZSBJUEMgZWRnZSAodXNlU2libGluZ1N5bmMgLyB1c2VTdGFsZW5lc3MpXFxuc3JjL2NvbXBvbmVudHMvUHJvYmxlbXNQYW5lbC50c3ggIHBhbmVsLnRvb2xzIOKAlCBjaGlwcywgZmlsdGVyLCBncm91cGVkIGxpc3QsIGJhbm5lcnNcXG5zcmMvY29tcG9uZW50cy9SdW5uZXJQYW5lLnRzeCAgICAgbWFpbnBhbmUudG9vbHMg4oCUIHRhYnMsIHJ1biBiYXIsIGNvZGUgZnJhbWUsIGFjdGlvbnNcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXZlcnl0aGluZyBhYm92ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJob3N0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YWtlcyBwb3J0cywgc28gdGhlIHBpcGVsaW5lIGFuZCBib3RoIGhhbHZlcyBhcmUgdGVzdGVkXFxuYWdhaW5zdCBhbiBpbi1tZW1vcnkgdHJlZSwgYW4gaW4tbWVtb3J5IGJ1cyBhbmQgY2FubmVkIHNlcnZpY2UgcmVwbGllcyB3aXRoIG5vIFNESyBtb2NrLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSB0d28gaGFsdmVzIGFyZSB0d28gZnJhbWVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaG9zdCBtb3VudHMgZWFjaCByZWdpb24gaW4gaXRzIG93biBzYW5kYm94ZWRcXG5pZnJhbWU7IHRoZXkgc2hhcmUgbm8gbWVtb3J5LiBUaGV5IGhvbGQgb25lIHNlc3Npb24gaW4gc3RlcCBvdmVyIHRoZWlyIHNpbmdsZSDCpzUuNlxcbklQQyBlZGdlIHRvIGVhY2ggb3RoZXIgKGFuZCB0byBub3RoaW5nIGVsc2Ug4oCUIHRoZSBleHBsb3JlciByZXZlYWwgc3RheXMgYSBjb25zZXF1ZW5jZSxcXG5uZXZlciBhIG1lc3NhZ2UpLiBBIGhhbGYgdGhhdCBtb3VudHMgbGF0ZXIgc2VuZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGVsbG9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCByZWNlaXZlcyB0aGUgY3VycmVudCBydW5cXG5hbmQgc2VsZWN0aW9uIGluc3RlYWQgb2YgcmUtcnVubmluZy4gVGhlIHBhbmVsIGRvZXMgdGhlIG9uZSBhdXRvbWF0aWMgZmlyc3Qtb3BlbiBydW47XFxudGhlIHJ1bm5lciBuZXZlciBhdXRvLXJ1bnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhbGVuZXNzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIHJ1biByZWNvcmRzIHRoZSBwYXRocyBpdCBjb3ZlcmVkOyB0aGUgd29ya3RyZWUgbW91bnQncyBjaGFuZ2Ugc3RyZWFtIOKGklxcbmRlYm91bmNlIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoRGlmZigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgYSB3cml0ZSB0byBhIGNvdmVyZWQgcGF0aCBtYXJrcyB0aGUgcnVuIHN0YWxlLiBJdCBzdGF5cyBvblxcbnNjcmVlbiwgZGltbWVkIGFuZCBsYWJlbGxlZCwgYW5kIGlzIG5ldmVyIGEgY2xlYW4gYmlsbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJLZXlib2FyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgcGVyIGZyYW1lIChrZXlzIGRvIG5vdCBjcm9zcyBpZnJhbWVzKTogdGhlIHBhbmVsJ3MgbGlzdCB0YWtlcyBhcnJvd3MgL1xcbkhvbWUgLyBFbmQgLyBFbnRlcjsgdGhlIHJ1bm5lciB0YWtlcyBKIC8gSyBhbmQgRjggLyDih6dGOCAobmV4dCAvIHByZXZpb3VzIHByb2JsZW0gaW4gdGhlXFxuYWN0aXZlIHRhYikgYW5kIEVudGVyLiBOb25lIGNvbGxpZGUgd2l0aCB0aGUgaG9zdCAo4oyYSyBwYWxldHRlLCDijJhCIHBhbmVsLCDijJguIG1vZGUsXFxuRXNjYXBlKSBvciB0aGUgZWRpdG9yIChDb2RlTWlycm9yJ3MgZGVmYXVsdCBrZXltYXApLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUd28gcnVsZXMgYSBjaGFuZ2UgaGVyZSBtdXN0IGtlZXA6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIHJ1biB3aXRoIGFueXRoaW5nIHVuY2hlY2tlZCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJ0aWFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgbmV2ZXIgcmVuZGVycyBcXFwiTm8gcHJvYmxlbXNcXFwiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblJlbGF0aXZlIGNvdmVyYWdlIG5vdGVzIChhbiBpbXBvcnQgdGhlIHJlcXVlc3QgZGlkIG5vdCBpbmNsdWRlKSBjb3VudCBhcyB1bmNoZWNrZWRcXG7igJQgYSBiYXJlIGNoYW5nZWQgZmlsZSB3aG9zZSBpbXBvcnRzIGFyZSBhbGwgb3V0c2lkZSB0aGUgcmVxdWVzdCB3b3VsZCBvdGhlcndpc2VcXG5yZXBvcnQgYSBjbGVhbiBydW4gaGF2aW5nIGNoZWNrZWQgYWxtb3N0IG5vdGhpbmcgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRPT0xTX0FDVElWSVRZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMy4yLCDCpzcuMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgcm93IGNsaWNrIGlzIHRoZSBnZXN0dXJlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBPcGVuaW5nIGEgZGlhZ25vc3RpYyBhc2tzIHRoZSBob3N0IHRvIHN3aXRjaCB0aGVcXG51c2VyIHRvIHRoZSBlZGl0b3IgYWN0aXZpdHkgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRvcjpyZXZlYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgd2hpY2ggdGhlIGhvc3Qgb25seSBkb2VzIHVuZGVyIGEgcmVhbFxcbnVzZXIgYWN0aXZhdGlvbiBpdCByZWFkcyBpdHNlbGYuIE5ldmVyIGNhbGwgaXQgb24gcnVuIGNvbXBsZXRpb24gb3IgZnJvbSBhIHRpbWVyO1xcbml0IGlzIGRlbmllZCBieSBkZXNpZ24gdGhlcmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSB0d28gcmVnaW9ucyBhcmUgdHdvIHNhbmRib3hlZCBmcmFtZXMgYW5kIHNoYXJlIG5vIG1lbW9yeTsgc2VlIFxcXCJUaGUgdHdvIGhhbHZlcyBhcmVcXG50d28gZnJhbWVzXFxcIiBhYm92ZSBmb3IgaG93IHRoZXkgc3RheSBpbiBzdGVwLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZXZlbG9waW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXZlbG9waW5nXCIgLz57XCJEZXZlbG9waW5nXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXNoXCI+e1wibnBtIGNpXFxubnBtIHJ1biBkZXYgICAgICMgc3RhbmRhbG9uZTsgbm8gd29ya2luZyB0cmVlLCBzbyB0aGUgcGxhY2Vob2xkZXIgZXhwbGFpbnMgaXRzZWxmXFxubnBtIHRlc3RcXG5ucG0gcnVuIGxpbnRcXG5ucG0gcnVuIGJ1aWxkXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRvIHJ1biBpdCBpbnNpZGUgdGhlIHJlYWwgd29ya2JlbmNoLCBzZXJ2ZSB0aGUgd29ya2luZyB0cmVlIGFuZCBiaW5kIGl0IHRvIGEgcmVnaW9uOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXNoXCI+e1wiaW1tZWRpYXRlbHkucnVuIGRldiAuIC0tcmVnaW9uIHBhbmVsLnRvb2xzIC0tb3JpZ2luIGh0dHBzOi8vbG9jYWwuaW1tZWRpYXRlbHkucnVuXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoYXQgb25seSB3b3JrcyBvbmNlIHRoZSByZWdpb24gZXhpc3RzIGluIHRoZSBob3N0J3MgYnVpbGQgZGVmYXVsdHMgKFIzLTM4NykuIEJlZm9yZVxcbnRoZW4gaXQgZmFpbHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaWxlbnRseVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHBhZ2UgcmVuZGVycyBhbmQgdGhlIHJlZ2lvbiBsb2FkcyBub3RoaW5nLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2pCLEtBQUssQ0FBQ2tCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbEIsV0FBVztFQUNoQyxJQUFJLENBQUNrQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXRCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQXZCLFdBQUEsQ0FBQXdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDRyxFQUFFO01BQUNvQixFQUFFLEVBQUMsZ0RBQWdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0QsQ0FBRSxDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLEdBQUUsaURBQWlELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLEdBQUUsc0ZBQXNGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHVZQUF1WSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLHlDQUF5QztRQUFBSCxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQXFCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsb0pBQW9KO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsT0FBTztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsT0FBTztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sQ0FBQztNQUFBZ0IsUUFBQSxFQUFFO0lBQXlDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1MsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBYSxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0YsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxzRkFBc0YsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLE9BQU87SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrQkFBa0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxvQkFBb0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywwREFBMEQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsMERBQTBEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywwQkFBMEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNPLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFzbEQsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsb0pBQW9KO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWdDLENBQXFCLENBQUMsRUFBQyxrUkFBa1IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsbUpBQW1KO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLHdGQUF3RixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyx3SEFBd0g7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsNFNBQTRTO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBb0MsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDZSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxtQ0FBbUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFvQixRQUFBLEVBQUU7VUFBUyxDQUFtQixDQUFDLEVBQUMscUNBQXFDO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDJOQUEyTixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsZUFBZTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLDRKQUE0SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBdUksQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsWUFBWTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVksQ0FBRSxDQUFDLEVBQUMsWUFBWTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ08sR0FBRztNQUFBZSxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDd0IsU0FBUyxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQW9JLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDTSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBc0YsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDTyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUN3QixTQUFTLEVBQUMsYUFBYTtRQUFBSixRQUFBLEVBQUU7TUFBcUYsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxzR0FBc0csZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxtREFBbUQ7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzEyUztBQUNlLFNBQVNLLFVBQVVBLENBQUM1QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2pCLEtBQUssQ0FBQ2tCO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUF1QixRQUFBLGVBQUUsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQzFCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}