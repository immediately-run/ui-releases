var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ColorPicker;
var _sdk = require("@immediately-run/sdk");
require("./ColorPicker.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The pick-color task callee (UI_AS_APPS_SPEC §5.7). Reads the invocation params
// via `useTaskInput()` (the caller's `initial` color, untrusted but harmless), and
// returns the chosen color to the caller via `completeTask({ color })`. `cancelTask`
// aborts — though the host always owns dismiss (T28), so the overlay's Escape/close
// work even if this code never calls it.
// A small, friendly default palette.
const SWATCHES = ["#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16", "#22c55e", "#10b981", "#14b8a6", "#06b6d4", "#3b82f6", "#6366f1", "#8b5cf6", "#a855f7", "#d946ef", "#ec4899", "#f43f5e", "#64748b", "#1e293b", "#ffffff", "#000000"];
const asString = (v, fallback) => typeof v === "string" ? v : fallback;
function ColorPicker() {
  _s();
  const input = (0, _sdk.useTaskInput)();
  const initial = asString(input?.params.initial, "#3b82f6");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "cp",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "cp-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "cp-title",
        children: "Pick a color \xB7 GATE-2 VARIANT"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "cp-current",
        "aria-label": `current color ${initial}`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "cp-chip",
          style: {
            background: initial
          }
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: initial
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "cp-grid",
      role: "listbox",
      "aria-label": "Colors",
      children: SWATCHES.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        role: "option",
        "aria-selected": c.toLowerCase() === initial.toLowerCase(),
        className: "cp-swatch",
        style: {
          background: c
        },
        title: c,
        "aria-label": c,
        onClick: () => (0, _sdk.completeTask)({
          color: c
        })
      }, c))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("footer", {
      className: "cp-foot",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "cp-cancel",
        onClick: () => (0, _sdk.cancelTask)(),
        children: "Cancel"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "cp-keep",
        onClick: () => (0, _sdk.completeTask)({
          color: initial
        }),
        children: ["Keep ", initial]
      })]
    })]
  });
}
_s(ColorPicker, "9A88pMYRJAnn1YeI1djcXH3MZ8M=", false, function () {
  return [_sdk.useTaskInput];
});
_c = ColorPicker;
var _c;
$RefreshReg$(_c, "ColorPicker");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJTV0FUQ0hFUyIsImFzU3RyaW5nIiwidiIsImZhbGxiYWNrIiwiQ29sb3JQaWNrZXIiLCJpbnB1dCIsInVzZVRhc2tJbnB1dCIsImluaXRpYWwiLCJwYXJhbXMiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJzdHlsZSIsImJhY2tncm91bmQiLCJyb2xlIiwibWFwIiwiYyIsInR5cGUiLCJ0b0xvd2VyQ2FzZSIsInRpdGxlIiwib25DbGljayIsImNvbXBsZXRlVGFzayIsImNvbG9yIiwiY2FuY2VsVGFzayIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29sb3JQaWNrZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBwaWNrLWNvbG9yIHRhc2sgY2FsbGVlIChVSV9BU19BUFBTX1NQRUMgwqc1LjcpLiBSZWFkcyB0aGUgaW52b2NhdGlvbiBwYXJhbXNcbi8vIHZpYSBgdXNlVGFza0lucHV0KClgICh0aGUgY2FsbGVyJ3MgYGluaXRpYWxgIGNvbG9yLCB1bnRydXN0ZWQgYnV0IGhhcm1sZXNzKSwgYW5kXG4vLyByZXR1cm5zIHRoZSBjaG9zZW4gY29sb3IgdG8gdGhlIGNhbGxlciB2aWEgYGNvbXBsZXRlVGFzayh7IGNvbG9yIH0pYC4gYGNhbmNlbFRhc2tgXG4vLyBhYm9ydHMg4oCUIHRob3VnaCB0aGUgaG9zdCBhbHdheXMgb3ducyBkaXNtaXNzIChUMjgpLCBzbyB0aGUgb3ZlcmxheSdzIEVzY2FwZS9jbG9zZVxuLy8gd29yayBldmVuIGlmIHRoaXMgY29kZSBuZXZlciBjYWxscyBpdC5cbmltcG9ydCB7IHVzZVRhc2tJbnB1dCwgY29tcGxldGVUYXNrLCBjYW5jZWxUYXNrIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgXCIuL0NvbG9yUGlja2VyLmNzc1wiO1xuXG4vLyBBIHNtYWxsLCBmcmllbmRseSBkZWZhdWx0IHBhbGV0dGUuXG5jb25zdCBTV0FUQ0hFUyA9IFtcbiAgXCIjZWY0NDQ0XCIsIFwiI2Y5NzMxNlwiLCBcIiNmNTllMGJcIiwgXCIjZWFiMzA4XCIsXG4gIFwiIzg0Y2MxNlwiLCBcIiMyMmM1NWVcIiwgXCIjMTBiOTgxXCIsIFwiIzE0YjhhNlwiLFxuICBcIiMwNmI2ZDRcIiwgXCIjM2I4MmY2XCIsIFwiIzYzNjZmMVwiLCBcIiM4YjVjZjZcIixcbiAgXCIjYTg1NWY3XCIsIFwiI2Q5NDZlZlwiLCBcIiNlYzQ4OTlcIiwgXCIjZjQzZjVlXCIsXG4gIFwiIzY0NzQ4YlwiLCBcIiMxZTI5M2JcIiwgXCIjZmZmZmZmXCIsIFwiIzAwMDAwMFwiLFxuXTtcblxuY29uc3QgYXNTdHJpbmcgPSAodjogdW5rbm93biwgZmFsbGJhY2s6IHN0cmluZyk6IHN0cmluZyA9PlxuICB0eXBlb2YgdiA9PT0gXCJzdHJpbmdcIiA/IHYgOiBmYWxsYmFjaztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ29sb3JQaWNrZXIoKSB7XG4gIGNvbnN0IGlucHV0ID0gdXNlVGFza0lucHV0KCk7XG4gIGNvbnN0IGluaXRpYWwgPSBhc1N0cmluZyhpbnB1dD8ucGFyYW1zLmluaXRpYWwsIFwiIzNiODJmNlwiKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY3BcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiY3AtaGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3AtdGl0bGVcIj5QaWNrIGEgY29sb3IgwrcgR0FURS0yIFZBUklBTlQ8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNwLWN1cnJlbnRcIiBhcmlhLWxhYmVsPXtgY3VycmVudCBjb2xvciAke2luaXRpYWx9YH0+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3AtY2hpcFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGluaXRpYWwgfX0gLz5cbiAgICAgICAgICA8Y29kZT57aW5pdGlhbH08L2NvZGU+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNwLWdyaWRcIiByb2xlPVwibGlzdGJveFwiIGFyaWEtbGFiZWw9XCJDb2xvcnNcIj5cbiAgICAgICAge1NXQVRDSEVTLm1hcCgoYykgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17Y31cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgcm9sZT1cIm9wdGlvblwiXG4gICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXtjLnRvTG93ZXJDYXNlKCkgPT09IGluaXRpYWwudG9Mb3dlckNhc2UoKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImNwLXN3YXRjaFwiXG4gICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBjIH19XG4gICAgICAgICAgICB0aXRsZT17Y31cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2N9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb21wbGV0ZVRhc2soeyBjb2xvcjogYyB9KX1cbiAgICAgICAgICAvPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cImNwLWZvb3RcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY3AtY2FuY2VsXCIgb25DbGljaz17KCkgPT4gY2FuY2VsVGFzaygpfT5cbiAgICAgICAgICBDYW5jZWxcbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJjcC1rZWVwXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb21wbGV0ZVRhc2soeyBjb2xvcjogaW5pdGlhbCB9KX1cbiAgICAgICAgPlxuICAgICAgICAgIEtlZXAge2luaXRpYWx9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb290ZXI+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBQSxPQUFBO0FBQTJCLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLElBQUFFLEVBQUEsR0FBQUMsWUFBQSxJQU4zQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQSxNQUFNQyxRQUFRLEdBQUcsQ0FDZixTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQzFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFDMUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUMxQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQzFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FDM0M7QUFFRCxNQUFNQyxRQUFRLEdBQUdBLENBQUNDLENBQVUsRUFBRUMsUUFBZ0IsS0FDNUMsT0FBT0QsQ0FBQyxLQUFLLFFBQVEsR0FBR0EsQ0FBQyxHQUFHQyxRQUFRO0FBRXZCLFNBQVNDLFdBQVdBLENBQUEsRUFBRztFQUFBTixFQUFBO0VBQ3BDLE1BQU1PLEtBQUssR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDNUIsTUFBTUMsT0FBTyxHQUFHTixRQUFRLENBQUNJLEtBQUssRUFBRUcsTUFBTSxDQUFDRCxPQUFPLEVBQUUsU0FBUyxDQUFDO0VBRTFELG9CQUNFLElBQUFWLFdBQUEsQ0FBQVksSUFBQTtJQUFLQyxTQUFTLEVBQUMsSUFBSTtJQUFBQyxRQUFBLGdCQUNqQixJQUFBZCxXQUFBLENBQUFZLElBQUE7TUFBUUMsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxnQkFDdkIsSUFBQWQsV0FBQSxDQUFBZSxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUE2QixDQUFNLENBQUMsZUFDL0QsSUFBQWQsV0FBQSxDQUFBWSxJQUFBO1FBQU1DLFNBQVMsRUFBQyxZQUFZO1FBQUMsY0FBWSxpQkFBaUJILE9BQU8sRUFBRztRQUFBSSxRQUFBLGdCQUNsRSxJQUFBZCxXQUFBLENBQUFlLEdBQUE7VUFBTUYsU0FBUyxFQUFDLFNBQVM7VUFBQ0csS0FBSyxFQUFFO1lBQUVDLFVBQVUsRUFBRVA7VUFBUTtRQUFFLENBQUUsQ0FBQyxlQUM1RCxJQUFBVixXQUFBLENBQUFlLEdBQUE7VUFBQUQsUUFBQSxFQUFPSjtRQUFPLENBQU8sQ0FBQztNQUFBLENBQ2xCLENBQUM7SUFBQSxDQUNELENBQUMsZUFFVCxJQUFBVixXQUFBLENBQUFlLEdBQUE7TUFBS0YsU0FBUyxFQUFDLFNBQVM7TUFBQ0ssSUFBSSxFQUFDLFNBQVM7TUFBQyxjQUFXLFFBQVE7TUFBQUosUUFBQSxFQUN4RFgsUUFBUSxDQUFDZ0IsR0FBRyxDQUFFQyxDQUFDLGlCQUNkLElBQUFwQixXQUFBLENBQUFlLEdBQUE7UUFFRU0sSUFBSSxFQUFDLFFBQVE7UUFDYkgsSUFBSSxFQUFDLFFBQVE7UUFDYixpQkFBZUUsQ0FBQyxDQUFDRSxXQUFXLENBQUMsQ0FBQyxLQUFLWixPQUFPLENBQUNZLFdBQVcsQ0FBQyxDQUFFO1FBQ3pEVCxTQUFTLEVBQUMsV0FBVztRQUNyQkcsS0FBSyxFQUFFO1VBQUVDLFVBQVUsRUFBRUc7UUFBRSxDQUFFO1FBQ3pCRyxLQUFLLEVBQUVILENBQUU7UUFDVCxjQUFZQSxDQUFFO1FBQ2RJLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLElBQUFDLGlCQUFZLEVBQUM7VUFBRUMsS0FBSyxFQUFFTjtRQUFFLENBQUM7TUFBRSxHQVJyQ0EsQ0FTTixDQUNGO0lBQUMsQ0FDQyxDQUFDLGVBRU4sSUFBQXBCLFdBQUEsQ0FBQVksSUFBQTtNQUFRQyxTQUFTLEVBQUMsU0FBUztNQUFBQyxRQUFBLGdCQUN6QixJQUFBZCxXQUFBLENBQUFlLEdBQUE7UUFBUU0sSUFBSSxFQUFDLFFBQVE7UUFBQ1IsU0FBUyxFQUFDLFdBQVc7UUFBQ1csT0FBTyxFQUFFQSxDQUFBLEtBQU0sSUFBQUcsZUFBVSxFQUFDLENBQUU7UUFBQWIsUUFBQSxFQUFDO01BRXpFLENBQVEsQ0FBQyxlQUNULElBQUFkLFdBQUEsQ0FBQVksSUFBQTtRQUNFUyxJQUFJLEVBQUMsUUFBUTtRQUNiUixTQUFTLEVBQUMsU0FBUztRQUNuQlcsT0FBTyxFQUFFQSxDQUFBLEtBQU0sSUFBQUMsaUJBQVksRUFBQztVQUFFQyxLQUFLLEVBQUVoQjtRQUFRLENBQUMsQ0FBRTtRQUFBSSxRQUFBLEdBQ2pELE9BQ00sRUFBQ0osT0FBTztNQUFBLENBQ1AsQ0FBQztJQUFBLENBQ0gsQ0FBQztFQUFBLENBQ04sQ0FBQztBQUVWO0FBQUNULEVBQUEsQ0E1Q3VCTSxXQUFXO0VBQUEsUUFDbkJFLGlCQUFZO0FBQUE7QUFBQW1CLEVBQUEsR0FESnJCLFdBQVc7QUFBQSxJQUFBcUIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}