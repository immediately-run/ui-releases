var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./App.css");
var _ColorPicker = _interopRequireDefault(require("./components/ColorPicker"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The Phase-09 pilot TASK app: it `provides` the `pick-color` contract (§5.7).
// It is loaded ONLY into a host-owned overlay when another app
// `invokeTask('pick-color', …)`s it, reads its params via the SDK, and returns a
// color with `completeTask`. It holds NO standing authority — it computes over its
// arguments (the §5.7 invariant: data crosses, ambient authority does not).

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ColorPicker.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0NvbG9yUGlja2VyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwianN4IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLlxuLy8gVGhlIFBoYXNlLTA5IHBpbG90IFRBU0sgYXBwOiBpdCBgcHJvdmlkZXNgIHRoZSBgcGljay1jb2xvcmAgY29udHJhY3QgKMKnNS43KS5cbi8vIEl0IGlzIGxvYWRlZCBPTkxZIGludG8gYSBob3N0LW93bmVkIG92ZXJsYXkgd2hlbiBhbm90aGVyIGFwcFxuLy8gYGludm9rZVRhc2soJ3BpY2stY29sb3InLCDigKYpYHMgaXQsIHJlYWRzIGl0cyBwYXJhbXMgdmlhIHRoZSBTREssIGFuZCByZXR1cm5zIGFcbi8vIGNvbG9yIHdpdGggYGNvbXBsZXRlVGFza2AuIEl0IGhvbGRzIE5PIHN0YW5kaW5nIGF1dGhvcml0eSDigJQgaXQgY29tcHV0ZXMgb3ZlciBpdHNcbi8vIGFyZ3VtZW50cyAodGhlIMKnNS43IGludmFyaWFudDogZGF0YSBjcm9zc2VzLCBhbWJpZW50IGF1dGhvcml0eSBkb2VzIG5vdCkuXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5pbXBvcnQgQ29sb3JQaWNrZXIgZnJvbSBcIi4vY29tcG9uZW50cy9Db2xvclBpY2tlclwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiA8Q29sb3JQaWNrZXIgLz47XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUFBLE9BQUE7QUFDQUEsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUFtRCxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxTQUFBRSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVJuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQ2Isb0JBQU8sSUFBQUosV0FBQSxDQUFBSyxHQUFBLEVBQUNQLFlBQUEsQ0FBQUssT0FBVyxJQUFFLENBQUM7QUFDeEI7QUFBQ0csRUFBQSxHQUZRRixHQUFHO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFMLE9BQUEsR0FJR0MsR0FBRztBQUFBLElBQUFFLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}