var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "color-picker",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "color-picker"
      }), "color-picker"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The Phase-09 pilot ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "task app"
      }), " for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), ". It\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides"
      }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "pick-color"
      }), " task contract (UI_AS_APPS_SPEC §5.7): another app calls\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokeTask('pick-color', { initial })"
      }), ", the host loads this into a host-owned\noverlay, and it returns the chosen color via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "completeTask({ color })"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no standing authority"
      }), " — it computes over its arguments (the §5.7\ninvariant: data crosses, ambient authority does not). Like any binding it is\nforkable (§7): fork the picker and every app that invokes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "pick-color"
      }), " gets yours."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "// package.json\n\"immediately.run\": { \"provides\": [{ \"task\": \"pick-color\", \"version\": \"1.0\" }] }\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwicCIsInByZSIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiY29sb3ItcGlja2VyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb2xvci1waWNrZXJcIiAvPntcImNvbG9yLXBpY2tlclwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFBoYXNlLTA5IHBpbG90IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGFzayBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm9yIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCIuIEl0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmlkZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwaWNrLWNvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrIGNvbnRyYWN0IChVSV9BU19BUFBTX1NQRUMgwqc1LjcpOiBhbm90aGVyIGFwcCBjYWxsc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2soJ3BpY2stY29sb3InLCB7IGluaXRpYWwgfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgaG9zdCBsb2FkcyB0aGlzIGludG8gYSBob3N0LW93bmVkXFxub3ZlcmxheSwgYW5kIGl0IHJldHVybnMgdGhlIGNob3NlbiBjb2xvciB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGxldGVUYXNrKHsgY29sb3IgfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJdCBob2xkcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHN0YW5kaW5nIGF1dGhvcml0eVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaXQgY29tcHV0ZXMgb3ZlciBpdHMgYXJndW1lbnRzICh0aGUgwqc1LjdcXG5pbnZhcmlhbnQ6IGRhdGEgY3Jvc3NlcywgYW1iaWVudCBhdXRob3JpdHkgZG9lcyBub3QpLiBMaWtlIGFueSBiaW5kaW5nIGl0IGlzXFxuZm9ya2FibGUgKMKnNyk6IGZvcmsgdGhlIHBpY2tlciBhbmQgZXZlcnkgYXBwIHRoYXQgaW52b2tlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwaWNrLWNvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBnZXRzIHlvdXJzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWpzb25jXCI+e1wiLy8gcGFja2FnZS5qc29uXFxuXFxcImltbWVkaWF0ZWx5LnJ1blxcXCI6IHsgXFxcInByb3ZpZGVzXFxcIjogW3sgXFxcInRhc2tcXFwiOiBcXFwicGljay1jb2xvclxcXCIsIFxcXCJ2ZXJzaW9uXFxcIjogXFxcIjEuMFxcXCIgfV0gfVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1IsS0FBSyxDQUFDUztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1QsV0FBVztFQUNoQyxJQUFJLENBQUNTLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBYixXQUFBLENBQUFjLElBQUEsRUFBQWQsV0FBQSxDQUFBZSxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNHLEVBQUU7TUFBQ1csRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxDQUFDO01BQUFTLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNNLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLENBQUM7UUFBQ2UsSUFBSSxFQUFDLHlCQUF5QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNFLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNFLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLHdGQUF3RixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxDQUFDO01BQUFTLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDTSxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsdUxBQXVMLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDRSxJQUFJO1FBQUFXLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxjQUFjO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNLLEdBQUc7TUFBQVEsUUFBQSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDZSxTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsRUFBRTtNQUFnSCxDQUFtQjtJQUFDLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDNXlDO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ25CLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNvQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHUixLQUFLLENBQUNTO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQXZCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUtyQixLQUFLO0lBQUFjLFFBQUEsZUFBRSxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDakIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3NCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}