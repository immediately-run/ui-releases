var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _rollup = _interopRequireDefault(require("@mdx-js/rollup"));
var _pluginTypescript = _interopRequireDefault(require("@rollup/plugin-typescript"));
var _rollupPluginPostcss = _interopRequireDefault(require("rollup-plugin-postcss"));
var _pluginNodeResolve = require("@rollup/plugin-node-resolve");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const config = {
  input: "index.tsx",
  external: ["@immediately-run/sdk/v1", /node_modules/],
  output: {
    dir: "build"
  },
  plugins: [(0, _pluginNodeResolve.nodeResolve)({
    browser: true
  }), (0, _rollup.default)({/* jsxImportSource: …, otherOptions… */}), (0, _pluginTypescript.default)(), (0, _rollupPluginPostcss.default)({
    extract: true
  })]
};
var _default = exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcm9sbHVwIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfcGx1Z2luVHlwZXNjcmlwdCIsIl9yb2xsdXBQbHVnaW5Qb3N0Y3NzIiwiX3BsdWdpbk5vZGVSZXNvbHZlIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiY29uZmlnIiwiaW5wdXQiLCJleHRlcm5hbCIsIm91dHB1dCIsImRpciIsInBsdWdpbnMiLCJub2RlUmVzb2x2ZSIsImJyb3dzZXIiLCJtZHgiLCJ0eXBlc2NyaXB0IiwicG9zdGNzcyIsImV4dHJhY3QiLCJfZGVmYXVsdCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJyb2xsdXAuY29uZmlnLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbWR4IGZyb20gJ0BtZHgtanMvcm9sbHVwJztcbmltcG9ydCB0eXBlc2NyaXB0IGZyb20gJ0Byb2xsdXAvcGx1Z2luLXR5cGVzY3JpcHQnO1xuaW1wb3J0IHBvc3Rjc3MgZnJvbSAncm9sbHVwLXBsdWdpbi1wb3N0Y3NzJztcbmltcG9ydCB7IG5vZGVSZXNvbHZlIH0gZnJvbSAnQHJvbGx1cC9wbHVnaW4tbm9kZS1yZXNvbHZlJztcblxuY29uc3QgY29uZmlnID0ge1xuICBpbnB1dDogXCJpbmRleC50c3hcIixcbiAgZXh0ZXJuYWw6IFtcIkBpbW1lZGlhdGVseS1ydW4vc2RrL3YxXCIsIC9ub2RlX21vZHVsZXMvXSxcbiAgb3V0cHV0OiB7XG4gICAgZGlyOiBcImJ1aWxkXCJcbiAgfSxcbiAgcGx1Z2luczogW1xuICAgIG5vZGVSZXNvbHZlKHticm93c2VyOiB0cnVlfSksXG4gICAgbWR4KHsvKiBqc3hJbXBvcnRTb3VyY2U6IOKApiwgb3RoZXJPcHRpb25z4oCmICovfSksXG4gICAgdHlwZXNjcmlwdCgpLFxuICAgIHBvc3Rjc3Moe2V4dHJhY3Q6IHRydWV9KSxcbiAgXVxufVxuZXhwb3J0IGRlZmF1bHQgY29uZmlnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxPQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxpQkFBQSxHQUFBRixzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQUUsb0JBQUEsR0FBQUgsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFHLGtCQUFBLEdBQUFILE9BQUE7QUFBMEQsU0FBQUQsdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFMUQsTUFBTUcsTUFBTSxHQUFHO0VBQ2JDLEtBQUssRUFBRSxXQUFXO0VBQ2xCQyxRQUFRLEVBQUUsQ0FBQyx5QkFBeUIsRUFBRSxjQUFjLENBQUM7RUFDckRDLE1BQU0sRUFBRTtJQUNOQyxHQUFHLEVBQUU7RUFDUCxDQUFDO0VBQ0RDLE9BQU8sRUFBRSxDQUNQLElBQUFDLDhCQUFXLEVBQUM7SUFBQ0MsT0FBTyxFQUFFO0VBQUksQ0FBQyxDQUFDLEVBQzVCLElBQUFDLGVBQUcsRUFBQyxDQUFDLHdDQUF3QyxDQUFDLEVBQzlDLElBQUFDLHlCQUFVLEVBQUMsQ0FBQyxFQUNaLElBQUFDLDRCQUFPLEVBQUM7SUFBQ0MsT0FBTyxFQUFFO0VBQUksQ0FBQyxDQUFDO0FBRTVCLENBQUM7QUFBQSxJQUFBQyxRQUFBLEdBQUFDLE9BQUEsQ0FBQWQsT0FBQSxHQUNjQyxNQUFNIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}