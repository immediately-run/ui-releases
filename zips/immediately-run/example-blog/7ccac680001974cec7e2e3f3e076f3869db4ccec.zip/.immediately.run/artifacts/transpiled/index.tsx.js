var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("./styles2.css");
var _boot = require("@immediately-run/sdk/boot");
(0, _boot.boot)();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2Jvb3QiLCJib290Il0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4vc3R5bGVzMi5jc3NcIjtcbmltcG9ydCB7IGJvb3QgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvYm9vdFwiO1xuXG5ib290KCk7XG4iXSwibWFwcGluZ3MiOiI7O0FBQUFBLE9BQUE7QUFDQSxJQUFBQyxLQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxVQUFJLEVBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}