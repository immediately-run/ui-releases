var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Toc = void 0;
var _react = require("react");
var _jsxRuntime = require("react/jsx-runtime");
const Toc = () => {
  console.log("ASDFASDF");
  // @ts-ignore
  const MyTOC = /*#__PURE__*/(0, _react.lazy)(() => module.dynamicImport("./pages/landing.tsx", "*"));
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.Suspense, {
    fallback: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      children: "Loading..."
    }),
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("section", {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(MyTOC, {})
    })
  });
};
exports.Toc = Toc;
_c = Toc;
var _default = exports.default = Toc;
var _c;
$RefreshReg$(_c, "Toc");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJUb2MiLCJjb25zb2xlIiwibG9nIiwiTXlUT0MiLCJsYXp5IiwibW9kdWxlIiwiZHluYW1pY0ltcG9ydCIsImpzeCIsIlN1c3BlbnNlIiwiZmFsbGJhY2siLCJjaGlsZHJlbiIsImV4cG9ydHMiLCJfYyIsIl9kZWZhdWx0IiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBKU1ggfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFN1c3BlbnNlLCBsYXp5IH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCBUb2MgPSAoKTogSlNYLkVsZW1lbnQgPT4ge1xuICBjb25zb2xlLmxvZyhcIkFTREZBU0RGXCIpO1xuICAvLyBAdHMtaWdub3JlXG4gIGNvbnN0IE15VE9DID0gbGF6eSgoKSA9PiBtb2R1bGUuZHluYW1pY0ltcG9ydChcIi4vcGFnZXMvbGFuZGluZy50c3hcIiwgXCIqXCIpKTtcbiAgcmV0dXJuIChcbiAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxkaXY+TG9hZGluZy4uLjwvZGl2Pn0+XG4gICAgICA8c2VjdGlvbj5cbiAgICAgICAgPE15VE9DIC8+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgPC9TdXNwZW5zZT5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFRvYztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQXVDLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUVoQyxNQUFNRSxHQUFHLEdBQUdBLENBQUEsS0FBbUI7RUFDcENDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLFVBQVUsQ0FBQztFQUN2QjtFQUNBLE1BQU1DLEtBQUssZ0JBQUcsSUFBQUMsV0FBSSxFQUFDLE1BQU1DLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQzFFLG9CQUNFLElBQUFQLFdBQUEsQ0FBQVEsR0FBQSxFQUFDVixNQUFBLENBQUFXLFFBQVE7SUFBQ0MsUUFBUSxlQUFFLElBQUFWLFdBQUEsQ0FBQVEsR0FBQTtNQUFBRyxRQUFBLEVBQUs7SUFBVSxDQUFLLENBQUU7SUFBQUEsUUFBQSxlQUN4QyxJQUFBWCxXQUFBLENBQUFRLEdBQUE7TUFBQUcsUUFBQSxlQUNFLElBQUFYLFdBQUEsQ0FBQVEsR0FBQSxFQUFDSixLQUFLLElBQUU7SUFBQyxDQUNGO0VBQUMsQ0FDRixDQUFDO0FBRWYsQ0FBQztBQUFDUSxPQUFBLENBQUFYLEdBQUEsR0FBQUEsR0FBQTtBQUFBWSxFQUFBLEdBWFdaLEdBQUc7QUFBQSxJQUFBYSxRQUFBLEdBQUFGLE9BQUEsQ0FBQUcsT0FBQSxHQWFEZCxHQUFHO0FBQUEsSUFBQVksRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}