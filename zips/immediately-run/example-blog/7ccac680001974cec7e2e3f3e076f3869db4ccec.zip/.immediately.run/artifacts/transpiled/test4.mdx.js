var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      del: "del",
      h1: "h1",
      h2: "h2",
      input: "input",
      li: "li",
      ol: "ol",
      p: "p",
      section: "section",
      sup: "sup",
      table: "table",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "gfm",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gfm"
      }), "GFM"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "autolink-literals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "autolink-literals"
      }), "Autolink literals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "http://www.example.com",
        children: "www.example.com"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://example.com",
        children: "https://example.com"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "mailto:contact@example.com",
        children: "contact@example.com"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "footnote",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "footnote"
      }), "Footnote"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A note", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.sup, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#user-content-fn-1",
          id: "user-content-fnref-1",
          "data-footnote-ref": true,
          "aria-describedby": "footnote-label",
          children: "1"
        })
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "strikethrough",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "strikethrough"
      }), "Strikethrough"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
        children: "one"
      }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
        children: "two"
      }), " tildes."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "table",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "table"
      }), "Table"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.table, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "left"
            },
            children: "b"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "right"
            },
            children: "c"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "d"
          })]
        })
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "tasklist",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "tasklist"
      }), "Tasklist"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      className: "contains-task-list",
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", "to do"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          checked: true,
          disabled: true
        }), " ", "done"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/my/absolute/link.html",
        children: "absolute link somewhere"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/pages/test3.mdx",
        children: "another absolute link"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "sec-test4",
      "data-slug": "test4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-test4"
      }), "TEST4"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.section, {
      "data-footnotes": true,
      className: "footnotes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.h2, {
        className: "sr-only",
        id: "footnote-label",
        children: "Footnotes"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          id: "user-content-fn-1",
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
            children: ["Big note. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
              href: "#user-content-fnref-1",
              "data-footnote-backref": "",
              "aria-label": "Back to reference 1",
              className: "data-footnote-backref",
              children: "↩"
            })]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/test4.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiZGVsIiwiaDEiLCJoMiIsImlucHV0IiwibGkiLCJvbCIsInAiLCJzZWN0aW9uIiwic3VwIiwidGFibGUiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsInN0eWxlIiwidGV4dEFsaWduIiwiY2xhc3NOYW1lIiwidHlwZSIsImRpc2FibGVkIiwiY2hlY2tlZCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidGVzdDQubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGRlbDogXCJkZWxcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaW5wdXQ6IFwiaW5wdXRcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc2VjdGlvbjogXCJzZWN0aW9uXCIsXG4gICAgc3VwOiBcInN1cFwiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZ2ZtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnZm1cIiAvPntcIkdGTVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYXV0b2xpbmstbGl0ZXJhbHNcIj48SGVhZGluZ0FuY2hvciBpZD1cImF1dG9saW5rLWxpdGVyYWxzXCIgLz57XCJBdXRvbGluayBsaXRlcmFsc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHA6Ly93d3cuZXhhbXBsZS5jb21cIj57XCJ3d3cuZXhhbXBsZS5jb21cIn08L19jb21wb25lbnRzLmE+e1wiLCBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9leGFtcGxlLmNvbVwiPntcImh0dHBzOi8vZXhhbXBsZS5jb21cIn08L19jb21wb25lbnRzLmE+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIm1haWx0bzpjb250YWN0QGV4YW1wbGUuY29tXCI+e1wiY29udGFjdEBleGFtcGxlLmNvbVwifTwvX2NvbXBvbmVudHMuYT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImZvb3Rub3RlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmb290bm90ZVwiIC8+e1wiRm9vdG5vdGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgbm90ZVwifTxfY29tcG9uZW50cy5zdXA+PF9jb21wb25lbnRzLmEgaHJlZj1cIiN1c2VyLWNvbnRlbnQtZm4tMVwiIGlkPVwidXNlci1jb250ZW50LWZucmVmLTFcIiBkYXRhLWZvb3Rub3RlLXJlZiBhcmlhLWRlc2NyaWJlZGJ5PVwiZm9vdG5vdGUtbGFiZWxcIj57XCIxXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMuc3VwPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdHJpa2V0aHJvdWdoXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdHJpa2V0aHJvdWdoXCIgLz57XCJTdHJpa2V0aHJvdWdoXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuZGVsPntcIm9uZVwifTwvX2NvbXBvbmVudHMuZGVsPntcIiBvciBcIn08X2NvbXBvbmVudHMuZGVsPntcInR3b1wifTwvX2NvbXBvbmVudHMuZGVsPntcIiB0aWxkZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRhYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0YWJsZVwiIC8+e1wiVGFibGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJhXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGggc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwibGVmdFwiXG4gIH19PntcImJcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJyaWdodFwiXG4gIH19PntcImNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCJkXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0YXNrbGlzdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGFza2xpc3RcIiAvPntcIlRhc2tsaXN0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWwgY2xhc3NOYW1lPVwiY29udGFpbnMtdGFzay1saXN0XCI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpIGNsYXNzTmFtZT1cInRhc2stbGlzdC1pdGVtXCI+PF9jb21wb25lbnRzLmlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkIC8+e1wiIFwifXtcInRvIGRvXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGkgY2xhc3NOYW1lPVwidGFzay1saXN0LWl0ZW1cIj48X2NvbXBvbmVudHMuaW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZCBkaXNhYmxlZCAvPntcIiBcIn17XCJkb25lXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5hIGhyZWY9XCIvbXkvYWJzb2x1dGUvbGluay5odG1sXCI+e1wiYWJzb2x1dGUgbGluayBzb21ld2hlcmVcIn08L19jb21wb25lbnRzLmE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9wYWdlcy90ZXN0My5tZHhcIj57XCJhbm90aGVyIGFic29sdXRlIGxpbmtcIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMSBpZD1cInNlYy10ZXN0NFwiIGRhdGEtc2x1Zz1cInRlc3Q0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdGVzdDRcIiAvPntcIlRFU1Q0XCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMuc2VjdGlvbiBkYXRhLWZvb3Rub3RlcyBjbGFzc05hbWU9XCJmb290bm90ZXNcIj48X2NvbXBvbmVudHMuaDIgY2xhc3NOYW1lPVwic3Itb25seVwiIGlkPVwiZm9vdG5vdGUtbGFiZWxcIj57XCJGb290bm90ZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGkgaWQ9XCJ1c2VyLWNvbnRlbnQtZm4tMVwiPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkJpZyBub3RlLiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiI3VzZXItY29udGVudC1mbnJlZi0xXCIgZGF0YS1mb290bm90ZS1iYWNrcmVmPVwiXCIgYXJpYS1sYWJlbD1cIkJhY2sgdG8gcmVmZXJlbmNlIDFcIiBjbGFzc05hbWU9XCJkYXRhLWZvb3Rub3RlLWJhY2tyZWZcIj57XCLihqlcIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08L19jb21wb25lbnRzLnNlY3Rpb24+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL3Rlc3Q0Lm1keGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsT0FBTyxFQUFFLFNBQVM7TUFDbEJDLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2xCLFdBQVc7RUFDaEMsSUFBSSxDQUFDa0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF0QixXQUFBLENBQUF1QixJQUFBLEVBQUF2QixXQUFBLENBQUF3QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtNQUFDb0IsRUFBRSxFQUFDLEtBQUs7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFLLENBQUUsQ0FBQyxFQUFDLEtBQUs7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLENBQUM7TUFBQWMsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxDQUFDO1FBQUN3QixJQUFJLEVBQUMsd0JBQXdCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyxxQkFBcUI7UUFBQUgsUUFBQSxFQUFFO01BQXFCLENBQWdCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLDRCQUE0QjtRQUFBSCxRQUFBLEVBQUU7TUFBcUIsQ0FBZ0IsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxVQUFVO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBVSxDQUFFLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO01BQUFjLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsR0FBRztRQUFBWSxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDd0IsSUFBSSxFQUFDLG9CQUFvQjtVQUFDRixFQUFFLEVBQUMsc0JBQXNCO1VBQUMseUJBQWlCO1VBQUMsb0JBQWlCLGdCQUFnQjtVQUFBRCxRQUFBLEVBQUU7UUFBRyxDQUFnQjtNQUFDLENBQWlCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLENBQUM7TUFBQWMsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxHQUFHO1FBQUFvQixRQUFBLEVBQUU7TUFBSyxDQUFrQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLEdBQUc7UUFBQW9CLFFBQUEsRUFBRTtNQUFLLENBQWtCLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsT0FBTztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsT0FBTztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csS0FBSztNQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDMXdDQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFMLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQ2MsS0FBSyxFQUFFO2NBQzlDQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFMLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQ2MsS0FBSyxFQUFFO2NBQzlDQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFMLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CO0lBQUMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsVUFBVTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVUsQ0FBRSxDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtNQUFDYSxTQUFTLEVBQUMsb0JBQW9CO01BQUFOLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtRQUFDc0IsU0FBUyxFQUFDLGdCQUFnQjtRQUFBTixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNLLEtBQUs7VUFBQ3dCLElBQUksRUFBQyxVQUFVO1VBQUNDLFFBQVE7UUFBQSxDQUFFLENBQUMsRUFBQyxHQUFHLEVBQUUsT0FBTztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpDLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtRQUFDc0IsU0FBUyxFQUFDLGdCQUFnQjtRQUFBTixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNLLEtBQUs7VUFBQ3dCLElBQUksRUFBQyxVQUFVO1VBQUNFLE9BQU87VUFBQ0QsUUFBUTtRQUFBLENBQUUsQ0FBQyxFQUFDLEdBQUcsRUFBRSxNQUFNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQyxXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLENBQUM7TUFBQWMsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxDQUFDO1FBQUN3QixJQUFJLEVBQUMsd0JBQXdCO1FBQUFILFFBQUEsRUFBRTtNQUF5QixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyxrQkFBa0I7UUFBQUgsUUFBQSxFQUFFO01BQXVCLENBQWdCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFdBQVc7TUFBQyxhQUFVLE9BQU87TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFXLENBQUUsQ0FBQyxFQUFDLE9BQU87SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNTLE9BQU87TUFBQyxzQkFBYztNQUFDbUIsU0FBUyxFQUFDLFdBQVc7TUFBQU4sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO1FBQUN3QixTQUFTLEVBQUMsU0FBUztRQUFDTCxFQUFFLEVBQUMsZ0JBQWdCO1FBQUFELFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7VUFBQ2lCLEVBQUUsRUFBQyxtQkFBbUI7VUFBQUQsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO1lBQUFjLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztjQUFDd0IsSUFBSSxFQUFDLHVCQUF1QjtjQUFDLHlCQUFzQixFQUFFO2NBQUMsY0FBVyxxQkFBcUI7Y0FBQ0csU0FBUyxFQUFDLHVCQUF1QjtjQUFBTixRQUFBLEVBQUU7WUFBRyxDQUFnQixDQUFDO1VBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFzQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzd6QztBQUNlLFNBQVNVLFVBQVVBLENBQUNqQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDa0MsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFsQiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtFQUNYLENBQUM7RUFDRCxPQUFPaUIsU0FBUyxnQkFBRyxJQUFBckMsV0FBQSxDQUFBMkIsR0FBQSxFQUFDVSxTQUFTO0lBQUEsR0FBS25DLEtBQUs7SUFBQXVCLFFBQUEsZUFBRSxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDMUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29DLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU2Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVhLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdiLEVBQUUsR0FBRyxvRUFBb0UsSUFBSWMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}