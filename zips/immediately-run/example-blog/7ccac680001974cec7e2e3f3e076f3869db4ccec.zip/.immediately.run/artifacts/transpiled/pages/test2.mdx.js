var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      del: "del",
      h1: "h1",
      h2: "h2",
      input: "input",
      li: "li",
      ol: "ol",
      p: "p",
      section: "section",
      sup: "sup",
      table: "table",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "gfm",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gfm"
      }), "GFM"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "autolink-literals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "autolink-literals"
      }), "Autolink literals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "http://www.example.com",
        children: "www.example.com"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://example.com",
        children: "https://example.com"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "mailto:contact@example.com",
        children: "contact@example.com"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "footnote",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "footnote"
      }), "Footnote"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A note", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.sup, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#user-content-fn-1",
          id: "user-content-fnref-1",
          "data-footnote-ref": true,
          "aria-describedby": "footnote-label",
          children: "1"
        })
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "strikethrough",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "strikethrough"
      }), "Strikethrough"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
        children: "one"
      }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
        children: "two"
      }), " tildes."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "table",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "table"
      }), "Table"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.table, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "left"
            },
            children: "b"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "right"
            },
            children: "c"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "d"
          })]
        })
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "tasklist",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "tasklist"
      }), "Tasklist"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      className: "contains-task-list",
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", "to do"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          checked: true,
          disabled: true
        }), " ", "done"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/my/absolute/link.html",
        children: "absolute link somewhere"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/pages/test3.mdx",
        children: "another absolute link"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./test3.mdx",
        children: "relative link 1"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../test4",
        children: "relative link 2"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.section, {
      "data-footnotes": true,
      className: "footnotes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.h2, {
        className: "sr-only",
        id: "footnote-label",
        children: "Footnotes"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          id: "user-content-fn-1",
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
            children: ["Big note. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
              href: "#user-content-fnref-1",
              "data-footnote-backref": "",
              "aria-label": "Back to reference 1",
              className: "data-footnote-backref",
              children: "↩"
            })]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/pages/test2.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiZGVsIiwiaDEiLCJoMiIsImlucHV0IiwibGkiLCJvbCIsInAiLCJzZWN0aW9uIiwic3VwIiwidGFibGUiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsInN0eWxlIiwidGV4dEFsaWduIiwiY2xhc3NOYW1lIiwidHlwZSIsImRpc2FibGVkIiwiY2hlY2tlZCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidGVzdDIubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGRlbDogXCJkZWxcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaW5wdXQ6IFwiaW5wdXRcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc2VjdGlvbjogXCJzZWN0aW9uXCIsXG4gICAgc3VwOiBcInN1cFwiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZ2ZtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnZm1cIiAvPntcIkdGTVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYXV0b2xpbmstbGl0ZXJhbHNcIj48SGVhZGluZ0FuY2hvciBpZD1cImF1dG9saW5rLWxpdGVyYWxzXCIgLz57XCJBdXRvbGluayBsaXRlcmFsc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHA6Ly93d3cuZXhhbXBsZS5jb21cIj57XCJ3d3cuZXhhbXBsZS5jb21cIn08L19jb21wb25lbnRzLmE+e1wiLCBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9leGFtcGxlLmNvbVwiPntcImh0dHBzOi8vZXhhbXBsZS5jb21cIn08L19jb21wb25lbnRzLmE+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIm1haWx0bzpjb250YWN0QGV4YW1wbGUuY29tXCI+e1wiY29udGFjdEBleGFtcGxlLmNvbVwifTwvX2NvbXBvbmVudHMuYT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImZvb3Rub3RlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmb290bm90ZVwiIC8+e1wiRm9vdG5vdGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgbm90ZVwifTxfY29tcG9uZW50cy5zdXA+PF9jb21wb25lbnRzLmEgaHJlZj1cIiN1c2VyLWNvbnRlbnQtZm4tMVwiIGlkPVwidXNlci1jb250ZW50LWZucmVmLTFcIiBkYXRhLWZvb3Rub3RlLXJlZiBhcmlhLWRlc2NyaWJlZGJ5PVwiZm9vdG5vdGUtbGFiZWxcIj57XCIxXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMuc3VwPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdHJpa2V0aHJvdWdoXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdHJpa2V0aHJvdWdoXCIgLz57XCJTdHJpa2V0aHJvdWdoXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuZGVsPntcIm9uZVwifTwvX2NvbXBvbmVudHMuZGVsPntcIiBvciBcIn08X2NvbXBvbmVudHMuZGVsPntcInR3b1wifTwvX2NvbXBvbmVudHMuZGVsPntcIiB0aWxkZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRhYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0YWJsZVwiIC8+e1wiVGFibGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJhXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGggc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwibGVmdFwiXG4gIH19PntcImJcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJyaWdodFwiXG4gIH19PntcImNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCJkXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0YXNrbGlzdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGFza2xpc3RcIiAvPntcIlRhc2tsaXN0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWwgY2xhc3NOYW1lPVwiY29udGFpbnMtdGFzay1saXN0XCI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpIGNsYXNzTmFtZT1cInRhc2stbGlzdC1pdGVtXCI+PF9jb21wb25lbnRzLmlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkIC8+e1wiIFwifXtcInRvIGRvXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGkgY2xhc3NOYW1lPVwidGFzay1saXN0LWl0ZW1cIj48X2NvbXBvbmVudHMuaW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZCBkaXNhYmxlZCAvPntcIiBcIn17XCJkb25lXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5hIGhyZWY9XCIvbXkvYWJzb2x1dGUvbGluay5odG1sXCI+e1wiYWJzb2x1dGUgbGluayBzb21ld2hlcmVcIn08L19jb21wb25lbnRzLmE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9wYWdlcy90ZXN0My5tZHhcIj57XCJhbm90aGVyIGFic29sdXRlIGxpbmtcIn08L19jb21wb25lbnRzLmE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vdGVzdDMubWR4XCI+e1wicmVsYXRpdmUgbGluayAxXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi90ZXN0NFwiPntcInJlbGF0aXZlIGxpbmsgMlwifTwvX2NvbXBvbmVudHMuYT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnNlY3Rpb24gZGF0YS1mb290bm90ZXMgY2xhc3NOYW1lPVwiZm9vdG5vdGVzXCI+PF9jb21wb25lbnRzLmgyIGNsYXNzTmFtZT1cInNyLW9ubHlcIiBpZD1cImZvb3Rub3RlLWxhYmVsXCI+e1wiRm9vdG5vdGVzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpIGlkPVwidXNlci1jb250ZW50LWZuLTFcIj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJCaWcgbm90ZS4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIiN1c2VyLWNvbnRlbnQtZm5yZWYtMVwiIGRhdGEtZm9vdG5vdGUtYmFja3JlZj1cIlwiIGFyaWEtbGFiZWw9XCJCYWNrIHRvIHJlZmVyZW5jZSAxXCIgY2xhc3NOYW1lPVwiZGF0YS1mb290bm90ZS1iYWNrcmVmXCI+e1wi4oapXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5zZWN0aW9uPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9wYWdlcy90ZXN0Mi5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE9BQU8sRUFBRSxTQUFTO01BQ2xCQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHakIsS0FBSyxDQUFDa0I7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdsQixXQUFXO0VBQ2hDLElBQUksQ0FBQ2tCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBdEIsV0FBQSxDQUFBdUIsSUFBQSxFQUFBdkIsV0FBQSxDQUFBd0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNHLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxLQUFLO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBSyxDQUFFLENBQUMsRUFBQyxLQUFLO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO01BQUFjLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLHdCQUF3QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxDQUFDO1FBQUN3QixJQUFJLEVBQUMscUJBQXFCO1FBQUFILFFBQUEsRUFBRTtNQUFxQixDQUFnQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyw0QkFBNEI7UUFBQUgsUUFBQSxFQUFFO01BQXFCLENBQWdCLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsVUFBVTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVUsQ0FBRSxDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBYyxRQUFBLEdBQUUsUUFBUSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNVLEdBQUc7UUFBQVksUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7VUFBQ3dCLElBQUksRUFBQyxvQkFBb0I7VUFBQ0YsRUFBRSxFQUFDLHNCQUFzQjtVQUFDLHlCQUFpQjtVQUFDLG9CQUFpQixnQkFBZ0I7VUFBQUQsUUFBQSxFQUFFO1FBQUcsQ0FBZ0I7TUFBQyxDQUFpQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO01BQUFjLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsR0FBRztRQUFBb0IsUUFBQSxFQUFFO01BQUssQ0FBa0IsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxHQUFHO1FBQUFvQixRQUFBLEVBQUU7TUFBSyxDQUFrQixDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLE9BQU87SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEtBQUs7TUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQ2MsS0FBSyxFQUFFO2NBQzF3Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBTCxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBTCxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBTCxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQjtJQUFDLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLFVBQVU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFVLENBQUUsQ0FBQyxFQUFDLFVBQVU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7TUFBQ2EsU0FBUyxFQUFDLG9CQUFvQjtNQUFBTixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7UUFBQ3NCLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQU4sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDSyxLQUFLO1VBQUN3QixJQUFJLEVBQUMsVUFBVTtVQUFDQyxRQUFRO1FBQUEsQ0FBRSxDQUFDLEVBQUMsR0FBRyxFQUFFLE9BQU87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQyxXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7UUFBQ3NCLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQU4sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDSyxLQUFLO1VBQUN3QixJQUFJLEVBQUMsVUFBVTtVQUFDRSxPQUFPO1VBQUNELFFBQVE7UUFBQSxDQUFFLENBQUMsRUFBQyxHQUFHLEVBQUUsTUFBTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakMsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO01BQUFjLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLHdCQUF3QjtRQUFBSCxRQUFBLEVBQUU7TUFBeUIsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxDQUFDO1FBQUN3QixJQUFJLEVBQUMsa0JBQWtCO1FBQUFILFFBQUEsRUFBRTtNQUF1QixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyxhQUFhO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyxVQUFVO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNTLE9BQU87TUFBQyxzQkFBYztNQUFDbUIsU0FBUyxFQUFDLFdBQVc7TUFBQU4sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO1FBQUN3QixTQUFTLEVBQUMsU0FBUztRQUFDTCxFQUFFLEVBQUMsZ0JBQWdCO1FBQUFELFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7VUFBQ2lCLEVBQUUsRUFBQyxtQkFBbUI7VUFBQUQsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxDQUFDO1lBQUFjLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztjQUFDd0IsSUFBSSxFQUFDLHVCQUF1QjtjQUFDLHlCQUFzQixFQUFFO2NBQUMsY0FBVyxxQkFBcUI7Y0FBQ0csU0FBUyxFQUFDLHVCQUF1QjtjQUFBTixRQUFBLEVBQUU7WUFBRyxDQUFnQixDQUFDO1VBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFzQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQy8xQztBQUNlLFNBQVNVLFVBQVVBLENBQUNqQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDa0MsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFsQiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtFQUNYLENBQUM7RUFDRCxPQUFPaUIsU0FBUyxnQkFBRyxJQUFBckMsV0FBQSxDQUFBMkIsR0FBQSxFQUFDVSxTQUFTO0lBQUEsR0FBS25DLEtBQUs7SUFBQXVCLFFBQUEsZUFBRSxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDMUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29DLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU2Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVhLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdiLEVBQUUsR0FBRyxvRUFBb0UsSUFBSWMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsNkJBQTZCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDdlA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}