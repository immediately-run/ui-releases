var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      h3: "h3",
      li: "li",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "popular-posts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "popular-posts"
      }), "Popular Posts"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#",
          children: "10 Web Development Trends to Watch This Year"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#",
          children: "The Psychology Behind Effective UX Design"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#",
          children: "Building Sustainable Tech Habits"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#",
          children: "Cryptocurrency and the Future of Finance"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "#",
          children: "Remote Work Tools That Actually Work"
        })
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/pages/popular_posts.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiaDMiLCJsaSIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJwb3B1bGFyX3Bvc3RzLm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgzIGlkPVwicG9wdWxhci1wb3N0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwicG9wdWxhci1wb3N0c1wiIC8+e1wiUG9wdWxhciBQb3N0c1wifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuYSBocmVmPVwiI1wiPntcIjEwIFdlYiBEZXZlbG9wbWVudCBUcmVuZHMgdG8gV2F0Y2ggVGhpcyBZZWFyXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5hIGhyZWY9XCIjXCI+e1wiVGhlIFBzeWNob2xvZ3kgQmVoaW5kIEVmZmVjdGl2ZSBVWCBEZXNpZ25cIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmEgaHJlZj1cIiNcIj57XCJCdWlsZGluZyBTdXN0YWluYWJsZSBUZWNoIEhhYml0c1wifTwvX2NvbXBvbmVudHMuYT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuYSBocmVmPVwiI1wiPntcIkNyeXB0b2N1cnJlbmN5IGFuZCB0aGUgRnV0dXJlIG9mIEZpbmFuY2VcIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmEgaHJlZj1cIiNcIj57XCJSZW1vdGUgV29yayBUb29scyBUaGF0IEFjdHVhbGx5IFdvcmtcIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9wYWdlcy9wb3B1bGFyX3Bvc3RzLm1keGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR04sS0FBSyxDQUFDTztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1AsV0FBVztFQUNoQyxJQUFJLENBQUNPLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBWCxXQUFBLENBQUFZLElBQUEsRUFBQVosV0FBQSxDQUFBYSxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWQsV0FBQSxDQUFBWSxJQUFBLEVBQUNULFdBQVcsQ0FBQ0UsRUFBRTtNQUFDVSxFQUFFLEVBQUMsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFZLElBQUEsRUFBQ1QsV0FBVyxDQUFDSSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQWQsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7UUFBQVEsUUFBQSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDQyxDQUFDO1VBQUNhLElBQUksRUFBQyxHQUFHO1VBQUFILFFBQUEsRUFBRTtRQUE4QyxDQUFnQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWQsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7UUFBQVEsUUFBQSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDQyxDQUFDO1VBQUNhLElBQUksRUFBQyxHQUFHO1VBQUFILFFBQUEsRUFBRTtRQUEyQyxDQUFnQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWQsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7UUFBQVEsUUFBQSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDQyxDQUFDO1VBQUNhLElBQUksRUFBQyxHQUFHO1VBQUFILFFBQUEsRUFBRTtRQUFrQyxDQUFnQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWQsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7UUFBQVEsUUFBQSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDQyxDQUFDO1VBQUNhLElBQUksRUFBQyxHQUFHO1VBQUFILFFBQUEsRUFBRTtRQUEwQyxDQUFnQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWQsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7UUFBQVEsUUFBQSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDQyxDQUFDO1VBQUNhLElBQUksRUFBQyxHQUFHO1VBQUFILFFBQUEsRUFBRTtRQUFzQyxDQUFnQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwd0I7QUFDZSxTQUFTSSxVQUFVQSxDQUFDaEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2lCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdOLEtBQUssQ0FBQ087RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBcEIsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2xCLEtBQUs7SUFBQVksUUFBQSxlQUFFLElBQUFkLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2YsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ21CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcscUNBQXFDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDL1A7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}