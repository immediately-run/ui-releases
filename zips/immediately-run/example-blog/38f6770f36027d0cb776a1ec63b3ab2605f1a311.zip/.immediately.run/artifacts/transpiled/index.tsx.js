var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _boot = require("@immediately-run/sdk/boot");
var _logger = require("./lib/logger");
(0, _logger.initDiagnosticLogger)();
(0, _boot.boot)();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYm9vdCIsInJlcXVpcmUiLCJfbG9nZ2VyIiwiaW5pdERpYWdub3N0aWNMb2dnZXIiLCJib290Il0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3QgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvYm9vdFwiO1xuaW1wb3J0IHsgaW5pdERpYWdub3N0aWNMb2dnZXIgfSBmcm9tIFwiLi9saWIvbG9nZ2VyXCI7XG5cbmluaXREaWFnbm9zdGljTG9nZ2VyKCk7XG5ib290KCk7XG4iXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBQUEsS0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsNEJBQW9CLEVBQUMsQ0FBQztBQUN0QixJQUFBQyxVQUFJLEVBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}