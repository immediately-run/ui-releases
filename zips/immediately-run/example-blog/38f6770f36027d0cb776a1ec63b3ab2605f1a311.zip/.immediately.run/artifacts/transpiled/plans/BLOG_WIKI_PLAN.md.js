var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-blog-wiki-feature-implementation-plan",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-blog-wiki-feature-implementation-plan"
      }), "immediately.run Blog & Wiki — Feature Implementation Plan"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is a multi-phased engineering plan to build the customizable, theme-friendly Blog & Wiki application (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "example-blog"
      }), ") running natively on immediately.run."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This document defines the implementation roadmap, step-by-step instructions, and clear, measurable exit criteria for each phase. This plan is designed to be easily executed by a junior developer or a simple language model."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "phase-1-project-scaffolding-custom-component-ecosystem-core-layout",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "phase-1-project-scaffolding-custom-component-ecosystem-core-layout"
      }), "Phase 1: Project Scaffolding & Custom Component Ecosystem (Core Layout)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "goal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "goal"
      }), "Goal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Establish the project layout, wire up necessary styling and design tokens from the brand guidelines, and register custom global components that can be used inside MDX files without explicit imports."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "step-by-step-instructions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-by-step-instructions"
      }), "Step-by-Step Instructions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Design Tokens & Global CSS (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "styles2.css"
          }), "):"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Refactor ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "styles2.css"
            }), " (or define inline stylesheet overrides) to enforce the immediately.run brand styling:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
              children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Background: Cool near-black canvas (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "--bg"
                }), ")."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Ink/Text: Clean near-white/grey (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "--ink"
                }), ")."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Accents: Signature gradient (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "--grad"
                }), " token, e.g., ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: ".grad-text"
                }), ")."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Details/Metadata: Use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "Space Mono"
                }), " or monospace fonts."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Borders: Hairline solid lines (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "1px solid var(--panel)"
                }), ")."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
                children: "Hover Shadows: Hard-offset solid block shadows on clickable cards."
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Casing: Strict sentence case for headlines, with headings terminating in a period (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "Tech stack."
                }), ")."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
                  children: "No Emoji:"
                }), " Strip any present or future emojis from the layout."]
              }), "\n"]
            }), "\n"]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MDX Reusable Component Registry:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Create a directory for reusable layout elements: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/components/"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Implement the following default components (following the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "React Fast Refresh rule"
            }), " - one default-exported component per file, no mixed named exports of data/logic):", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
              children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "Callout.tsx"
                }), ": Renders high-contrast info/warning box with hairline borders."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "Button.tsx"
                }), ": Renders a clickable button with block hover-shadow styling."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "More.tsx"
                }), ": A simple placeholder component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "<div className=\"read-more-marker\" />"
                }), " used to identify content excerpt cutoff points."]
              }), "\n"]
            }), "\n"]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["MDX Provider Wiring (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          }), "):"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Refactor ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "App.tsx"
            }), " to serve as the single entry point."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Import ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "MDXProvider"
            }), " from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/sdk"
            }), " (or its specific path)."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Wrap the main application structure inside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<MDXProvider components={{ Callout, Button, More }}>"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Confirm that standard MDX files can evaluate ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Callout>"
            }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Button>"
            }), " tags without needing an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "import"
            }), " declaration within the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".mdx"
            }), " file."]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "exit-criteria",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "exit-criteria"
      }), "Exit Criteria"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " succeeds with zero errors."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Visual check: Layout features a cool near-black theme with sentence-case headlines ending in periods, hairline borders, and zero emojis."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Validation: An MDX file containing a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Callout>"
        }), " element compiles and renders without throwing reference or import errors."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "phase-2-metadata-harvesting-search-sidebar-categorization",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "phase-2-metadata-harvesting-search-sidebar-categorization"
      }), "Phase 2: Metadata Harvesting, Search & Sidebar Categorization"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "goal-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "goal-1"
      }), "Goal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Implement client-side frontmatter parsing and compilation of an in-memory metadata index to power list queries, tag categorization, and rapid search without any database backends."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "step-by-step-instructions-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-by-step-instructions-1"
      }), "Step-by-Step Instructions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Frontmatter Parser Utility (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/lib/parser.ts"
          }), "):"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Implement a lightweight parser that reads the first 1000 characters of an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".mdx"
            }), " file to parse YAML frontmatter block headers (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "title"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "date"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "tags"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readtime"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "excerpt"
            }), ")."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Local Metadata Indexer:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Integrate with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/sdk/hooks"
            }), " using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useMetadataQuery"
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useFileMetadata"
            }), " to load metadata for files inside the repository (under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "/app/pages/entries/"
            }), ")."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Sort posts dynamically by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "date"
            }), " (newest first)."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sidebar & Category System:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "Construct a category sidebar that extracts a unique set of all tags found across all posts."
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "Support clicking a tag card to filter the main articles grid dynamically."
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Instant Client-Side Search:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "Implement a search text field in the main view."
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "Filter the parsed in-memory metadata array instantly against the search query (matching titles, tags, and excerpts)."
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "exit-criteria-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "exit-criteria-1"
      }), "Exit Criteria"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The landing page compiles and correctly displays cards with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "title"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "date"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "readtime"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "excerpt"
        }), " extracted from the MDX frontmatter."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Clicking a category tag updates the articles grid to show only posts matching that category."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Typing into the search input filters list items immediately."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "phase-3-platform-editor-integration-defensive-permissions-gating",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "phase-3-platform-editor-integration-defensive-permissions-gating"
      }), "Phase 3: Platform Editor Integration & Defensive Permissions (Gating)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "goal-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "goal-2"
      }), "Goal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Wire up native immediately.run editing capabilities, checking filesystem read-only/read-write states defensively to respect the Zero-Chrome Principle for public readers."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "step-by-step-instructions-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-by-step-instructions-2"
      }), "Step-by-Step Instructions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Active Mode Check:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useContext(TinkerableContext)"
            }), " to read ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "navigationState.mode"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Determine if the app is currently in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'present'"
            }), " mode or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'edit'"
            }), " mode."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Defensive Permission Check (Zero-Chrome):"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Query active workspace mounts using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useMounts()"
            }), " or equivalent from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/sdk"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["If the active mount has ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: \"ro\""
            }), " (or user is unauthenticated), strip all edit icons, save buttons, and configuration options from the DOM."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Present-to-Edit Transition Button:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["If the active mount is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: \"rw\""
            }), " and the user is in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'present'"
            }), " mode, show an elegant ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "\"Edit Page\" (✎)"
            }), " button."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Clicking it calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "requestEdit({ path: currentPath })"
            }), " from the SDK to transition the workbench to edit mode."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Single-file Editing Task:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["If the user is in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'edit'"
            }), " mode, display an inline edit affordance."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Clicking it calls the host's native ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "edit-file"
            }), " task using the SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokeTask('edit-file', { file: capFile(...) })"
            }), " to open the file in the workspace CodeMirror editor."]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "exit-criteria-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "exit-criteria-2"
      }), "Exit Criteria"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "In read-only mounts or guest sessions, the layout is perfectly clean with zero edit chrome."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "In read-write mode, clicking the \"Edit Page\" button transitions the workspace into edit mode."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "In edit mode, clicking the edit icon successfully opens the target MDX file in the platform's editor."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "phase-4-content-extensibility-dynamic-imports-asset-loading",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "phase-4-content-extensibility-dynamic-imports-asset-loading"
      }), "Phase 4: Content Extensibility, Dynamic Imports & Asset Loading"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "goal-3",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "goal-3"
      }), "Goal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Enable the wiki to load dynamically from another mounted Space, support dynamic module resolution (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/mnt/{hash}/"
      }), " imports) within the MDX pages, and resolve local assets such as images."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "step-by-step-instructions-3",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-by-step-instructions-3"
      }), "Step-by-Step Instructions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Dynamic Workspace Auto-Detection:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["On launch, check the query parameters (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "?mount=space:xyz"
            }), ") or local storage."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Scan mounted filesystems for a standard ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "blog-config.json"
            }), " file. If present, load pages from that mount rather than the default in-repo path."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Stable Mount Path Resolution for Dynamic Imports:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["MDX pages inside external spaces can import React components (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "import Graph from './components/Graph'"
            }), "). Let the immediately.run runtime compiler resolve these dynamically relative to the stable mount path ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "/mnt/{hash}/"
            }), "."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Binary Image Asset Loader:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Implement an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Image>"
            }), " wrapper component for markdown images (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "![alt](./images/photo.png)"
            }), "):", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
              children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
                children: "Read file bytes from the dynamic path."
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Convert the byte array into a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "Blob"
                }), "."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
                children: ["Call ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                  children: "URL.createObjectURL(blob)"
                }), " to get a secure local URL."]
              }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
                children: "Revoke the object URL on unmount."
              }), "\n"]
            }), "\n"]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["React ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<ErrorBoundary>"
          }), " fallbacks:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Wrap MDX page renders and dynamically imported components in an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<ErrorBoundary>"
            }), " block. If a dynamic component fails to load or resolves to a missing path, render a clean fallback card instead of crashing the app."]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "exit-criteria-3",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "exit-criteria-3"
      }), "Exit Criteria"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "The blog successfully loads, indexes, and renders MDX files located on an external Space mount."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Relative imports inside the external MDX pages resolve and render successfully."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Relative image tags inside the external MDX files successfully display their graphic assets using the Blob URL loader."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Deleting an imported component displays a clean error banner on that specific page instead of throwing a blank screen crash."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "phase-5-build-linting-self-verification",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "phase-5-build-linting-self-verification"
      }), "Phase 5: Build, Linting & Self-Verification"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "goal-4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "goal-4"
      }), "Goal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Guarantee complete code hygiene, Fast Refresh compliance, error-free production compilation, and seamless hot reloading."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "step-by-step-instructions-4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-by-step-instructions-4"
      }), "Step-by-Step Instructions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lint Check:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "npm run lint"
            }), ". Fix any errors, focusing heavily on Fast Refresh violations (e.g. no mixed component and helper named exports)."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build Verification:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "npm run build"
            }), " using the project's rollup configuration. Fix any typescript or bundle compilation errors."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Interactive Manual Test:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "npm run dev"
            }), " to boot locally."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "Navigate pages, trigger search, click tags, and check layout transitions to ensure flawless operation."
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "exit-criteria-4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "exit-criteria-4"
      }), "Exit Criteria"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " yields zero warnings and zero errors."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " successfully compiles and outputs bundle files under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build/"
        }), " with no typescript or compilation errors."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/plans/BLOG_WIKI_PLAN.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJMT0dfV0lLSV9QTEFOLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJpbW1lZGlhdGVseXJ1bi1ibG9nLXdpa2ktZmVhdHVyZS1pbXBsZW1lbnRhdGlvbi1wbGFuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJpbW1lZGlhdGVseXJ1bi1ibG9nLXdpa2ktZmVhdHVyZS1pbXBsZW1lbnRhdGlvbi1wbGFuXCIgLz57XCJpbW1lZGlhdGVseS5ydW4gQmxvZyAmIFdpa2kg4oCUIEZlYXR1cmUgSW1wbGVtZW50YXRpb24gUGxhblwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyBhIG11bHRpLXBoYXNlZCBlbmdpbmVlcmluZyBwbGFuIHRvIGJ1aWxkIHRoZSBjdXN0b21pemFibGUsIHRoZW1lLWZyaWVuZGx5IEJsb2cgJiBXaWtpIGFwcGxpY2F0aW9uIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGFtcGxlLWJsb2dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBydW5uaW5nIG5hdGl2ZWx5IG9uIGltbWVkaWF0ZWx5LnJ1bi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBkb2N1bWVudCBkZWZpbmVzIHRoZSBpbXBsZW1lbnRhdGlvbiByb2FkbWFwLCBzdGVwLWJ5LXN0ZXAgaW5zdHJ1Y3Rpb25zLCBhbmQgY2xlYXIsIG1lYXN1cmFibGUgZXhpdCBjcml0ZXJpYSBmb3IgZWFjaCBwaGFzZS4gVGhpcyBwbGFuIGlzIGRlc2lnbmVkIHRvIGJlIGVhc2lseSBleGVjdXRlZCBieSBhIGp1bmlvciBkZXZlbG9wZXIgb3IgYSBzaW1wbGUgbGFuZ3VhZ2UgbW9kZWwuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBoYXNlLTEtcHJvamVjdC1zY2FmZm9sZGluZy1jdXN0b20tY29tcG9uZW50LWVjb3N5c3RlbS1jb3JlLWxheW91dFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGhhc2UtMS1wcm9qZWN0LXNjYWZmb2xkaW5nLWN1c3RvbS1jb21wb25lbnQtZWNvc3lzdGVtLWNvcmUtbGF5b3V0XCIgLz57XCJQaGFzZSAxOiBQcm9qZWN0IFNjYWZmb2xkaW5nICYgQ3VzdG9tIENvbXBvbmVudCBFY29zeXN0ZW0gKENvcmUgTGF5b3V0KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZ29hbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ29hbFwiIC8+e1wiR29hbFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXN0YWJsaXNoIHRoZSBwcm9qZWN0IGxheW91dCwgd2lyZSB1cCBuZWNlc3Nhcnkgc3R5bGluZyBhbmQgZGVzaWduIHRva2VucyBmcm9tIHRoZSBicmFuZCBndWlkZWxpbmVzLCBhbmQgcmVnaXN0ZXIgY3VzdG9tIGdsb2JhbCBjb21wb25lbnRzIHRoYXQgY2FuIGJlIHVzZWQgaW5zaWRlIE1EWCBmaWxlcyB3aXRob3V0IGV4cGxpY2l0IGltcG9ydHMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInN0ZXAtYnktc3RlcC1pbnN0cnVjdGlvbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtYnktc3RlcC1pbnN0cnVjdGlvbnNcIiAvPntcIlN0ZXAtYnktU3RlcCBJbnN0cnVjdGlvbnNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXNpZ24gVG9rZW5zICYgR2xvYmFsIENTUyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3R5bGVzMi5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlJlZmFjdG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN0eWxlczIuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3IgZGVmaW5lIGlubGluZSBzdHlsZXNoZWV0IG92ZXJyaWRlcykgdG8gZW5mb3JjZSB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kIHN0eWxpbmc6XCJ9e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJCYWNrZ3JvdW5kOiBDb29sIG5lYXItYmxhY2sgY2FudmFzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSW5rL1RleHQ6IENsZWFuIG5lYXItd2hpdGUvZ3JleSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBY2NlbnRzOiBTaWduYXR1cmUgZ3JhZGllbnQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZ3JhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG9rZW4sIGUuZy4sIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncmFkLXRleHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJEZXRhaWxzL01ldGFkYXRhOiBVc2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3BhY2UgTW9ub1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgbW9ub3NwYWNlIGZvbnRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkJvcmRlcnM6IEhhaXJsaW5lIHNvbGlkIGxpbmVzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIxcHggc29saWQgdmFyKC0tcGFuZWwpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSG92ZXIgU2hhZG93czogSGFyZC1vZmZzZXQgc29saWQgYmxvY2sgc2hhZG93cyBvbiBjbGlja2FibGUgY2FyZHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQ2FzaW5nOiBTdHJpY3Qgc2VudGVuY2UgY2FzZSBmb3IgaGVhZGxpbmVzLCB3aXRoIGhlYWRpbmdzIHRlcm1pbmF0aW5nIGluIGEgcGVyaW9kIChlLmcuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRlY2ggc3RhY2suXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBFbW9qaTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU3RyaXAgYW55IHByZXNlbnQgb3IgZnV0dXJlIGVtb2ppcyBmcm9tIHRoZSBsYXlvdXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1EWCBSZXVzYWJsZSBDb21wb25lbnQgUmVnaXN0cnk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDcmVhdGUgYSBkaXJlY3RvcnkgZm9yIHJldXNhYmxlIGxheW91dCBlbGVtZW50czogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJJbXBsZW1lbnQgdGhlIGZvbGxvd2luZyBkZWZhdWx0IGNvbXBvbmVudHMgKGZvbGxvd2luZyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFjdCBGYXN0IFJlZnJlc2ggcnVsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAtIG9uZSBkZWZhdWx0LWV4cG9ydGVkIGNvbXBvbmVudCBwZXIgZmlsZSwgbm8gbWl4ZWQgbmFtZWQgZXhwb3J0cyBvZiBkYXRhL2xvZ2ljKTpcIn17XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIkNhbGxvdXQudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogUmVuZGVycyBoaWdoLWNvbnRyYXN0IGluZm8vd2FybmluZyBib3ggd2l0aCBoYWlybGluZSBib3JkZXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIkJ1dHRvbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOiBSZW5kZXJzIGEgY2xpY2thYmxlIGJ1dHRvbiB3aXRoIGJsb2NrIGhvdmVyLXNoYWRvdyBzdHlsaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIk1vcmUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogQSBzaW1wbGUgcGxhY2Vob2xkZXIgY29tcG9uZW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxkaXYgY2xhc3NOYW1lPVxcXCJyZWFkLW1vcmUtbWFya2VyXFxcIiAvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdXNlZCB0byBpZGVudGlmeSBjb250ZW50IGV4Y2VycHQgY3V0b2ZmIHBvaW50cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTURYIFByb3ZpZGVyIFdpcmluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmVmYWN0b3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gc2VydmUgYXMgdGhlIHNpbmdsZSBlbnRyeSBwb2ludC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJJbXBvcnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTURYUHJvdmlkZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChvciBpdHMgc3BlY2lmaWMgcGF0aCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiV3JhcCB0aGUgbWFpbiBhcHBsaWNhdGlvbiBzdHJ1Y3R1cmUgaW5zaWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxNRFhQcm92aWRlciBjb21wb25lbnRzPXt7IENhbGxvdXQsIEJ1dHRvbiwgTW9yZSB9fT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNvbmZpcm0gdGhhdCBzdGFuZGFyZCBNRFggZmlsZXMgY2FuIGV2YWx1YXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxDYWxsb3V0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEJ1dHRvbj5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhZ3Mgd2l0aG91dCBuZWVkaW5nIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyYXRpb24gd2l0aGluIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZXhpdC1jcml0ZXJpYVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZXhpdC1jcml0ZXJpYVwiIC8+e1wiRXhpdCBDcml0ZXJpYVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdWNjZWVkcyB3aXRoIHplcm8gZXJyb3JzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlZpc3VhbCBjaGVjazogTGF5b3V0IGZlYXR1cmVzIGEgY29vbCBuZWFyLWJsYWNrIHRoZW1lIHdpdGggc2VudGVuY2UtY2FzZSBoZWFkbGluZXMgZW5kaW5nIGluIHBlcmlvZHMsIGhhaXJsaW5lIGJvcmRlcnMsIGFuZCB6ZXJvIGVtb2ppcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJWYWxpZGF0aW9uOiBBbiBNRFggZmlsZSBjb250YWluaW5nIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPENhbGxvdXQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbGVtZW50IGNvbXBpbGVzIGFuZCByZW5kZXJzIHdpdGhvdXQgdGhyb3dpbmcgcmVmZXJlbmNlIG9yIGltcG9ydCBlcnJvcnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBoYXNlLTItbWV0YWRhdGEtaGFydmVzdGluZy1zZWFyY2gtc2lkZWJhci1jYXRlZ29yaXphdGlvblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGhhc2UtMi1tZXRhZGF0YS1oYXJ2ZXN0aW5nLXNlYXJjaC1zaWRlYmFyLWNhdGVnb3JpemF0aW9uXCIgLz57XCJQaGFzZSAyOiBNZXRhZGF0YSBIYXJ2ZXN0aW5nLCBTZWFyY2ggJiBTaWRlYmFyIENhdGVnb3JpemF0aW9uXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJnb2FsLTFcIj48SGVhZGluZ0FuY2hvciBpZD1cImdvYWwtMVwiIC8+e1wiR29hbFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSW1wbGVtZW50IGNsaWVudC1zaWRlIGZyb250bWF0dGVyIHBhcnNpbmcgYW5kIGNvbXBpbGF0aW9uIG9mIGFuIGluLW1lbW9yeSBtZXRhZGF0YSBpbmRleCB0byBwb3dlciBsaXN0IHF1ZXJpZXMsIHRhZyBjYXRlZ29yaXphdGlvbiwgYW5kIHJhcGlkIHNlYXJjaCB3aXRob3V0IGFueSBkYXRhYmFzZSBiYWNrZW5kcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic3RlcC1ieS1zdGVwLWluc3RydWN0aW9ucy0xXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdGVwLWJ5LXN0ZXAtaW5zdHJ1Y3Rpb25zLTFcIiAvPntcIlN0ZXAtYnktU3RlcCBJbnN0cnVjdGlvbnNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGcm9udG1hdHRlciBQYXJzZXIgVXRpbGl0eSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9wYXJzZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkltcGxlbWVudCBhIGxpZ2h0d2VpZ2h0IHBhcnNlciB0aGF0IHJlYWRzIHRoZSBmaXJzdCAxMDAwIGNoYXJhY3RlcnMgb2YgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmlsZSB0byBwYXJzZSBZQU1MIGZyb250bWF0dGVyIGJsb2NrIGhlYWRlcnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInRpdGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhZ3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkdGltZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4Y2VycHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2NhbCBNZXRhZGF0YSBJbmRleGVyOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSW50ZWdyYXRlIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvaG9va3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVzaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZU1ldGFkYXRhUXVlcnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VGaWxlTWV0YWRhdGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvIGxvYWQgbWV0YWRhdGEgZm9yIGZpbGVzIGluc2lkZSB0aGUgcmVwb3NpdG9yeSAodW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2FwcC9wYWdlcy9lbnRyaWVzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlNvcnQgcG9zdHMgZHluYW1pY2FsbHkgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG5ld2VzdCBmaXJzdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2lkZWJhciAmIENhdGVnb3J5IFN5c3RlbTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNvbnN0cnVjdCBhIGNhdGVnb3J5IHNpZGViYXIgdGhhdCBleHRyYWN0cyBhIHVuaXF1ZSBzZXQgb2YgYWxsIHRhZ3MgZm91bmQgYWNyb3NzIGFsbCBwb3N0cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTdXBwb3J0IGNsaWNraW5nIGEgdGFnIGNhcmQgdG8gZmlsdGVyIHRoZSBtYWluIGFydGljbGVzIGdyaWQgZHluYW1pY2FsbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW5zdGFudCBDbGllbnQtU2lkZSBTZWFyY2g6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJJbXBsZW1lbnQgYSBzZWFyY2ggdGV4dCBmaWVsZCBpbiB0aGUgbWFpbiB2aWV3LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkZpbHRlciB0aGUgcGFyc2VkIGluLW1lbW9yeSBtZXRhZGF0YSBhcnJheSBpbnN0YW50bHkgYWdhaW5zdCB0aGUgc2VhcmNoIHF1ZXJ5IChtYXRjaGluZyB0aXRsZXMsIHRhZ3MsIGFuZCBleGNlcnB0cykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJleGl0LWNyaXRlcmlhLTFcIj48SGVhZGluZ0FuY2hvciBpZD1cImV4aXQtY3JpdGVyaWEtMVwiIC8+e1wiRXhpdCBDcml0ZXJpYVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgbGFuZGluZyBwYWdlIGNvbXBpbGVzIGFuZCBjb3JyZWN0bHkgZGlzcGxheXMgY2FyZHMgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aXRsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkdGltZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGNlcnB0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBleHRyYWN0ZWQgZnJvbSB0aGUgTURYIGZyb250bWF0dGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNsaWNraW5nIGEgY2F0ZWdvcnkgdGFnIHVwZGF0ZXMgdGhlIGFydGljbGVzIGdyaWQgdG8gc2hvdyBvbmx5IHBvc3RzIG1hdGNoaW5nIHRoYXQgY2F0ZWdvcnkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVHlwaW5nIGludG8gdGhlIHNlYXJjaCBpbnB1dCBmaWx0ZXJzIGxpc3QgaXRlbXMgaW1tZWRpYXRlbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBoYXNlLTMtcGxhdGZvcm0tZWRpdG9yLWludGVncmF0aW9uLWRlZmVuc2l2ZS1wZXJtaXNzaW9ucy1nYXRpbmdcIj48SGVhZGluZ0FuY2hvciBpZD1cInBoYXNlLTMtcGxhdGZvcm0tZWRpdG9yLWludGVncmF0aW9uLWRlZmVuc2l2ZS1wZXJtaXNzaW9ucy1nYXRpbmdcIiAvPntcIlBoYXNlIDM6IFBsYXRmb3JtIEVkaXRvciBJbnRlZ3JhdGlvbiAmIERlZmVuc2l2ZSBQZXJtaXNzaW9ucyAoR2F0aW5nKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZ29hbC0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnb2FsLTJcIiAvPntcIkdvYWxcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIldpcmUgdXAgbmF0aXZlIGltbWVkaWF0ZWx5LnJ1biBlZGl0aW5nIGNhcGFiaWxpdGllcywgY2hlY2tpbmcgZmlsZXN5c3RlbSByZWFkLW9ubHkvcmVhZC13cml0ZSBzdGF0ZXMgZGVmZW5zaXZlbHkgdG8gcmVzcGVjdCB0aGUgWmVyby1DaHJvbWUgUHJpbmNpcGxlIGZvciBwdWJsaWMgcmVhZGVycy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic3RlcC1ieS1zdGVwLWluc3RydWN0aW9ucy0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdGVwLWJ5LXN0ZXAtaW5zdHJ1Y3Rpb25zLTJcIiAvPntcIlN0ZXAtYnktU3RlcCBJbnN0cnVjdGlvbnNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBY3RpdmUgTW9kZSBDaGVjazpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VDb250ZXh0KFRpbmtlcmFibGVDb250ZXh0KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gcmVhZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuYXZpZ2F0aW9uU3RhdGUubW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRGV0ZXJtaW5lIGlmIHRoZSBhcHAgaXMgY3VycmVudGx5IGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIidwcmVzZW50J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW9kZSBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCInZWRpdCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1vZGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVmZW5zaXZlIFBlcm1pc3Npb24gQ2hlY2sgKFplcm8tQ2hyb21lKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlF1ZXJ5IGFjdGl2ZSB3b3Jrc3BhY2UgbW91bnRzIHVzaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZU1vdW50cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBlcXVpdmFsZW50IGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIklmIHRoZSBhY3RpdmUgbW91bnQgaGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGU6IFxcXCJyb1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChvciB1c2VyIGlzIHVuYXV0aGVudGljYXRlZCksIHN0cmlwIGFsbCBlZGl0IGljb25zLCBzYXZlIGJ1dHRvbnMsIGFuZCBjb25maWd1cmF0aW9uIG9wdGlvbnMgZnJvbSB0aGUgRE9NLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlByZXNlbnQtdG8tRWRpdCBUcmFuc2l0aW9uIEJ1dHRvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIklmIHRoZSBhY3RpdmUgbW91bnQgaXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZTogXFxcInJ3XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSB1c2VyIGlzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIidwcmVzZW50J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW9kZSwgc2hvdyBhbiBlbGVnYW50IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIkVkaXQgUGFnZVxcXCIgKOKcjilcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYnV0dG9uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNsaWNraW5nIGl0IGNhbGxzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcXVlc3RFZGl0KHsgcGF0aDogY3VycmVudFBhdGggfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZyb20gdGhlIFNESyB0byB0cmFuc2l0aW9uIHRoZSB3b3JrYmVuY2ggdG8gZWRpdCBtb2RlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNpbmdsZS1maWxlIEVkaXRpbmcgVGFzazpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIklmIHRoZSB1c2VyIGlzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIidlZGl0J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW9kZSwgZGlzcGxheSBhbiBpbmxpbmUgZWRpdCBhZmZvcmRhbmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNsaWNraW5nIGl0IGNhbGxzIHRoZSBob3N0J3MgbmF0aXZlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFzayB1c2luZyB0aGUgU0RLIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2soJ2VkaXQtZmlsZScsIHsgZmlsZTogY2FwRmlsZSguLi4pIH0pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byBvcGVuIHRoZSBmaWxlIGluIHRoZSB3b3Jrc3BhY2UgQ29kZU1pcnJvciBlZGl0b3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJleGl0LWNyaXRlcmlhLTJcIj48SGVhZGluZ0FuY2hvciBpZD1cImV4aXQtY3JpdGVyaWEtMlwiIC8+e1wiRXhpdCBDcml0ZXJpYVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJJbiByZWFkLW9ubHkgbW91bnRzIG9yIGd1ZXN0IHNlc3Npb25zLCB0aGUgbGF5b3V0IGlzIHBlcmZlY3RseSBjbGVhbiB3aXRoIHplcm8gZWRpdCBjaHJvbWUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSW4gcmVhZC13cml0ZSBtb2RlLCBjbGlja2luZyB0aGUgXFxcIkVkaXQgUGFnZVxcXCIgYnV0dG9uIHRyYW5zaXRpb25zIHRoZSB3b3Jrc3BhY2UgaW50byBlZGl0IG1vZGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSW4gZWRpdCBtb2RlLCBjbGlja2luZyB0aGUgZWRpdCBpY29uIHN1Y2Nlc3NmdWxseSBvcGVucyB0aGUgdGFyZ2V0IE1EWCBmaWxlIGluIHRoZSBwbGF0Zm9ybSdzIGVkaXRvci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGhhc2UtNC1jb250ZW50LWV4dGVuc2liaWxpdHktZHluYW1pYy1pbXBvcnRzLWFzc2V0LWxvYWRpbmdcIj48SGVhZGluZ0FuY2hvciBpZD1cInBoYXNlLTQtY29udGVudC1leHRlbnNpYmlsaXR5LWR5bmFtaWMtaW1wb3J0cy1hc3NldC1sb2FkaW5nXCIgLz57XCJQaGFzZSA0OiBDb250ZW50IEV4dGVuc2liaWxpdHksIER5bmFtaWMgSW1wb3J0cyAmIEFzc2V0IExvYWRpbmdcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImdvYWwtM1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ29hbC0zXCIgLz57XCJHb2FsXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFbmFibGUgdGhlIHdpa2kgdG8gbG9hZCBkeW5hbWljYWxseSBmcm9tIGFub3RoZXIgbW91bnRlZCBTcGFjZSwgc3VwcG9ydCBkeW5hbWljIG1vZHVsZSByZXNvbHV0aW9uIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIvbW50L3toYXNofS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGltcG9ydHMpIHdpdGhpbiB0aGUgTURYIHBhZ2VzLCBhbmQgcmVzb2x2ZSBsb2NhbCBhc3NldHMgc3VjaCBhcyBpbWFnZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInN0ZXAtYnktc3RlcC1pbnN0cnVjdGlvbnMtM1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC1ieS1zdGVwLWluc3RydWN0aW9ucy0zXCIgLz57XCJTdGVwLWJ5LVN0ZXAgSW5zdHJ1Y3Rpb25zXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRHluYW1pYyBXb3Jrc3BhY2UgQXV0by1EZXRlY3Rpb246XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJPbiBsYXVuY2gsIGNoZWNrIHRoZSBxdWVyeSBwYXJhbWV0ZXJzIChlLmcuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIj9tb3VudD1zcGFjZTp4eXpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBvciBsb2NhbCBzdG9yYWdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlNjYW4gbW91bnRlZCBmaWxlc3lzdGVtcyBmb3IgYSBzdGFuZGFyZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJibG9nLWNvbmZpZy5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlLiBJZiBwcmVzZW50LCBsb2FkIHBhZ2VzIGZyb20gdGhhdCBtb3VudCByYXRoZXIgdGhhbiB0aGUgZGVmYXVsdCBpbi1yZXBvIHBhdGguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhYmxlIE1vdW50IFBhdGggUmVzb2x1dGlvbiBmb3IgRHluYW1pYyBJbXBvcnRzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiTURYIHBhZ2VzIGluc2lkZSBleHRlcm5hbCBzcGFjZXMgY2FuIGltcG9ydCBSZWFjdCBjb21wb25lbnRzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgR3JhcGggZnJvbSAnLi9jb21wb25lbnRzL0dyYXBoJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBMZXQgdGhlIGltbWVkaWF0ZWx5LnJ1biBydW50aW1lIGNvbXBpbGVyIHJlc29sdmUgdGhlc2UgZHluYW1pY2FsbHkgcmVsYXRpdmUgdG8gdGhlIHN0YWJsZSBtb3VudCBwYXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9tbnQve2hhc2h9L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQmluYXJ5IEltYWdlIEFzc2V0IExvYWRlcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkltcGxlbWVudCBhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8SW1hZ2U+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3cmFwcGVyIGNvbXBvbmVudCBmb3IgbWFya2Rvd24gaW1hZ2VzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIhW2FsdF0oLi9pbWFnZXMvcGhvdG8ucG5nKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifXtcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmVhZCBmaWxlIGJ5dGVzIGZyb20gdGhlIGR5bmFtaWMgcGF0aC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDb252ZXJ0IHRoZSBieXRlIGFycmF5IGludG8gYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJCbG9iXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDYWxsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvIGdldCBhIHNlY3VyZSBsb2NhbCBVUkwuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmV2b2tlIHRoZSBvYmplY3QgVVJMIG9uIHVubW91bnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxFcnJvckJvdW5kYXJ5PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmFsbGJhY2tzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiV3JhcCBNRFggcGFnZSByZW5kZXJzIGFuZCBkeW5hbWljYWxseSBpbXBvcnRlZCBjb21wb25lbnRzIGluIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxFcnJvckJvdW5kYXJ5PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmxvY2suIElmIGEgZHluYW1pYyBjb21wb25lbnQgZmFpbHMgdG8gbG9hZCBvciByZXNvbHZlcyB0byBhIG1pc3NpbmcgcGF0aCwgcmVuZGVyIGEgY2xlYW4gZmFsbGJhY2sgY2FyZCBpbnN0ZWFkIG9mIGNyYXNoaW5nIHRoZSBhcHAuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJleGl0LWNyaXRlcmlhLTNcIj48SGVhZGluZ0FuY2hvciBpZD1cImV4aXQtY3JpdGVyaWEtM1wiIC8+e1wiRXhpdCBDcml0ZXJpYVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgYmxvZyBzdWNjZXNzZnVsbHkgbG9hZHMsIGluZGV4ZXMsIGFuZCByZW5kZXJzIE1EWCBmaWxlcyBsb2NhdGVkIG9uIGFuIGV4dGVybmFsIFNwYWNlIG1vdW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlJlbGF0aXZlIGltcG9ydHMgaW5zaWRlIHRoZSBleHRlcm5hbCBNRFggcGFnZXMgcmVzb2x2ZSBhbmQgcmVuZGVyIHN1Y2Nlc3NmdWxseS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJSZWxhdGl2ZSBpbWFnZSB0YWdzIGluc2lkZSB0aGUgZXh0ZXJuYWwgTURYIGZpbGVzIHN1Y2Nlc3NmdWxseSBkaXNwbGF5IHRoZWlyIGdyYXBoaWMgYXNzZXRzIHVzaW5nIHRoZSBCbG9iIFVSTCBsb2FkZXIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRGVsZXRpbmcgYW4gaW1wb3J0ZWQgY29tcG9uZW50IGRpc3BsYXlzIGEgY2xlYW4gZXJyb3IgYmFubmVyIG9uIHRoYXQgc3BlY2lmaWMgcGFnZSBpbnN0ZWFkIG9mIHRocm93aW5nIGEgYmxhbmsgc2NyZWVuIGNyYXNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJwaGFzZS01LWJ1aWxkLWxpbnRpbmctc2VsZi12ZXJpZmljYXRpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInBoYXNlLTUtYnVpbGQtbGludGluZy1zZWxmLXZlcmlmaWNhdGlvblwiIC8+e1wiUGhhc2UgNTogQnVpbGQsIExpbnRpbmcgJiBTZWxmLVZlcmlmaWNhdGlvblwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZ29hbC00XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnb2FsLTRcIiAvPntcIkdvYWxcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkd1YXJhbnRlZSBjb21wbGV0ZSBjb2RlIGh5Z2llbmUsIEZhc3QgUmVmcmVzaCBjb21wbGlhbmNlLCBlcnJvci1mcmVlIHByb2R1Y3Rpb24gY29tcGlsYXRpb24sIGFuZCBzZWFtbGVzcyBob3QgcmVsb2FkaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzdGVwLWJ5LXN0ZXAtaW5zdHJ1Y3Rpb25zLTRcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtYnktc3RlcC1pbnN0cnVjdGlvbnMtNFwiIC8+e1wiU3RlcC1ieS1TdGVwIEluc3RydWN0aW9uc1wifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxpbnQgQ2hlY2s6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJSdW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gRml4IGFueSBlcnJvcnMsIGZvY3VzaW5nIGhlYXZpbHkgb24gRmFzdCBSZWZyZXNoIHZpb2xhdGlvbnMgKGUuZy4gbm8gbWl4ZWQgY29tcG9uZW50IGFuZCBoZWxwZXIgbmFtZWQgZXhwb3J0cykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnVpbGQgVmVyaWZpY2F0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUnVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVzaW5nIHRoZSBwcm9qZWN0J3Mgcm9sbHVwIGNvbmZpZ3VyYXRpb24uIEZpeCBhbnkgdHlwZXNjcmlwdCBvciBidW5kbGUgY29tcGlsYXRpb24gZXJyb3JzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkludGVyYWN0aXZlIE1hbnVhbCBUZXN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUnVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byBib290IGxvY2FsbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiTmF2aWdhdGUgcGFnZXMsIHRyaWdnZXIgc2VhcmNoLCBjbGljayB0YWdzLCBhbmQgY2hlY2sgbGF5b3V0IHRyYW5zaXRpb25zIHRvIGVuc3VyZSBmbGF3bGVzcyBvcGVyYXRpb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJleGl0LWNyaXRlcmlhLTRcIj48SGVhZGluZ0FuY2hvciBpZD1cImV4aXQtY3JpdGVyaWEtNFwiIC8+e1wiRXhpdCBDcml0ZXJpYVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHlpZWxkcyB6ZXJvIHdhcm5pbmdzIGFuZCB6ZXJvIGVycm9ycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdWNjZXNzZnVsbHkgY29tcGlsZXMgYW5kIG91dHB1dHMgYnVuZGxlIGZpbGVzIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1aWxkL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBubyB0eXBlc2NyaXB0IG9yIGNvbXBpbGF0aW9uIGVycm9ycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL3BsYW5zL0JMT0dfV0lLSV9QTEFOLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1osS0FBSyxDQUFDYTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2IsV0FBVztFQUNoQyxJQUFJLENBQUNhLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBakIsV0FBQSxDQUFBa0IsSUFBQSxFQUFBbEIsV0FBQSxDQUFBbUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLHNEQUFzRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXNELENBQUUsQ0FBQyxFQUFDLDJEQUEyRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSw2R0FBNkcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsd0NBQXdDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUFnTyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFSLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyxvRUFBb0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvRSxDQUFFLENBQUMsRUFBQyx5RUFBeUU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsTUFBTTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU0sQ0FBRSxDQUFDLEVBQUMsTUFBTTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBd00sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDJCQUEyQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO1VBQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLHdGQUF3RixFQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7Y0FBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsR0FBRSxtQ0FBbUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsR0FBRSwrQkFBK0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFRLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFZLENBQW1CLENBQUMsRUFBQyxzQkFBc0I7Y0FBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtnQkFBQVcsUUFBQSxHQUFFLGlDQUFpQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7a0JBQUFnQixRQUFBLEVBQUU7Z0JBQXdCLENBQW1CLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO2dCQUFBVyxRQUFBLEVBQUU7Y0FBb0UsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsR0FBRSwwRkFBMEYsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtrQkFBQVEsUUFBQSxFQUFFO2dCQUFXLENBQXFCLENBQUMsRUFBQyxzREFBc0Q7Y0FBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtZQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG1EQUFtRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUF5QixDQUFxQixDQUFDLEVBQUMsb0ZBQW9GLEVBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtjQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtnQkFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFhLENBQW1CLENBQUMsRUFBQyxpRUFBaUU7Y0FBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtnQkFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFZLENBQW1CLENBQUMsRUFBQywrREFBK0Q7Y0FBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtnQkFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUFVLENBQW1CLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2tCQUFBZ0IsUUFBQSxFQUFFO2dCQUF3QyxDQUFtQixDQUFDLEVBQUMsa0RBQWtEO2NBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7WUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUsV0FBVyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQywwQkFBMEI7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUsNkNBQTZDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQXNELENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLCtDQUErQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsUUFBUTtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUEwSSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEdBQUUsdUNBQXVDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDRFQUE0RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDSyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBUixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csRUFBRTtNQUFDZSxFQUFFLEVBQUMsMkRBQTJEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMkQsQ0FBRSxDQUFDLEVBQUMsK0RBQStEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFFBQVE7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLE1BQU07SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQXFMLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQW1CLENBQW1CLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDRFQUE0RSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGlCQUFpQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUE0QixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDRCQUE0QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZGLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkUsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFpRCxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNILENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyxpQkFBaUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQixDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxHQUFFLDhEQUE4RCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxFQUFFO01BQThGLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEVBQUU7TUFBOEQsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFSLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyxrRUFBa0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRSxDQUFFLENBQUMsRUFBQyx1RUFBdUU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsUUFBUTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsTUFBTTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBMkssQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDZCQUE2QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUNBQXVDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsUUFBUTtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJDLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO1VBQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFvQyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFtQixDQUFxQixDQUFDLEVBQUMsVUFBVTtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQkFBb0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO1VBQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQkFBb0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHNDQUFzQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBaUQsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyxpQkFBaUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQixDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUE2RixDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxFQUFFO01BQWlHLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEVBQUU7TUFBdUcsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFSLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyw2REFBNkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2RCxDQUFFLENBQUMsRUFBQyxpRUFBaUU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsUUFBUTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsTUFBTTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSxxR0FBcUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsMEVBQTBFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDZCQUE2QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhDQUE4QyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMscUJBQXFCO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMscUZBQXFGO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGdFQUFnRSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUF3QyxDQUFtQixDQUFDLEVBQUMsMEdBQTBHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksRUFBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO2NBQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sRUFBRTtnQkFBQVcsUUFBQSxFQUFFO2NBQXdDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO2dCQUFBVyxRQUFBLEdBQUUsZ0NBQWdDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtrQkFBQWdCLFFBQUEsRUFBRTtnQkFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRztjQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO2dCQUFBVyxRQUFBLEdBQUUsT0FBTyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7a0JBQUFnQixRQUFBLEVBQUU7Z0JBQTJCLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7Y0FBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7Z0JBQUFXLFFBQUEsRUFBRTtjQUFtQyxDQUFpQixDQUFDLEVBQUMsSUFBSTtZQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWlCLENBQW1CLENBQUMsRUFBQyxhQUFhO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGtFQUFrRSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsdUlBQXVJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxFQUFFO01BQWlHLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEVBQUU7TUFBaUYsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUF3SCxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxFQUFFO01BQThILENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDSyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBUixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csRUFBRTtNQUFDZSxFQUFFLEVBQUMseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUMsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFFBQVE7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLE1BQU07SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTBILENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsbUhBQW1IO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsNkZBQTZGO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3RyxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYyxFQUFFLEVBQUMsaUJBQWlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUIsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDN21uQjtBQUNlLFNBQVNHLFVBQVVBLENBQUNyQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDc0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1osS0FBSyxDQUFDYTtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUF6QixXQUFBLENBQUFzQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLdkIsS0FBSztJQUFBa0IsUUFBQSxlQUFFLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNyQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDd0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}