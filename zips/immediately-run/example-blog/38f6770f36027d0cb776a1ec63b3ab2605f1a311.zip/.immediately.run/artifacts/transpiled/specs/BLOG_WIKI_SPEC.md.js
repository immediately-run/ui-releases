var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-blog-wiki-customizable-extensible-themeable-mdx-based-knowledge-sharing",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-blog-wiki-customizable-extensible-themeable-mdx-based-knowledge-sharing"
      }), "immediately.run Blog & Wiki — Customizable, extensible themeable MDX-based knowledge sharing"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal — initial draft for review · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-06-23"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "specs/status/BLOG_WIKI_STATUS.md"
          })]
        }), " — where this document and that one disagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "core_concepts.md"
        }), " §1 (App), §2 (Host), §4 (Principal), §7 (Resource), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), " §1 (Principle), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " (Design system & Editing)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-vision-core-philosophy-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Vision & Core Philosophy ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The Blog/Wiki is a high-fidelity, highly customizable, and themeable content platform designed to run natively as an immediately.run sandboxed app. It serves two primary audiences:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Unauthenticated Public Readers:"
        }), " Visitors who consume content in a clean, high-performance, distraction-free interface with absolutely zero editing chrome, zero credential popups, and instant search."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Collaborative Team Contributors:"
        }), " Small teams who share a workspace (such as a local directory or a platform-hosted collaborative Space) where every reader can become a writer at the click of an edit affordance."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Consistent with immediately.run's core product values, the app enforces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "run-mode first"
      }), " (visual styling, speed, and mobile responsiveness are never compromised for authoring features), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "leveraging platform tools"
      }), " (saving, versioning, conflict resolution, and text editing are delegated to the platform editor), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "first-class agent collaboration"
      }), " (both content files and index structures are programmatically legible)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-content-storage-workspace-options-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. Content Storage & Workspace Options ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "To enable both stand-alone self-contained blogs and shared multi-tenant knowledge bases, the app resolves content from two distinct topologies:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "21-in-repo-content-topology",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "21-in-repo-content-topology"
      }), "§2.1 In-Repo Content Topology"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Location:"
        }), " Inside the app's own git repository under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/app/pages/entries/**/*.mdx"
        }), " (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "example-blog"
        }), "'s default entries)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Resolution:"
        }), " Loaded via the immediately.run standard package resolution or dynamic imports."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Use Case:"
        }), " Personal portfolios, technical documentation tied directly to code releases, static-first blogs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "22-external-mount-content-topology",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "22-external-mount-content-topology"
      }), "§2.2 External Mount Content Topology"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Location:"
        }), " Inside an external workspace mounted by the host filesystem, such as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "local directory"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "local:..."
        }), ") or a collaborative team ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Space"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "space:..."
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Resolution:"
        }), " Path references resolve to secure absolute paths, e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/mnt/{hash}/"
        }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/mnt/space:{space_id}/"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Use Case:"
        }), " High-churn team wikis, meeting notes, project trackers, shared brainstorming vaults."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Auto-Discovery:"
        }), " On boot, the blog scans available mounts via the SDK for a conventional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "blog-config.json"
        }), " file at the root. If found, it automatically switches from in-repo mode to the external workspace."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-extensible-mdx-dynamic-module-imports-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Extensible MDX & Dynamic Module Imports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "To deliver on the promise of infinite customizability and extensibility, MDX files within the blog/wiki are treated as first-class executable React components. They must be able to freely import styling, helper scripts, and other third-party JSX components from within the same workspace or space."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: " ┌─────────────────────────────────────────────────────────────┐\n │                      Mounted Workspace                      │\n │                     (/mnt/space:team-xyz/)                  │\n │                                                             │\n │  ┌──────────────────────────┐    ┌───────────────────────┐  │\n │  │        index.mdx         │    │  CustomCalculator.tsx │  │\n │  │                          │    │                       │  │\n │  │ import Calc from         ├─►──┤ export default const  │  │\n │  │   \"./CustomCalculator\";  │    │   Calc = () => ...    │  │\n │  └──────────────────────────┘    └───────────────────────┘  │\n └─────────────────────────────────────────────────────────────┘\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "31-native-resolution-of-stable-paths",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "31-native-resolution-of-stable-paths"
      }), "§3.1 Native Resolution of Stable Paths"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run maps mounted filesystems to stable absolute paths in the sandboxed iframe's runtime environment (e.g., ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/mnt/{hash}/"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Relative Imports:"
        }), " Standard ES relative imports within an MDX file (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import InteractiveMap from './components/InteractiveMap.tsx'"
        }), ") are resolved relative to the file's absolute path inside the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/mnt/{hash}/"
        }), " boundary."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Absolute Imports:"
        }), " If an MDX page needs to import global shared modules (e.g. a centralized theme helper or design system bundle), it can import directly using absolute paths: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import { Button } from \"/mnt/{hash}/lib/ui.tsx\""
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Persistence Across Sessions:"
        }), " Because filesystem hashes and Space IDs are stable, these absolute and relative imports resolve reliably across browser sessions, reboots, and hot reloads, provided the target filesystem is mounted with appropriate capabilities."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "32-dynamic-third-party-jsx-compilation",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "32-dynamic-third-party-jsx-compilation"
      }), "§3.2 Dynamic Third-Party JSX Compilation"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "MDX content containing third-party JSX components is evaluated dynamically by the blog engine inside the iframe sandbox:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "When a reader navigates to an MDX page, the blog engine requests the file's raw content."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "The code is compiled by the browser-side compiler provided by immediately.run, preserving the import declarations."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The platform's dynamic bundler maps the resolved import paths (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/mnt/{hash}/..."
        }), ") to the live, sandboxed filesystem."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["If an import fails (e.g. a component file was deleted or the mount is missing), the blog wraps the page in a React ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<ErrorBoundary>"
        }), " container, rendering an elegant placeholder block while preserving the rest of the page layout."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-gated-editing-experience-editor-integration-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. The Gated Editing Experience & Editor Integration ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["In strict compliance with ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " §11"]
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC"
        })
      }), ", the blog does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " include a built-in text-input or markdown editor. Instead, it relies on deep integration with immediately.run's native workbench editor:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "┌────────────────────────────────────────────────────────────────┐\n│  Blog / Wiki UI                                                │\n│                                                                │\n│  [ Title of Page ]                                             │\n│  Written on June 23, 2026 • By Contributor [Edit Page ✎] ──────┼───┐\n│                                                                │   │\n│  This is MDX content being read inside the sandboxed iframe.   │   │\n└────────────────────────────────────────────────────────────────┘   │\n                                                                     │ (SDK Invoke)\n┌────────────────────────────────────────────────────────────────┐   ▼\n│  immediately.run Host Workbench (Active Overlay)              │   │\n│                                                                │   │\n│  ┌─ File: /mnt/space-xyz/entries/future-of-ai.mdx ──────────┐  │   │\n│  │ ---                                                      │  │◄──┘\n│  │ title: The Future of Artificial Intelligence             │  │\n│  │ ---                                                      │  │\n│  │ Exploring how AI is transforming creative workflows...   │  │\n│  └──────────────────────────────────────────────────────────┘  │\n└────────────────────────────────────────────────────────────────┘\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "41-read-only-experience-zero-chrome-principle",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "41-read-only-experience-zero-chrome-principle"
      }), "§4.1 Read-Only Experience (Zero-Chrome Principle)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["When the active workspace mount has read-only permissions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode: \"ro\""
        }), "), or when the user is unauthenticated, all edit affordances, buttons, and settings are stripped from the DOM."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The user is presented with a pristine, uncluttered content view. Under no circumstances will a read-only reader be exposed to interactive controls that yield ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " (Read-only file system) errors."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "42-actionable-editing-affordances",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "42-actionable-editing-affordances"
      }), "§4.2 Actionable Editing Affordances"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["When the workspace mount has write permissions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode: \"rw\""
        }), "), the app exposes a subtle ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Edit Entry\" (✎)"
        }), " button next to the title or section headers."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Clicking the button requests single-file write delegation via the SDK and triggers the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " host task:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-ts",
            children: "import { invokeTask, capFile } from '@immediately-run/sdk';\n\nawait invokeTask('edit-file', {\n  file: capFile({ mountId: 'space:team-wiki', relPath: 'entries/future-of-ai.mdx' }, { mode: 'rw' }),\n});\n"
          })
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Any edits made in the platform editor trigger the browser's hot module reloading (HMR) flow, instantly updating the blog/wiki page view behind the editor overlay."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "43-structured-content-scaffolding",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "43-structured-content-scaffolding"
      }), "§4.3 Structured Content Scaffolding"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["To write a new post, authorized contributors click a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"New Entry\""
        }), " button."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The app requests title input, validates that the title does not collide with existing entries, and writes a skeleton template containing default frontmatter:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-markdown",
            children: "---\ntitle: \"A New Journey\"\ndate: June 23, 2026\ntags: []\n---\nType your contents here...\n"
          })
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The app immediately triggers the platform's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " task on the newly created file path."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-frontmatter-harvesting-full-text-search-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Frontmatter Harvesting & Full-Text Search ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "To enable navigation, categorizations, and searching without a static backend, the Blog/Wiki app runs an active client-side metadata indexer:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "51-frontmatter-spec",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "51-frontmatter-spec"
      }), "§5.1 Frontmatter Spec"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Every blog post / wiki page is expected to begin with a standard frontmatter block:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-yaml",
        children: "---\ntitle: \"Digital Wellness: Finding Balance in a Connected World\"\ndate: \"January 10, 2024\"\nreadtime: \"6 min read\"\ntags: [Lifestyle, Wellness]\nexcerpt: \"Practical strategies for maintaining mental health and productivity while navigating our increasingly digital lives.\"\n---\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "52-client-side-harvesting-engine",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "52-client-side-harvesting-engine"
      }), "§5.2 Client-Side Harvesting Engine"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Local Indexer:"
        }), " The engine queries files matching ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/entries/**/*.mdx"
        }), " (or custom paths specified in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "blog-config.json"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lazy Metadata Scrape:"
        }), " Instead of reading full files, the app reads only the first 500 bytes of each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), " file to parse the frontmatter metadata block."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "SDK Query Hook Integration:"
        }), " For in-repo files, the app integrates with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " metadata queries:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-ts",
            children: "import { useMetadataQuery, useFileMetadata } from \"@immediately-run/sdk/hooks\";\n"
          })
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "In-Memory Search Index:"
        }), " The parsed titles, tags, and excerpts are compiled into a lightweight client-side index. Full-text search filters this index instantly on the client, avoiding any remote API rounds."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-layouts-design-tokens-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Layouts & Design Tokens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The Blog/Wiki is built to follow the immediately.run project-specific brand design language specified in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        })
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "61-aesthetics-ui",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "61-aesthetics-ui"
      }), "§6.1 Aesthetics & UI"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Canvas:"
        }), " Cool near-black backdrop (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), " token) as default with near-white ink (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Accents:"
        }), " Neon magenta-to-violet gradient (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), " token) for interactive links, category pills, and header details."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Typography:"
        }), " Gabarito display family for headlines; Space Mono details for metadata, tags, and timestamps."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Borders:"
        }), " Thin, elegant hairline borders (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--hairline"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "1px solid var(--panel)"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Shadows:"
        }), " Hard-offset solid block shadows on card hovers."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Copy:"
        }), " Clean, modern sentence case. Headings terminate with a period (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Future of AI."
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Icons:"
        }), " Lucide icons sized to 16px–24px, using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Emojis:"
        }), " The brand strictly forbids emojis in any layout files, page indexes, or templates."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "decisions-rejected-alternatives"
      }), "Decisions & Rejected Alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Chose dynamic ES runtime imports over static build pre-rendering:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rationale:"
        }), " Static site generation is impossible for arbitrary external workspace mounts loaded dynamically at runtime. Compiling and bundling MDX directly in the sandbox browser environment aligns with immediately.run's no-build runtime model, ensuring complete flexibility for forked themes and customized code blocks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Chose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit-file"
          }), " task delegation over inline editor:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rationale:"
        }), " Reinforces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Product Value 7"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "CLAUDE.md §11"
        }), ". Minimizes bundle size, maximizes mobile editing responsiveness (handling soft keyboard viewport resizing), and gives users who fork their platform editor custom keybindings, tabs, and diagnostic panels across every blog they edit."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Chose stable path ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/mnt/{hash}"
          }), " resolution for imports:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rationale:"
        }), " Storing modules in external collaborative spaces requires a stable import path. Because immediately.run guarantees stable virtual paths for mounts across session reboots, we can directly utilize ES imports inside MDX files without needing complex dynamic import proxies or virtual path mapping layers."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-questions"
      }), "Open Questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "How should we handle unauthenticated asset fetching from protected Spaces?"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "Proposed Solution:"
            }), " If a Space is private, unauthenticated readers cannot access it. Public blogs must reside either in public git repositories (In-Repo model) or inside public Spaces where read-access is explicitly open to public origins."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "What happens if a third-party JSX component imported inside the MDX requests a capability the parent blog app does not hold?"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "Proposed Solution:"
            }), " Due to sandboxing, any imported JSX component runs strictly inside the Blog/Wiki app's sandbox. It can never exceed the capabilities granted to the Blog/Wiki app itself. If an imported component tries to invoke an unauthorized SDK task, it will safely reject with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", protecting the user's host origin."]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/specs/BLOG_WIKI_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJMT0dfV0lLSV9TUEVDLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGJsb2NrcXVvdGU6IFwiYmxvY2txdW90ZVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGgzOiBcImgzXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJpbW1lZGlhdGVseXJ1bi1ibG9nLXdpa2ktY3VzdG9taXphYmxlLWV4dGVuc2libGUtdGhlbWVhYmxlLW1keC1iYXNlZC1rbm93bGVkZ2Utc2hhcmluZ1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaW1tZWRpYXRlbHlydW4tYmxvZy13aWtpLWN1c3RvbWl6YWJsZS1leHRlbnNpYmxlLXRoZW1lYWJsZS1tZHgtYmFzZWQta25vd2xlZGdlLXNoYXJpbmdcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBCbG9nICYgV2lraSDigJQgQ3VzdG9taXphYmxlLCBleHRlbnNpYmxlIHRoZW1lYWJsZSBNRFgtYmFzZWQga25vd2xlZGdlIHNoYXJpbmdcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwcm9wb3NhbCDigJQgaW5pdGlhbCBkcmFmdCBmb3IgcmV2aWV3IMK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wNi0yM1wifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZSBmb3IgdGhpcyBzcGVjIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwZWNzL3N0YXR1cy9CTE9HX1dJS0lfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmUgZGlzYWdyZWUsIHRoZSBzdGF0dXMgZG9jIGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRzIGZpcnN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb3JlX2NvbmNlcHRzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzEgKEFwcCksIMKnMiAoSG9zdCksIMKnNCAoUHJpbmNpcGFsKSwgwqc3IChSZXNvdXJjZSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9GSVJTVF9FRElUSU5HX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMSAoUHJpbmNpcGxlKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoRGVzaWduIHN5c3RlbSAmIEVkaXRpbmcpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLXZpc2lvbi1jb3JlLXBoaWxvc29waHktbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMS4gVmlzaW9uICYgQ29yZSBQaGlsb3NvcGh5IFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgQmxvZy9XaWtpIGlzIGEgaGlnaC1maWRlbGl0eSwgaGlnaGx5IGN1c3RvbWl6YWJsZSwgYW5kIHRoZW1lYWJsZSBjb250ZW50IHBsYXRmb3JtIGRlc2lnbmVkIHRvIHJ1biBuYXRpdmVseSBhcyBhbiBpbW1lZGlhdGVseS5ydW4gc2FuZGJveGVkIGFwcC4gSXQgc2VydmVzIHR3byBwcmltYXJ5IGF1ZGllbmNlczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlVuYXV0aGVudGljYXRlZCBQdWJsaWMgUmVhZGVyczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVmlzaXRvcnMgd2hvIGNvbnN1bWUgY29udGVudCBpbiBhIGNsZWFuLCBoaWdoLXBlcmZvcm1hbmNlLCBkaXN0cmFjdGlvbi1mcmVlIGludGVyZmFjZSB3aXRoIGFic29sdXRlbHkgemVybyBlZGl0aW5nIGNocm9tZSwgemVybyBjcmVkZW50aWFsIHBvcHVwcywgYW5kIGluc3RhbnQgc2VhcmNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29sbGFib3JhdGl2ZSBUZWFtIENvbnRyaWJ1dG9yczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU21hbGwgdGVhbXMgd2hvIHNoYXJlIGEgd29ya3NwYWNlIChzdWNoIGFzIGEgbG9jYWwgZGlyZWN0b3J5IG9yIGEgcGxhdGZvcm0taG9zdGVkIGNvbGxhYm9yYXRpdmUgU3BhY2UpIHdoZXJlIGV2ZXJ5IHJlYWRlciBjYW4gYmVjb21lIGEgd3JpdGVyIGF0IHRoZSBjbGljayBvZiBhbiBlZGl0IGFmZm9yZGFuY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNvbnNpc3RlbnQgd2l0aCBpbW1lZGlhdGVseS5ydW4ncyBjb3JlIHByb2R1Y3QgdmFsdWVzLCB0aGUgYXBwIGVuZm9yY2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicnVuLW1vZGUgZmlyc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHZpc3VhbCBzdHlsaW5nLCBzcGVlZCwgYW5kIG1vYmlsZSByZXNwb25zaXZlbmVzcyBhcmUgbmV2ZXIgY29tcHJvbWlzZWQgZm9yIGF1dGhvcmluZyBmZWF0dXJlcyksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGV2ZXJhZ2luZyBwbGF0Zm9ybSB0b29sc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc2F2aW5nLCB2ZXJzaW9uaW5nLCBjb25mbGljdCByZXNvbHV0aW9uLCBhbmQgdGV4dCBlZGl0aW5nIGFyZSBkZWxlZ2F0ZWQgdG8gdGhlIHBsYXRmb3JtIGVkaXRvciksIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpcnN0LWNsYXNzIGFnZW50IGNvbGxhYm9yYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGJvdGggY29udGVudCBmaWxlcyBhbmQgaW5kZXggc3RydWN0dXJlcyBhcmUgcHJvZ3JhbW1hdGljYWxseSBsZWdpYmxlKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTJcIiBkYXRhLXNsdWc9XCIyLWNvbnRlbnQtc3RvcmFnZS13b3Jrc3BhY2Utb3B0aW9ucy1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBDb250ZW50IFN0b3JhZ2UgJiBXb3Jrc3BhY2UgT3B0aW9ucyBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVG8gZW5hYmxlIGJvdGggc3RhbmQtYWxvbmUgc2VsZi1jb250YWluZWQgYmxvZ3MgYW5kIHNoYXJlZCBtdWx0aS10ZW5hbnQga25vd2xlZGdlIGJhc2VzLCB0aGUgYXBwIHJlc29sdmVzIGNvbnRlbnQgZnJvbSB0d28gZGlzdGluY3QgdG9wb2xvZ2llczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiMjEtaW4tcmVwby1jb250ZW50LXRvcG9sb2d5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCIyMS1pbi1yZXBvLWNvbnRlbnQtdG9wb2xvZ3lcIiAvPntcIsKnMi4xIEluLVJlcG8gQ29udGVudCBUb3BvbG9neVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxvY2F0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJbnNpZGUgdGhlIGFwcCdzIG93biBnaXQgcmVwb3NpdG9yeSB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvYXBwL3BhZ2VzL2VudHJpZXMvKiovKi5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChlLmcuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4YW1wbGUtYmxvZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBkZWZhdWx0IGVudHJpZXMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVzb2x1dGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTG9hZGVkIHZpYSB0aGUgaW1tZWRpYXRlbHkucnVuIHN0YW5kYXJkIHBhY2thZ2UgcmVzb2x1dGlvbiBvciBkeW5hbWljIGltcG9ydHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJVc2UgQ2FzZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUGVyc29uYWwgcG9ydGZvbGlvcywgdGVjaG5pY2FsIGRvY3VtZW50YXRpb24gdGllZCBkaXJlY3RseSB0byBjb2RlIHJlbGVhc2VzLCBzdGF0aWMtZmlyc3QgYmxvZ3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjIyLWV4dGVybmFsLW1vdW50LWNvbnRlbnQtdG9wb2xvZ3lcIj48SGVhZGluZ0FuY2hvciBpZD1cIjIyLWV4dGVybmFsLW1vdW50LWNvbnRlbnQtdG9wb2xvZ3lcIiAvPntcIsKnMi4yIEV4dGVybmFsIE1vdW50IENvbnRlbnQgVG9wb2xvZ3lcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2NhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSW5zaWRlIGFuIGV4dGVybmFsIHdvcmtzcGFjZSBtb3VudGVkIGJ5IHRoZSBob3N0IGZpbGVzeXN0ZW0sIHN1Y2ggYXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxvY2FsIGRpcmVjdG9yeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWw6Li4uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb3IgYSBjb2xsYWJvcmF0aXZlIHRlYW0gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTcGFjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BhY2U6Li4uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXNvbHV0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQYXRoIHJlZmVyZW5jZXMgcmVzb2x2ZSB0byBzZWN1cmUgYWJzb2x1dGUgcGF0aHMsIGUuZy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL21udC97aGFzaH0vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvbW50L3NwYWNlOntzcGFjZV9pZH0vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlVzZSBDYXNlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBIaWdoLWNodXJuIHRlYW0gd2lraXMsIG1lZXRpbmcgbm90ZXMsIHByb2plY3QgdHJhY2tlcnMsIHNoYXJlZCBicmFpbnN0b3JtaW5nIHZhdWx0cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkF1dG8tRGlzY292ZXJ5OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBPbiBib290LCB0aGUgYmxvZyBzY2FucyBhdmFpbGFibGUgbW91bnRzIHZpYSB0aGUgU0RLIGZvciBhIGNvbnZlbnRpb25hbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJibG9nLWNvbmZpZy5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlIGF0IHRoZSByb290LiBJZiBmb3VuZCwgaXQgYXV0b21hdGljYWxseSBzd2l0Y2hlcyBmcm9tIGluLXJlcG8gbW9kZSB0byB0aGUgZXh0ZXJuYWwgd29ya3NwYWNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtZXh0ZW5zaWJsZS1tZHgtZHluYW1pYy1tb2R1bGUtaW1wb3J0cy1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBFeHRlbnNpYmxlIE1EWCAmIER5bmFtaWMgTW9kdWxlIEltcG9ydHMgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRvIGRlbGl2ZXIgb24gdGhlIHByb21pc2Ugb2YgaW5maW5pdGUgY3VzdG9taXphYmlsaXR5IGFuZCBleHRlbnNpYmlsaXR5LCBNRFggZmlsZXMgd2l0aGluIHRoZSBibG9nL3dpa2kgYXJlIHRyZWF0ZWQgYXMgZmlyc3QtY2xhc3MgZXhlY3V0YWJsZSBSZWFjdCBjb21wb25lbnRzLiBUaGV5IG11c3QgYmUgYWJsZSB0byBmcmVlbHkgaW1wb3J0IHN0eWxpbmcsIGhlbHBlciBzY3JpcHRzLCBhbmQgb3RoZXIgdGhpcmQtcGFydHkgSlNYIGNvbXBvbmVudHMgZnJvbSB3aXRoaW4gdGhlIHNhbWUgd29ya3NwYWNlIG9yIHNwYWNlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlPntcIiDilIzilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJBcXG4g4pSCICAgICAgICAgICAgICAgICAgICAgIE1vdW50ZWQgV29ya3NwYWNlICAgICAgICAgICAgICAgICAgICAgIOKUglxcbiDilIIgICAgICAgICAgICAgICAgICAgICAoL21udC9zcGFjZTp0ZWFtLXh5ei8pICAgICAgICAgICAgICAgICAg4pSCXFxuIOKUgiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilIJcXG4g4pSCICDilIzilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJAgICAg4pSM4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSQICDilIJcXG4g4pSCICDilIIgICAgICAgIGluZGV4Lm1keCAgICAgICAgIOKUgiAgICDilIIgIEN1c3RvbUNhbGN1bGF0b3IudHN4IOKUgiAg4pSCXFxuIOKUgiAg4pSCICAgICAgICAgICAgICAgICAgICAgICAgICDilIIgICAg4pSCICAgICAgICAgICAgICAgICAgICAgICDilIIgIOKUglxcbiDilIIgIOKUgiBpbXBvcnQgQ2FsYyBmcm9tICAgICAgICAg4pSc4pSA4pa64pSA4pSA4pSkIGV4cG9ydCBkZWZhdWx0IGNvbnN0ICDilIIgIOKUglxcbiDilIIgIOKUgiAgIFxcXCIuL0N1c3RvbUNhbGN1bGF0b3JcXFwiOyAg4pSCICAgIOKUgiAgIENhbGMgPSAoKSA9PiAuLi4gICAg4pSCICDilIJcXG4g4pSCICDilJTilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJggICAg4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYICDilIJcXG4g4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjMxLW5hdGl2ZS1yZXNvbHV0aW9uLW9mLXN0YWJsZS1wYXRoc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiMzEtbmF0aXZlLXJlc29sdXRpb24tb2Ytc3RhYmxlLXBhdGhzXCIgLz57XCLCpzMuMSBOYXRpdmUgUmVzb2x1dGlvbiBvZiBTdGFibGUgUGF0aHNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcImltbWVkaWF0ZWx5LnJ1biBtYXBzIG1vdW50ZWQgZmlsZXN5c3RlbXMgdG8gc3RhYmxlIGFic29sdXRlIHBhdGhzIGluIHRoZSBzYW5kYm94ZWQgaWZyYW1lJ3MgcnVudGltZSBlbnZpcm9ubWVudCAoZS5nLiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL21udC97aGFzaH0vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWxhdGl2ZSBJbXBvcnRzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBTdGFuZGFyZCBFUyByZWxhdGl2ZSBpbXBvcnRzIHdpdGhpbiBhbiBNRFggZmlsZSAoZS5nLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgSW50ZXJhY3RpdmVNYXAgZnJvbSAnLi9jb21wb25lbnRzL0ludGVyYWN0aXZlTWFwLnRzeCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhcmUgcmVzb2x2ZWQgcmVsYXRpdmUgdG8gdGhlIGZpbGUncyBhYnNvbHV0ZSBwYXRoIGluc2lkZSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL21udC97aGFzaH0vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBib3VuZGFyeS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFic29sdXRlIEltcG9ydHM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIElmIGFuIE1EWCBwYWdlIG5lZWRzIHRvIGltcG9ydCBnbG9iYWwgc2hhcmVkIG1vZHVsZXMgKGUuZy4gYSBjZW50cmFsaXplZCB0aGVtZSBoZWxwZXIgb3IgZGVzaWduIHN5c3RlbSBidW5kbGUpLCBpdCBjYW4gaW1wb3J0IGRpcmVjdGx5IHVzaW5nIGFic29sdXRlIHBhdGhzOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgeyBCdXR0b24gfSBmcm9tIFxcXCIvbW50L3toYXNofS9saWIvdWkudHN4XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQZXJzaXN0ZW5jZSBBY3Jvc3MgU2Vzc2lvbnM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEJlY2F1c2UgZmlsZXN5c3RlbSBoYXNoZXMgYW5kIFNwYWNlIElEcyBhcmUgc3RhYmxlLCB0aGVzZSBhYnNvbHV0ZSBhbmQgcmVsYXRpdmUgaW1wb3J0cyByZXNvbHZlIHJlbGlhYmx5IGFjcm9zcyBicm93c2VyIHNlc3Npb25zLCByZWJvb3RzLCBhbmQgaG90IHJlbG9hZHMsIHByb3ZpZGVkIHRoZSB0YXJnZXQgZmlsZXN5c3RlbSBpcyBtb3VudGVkIHdpdGggYXBwcm9wcmlhdGUgY2FwYWJpbGl0aWVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCIzMi1keW5hbWljLXRoaXJkLXBhcnR5LWpzeC1jb21waWxhdGlvblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiMzItZHluYW1pYy10aGlyZC1wYXJ0eS1qc3gtY29tcGlsYXRpb25cIiAvPntcIsKnMy4yIER5bmFtaWMgVGhpcmQtUGFydHkgSlNYIENvbXBpbGF0aW9uXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJNRFggY29udGVudCBjb250YWluaW5nIHRoaXJkLXBhcnR5IEpTWCBjb21wb25lbnRzIGlzIGV2YWx1YXRlZCBkeW5hbWljYWxseSBieSB0aGUgYmxvZyBlbmdpbmUgaW5zaWRlIHRoZSBpZnJhbWUgc2FuZGJveDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXaGVuIGEgcmVhZGVyIG5hdmlnYXRlcyB0byBhbiBNRFggcGFnZSwgdGhlIGJsb2cgZW5naW5lIHJlcXVlc3RzIHRoZSBmaWxlJ3MgcmF3IGNvbnRlbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIGNvZGUgaXMgY29tcGlsZWQgYnkgdGhlIGJyb3dzZXItc2lkZSBjb21waWxlciBwcm92aWRlZCBieSBpbW1lZGlhdGVseS5ydW4sIHByZXNlcnZpbmcgdGhlIGltcG9ydCBkZWNsYXJhdGlvbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHBsYXRmb3JtJ3MgZHluYW1pYyBidW5kbGVyIG1hcHMgdGhlIHJlc29sdmVkIGltcG9ydCBwYXRocyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL21udC97aGFzaH0vLi4uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgdG8gdGhlIGxpdmUsIHNhbmRib3hlZCBmaWxlc3lzdGVtLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIklmIGFuIGltcG9ydCBmYWlscyAoZS5nLiBhIGNvbXBvbmVudCBmaWxlIHdhcyBkZWxldGVkIG9yIHRoZSBtb3VudCBpcyBtaXNzaW5nKSwgdGhlIGJsb2cgd3JhcHMgdGhlIHBhZ2UgaW4gYSBSZWFjdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8RXJyb3JCb3VuZGFyeT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRhaW5lciwgcmVuZGVyaW5nIGFuIGVsZWdhbnQgcGxhY2Vob2xkZXIgYmxvY2sgd2hpbGUgcHJlc2VydmluZyB0aGUgcmVzdCBvZiB0aGUgcGFnZSBsYXlvdXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy00XCIgZGF0YS1zbHVnPVwiNC10aGUtZ2F0ZWQtZWRpdGluZy1leHBlcmllbmNlLWVkaXRvci1pbnRlZ3JhdGlvbi1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0LiBUaGUgR2F0ZWQgRWRpdGluZyBFeHBlcmllbmNlICYgRWRpdG9yIEludGVncmF0aW9uIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJbiBzdHJpY3QgY29tcGxpYW5jZSB3aXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzExXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9GSVJTVF9FRElUSU5HX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB0aGUgYmxvZyBkb2VzIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiBpbmNsdWRlIGEgYnVpbHQtaW4gdGV4dC1pbnB1dCBvciBtYXJrZG93biBlZGl0b3IuIEluc3RlYWQsIGl0IHJlbGllcyBvbiBkZWVwIGludGVncmF0aW9uIHdpdGggaW1tZWRpYXRlbHkucnVuJ3MgbmF0aXZlIHdvcmtiZW5jaCBlZGl0b3I6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wi4pSM4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSQXFxu4pSCICBCbG9nIC8gV2lraSBVSSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKUglxcbuKUgiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilIJcXG7ilIIgIFsgVGl0bGUgb2YgUGFnZSBdICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCXFxu4pSCICBXcml0dGVuIG9uIEp1bmUgMjMsIDIwMjYg4oCiIEJ5IENvbnRyaWJ1dG9yIFtFZGl0IFBhZ2Ug4pyOXSDilIDilIDilIDilIDilIDilIDilLzilIDilIDilIDilJBcXG7ilIIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCICAg4pSCXFxu4pSCICBUaGlzIGlzIE1EWCBjb250ZW50IGJlaW5nIHJlYWQgaW5zaWRlIHRoZSBzYW5kYm94ZWQgaWZyYW1lLiAgIOKUgiAgIOKUglxcbuKUlOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUmCAgIOKUglxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKUgiAoU0RLIEludm9rZSlcXG7ilIzilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJAgICDilrxcXG7ilIIgIGltbWVkaWF0ZWx5LnJ1biBIb3N0IFdvcmtiZW5jaCAoQWN0aXZlIE92ZXJsYXkpICAgICAgICAgICAgICDilIIgICDilIJcXG7ilIIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCICAg4pSCXFxu4pSCICDilIzilIAgRmlsZTogL21udC9zcGFjZS14eXovZW50cmllcy9mdXR1cmUtb2YtYWkubWR4IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUkCAg4pSCICAg4pSCXFxu4pSCICDilIIgLS0tICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCICDilILil4TilIDilIDilJhcXG7ilIIgIOKUgiB0aXRsZTogVGhlIEZ1dHVyZSBvZiBBcnRpZmljaWFsIEludGVsbGlnZW5jZSAgICAgICAgICAgICDilIIgIOKUglxcbuKUgiAg4pSCIC0tLSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKUgiAg4pSCXFxu4pSCICDilIIgRXhwbG9yaW5nIGhvdyBBSSBpcyB0cmFuc2Zvcm1pbmcgY3JlYXRpdmUgd29ya2Zsb3dzLi4uICAg4pSCICDilIJcXG7ilIIgIOKUlOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUmCAg4pSCXFxu4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjQxLXJlYWQtb25seS1leHBlcmllbmNlLXplcm8tY2hyb21lLXByaW5jaXBsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiNDEtcmVhZC1vbmx5LWV4cGVyaWVuY2UtemVyby1jaHJvbWUtcHJpbmNpcGxlXCIgLz57XCLCpzQuMSBSZWFkLU9ubHkgRXhwZXJpZW5jZSAoWmVyby1DaHJvbWUgUHJpbmNpcGxlKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXaGVuIHRoZSBhY3RpdmUgd29ya3NwYWNlIG1vdW50IGhhcyByZWFkLW9ubHkgcGVybWlzc2lvbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGU6IFxcXCJyb1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgb3Igd2hlbiB0aGUgdXNlciBpcyB1bmF1dGhlbnRpY2F0ZWQsIGFsbCBlZGl0IGFmZm9yZGFuY2VzLCBidXR0b25zLCBhbmQgc2V0dGluZ3MgYXJlIHN0cmlwcGVkIGZyb20gdGhlIERPTS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgdXNlciBpcyBwcmVzZW50ZWQgd2l0aCBhIHByaXN0aW5lLCB1bmNsdXR0ZXJlZCBjb250ZW50IHZpZXcuIFVuZGVyIG5vIGNpcmN1bXN0YW5jZXMgd2lsbCBhIHJlYWQtb25seSByZWFkZXIgYmUgZXhwb3NlZCB0byBpbnRlcmFjdGl2ZSBjb250cm9scyB0aGF0IHlpZWxkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVST0ZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoUmVhZC1vbmx5IGZpbGUgc3lzdGVtKSBlcnJvcnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjQyLWFjdGlvbmFibGUtZWRpdGluZy1hZmZvcmRhbmNlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiNDItYWN0aW9uYWJsZS1lZGl0aW5nLWFmZm9yZGFuY2VzXCIgLz57XCLCpzQuMiBBY3Rpb25hYmxlIEVkaXRpbmcgQWZmb3JkYW5jZXNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiV2hlbiB0aGUgd29ya3NwYWNlIG1vdW50IGhhcyB3cml0ZSBwZXJtaXNzaW9ucyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZTogXFxcInJ3XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB0aGUgYXBwIGV4cG9zZXMgYSBzdWJ0bGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiRWRpdCBFbnRyeVxcXCIgKOKcjilcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYnV0dG9uIG5leHQgdG8gdGhlIHRpdGxlIG9yIHNlY3Rpb24gaGVhZGVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDbGlja2luZyB0aGUgYnV0dG9uIHJlcXVlc3RzIHNpbmdsZS1maWxlIHdyaXRlIGRlbGVnYXRpb24gdmlhIHRoZSBTREsgYW5kIHRyaWdnZXJzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhvc3QgdGFzazpcIn17XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXRzXCI+e1wiaW1wb3J0IHsgaW52b2tlVGFzaywgY2FwRmlsZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcXG5cXG5hd2FpdCBpbnZva2VUYXNrKCdlZGl0LWZpbGUnLCB7XFxuICBmaWxlOiBjYXBGaWxlKHsgbW91bnRJZDogJ3NwYWNlOnRlYW0td2lraScsIHJlbFBhdGg6ICdlbnRyaWVzL2Z1dHVyZS1vZi1haS5tZHgnIH0sIHsgbW9kZTogJ3J3JyB9KSxcXG59KTtcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQW55IGVkaXRzIG1hZGUgaW4gdGhlIHBsYXRmb3JtIGVkaXRvciB0cmlnZ2VyIHRoZSBicm93c2VyJ3MgaG90IG1vZHVsZSByZWxvYWRpbmcgKEhNUikgZmxvdywgaW5zdGFudGx5IHVwZGF0aW5nIHRoZSBibG9nL3dpa2kgcGFnZSB2aWV3IGJlaGluZCB0aGUgZWRpdG9yIG92ZXJsYXkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjQzLXN0cnVjdHVyZWQtY29udGVudC1zY2FmZm9sZGluZ1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiNDMtc3RydWN0dXJlZC1jb250ZW50LXNjYWZmb2xkaW5nXCIgLz57XCLCpzQuMyBTdHJ1Y3R1cmVkIENvbnRlbnQgU2NhZmZvbGRpbmdcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVG8gd3JpdGUgYSBuZXcgcG9zdCwgYXV0aG9yaXplZCBjb250cmlidXRvcnMgY2xpY2sgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJOZXcgRW50cnlcXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJ1dHRvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgYXBwIHJlcXVlc3RzIHRpdGxlIGlucHV0LCB2YWxpZGF0ZXMgdGhhdCB0aGUgdGl0bGUgZG9lcyBub3QgY29sbGlkZSB3aXRoIGV4aXN0aW5nIGVudHJpZXMsIGFuZCB3cml0ZXMgYSBza2VsZXRvbiB0ZW1wbGF0ZSBjb250YWluaW5nIGRlZmF1bHQgZnJvbnRtYXR0ZXI6XCJ9e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1tYXJrZG93blwiPntcIi0tLVxcbnRpdGxlOiBcXFwiQSBOZXcgSm91cm5leVxcXCJcXG5kYXRlOiBKdW5lIDIzLCAyMDI2XFxudGFnczogW11cXG4tLS1cXG5UeXBlIHlvdXIgY29udGVudHMgaGVyZS4uLlxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgYXBwIGltbWVkaWF0ZWx5IHRyaWdnZXJzIHRoZSBwbGF0Zm9ybSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFzayBvbiB0aGUgbmV3bHkgY3JlYXRlZCBmaWxlIHBhdGguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy01XCIgZGF0YS1zbHVnPVwiNS1mcm9udG1hdHRlci1oYXJ2ZXN0aW5nLWZ1bGwtdGV4dC1zZWFyY2gtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNVwiIC8+e1wiNS4gRnJvbnRtYXR0ZXIgSGFydmVzdGluZyAmIEZ1bGwtVGV4dCBTZWFyY2ggXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRvIGVuYWJsZSBuYXZpZ2F0aW9uLCBjYXRlZ29yaXphdGlvbnMsIGFuZCBzZWFyY2hpbmcgd2l0aG91dCBhIHN0YXRpYyBiYWNrZW5kLCB0aGUgQmxvZy9XaWtpIGFwcCBydW5zIGFuIGFjdGl2ZSBjbGllbnQtc2lkZSBtZXRhZGF0YSBpbmRleGVyOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCI1MS1mcm9udG1hdHRlci1zcGVjXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCI1MS1mcm9udG1hdHRlci1zcGVjXCIgLz57XCLCpzUuMSBGcm9udG1hdHRlciBTcGVjXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmVyeSBibG9nIHBvc3QgLyB3aWtpIHBhZ2UgaXMgZXhwZWN0ZWQgdG8gYmVnaW4gd2l0aCBhIHN0YW5kYXJkIGZyb250bWF0dGVyIGJsb2NrOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXlhbWxcIj57XCItLS1cXG50aXRsZTogXFxcIkRpZ2l0YWwgV2VsbG5lc3M6IEZpbmRpbmcgQmFsYW5jZSBpbiBhIENvbm5lY3RlZCBXb3JsZFxcXCJcXG5kYXRlOiBcXFwiSmFudWFyeSAxMCwgMjAyNFxcXCJcXG5yZWFkdGltZTogXFxcIjYgbWluIHJlYWRcXFwiXFxudGFnczogW0xpZmVzdHlsZSwgV2VsbG5lc3NdXFxuZXhjZXJwdDogXFxcIlByYWN0aWNhbCBzdHJhdGVnaWVzIGZvciBtYWludGFpbmluZyBtZW50YWwgaGVhbHRoIGFuZCBwcm9kdWN0aXZpdHkgd2hpbGUgbmF2aWdhdGluZyBvdXIgaW5jcmVhc2luZ2x5IGRpZ2l0YWwgbGl2ZXMuXFxcIlxcbi0tLVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCI1Mi1jbGllbnQtc2lkZS1oYXJ2ZXN0aW5nLWVuZ2luZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiNTItY2xpZW50LXNpZGUtaGFydmVzdGluZy1lbmdpbmVcIiAvPntcIsKnNS4yIENsaWVudC1TaWRlIEhhcnZlc3RpbmcgRW5naW5lXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTG9jYWwgSW5kZXhlcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGVuZ2luZSBxdWVyaWVzIGZpbGVzIG1hdGNoaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9lbnRyaWVzLyoqLyoubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3IgY3VzdG9tIHBhdGhzIHNwZWNpZmllZCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJibG9nLWNvbmZpZy5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMYXp5IE1ldGFkYXRhIFNjcmFwZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSW5zdGVhZCBvZiByZWFkaW5nIGZ1bGwgZmlsZXMsIHRoZSBhcHAgcmVhZHMgb25seSB0aGUgZmlyc3QgNTAwIGJ5dGVzIG9mIGVhY2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmlsZSB0byBwYXJzZSB0aGUgZnJvbnRtYXR0ZXIgbWV0YWRhdGEgYmxvY2suXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTREsgUXVlcnkgSG9vayBJbnRlZ3JhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRm9yIGluLXJlcG8gZmlsZXMsIHRoZSBhcHAgaW50ZWdyYXRlcyB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtZXRhZGF0YSBxdWVyaWVzOlwifXtcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtdHNcIj57XCJpbXBvcnQgeyB1c2VNZXRhZGF0YVF1ZXJ5LCB1c2VGaWxlTWV0YWRhdGEgfSBmcm9tIFxcXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9ob29rc1xcXCI7XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW4tTWVtb3J5IFNlYXJjaCBJbmRleDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHBhcnNlZCB0aXRsZXMsIHRhZ3MsIGFuZCBleGNlcnB0cyBhcmUgY29tcGlsZWQgaW50byBhIGxpZ2h0d2VpZ2h0IGNsaWVudC1zaWRlIGluZGV4LiBGdWxsLXRleHQgc2VhcmNoIGZpbHRlcnMgdGhpcyBpbmRleCBpbnN0YW50bHkgb24gdGhlIGNsaWVudCwgYXZvaWRpbmcgYW55IHJlbW90ZSBBUEkgcm91bmRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNlwiIGRhdGEtc2x1Zz1cIjYtbGF5b3V0cy1kZXNpZ24tdG9rZW5zLW5vcm1hdGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTZcIiAvPntcIjYuIExheW91dHMgJiBEZXNpZ24gVG9rZW5zIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgQmxvZy9XaWtpIGlzIGJ1aWx0IHRvIGZvbGxvdyB0aGUgaW1tZWRpYXRlbHkucnVuIHByb2plY3Qtc3BlY2lmaWMgYnJhbmQgZGVzaWduIGxhbmd1YWdlIHNwZWNpZmllZCBpbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIkNMQVVERS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCI6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIjYxLWFlc3RoZXRpY3MtdWlcIj48SGVhZGluZ0FuY2hvciBpZD1cIjYxLWFlc3RoZXRpY3MtdWlcIiAvPntcIsKnNi4xIEFlc3RoZXRpY3MgJiBVSVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhbnZhczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQ29vbCBuZWFyLWJsYWNrIGJhY2tkcm9wIChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0b2tlbikgYXMgZGVmYXVsdCB3aXRoIG5lYXItd2hpdGUgaW5rIChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWlua1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWNjZW50czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTmVvbiBtYWdlbnRhLXRvLXZpb2xldCBncmFkaWVudCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0b2tlbikgZm9yIGludGVyYWN0aXZlIGxpbmtzLCBjYXRlZ29yeSBwaWxscywgYW5kIGhlYWRlciBkZXRhaWxzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHlwb2dyYXBoeTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR2FiYXJpdG8gZGlzcGxheSBmYW1pbHkgZm9yIGhlYWRsaW5lczsgU3BhY2UgTW9ubyBkZXRhaWxzIGZvciBtZXRhZGF0YSwgdGFncywgYW5kIHRpbWVzdGFtcHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCb3JkZXJzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGluLCBlbGVnYW50IGhhaXJsaW5lIGJvcmRlcnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taGFpcmxpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMXB4IHNvbGlkIHZhcigtLXBhbmVsKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2hhZG93czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSGFyZC1vZmZzZXQgc29saWQgYmxvY2sgc2hhZG93cyBvbiBjYXJkIGhvdmVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvcHk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENsZWFuLCBtb2Rlcm4gc2VudGVuY2UgY2FzZS4gSGVhZGluZ3MgdGVybWluYXRlIHdpdGggYSBwZXJpb2QgKGUuZy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRnV0dXJlIG9mIEFJLlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSWNvbnM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEx1Y2lkZSBpY29ucyBzaXplZCB0byAxNnB44oCTMjRweCwgdXNpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VycmVudENvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIEVtb2ppczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGJyYW5kIHN0cmljdGx5IGZvcmJpZHMgZW1vamlzIGluIGFueSBsYXlvdXQgZmlsZXMsIHBhZ2UgaW5kZXhlcywgb3IgdGVtcGxhdGVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzXCIgLz57XCJEZWNpc2lvbnMgJiBSZWplY3RlZCBBbHRlcm5hdGl2ZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDaG9zZSBkeW5hbWljIEVTIHJ1bnRpbWUgaW1wb3J0cyBvdmVyIHN0YXRpYyBidWlsZCBwcmUtcmVuZGVyaW5nOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSYXRpb25hbGU6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgU3RhdGljIHNpdGUgZ2VuZXJhdGlvbiBpcyBpbXBvc3NpYmxlIGZvciBhcmJpdHJhcnkgZXh0ZXJuYWwgd29ya3NwYWNlIG1vdW50cyBsb2FkZWQgZHluYW1pY2FsbHkgYXQgcnVudGltZS4gQ29tcGlsaW5nIGFuZCBidW5kbGluZyBNRFggZGlyZWN0bHkgaW4gdGhlIHNhbmRib3ggYnJvd3NlciBlbnZpcm9ubWVudCBhbGlnbnMgd2l0aCBpbW1lZGlhdGVseS5ydW4ncyBuby1idWlsZCBydW50aW1lIG1vZGVsLCBlbnN1cmluZyBjb21wbGV0ZSBmbGV4aWJpbGl0eSBmb3IgZm9ya2VkIHRoZW1lcyBhbmQgY3VzdG9taXplZCBjb2RlIGJsb2Nrcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNob3NlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFzayBkZWxlZ2F0aW9uIG92ZXIgaW5saW5lIGVkaXRvcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmF0aW9uYWxlOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFJlaW5mb3JjZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcm9kdWN0IFZhbHVlIDdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ0xBVURFLm1kIMKnMTFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIE1pbmltaXplcyBidW5kbGUgc2l6ZSwgbWF4aW1pemVzIG1vYmlsZSBlZGl0aW5nIHJlc3BvbnNpdmVuZXNzIChoYW5kbGluZyBzb2Z0IGtleWJvYXJkIHZpZXdwb3J0IHJlc2l6aW5nKSwgYW5kIGdpdmVzIHVzZXJzIHdobyBmb3JrIHRoZWlyIHBsYXRmb3JtIGVkaXRvciBjdXN0b20ga2V5YmluZGluZ3MsIHRhYnMsIGFuZCBkaWFnbm9zdGljIHBhbmVscyBhY3Jvc3MgZXZlcnkgYmxvZyB0aGV5IGVkaXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDaG9zZSBzdGFibGUgcGF0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvbW50L3toYXNofVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVzb2x1dGlvbiBmb3IgaW1wb3J0czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmF0aW9uYWxlOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFN0b3JpbmcgbW9kdWxlcyBpbiBleHRlcm5hbCBjb2xsYWJvcmF0aXZlIHNwYWNlcyByZXF1aXJlcyBhIHN0YWJsZSBpbXBvcnQgcGF0aC4gQmVjYXVzZSBpbW1lZGlhdGVseS5ydW4gZ3VhcmFudGVlcyBzdGFibGUgdmlydHVhbCBwYXRocyBmb3IgbW91bnRzIGFjcm9zcyBzZXNzaW9uIHJlYm9vdHMsIHdlIGNhbiBkaXJlY3RseSB1dGlsaXplIEVTIGltcG9ydHMgaW5zaWRlIE1EWCBmaWxlcyB3aXRob3V0IG5lZWRpbmcgY29tcGxleCBkeW5hbWljIGltcG9ydCBwcm94aWVzIG9yIHZpcnR1YWwgcGF0aCBtYXBwaW5nIGxheWVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwib3Blbi1xdWVzdGlvbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm9wZW4tcXVlc3Rpb25zXCIgLz57XCJPcGVuIFF1ZXN0aW9uc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvdyBzaG91bGQgd2UgaGFuZGxlIHVuYXV0aGVudGljYXRlZCBhc3NldCBmZXRjaGluZyBmcm9tIHByb3RlY3RlZCBTcGFjZXM/XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuZW0+e1wiUHJvcG9zZWQgU29sdXRpb246XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgSWYgYSBTcGFjZSBpcyBwcml2YXRlLCB1bmF1dGhlbnRpY2F0ZWQgcmVhZGVycyBjYW5ub3QgYWNjZXNzIGl0LiBQdWJsaWMgYmxvZ3MgbXVzdCByZXNpZGUgZWl0aGVyIGluIHB1YmxpYyBnaXQgcmVwb3NpdG9yaWVzIChJbi1SZXBvIG1vZGVsKSBvciBpbnNpZGUgcHVibGljIFNwYWNlcyB3aGVyZSByZWFkLWFjY2VzcyBpcyBleHBsaWNpdGx5IG9wZW4gdG8gcHVibGljIG9yaWdpbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2hhdCBoYXBwZW5zIGlmIGEgdGhpcmQtcGFydHkgSlNYIGNvbXBvbmVudCBpbXBvcnRlZCBpbnNpZGUgdGhlIE1EWCByZXF1ZXN0cyBhIGNhcGFiaWxpdHkgdGhlIHBhcmVudCBibG9nIGFwcCBkb2VzIG5vdCBob2xkP1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmVtPntcIlByb3Bvc2VkIFNvbHV0aW9uOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIER1ZSB0byBzYW5kYm94aW5nLCBhbnkgaW1wb3J0ZWQgSlNYIGNvbXBvbmVudCBydW5zIHN0cmljdGx5IGluc2lkZSB0aGUgQmxvZy9XaWtpIGFwcCdzIHNhbmRib3guIEl0IGNhbiBuZXZlciBleGNlZWQgdGhlIGNhcGFiaWxpdGllcyBncmFudGVkIHRvIHRoZSBCbG9nL1dpa2kgYXBwIGl0c2VsZi4gSWYgYW4gaW1wb3J0ZWQgY29tcG9uZW50IHRyaWVzIHRvIGludm9rZSBhbiB1bmF1dGhvcml6ZWQgU0RLIHRhc2ssIGl0IHdpbGwgc2FmZWx5IHJlamVjdCB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHByb3RlY3RpbmcgdGhlIHVzZXIncyBob3N0IG9yaWdpbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9zcGVjcy9CTE9HX1dJS0lfU1BFQy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZixLQUFLLENBQUNnQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2hCLFdBQVc7RUFDaEMsSUFBSSxDQUFDZ0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixJQUFBLEVBQUFyQixXQUFBLENBQUFzQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDaUIsRUFBRSxFQUFDLHdGQUF3RjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXdGLENBQUUsQ0FBQyxFQUFDLDhGQUE4RjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNDLFVBQVU7TUFBQW1CLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLDJEQUEyRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7WUFBQWtCLFFBQUEsRUFBRTtVQUFrQyxDQUFtQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLHVFQUF1RTtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDQyxVQUFVO01BQUFtQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7UUFBQVUsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSyxFQUFFO01BQUNnQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsb0NBQW9DO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxFQUFFO1FBQUFpQixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUFzTCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHlLQUF5SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyxvTEFBb0w7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsMEVBQTBFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLG9HQUFvRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTJCLENBQXFCLENBQUMsRUFBQyx5R0FBeUcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMsMEVBQTBFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7TUFBQ2dCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLEVBQUU7UUFBQWlCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQWlKLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsNkJBQTZCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkIsQ0FBRSxDQUFDLEVBQUMsK0JBQStCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxzQkFBc0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxpRkFBaUY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxtR0FBbUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsb0NBQW9DO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0MsQ0FBRSxDQUFDLEVBQUMsc0NBQXNDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU8sQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsdUZBQXVGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMscUdBQXFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLG1EQUFtRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBMlMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFrQixRQUFBLEVBQUU7TUFBMHRCLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxzQ0FBc0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQyxDQUFFLENBQUMsRUFBQyx3Q0FBd0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLHlIQUF5SCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7UUFBQWtCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBOEQsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxZQUFZO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGdLQUFnSyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFtRCxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQThCLENBQXFCLENBQUMsRUFBQyx1T0FBdU87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0MsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUEwSCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsRUFBRTtNQUEwRixDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxFQUFFO01BQW9ILENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsaUVBQWlFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLHFIQUFxSCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsa0dBQWtHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDZEQUE2RDtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsNEJBQTRCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxNQUFNO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUI7TUFBQyxDQUFvQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLDJJQUEySTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBa0IsUUFBQSxFQUFFO01BQWswQyxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsK0NBQStDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBK0MsQ0FBRSxDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsNkRBQTZELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGdIQUFnSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsZ0tBQWdLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxxQ0FBcUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUseUZBQXlGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsRUFBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztVQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFDcUIsU0FBUyxFQUFDLGFBQWE7WUFBQUgsUUFBQSxFQUFFO1VBQThNLENBQW1CO1FBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxFQUFFO01BQW9LLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxxQ0FBcUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSx1REFBdUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxVQUFVO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSwrSkFBK0osRUFBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztVQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFDcUIsU0FBUyxFQUFDLG1CQUFtQjtZQUFBSCxRQUFBLEVBQUU7VUFBaUcsQ0FBbUI7UUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsOENBQThDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7TUFBQ2dCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxxREFBcUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLEVBQUU7UUFBQWlCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQStJLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUIsQ0FBRSxDQUFDLEVBQUMsdUJBQXVCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUFxRixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7UUFBQ3FCLFNBQVMsRUFBQyxlQUFlO1FBQUFILFFBQUEsRUFBRTtNQUFxUyxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsa0NBQWtDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0MsQ0FBRSxDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyxpRkFBaUYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsZ0RBQWdEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsb0JBQW9CLEVBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7WUFBQ3FCLFNBQVMsRUFBQyxhQUFhO1lBQUFILFFBQUEsRUFBRTtVQUFxRixDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLHdMQUF3TDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7TUFBQ2dCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLEVBQUU7UUFBQWlCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDJHQUEyRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFXLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtCLENBQUUsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ2EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsZ0dBQWdHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxrREFBa0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7VUFBQWtCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMscUZBQXFGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLGlDQUFpQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlDLENBQUUsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ2EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtRSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLEVBQUU7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQWlCLENBQUMsRUFBQyx1VEFBdVQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBa0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztRQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBaUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLDBPQUEwTztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNFLElBQUk7WUFBQWtCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQywwQkFBMEI7UUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLEVBQUU7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQWlCLENBQUMsRUFBQyxnVEFBZ1Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSyxFQUFFO01BQUNnQixFQUFFLEVBQUMsZ0JBQWdCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0IsQ0FBRSxDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTRFLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ2EsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7WUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxFQUFFO2NBQUFpQixRQUFBLEVBQUU7WUFBb0IsQ0FBaUIsQ0FBQyxFQUFDLDhOQUE4TjtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE4SCxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBaUIsUUFBQSxFQUFFO1lBQW9CLENBQWlCLENBQUMsRUFBQywyUUFBMlEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFrQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsc0NBQXNDO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNsMnRCO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQ3pCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUMwQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHZixLQUFLLENBQUNnQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUE3QixXQUFBLENBQUF5QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLM0IsS0FBSztJQUFBcUIsUUFBQSxlQUFFLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN4QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}