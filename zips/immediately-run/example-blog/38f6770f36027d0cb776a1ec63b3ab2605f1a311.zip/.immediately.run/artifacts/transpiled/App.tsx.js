var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.App = void 0;
require("./styles2.css");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _Callout = _interopRequireDefault(require("./components/Callout"));
var _Button = _interopRequireDefault(require("./components/Button"));
var _More = _interopRequireDefault(require("./components/More"));
var _Image = _interopRequireDefault(require("./components/Image"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const mdxComponents = {
  Callout: _Callout.default,
  Button: _Button.default,
  More: _More.default,
  img: _Image.default
};

// Lazy-loaded main homepage / wiki router
const Homepage = /*#__PURE__*/(0, _react.lazy)(_c = () => module.dynamicImport("./pages/landing.tsx", "*"));
_c2 = Homepage;
const App = () => {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.MDXProvider, {
    components: mdxComponents,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "container",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("header", {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "header-content",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "logo",
            children: "immediately.blog."
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
            children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
                  href: "#",
                  children: "home"
                })
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
                  href: "#",
                  children: "categories"
                })
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
                  href: "#",
                  children: "about"
                })
              })]
            })
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.Suspense, {
        fallback: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "loading-state",
          children: "Loading workspace..."
        }),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(Homepage, {})
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("footer", {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "footer-content",
          children: "built natively as an immediately.run application. zero servers. zero build steps."
        })
      })]
    })
  });
};
exports.App = App;
_c3 = App;
var _default = exports.default = App;
var _c, _c2, _c3;
$RefreshReg$(_c, "Homepage$lazy");
$RefreshReg$(_c2, "Homepage");
$RefreshReg$(_c3, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3JlYWN0IiwiX3NkayIsIl9DYWxsb3V0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9CdXR0b24iLCJfTW9yZSIsIl9JbWFnZSIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwibWR4Q29tcG9uZW50cyIsIkNhbGxvdXQiLCJCdXR0b24iLCJNb3JlIiwiaW1nIiwiSW1hZ2UiLCJIb21lcGFnZSIsImxhenkiLCJfYyIsIm1vZHVsZSIsImR5bmFtaWNJbXBvcnQiLCJfYzIiLCJBcHAiLCJqc3giLCJNRFhQcm92aWRlciIsImNvbXBvbmVudHMiLCJjaGlsZHJlbiIsImpzeHMiLCJjbGFzc05hbWUiLCJocmVmIiwiU3VzcGVuc2UiLCJmYWxsYmFjayIsImV4cG9ydHMiLCJfYzMiLCJfZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9zdHlsZXMyLmNzc1wiO1xuaW1wb3J0IHR5cGUgeyBKU1ggfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFN1c3BlbnNlLCBsYXp5IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBNRFhQcm92aWRlciB9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IENhbGxvdXQgZnJvbSBcIi4vY29tcG9uZW50cy9DYWxsb3V0XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCIuL2NvbXBvbmVudHMvQnV0dG9uXCI7XG5pbXBvcnQgTW9yZSBmcm9tIFwiLi9jb21wb25lbnRzL01vcmVcIjtcbmltcG9ydCBJbWFnZSBmcm9tIFwiLi9jb21wb25lbnRzL0ltYWdlXCI7XG5cbmRlY2xhcmUgY29uc3QgbW9kdWxlOiBhbnk7XG5cbmNvbnN0IG1keENvbXBvbmVudHMgPSB7XG4gIENhbGxvdXQsXG4gIEJ1dHRvbixcbiAgTW9yZSxcbiAgaW1nOiBJbWFnZSxcbn07XG5cbi8vIExhenktbG9hZGVkIG1haW4gaG9tZXBhZ2UgLyB3aWtpIHJvdXRlclxuY29uc3QgSG9tZXBhZ2UgPSBsYXp5KCgpID0+IG1vZHVsZS5keW5hbWljSW1wb3J0KFwiLi9wYWdlcy9sYW5kaW5nLnRzeFwiLCBcIipcIikpO1xuXG5leHBvcnQgY29uc3QgQXBwID0gKCk6IEpTWC5FbGVtZW50ID0+IHtcbiAgcmV0dXJuIChcbiAgICA8TURYUHJvdmlkZXIgY29tcG9uZW50cz17bWR4Q29tcG9uZW50c30+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICA8aGVhZGVyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLWNvbnRlbnRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nb1wiPmltbWVkaWF0ZWx5LmJsb2cuPC9kaXY+XG4gICAgICAgICAgICA8bmF2PlxuICAgICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+aG9tZTwvYT48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI1wiPmNhdGVnb3JpZXM8L2E+PC9saT5cbiAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIiNcIj5hYm91dDwvYT48L2xpPlxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9uYXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PGRpdiBjbGFzc05hbWU9XCJsb2FkaW5nLXN0YXRlXCI+TG9hZGluZyB3b3Jrc3BhY2UuLi48L2Rpdj59PlxuICAgICAgICAgIDxIb21lcGFnZSAvPlxuICAgICAgICA8L1N1c3BlbnNlPlxuXG4gICAgICAgIDxmb290ZXI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItY29udGVudFwiPlxuICAgICAgICAgICAgYnVpbHQgbmF0aXZlbHkgYXMgYW4gaW1tZWRpYXRlbHkucnVuIGFwcGxpY2F0aW9uLiB6ZXJvIHNlcnZlcnMuIHplcm8gYnVpbGQgc3RlcHMuXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9vdGVyPlxuICAgICAgPC9kaXY+XG4gICAgPC9NRFhQcm92aWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUFBLE9BQUE7QUFFQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxRQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxPQUFBLEdBQUFELHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTSxLQUFBLEdBQUFGLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTyxNQUFBLEdBQUFILHNCQUFBLENBQUFKLE9BQUE7QUFBdUMsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsU0FBQUksdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFJdkMsTUFBTUcsYUFBYSxHQUFHO0VBQ3BCQyxPQUFPLEVBQVBBLGdCQUFPO0VBQ1BDLE1BQU0sRUFBTkEsZUFBTTtFQUNOQyxJQUFJLEVBQUpBLGFBQUk7RUFDSkMsR0FBRyxFQUFFQztBQUNQLENBQUM7O0FBRUQ7QUFDQSxNQUFNQyxRQUFRLGdCQUFHLElBQUFDLFdBQUksRUFBQUMsRUFBQSxHQUFDQSxDQUFBLEtBQU1DLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO0FBQUNDLEdBQUEsR0FBeEVMLFFBQVE7QUFFUCxNQUFNTSxHQUFHLEdBQUdBLENBQUEsS0FBbUI7RUFDcEMsb0JBQ0UsSUFBQWhCLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ3ZCLElBQUEsQ0FBQXdCLFdBQVc7SUFBQ0MsVUFBVSxFQUFFZixhQUFjO0lBQUFnQixRQUFBLGVBQ3JDLElBQUFwQixXQUFBLENBQUFxQixJQUFBO01BQUtDLFNBQVMsRUFBQyxXQUFXO01BQUFGLFFBQUEsZ0JBQ3hCLElBQUFwQixXQUFBLENBQUFpQixHQUFBO1FBQUFHLFFBQUEsZUFDRSxJQUFBcEIsV0FBQSxDQUFBcUIsSUFBQTtVQUFLQyxTQUFTLEVBQUMsZ0JBQWdCO1VBQUFGLFFBQUEsZ0JBQzdCLElBQUFwQixXQUFBLENBQUFpQixHQUFBO1lBQUtLLFNBQVMsRUFBQyxNQUFNO1lBQUFGLFFBQUEsRUFBQztVQUFpQixDQUFLLENBQUMsZUFDN0MsSUFBQXBCLFdBQUEsQ0FBQWlCLEdBQUE7WUFBQUcsUUFBQSxlQUNFLElBQUFwQixXQUFBLENBQUFxQixJQUFBO2NBQUFELFFBQUEsZ0JBQ0UsSUFBQXBCLFdBQUEsQ0FBQWlCLEdBQUE7Z0JBQUFHLFFBQUEsZUFBSSxJQUFBcEIsV0FBQSxDQUFBaUIsR0FBQTtrQkFBR00sSUFBSSxFQUFDLEdBQUc7a0JBQUFILFFBQUEsRUFBQztnQkFBSSxDQUFHO2NBQUMsQ0FBSSxDQUFDLGVBQzdCLElBQUFwQixXQUFBLENBQUFpQixHQUFBO2dCQUFBRyxRQUFBLGVBQUksSUFBQXBCLFdBQUEsQ0FBQWlCLEdBQUE7a0JBQUdNLElBQUksRUFBQyxHQUFHO2tCQUFBSCxRQUFBLEVBQUM7Z0JBQVUsQ0FBRztjQUFDLENBQUksQ0FBQyxlQUNuQyxJQUFBcEIsV0FBQSxDQUFBaUIsR0FBQTtnQkFBQUcsUUFBQSxlQUFJLElBQUFwQixXQUFBLENBQUFpQixHQUFBO2tCQUFHTSxJQUFJLEVBQUMsR0FBRztrQkFBQUgsUUFBQSxFQUFDO2dCQUFLLENBQUc7Y0FBQyxDQUFJLENBQUM7WUFBQSxDQUM1QjtVQUFDLENBQ0YsQ0FBQztRQUFBLENBQ0g7TUFBQyxDQUNBLENBQUMsZUFFVCxJQUFBcEIsV0FBQSxDQUFBaUIsR0FBQSxFQUFDeEIsTUFBQSxDQUFBK0IsUUFBUTtRQUFDQyxRQUFRLGVBQUUsSUFBQXpCLFdBQUEsQ0FBQWlCLEdBQUE7VUFBS0ssU0FBUyxFQUFDLGVBQWU7VUFBQUYsUUFBQSxFQUFDO1FBQW9CLENBQUssQ0FBRTtRQUFBQSxRQUFBLGVBQzVFLElBQUFwQixXQUFBLENBQUFpQixHQUFBLEVBQUNQLFFBQVEsSUFBRTtNQUFDLENBQ0osQ0FBQyxlQUVYLElBQUFWLFdBQUEsQ0FBQWlCLEdBQUE7UUFBQUcsUUFBQSxlQUNFLElBQUFwQixXQUFBLENBQUFpQixHQUFBO1VBQUtLLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUYsUUFBQSxFQUFDO1FBRWhDLENBQUs7TUFBQyxDQUNBLENBQUM7SUFBQSxDQUNOO0VBQUMsQ0FDSyxDQUFDO0FBRWxCLENBQUM7QUFBQ00sT0FBQSxDQUFBVixHQUFBLEdBQUFBLEdBQUE7QUFBQVcsR0FBQSxHQTdCV1gsR0FBRztBQUFBLElBQUFZLFFBQUEsR0FBQUYsT0FBQSxDQUFBdkIsT0FBQSxHQStCRGEsR0FBRztBQUFBLElBQUFKLEVBQUEsRUFBQUcsR0FBQSxFQUFBWSxHQUFBO0FBQUFFLFlBQUEsQ0FBQWpCLEVBQUE7QUFBQWlCLFlBQUEsQ0FBQWQsR0FBQTtBQUFBYyxZQUFBLENBQUFGLEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}