var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.More = void 0;
var _jsxRuntime = require("react/jsx-runtime");
const More = () => {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "read-more-divider",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "read-more-dot",
      children: "\u25CF"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "read-more-dot",
      children: "\u25CF"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "read-more-dot",
      children: "\u25CF"
    })]
  });
};
exports.More = More;
_c = More;
var _default = exports.default = More;
var _c;
$RefreshReg$(_c, "More");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJNb3JlIiwiX2pzeFJ1bnRpbWUiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJleHBvcnRzIiwiX2MiLCJfZGVmYXVsdCIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNb3JlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEpTWCB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgY29uc3QgTW9yZSA9ICgpOiBKU1guRWxlbWVudCA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkLW1vcmUtZGl2aWRlclwiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVhZC1tb3JlLWRvdFwiPuKXjzwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlYWQtbW9yZS1kb3RcIj7il488L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWFkLW1vcmUtZG90XCI+4pePPC9zcGFuPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTW9yZTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUVPLE1BQU1BLElBQUksR0FBR0EsQ0FBQSxLQUFtQjtFQUNyQyxvQkFDRSxJQUFBQyxXQUFBLENBQUFDLElBQUE7SUFBS0MsU0FBUyxFQUFDLG1CQUFtQjtJQUFBQyxRQUFBLGdCQUNoQyxJQUFBSCxXQUFBLENBQUFJLEdBQUE7TUFBTUYsU0FBUyxFQUFDLGVBQWU7TUFBQUMsUUFBQSxFQUFDO0lBQUMsQ0FBTSxDQUFDLGVBQ3hDLElBQUFILFdBQUEsQ0FBQUksR0FBQTtNQUFNRixTQUFTLEVBQUMsZUFBZTtNQUFBQyxRQUFBLEVBQUM7SUFBQyxDQUFNLENBQUMsZUFDeEMsSUFBQUgsV0FBQSxDQUFBSSxHQUFBO01BQU1GLFNBQVMsRUFBQyxlQUFlO01BQUFDLFFBQUEsRUFBQztJQUFDLENBQU0sQ0FBQztFQUFBLENBQ3JDLENBQUM7QUFFVixDQUFDO0FBQUNFLE9BQUEsQ0FBQU4sSUFBQSxHQUFBQSxJQUFBO0FBQUFPLEVBQUEsR0FSV1AsSUFBSTtBQUFBLElBQUFRLFFBQUEsR0FBQUYsT0FBQSxDQUFBRyxPQUFBLEdBVUZULElBQUk7QUFBQSxJQUFBTyxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}