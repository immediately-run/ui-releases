var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Callout = void 0;
var _jsxRuntime = require("react/jsx-runtime");
const Callout = ({
  type = "info",
  children
}) => {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: `callout callout-${type}`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "callout-type-tag",
      children: type.toUpperCase()
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "callout-content",
      children: children
    })]
  });
};
exports.Callout = Callout;
_c = Callout;
var _default = exports.default = Callout;
var _c;
$RefreshReg$(_c, "Callout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJDYWxsb3V0IiwidHlwZSIsImNoaWxkcmVuIiwiX2pzeFJ1bnRpbWUiLCJqc3hzIiwiY2xhc3NOYW1lIiwianN4IiwidG9VcHBlckNhc2UiLCJleHBvcnRzIiwiX2MiLCJfZGVmYXVsdCIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYWxsb3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEpTWCwgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBDYWxsb3V0UHJvcHMge1xuICB0eXBlPzogXCJpbmZvXCIgfCBcIndhcm5pbmdcIiB8IFwic3VjY2Vzc1wiIHwgXCJ0aXBcIjtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbn1cblxuZXhwb3J0IGNvbnN0IENhbGxvdXQgPSAoeyB0eXBlID0gXCJpbmZvXCIsIGNoaWxkcmVuIH06IENhbGxvdXRQcm9wcyk6IEpTWC5FbGVtZW50ID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YGNhbGxvdXQgY2FsbG91dC0ke3R5cGV9YH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGxvdXQtdHlwZS10YWdcIj57dHlwZS50b1VwcGVyQ2FzZSgpfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYWxsb3V0LWNvbnRlbnRcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDYWxsb3V0O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBT08sTUFBTUEsT0FBTyxHQUFHQSxDQUFDO0VBQUVDLElBQUksR0FBRyxNQUFNO0VBQUVDO0FBQXVCLENBQUMsS0FBa0I7RUFDakYsb0JBQ0UsSUFBQUMsV0FBQSxDQUFBQyxJQUFBO0lBQUtDLFNBQVMsRUFBRSxtQkFBbUJKLElBQUksRUFBRztJQUFBQyxRQUFBLGdCQUN4QyxJQUFBQyxXQUFBLENBQUFHLEdBQUE7TUFBS0QsU0FBUyxFQUFDLGtCQUFrQjtNQUFBSCxRQUFBLEVBQUVELElBQUksQ0FBQ00sV0FBVyxDQUFDO0lBQUMsQ0FBTSxDQUFDLGVBQzVELElBQUFKLFdBQUEsQ0FBQUcsR0FBQTtNQUFLRCxTQUFTLEVBQUMsaUJBQWlCO01BQUFILFFBQUEsRUFBRUE7SUFBUSxDQUFNLENBQUM7RUFBQSxDQUM5QyxDQUFDO0FBRVYsQ0FBQztBQUFDTSxPQUFBLENBQUFSLE9BQUEsR0FBQUEsT0FBQTtBQUFBUyxFQUFBLEdBUFdULE9BQU87QUFBQSxJQUFBVSxRQUFBLEdBQUFGLE9BQUEsQ0FBQUcsT0FBQSxHQVNMWCxPQUFPO0FBQUEsSUFBQVMsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}