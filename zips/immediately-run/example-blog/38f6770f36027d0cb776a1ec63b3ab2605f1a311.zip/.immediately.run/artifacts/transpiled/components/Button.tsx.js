var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Button = void 0;
var _jsxRuntime = require("react/jsx-runtime");
const Button = ({
  children,
  className = "",
  ...props
}) => {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
    className: `btn-primary ${className}`,
    ...props,
    children: children
  });
};
exports.Button = Button;
_c = Button;
var _default = exports.default = Button;
var _c;
$RefreshReg$(_c, "Button");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJCdXR0b24iLCJjaGlsZHJlbiIsImNsYXNzTmFtZSIsInByb3BzIiwiX2pzeFJ1bnRpbWUiLCJqc3giLCJleHBvcnRzIiwiX2MiLCJfZGVmYXVsdCIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCdXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgSlNYLCBSZWFjdE5vZGUsIEJ1dHRvbkhUTUxBdHRyaWJ1dGVzIH0gZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBCdXR0b25Qcm9wcyBleHRlbmRzIEJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PiB7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59XG5cbmV4cG9ydCBjb25zdCBCdXR0b24gPSAoeyBjaGlsZHJlbiwgY2xhc3NOYW1lID0gXCJcIiwgLi4ucHJvcHMgfTogQnV0dG9uUHJvcHMpOiBKU1guRWxlbWVudCA9PiB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvbiBjbGFzc05hbWU9e2BidG4tcHJpbWFyeSAke2NsYXNzTmFtZX1gfSB7Li4ucHJvcHN9PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQnV0dG9uO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBTU8sTUFBTUEsTUFBTSxHQUFHQSxDQUFDO0VBQUVDLFFBQVE7RUFBRUMsU0FBUyxHQUFHLEVBQUU7RUFBRSxHQUFHQztBQUFtQixDQUFDLEtBQWtCO0VBQzFGLG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFRSCxTQUFTLEVBQUUsZUFBZUEsU0FBUyxFQUFHO0lBQUEsR0FBS0MsS0FBSztJQUFBRixRQUFBLEVBQ3JEQTtFQUFRLENBQ0gsQ0FBQztBQUViLENBQUM7QUFBQ0ssT0FBQSxDQUFBTixNQUFBLEdBQUFBLE1BQUE7QUFBQU8sRUFBQSxHQU5XUCxNQUFNO0FBQUEsSUFBQVEsUUFBQSxHQUFBRixPQUFBLENBQUFHLE9BQUEsR0FRSlQsTUFBTTtBQUFBLElBQUFPLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}