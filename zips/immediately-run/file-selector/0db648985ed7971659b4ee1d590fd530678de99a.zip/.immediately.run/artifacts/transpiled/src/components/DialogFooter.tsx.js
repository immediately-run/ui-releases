var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DialogFooter;
var _context = require("../lib/context");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The save-name field (save-file only) + selection summary + Cancel / primary.
function DialogFooter() {
  _s();
  const c = (0, _context.useController)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "fs-foot",
    children: [c.isSave && /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
      className: "fs-savefield",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "fs-savefield-label",
        children: "Save as"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "fs-savefield-input",
        value: c.saveName,
        placeholder: "filename",
        "aria-label": "File name",
        onChange: e => c.setSaveName(e.target.value),
        onKeyDown: e => {
          if (e.key === 'Enter' && c.canConfirm) c.confirm();
        }
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "fs-foot-row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: `fs-selpath${c.error ? ' is-error' : ''}`,
        children: c.selectionLabel
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "fs-btn fs-btn-quiet",
        onClick: c.cancel,
        children: "Cancel"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "fs-btn fs-btn-primary",
        disabled: !c.canConfirm || c.busy,
        onClick: c.confirm,
        children: c.primaryLabel
      })]
    })]
  });
}
_s(DialogFooter, "EpRKP5YlLygKruAQ/BiYBiBA7QE=", false, function () {
  return [_context.useController];
});
_c = DialogFooter;
var _c;
$RefreshReg$(_c, "DialogFooter");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29udGV4dCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiRGlhbG9nRm9vdGVyIiwiYyIsInVzZUNvbnRyb2xsZXIiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJpc1NhdmUiLCJqc3giLCJ2YWx1ZSIsInNhdmVOYW1lIiwicGxhY2Vob2xkZXIiLCJvbkNoYW5nZSIsImUiLCJzZXRTYXZlTmFtZSIsInRhcmdldCIsIm9uS2V5RG93biIsImtleSIsImNhbkNvbmZpcm0iLCJjb25maXJtIiwiZXJyb3IiLCJzZWxlY3Rpb25MYWJlbCIsInR5cGUiLCJvbkNsaWNrIiwiY2FuY2VsIiwiZGlzYWJsZWQiLCJidXN5IiwicHJpbWFyeUxhYmVsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEaWFsb2dGb290ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNvbnRyb2xsZXIgfSBmcm9tICcuLi9saWIvY29udGV4dCc7XG5cbi8vIFRoZSBzYXZlLW5hbWUgZmllbGQgKHNhdmUtZmlsZSBvbmx5KSArIHNlbGVjdGlvbiBzdW1tYXJ5ICsgQ2FuY2VsIC8gcHJpbWFyeS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERpYWxvZ0Zvb3RlcigpIHtcbiAgY29uc3QgYyA9IHVzZUNvbnRyb2xsZXIoKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZzLWZvb3RcIj5cbiAgICAgIHtjLmlzU2F2ZSAmJiAoXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmcy1zYXZlZmllbGRcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmcy1zYXZlZmllbGQtbGFiZWxcIj5TYXZlIGFzPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZnMtc2F2ZWZpZWxkLWlucHV0XCJcbiAgICAgICAgICAgIHZhbHVlPXtjLnNhdmVOYW1lfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJmaWxlbmFtZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiRmlsZSBuYW1lXCJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gYy5zZXRTYXZlTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyAmJiBjLmNhbkNvbmZpcm0pIGMuY29uZmlybSgpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgKX1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtZm9vdC1yb3dcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZnMtc2VscGF0aCR7Yy5lcnJvciA/ICcgaXMtZXJyb3InIDogJyd9YH0+e2Muc2VsZWN0aW9uTGFiZWx9PC9zcGFuPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJmcy1idG4gZnMtYnRuLXF1aWV0XCIgb25DbGljaz17Yy5jYW5jZWx9PlxuICAgICAgICAgIENhbmNlbFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImZzLWJ0biBmcy1idG4tcHJpbWFyeVwiXG4gICAgICAgICAgZGlzYWJsZWQ9eyFjLmNhbkNvbmZpcm0gfHwgYy5idXN5fVxuICAgICAgICAgIG9uQ2xpY2s9e2MuY29uZmlybX1cbiAgICAgICAgPlxuICAgICAgICAgIHtjLnByaW1hcnlMYWJlbH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsUUFBQSxHQUFBQyxPQUFBO0FBQStDLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLElBQUFFLEVBQUEsR0FBQUMsWUFBQSxJQUUvQztBQUNlLFNBQVNDLFlBQVlBLENBQUEsRUFBRztFQUFBRixFQUFBO0VBQ3JDLE1BQU1HLENBQUMsR0FBRyxJQUFBQyxzQkFBYSxFQUFDLENBQUM7RUFDekIsb0JBQ0UsSUFBQUwsV0FBQSxDQUFBTSxJQUFBO0lBQUtDLFNBQVMsRUFBQyxTQUFTO0lBQUFDLFFBQUEsR0FDckJKLENBQUMsQ0FBQ0ssTUFBTSxpQkFDUCxJQUFBVCxXQUFBLENBQUFNLElBQUE7TUFBT0MsU0FBUyxFQUFDLGNBQWM7TUFBQUMsUUFBQSxnQkFDN0IsSUFBQVIsV0FBQSxDQUFBVSxHQUFBO1FBQU1ILFNBQVMsRUFBQyxvQkFBb0I7UUFBQUMsUUFBQSxFQUFDO01BQU8sQ0FBTSxDQUFDLGVBQ25ELElBQUFSLFdBQUEsQ0FBQVUsR0FBQTtRQUNFSCxTQUFTLEVBQUMsb0JBQW9CO1FBQzlCSSxLQUFLLEVBQUVQLENBQUMsQ0FBQ1EsUUFBUztRQUNsQkMsV0FBVyxFQUFDLFVBQVU7UUFDdEIsY0FBVyxXQUFXO1FBQ3RCQyxRQUFRLEVBQUdDLENBQUMsSUFBS1gsQ0FBQyxDQUFDWSxXQUFXLENBQUNELENBQUMsQ0FBQ0UsTUFBTSxDQUFDTixLQUFLLENBQUU7UUFDL0NPLFNBQVMsRUFBR0gsQ0FBQyxJQUFLO1VBQ2hCLElBQUlBLENBQUMsQ0FBQ0ksR0FBRyxLQUFLLE9BQU8sSUFBSWYsQ0FBQyxDQUFDZ0IsVUFBVSxFQUFFaEIsQ0FBQyxDQUFDaUIsT0FBTyxDQUFDLENBQUM7UUFDcEQ7TUFBRSxDQUNILENBQUM7SUFBQSxDQUNHLENBQ1IsZUFDRCxJQUFBckIsV0FBQSxDQUFBTSxJQUFBO01BQUtDLFNBQVMsRUFBQyxhQUFhO01BQUFDLFFBQUEsZ0JBQzFCLElBQUFSLFdBQUEsQ0FBQVUsR0FBQTtRQUFNSCxTQUFTLEVBQUUsYUFBYUgsQ0FBQyxDQUFDa0IsS0FBSyxHQUFHLFdBQVcsR0FBRyxFQUFFLEVBQUc7UUFBQWQsUUFBQSxFQUFFSixDQUFDLENBQUNtQjtNQUFjLENBQU8sQ0FBQyxlQUNyRixJQUFBdkIsV0FBQSxDQUFBVSxHQUFBO1FBQVFjLElBQUksRUFBQyxRQUFRO1FBQUNqQixTQUFTLEVBQUMscUJBQXFCO1FBQUNrQixPQUFPLEVBQUVyQixDQUFDLENBQUNzQixNQUFPO1FBQUFsQixRQUFBLEVBQUM7TUFFekUsQ0FBUSxDQUFDLGVBQ1QsSUFBQVIsV0FBQSxDQUFBVSxHQUFBO1FBQ0VjLElBQUksRUFBQyxRQUFRO1FBQ2JqQixTQUFTLEVBQUMsdUJBQXVCO1FBQ2pDb0IsUUFBUSxFQUFFLENBQUN2QixDQUFDLENBQUNnQixVQUFVLElBQUloQixDQUFDLENBQUN3QixJQUFLO1FBQ2xDSCxPQUFPLEVBQUVyQixDQUFDLENBQUNpQixPQUFRO1FBQUFiLFFBQUEsRUFFbEJKLENBQUMsQ0FBQ3lCO01BQVksQ0FDVCxDQUFDO0lBQUEsQ0FDTixDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQzVCLEVBQUEsQ0FuQ3VCRSxZQUFZO0VBQUEsUUFDeEJFLHNCQUFhO0FBQUE7QUFBQXlCLEVBQUEsR0FERDNCLFlBQVk7QUFBQSxJQUFBMkIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}