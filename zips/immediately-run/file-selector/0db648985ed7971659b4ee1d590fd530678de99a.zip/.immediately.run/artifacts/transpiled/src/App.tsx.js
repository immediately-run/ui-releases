var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
require("./index.css");
require("./components/FileSelector.css");
var _FileSelector2 = _interopRequireDefault(require("./components/FileSelector"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file.
// The pick-file task callee (PICK_FILE_TASK_SPEC.md): the caller delegates one or
// more directory roots; the host mints attenuated, task-scoped chroots and hands
// this app their mounted paths. It browses them and returns `{ root, relPath }` —
// it holds no standing authority; the chroots ARE its world (§2).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  // Render in step with the host chrome: mirror the host theme onto <html>, which
  // drives the `[data-theme="light"]` tokens in index.css.
  const theme = (0, _sdk.useHostTheme)();
  (0, _react.useEffect)(() => {
    const root = document.documentElement;
    if (theme === 'light') root.setAttribute('data-theme', 'light');else root.removeAttribute('data-theme');
  }, [theme]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_FileSelector2.default, {});
}
_s(App, "s/fCWdnl0aS9PKe5owjfeMHSkpQ=", false, function () {
  return [_sdk.useHostTheme];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9GaWxlU2VsZWN0b3IyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJBcHAiLCJ0aGVtZSIsInVzZUhvc3RUaGVtZSIsInVzZUVmZmVjdCIsInJvb3QiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsInNldEF0dHJpYnV0ZSIsInJlbW92ZUF0dHJpYnV0ZSIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIFRoZSBwaWNrLWZpbGUgdGFzayBjYWxsZWUgKFBJQ0tfRklMRV9UQVNLX1NQRUMubWQpOiB0aGUgY2FsbGVyIGRlbGVnYXRlcyBvbmUgb3Jcbi8vIG1vcmUgZGlyZWN0b3J5IHJvb3RzOyB0aGUgaG9zdCBtaW50cyBhdHRlbnVhdGVkLCB0YXNrLXNjb3BlZCBjaHJvb3RzIGFuZCBoYW5kc1xuLy8gdGhpcyBhcHAgdGhlaXIgbW91bnRlZCBwYXRocy4gSXQgYnJvd3NlcyB0aGVtIGFuZCByZXR1cm5zIGB7IHJvb3QsIHJlbFBhdGggfWAg4oCUXG4vLyBpdCBob2xkcyBubyBzdGFuZGluZyBhdXRob3JpdHk7IHRoZSBjaHJvb3RzIEFSRSBpdHMgd29ybGQgKMKnMikuXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VIb3N0VGhlbWUgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgJy4vaW5kZXguY3NzJztcbmltcG9ydCAnLi9jb21wb25lbnRzL0ZpbGVTZWxlY3Rvci5jc3MnO1xuaW1wb3J0IEZpbGVTZWxlY3RvciBmcm9tICcuL2NvbXBvbmVudHMvRmlsZVNlbGVjdG9yJztcblxuZnVuY3Rpb24gQXBwKCkge1xuICAvLyBSZW5kZXIgaW4gc3RlcCB3aXRoIHRoZSBob3N0IGNocm9tZTogbWlycm9yIHRoZSBob3N0IHRoZW1lIG9udG8gPGh0bWw+LCB3aGljaFxuICAvLyBkcml2ZXMgdGhlIGBbZGF0YS10aGVtZT1cImxpZ2h0XCJdYCB0b2tlbnMgaW4gaW5kZXguY3NzLlxuICBjb25zdCB0aGVtZSA9IHVzZUhvc3RUaGVtZSgpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XG4gICAgaWYgKHRoZW1lID09PSAnbGlnaHQnKSByb290LnNldEF0dHJpYnV0ZSgnZGF0YS10aGVtZScsICdsaWdodCcpO1xuICAgIGVsc2Ugcm9vdC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtdGhlbWUnKTtcbiAgfSwgW3RoZW1lXSk7XG5cbiAgcmV0dXJuIDxGaWxlU2VsZWN0b3IgLz47XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0FBLE9BQUE7QUFDQUEsT0FBQTtBQUNBLElBQUFFLGNBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUFxRCxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUEsSUFUckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBT0EsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDYjtFQUNBO0VBQ0EsTUFBTU0sS0FBSyxHQUFHLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztFQUM1QixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNQyxJQUFJLEdBQUdDLFFBQVEsQ0FBQ0MsZUFBZTtJQUNyQyxJQUFJTCxLQUFLLEtBQUssT0FBTyxFQUFFRyxJQUFJLENBQUNHLFlBQVksQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FDM0RILElBQUksQ0FBQ0ksZUFBZSxDQUFDLFlBQVksQ0FBQztFQUN6QyxDQUFDLEVBQUUsQ0FBQ1AsS0FBSyxDQUFDLENBQUM7RUFFWCxvQkFBTyxJQUFBUCxXQUFBLENBQUFlLEdBQUEsRUFBQ2pCLGNBQUEsQ0FBQU8sT0FBWSxJQUFFLENBQUM7QUFDekI7QUFBQ0osRUFBQSxDQVhRSyxHQUFHO0VBQUEsUUFHSUUsaUJBQVk7QUFBQTtBQUFBUSxFQUFBLEdBSG5CVixHQUFHO0FBQUEsSUFBQVcsUUFBQSxHQUFBQyxPQUFBLENBQUFiLE9BQUEsR0FhR0MsR0FBRztBQUFBLElBQUFVLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}