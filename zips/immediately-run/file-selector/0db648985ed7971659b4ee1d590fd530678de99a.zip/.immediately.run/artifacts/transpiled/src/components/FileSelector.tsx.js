var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = FileSelector;
var _fileExplorerUi = require("@immediately-run/file-explorer-ui");
require("@immediately-run/file-explorer-ui/styles.css");
var _useFileSelector = require("../hooks/useFileSelector");
var _context = require("../lib/context");
var _explorerAdapter = require("../lib/explorerAdapter");
var _DialogFooter = _interopRequireDefault(require("./DialogFooter"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _NewFolderBar = _interopRequireDefault(require("./NewFolderBar"));
var _OverwriteConfirm = _interopRequireDefault(require("./OverwriteConfirm"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The toolbar above the browse area: the new-folder + filter chrome the library
// doesn't provide. Breadcrumb + root list + entry rows are the library's.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Toolbar({
  c
}) {
  if (!c.allowCreateFolder && !c.hasFilters) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "fs-toolbar",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "fs-toolbar-spacer"
    }), c.allowCreateFolder && /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      type: "button",
      className: "fs-btn fs-btn-quiet fs-toolbar-btn",
      onClick: c.startNewFolder,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "folderPlus",
        size: 14,
        strokeWidth: 1.7
      }), "New folder"]
    }), c.hasFilters && /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      type: "button",
      className: "fs-btn fs-btn-quiet fs-toolbar-btn",
      onClick: c.cycleFilter,
      children: [c.filterLabel, /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "chevD",
        size: 14,
        strokeWidth: 2
      })]
    })]
  });
}
_c = Toolbar;
function FileSelector() {
  _s();
  const c = (0, _useFileSelector.useFileSelector)();
  if (c.invalid) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "fs fs-blank",
      children: "No location to browse."
    });
  }
  if (!c.ready) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "fs fs-blank",
      children: "Loading\u2026"
    });
  }
  const mobile = c.formFactor.class === 'mobile';
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_context.FileSelectorContext.Provider, {
    value: c,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: `fs${mobile ? ' fs-mobile' : ''}`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
        className: "fs-head",
        children: [c.showBack && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "fs-back",
          "aria-label": "Locations",
          onClick: c.backMobile,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "chevL",
            size: 18
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
          className: "fs-title",
          children: c.title
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "fs-pane",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Toolbar, {
          c: c
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_NewFolderBar.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "fs-browse",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_fileExplorerUi.FileExplorerView, {
            roots: c.explorerRoots,
            fs: _explorerAdapter.explorerFs,
            cwd: c.cwd,
            selectionMode: "single",
            onSelect: c.onSelect,
            onActivate: c.onActivate,
            onNavigate: c.onNavigate,
            layout: "list"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_DialogFooter.default, {})]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_OverwriteConfirm.default, {})]
    })
  });
}
_s(FileSelector, "N+0BYrkW/mGhci3x+pQy54740ws=", false, function () {
  return [_useFileSelector.useFileSelector];
});
_c2 = FileSelector;
var _c, _c2;
$RefreshReg$(_c, "Toolbar");
$RefreshReg$(_c2, "FileSelector");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZmlsZUV4cGxvcmVyVWkiLCJyZXF1aXJlIiwiX3VzZUZpbGVTZWxlY3RvciIsIl9jb250ZXh0IiwiX2V4cGxvcmVyQWRhcHRlciIsIl9EaWFsb2dGb290ZXIiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0ljb24iLCJfTmV3Rm9sZGVyQmFyIiwiX092ZXJ3cml0ZUNvbmZpcm0iLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiVG9vbGJhciIsImMiLCJhbGxvd0NyZWF0ZUZvbGRlciIsImhhc0ZpbHRlcnMiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwib25DbGljayIsInN0YXJ0TmV3Rm9sZGVyIiwibmFtZSIsInNpemUiLCJzdHJva2VXaWR0aCIsImN5Y2xlRmlsdGVyIiwiZmlsdGVyTGFiZWwiLCJfYyIsIkZpbGVTZWxlY3RvciIsInVzZUZpbGVTZWxlY3RvciIsImludmFsaWQiLCJyZWFkeSIsIm1vYmlsZSIsImZvcm1GYWN0b3IiLCJjbGFzcyIsIkZpbGVTZWxlY3RvckNvbnRleHQiLCJQcm92aWRlciIsInZhbHVlIiwic2hvd0JhY2siLCJiYWNrTW9iaWxlIiwidGl0bGUiLCJGaWxlRXhwbG9yZXJWaWV3Iiwicm9vdHMiLCJleHBsb3JlclJvb3RzIiwiZnMiLCJleHBsb3JlckZzIiwiY3dkIiwic2VsZWN0aW9uTW9kZSIsIm9uU2VsZWN0Iiwib25BY3RpdmF0ZSIsIm9uTmF2aWdhdGUiLCJsYXlvdXQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaWxlU2VsZWN0b3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpbGVFeHBsb3JlclZpZXcgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL2ZpbGUtZXhwbG9yZXItdWknO1xuaW1wb3J0ICdAaW1tZWRpYXRlbHktcnVuL2ZpbGUtZXhwbG9yZXItdWkvc3R5bGVzLmNzcyc7XG5pbXBvcnQgeyB1c2VGaWxlU2VsZWN0b3IgfSBmcm9tICcuLi9ob29rcy91c2VGaWxlU2VsZWN0b3InO1xuaW1wb3J0IHsgRmlsZVNlbGVjdG9yQ29udGV4dCB9IGZyb20gJy4uL2xpYi9jb250ZXh0JztcbmltcG9ydCB7IGV4cGxvcmVyRnMgfSBmcm9tICcuLi9saWIvZXhwbG9yZXJBZGFwdGVyJztcbmltcG9ydCBEaWFsb2dGb290ZXIgZnJvbSAnLi9EaWFsb2dGb290ZXInO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcbmltcG9ydCBOZXdGb2xkZXJCYXIgZnJvbSAnLi9OZXdGb2xkZXJCYXInO1xuaW1wb3J0IE92ZXJ3cml0ZUNvbmZpcm0gZnJvbSAnLi9PdmVyd3JpdGVDb25maXJtJztcblxuLy8gVGhlIHRvb2xiYXIgYWJvdmUgdGhlIGJyb3dzZSBhcmVhOiB0aGUgbmV3LWZvbGRlciArIGZpbHRlciBjaHJvbWUgdGhlIGxpYnJhcnlcbi8vIGRvZXNuJ3QgcHJvdmlkZS4gQnJlYWRjcnVtYiArIHJvb3QgbGlzdCArIGVudHJ5IHJvd3MgYXJlIHRoZSBsaWJyYXJ5J3MuXG5mdW5jdGlvbiBUb29sYmFyKHsgYyB9OiB7IGM6IFJldHVyblR5cGU8dHlwZW9mIHVzZUZpbGVTZWxlY3Rvcj4gfSkge1xuICBpZiAoIWMuYWxsb3dDcmVhdGVGb2xkZXIgJiYgIWMuaGFzRmlsdGVycykgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmcy10b29sYmFyXCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJmcy10b29sYmFyLXNwYWNlclwiIC8+XG4gICAgICB7Yy5hbGxvd0NyZWF0ZUZvbGRlciAmJiAoXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImZzLWJ0biBmcy1idG4tcXVpZXQgZnMtdG9vbGJhci1idG5cIiBvbkNsaWNrPXtjLnN0YXJ0TmV3Rm9sZGVyfT5cbiAgICAgICAgICA8SWNvbiBuYW1lPVwiZm9sZGVyUGx1c1wiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43fSAvPlxuICAgICAgICAgIE5ldyBmb2xkZXJcbiAgICAgICAgPC9idXR0b24+XG4gICAgICApfVxuICAgICAge2MuaGFzRmlsdGVycyAmJiAoXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImZzLWJ0biBmcy1idG4tcXVpZXQgZnMtdG9vbGJhci1idG5cIiBvbkNsaWNrPXtjLmN5Y2xlRmlsdGVyfT5cbiAgICAgICAgICB7Yy5maWx0ZXJMYWJlbH1cbiAgICAgICAgICA8SWNvbiBuYW1lPVwiY2hldkRcIiBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRmlsZVNlbGVjdG9yKCkge1xuICBjb25zdCBjID0gdXNlRmlsZVNlbGVjdG9yKCk7XG5cbiAgaWYgKGMuaW52YWxpZCkge1xuICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImZzIGZzLWJsYW5rXCI+Tm8gbG9jYXRpb24gdG8gYnJvd3NlLjwvZGl2PjtcbiAgfVxuICBpZiAoIWMucmVhZHkpIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJmcyBmcy1ibGFua1wiPkxvYWRpbmfigKY8L2Rpdj47XG4gIH1cblxuICBjb25zdCBtb2JpbGUgPSBjLmZvcm1GYWN0b3IuY2xhc3MgPT09ICdtb2JpbGUnO1xuXG4gIHJldHVybiAoXG4gICAgPEZpbGVTZWxlY3RvckNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2N9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BmcyR7bW9iaWxlID8gJyBmcy1tb2JpbGUnIDogJyd9YH0+XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZnMtaGVhZFwiPlxuICAgICAgICAgIHtjLnNob3dCYWNrICYmIChcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImZzLWJhY2tcIiBhcmlhLWxhYmVsPVwiTG9jYXRpb25zXCIgb25DbGljaz17Yy5iYWNrTW9iaWxlfT5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImNoZXZMXCIgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmcy10aXRsZVwiPntjLnRpdGxlfTwvaDE+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtcGFuZVwiPlxuICAgICAgICAgIDxUb29sYmFyIGM9e2N9IC8+XG4gICAgICAgICAgPE5ld0ZvbGRlckJhciAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtYnJvd3NlXCI+XG4gICAgICAgICAgICA8RmlsZUV4cGxvcmVyVmlld1xuICAgICAgICAgICAgICByb290cz17Yy5leHBsb3JlclJvb3RzfVxuICAgICAgICAgICAgICBmcz17ZXhwbG9yZXJGc31cbiAgICAgICAgICAgICAgY3dkPXtjLmN3ZH1cbiAgICAgICAgICAgICAgc2VsZWN0aW9uTW9kZT1cInNpbmdsZVwiXG4gICAgICAgICAgICAgIG9uU2VsZWN0PXtjLm9uU2VsZWN0fVxuICAgICAgICAgICAgICBvbkFjdGl2YXRlPXtjLm9uQWN0aXZhdGV9XG4gICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2Mub25OYXZpZ2F0ZX1cbiAgICAgICAgICAgICAgbGF5b3V0PVwibGlzdFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxEaWFsb2dGb290ZXIgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPE92ZXJ3cml0ZUNvbmZpcm0gLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvRmlsZVNlbGVjdG9yQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsZUFBQSxHQUFBQyxPQUFBO0FBQ0FBLE9BQUE7QUFDQSxJQUFBQyxnQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsZ0JBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGFBQUEsR0FBQUMsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFNLEtBQUEsR0FBQUQsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFPLGFBQUEsR0FBQUYsc0JBQUEsQ0FBQUwsT0FBQTtBQUNBLElBQUFRLGlCQUFBLEdBQUFILHNCQUFBLENBQUFMLE9BQUE7QUFBa0QsSUFBQVMsV0FBQSxHQUFBVCxPQUFBO0FBQUEsSUFBQVUsRUFBQSxHQUFBQyxZQUFBLElBRWxEO0FBQ0E7QUFBQSxTQUFBTix1QkFBQU8sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNBLFNBQVNHLE9BQU9BLENBQUM7RUFBRUM7QUFBNkMsQ0FBQyxFQUFFO0VBQ2pFLElBQUksQ0FBQ0EsQ0FBQyxDQUFDQyxpQkFBaUIsSUFBSSxDQUFDRCxDQUFDLENBQUNFLFVBQVUsRUFBRSxPQUFPLElBQUk7RUFDdEQsb0JBQ0UsSUFBQVQsV0FBQSxDQUFBVSxJQUFBO0lBQUtDLFNBQVMsRUFBQyxZQUFZO0lBQUFDLFFBQUEsZ0JBQ3pCLElBQUFaLFdBQUEsQ0FBQWEsR0FBQTtNQUFNRixTQUFTLEVBQUM7SUFBbUIsQ0FBRSxDQUFDLEVBQ3JDSixDQUFDLENBQUNDLGlCQUFpQixpQkFDbEIsSUFBQVIsV0FBQSxDQUFBVSxJQUFBO01BQVFJLElBQUksRUFBQyxRQUFRO01BQUNILFNBQVMsRUFBQyxvQ0FBb0M7TUFBQ0ksT0FBTyxFQUFFUixDQUFDLENBQUNTLGNBQWU7TUFBQUosUUFBQSxnQkFDN0YsSUFBQVosV0FBQSxDQUFBYSxHQUFBLEVBQUNoQixLQUFBLENBQUFRLE9BQUk7UUFBQ1ksSUFBSSxFQUFDLFlBQVk7UUFBQ0MsSUFBSSxFQUFFLEVBQUc7UUFBQ0MsV0FBVyxFQUFFO01BQUksQ0FBRSxDQUFDLGNBRXhEO0lBQUEsQ0FBUSxDQUNULEVBQ0FaLENBQUMsQ0FBQ0UsVUFBVSxpQkFDWCxJQUFBVCxXQUFBLENBQUFVLElBQUE7TUFBUUksSUFBSSxFQUFDLFFBQVE7TUFBQ0gsU0FBUyxFQUFDLG9DQUFvQztNQUFDSSxPQUFPLEVBQUVSLENBQUMsQ0FBQ2EsV0FBWTtNQUFBUixRQUFBLEdBQ3pGTCxDQUFDLENBQUNjLFdBQVcsZUFDZCxJQUFBckIsV0FBQSxDQUFBYSxHQUFBLEVBQUNoQixLQUFBLENBQUFRLE9BQUk7UUFBQ1ksSUFBSSxFQUFDLE9BQU87UUFBQ0MsSUFBSSxFQUFFLEVBQUc7UUFBQ0MsV0FBVyxFQUFFO01BQUUsQ0FBRSxDQUFDO0lBQUEsQ0FDekMsQ0FDVDtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUNHLEVBQUEsR0FuQlFoQixPQUFPO0FBcUJELFNBQVNpQixZQUFZQSxDQUFBLEVBQUc7RUFBQXRCLEVBQUE7RUFDckMsTUFBTU0sQ0FBQyxHQUFHLElBQUFpQixnQ0FBZSxFQUFDLENBQUM7RUFFM0IsSUFBSWpCLENBQUMsQ0FBQ2tCLE9BQU8sRUFBRTtJQUNiLG9CQUFPLElBQUF6QixXQUFBLENBQUFhLEdBQUE7TUFBS0YsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxFQUFDO0lBQXNCLENBQUssQ0FBQztFQUNsRTtFQUNBLElBQUksQ0FBQ0wsQ0FBQyxDQUFDbUIsS0FBSyxFQUFFO0lBQ1osb0JBQU8sSUFBQTFCLFdBQUEsQ0FBQWEsR0FBQTtNQUFLRixTQUFTLEVBQUMsYUFBYTtNQUFBQyxRQUFBLEVBQUM7SUFBUSxDQUFLLENBQUM7RUFDcEQ7RUFFQSxNQUFNZSxNQUFNLEdBQUdwQixDQUFDLENBQUNxQixVQUFVLENBQUNDLEtBQUssS0FBSyxRQUFRO0VBRTlDLG9CQUNFLElBQUE3QixXQUFBLENBQUFhLEdBQUEsRUFBQ3BCLFFBQUEsQ0FBQXFDLG1CQUFtQixDQUFDQyxRQUFRO0lBQUNDLEtBQUssRUFBRXpCLENBQUU7SUFBQUssUUFBQSxlQUNyQyxJQUFBWixXQUFBLENBQUFVLElBQUE7TUFBS0MsU0FBUyxFQUFFLEtBQUtnQixNQUFNLEdBQUcsWUFBWSxHQUFHLEVBQUUsRUFBRztNQUFBZixRQUFBLGdCQUNoRCxJQUFBWixXQUFBLENBQUFVLElBQUE7UUFBUUMsU0FBUyxFQUFDLFNBQVM7UUFBQUMsUUFBQSxHQUN4QkwsQ0FBQyxDQUFDMEIsUUFBUSxpQkFDVCxJQUFBakMsV0FBQSxDQUFBYSxHQUFBO1VBQVFDLElBQUksRUFBQyxRQUFRO1VBQUNILFNBQVMsRUFBQyxTQUFTO1VBQUMsY0FBVyxXQUFXO1VBQUNJLE9BQU8sRUFBRVIsQ0FBQyxDQUFDMkIsVUFBVztVQUFBdEIsUUFBQSxlQUNyRixJQUFBWixXQUFBLENBQUFhLEdBQUEsRUFBQ2hCLEtBQUEsQ0FBQVEsT0FBSTtZQUFDWSxJQUFJLEVBQUMsT0FBTztZQUFDQyxJQUFJLEVBQUU7VUFBRyxDQUFFO1FBQUMsQ0FDekIsQ0FDVCxlQUNELElBQUFsQixXQUFBLENBQUFhLEdBQUE7VUFBSUYsU0FBUyxFQUFDLFVBQVU7VUFBQUMsUUFBQSxFQUFFTCxDQUFDLENBQUM0QjtRQUFLLENBQUssQ0FBQztNQUFBLENBQ2pDLENBQUMsZUFFVCxJQUFBbkMsV0FBQSxDQUFBVSxJQUFBO1FBQUtDLFNBQVMsRUFBQyxTQUFTO1FBQUFDLFFBQUEsZ0JBQ3RCLElBQUFaLFdBQUEsQ0FBQWEsR0FBQSxFQUFDUCxPQUFPO1VBQUNDLENBQUMsRUFBRUE7UUFBRSxDQUFFLENBQUMsZUFDakIsSUFBQVAsV0FBQSxDQUFBYSxHQUFBLEVBQUNmLGFBQUEsQ0FBQU8sT0FBWSxJQUFFLENBQUMsZUFDaEIsSUFBQUwsV0FBQSxDQUFBYSxHQUFBO1VBQUtGLFNBQVMsRUFBQyxXQUFXO1VBQUFDLFFBQUEsZUFDeEIsSUFBQVosV0FBQSxDQUFBYSxHQUFBLEVBQUN2QixlQUFBLENBQUE4QyxnQkFBZ0I7WUFDZkMsS0FBSyxFQUFFOUIsQ0FBQyxDQUFDK0IsYUFBYztZQUN2QkMsRUFBRSxFQUFFQywyQkFBVztZQUNmQyxHQUFHLEVBQUVsQyxDQUFDLENBQUNrQyxHQUFJO1lBQ1hDLGFBQWEsRUFBQyxRQUFRO1lBQ3RCQyxRQUFRLEVBQUVwQyxDQUFDLENBQUNvQyxRQUFTO1lBQ3JCQyxVQUFVLEVBQUVyQyxDQUFDLENBQUNxQyxVQUFXO1lBQ3pCQyxVQUFVLEVBQUV0QyxDQUFDLENBQUNzQyxVQUFXO1lBQ3pCQyxNQUFNLEVBQUM7VUFBTSxDQUNkO1FBQUMsQ0FDQyxDQUFDLGVBQ04sSUFBQTlDLFdBQUEsQ0FBQWEsR0FBQSxFQUFDbEIsYUFBQSxDQUFBVSxPQUFZLElBQUUsQ0FBQztNQUFBLENBQ2IsQ0FBQyxlQUVOLElBQUFMLFdBQUEsQ0FBQWEsR0FBQSxFQUFDZCxpQkFBQSxDQUFBTSxPQUFnQixJQUFFLENBQUM7SUFBQSxDQUNqQjtFQUFDLENBQ3NCLENBQUM7QUFFbkM7QUFBQ0osRUFBQSxDQTlDdUJzQixZQUFZO0VBQUEsUUFDeEJDLGdDQUFlO0FBQUE7QUFBQXVCLEdBQUEsR0FESHhCLFlBQVk7QUFBQSxJQUFBRCxFQUFBLEVBQUF5QixHQUFBO0FBQUFDLFlBQUEsQ0FBQTFCLEVBQUE7QUFBQTBCLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}