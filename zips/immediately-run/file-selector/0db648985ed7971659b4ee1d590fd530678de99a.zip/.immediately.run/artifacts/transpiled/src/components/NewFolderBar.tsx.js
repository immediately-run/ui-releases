var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = NewFolderBar;
var _context = require("../lib/context");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The inline "new folder" name editor (picker chrome). Shown above the library's
// browse area when the user starts a new folder; on submit the controller calls
// `fs.makeDir` and drops the library into the new directory.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function NewFolderBar() {
  _s();
  const c = (0, _context.useController)();
  if (c.newFolderName == null) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "fs-newfolder",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: "folderPlus",
      size: 18,
      strokeWidth: 1.7,
      className: "fs-newfolder-ico"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
      autoFocus: true,
      className: "fs-newfolder-input",
      value: c.newFolderName,
      placeholder: "New folder name",
      "aria-label": "New folder name",
      onChange: e => c.setNewFolderName(e.target.value),
      onKeyDown: e => {
        if (e.key === 'Enter') c.submitNewFolder();
        if (e.key === 'Escape') c.cancelNewFolder();
      }
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "fs-btn fs-btn-quiet",
      onClick: c.cancelNewFolder,
      children: "Cancel"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "fs-btn fs-btn-create",
      disabled: c.busy,
      onClick: c.submitNewFolder,
      children: "Create"
    })]
  });
}
_s(NewFolderBar, "EpRKP5YlLygKruAQ/BiYBiBA7QE=", false, function () {
  return [_context.useController];
});
_c = NewFolderBar;
var _c;
$RefreshReg$(_c, "NewFolderBar");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29udGV4dCIsInJlcXVpcmUiLCJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiTmV3Rm9sZGVyQmFyIiwiYyIsInVzZUNvbnRyb2xsZXIiLCJuZXdGb2xkZXJOYW1lIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwibmFtZSIsInNpemUiLCJzdHJva2VXaWR0aCIsImF1dG9Gb2N1cyIsInZhbHVlIiwicGxhY2Vob2xkZXIiLCJvbkNoYW5nZSIsInNldE5ld0ZvbGRlck5hbWUiLCJ0YXJnZXQiLCJvbktleURvd24iLCJrZXkiLCJzdWJtaXROZXdGb2xkZXIiLCJjYW5jZWxOZXdGb2xkZXIiLCJ0eXBlIiwib25DbGljayIsImRpc2FibGVkIiwiYnVzeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTmV3Rm9sZGVyQmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb250cm9sbGVyIH0gZnJvbSAnLi4vbGliL2NvbnRleHQnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuLy8gVGhlIGlubGluZSBcIm5ldyBmb2xkZXJcIiBuYW1lIGVkaXRvciAocGlja2VyIGNocm9tZSkuIFNob3duIGFib3ZlIHRoZSBsaWJyYXJ5J3Ncbi8vIGJyb3dzZSBhcmVhIHdoZW4gdGhlIHVzZXIgc3RhcnRzIGEgbmV3IGZvbGRlcjsgb24gc3VibWl0IHRoZSBjb250cm9sbGVyIGNhbGxzXG4vLyBgZnMubWFrZURpcmAgYW5kIGRyb3BzIHRoZSBsaWJyYXJ5IGludG8gdGhlIG5ldyBkaXJlY3RvcnkuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOZXdGb2xkZXJCYXIoKSB7XG4gIGNvbnN0IGMgPSB1c2VDb250cm9sbGVyKCk7XG4gIGlmIChjLm5ld0ZvbGRlck5hbWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmcy1uZXdmb2xkZXJcIj5cbiAgICAgIDxJY29uIG5hbWU9XCJmb2xkZXJQbHVzXCIgc2l6ZT17MTh9IHN0cm9rZVdpZHRoPXsxLjd9IGNsYXNzTmFtZT1cImZzLW5ld2ZvbGRlci1pY29cIiAvPlxuICAgICAgPGlucHV0XG4gICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICBjbGFzc05hbWU9XCJmcy1uZXdmb2xkZXItaW5wdXRcIlxuICAgICAgICB2YWx1ZT17Yy5uZXdGb2xkZXJOYW1lfVxuICAgICAgICBwbGFjZWhvbGRlcj1cIk5ldyBmb2xkZXIgbmFtZVwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJOZXcgZm9sZGVyIG5hbWVcIlxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IGMuc2V0TmV3Rm9sZGVyTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicpIGMuc3VibWl0TmV3Rm9sZGVyKCk7XG4gICAgICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykgYy5jYW5jZWxOZXdGb2xkZXIoKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJmcy1idG4gZnMtYnRuLXF1aWV0XCIgb25DbGljaz17Yy5jYW5jZWxOZXdGb2xkZXJ9PlxuICAgICAgICBDYW5jZWxcbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZnMtYnRuIGZzLWJ0bi1jcmVhdGVcIiBkaXNhYmxlZD17Yy5idXN5fSBvbkNsaWNrPXtjLnN1Ym1pdE5ld0ZvbGRlcn0+XG4gICAgICAgIENyZWF0ZVxuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLFFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUEwQixJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUFFMUI7QUFDQTtBQUNBO0FBQUEsU0FBQUgsdUJBQUFJLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFDZSxTQUFTRyxZQUFZQSxDQUFBLEVBQUc7RUFBQUwsRUFBQTtFQUNyQyxNQUFNTSxDQUFDLEdBQUcsSUFBQUMsc0JBQWEsRUFBQyxDQUFDO0VBQ3pCLElBQUlELENBQUMsQ0FBQ0UsYUFBYSxJQUFJLElBQUksRUFBRSxPQUFPLElBQUk7RUFDeEMsb0JBQ0UsSUFBQVQsV0FBQSxDQUFBVSxJQUFBO0lBQUtDLFNBQVMsRUFBQyxjQUFjO0lBQUFDLFFBQUEsZ0JBQzNCLElBQUFaLFdBQUEsQ0FBQWEsR0FBQSxFQUFDZixLQUFBLENBQUFPLE9BQUk7TUFBQ1MsSUFBSSxFQUFDLFlBQVk7TUFBQ0MsSUFBSSxFQUFFLEVBQUc7TUFBQ0MsV0FBVyxFQUFFLEdBQUk7TUFBQ0wsU0FBUyxFQUFDO0lBQWtCLENBQUUsQ0FBQyxlQUNuRixJQUFBWCxXQUFBLENBQUFhLEdBQUE7TUFDRUksU0FBUztNQUNUTixTQUFTLEVBQUMsb0JBQW9CO01BQzlCTyxLQUFLLEVBQUVYLENBQUMsQ0FBQ0UsYUFBYztNQUN2QlUsV0FBVyxFQUFDLGlCQUFpQjtNQUM3QixjQUFXLGlCQUFpQjtNQUM1QkMsUUFBUSxFQUFHakIsQ0FBQyxJQUFLSSxDQUFDLENBQUNjLGdCQUFnQixDQUFDbEIsQ0FBQyxDQUFDbUIsTUFBTSxDQUFDSixLQUFLLENBQUU7TUFDcERLLFNBQVMsRUFBR3BCLENBQUMsSUFBSztRQUNoQixJQUFJQSxDQUFDLENBQUNxQixHQUFHLEtBQUssT0FBTyxFQUFFakIsQ0FBQyxDQUFDa0IsZUFBZSxDQUFDLENBQUM7UUFDMUMsSUFBSXRCLENBQUMsQ0FBQ3FCLEdBQUcsS0FBSyxRQUFRLEVBQUVqQixDQUFDLENBQUNtQixlQUFlLENBQUMsQ0FBQztNQUM3QztJQUFFLENBQ0gsQ0FBQyxlQUNGLElBQUExQixXQUFBLENBQUFhLEdBQUE7TUFBUWMsSUFBSSxFQUFDLFFBQVE7TUFBQ2hCLFNBQVMsRUFBQyxxQkFBcUI7TUFBQ2lCLE9BQU8sRUFBRXJCLENBQUMsQ0FBQ21CLGVBQWdCO01BQUFkLFFBQUEsRUFBQztJQUVsRixDQUFRLENBQUMsZUFDVCxJQUFBWixXQUFBLENBQUFhLEdBQUE7TUFBUWMsSUFBSSxFQUFDLFFBQVE7TUFBQ2hCLFNBQVMsRUFBQyxzQkFBc0I7TUFBQ2tCLFFBQVEsRUFBRXRCLENBQUMsQ0FBQ3VCLElBQUs7TUFBQ0YsT0FBTyxFQUFFckIsQ0FBQyxDQUFDa0IsZUFBZ0I7TUFBQWIsUUFBQSxFQUFDO0lBRXJHLENBQVEsQ0FBQztFQUFBLENBQ04sQ0FBQztBQUVWO0FBQUNYLEVBQUEsQ0ExQnVCSyxZQUFZO0VBQUEsUUFDeEJFLHNCQUFhO0FBQUE7QUFBQXVCLEVBQUEsR0FERHpCLFlBQVk7QUFBQSxJQUFBeUIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}