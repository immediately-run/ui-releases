"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFileSelector = useFileSelector;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _fs = require("../fs");
var _explorerAdapter = require("../lib/explorerAdapter");
var _paths = require("../lib/paths");
// The pick-file controller (PICK_FILE_TASK_SPEC.md §3). Reads `useTaskInput()`,
// then hands the whole browse experience (entry list, breadcrumb, folder tree,
// root list, navigation) to the shared `@immediately-run/file-explorer-ui`
// `FileExplorerView`. This controller keeps only the PICKER CHROME: mode/params
// parse, the Open/Cancel footer, save-name, ext filters, new-folder, overwrite
// confirm, mobile framing, and the `completeTask()` / `cancelTask()` mapping to
// the `{ root, relPath, created? }` result. It holds NO standing authority — the
// delegated chroots ARE its world. Hooks live here (not in a component file) to
// satisfy the Fast Refresh rule.

const isMode = v => v === 'open-file' || v === 'open-folder' || v === 'save-file';
function parseFilters(v) {
  if (!Array.isArray(v)) return undefined;
  const out = [];
  for (const f of v) {
    const o = f;
    if (typeof o?.label === 'string' && Array.isArray(o.extensions)) {
      out.push({
        label: o.label,
        extensions: o.extensions.filter(e => typeof e === 'string')
      });
    }
  }
  return out.length ? out : undefined;
}

/** Validate the (host-rewritten) callee params; null ⇒ caller bug ⇒ cancel. */
function parseParams(raw) {
  if (!raw) return null;
  const roots = raw.roots;
  if (!Array.isArray(roots) || roots.length === 0) return null;
  if (!roots.every(r => typeof r === 'string' && r.length > 0)) return null;
  if (!isMode(raw.mode)) return null;
  const startInRaw = raw.startIn;
  const startIn = startInRaw && typeof startInRaw.root === 'number' && startInRaw.root >= 0 && startInRaw.root < roots.length && typeof startInRaw.relPath === 'string' ? {
    root: startInRaw.root,
    relPath: startInRaw.relPath
  } : undefined;
  return {
    mode: raw.mode,
    roots: roots,
    rootLabels: Array.isArray(raw.rootLabels) ? raw.rootLabels.map(String) : undefined,
    rootModes: Array.isArray(raw.rootModes) ? raw.rootModes.map(m => m === 'ro' ? 'ro' : 'rw') : undefined,
    title: typeof raw.title === 'string' ? raw.title : undefined,
    filters: parseFilters(raw.filters),
    defaultName: typeof raw.defaultName === 'string' ? raw.defaultName : undefined,
    startIn,
    allowCreateFolder: typeof raw.allowCreateFolder === 'boolean' ? raw.allowCreateFolder : undefined
  };
}

/** The file the user has highlighted (via the library's `onSelect`), if any. */

function useFileSelector() {
  const input = (0, _sdk.useTaskInput)();
  const formFactor = (0, _sdk.useFormFactor)();
  const [params, setParams] = (0, _react.useState)(null);
  const [invalid, setInvalid] = (0, _react.useState)(false);
  // The current directory the library is browsing (absolute chroot path), or null
  // for the synthetic roots-root (the library's root list). Controlled so we know
  // the save destination / new-folder target / overwrite scope at all times.
  const [cwd, setCwd] = (0, _react.useState)(null);
  const [sel, setSel] = (0, _react.useState)(null);
  const [filterIdx, setFilterIdx] = (0, _react.useState)(0);
  const [saveName, setSaveName] = (0, _react.useState)('');
  const [newFolderName, setNewFolderName] = (0, _react.useState)(null);
  const [overwrite, setOverwrite] = (0, _react.useState)(null);
  const [busy, setBusy] = (0, _react.useState)(false);
  const [error, setError] = (0, _react.useState)(null);
  const createdPaths = (0, _react.useRef)(new Set());

  // ── init from task input (once) ──────────────────────────────────────────
  (0, _react.useEffect)(() => {
    if (!input || params || invalid) return;
    const parsed = parseParams(input.params);
    if (!parsed) {
      // Caller bug (zero/garbled roots) — dismiss immediately (spec §3).
      setInvalid(true);
      (0, _sdk.cancelTask)();
      return;
    }
    setParams(parsed);
    setSaveName(parsed.defaultName ?? '');
    if (parsed.startIn) {
      const base = parsed.roots[parsed.startIn.root];
      setCwd((0, _paths.joinPath)(base, ...(0, _paths.segsOf)(parsed.startIn.relPath)));
    }
  }, [input, params, invalid]);
  const roots = (0, _react.useMemo)(() => {
    if (!params) return [];
    return params.roots.map((p, i) => ({
      path: p,
      label: params.rootLabels?.[i] ?? `Location ${i + 1}`,
      mode: params.rootModes?.[i] ?? 'rw'
    }));
  }, [params]);
  const explorerRoots = (0, _react.useMemo)(() => (0, _explorerAdapter.toExplorerRoots)(roots), [roots]);
  const mode = params?.mode ?? 'open-file';
  const isSave = mode === 'save-file';
  const filters = params?.filters ?? [];
  const hasFilters = mode === 'open-file' && filters.length > 0;
  const activeFilter = hasFilters ? filters[filterIdx] ?? filters[0] : null;

  // The root that owns the current directory (null at the roots-root). Its index
  // is the `root` field of the returned result; its writability gates create/save.
  const curRootIdx = (0, _react.useMemo)(() => {
    if (!cwd) return null;
    const i = roots.findIndex(r => cwd === r.path || cwd.startsWith(r.path + '/'));
    return i >= 0 ? i : null;
  }, [cwd, roots]);
  const curRoot = curRootIdx != null ? roots[curRootIdx] : null;
  const destWritable = !!curRoot && curRoot.mode === 'rw';
  const allowCreateFolder = (params?.allowCreateFolder ?? mode === 'save-file') && !!cwd && destWritable;
  const matchesFilter = (0, _react.useCallback)(name => activeFilter ? (0, _paths.matchesExt)(name, activeFilter.extensions) : true, [activeFilter]);

  // ── library callbacks ────────────────────────────────────────────────────
  // `onNavigate` fires from the library's flat list when the browsed directory
  // changes (breadcrumb / opening a folder / opening a root). Adopt it as our
  // controlled cwd — this is the save destination / open-folder choice / the
  // new-folder target. `onActivate(dir)` reports the same transition, so keeping
  // both in sync is idempotent.
  const onNavigate = (0, _react.useCallback)((root, relPath) => {
    const rel = (0, _explorerAdapter.cleanRel)(relPath);
    setCwd(rel ? (0, _paths.joinPath)(root.path, ...(0, _paths.segsOf)(rel)) : root.path);
    setSel(null);
    setNewFolderName(null);
  }, []);

  // `onActivate` fires for both a directory (the library navigates into it and
  // reports the NEW directory) and a file (a click/Enter). For directories we
  // adopt the new cwd; for files we record the highlight (save-file also fills the
  // name field). We never auto-complete here — the footer's primary button is the
  // single commit path, so filter/writability gating stays meaningful.
  const onActivate = (0, _react.useCallback)((root, relPath, isDir) => {
    setError(null);
    if (isDir) {
      const rel = (0, _explorerAdapter.cleanRel)(relPath);
      setCwd(rel ? (0, _paths.joinPath)(root.path, ...(0, _paths.segsOf)(rel)) : root.path);
      setSel(null);
      setNewFolderName(null);
      return;
    }
    const rel = (0, _explorerAdapter.cleanRel)(relPath);
    const name = (0, _paths.segsOf)(rel).pop() ?? rel;
    setSel({
      rootIdx: (0, _explorerAdapter.rootIndexOf)(root),
      rel,
      name
    });
    if (isSave) setSaveName(name);
  }, [isSave]);

  // The library's single-cursor highlight. Same effect as a file activation's
  // highlight; directories don't fire `onSelect`.
  const onSelect = (0, _react.useCallback)((root, relPath) => {
    setError(null);
    const rel = (0, _explorerAdapter.cleanRel)(relPath);
    const name = (0, _paths.segsOf)(rel).pop() ?? rel;
    setSel({
      rootIdx: (0, _explorerAdapter.rootIndexOf)(root),
      rel,
      name
    });
    if (isSave) setSaveName(name);
  }, [isSave]);

  // ── filters ──────────────────────────────────────────────────────────────
  const cycleFilter = (0, _react.useCallback)(() => {
    setFilterIdx(i => (i + 1) % Math.max(1, filters.length));
    setSel(null);
  }, [filters.length]);

  // ── result mapping ─────────────────────────────────────────────────────────
  const finish = (0, _react.useCallback)((rootIdx, rel, created) => {
    if (!(0, _paths.isSafeRel)(rel)) {
      setError('That name is not allowed.');
      return;
    }
    const result = {
      root: rootIdx,
      relPath: rel
    };
    if (created) result.created = true;
    (0, _sdk.completeTask)(result);
  }, []);
  const cancel = (0, _react.useCallback)(() => (0, _sdk.cancelTask)(), []);

  // ── new folder ─────────────────────────────────────────────────────────────
  const startNewFolder = (0, _react.useCallback)(() => {
    if (!allowCreateFolder) return;
    setNewFolderName('');
  }, [allowCreateFolder]);
  const cancelNewFolder = (0, _react.useCallback)(() => setNewFolderName(null), []);
  const submitNewFolder = (0, _react.useCallback)(async () => {
    if (newFolderName == null || !cwd || curRoot == null) return;
    const name = newFolderName.trim();
    if (!name || name.includes('/') || name.includes('\\') || name === '.' || name === '..') {
      setError('Invalid folder name.');
      return;
    }
    setBusy(true);
    setError(null);
    const abs = (0, _paths.joinPath)(cwd, name);
    try {
      await (0, _fs.makeDir)(abs);
      createdPaths.current.add(abs);
      setNewFolderName(null);
      // Drop into the new folder (save-file) / make it the browsed dir; the
      // library re-reads this directory on its next render.
      setCwd(abs);
      setSel(null);
    } catch (err) {
      // A forced create against a `ro` chroot lands here as EROFS — never data loss.
      setError(`Couldn't create folder: ${err?.message ?? 'read-only'}.`);
    } finally {
      setBusy(false);
    }
  }, [newFolderName, cwd, curRoot]);

  // ── confirm (the footer's primary button) ───────────────────────────────────
  const confirm = (0, _react.useCallback)(() => {
    if (!params) return;
    if (isSave) {
      const name = saveName.trim();
      if (!name || !cwd || curRootIdx == null || !destWritable) return;
      const relSegs = curRoot ? (0, _paths.segsOf)(cwd.slice(curRoot.path.length)).concat(name) : [name];
      const rel = relSegs.join('/');
      // Overwrite confirm: check the current directory for a same-named file.
      (0, _fs.listDir)(cwd).then(entries => {
        const exists = entries.some(e => !e.isDir && e.name === name);
        if (exists && overwrite !== name) {
          setOverwrite(name);
          return;
        }
        finish(curRootIdx, rel, !exists);
      }).catch(() => {
        // Can't stat the dir — attempt the save; the host is the real boundary.
        finish(curRootIdx, rel, false);
      });
      return;
    }
    if (mode === 'open-folder') {
      // The chosen folder is the current directory (the library navigates into
      // folders; you drill to the one you want, then Choose folder).
      if (!cwd || curRootIdx == null || !curRoot) return;
      const rel = (0, _paths.segsOf)(cwd.slice(curRoot.path.length)).join('/');
      if (rel.length === 0) return; // can't return the root itself (empty relPath)
      const abs = (0, _paths.joinPath)(curRoot.path, ...(0, _paths.segsOf)(rel));
      finish(curRootIdx, rel, createdPaths.current.has(abs));
      return;
    }
    // open-file — a highlighted, filter-matching file.
    if (!sel) return;
    if (!matchesFilter(sel.name)) return;
    finish(sel.rootIdx, sel.rel, false);
  }, [params, isSave, saveName, cwd, curRootIdx, curRoot, destWritable, overwrite, finish, mode, sel, matchesFilter]);
  const doOverwrite = (0, _react.useCallback)(() => {
    if (overwrite == null || !cwd || curRootIdx == null || !curRoot) return;
    const name = overwrite;
    setOverwrite(null);
    const rel = (0, _paths.segsOf)(cwd.slice(curRoot.path.length)).concat(name).join('/');
    finish(curRootIdx, rel, false);
  }, [overwrite, cwd, curRootIdx, curRoot, finish]);
  const cancelOverwrite = (0, _react.useCallback)(() => setOverwrite(null), []);

  // ── footer state ─────────────────────────────────────────────────────────
  const primaryLabel = mode === 'open-file' ? 'Open' : mode === 'open-folder' ? 'Choose folder' : 'Save';
  const canConfirm = (0, _react.useMemo)(() => {
    if (isSave) return destWritable && saveName.trim().length > 0;
    if (mode === 'open-folder') return curRootIdx != null && !!cwd && cwd !== curRoot?.path;
    // open-file: a highlighted file that matches the active filter.
    return !!sel && matchesFilter(sel.name);
  }, [isSave, destWritable, saveName, mode, curRootIdx, cwd, curRoot, sel, matchesFilter]);
  const selectionLabel = (0, _react.useMemo)(() => {
    if (error) return error;
    const label = curRoot?.label ?? (sel != null ? roots[sel.rootIdx]?.label : undefined);
    if (isSave) {
      const dirRel = curRoot && cwd ? (0, _paths.segsOf)(cwd.slice(curRoot.path.length)).join('/') : '';
      const full = [dirRel, saveName].filter(Boolean).join('/');
      if (!full || !label) return 'Choose a folder and file name.';
      return `${label} / ${full}`;
    }
    if (mode === 'open-folder') {
      const rel = curRoot && cwd ? (0, _paths.segsOf)(cwd.slice(curRoot.path.length)).join('/') : '';
      if (!rel || !label) return 'Open a folder to choose it.';
      return `${label} / ${rel}`;
    }
    if (!sel) return 'Select a file.';
    return `${roots[sel.rootIdx]?.label ?? ''} / ${sel.rel}`;
  }, [error, curRoot, cwd, isSave, saveName, mode, sel, roots]);

  // ── "back to locations" ────────────────────────────────────────────────
  // The library's list drills DOWN via its own breadcrumb, but under a CONTROLLED
  // `cwd` its "roots-root" breadcrumb link can't report the null transition back to
  // us (library gap — see report). We own that affordance instead: a header Back
  // button that returns to the root list (`cwd = null`), so multi-root switching
  // works on every form factor. Shown whenever we're inside a root.
  const showBack = cwd != null;
  const backMobile = (0, _react.useCallback)(() => {
    setCwd(null);
    setSel(null);
    setNewFolderName(null);
  }, []);
  return {
    ready: !!params,
    invalid,
    formFactor,
    mode,
    title: params?.title ?? (mode === 'save-file' ? 'Save file' : mode === 'open-folder' ? 'Choose folder' : 'Open file'),
    isSave,
    hasFilters,
    filterLabel: activeFilter?.label ?? 'All files',
    cycleFilter,
    allowCreateFolder,
    roots,
    explorerRoots,
    cwd,
    onNavigate,
    onSelect,
    onActivate,
    newFolderName,
    setNewFolderName,
    startNewFolder,
    submitNewFolder,
    cancelNewFolder,
    saveName,
    setSaveName,
    overwrite,
    doOverwrite,
    cancelOverwrite,
    canConfirm,
    primaryLabel,
    selectionLabel,
    confirm,
    cancel,
    busy,
    error,
    showBack,
    backMobile
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9mcyIsIl9leHBsb3JlckFkYXB0ZXIiLCJfcGF0aHMiLCJpc01vZGUiLCJ2IiwicGFyc2VGaWx0ZXJzIiwiQXJyYXkiLCJpc0FycmF5IiwidW5kZWZpbmVkIiwib3V0IiwiZiIsIm8iLCJsYWJlbCIsImV4dGVuc2lvbnMiLCJwdXNoIiwiZmlsdGVyIiwiZSIsImxlbmd0aCIsInBhcnNlUGFyYW1zIiwicmF3Iiwicm9vdHMiLCJldmVyeSIsInIiLCJtb2RlIiwic3RhcnRJblJhdyIsInN0YXJ0SW4iLCJyb290IiwicmVsUGF0aCIsInJvb3RMYWJlbHMiLCJtYXAiLCJTdHJpbmciLCJyb290TW9kZXMiLCJtIiwidGl0bGUiLCJmaWx0ZXJzIiwiZGVmYXVsdE5hbWUiLCJhbGxvd0NyZWF0ZUZvbGRlciIsInVzZUZpbGVTZWxlY3RvciIsImlucHV0IiwidXNlVGFza0lucHV0IiwiZm9ybUZhY3RvciIsInVzZUZvcm1GYWN0b3IiLCJwYXJhbXMiLCJzZXRQYXJhbXMiLCJ1c2VTdGF0ZSIsImludmFsaWQiLCJzZXRJbnZhbGlkIiwiY3dkIiwic2V0Q3dkIiwic2VsIiwic2V0U2VsIiwiZmlsdGVySWR4Iiwic2V0RmlsdGVySWR4Iiwic2F2ZU5hbWUiLCJzZXRTYXZlTmFtZSIsIm5ld0ZvbGRlck5hbWUiLCJzZXROZXdGb2xkZXJOYW1lIiwib3ZlcndyaXRlIiwic2V0T3ZlcndyaXRlIiwiYnVzeSIsInNldEJ1c3kiLCJlcnJvciIsInNldEVycm9yIiwiY3JlYXRlZFBhdGhzIiwidXNlUmVmIiwiU2V0IiwidXNlRWZmZWN0IiwicGFyc2VkIiwiY2FuY2VsVGFzayIsImJhc2UiLCJqb2luUGF0aCIsInNlZ3NPZiIsInVzZU1lbW8iLCJwIiwiaSIsInBhdGgiLCJleHBsb3JlclJvb3RzIiwidG9FeHBsb3JlclJvb3RzIiwiaXNTYXZlIiwiaGFzRmlsdGVycyIsImFjdGl2ZUZpbHRlciIsImN1clJvb3RJZHgiLCJmaW5kSW5kZXgiLCJzdGFydHNXaXRoIiwiY3VyUm9vdCIsImRlc3RXcml0YWJsZSIsIm1hdGNoZXNGaWx0ZXIiLCJ1c2VDYWxsYmFjayIsIm5hbWUiLCJtYXRjaGVzRXh0Iiwib25OYXZpZ2F0ZSIsInJlbCIsImNsZWFuUmVsIiwib25BY3RpdmF0ZSIsImlzRGlyIiwicG9wIiwicm9vdElkeCIsInJvb3RJbmRleE9mIiwib25TZWxlY3QiLCJjeWNsZUZpbHRlciIsIk1hdGgiLCJtYXgiLCJmaW5pc2giLCJjcmVhdGVkIiwiaXNTYWZlUmVsIiwicmVzdWx0IiwiY29tcGxldGVUYXNrIiwiY2FuY2VsIiwic3RhcnROZXdGb2xkZXIiLCJjYW5jZWxOZXdGb2xkZXIiLCJzdWJtaXROZXdGb2xkZXIiLCJ0cmltIiwiaW5jbHVkZXMiLCJhYnMiLCJtYWtlRGlyIiwiY3VycmVudCIsImFkZCIsImVyciIsIm1lc3NhZ2UiLCJjb25maXJtIiwicmVsU2VncyIsInNsaWNlIiwiY29uY2F0Iiwiam9pbiIsImxpc3REaXIiLCJ0aGVuIiwiZW50cmllcyIsImV4aXN0cyIsInNvbWUiLCJjYXRjaCIsImhhcyIsImRvT3ZlcndyaXRlIiwiY2FuY2VsT3ZlcndyaXRlIiwicHJpbWFyeUxhYmVsIiwiY2FuQ29uZmlybSIsInNlbGVjdGlvbkxhYmVsIiwiZGlyUmVsIiwiZnVsbCIsIkJvb2xlYW4iLCJzaG93QmFjayIsImJhY2tNb2JpbGUiLCJyZWFkeSIsImZpbHRlckxhYmVsIl0sInNvdXJjZXMiOlsidXNlRmlsZVNlbGVjdG9yLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBwaWNrLWZpbGUgY29udHJvbGxlciAoUElDS19GSUxFX1RBU0tfU1BFQy5tZCDCpzMpLiBSZWFkcyBgdXNlVGFza0lucHV0KClgLFxuLy8gdGhlbiBoYW5kcyB0aGUgd2hvbGUgYnJvd3NlIGV4cGVyaWVuY2UgKGVudHJ5IGxpc3QsIGJyZWFkY3J1bWIsIGZvbGRlciB0cmVlLFxuLy8gcm9vdCBsaXN0LCBuYXZpZ2F0aW9uKSB0byB0aGUgc2hhcmVkIGBAaW1tZWRpYXRlbHktcnVuL2ZpbGUtZXhwbG9yZXItdWlgXG4vLyBgRmlsZUV4cGxvcmVyVmlld2AuIFRoaXMgY29udHJvbGxlciBrZWVwcyBvbmx5IHRoZSBQSUNLRVIgQ0hST01FOiBtb2RlL3BhcmFtc1xuLy8gcGFyc2UsIHRoZSBPcGVuL0NhbmNlbCBmb290ZXIsIHNhdmUtbmFtZSwgZXh0IGZpbHRlcnMsIG5ldy1mb2xkZXIsIG92ZXJ3cml0ZVxuLy8gY29uZmlybSwgbW9iaWxlIGZyYW1pbmcsIGFuZCB0aGUgYGNvbXBsZXRlVGFzaygpYCAvIGBjYW5jZWxUYXNrKClgIG1hcHBpbmcgdG9cbi8vIHRoZSBgeyByb290LCByZWxQYXRoLCBjcmVhdGVkPyB9YCByZXN1bHQuIEl0IGhvbGRzIE5PIHN0YW5kaW5nIGF1dGhvcml0eSDigJQgdGhlXG4vLyBkZWxlZ2F0ZWQgY2hyb290cyBBUkUgaXRzIHdvcmxkLiBIb29rcyBsaXZlIGhlcmUgKG5vdCBpbiBhIGNvbXBvbmVudCBmaWxlKSB0b1xuLy8gc2F0aXNmeSB0aGUgRmFzdCBSZWZyZXNoIHJ1bGUuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgY2FuY2VsVGFzayxcbiAgY29tcGxldGVUYXNrLFxuICB1c2VGb3JtRmFjdG9yLFxuICB1c2VUYXNrSW5wdXQsXG4gIHR5cGUgRm9ybUZhY3Rvcixcbn0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHR5cGUgeyBFeHBsb3JlclJvb3QgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL2ZpbGUtZXhwbG9yZXItdWknO1xuaW1wb3J0IHsgbGlzdERpciwgbWFrZURpciB9IGZyb20gJy4uL2ZzJztcbmltcG9ydCB7IGNsZWFuUmVsLCByb290SW5kZXhPZiwgdG9FeHBsb3JlclJvb3RzIH0gZnJvbSAnLi4vbGliL2V4cGxvcmVyQWRhcHRlcic7XG5pbXBvcnQgeyBpc1NhZmVSZWwsIGpvaW5QYXRoLCBtYXRjaGVzRXh0LCBzZWdzT2YgfSBmcm9tICcuLi9saWIvcGF0aHMnO1xuaW1wb3J0IHR5cGUgeyBDYWxsZWVQYXJhbXMsIFBpY2tGaWx0ZXIsIFBpY2tGaWxlUmVzdWx0LCBQaWNrTW9kZSwgUm9vdEluZm8gfSBmcm9tICcuLi9saWIvdHlwZXMnO1xuXG5jb25zdCBpc01vZGUgPSAodjogdW5rbm93bik6IHYgaXMgUGlja01vZGUgPT5cbiAgdiA9PT0gJ29wZW4tZmlsZScgfHwgdiA9PT0gJ29wZW4tZm9sZGVyJyB8fCB2ID09PSAnc2F2ZS1maWxlJztcblxuZnVuY3Rpb24gcGFyc2VGaWx0ZXJzKHY6IHVua25vd24pOiBQaWNrRmlsdGVyW10gfCB1bmRlZmluZWQge1xuICBpZiAoIUFycmF5LmlzQXJyYXkodikpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IG91dDogUGlja0ZpbHRlcltdID0gW107XG4gIGZvciAoY29uc3QgZiBvZiB2KSB7XG4gICAgY29uc3QgbyA9IGYgYXMgeyBsYWJlbD86IHVua25vd247IGV4dGVuc2lvbnM/OiB1bmtub3duIH07XG4gICAgaWYgKHR5cGVvZiBvPy5sYWJlbCA9PT0gJ3N0cmluZycgJiYgQXJyYXkuaXNBcnJheShvLmV4dGVuc2lvbnMpKSB7XG4gICAgICBvdXQucHVzaCh7IGxhYmVsOiBvLmxhYmVsLCBleHRlbnNpb25zOiBvLmV4dGVuc2lvbnMuZmlsdGVyKChlKSA9PiB0eXBlb2YgZSA9PT0gJ3N0cmluZycpIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0Lmxlbmd0aCA/IG91dCA6IHVuZGVmaW5lZDtcbn1cblxuLyoqIFZhbGlkYXRlIHRoZSAoaG9zdC1yZXdyaXR0ZW4pIGNhbGxlZSBwYXJhbXM7IG51bGwg4oeSIGNhbGxlciBidWcg4oeSIGNhbmNlbC4gKi9cbmZ1bmN0aW9uIHBhcnNlUGFyYW1zKHJhdzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCB1bmRlZmluZWQpOiBDYWxsZWVQYXJhbXMgfCBudWxsIHtcbiAgaWYgKCFyYXcpIHJldHVybiBudWxsO1xuICBjb25zdCByb290cyA9IHJhdy5yb290cztcbiAgaWYgKCFBcnJheS5pc0FycmF5KHJvb3RzKSB8fCByb290cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuICBpZiAoIXJvb3RzLmV2ZXJ5KChyKSA9PiB0eXBlb2YgciA9PT0gJ3N0cmluZycgJiYgci5sZW5ndGggPiAwKSkgcmV0dXJuIG51bGw7XG4gIGlmICghaXNNb2RlKHJhdy5tb2RlKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHN0YXJ0SW5SYXcgPSByYXcuc3RhcnRJbiBhcyB7IHJvb3Q/OiB1bmtub3duOyByZWxQYXRoPzogdW5rbm93biB9IHwgdW5kZWZpbmVkO1xuICBjb25zdCBzdGFydEluID1cbiAgICBzdGFydEluUmF3ICYmXG4gICAgdHlwZW9mIHN0YXJ0SW5SYXcucm9vdCA9PT0gJ251bWJlcicgJiZcbiAgICBzdGFydEluUmF3LnJvb3QgPj0gMCAmJlxuICAgIHN0YXJ0SW5SYXcucm9vdCA8IHJvb3RzLmxlbmd0aCAmJlxuICAgIHR5cGVvZiBzdGFydEluUmF3LnJlbFBhdGggPT09ICdzdHJpbmcnXG4gICAgICA/IHsgcm9vdDogc3RhcnRJblJhdy5yb290LCByZWxQYXRoOiBzdGFydEluUmF3LnJlbFBhdGggfVxuICAgICAgOiB1bmRlZmluZWQ7XG4gIHJldHVybiB7XG4gICAgbW9kZTogcmF3Lm1vZGUsXG4gICAgcm9vdHM6IHJvb3RzIGFzIHN0cmluZ1tdLFxuICAgIHJvb3RMYWJlbHM6IEFycmF5LmlzQXJyYXkocmF3LnJvb3RMYWJlbHMpID8gKHJhdy5yb290TGFiZWxzIGFzIHVua25vd25bXSkubWFwKFN0cmluZykgOiB1bmRlZmluZWQsXG4gICAgcm9vdE1vZGVzOiBBcnJheS5pc0FycmF5KHJhdy5yb290TW9kZXMpXG4gICAgICA/IChyYXcucm9vdE1vZGVzIGFzIHVua25vd25bXSkubWFwKChtKSA9PiAobSA9PT0gJ3JvJyA/ICdybycgOiAncncnKSlcbiAgICAgIDogdW5kZWZpbmVkLFxuICAgIHRpdGxlOiB0eXBlb2YgcmF3LnRpdGxlID09PSAnc3RyaW5nJyA/IHJhdy50aXRsZSA6IHVuZGVmaW5lZCxcbiAgICBmaWx0ZXJzOiBwYXJzZUZpbHRlcnMocmF3LmZpbHRlcnMpLFxuICAgIGRlZmF1bHROYW1lOiB0eXBlb2YgcmF3LmRlZmF1bHROYW1lID09PSAnc3RyaW5nJyA/IHJhdy5kZWZhdWx0TmFtZSA6IHVuZGVmaW5lZCxcbiAgICBzdGFydEluLFxuICAgIGFsbG93Q3JlYXRlRm9sZGVyOiB0eXBlb2YgcmF3LmFsbG93Q3JlYXRlRm9sZGVyID09PSAnYm9vbGVhbicgPyByYXcuYWxsb3dDcmVhdGVGb2xkZXIgOiB1bmRlZmluZWQsXG4gIH07XG59XG5cbi8qKiBUaGUgZmlsZSB0aGUgdXNlciBoYXMgaGlnaGxpZ2h0ZWQgKHZpYSB0aGUgbGlicmFyeSdzIGBvblNlbGVjdGApLCBpZiBhbnkuICovXG5pbnRlcmZhY2UgU2VsZWN0aW9uIHtcbiAgcm9vdElkeDogbnVtYmVyO1xuICAvKiogQ2xlYW4gbW91bnQtcmVsYXRpdmUgcGF0aCAobm8gbGVhZGluZyBzbGFzaCkuICovXG4gIHJlbDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29udHJvbGxlciB7XG4gIHJlYWR5OiBib29sZWFuO1xuICBpbnZhbGlkOiBib29sZWFuO1xuICBmb3JtRmFjdG9yOiBGb3JtRmFjdG9yO1xuXG4gIG1vZGU6IFBpY2tNb2RlO1xuICB0aXRsZTogc3RyaW5nO1xuICBpc1NhdmU6IGJvb2xlYW47XG4gIGhhc0ZpbHRlcnM6IGJvb2xlYW47XG4gIGZpbHRlckxhYmVsOiBzdHJpbmc7XG4gIGN5Y2xlRmlsdGVyOiAoKSA9PiB2b2lkO1xuICBhbGxvd0NyZWF0ZUZvbGRlcjogYm9vbGVhbjtcblxuICAvLyDilIDilIAgd2hhdCB0aGUgbGlicmFyeSBuZWVkcyDilIDilIBcbiAgcm9vdHM6IFJvb3RJbmZvW107XG4gIGV4cGxvcmVyUm9vdHM6IEV4cGxvcmVyUm9vdFtdO1xuICBjd2Q6IHN0cmluZyB8IG51bGw7XG4gIG9uTmF2aWdhdGU6IChyb290OiBFeHBsb3JlclJvb3QsIHJlbFBhdGg6IHN0cmluZykgPT4gdm9pZDtcbiAgb25TZWxlY3Q6IChyb290OiBFeHBsb3JlclJvb3QsIHJlbFBhdGg6IHN0cmluZykgPT4gdm9pZDtcbiAgb25BY3RpdmF0ZTogKHJvb3Q6IEV4cGxvcmVyUm9vdCwgcmVsUGF0aDogc3RyaW5nLCBpc0RpcjogYm9vbGVhbikgPT4gdm9pZDtcblxuICAvLyDilIDilIAgbmV3IGZvbGRlciAocGlja2VyIGNocm9tZSkg4pSA4pSAXG4gIG5ld0ZvbGRlck5hbWU6IHN0cmluZyB8IG51bGw7XG4gIHNldE5ld0ZvbGRlck5hbWU6IChzOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHN0YXJ0TmV3Rm9sZGVyOiAoKSA9PiB2b2lkO1xuICBzdWJtaXROZXdGb2xkZXI6ICgpID0+IHZvaWQ7XG4gIGNhbmNlbE5ld0ZvbGRlcjogKCkgPT4gdm9pZDtcblxuICAvLyDilIDilIAgc2F2ZS1uYW1lIChwaWNrZXIgY2hyb21lKSDilIDilIBcbiAgc2F2ZU5hbWU6IHN0cmluZztcbiAgc2V0U2F2ZU5hbWU6IChzOiBzdHJpbmcpID0+IHZvaWQ7XG5cbiAgLy8g4pSA4pSAIG92ZXJ3cml0ZSBjb25maXJtIChwaWNrZXIgY2hyb21lKSDilIDilIBcbiAgb3ZlcndyaXRlOiBzdHJpbmcgfCBudWxsO1xuICBkb092ZXJ3cml0ZTogKCkgPT4gdm9pZDtcbiAgY2FuY2VsT3ZlcndyaXRlOiAoKSA9PiB2b2lkO1xuXG4gIC8vIOKUgOKUgCBmb290ZXIg4pSA4pSAXG4gIGNhbkNvbmZpcm06IGJvb2xlYW47XG4gIHByaW1hcnlMYWJlbDogc3RyaW5nO1xuICBzZWxlY3Rpb25MYWJlbDogc3RyaW5nO1xuICBjb25maXJtOiAoKSA9PiB2b2lkO1xuICBjYW5jZWw6ICgpID0+IHZvaWQ7XG5cbiAgYnVzeTogYm9vbGVhbjtcbiAgZXJyb3I6IHN0cmluZyB8IG51bGw7XG5cbiAgLy8g4pSA4pSAIG1vYmlsZSBmcmFtaW5nIOKUgOKUgFxuICBzaG93QmFjazogYm9vbGVhbjtcbiAgYmFja01vYmlsZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUZpbGVTZWxlY3RvcigpOiBDb250cm9sbGVyIHtcbiAgY29uc3QgaW5wdXQgPSB1c2VUYXNrSW5wdXQoKTtcbiAgY29uc3QgZm9ybUZhY3RvciA9IHVzZUZvcm1GYWN0b3IoKTtcblxuICBjb25zdCBbcGFyYW1zLCBzZXRQYXJhbXNdID0gdXNlU3RhdGU8Q2FsbGVlUGFyYW1zIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpbnZhbGlkLCBzZXRJbnZhbGlkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgLy8gVGhlIGN1cnJlbnQgZGlyZWN0b3J5IHRoZSBsaWJyYXJ5IGlzIGJyb3dzaW5nIChhYnNvbHV0ZSBjaHJvb3QgcGF0aCksIG9yIG51bGxcbiAgLy8gZm9yIHRoZSBzeW50aGV0aWMgcm9vdHMtcm9vdCAodGhlIGxpYnJhcnkncyByb290IGxpc3QpLiBDb250cm9sbGVkIHNvIHdlIGtub3dcbiAgLy8gdGhlIHNhdmUgZGVzdGluYXRpb24gLyBuZXctZm9sZGVyIHRhcmdldCAvIG92ZXJ3cml0ZSBzY29wZSBhdCBhbGwgdGltZXMuXG4gIGNvbnN0IFtjd2QsIHNldEN3ZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NlbCwgc2V0U2VsXSA9IHVzZVN0YXRlPFNlbGVjdGlvbiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZmlsdGVySWR4LCBzZXRGaWx0ZXJJZHhdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtzYXZlTmFtZSwgc2V0U2F2ZU5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3Rm9sZGVyTmFtZSwgc2V0TmV3Rm9sZGVyTmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW292ZXJ3cml0ZSwgc2V0T3ZlcndyaXRlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgY3JlYXRlZFBhdGhzID0gdXNlUmVmPFNldDxzdHJpbmc+PihuZXcgU2V0KCkpO1xuXG4gIC8vIOKUgOKUgCBpbml0IGZyb20gdGFzayBpbnB1dCAob25jZSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpbnB1dCB8fCBwYXJhbXMgfHwgaW52YWxpZCkgcmV0dXJuO1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlUGFyYW1zKGlucHV0LnBhcmFtcyk7XG4gICAgaWYgKCFwYXJzZWQpIHtcbiAgICAgIC8vIENhbGxlciBidWcgKHplcm8vZ2FyYmxlZCByb290cykg4oCUIGRpc21pc3MgaW1tZWRpYXRlbHkgKHNwZWMgwqczKS5cbiAgICAgIHNldEludmFsaWQodHJ1ZSk7XG4gICAgICBjYW5jZWxUYXNrKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldFBhcmFtcyhwYXJzZWQpO1xuICAgIHNldFNhdmVOYW1lKHBhcnNlZC5kZWZhdWx0TmFtZSA/PyAnJyk7XG4gICAgaWYgKHBhcnNlZC5zdGFydEluKSB7XG4gICAgICBjb25zdCBiYXNlID0gcGFyc2VkLnJvb3RzW3BhcnNlZC5zdGFydEluLnJvb3RdO1xuICAgICAgc2V0Q3dkKGpvaW5QYXRoKGJhc2UsIC4uLnNlZ3NPZihwYXJzZWQuc3RhcnRJbi5yZWxQYXRoKSkpO1xuICAgIH1cbiAgfSwgW2lucHV0LCBwYXJhbXMsIGludmFsaWRdKTtcblxuICBjb25zdCByb290czogUm9vdEluZm9bXSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghcGFyYW1zKSByZXR1cm4gW107XG4gICAgcmV0dXJuIHBhcmFtcy5yb290cy5tYXAoKHAsIGkpID0+ICh7XG4gICAgICBwYXRoOiBwLFxuICAgICAgbGFiZWw6IHBhcmFtcy5yb290TGFiZWxzPy5baV0gPz8gYExvY2F0aW9uICR7aSArIDF9YCxcbiAgICAgIG1vZGU6IHBhcmFtcy5yb290TW9kZXM/LltpXSA/PyAncncnLFxuICAgIH0pKTtcbiAgfSwgW3BhcmFtc10pO1xuXG4gIGNvbnN0IGV4cGxvcmVyUm9vdHMgPSB1c2VNZW1vKCgpID0+IHRvRXhwbG9yZXJSb290cyhyb290cyksIFtyb290c10pO1xuXG4gIGNvbnN0IG1vZGU6IFBpY2tNb2RlID0gcGFyYW1zPy5tb2RlID8/ICdvcGVuLWZpbGUnO1xuICBjb25zdCBpc1NhdmUgPSBtb2RlID09PSAnc2F2ZS1maWxlJztcbiAgY29uc3QgZmlsdGVycyA9IHBhcmFtcz8uZmlsdGVycyA/PyBbXTtcbiAgY29uc3QgaGFzRmlsdGVycyA9IG1vZGUgPT09ICdvcGVuLWZpbGUnICYmIGZpbHRlcnMubGVuZ3RoID4gMDtcbiAgY29uc3QgYWN0aXZlRmlsdGVyID0gaGFzRmlsdGVycyA/IChmaWx0ZXJzW2ZpbHRlcklkeF0gPz8gZmlsdGVyc1swXSkgOiBudWxsO1xuXG4gIC8vIFRoZSByb290IHRoYXQgb3ducyB0aGUgY3VycmVudCBkaXJlY3RvcnkgKG51bGwgYXQgdGhlIHJvb3RzLXJvb3QpLiBJdHMgaW5kZXhcbiAgLy8gaXMgdGhlIGByb290YCBmaWVsZCBvZiB0aGUgcmV0dXJuZWQgcmVzdWx0OyBpdHMgd3JpdGFiaWxpdHkgZ2F0ZXMgY3JlYXRlL3NhdmUuXG4gIGNvbnN0IGN1clJvb3RJZHggPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIWN3ZCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgaSA9IHJvb3RzLmZpbmRJbmRleCgocikgPT4gY3dkID09PSByLnBhdGggfHwgY3dkLnN0YXJ0c1dpdGgoci5wYXRoICsgJy8nKSk7XG4gICAgcmV0dXJuIGkgPj0gMCA/IGkgOiBudWxsO1xuICB9LCBbY3dkLCByb290c10pO1xuICBjb25zdCBjdXJSb290ID0gY3VyUm9vdElkeCAhPSBudWxsID8gcm9vdHNbY3VyUm9vdElkeF0gOiBudWxsO1xuICBjb25zdCBkZXN0V3JpdGFibGUgPSAhIWN1clJvb3QgJiYgY3VyUm9vdC5tb2RlID09PSAncncnO1xuXG4gIGNvbnN0IGFsbG93Q3JlYXRlRm9sZGVyID1cbiAgICAocGFyYW1zPy5hbGxvd0NyZWF0ZUZvbGRlciA/PyBtb2RlID09PSAnc2F2ZS1maWxlJykgJiYgISFjd2QgJiYgZGVzdFdyaXRhYmxlO1xuXG4gIGNvbnN0IG1hdGNoZXNGaWx0ZXIgPSB1c2VDYWxsYmFjayhcbiAgICAobmFtZTogc3RyaW5nKTogYm9vbGVhbiA9PiAoYWN0aXZlRmlsdGVyID8gbWF0Y2hlc0V4dChuYW1lLCBhY3RpdmVGaWx0ZXIuZXh0ZW5zaW9ucykgOiB0cnVlKSxcbiAgICBbYWN0aXZlRmlsdGVyXSxcbiAgKTtcblxuICAvLyDilIDilIAgbGlicmFyeSBjYWxsYmFja3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIGBvbk5hdmlnYXRlYCBmaXJlcyBmcm9tIHRoZSBsaWJyYXJ5J3MgZmxhdCBsaXN0IHdoZW4gdGhlIGJyb3dzZWQgZGlyZWN0b3J5XG4gIC8vIGNoYW5nZXMgKGJyZWFkY3J1bWIgLyBvcGVuaW5nIGEgZm9sZGVyIC8gb3BlbmluZyBhIHJvb3QpLiBBZG9wdCBpdCBhcyBvdXJcbiAgLy8gY29udHJvbGxlZCBjd2Qg4oCUIHRoaXMgaXMgdGhlIHNhdmUgZGVzdGluYXRpb24gLyBvcGVuLWZvbGRlciBjaG9pY2UgLyB0aGVcbiAgLy8gbmV3LWZvbGRlciB0YXJnZXQuIGBvbkFjdGl2YXRlKGRpcilgIHJlcG9ydHMgdGhlIHNhbWUgdHJhbnNpdGlvbiwgc28ga2VlcGluZ1xuICAvLyBib3RoIGluIHN5bmMgaXMgaWRlbXBvdGVudC5cbiAgY29uc3Qgb25OYXZpZ2F0ZSA9IHVzZUNhbGxiYWNrKChyb290OiBFeHBsb3JlclJvb3QsIHJlbFBhdGg6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHJlbCA9IGNsZWFuUmVsKHJlbFBhdGgpO1xuICAgIHNldEN3ZChyZWwgPyBqb2luUGF0aChyb290LnBhdGgsIC4uLnNlZ3NPZihyZWwpKSA6IHJvb3QucGF0aCk7XG4gICAgc2V0U2VsKG51bGwpO1xuICAgIHNldE5ld0ZvbGRlck5hbWUobnVsbCk7XG4gIH0sIFtdKTtcblxuICAvLyBgb25BY3RpdmF0ZWAgZmlyZXMgZm9yIGJvdGggYSBkaXJlY3RvcnkgKHRoZSBsaWJyYXJ5IG5hdmlnYXRlcyBpbnRvIGl0IGFuZFxuICAvLyByZXBvcnRzIHRoZSBORVcgZGlyZWN0b3J5KSBhbmQgYSBmaWxlIChhIGNsaWNrL0VudGVyKS4gRm9yIGRpcmVjdG9yaWVzIHdlXG4gIC8vIGFkb3B0IHRoZSBuZXcgY3dkOyBmb3IgZmlsZXMgd2UgcmVjb3JkIHRoZSBoaWdobGlnaHQgKHNhdmUtZmlsZSBhbHNvIGZpbGxzIHRoZVxuICAvLyBuYW1lIGZpZWxkKS4gV2UgbmV2ZXIgYXV0by1jb21wbGV0ZSBoZXJlIOKAlCB0aGUgZm9vdGVyJ3MgcHJpbWFyeSBidXR0b24gaXMgdGhlXG4gIC8vIHNpbmdsZSBjb21taXQgcGF0aCwgc28gZmlsdGVyL3dyaXRhYmlsaXR5IGdhdGluZyBzdGF5cyBtZWFuaW5nZnVsLlxuICBjb25zdCBvbkFjdGl2YXRlID0gdXNlQ2FsbGJhY2soXG4gICAgKHJvb3Q6IEV4cGxvcmVyUm9vdCwgcmVsUGF0aDogc3RyaW5nLCBpc0RpcjogYm9vbGVhbikgPT4ge1xuICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICBpZiAoaXNEaXIpIHtcbiAgICAgICAgY29uc3QgcmVsID0gY2xlYW5SZWwocmVsUGF0aCk7XG4gICAgICAgIHNldEN3ZChyZWwgPyBqb2luUGF0aChyb290LnBhdGgsIC4uLnNlZ3NPZihyZWwpKSA6IHJvb3QucGF0aCk7XG4gICAgICAgIHNldFNlbChudWxsKTtcbiAgICAgICAgc2V0TmV3Rm9sZGVyTmFtZShudWxsKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVsID0gY2xlYW5SZWwocmVsUGF0aCk7XG4gICAgICBjb25zdCBuYW1lID0gc2Vnc09mKHJlbCkucG9wKCkgPz8gcmVsO1xuICAgICAgc2V0U2VsKHsgcm9vdElkeDogcm9vdEluZGV4T2Yocm9vdCksIHJlbCwgbmFtZSB9KTtcbiAgICAgIGlmIChpc1NhdmUpIHNldFNhdmVOYW1lKG5hbWUpO1xuICAgIH0sXG4gICAgW2lzU2F2ZV0sXG4gICk7XG5cbiAgLy8gVGhlIGxpYnJhcnkncyBzaW5nbGUtY3Vyc29yIGhpZ2hsaWdodC4gU2FtZSBlZmZlY3QgYXMgYSBmaWxlIGFjdGl2YXRpb24nc1xuICAvLyBoaWdobGlnaHQ7IGRpcmVjdG9yaWVzIGRvbid0IGZpcmUgYG9uU2VsZWN0YC5cbiAgY29uc3Qgb25TZWxlY3QgPSB1c2VDYWxsYmFjayhcbiAgICAocm9vdDogRXhwbG9yZXJSb290LCByZWxQYXRoOiBzdHJpbmcpID0+IHtcbiAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgY29uc3QgcmVsID0gY2xlYW5SZWwocmVsUGF0aCk7XG4gICAgICBjb25zdCBuYW1lID0gc2Vnc09mKHJlbCkucG9wKCkgPz8gcmVsO1xuICAgICAgc2V0U2VsKHsgcm9vdElkeDogcm9vdEluZGV4T2Yocm9vdCksIHJlbCwgbmFtZSB9KTtcbiAgICAgIGlmIChpc1NhdmUpIHNldFNhdmVOYW1lKG5hbWUpO1xuICAgIH0sXG4gICAgW2lzU2F2ZV0sXG4gICk7XG5cbiAgLy8g4pSA4pSAIGZpbHRlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IGN5Y2xlRmlsdGVyID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldEZpbHRlcklkeCgoaSkgPT4gKGkgKyAxKSAlIE1hdGgubWF4KDEsIGZpbHRlcnMubGVuZ3RoKSk7XG4gICAgc2V0U2VsKG51bGwpO1xuICB9LCBbZmlsdGVycy5sZW5ndGhdKTtcblxuICAvLyDilIDilIAgcmVzdWx0IG1hcHBpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IGZpbmlzaCA9IHVzZUNhbGxiYWNrKChyb290SWR4OiBudW1iZXIsIHJlbDogc3RyaW5nLCBjcmVhdGVkOiBib29sZWFuKSA9PiB7XG4gICAgaWYgKCFpc1NhZmVSZWwocmVsKSkge1xuICAgICAgc2V0RXJyb3IoJ1RoYXQgbmFtZSBpcyBub3QgYWxsb3dlZC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0OiBQaWNrRmlsZVJlc3VsdCA9IHsgcm9vdDogcm9vdElkeCwgcmVsUGF0aDogcmVsIH07XG4gICAgaWYgKGNyZWF0ZWQpIHJlc3VsdC5jcmVhdGVkID0gdHJ1ZTtcbiAgICBjb21wbGV0ZVRhc2socmVzdWx0KTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGNhbmNlbCA9IHVzZUNhbGxiYWNrKCgpID0+IGNhbmNlbFRhc2soKSwgW10pO1xuXG4gIC8vIOKUgOKUgCBuZXcgZm9sZGVyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBzdGFydE5ld0ZvbGRlciA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIWFsbG93Q3JlYXRlRm9sZGVyKSByZXR1cm47XG4gICAgc2V0TmV3Rm9sZGVyTmFtZSgnJyk7XG4gIH0sIFthbGxvd0NyZWF0ZUZvbGRlcl0pO1xuXG4gIGNvbnN0IGNhbmNlbE5ld0ZvbGRlciA9IHVzZUNhbGxiYWNrKCgpID0+IHNldE5ld0ZvbGRlck5hbWUobnVsbCksIFtdKTtcblxuICBjb25zdCBzdWJtaXROZXdGb2xkZXIgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKG5ld0ZvbGRlck5hbWUgPT0gbnVsbCB8fCAhY3dkIHx8IGN1clJvb3QgPT0gbnVsbCkgcmV0dXJuO1xuICAgIGNvbnN0IG5hbWUgPSBuZXdGb2xkZXJOYW1lLnRyaW0oKTtcbiAgICBpZiAoIW5hbWUgfHwgbmFtZS5pbmNsdWRlcygnLycpIHx8IG5hbWUuaW5jbHVkZXMoJ1xcXFwnKSB8fCBuYW1lID09PSAnLicgfHwgbmFtZSA9PT0gJy4uJykge1xuICAgICAgc2V0RXJyb3IoJ0ludmFsaWQgZm9sZGVyIG5hbWUuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEJ1c3kodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgY29uc3QgYWJzID0gam9pblBhdGgoY3dkLCBuYW1lKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbWFrZURpcihhYnMpO1xuICAgICAgY3JlYXRlZFBhdGhzLmN1cnJlbnQuYWRkKGFicyk7XG4gICAgICBzZXROZXdGb2xkZXJOYW1lKG51bGwpO1xuICAgICAgLy8gRHJvcCBpbnRvIHRoZSBuZXcgZm9sZGVyIChzYXZlLWZpbGUpIC8gbWFrZSBpdCB0aGUgYnJvd3NlZCBkaXI7IHRoZVxuICAgICAgLy8gbGlicmFyeSByZS1yZWFkcyB0aGlzIGRpcmVjdG9yeSBvbiBpdHMgbmV4dCByZW5kZXIuXG4gICAgICBzZXRDd2QoYWJzKTtcbiAgICAgIHNldFNlbChudWxsKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEEgZm9yY2VkIGNyZWF0ZSBhZ2FpbnN0IGEgYHJvYCBjaHJvb3QgbGFuZHMgaGVyZSBhcyBFUk9GUyDigJQgbmV2ZXIgZGF0YSBsb3NzLlxuICAgICAgc2V0RXJyb3IoYENvdWxkbid0IGNyZWF0ZSBmb2xkZXI6ICR7KGVyciBhcyBFcnJvcik/Lm1lc3NhZ2UgPz8gJ3JlYWQtb25seSd9LmApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5KGZhbHNlKTtcbiAgICB9XG4gIH0sIFtuZXdGb2xkZXJOYW1lLCBjd2QsIGN1clJvb3RdKTtcblxuICAvLyDilIDilIAgY29uZmlybSAodGhlIGZvb3RlcidzIHByaW1hcnkgYnV0dG9uKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgY29uZmlybSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIXBhcmFtcykgcmV0dXJuO1xuICAgIGlmIChpc1NhdmUpIHtcbiAgICAgIGNvbnN0IG5hbWUgPSBzYXZlTmFtZS50cmltKCk7XG4gICAgICBpZiAoIW5hbWUgfHwgIWN3ZCB8fCBjdXJSb290SWR4ID09IG51bGwgfHwgIWRlc3RXcml0YWJsZSkgcmV0dXJuO1xuICAgICAgY29uc3QgcmVsU2VncyA9IGN1clJvb3QgPyBzZWdzT2YoY3dkLnNsaWNlKGN1clJvb3QucGF0aC5sZW5ndGgpKS5jb25jYXQobmFtZSkgOiBbbmFtZV07XG4gICAgICBjb25zdCByZWwgPSByZWxTZWdzLmpvaW4oJy8nKTtcbiAgICAgIC8vIE92ZXJ3cml0ZSBjb25maXJtOiBjaGVjayB0aGUgY3VycmVudCBkaXJlY3RvcnkgZm9yIGEgc2FtZS1uYW1lZCBmaWxlLlxuICAgICAgbGlzdERpcihjd2QpXG4gICAgICAgIC50aGVuKChlbnRyaWVzKSA9PiB7XG4gICAgICAgICAgY29uc3QgZXhpc3RzID0gZW50cmllcy5zb21lKChlKSA9PiAhZS5pc0RpciAmJiBlLm5hbWUgPT09IG5hbWUpO1xuICAgICAgICAgIGlmIChleGlzdHMgJiYgb3ZlcndyaXRlICE9PSBuYW1lKSB7XG4gICAgICAgICAgICBzZXRPdmVyd3JpdGUobmFtZSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGZpbmlzaChjdXJSb290SWR4LCByZWwsICFleGlzdHMpO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgIC8vIENhbid0IHN0YXQgdGhlIGRpciDigJQgYXR0ZW1wdCB0aGUgc2F2ZTsgdGhlIGhvc3QgaXMgdGhlIHJlYWwgYm91bmRhcnkuXG4gICAgICAgICAgZmluaXNoKGN1clJvb3RJZHgsIHJlbCwgZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG1vZGUgPT09ICdvcGVuLWZvbGRlcicpIHtcbiAgICAgIC8vIFRoZSBjaG9zZW4gZm9sZGVyIGlzIHRoZSBjdXJyZW50IGRpcmVjdG9yeSAodGhlIGxpYnJhcnkgbmF2aWdhdGVzIGludG9cbiAgICAgIC8vIGZvbGRlcnM7IHlvdSBkcmlsbCB0byB0aGUgb25lIHlvdSB3YW50LCB0aGVuIENob29zZSBmb2xkZXIpLlxuICAgICAgaWYgKCFjd2QgfHwgY3VyUm9vdElkeCA9PSBudWxsIHx8ICFjdXJSb290KSByZXR1cm47XG4gICAgICBjb25zdCByZWwgPSBzZWdzT2YoY3dkLnNsaWNlKGN1clJvb3QucGF0aC5sZW5ndGgpKS5qb2luKCcvJyk7XG4gICAgICBpZiAocmVsLmxlbmd0aCA9PT0gMCkgcmV0dXJuOyAvLyBjYW4ndCByZXR1cm4gdGhlIHJvb3QgaXRzZWxmIChlbXB0eSByZWxQYXRoKVxuICAgICAgY29uc3QgYWJzID0gam9pblBhdGgoY3VyUm9vdC5wYXRoLCAuLi5zZWdzT2YocmVsKSk7XG4gICAgICBmaW5pc2goY3VyUm9vdElkeCwgcmVsLCBjcmVhdGVkUGF0aHMuY3VycmVudC5oYXMoYWJzKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIG9wZW4tZmlsZSDigJQgYSBoaWdobGlnaHRlZCwgZmlsdGVyLW1hdGNoaW5nIGZpbGUuXG4gICAgaWYgKCFzZWwpIHJldHVybjtcbiAgICBpZiAoIW1hdGNoZXNGaWx0ZXIoc2VsLm5hbWUpKSByZXR1cm47XG4gICAgZmluaXNoKHNlbC5yb290SWR4LCBzZWwucmVsLCBmYWxzZSk7XG4gIH0sIFtwYXJhbXMsIGlzU2F2ZSwgc2F2ZU5hbWUsIGN3ZCwgY3VyUm9vdElkeCwgY3VyUm9vdCwgZGVzdFdyaXRhYmxlLCBvdmVyd3JpdGUsIGZpbmlzaCwgbW9kZSwgc2VsLCBtYXRjaGVzRmlsdGVyXSk7XG5cbiAgY29uc3QgZG9PdmVyd3JpdGUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKG92ZXJ3cml0ZSA9PSBudWxsIHx8ICFjd2QgfHwgY3VyUm9vdElkeCA9PSBudWxsIHx8ICFjdXJSb290KSByZXR1cm47XG4gICAgY29uc3QgbmFtZSA9IG92ZXJ3cml0ZTtcbiAgICBzZXRPdmVyd3JpdGUobnVsbCk7XG4gICAgY29uc3QgcmVsID0gc2Vnc09mKGN3ZC5zbGljZShjdXJSb290LnBhdGgubGVuZ3RoKSkuY29uY2F0KG5hbWUpLmpvaW4oJy8nKTtcbiAgICBmaW5pc2goY3VyUm9vdElkeCwgcmVsLCBmYWxzZSk7XG4gIH0sIFtvdmVyd3JpdGUsIGN3ZCwgY3VyUm9vdElkeCwgY3VyUm9vdCwgZmluaXNoXSk7XG5cbiAgY29uc3QgY2FuY2VsT3ZlcndyaXRlID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0T3ZlcndyaXRlKG51bGwpLCBbXSk7XG5cbiAgLy8g4pSA4pSAIGZvb3RlciBzdGF0ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgcHJpbWFyeUxhYmVsID1cbiAgICBtb2RlID09PSAnb3Blbi1maWxlJyA/ICdPcGVuJyA6IG1vZGUgPT09ICdvcGVuLWZvbGRlcicgPyAnQ2hvb3NlIGZvbGRlcicgOiAnU2F2ZSc7XG5cbiAgY29uc3QgY2FuQ29uZmlybSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChpc1NhdmUpIHJldHVybiBkZXN0V3JpdGFibGUgJiYgc2F2ZU5hbWUudHJpbSgpLmxlbmd0aCA+IDA7XG4gICAgaWYgKG1vZGUgPT09ICdvcGVuLWZvbGRlcicpIHJldHVybiBjdXJSb290SWR4ICE9IG51bGwgJiYgISFjd2QgJiYgY3dkICE9PSBjdXJSb290Py5wYXRoO1xuICAgIC8vIG9wZW4tZmlsZTogYSBoaWdobGlnaHRlZCBmaWxlIHRoYXQgbWF0Y2hlcyB0aGUgYWN0aXZlIGZpbHRlci5cbiAgICByZXR1cm4gISFzZWwgJiYgbWF0Y2hlc0ZpbHRlcihzZWwubmFtZSk7XG4gIH0sIFtpc1NhdmUsIGRlc3RXcml0YWJsZSwgc2F2ZU5hbWUsIG1vZGUsIGN1clJvb3RJZHgsIGN3ZCwgY3VyUm9vdCwgc2VsLCBtYXRjaGVzRmlsdGVyXSk7XG5cbiAgY29uc3Qgc2VsZWN0aW9uTGFiZWwgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoZXJyb3IpIHJldHVybiBlcnJvcjtcbiAgICBjb25zdCBsYWJlbCA9IGN1clJvb3Q/LmxhYmVsID8/IChzZWwgIT0gbnVsbCA/IHJvb3RzW3NlbC5yb290SWR4XT8ubGFiZWwgOiB1bmRlZmluZWQpO1xuICAgIGlmIChpc1NhdmUpIHtcbiAgICAgIGNvbnN0IGRpclJlbCA9IGN1clJvb3QgJiYgY3dkID8gc2Vnc09mKGN3ZC5zbGljZShjdXJSb290LnBhdGgubGVuZ3RoKSkuam9pbignLycpIDogJyc7XG4gICAgICBjb25zdCBmdWxsID0gW2RpclJlbCwgc2F2ZU5hbWVdLmZpbHRlcihCb29sZWFuKS5qb2luKCcvJyk7XG4gICAgICBpZiAoIWZ1bGwgfHwgIWxhYmVsKSByZXR1cm4gJ0Nob29zZSBhIGZvbGRlciBhbmQgZmlsZSBuYW1lLic7XG4gICAgICByZXR1cm4gYCR7bGFiZWx9IC8gJHtmdWxsfWA7XG4gICAgfVxuICAgIGlmIChtb2RlID09PSAnb3Blbi1mb2xkZXInKSB7XG4gICAgICBjb25zdCByZWwgPSBjdXJSb290ICYmIGN3ZCA/IHNlZ3NPZihjd2Quc2xpY2UoY3VyUm9vdC5wYXRoLmxlbmd0aCkpLmpvaW4oJy8nKSA6ICcnO1xuICAgICAgaWYgKCFyZWwgfHwgIWxhYmVsKSByZXR1cm4gJ09wZW4gYSBmb2xkZXIgdG8gY2hvb3NlIGl0Lic7XG4gICAgICByZXR1cm4gYCR7bGFiZWx9IC8gJHtyZWx9YDtcbiAgICB9XG4gICAgaWYgKCFzZWwpIHJldHVybiAnU2VsZWN0IGEgZmlsZS4nO1xuICAgIHJldHVybiBgJHtyb290c1tzZWwucm9vdElkeF0/LmxhYmVsID8/ICcnfSAvICR7c2VsLnJlbH1gO1xuICB9LCBbZXJyb3IsIGN1clJvb3QsIGN3ZCwgaXNTYXZlLCBzYXZlTmFtZSwgbW9kZSwgc2VsLCByb290c10pO1xuXG4gIC8vIOKUgOKUgCBcImJhY2sgdG8gbG9jYXRpb25zXCIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRoZSBsaWJyYXJ5J3MgbGlzdCBkcmlsbHMgRE9XTiB2aWEgaXRzIG93biBicmVhZGNydW1iLCBidXQgdW5kZXIgYSBDT05UUk9MTEVEXG4gIC8vIGBjd2RgIGl0cyBcInJvb3RzLXJvb3RcIiBicmVhZGNydW1iIGxpbmsgY2FuJ3QgcmVwb3J0IHRoZSBudWxsIHRyYW5zaXRpb24gYmFjayB0b1xuICAvLyB1cyAobGlicmFyeSBnYXAg4oCUIHNlZSByZXBvcnQpLiBXZSBvd24gdGhhdCBhZmZvcmRhbmNlIGluc3RlYWQ6IGEgaGVhZGVyIEJhY2tcbiAgLy8gYnV0dG9uIHRoYXQgcmV0dXJucyB0byB0aGUgcm9vdCBsaXN0IChgY3dkID0gbnVsbGApLCBzbyBtdWx0aS1yb290IHN3aXRjaGluZ1xuICAvLyB3b3JrcyBvbiBldmVyeSBmb3JtIGZhY3Rvci4gU2hvd24gd2hlbmV2ZXIgd2UncmUgaW5zaWRlIGEgcm9vdC5cbiAgY29uc3Qgc2hvd0JhY2sgPSBjd2QgIT0gbnVsbDtcbiAgY29uc3QgYmFja01vYmlsZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBzZXRDd2QobnVsbCk7XG4gICAgc2V0U2VsKG51bGwpO1xuICAgIHNldE5ld0ZvbGRlck5hbWUobnVsbCk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4ge1xuICAgIHJlYWR5OiAhIXBhcmFtcyxcbiAgICBpbnZhbGlkLFxuICAgIGZvcm1GYWN0b3IsXG4gICAgbW9kZSxcbiAgICB0aXRsZTpcbiAgICAgIHBhcmFtcz8udGl0bGUgPz9cbiAgICAgIChtb2RlID09PSAnc2F2ZS1maWxlJyA/ICdTYXZlIGZpbGUnIDogbW9kZSA9PT0gJ29wZW4tZm9sZGVyJyA/ICdDaG9vc2UgZm9sZGVyJyA6ICdPcGVuIGZpbGUnKSxcbiAgICBpc1NhdmUsXG4gICAgaGFzRmlsdGVycyxcbiAgICBmaWx0ZXJMYWJlbDogYWN0aXZlRmlsdGVyPy5sYWJlbCA/PyAnQWxsIGZpbGVzJyxcbiAgICBjeWNsZUZpbHRlcixcbiAgICBhbGxvd0NyZWF0ZUZvbGRlcixcbiAgICByb290cyxcbiAgICBleHBsb3JlclJvb3RzLFxuICAgIGN3ZCxcbiAgICBvbk5hdmlnYXRlLFxuICAgIG9uU2VsZWN0LFxuICAgIG9uQWN0aXZhdGUsXG4gICAgbmV3Rm9sZGVyTmFtZSxcbiAgICBzZXROZXdGb2xkZXJOYW1lLFxuICAgIHN0YXJ0TmV3Rm9sZGVyLFxuICAgIHN1Ym1pdE5ld0ZvbGRlcixcbiAgICBjYW5jZWxOZXdGb2xkZXIsXG4gICAgc2F2ZU5hbWUsXG4gICAgc2V0U2F2ZU5hbWUsXG4gICAgb3ZlcndyaXRlLFxuICAgIGRvT3ZlcndyaXRlLFxuICAgIGNhbmNlbE92ZXJ3cml0ZSxcbiAgICBjYW5Db25maXJtLFxuICAgIHByaW1hcnlMYWJlbCxcbiAgICBzZWxlY3Rpb25MYWJlbCxcbiAgICBjb25maXJtLFxuICAgIGNhbmNlbCxcbiAgICBidXN5LFxuICAgIGVycm9yLFxuICAgIHNob3dCYWNrLFxuICAgIGJhY2tNb2JpbGUsXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBU0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBUUEsSUFBQUUsR0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsZ0JBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLE1BQUEsR0FBQUosT0FBQTtBQXBCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBZUEsTUFBTUssTUFBTSxHQUFJQyxDQUFVLElBQ3hCQSxDQUFDLEtBQUssV0FBVyxJQUFJQSxDQUFDLEtBQUssYUFBYSxJQUFJQSxDQUFDLEtBQUssV0FBVztBQUUvRCxTQUFTQyxZQUFZQSxDQUFDRCxDQUFVLEVBQTRCO0VBQzFELElBQUksQ0FBQ0UsS0FBSyxDQUFDQyxPQUFPLENBQUNILENBQUMsQ0FBQyxFQUFFLE9BQU9JLFNBQVM7RUFDdkMsTUFBTUMsR0FBaUIsR0FBRyxFQUFFO0VBQzVCLEtBQUssTUFBTUMsQ0FBQyxJQUFJTixDQUFDLEVBQUU7SUFDakIsTUFBTU8sQ0FBQyxHQUFHRCxDQUE4QztJQUN4RCxJQUFJLE9BQU9DLENBQUMsRUFBRUMsS0FBSyxLQUFLLFFBQVEsSUFBSU4sS0FBSyxDQUFDQyxPQUFPLENBQUNJLENBQUMsQ0FBQ0UsVUFBVSxDQUFDLEVBQUU7TUFDL0RKLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDO1FBQUVGLEtBQUssRUFBRUQsQ0FBQyxDQUFDQyxLQUFLO1FBQUVDLFVBQVUsRUFBRUYsQ0FBQyxDQUFDRSxVQUFVLENBQUNFLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLLE9BQU9BLENBQUMsS0FBSyxRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQzdGO0VBQ0Y7RUFDQSxPQUFPUCxHQUFHLENBQUNRLE1BQU0sR0FBR1IsR0FBRyxHQUFHRCxTQUFTO0FBQ3JDOztBQUVBO0FBQ0EsU0FBU1UsV0FBV0EsQ0FBQ0MsR0FBd0MsRUFBdUI7RUFDbEYsSUFBSSxDQUFDQSxHQUFHLEVBQUUsT0FBTyxJQUFJO0VBQ3JCLE1BQU1DLEtBQUssR0FBR0QsR0FBRyxDQUFDQyxLQUFLO0VBQ3ZCLElBQUksQ0FBQ2QsS0FBSyxDQUFDQyxPQUFPLENBQUNhLEtBQUssQ0FBQyxJQUFJQSxLQUFLLENBQUNILE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQzVELElBQUksQ0FBQ0csS0FBSyxDQUFDQyxLQUFLLENBQUVDLENBQUMsSUFBSyxPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUFJQSxDQUFDLENBQUNMLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDM0UsSUFBSSxDQUFDZCxNQUFNLENBQUNnQixHQUFHLENBQUNJLElBQUksQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUNsQyxNQUFNQyxVQUFVLEdBQUdMLEdBQUcsQ0FBQ00sT0FBNEQ7RUFDbkYsTUFBTUEsT0FBTyxHQUNYRCxVQUFVLElBQ1YsT0FBT0EsVUFBVSxDQUFDRSxJQUFJLEtBQUssUUFBUSxJQUNuQ0YsVUFBVSxDQUFDRSxJQUFJLElBQUksQ0FBQyxJQUNwQkYsVUFBVSxDQUFDRSxJQUFJLEdBQUdOLEtBQUssQ0FBQ0gsTUFBTSxJQUM5QixPQUFPTyxVQUFVLENBQUNHLE9BQU8sS0FBSyxRQUFRLEdBQ2xDO0lBQUVELElBQUksRUFBRUYsVUFBVSxDQUFDRSxJQUFJO0lBQUVDLE9BQU8sRUFBRUgsVUFBVSxDQUFDRztFQUFRLENBQUMsR0FDdERuQixTQUFTO0VBQ2YsT0FBTztJQUNMZSxJQUFJLEVBQUVKLEdBQUcsQ0FBQ0ksSUFBSTtJQUNkSCxLQUFLLEVBQUVBLEtBQWlCO0lBQ3hCUSxVQUFVLEVBQUV0QixLQUFLLENBQUNDLE9BQU8sQ0FBQ1ksR0FBRyxDQUFDUyxVQUFVLENBQUMsR0FBSVQsR0FBRyxDQUFDUyxVQUFVLENBQWVDLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDLEdBQUd0QixTQUFTO0lBQ2pHdUIsU0FBUyxFQUFFekIsS0FBSyxDQUFDQyxPQUFPLENBQUNZLEdBQUcsQ0FBQ1ksU0FBUyxDQUFDLEdBQ2xDWixHQUFHLENBQUNZLFNBQVMsQ0FBZUYsR0FBRyxDQUFFRyxDQUFDLElBQU1BLENBQUMsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUssQ0FBQyxHQUNuRXhCLFNBQVM7SUFDYnlCLEtBQUssRUFBRSxPQUFPZCxHQUFHLENBQUNjLEtBQUssS0FBSyxRQUFRLEdBQUdkLEdBQUcsQ0FBQ2MsS0FBSyxHQUFHekIsU0FBUztJQUM1RDBCLE9BQU8sRUFBRTdCLFlBQVksQ0FBQ2MsR0FBRyxDQUFDZSxPQUFPLENBQUM7SUFDbENDLFdBQVcsRUFBRSxPQUFPaEIsR0FBRyxDQUFDZ0IsV0FBVyxLQUFLLFFBQVEsR0FBR2hCLEdBQUcsQ0FBQ2dCLFdBQVcsR0FBRzNCLFNBQVM7SUFDOUVpQixPQUFPO0lBQ1BXLGlCQUFpQixFQUFFLE9BQU9qQixHQUFHLENBQUNpQixpQkFBaUIsS0FBSyxTQUFTLEdBQUdqQixHQUFHLENBQUNpQixpQkFBaUIsR0FBRzVCO0VBQzFGLENBQUM7QUFDSDs7QUFFQTs7QUE0RE8sU0FBUzZCLGVBQWVBLENBQUEsRUFBZTtFQUM1QyxNQUFNQyxLQUFLLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDO0VBQzVCLE1BQU1DLFVBQVUsR0FBRyxJQUFBQyxrQkFBYSxFQUFDLENBQUM7RUFFbEMsTUFBTSxDQUFDQyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBc0IsSUFBSSxDQUFDO0VBQy9ELE1BQU0sQ0FBQ0MsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0csR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUNuRCxNQUFNLENBQUNLLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQU4sZUFBUSxFQUFtQixJQUFJLENBQUM7RUFDdEQsTUFBTSxDQUFDTyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFSLGVBQVEsRUFBQyxDQUFDLENBQUM7RUFDN0MsTUFBTSxDQUFDUyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFWLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDNUMsTUFBTSxDQUFDVyxhQUFhLEVBQUVDLGdCQUFnQixDQUFDLEdBQUcsSUFBQVosZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDdkUsTUFBTSxDQUFDYSxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFkLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQy9ELE1BQU0sQ0FBQ2UsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBaEIsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUN2QyxNQUFNLENBQUNpQixLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFsQixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUV2RCxNQUFNbUIsWUFBWSxHQUFHLElBQUFDLGFBQU0sRUFBYyxJQUFJQyxHQUFHLENBQUMsQ0FBQyxDQUFDOztFQUVuRDtFQUNBLElBQUFDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQzVCLEtBQUssSUFBSUksTUFBTSxJQUFJRyxPQUFPLEVBQUU7SUFDakMsTUFBTXNCLE1BQU0sR0FBR2pELFdBQVcsQ0FBQ29CLEtBQUssQ0FBQ0ksTUFBTSxDQUFDO0lBQ3hDLElBQUksQ0FBQ3lCLE1BQU0sRUFBRTtNQUNYO01BQ0FyQixVQUFVLENBQUMsSUFBSSxDQUFDO01BQ2hCLElBQUFzQixlQUFVLEVBQUMsQ0FBQztNQUNaO0lBQ0Y7SUFDQXpCLFNBQVMsQ0FBQ3dCLE1BQU0sQ0FBQztJQUNqQmIsV0FBVyxDQUFDYSxNQUFNLENBQUNoQyxXQUFXLElBQUksRUFBRSxDQUFDO0lBQ3JDLElBQUlnQyxNQUFNLENBQUMxQyxPQUFPLEVBQUU7TUFDbEIsTUFBTTRDLElBQUksR0FBR0YsTUFBTSxDQUFDL0MsS0FBSyxDQUFDK0MsTUFBTSxDQUFDMUMsT0FBTyxDQUFDQyxJQUFJLENBQUM7TUFDOUNzQixNQUFNLENBQUMsSUFBQXNCLGVBQVEsRUFBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBQUUsYUFBTSxFQUFDSixNQUFNLENBQUMxQyxPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDM0Q7RUFDRixDQUFDLEVBQUUsQ0FBQ1csS0FBSyxFQUFFSSxNQUFNLEVBQUVHLE9BQU8sQ0FBQyxDQUFDO0VBRTVCLE1BQU16QixLQUFpQixHQUFHLElBQUFvRCxjQUFPLEVBQUMsTUFBTTtJQUN0QyxJQUFJLENBQUM5QixNQUFNLEVBQUUsT0FBTyxFQUFFO0lBQ3RCLE9BQU9BLE1BQU0sQ0FBQ3RCLEtBQUssQ0FBQ1MsR0FBRyxDQUFDLENBQUM0QyxDQUFDLEVBQUVDLENBQUMsTUFBTTtNQUNqQ0MsSUFBSSxFQUFFRixDQUFDO01BQ1A3RCxLQUFLLEVBQUU4QixNQUFNLENBQUNkLFVBQVUsR0FBRzhDLENBQUMsQ0FBQyxJQUFJLFlBQVlBLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDcERuRCxJQUFJLEVBQUVtQixNQUFNLENBQUNYLFNBQVMsR0FBRzJDLENBQUMsQ0FBQyxJQUFJO0lBQ2pDLENBQUMsQ0FBQyxDQUFDO0VBQ0wsQ0FBQyxFQUFFLENBQUNoQyxNQUFNLENBQUMsQ0FBQztFQUVaLE1BQU1rQyxhQUFhLEdBQUcsSUFBQUosY0FBTyxFQUFDLE1BQU0sSUFBQUssZ0NBQWUsRUFBQ3pELEtBQUssQ0FBQyxFQUFFLENBQUNBLEtBQUssQ0FBQyxDQUFDO0VBRXBFLE1BQU1HLElBQWMsR0FBR21CLE1BQU0sRUFBRW5CLElBQUksSUFBSSxXQUFXO0VBQ2xELE1BQU11RCxNQUFNLEdBQUd2RCxJQUFJLEtBQUssV0FBVztFQUNuQyxNQUFNVyxPQUFPLEdBQUdRLE1BQU0sRUFBRVIsT0FBTyxJQUFJLEVBQUU7RUFDckMsTUFBTTZDLFVBQVUsR0FBR3hELElBQUksS0FBSyxXQUFXLElBQUlXLE9BQU8sQ0FBQ2pCLE1BQU0sR0FBRyxDQUFDO0VBQzdELE1BQU0rRCxZQUFZLEdBQUdELFVBQVUsR0FBSTdDLE9BQU8sQ0FBQ2lCLFNBQVMsQ0FBQyxJQUFJakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFJLElBQUk7O0VBRTNFO0VBQ0E7RUFDQSxNQUFNK0MsVUFBVSxHQUFHLElBQUFULGNBQU8sRUFBQyxNQUFNO0lBQy9CLElBQUksQ0FBQ3pCLEdBQUcsRUFBRSxPQUFPLElBQUk7SUFDckIsTUFBTTJCLENBQUMsR0FBR3RELEtBQUssQ0FBQzhELFNBQVMsQ0FBRTVELENBQUMsSUFBS3lCLEdBQUcsS0FBS3pCLENBQUMsQ0FBQ3FELElBQUksSUFBSTVCLEdBQUcsQ0FBQ29DLFVBQVUsQ0FBQzdELENBQUMsQ0FBQ3FELElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNoRixPQUFPRCxDQUFDLElBQUksQ0FBQyxHQUFHQSxDQUFDLEdBQUcsSUFBSTtFQUMxQixDQUFDLEVBQUUsQ0FBQzNCLEdBQUcsRUFBRTNCLEtBQUssQ0FBQyxDQUFDO0VBQ2hCLE1BQU1nRSxPQUFPLEdBQUdILFVBQVUsSUFBSSxJQUFJLEdBQUc3RCxLQUFLLENBQUM2RCxVQUFVLENBQUMsR0FBRyxJQUFJO0VBQzdELE1BQU1JLFlBQVksR0FBRyxDQUFDLENBQUNELE9BQU8sSUFBSUEsT0FBTyxDQUFDN0QsSUFBSSxLQUFLLElBQUk7RUFFdkQsTUFBTWEsaUJBQWlCLEdBQ3JCLENBQUNNLE1BQU0sRUFBRU4saUJBQWlCLElBQUliLElBQUksS0FBSyxXQUFXLEtBQUssQ0FBQyxDQUFDd0IsR0FBRyxJQUFJc0MsWUFBWTtFQUU5RSxNQUFNQyxhQUFhLEdBQUcsSUFBQUMsa0JBQVcsRUFDOUJDLElBQVksSUFBZVIsWUFBWSxHQUFHLElBQUFTLGlCQUFVLEVBQUNELElBQUksRUFBRVIsWUFBWSxDQUFDbkUsVUFBVSxDQUFDLEdBQUcsSUFBSyxFQUM1RixDQUFDbUUsWUFBWSxDQUNmLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTVUsVUFBVSxHQUFHLElBQUFILGtCQUFXLEVBQUMsQ0FBQzdELElBQWtCLEVBQUVDLE9BQWUsS0FBSztJQUN0RSxNQUFNZ0UsR0FBRyxHQUFHLElBQUFDLHlCQUFRLEVBQUNqRSxPQUFPLENBQUM7SUFDN0JxQixNQUFNLENBQUMyQyxHQUFHLEdBQUcsSUFBQXJCLGVBQVEsRUFBQzVDLElBQUksQ0FBQ2lELElBQUksRUFBRSxHQUFHLElBQUFKLGFBQU0sRUFBQ29CLEdBQUcsQ0FBQyxDQUFDLEdBQUdqRSxJQUFJLENBQUNpRCxJQUFJLENBQUM7SUFDN0R6QixNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ1pNLGdCQUFnQixDQUFDLElBQUksQ0FBQztFQUN4QixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNcUMsVUFBVSxHQUFHLElBQUFOLGtCQUFXLEVBQzVCLENBQUM3RCxJQUFrQixFQUFFQyxPQUFlLEVBQUVtRSxLQUFjLEtBQUs7SUFDdkRoQyxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ2QsSUFBSWdDLEtBQUssRUFBRTtNQUNULE1BQU1ILEdBQUcsR0FBRyxJQUFBQyx5QkFBUSxFQUFDakUsT0FBTyxDQUFDO01BQzdCcUIsTUFBTSxDQUFDMkMsR0FBRyxHQUFHLElBQUFyQixlQUFRLEVBQUM1QyxJQUFJLENBQUNpRCxJQUFJLEVBQUUsR0FBRyxJQUFBSixhQUFNLEVBQUNvQixHQUFHLENBQUMsQ0FBQyxHQUFHakUsSUFBSSxDQUFDaUQsSUFBSSxDQUFDO01BQzdEekIsTUFBTSxDQUFDLElBQUksQ0FBQztNQUNaTSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7TUFDdEI7SUFDRjtJQUNBLE1BQU1tQyxHQUFHLEdBQUcsSUFBQUMseUJBQVEsRUFBQ2pFLE9BQU8sQ0FBQztJQUM3QixNQUFNNkQsSUFBSSxHQUFHLElBQUFqQixhQUFNLEVBQUNvQixHQUFHLENBQUMsQ0FBQ0ksR0FBRyxDQUFDLENBQUMsSUFBSUosR0FBRztJQUNyQ3pDLE1BQU0sQ0FBQztNQUFFOEMsT0FBTyxFQUFFLElBQUFDLDRCQUFXLEVBQUN2RSxJQUFJLENBQUM7TUFBRWlFLEdBQUc7TUFBRUg7SUFBSyxDQUFDLENBQUM7SUFDakQsSUFBSVYsTUFBTSxFQUFFeEIsV0FBVyxDQUFDa0MsSUFBSSxDQUFDO0VBQy9CLENBQUMsRUFDRCxDQUFDVixNQUFNLENBQ1QsQ0FBQzs7RUFFRDtFQUNBO0VBQ0EsTUFBTW9CLFFBQVEsR0FBRyxJQUFBWCxrQkFBVyxFQUMxQixDQUFDN0QsSUFBa0IsRUFBRUMsT0FBZSxLQUFLO0lBQ3ZDbUMsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNkLE1BQU02QixHQUFHLEdBQUcsSUFBQUMseUJBQVEsRUFBQ2pFLE9BQU8sQ0FBQztJQUM3QixNQUFNNkQsSUFBSSxHQUFHLElBQUFqQixhQUFNLEVBQUNvQixHQUFHLENBQUMsQ0FBQ0ksR0FBRyxDQUFDLENBQUMsSUFBSUosR0FBRztJQUNyQ3pDLE1BQU0sQ0FBQztNQUFFOEMsT0FBTyxFQUFFLElBQUFDLDRCQUFXLEVBQUN2RSxJQUFJLENBQUM7TUFBRWlFLEdBQUc7TUFBRUg7SUFBSyxDQUFDLENBQUM7SUFDakQsSUFBSVYsTUFBTSxFQUFFeEIsV0FBVyxDQUFDa0MsSUFBSSxDQUFDO0VBQy9CLENBQUMsRUFDRCxDQUFDVixNQUFNLENBQ1QsQ0FBQzs7RUFFRDtFQUNBLE1BQU1xQixXQUFXLEdBQUcsSUFBQVosa0JBQVcsRUFBQyxNQUFNO0lBQ3BDbkMsWUFBWSxDQUFFc0IsQ0FBQyxJQUFLLENBQUNBLENBQUMsR0FBRyxDQUFDLElBQUkwQixJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUVuRSxPQUFPLENBQUNqQixNQUFNLENBQUMsQ0FBQztJQUMxRGlDLE1BQU0sQ0FBQyxJQUFJLENBQUM7RUFDZCxDQUFDLEVBQUUsQ0FBQ2hCLE9BQU8sQ0FBQ2pCLE1BQU0sQ0FBQyxDQUFDOztFQUVwQjtFQUNBLE1BQU1xRixNQUFNLEdBQUcsSUFBQWYsa0JBQVcsRUFBQyxDQUFDUyxPQUFlLEVBQUVMLEdBQVcsRUFBRVksT0FBZ0IsS0FBSztJQUM3RSxJQUFJLENBQUMsSUFBQUMsZ0JBQVMsRUFBQ2IsR0FBRyxDQUFDLEVBQUU7TUFDbkI3QixRQUFRLENBQUMsMkJBQTJCLENBQUM7TUFDckM7SUFDRjtJQUNBLE1BQU0yQyxNQUFzQixHQUFHO01BQUUvRSxJQUFJLEVBQUVzRSxPQUFPO01BQUVyRSxPQUFPLEVBQUVnRTtJQUFJLENBQUM7SUFDOUQsSUFBSVksT0FBTyxFQUFFRSxNQUFNLENBQUNGLE9BQU8sR0FBRyxJQUFJO0lBQ2xDLElBQUFHLGlCQUFZLEVBQUNELE1BQU0sQ0FBQztFQUN0QixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTUUsTUFBTSxHQUFHLElBQUFwQixrQkFBVyxFQUFDLE1BQU0sSUFBQW5CLGVBQVUsRUFBQyxDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVsRDtFQUNBLE1BQU13QyxjQUFjLEdBQUcsSUFBQXJCLGtCQUFXLEVBQUMsTUFBTTtJQUN2QyxJQUFJLENBQUNuRCxpQkFBaUIsRUFBRTtJQUN4Qm9CLGdCQUFnQixDQUFDLEVBQUUsQ0FBQztFQUN0QixDQUFDLEVBQUUsQ0FBQ3BCLGlCQUFpQixDQUFDLENBQUM7RUFFdkIsTUFBTXlFLGVBQWUsR0FBRyxJQUFBdEIsa0JBQVcsRUFBQyxNQUFNL0IsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRXJFLE1BQU1zRCxlQUFlLEdBQUcsSUFBQXZCLGtCQUFXLEVBQUMsWUFBWTtJQUM5QyxJQUFJaEMsYUFBYSxJQUFJLElBQUksSUFBSSxDQUFDUixHQUFHLElBQUlxQyxPQUFPLElBQUksSUFBSSxFQUFFO0lBQ3RELE1BQU1JLElBQUksR0FBR2pDLGFBQWEsQ0FBQ3dELElBQUksQ0FBQyxDQUFDO0lBQ2pDLElBQUksQ0FBQ3ZCLElBQUksSUFBSUEsSUFBSSxDQUFDd0IsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJeEIsSUFBSSxDQUFDd0IsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJeEIsSUFBSSxLQUFLLEdBQUcsSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtNQUN2RjFCLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQztNQUNoQztJQUNGO0lBQ0FGLE9BQU8sQ0FBQyxJQUFJLENBQUM7SUFDYkUsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNkLE1BQU1tRCxHQUFHLEdBQUcsSUFBQTNDLGVBQVEsRUFBQ3ZCLEdBQUcsRUFBRXlDLElBQUksQ0FBQztJQUMvQixJQUFJO01BQ0YsTUFBTSxJQUFBMEIsV0FBTyxFQUFDRCxHQUFHLENBQUM7TUFDbEJsRCxZQUFZLENBQUNvRCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsR0FBRyxDQUFDO01BQzdCekQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO01BQ3RCO01BQ0E7TUFDQVIsTUFBTSxDQUFDaUUsR0FBRyxDQUFDO01BQ1gvRCxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ2QsQ0FBQyxDQUFDLE9BQU9tRSxHQUFHLEVBQUU7TUFDWjtNQUNBdkQsUUFBUSxDQUFDLDJCQUE0QnVELEdBQUcsRUFBWUMsT0FBTyxJQUFJLFdBQVcsR0FBRyxDQUFDO0lBQ2hGLENBQUMsU0FBUztNQUNSMUQsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUNoQjtFQUNGLENBQUMsRUFBRSxDQUFDTCxhQUFhLEVBQUVSLEdBQUcsRUFBRXFDLE9BQU8sQ0FBQyxDQUFDOztFQUVqQztFQUNBLE1BQU1tQyxPQUFPLEdBQUcsSUFBQWhDLGtCQUFXLEVBQUMsTUFBTTtJQUNoQyxJQUFJLENBQUM3QyxNQUFNLEVBQUU7SUFDYixJQUFJb0MsTUFBTSxFQUFFO01BQ1YsTUFBTVUsSUFBSSxHQUFHbkMsUUFBUSxDQUFDMEQsSUFBSSxDQUFDLENBQUM7TUFDNUIsSUFBSSxDQUFDdkIsSUFBSSxJQUFJLENBQUN6QyxHQUFHLElBQUlrQyxVQUFVLElBQUksSUFBSSxJQUFJLENBQUNJLFlBQVksRUFBRTtNQUMxRCxNQUFNbUMsT0FBTyxHQUFHcEMsT0FBTyxHQUFHLElBQUFiLGFBQU0sRUFBQ3hCLEdBQUcsQ0FBQzBFLEtBQUssQ0FBQ3JDLE9BQU8sQ0FBQ1QsSUFBSSxDQUFDMUQsTUFBTSxDQUFDLENBQUMsQ0FBQ3lHLE1BQU0sQ0FBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUNBLElBQUksQ0FBQztNQUN0RixNQUFNRyxHQUFHLEdBQUc2QixPQUFPLENBQUNHLElBQUksQ0FBQyxHQUFHLENBQUM7TUFDN0I7TUFDQSxJQUFBQyxXQUFPLEVBQUM3RSxHQUFHLENBQUMsQ0FDVDhFLElBQUksQ0FBRUMsT0FBTyxJQUFLO1FBQ2pCLE1BQU1DLE1BQU0sR0FBR0QsT0FBTyxDQUFDRSxJQUFJLENBQUVoSCxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDOEUsS0FBSyxJQUFJOUUsQ0FBQyxDQUFDd0UsSUFBSSxLQUFLQSxJQUFJLENBQUM7UUFDL0QsSUFBSXVDLE1BQU0sSUFBSXRFLFNBQVMsS0FBSytCLElBQUksRUFBRTtVQUNoQzlCLFlBQVksQ0FBQzhCLElBQUksQ0FBQztVQUNsQjtRQUNGO1FBQ0FjLE1BQU0sQ0FBQ3JCLFVBQVUsRUFBRVUsR0FBRyxFQUFFLENBQUNvQyxNQUFNLENBQUM7TUFDbEMsQ0FBQyxDQUFDLENBQ0RFLEtBQUssQ0FBQyxNQUFNO1FBQ1g7UUFDQTNCLE1BQU0sQ0FBQ3JCLFVBQVUsRUFBRVUsR0FBRyxFQUFFLEtBQUssQ0FBQztNQUNoQyxDQUFDLENBQUM7TUFDSjtJQUNGO0lBQ0EsSUFBSXBFLElBQUksS0FBSyxhQUFhLEVBQUU7TUFDMUI7TUFDQTtNQUNBLElBQUksQ0FBQ3dCLEdBQUcsSUFBSWtDLFVBQVUsSUFBSSxJQUFJLElBQUksQ0FBQ0csT0FBTyxFQUFFO01BQzVDLE1BQU1PLEdBQUcsR0FBRyxJQUFBcEIsYUFBTSxFQUFDeEIsR0FBRyxDQUFDMEUsS0FBSyxDQUFDckMsT0FBTyxDQUFDVCxJQUFJLENBQUMxRCxNQUFNLENBQUMsQ0FBQyxDQUFDMEcsSUFBSSxDQUFDLEdBQUcsQ0FBQztNQUM1RCxJQUFJaEMsR0FBRyxDQUFDMUUsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLENBQUM7TUFDOUIsTUFBTWdHLEdBQUcsR0FBRyxJQUFBM0MsZUFBUSxFQUFDYyxPQUFPLENBQUNULElBQUksRUFBRSxHQUFHLElBQUFKLGFBQU0sRUFBQ29CLEdBQUcsQ0FBQyxDQUFDO01BQ2xEVyxNQUFNLENBQUNyQixVQUFVLEVBQUVVLEdBQUcsRUFBRTVCLFlBQVksQ0FBQ29ELE9BQU8sQ0FBQ2UsR0FBRyxDQUFDakIsR0FBRyxDQUFDLENBQUM7TUFDdEQ7SUFDRjtJQUNBO0lBQ0EsSUFBSSxDQUFDaEUsR0FBRyxFQUFFO0lBQ1YsSUFBSSxDQUFDcUMsYUFBYSxDQUFDckMsR0FBRyxDQUFDdUMsSUFBSSxDQUFDLEVBQUU7SUFDOUJjLE1BQU0sQ0FBQ3JELEdBQUcsQ0FBQytDLE9BQU8sRUFBRS9DLEdBQUcsQ0FBQzBDLEdBQUcsRUFBRSxLQUFLLENBQUM7RUFDckMsQ0FBQyxFQUFFLENBQUNqRCxNQUFNLEVBQUVvQyxNQUFNLEVBQUV6QixRQUFRLEVBQUVOLEdBQUcsRUFBRWtDLFVBQVUsRUFBRUcsT0FBTyxFQUFFQyxZQUFZLEVBQUU1QixTQUFTLEVBQUU2QyxNQUFNLEVBQUUvRSxJQUFJLEVBQUUwQixHQUFHLEVBQUVxQyxhQUFhLENBQUMsQ0FBQztFQUVuSCxNQUFNNkMsV0FBVyxHQUFHLElBQUE1QyxrQkFBVyxFQUFDLE1BQU07SUFDcEMsSUFBSTlCLFNBQVMsSUFBSSxJQUFJLElBQUksQ0FBQ1YsR0FBRyxJQUFJa0MsVUFBVSxJQUFJLElBQUksSUFBSSxDQUFDRyxPQUFPLEVBQUU7SUFDakUsTUFBTUksSUFBSSxHQUFHL0IsU0FBUztJQUN0QkMsWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQixNQUFNaUMsR0FBRyxHQUFHLElBQUFwQixhQUFNLEVBQUN4QixHQUFHLENBQUMwRSxLQUFLLENBQUNyQyxPQUFPLENBQUNULElBQUksQ0FBQzFELE1BQU0sQ0FBQyxDQUFDLENBQUN5RyxNQUFNLENBQUNsQyxJQUFJLENBQUMsQ0FBQ21DLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDekVyQixNQUFNLENBQUNyQixVQUFVLEVBQUVVLEdBQUcsRUFBRSxLQUFLLENBQUM7RUFDaEMsQ0FBQyxFQUFFLENBQUNsQyxTQUFTLEVBQUVWLEdBQUcsRUFBRWtDLFVBQVUsRUFBRUcsT0FBTyxFQUFFa0IsTUFBTSxDQUFDLENBQUM7RUFFakQsTUFBTThCLGVBQWUsR0FBRyxJQUFBN0Msa0JBQVcsRUFBQyxNQUFNN0IsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFakU7RUFDQSxNQUFNMkUsWUFBWSxHQUNoQjlHLElBQUksS0FBSyxXQUFXLEdBQUcsTUFBTSxHQUFHQSxJQUFJLEtBQUssYUFBYSxHQUFHLGVBQWUsR0FBRyxNQUFNO0VBRW5GLE1BQU0rRyxVQUFVLEdBQUcsSUFBQTlELGNBQU8sRUFBQyxNQUFNO0lBQy9CLElBQUlNLE1BQU0sRUFBRSxPQUFPTyxZQUFZLElBQUloQyxRQUFRLENBQUMwRCxJQUFJLENBQUMsQ0FBQyxDQUFDOUYsTUFBTSxHQUFHLENBQUM7SUFDN0QsSUFBSU0sSUFBSSxLQUFLLGFBQWEsRUFBRSxPQUFPMEQsVUFBVSxJQUFJLElBQUksSUFBSSxDQUFDLENBQUNsQyxHQUFHLElBQUlBLEdBQUcsS0FBS3FDLE9BQU8sRUFBRVQsSUFBSTtJQUN2RjtJQUNBLE9BQU8sQ0FBQyxDQUFDMUIsR0FBRyxJQUFJcUMsYUFBYSxDQUFDckMsR0FBRyxDQUFDdUMsSUFBSSxDQUFDO0VBQ3pDLENBQUMsRUFBRSxDQUFDVixNQUFNLEVBQUVPLFlBQVksRUFBRWhDLFFBQVEsRUFBRTlCLElBQUksRUFBRTBELFVBQVUsRUFBRWxDLEdBQUcsRUFBRXFDLE9BQU8sRUFBRW5DLEdBQUcsRUFBRXFDLGFBQWEsQ0FBQyxDQUFDO0VBRXhGLE1BQU1pRCxjQUFjLEdBQUcsSUFBQS9ELGNBQU8sRUFBQyxNQUFNO0lBQ25DLElBQUlYLEtBQUssRUFBRSxPQUFPQSxLQUFLO0lBQ3ZCLE1BQU1qRCxLQUFLLEdBQUd3RSxPQUFPLEVBQUV4RSxLQUFLLEtBQUtxQyxHQUFHLElBQUksSUFBSSxHQUFHN0IsS0FBSyxDQUFDNkIsR0FBRyxDQUFDK0MsT0FBTyxDQUFDLEVBQUVwRixLQUFLLEdBQUdKLFNBQVMsQ0FBQztJQUNyRixJQUFJc0UsTUFBTSxFQUFFO01BQ1YsTUFBTTBELE1BQU0sR0FBR3BELE9BQU8sSUFBSXJDLEdBQUcsR0FBRyxJQUFBd0IsYUFBTSxFQUFDeEIsR0FBRyxDQUFDMEUsS0FBSyxDQUFDckMsT0FBTyxDQUFDVCxJQUFJLENBQUMxRCxNQUFNLENBQUMsQ0FBQyxDQUFDMEcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7TUFDckYsTUFBTWMsSUFBSSxHQUFHLENBQUNELE1BQU0sRUFBRW5GLFFBQVEsQ0FBQyxDQUFDdEMsTUFBTSxDQUFDMkgsT0FBTyxDQUFDLENBQUNmLElBQUksQ0FBQyxHQUFHLENBQUM7TUFDekQsSUFBSSxDQUFDYyxJQUFJLElBQUksQ0FBQzdILEtBQUssRUFBRSxPQUFPLGdDQUFnQztNQUM1RCxPQUFPLEdBQUdBLEtBQUssTUFBTTZILElBQUksRUFBRTtJQUM3QjtJQUNBLElBQUlsSCxJQUFJLEtBQUssYUFBYSxFQUFFO01BQzFCLE1BQU1vRSxHQUFHLEdBQUdQLE9BQU8sSUFBSXJDLEdBQUcsR0FBRyxJQUFBd0IsYUFBTSxFQUFDeEIsR0FBRyxDQUFDMEUsS0FBSyxDQUFDckMsT0FBTyxDQUFDVCxJQUFJLENBQUMxRCxNQUFNLENBQUMsQ0FBQyxDQUFDMEcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7TUFDbEYsSUFBSSxDQUFDaEMsR0FBRyxJQUFJLENBQUMvRSxLQUFLLEVBQUUsT0FBTyw2QkFBNkI7TUFDeEQsT0FBTyxHQUFHQSxLQUFLLE1BQU0rRSxHQUFHLEVBQUU7SUFDNUI7SUFDQSxJQUFJLENBQUMxQyxHQUFHLEVBQUUsT0FBTyxnQkFBZ0I7SUFDakMsT0FBTyxHQUFHN0IsS0FBSyxDQUFDNkIsR0FBRyxDQUFDK0MsT0FBTyxDQUFDLEVBQUVwRixLQUFLLElBQUksRUFBRSxNQUFNcUMsR0FBRyxDQUFDMEMsR0FBRyxFQUFFO0VBQzFELENBQUMsRUFBRSxDQUFDOUIsS0FBSyxFQUFFdUIsT0FBTyxFQUFFckMsR0FBRyxFQUFFK0IsTUFBTSxFQUFFekIsUUFBUSxFQUFFOUIsSUFBSSxFQUFFMEIsR0FBRyxFQUFFN0IsS0FBSyxDQUFDLENBQUM7O0VBRTdEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU11SCxRQUFRLEdBQUc1RixHQUFHLElBQUksSUFBSTtFQUM1QixNQUFNNkYsVUFBVSxHQUFHLElBQUFyRCxrQkFBVyxFQUFDLE1BQU07SUFDbkN2QyxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ1pFLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDWk0sZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0VBQ3hCLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixPQUFPO0lBQ0xxRixLQUFLLEVBQUUsQ0FBQyxDQUFDbkcsTUFBTTtJQUNmRyxPQUFPO0lBQ1BMLFVBQVU7SUFDVmpCLElBQUk7SUFDSlUsS0FBSyxFQUNIUyxNQUFNLEVBQUVULEtBQUssS0FDWlYsSUFBSSxLQUFLLFdBQVcsR0FBRyxXQUFXLEdBQUdBLElBQUksS0FBSyxhQUFhLEdBQUcsZUFBZSxHQUFHLFdBQVcsQ0FBQztJQUMvRnVELE1BQU07SUFDTkMsVUFBVTtJQUNWK0QsV0FBVyxFQUFFOUQsWUFBWSxFQUFFcEUsS0FBSyxJQUFJLFdBQVc7SUFDL0N1RixXQUFXO0lBQ1gvRCxpQkFBaUI7SUFDakJoQixLQUFLO0lBQ0x3RCxhQUFhO0lBQ2I3QixHQUFHO0lBQ0gyQyxVQUFVO0lBQ1ZRLFFBQVE7SUFDUkwsVUFBVTtJQUNWdEMsYUFBYTtJQUNiQyxnQkFBZ0I7SUFDaEJvRCxjQUFjO0lBQ2RFLGVBQWU7SUFDZkQsZUFBZTtJQUNmeEQsUUFBUTtJQUNSQyxXQUFXO0lBQ1hHLFNBQVM7SUFDVDBFLFdBQVc7SUFDWEMsZUFBZTtJQUNmRSxVQUFVO0lBQ1ZELFlBQVk7SUFDWkUsY0FBYztJQUNkaEIsT0FBTztJQUNQWixNQUFNO0lBQ05oRCxJQUFJO0lBQ0pFLEtBQUs7SUFDTDhFLFFBQVE7SUFDUkM7RUFDRixDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=