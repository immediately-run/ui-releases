var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = OverwriteConfirm;
var _context = require("../lib/context");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // In-dialog overwrite confirmation for save-file (spec §1.1: overwrite requires
// an explicit confirm). Rendered inside the picker's own region — not host chrome.
function OverwriteConfirm() {
  _s();
  const c = (0, _context.useController)();
  if (c.overwrite == null) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "fs-overlay",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": "Confirm overwrite",
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "fs-confirm",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "fs-confirm-title",
        children: ["Replace ", c.overwrite, "?"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "fs-confirm-body",
        children: "A file with this name already exists in this folder. Saving will overwrite it."
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "fs-confirm-actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "fs-btn fs-btn-quiet",
          onClick: c.cancelOverwrite,
          children: "Keep both"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "fs-btn fs-btn-primary",
          onClick: c.doOverwrite,
          children: "Replace"
        })]
      })]
    })
  });
}
_s(OverwriteConfirm, "EpRKP5YlLygKruAQ/BiYBiBA7QE=", false, function () {
  return [_context.useController];
});
_c = OverwriteConfirm;
var _c;
$RefreshReg$(_c, "OverwriteConfirm");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29udGV4dCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiT3ZlcndyaXRlQ29uZmlybSIsImMiLCJ1c2VDb250cm9sbGVyIiwib3ZlcndyaXRlIiwianN4IiwiY2xhc3NOYW1lIiwicm9sZSIsImNoaWxkcmVuIiwianN4cyIsInR5cGUiLCJvbkNsaWNrIiwiY2FuY2VsT3ZlcndyaXRlIiwiZG9PdmVyd3JpdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk92ZXJ3cml0ZUNvbmZpcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNvbnRyb2xsZXIgfSBmcm9tICcuLi9saWIvY29udGV4dCc7XG5cbi8vIEluLWRpYWxvZyBvdmVyd3JpdGUgY29uZmlybWF0aW9uIGZvciBzYXZlLWZpbGUgKHNwZWMgwqcxLjE6IG92ZXJ3cml0ZSByZXF1aXJlc1xuLy8gYW4gZXhwbGljaXQgY29uZmlybSkuIFJlbmRlcmVkIGluc2lkZSB0aGUgcGlja2VyJ3Mgb3duIHJlZ2lvbiDigJQgbm90IGhvc3QgY2hyb21lLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gT3ZlcndyaXRlQ29uZmlybSgpIHtcbiAgY29uc3QgYyA9IHVzZUNvbnRyb2xsZXIoKTtcbiAgaWYgKGMub3ZlcndyaXRlID09IG51bGwpIHJldHVybiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtb3ZlcmxheVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJDb25maXJtIG92ZXJ3cml0ZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmcy1jb25maXJtXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtY29uZmlybS10aXRsZVwiPlJlcGxhY2Uge2Mub3ZlcndyaXRlfT88L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmcy1jb25maXJtLWJvZHlcIj5cbiAgICAgICAgICBBIGZpbGUgd2l0aCB0aGlzIG5hbWUgYWxyZWFkeSBleGlzdHMgaW4gdGhpcyBmb2xkZXIuIFNhdmluZyB3aWxsIG92ZXJ3cml0ZSBpdC5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnMtY29uZmlybS1hY3Rpb25zXCI+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZnMtYnRuIGZzLWJ0bi1xdWlldFwiIG9uQ2xpY2s9e2MuY2FuY2VsT3ZlcndyaXRlfT5cbiAgICAgICAgICAgIEtlZXAgYm90aFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImZzLWJ0biBmcy1idG4tcHJpbWFyeVwiIG9uQ2xpY2s9e2MuZG9PdmVyd3JpdGV9PlxuICAgICAgICAgICAgUmVwbGFjZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxRQUFBLEdBQUFDLE9BQUE7QUFBK0MsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsSUFBQUUsRUFBQSxHQUFBQyxZQUFBLElBRS9DO0FBQ0E7QUFDZSxTQUFTQyxnQkFBZ0JBLENBQUEsRUFBRztFQUFBRixFQUFBO0VBQ3pDLE1BQU1HLENBQUMsR0FBRyxJQUFBQyxzQkFBYSxFQUFDLENBQUM7RUFDekIsSUFBSUQsQ0FBQyxDQUFDRSxTQUFTLElBQUksSUFBSSxFQUFFLE9BQU8sSUFBSTtFQUNwQyxvQkFDRSxJQUFBTixXQUFBLENBQUFPLEdBQUE7SUFBS0MsU0FBUyxFQUFDLFlBQVk7SUFBQ0MsSUFBSSxFQUFDLFFBQVE7SUFBQyxjQUFXLE1BQU07SUFBQyxjQUFXLG1CQUFtQjtJQUFBQyxRQUFBLGVBQ3hGLElBQUFWLFdBQUEsQ0FBQVcsSUFBQTtNQUFLSCxTQUFTLEVBQUMsWUFBWTtNQUFBRSxRQUFBLGdCQUN6QixJQUFBVixXQUFBLENBQUFXLElBQUE7UUFBS0gsU0FBUyxFQUFDLGtCQUFrQjtRQUFBRSxRQUFBLEdBQUMsVUFBUSxFQUFDTixDQUFDLENBQUNFLFNBQVMsRUFBQyxHQUFDO01BQUEsQ0FBSyxDQUFDLGVBQzlELElBQUFOLFdBQUEsQ0FBQU8sR0FBQTtRQUFLQyxTQUFTLEVBQUMsaUJBQWlCO1FBQUFFLFFBQUEsRUFBQztNQUVqQyxDQUFLLENBQUMsZUFDTixJQUFBVixXQUFBLENBQUFXLElBQUE7UUFBS0gsU0FBUyxFQUFDLG9CQUFvQjtRQUFBRSxRQUFBLGdCQUNqQyxJQUFBVixXQUFBLENBQUFPLEdBQUE7VUFBUUssSUFBSSxFQUFDLFFBQVE7VUFBQ0osU0FBUyxFQUFDLHFCQUFxQjtVQUFDSyxPQUFPLEVBQUVULENBQUMsQ0FBQ1UsZUFBZ0I7VUFBQUosUUFBQSxFQUFDO1FBRWxGLENBQVEsQ0FBQyxlQUNULElBQUFWLFdBQUEsQ0FBQU8sR0FBQTtVQUFRSyxJQUFJLEVBQUMsUUFBUTtVQUFDSixTQUFTLEVBQUMsdUJBQXVCO1VBQUNLLE9BQU8sRUFBRVQsQ0FBQyxDQUFDVyxXQUFZO1VBQUFMLFFBQUEsRUFBQztRQUVoRixDQUFRLENBQUM7TUFBQSxDQUNOLENBQUM7SUFBQSxDQUNIO0VBQUMsQ0FDSCxDQUFDO0FBRVY7QUFBQ1QsRUFBQSxDQXJCdUJFLGdCQUFnQjtFQUFBLFFBQzVCRSxzQkFBYTtBQUFBO0FBQUFXLEVBQUEsR0FERGIsZ0JBQWdCO0FBQUEsSUFBQWEsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}