"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
var _rollup = _interopRequireDefault(require("@mdx-js/rollup"));
var _devFs = require("@immediately-run/dev-fs");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// MDX must run before @vitejs/plugin-react so the JSX it emits is handled by
// React's transform (Fast Refresh included). immediately.run processes .mdx
// natively; this wiring keeps the local `vite dev`/`build` in sync.
//
// devFs() (@immediately-run/dev-fs) makes `import ... from 'fs'` work during
// local `vite dev`, bridging the same async ZenFS surface immediately.run
// provides to your real disk. It is dev-only and absent from production builds.
// https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)({
  plugins: [(0, _devFs.devFs)(), {
    enforce: 'pre',
    ...(0, _rollup.default)()
  }, (0, _pluginReact.default)()]
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX3JvbGx1cCIsIl9kZXZGcyIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmluZUNvbmZpZyIsInBsdWdpbnMiLCJkZXZGcyIsImVuZm9yY2UiLCJtZHgiLCJyZWFjdCJdLCJzb3VyY2VzIjpbInZpdGUuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gJ3ZpdGUnXG5pbXBvcnQgcmVhY3QgZnJvbSAnQHZpdGVqcy9wbHVnaW4tcmVhY3QnXG5pbXBvcnQgbWR4IGZyb20gJ0BtZHgtanMvcm9sbHVwJ1xuaW1wb3J0IHsgZGV2RnMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL2Rldi1mcydcblxuLy8gTURYIG11c3QgcnVuIGJlZm9yZSBAdml0ZWpzL3BsdWdpbi1yZWFjdCBzbyB0aGUgSlNYIGl0IGVtaXRzIGlzIGhhbmRsZWQgYnlcbi8vIFJlYWN0J3MgdHJhbnNmb3JtIChGYXN0IFJlZnJlc2ggaW5jbHVkZWQpLiBpbW1lZGlhdGVseS5ydW4gcHJvY2Vzc2VzIC5tZHhcbi8vIG5hdGl2ZWx5OyB0aGlzIHdpcmluZyBrZWVwcyB0aGUgbG9jYWwgYHZpdGUgZGV2YC9gYnVpbGRgIGluIHN5bmMuXG4vL1xuLy8gZGV2RnMoKSAoQGltbWVkaWF0ZWx5LXJ1bi9kZXYtZnMpIG1ha2VzIGBpbXBvcnQgLi4uIGZyb20gJ2ZzJ2Agd29yayBkdXJpbmdcbi8vIGxvY2FsIGB2aXRlIGRldmAsIGJyaWRnaW5nIHRoZSBzYW1lIGFzeW5jIFplbkZTIHN1cmZhY2UgaW1tZWRpYXRlbHkucnVuXG4vLyBwcm92aWRlcyB0byB5b3VyIHJlYWwgZGlzay4gSXQgaXMgZGV2LW9ubHkgYW5kIGFic2VudCBmcm9tIHByb2R1Y3Rpb24gYnVpbGRzLlxuLy8gaHR0cHM6Ly92aXRlLmRldi9jb25maWcvXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbXG4gICAgZGV2RnMoKSxcbiAgICB7IGVuZm9yY2U6ICdwcmUnLCAuLi5tZHgoKSB9LFxuICAgIHJlYWN0KCksXG4gIF0sXG59KVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFELHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBSSxNQUFBLEdBQUFKLE9BQUE7QUFBK0MsU0FBQUUsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsa0JBQVksRUFBQztFQUMxQkMsT0FBTyxFQUFFLENBQ1AsSUFBQUMsWUFBSyxFQUFDLENBQUMsRUFDUDtJQUFFQyxPQUFPLEVBQUUsS0FBSztJQUFFLEdBQUcsSUFBQUMsZUFBRyxFQUFDO0VBQUUsQ0FBQyxFQUM1QixJQUFBQyxvQkFBSyxFQUFDLENBQUM7QUFFWCxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=