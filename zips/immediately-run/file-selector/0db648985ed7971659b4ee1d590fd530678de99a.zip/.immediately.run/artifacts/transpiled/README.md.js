var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-starter-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-starter-template"
      }), "immediately.run — starter template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ready-to-run starter for building apps on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), ": React + TypeScript + Vite, wired to\nthe brand design system, with the project layout immediately.run expects."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "try-it-instantly",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "try-it-instantly"
      }), "Try it instantly"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Try this template on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run/present/github/immediately-run/new-project-template/main/files/src/App.tsx",
        children: "immediately.run"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Using this as a starting point for your own app? After you push to your repo,\nupdate the link above to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "https://immediately.run/present/github/<owner>/<repo>/<ref>/files/src/App.tsx"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "use-this-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "use-this-template"
      }), "Use this template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Create a new repo from this template (or copy the files)."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm install"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run dev"
        }), " and start editing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Push to GitHub and open it on immediately.run with the link above."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "fast-loading-on-immediatelyrun-auto-cache",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "fast-loading-on-immediatelyrun-auto-cache"
      }), "Fast loading on immediately.run (auto-cache)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run normally reads your sources from the GitHub API, which is slow\nand rate-limited for anonymous visitors. This template ships a GitHub Action\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./.github/workflows/cache.yml",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".github/workflows/cache.yml"
        })
      }), ") that, on every\npush to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", builds a pre-cached zip of your repo and publishes it to your\nrepo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "own GitHub Pages"
      }), ". immediately.run finds it automatically at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), " and loads from\nthere — falling back to the API if it's missing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The cache also embeds a manifest sidecar, so visitors can push edits back to\nGitHub even when the app was loaded from the zip."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "One-time setup:"
      }), " in your repo, go to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Settings → Pages → Build and deployment"
      }), "\nand set ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Source"
      }), " to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "GitHub Actions"
      }), ". Push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), " and the workflow does\nthe rest. (The cache may lag a push by up to ~10 minutes of GitHub Pages CDN\ncaching.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "always-run-the-newest-commit",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "always-run-the-newest-commit"
      }), "Always run the newest commit"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["By default the cached version is served even if it's a few minutes behind\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ". If your app must always reflect the very latest commit, add this to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "{\n  \"immediately.run\": {\n    \"requireLatest\": true\n  }\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "immediately.run still boots instantly from the cache, then checks in the\nbackground (one API request) whether the cache is current and, if not, reloads\nfrom GitHub."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-its-organized",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-its-organized"
      }), "How it's organized"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run renders the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["default export of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        })]
      }), " — that's the\nentry point, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/\n  main.tsx              # local vite dev/build entry only — immediately.run IGNORES this\n  App.tsx               # ROOT: default export + imports the global CSS\n  index.css             # fonts, design tokens (dark + light), resets\n  App.css               # layout + component styles\n  mdx.d.ts              # type shim so `import X from './x.mdx'` works\n  components/           # one default-exported React component per file\n  data/                 # typed data arrays (NO components/JSX here)\n  hooks/                # custom hooks (NO components here)\n  assets/               # images you import, e.g. import logo from './assets/logo.png'\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The included page shows the core patterns: a data array mapped to cards\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data/features.ts"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/Features.tsx"
      }), "), a custom hook\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hooks/useTheme.ts"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/ThemeSwitch.tsx"
      }), "), and local React state\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/Counter.tsx"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "filesystem-access-fs",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "filesystem-access-fs"
      }), "Filesystem access (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run apps can read and write a filesystem by importing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs"
      }), " (async\nonly — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs.promises.*"
      }), " and callback style). This template has local-dev support\nfor it built in via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://github.com/immediately-run/dev-fs",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/dev-fs"
        })
      }), ",\na Vite plugin (already wired into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite.config.ts"
      }), ") that bridges the same\nfilesystem to your real local disk during ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ". See that repo for the\nsupported API and details."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "import fs from 'fs'\n\nawait fs.promises.writeFile('/data/notes.txt', 'hello', 'utf8')\nconst text = await fs.promises.readFile('/data/notes.txt', 'utf8')\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), " runs a one-off round-trip smoke test in dev — check the browser\nconsole for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[dev-fs]"
      }), " group, and delete it freely."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-rules-that-keep-it-working-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-rules-that-keep-it-working-on-immediatelyrun"
      }), "The rules that keep it working on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./CLAUDE.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        })
      }), " for the full list. The essentials:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Global CSS is imported from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          }), ", never only from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main.tsx"
          }), "."]
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A file that exports a component exports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "only"
          }), " components"]
        }), " — data, consts,\nand helpers go in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hooks/"
        }), ", or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " enforces this."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull colors, fonts, radii, and shadows from the tokens in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "index.css"
          })]
        }), "\nrather than hard-coding values."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Requires Node.js 20.19+ or 22.12+."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm install\nnpm run dev      # local dev server\nnpm run build    # tsc -b && vite build — must pass with no type errors\nnpm run lint     # eslint — enforces the React Fast Refresh / HMR rule\nnpm run preview  # serve the production build\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImxpIiwib2wiLCJwIiwicHJlIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImltbWVkaWF0ZWx5cnVuLXN0YXJ0ZXItdGVtcGxhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImltbWVkaWF0ZWx5cnVuLXN0YXJ0ZXItdGVtcGxhdGVcIiAvPntcImltbWVkaWF0ZWx5LnJ1biDigJQgc3RhcnRlciB0ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSByZWFkeS10by1ydW4gc3RhcnRlciBmb3IgYnVpbGRpbmcgYXBwcyBvblxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCI6IFJlYWN0ICsgVHlwZVNjcmlwdCArIFZpdGUsIHdpcmVkIHRvXFxudGhlIGJyYW5kIGRlc2lnbiBzeXN0ZW0sIHdpdGggdGhlIHByb2plY3QgbGF5b3V0IGltbWVkaWF0ZWx5LnJ1biBleHBlY3RzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0cnktaXQtaW5zdGFudGx5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0cnktaXQtaW5zdGFudGx5XCIgLz57XCJUcnkgaXQgaW5zdGFudGx5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUcnkgdGhpcyB0ZW1wbGF0ZSBvbiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvaW1tZWRpYXRlbHktcnVuL25ldy1wcm9qZWN0LXRlbXBsYXRlL21haW4vZmlsZXMvc3JjL0FwcC50c3hcIj57XCJpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlVzaW5nIHRoaXMgYXMgYSBzdGFydGluZyBwb2ludCBmb3IgeW91ciBvd24gYXBwPyBBZnRlciB5b3UgcHVzaCB0byB5b3VyIHJlcG8sXFxudXBkYXRlIHRoZSBsaW5rIGFib3ZlIHRvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvPG93bmVyPi88cmVwbz4vPHJlZj4vZmlsZXMvc3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidXNlLXRoaXMtdGVtcGxhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInVzZS10aGlzLXRlbXBsYXRlXCIgLz57XCJVc2UgdGhpcyB0ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDcmVhdGUgYSBuZXcgcmVwbyBmcm9tIHRoaXMgdGVtcGxhdGUgKG9yIGNvcHkgdGhlIGZpbGVzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gaW5zdGFsbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHN0YXJ0IGVkaXRpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlB1c2ggdG8gR2l0SHViIGFuZCBvcGVuIGl0IG9uIGltbWVkaWF0ZWx5LnJ1biB3aXRoIHRoZSBsaW5rIGFib3ZlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmYXN0LWxvYWRpbmctb24taW1tZWRpYXRlbHlydW4tYXV0by1jYWNoZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmFzdC1sb2FkaW5nLW9uLWltbWVkaWF0ZWx5cnVuLWF1dG8tY2FjaGVcIiAvPntcIkZhc3QgbG9hZGluZyBvbiBpbW1lZGlhdGVseS5ydW4gKGF1dG8tY2FjaGUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJpbW1lZGlhdGVseS5ydW4gbm9ybWFsbHkgcmVhZHMgeW91ciBzb3VyY2VzIGZyb20gdGhlIEdpdEh1YiBBUEksIHdoaWNoIGlzIHNsb3dcXG5hbmQgcmF0ZS1saW1pdGVkIGZvciBhbm9ueW1vdXMgdmlzaXRvcnMuIFRoaXMgdGVtcGxhdGUgc2hpcHMgYSBHaXRIdWIgQWN0aW9uXFxuKFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLy5naXRodWIvd29ya2Zsb3dzL2NhY2hlLnltbFwiPjxfY29tcG9uZW50cy5jb2RlPntcIi5naXRodWIvd29ya2Zsb3dzL2NhY2hlLnltbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiKSB0aGF0LCBvbiBldmVyeVxcbnB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGJ1aWxkcyBhIHByZS1jYWNoZWQgemlwIG9mIHlvdXIgcmVwbyBhbmQgcHVibGlzaGVzIGl0IHRvIHlvdXJcXG5yZXBvJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvd24gR2l0SHViIFBhZ2VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBpbW1lZGlhdGVseS5ydW4gZmluZHMgaXQgYXV0b21hdGljYWxseSBhdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vPG93bmVyPi5naXRodWIuaW8vPHJlcG8+L2NhY2hlZF9yZXBvc2l0b3JpZXMvbWFpbi56aXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBsb2FkcyBmcm9tXFxudGhlcmUg4oCUIGZhbGxpbmcgYmFjayB0byB0aGUgQVBJIGlmIGl0J3MgbWlzc2luZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNhY2hlIGFsc28gZW1iZWRzIGEgbWFuaWZlc3Qgc2lkZWNhciwgc28gdmlzaXRvcnMgY2FuIHB1c2ggZWRpdHMgYmFjayB0b1xcbkdpdEh1YiBldmVuIHdoZW4gdGhlIGFwcCB3YXMgbG9hZGVkIGZyb20gdGhlIHppcC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPbmUtdGltZSBzZXR1cDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4geW91ciByZXBvLCBnbyB0byBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNldHRpbmdzIOKGkiBQYWdlcyDihpIgQnVpbGQgYW5kIGRlcGxveW1lbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5hbmQgc2V0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiU291cmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2l0SHViIEFjdGlvbnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSB3b3JrZmxvdyBkb2VzXFxudGhlIHJlc3QuIChUaGUgY2FjaGUgbWF5IGxhZyBhIHB1c2ggYnkgdXAgdG8gfjEwIG1pbnV0ZXMgb2YgR2l0SHViIFBhZ2VzIENETlxcbmNhY2hpbmcuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJhbHdheXMtcnVuLXRoZS1uZXdlc3QtY29tbWl0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhbHdheXMtcnVuLXRoZS1uZXdlc3QtY29tbWl0XCIgLz57XCJBbHdheXMgcnVuIHRoZSBuZXdlc3QgY29tbWl0XCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJCeSBkZWZhdWx0IHRoZSBjYWNoZWQgdmVyc2lvbiBpcyBzZXJ2ZWQgZXZlbiBpZiBpdCdzIGEgZmV3IG1pbnV0ZXMgYmVoaW5kXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIElmIHlvdXIgYXBwIG11c3QgYWx3YXlzIHJlZmxlY3QgdGhlIHZlcnkgbGF0ZXN0IGNvbW1pdCwgYWRkIHRoaXMgdG9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWpzb25jXCI+e1wie1xcbiAgXFxcImltbWVkaWF0ZWx5LnJ1blxcXCI6IHtcXG4gICAgXFxcInJlcXVpcmVMYXRlc3RcXFwiOiB0cnVlXFxuICB9XFxufVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJpbW1lZGlhdGVseS5ydW4gc3RpbGwgYm9vdHMgaW5zdGFudGx5IGZyb20gdGhlIGNhY2hlLCB0aGVuIGNoZWNrcyBpbiB0aGVcXG5iYWNrZ3JvdW5kIChvbmUgQVBJIHJlcXVlc3QpIHdoZXRoZXIgdGhlIGNhY2hlIGlzIGN1cnJlbnQgYW5kLCBpZiBub3QsIHJlbG9hZHNcXG5mcm9tIEdpdEh1Yi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaG93LWl0cy1vcmdhbml6ZWRcIj48SGVhZGluZ0FuY2hvciBpZD1cImhvdy1pdHMtb3JnYW5pemVkXCIgLz57XCJIb3cgaXQncyBvcmdhbml6ZWRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcImltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmF1bHQgZXhwb3J0IG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhhdCdzIHRoZVxcbmVudHJ5IHBvaW50LCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9cXG4gIG1haW4udHN4ICAgICAgICAgICAgICAjIGxvY2FsIHZpdGUgZGV2L2J1aWxkIGVudHJ5IG9ubHkg4oCUIGltbWVkaWF0ZWx5LnJ1biBJR05PUkVTIHRoaXNcXG4gIEFwcC50c3ggICAgICAgICAgICAgICAjIFJPT1Q6IGRlZmF1bHQgZXhwb3J0ICsgaW1wb3J0cyB0aGUgZ2xvYmFsIENTU1xcbiAgaW5kZXguY3NzICAgICAgICAgICAgICMgZm9udHMsIGRlc2lnbiB0b2tlbnMgKGRhcmsgKyBsaWdodCksIHJlc2V0c1xcbiAgQXBwLmNzcyAgICAgICAgICAgICAgICMgbGF5b3V0ICsgY29tcG9uZW50IHN0eWxlc1xcbiAgbWR4LmQudHMgICAgICAgICAgICAgICMgdHlwZSBzaGltIHNvIGBpbXBvcnQgWCBmcm9tICcuL3gubWR4J2Agd29ya3NcXG4gIGNvbXBvbmVudHMvICAgICAgICAgICAjIG9uZSBkZWZhdWx0LWV4cG9ydGVkIFJlYWN0IGNvbXBvbmVudCBwZXIgZmlsZVxcbiAgZGF0YS8gICAgICAgICAgICAgICAgICMgdHlwZWQgZGF0YSBhcnJheXMgKE5PIGNvbXBvbmVudHMvSlNYIGhlcmUpXFxuICBob29rcy8gICAgICAgICAgICAgICAgIyBjdXN0b20gaG9va3MgKE5PIGNvbXBvbmVudHMgaGVyZSlcXG4gIGFzc2V0cy8gICAgICAgICAgICAgICAjIGltYWdlcyB5b3UgaW1wb3J0LCBlLmcuIGltcG9ydCBsb2dvIGZyb20gJy4vYXNzZXRzL2xvZ28ucG5nJ1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgaW5jbHVkZWQgcGFnZSBzaG93cyB0aGUgY29yZSBwYXR0ZXJuczogYSBkYXRhIGFycmF5IG1hcHBlZCB0byBjYXJkc1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhL2ZlYXR1cmVzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50cy9GZWF0dXJlcy50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYSBjdXN0b20gaG9va1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJob29rcy91c2VUaGVtZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHMvVGhlbWVTd2l0Y2gudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFuZCBsb2NhbCBSZWFjdCBzdGF0ZVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb25lbnRzL0NvdW50ZXIudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImZpbGVzeXN0ZW0tYWNjZXNzLWZzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaWxlc3lzdGVtLWFjY2Vzcy1mc1wiIC8+e1wiRmlsZXN5c3RlbSBhY2Nlc3MgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcImltbWVkaWF0ZWx5LnJ1biBhcHBzIGNhbiByZWFkIGFuZCB3cml0ZSBhIGZpbGVzeXN0ZW0gYnkgaW1wb3J0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYXN5bmNcXG5vbmx5IOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcy5wcm9taXNlcy4qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgY2FsbGJhY2sgc3R5bGUpLiBUaGlzIHRlbXBsYXRlIGhhcyBsb2NhbC1kZXYgc3VwcG9ydFxcbmZvciBpdCBidWlsdCBpbiB2aWEgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9pbW1lZGlhdGVseS1ydW4vZGV2LWZzXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9kZXYtZnNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIixcXG5hIFZpdGUgcGx1Z2luIChhbHJlYWR5IHdpcmVkIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZS5jb25maWcudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSB0aGF0IGJyaWRnZXMgdGhlIHNhbWVcXG5maWxlc3lzdGVtIHRvIHlvdXIgcmVhbCBsb2NhbCBkaXNrIGR1cmluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFNlZSB0aGF0IHJlcG8gZm9yIHRoZVxcbnN1cHBvcnRlZCBBUEkgYW5kIGRldGFpbHMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtdHNcIj57XCJpbXBvcnQgZnMgZnJvbSAnZnMnXFxuXFxuYXdhaXQgZnMucHJvbWlzZXMud3JpdGVGaWxlKCcvZGF0YS9ub3Rlcy50eHQnLCAnaGVsbG8nLCAndXRmOCcpXFxuY29uc3QgdGV4dCA9IGF3YWl0IGZzLnByb21pc2VzLnJlYWRGaWxlKCcvZGF0YS9ub3Rlcy50eHQnLCAndXRmOCcpXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIm1haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW5zIGEgb25lLW9mZiByb3VuZC10cmlwIHNtb2tlIHRlc3QgaW4gZGV2IOKAlCBjaGVjayB0aGUgYnJvd3NlclxcbmNvbnNvbGUgZm9yIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbZGV2LWZzXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ3JvdXAsIGFuZCBkZWxldGUgaXQgZnJlZWx5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtcnVsZXMtdGhhdC1rZWVwLWl0LXdvcmtpbmctb24taW1tZWRpYXRlbHlydW5cIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1ydWxlcy10aGF0LWtlZXAtaXQtd29ya2luZy1vbi1pbW1lZGlhdGVseXJ1blwiIC8+e1wiVGhlIHJ1bGVzIHRoYXQga2VlcCBpdCB3b3JraW5nIG9uIGltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU2VlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuL0NMQVVERS5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIkNMQVVERS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIGZvciB0aGUgZnVsbCBsaXN0LiBUaGUgZXNzZW50aWFsczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdsb2JhbCBDU1MgaXMgaW1wb3J0ZWQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbmV2ZXIgb25seSBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZmlsZSB0aGF0IGV4cG9ydHMgYSBjb21wb25lbnQgZXhwb3J0cyBcIn08X2NvbXBvbmVudHMuZW0+e1wib25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvbXBvbmVudHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRhdGEsIGNvbnN0cyxcXG5hbmQgaGVscGVycyBnbyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImhvb2tzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVuZm9yY2VzIHRoaXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQdWxsIGNvbG9ycywgZm9udHMsIHJhZGlpLCBhbmQgc2hhZG93cyBmcm9tIHRoZSB0b2tlbnMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbnJhdGhlciB0aGFuIGhhcmQtY29kaW5nIHZhbHVlcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGV2ZWxvcFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGV2ZWxvcFwiIC8+e1wiRGV2ZWxvcFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVxdWlyZXMgTm9kZS5qcyAyMC4xOSsgb3IgMjIuMTIrLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCJucG0gaW5zdGFsbFxcbm5wbSBydW4gZGV2ICAgICAgIyBsb2NhbCBkZXYgc2VydmVyXFxubnBtIHJ1biBidWlsZCAgICAjIHRzYyAtYiAmJiB2aXRlIGJ1aWxkIOKAlCBtdXN0IHBhc3Mgd2l0aCBubyB0eXBlIGVycm9yc1xcbm5wbSBydW4gbGludCAgICAgIyBlc2xpbnQg4oCUIGVuZm9yY2VzIHRoZSBSZWFjdCBGYXN0IFJlZnJlc2ggLyBITVIgcnVsZVxcbm5wbSBydW4gcHJldmlldyAgIyBzZXJ2ZSB0aGUgcHJvZHVjdGlvbiBidWlsZFxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHaEIsV0FBVztFQUNoQyxJQUFJLENBQUNnQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXBCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQXJCLFdBQUEsQ0FBQXNCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSyxFQUFFO01BQUNnQixFQUFFLEVBQUMsaUNBQWlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUMsQ0FBRSxDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMseUJBQXlCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsa0hBQWtIO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxrQkFBa0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrQixDQUFFLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLHVCQUF1QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7UUFBQ3NCLElBQUksRUFBQyxvR0FBb0c7UUFBQUgsUUFBQSxFQUFFO01BQWlCLENBQWdCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsR0FBRSwyR0FBMkcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBK0UsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEVBQUU7TUFBMkQsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYSxDQUFtQjtNQUFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEVBQUU7TUFBb0UsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLDJDQUEyQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJDLENBQUUsQ0FBQyxFQUFDLDhDQUE4QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsaUtBQWlLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLCtCQUErQjtRQUFBSCxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQTZCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBK0QsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBaUksQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXlDLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWdCLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDYyxFQUFFLEVBQUMsOEJBQThCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBOEIsQ0FBRSxDQUFDLEVBQUMsOEJBQThCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSw2RUFBNkUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQ3FCLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUosUUFBQSxFQUFFO01BQW9FLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUF3SyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLG1CQUFtQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW1CLENBQUUsQ0FBQyxFQUFDLG9CQUFvQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQztNQUFBLENBQW9CLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQW1wQixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsNEVBQTRFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXlCLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsc0JBQXNCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0IsQ0FBRSxDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLG9FQUFvRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsaUZBQWlGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLDJDQUEyQztRQUFBSCxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXlCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMscURBQXFEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUNxQixTQUFTLEVBQUMsYUFBYTtRQUFBSixRQUFBLEVBQUU7TUFBOEosQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsa0RBQWtEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0QsQ0FBRSxDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLGFBQWE7UUFBQUgsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMscUNBQXFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVMsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFVLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBcUI7TUFBQyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsR0FBRSwwQ0FBMEMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1lBQUFnQixRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLEVBQUMsYUFBYTtRQUFBLENBQXFCLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsNERBQTRELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxtQ0FBbUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsU0FBUztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsU0FBUztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBb0MsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUNxQixTQUFTLEVBQUMsZUFBZTtRQUFBSixRQUFBLEVBQUU7TUFBb1AsQ0FBbUI7SUFBQyxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3g5UjtBQUNlLFNBQVNLLFVBQVVBLENBQUMxQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2YsS0FBSyxDQUFDZ0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBOUIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBSzVCLEtBQUs7SUFBQXFCLFFBQUEsZUFBRSxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDeEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzZCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}