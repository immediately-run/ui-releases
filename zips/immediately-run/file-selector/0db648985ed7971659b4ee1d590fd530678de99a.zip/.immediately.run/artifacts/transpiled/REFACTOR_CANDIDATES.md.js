var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "findings-file-selector",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "findings-file-selector"
      }), "FINDINGS — file-selector"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Recorded by the 2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ").\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Record / verify only."
      }), " Gates green (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "spec-refs-phase-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "spec-refs-phase-1"
      }), "Spec-refs (Phase 1)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides: pick-file@1.0"
      }), ". ~11 spec-refs across ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FileSelector.tsx"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hooks/useFileSelector.ts"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lib/"
      }), ". Cited specs: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pick-file task"
      }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PICK_FILE_TASK_SPEC"
      }), ", which lives in the whiteboard-app docs subdir — NOT in the\nmain ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/"
      }), " checkout, so not fully resolvable here) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS"
      }), " tasks\n§5.7. Verify at execution that any opaque ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "plan Phase N"
      }), " pointers are replaced with\nthe real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PICK_FILE_TASK_SPEC §"
      }), " where one exists. The app uses\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useTaskInput"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "completeTask"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cancelTask"
      }), " and handles cancellation/absence —\nDone-spec ↔ code mapping checks out (dev-fs + MDX wired)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sdk-version-skew-record-only",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sdk-version-skew-record-only"
      }), "SDK-version skew (record only)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.8.1"
        })
      }), " (fleet spread: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.2.8"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.8.1"
      }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.11.0"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.12.0"
      }), "). Coordinated bump owed; do not bump here."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "vocabulary-phase-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "vocabulary-phase-2"
      }), "Vocabulary (Phase 2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "kernel"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "principal"
      }), "-as-grantee found in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/"
      }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), " dev-only.\nConformant. (file-selector has a vitest suite for its hooks — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), " applies.)"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/REFACTOR_CANDIDATES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsInAiLCJzdHJvbmciLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVGQUNUT1JfQ0FORElEQVRFUy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJmaW5kaW5ncy1maWxlLXNlbGVjdG9yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaW5kaW5ncy1maWxlLXNlbGVjdG9yXCIgLz57XCJGSU5ESU5HUyDigJQgZmlsZS1zZWxlY3RvclwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVjb3JkZWQgYnkgdGhlIDIwMjYtMDYgY29kZS12ZXJpZmljYXRpb24gcGFzcyAoUjMtMTI0OyBwbGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjA4LXN5c3RlbS1hcHBzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvcmQgLyB2ZXJpZnkgb25seS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR2F0ZXMgZ3JlZW4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNwZWMtcmVmcy1waGFzZS0xXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzcGVjLXJlZnMtcGhhc2UtMVwiIC8+e1wiU3BlYy1yZWZzIChQaGFzZSAxKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmlkZXM6IHBpY2stZmlsZUAxLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiB+MTEgc3BlYy1yZWZzIGFjcm9zcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGaWxlU2VsZWN0b3IudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJob29rcy91c2VGaWxlU2VsZWN0b3IudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaWIvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQ2l0ZWQgc3BlY3M6IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBpY2stZmlsZSB0YXNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBJQ0tfRklMRV9UQVNLX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGljaCBsaXZlcyBpbiB0aGUgd2hpdGVib2FyZC1hcHAgZG9jcyBzdWJkaXIg4oCUIE5PVCBpbiB0aGVcXG5tYWluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGVja291dCwgc28gbm90IGZ1bGx5IHJlc29sdmFibGUgaGVyZSkgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlVJX0FTX0FQUFNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2tzXFxuwqc1LjcuIFZlcmlmeSBhdCBleGVjdXRpb24gdGhhdCBhbnkgb3BhcXVlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBsYW4gUGhhc2UgTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcG9pbnRlcnMgYXJlIHJlcGxhY2VkIHdpdGhcXG50aGUgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQSUNLX0ZJTEVfVEFTS19TUEVDIMKnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aGVyZSBvbmUgZXhpc3RzLiBUaGUgYXBwIHVzZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VUYXNrSW5wdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBsZXRlVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGhhbmRsZXMgY2FuY2VsbGF0aW9uL2Fic2VuY2Ug4oCUXFxuRG9uZS1zcGVjIOKGlCBjb2RlIG1hcHBpbmcgY2hlY2tzIG91dCAoZGV2LWZzICsgTURYIHdpcmVkKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2RrLXZlcnNpb24tc2tldy1yZWNvcmQtb25seVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2RrLXZlcnNpb24tc2tldy1yZWNvcmQtb25seVwiIC8+e1wiU0RLLXZlcnNpb24gc2tldyAocmVjb3JkIG9ubHkpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQaW5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIjAuOC4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZmxlZXQgc3ByZWFkOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjIuOFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjguMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgL1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjAuMTEuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeMC4xMi4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIENvb3JkaW5hdGVkIGJ1bXAgb3dlZDsgZG8gbm90IGJ1bXAgaGVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidm9jYWJ1bGFyeS1waGFzZS0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ2b2NhYnVsYXJ5LXBoYXNlLTJcIiAvPntcIlZvY2FidWxhcnkgKFBoYXNlIDIpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJObyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJrZXJuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJpbmNpcGFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi1hcy1ncmFudGVlIGZvdW5kIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGV2LW9ubHkuXFxuQ29uZm9ybWFudC4gKGZpbGUtc2VsZWN0b3IgaGFzIGEgdml0ZXN0IHN1aXRlIGZvciBpdHMgaG9va3Mg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSB0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcHBsaWVzLilcIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFRkFDVE9SX0NBTkRJREFURVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHUCxLQUFLLENBQUNRO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHUixXQUFXO0VBQ2hDLElBQUksQ0FBQ1EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFaLFdBQUEsQ0FBQWEsSUFBQSxFQUFBYixXQUFBLENBQUFjLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDRSxFQUFFO01BQUNXLEVBQUUsRUFBQyx3QkFBd0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXdCLENBQUUsQ0FBQyxFQUFDLDBCQUEwQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLCtEQUErRCxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDQyxJQUFJO1FBQUFXLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDSyxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBYSxJQUFBLEVBQUNWLFdBQVcsQ0FBQ0csRUFBRTtNQUFDVSxFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxxQkFBcUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQXlCLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNLLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQWdCLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDQyxJQUFJO1FBQUFXLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDQyxJQUFJO1FBQUFXLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsZ0dBQWdHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDRyxFQUFFO01BQUNVLEVBQUUsRUFBQyw4QkFBOEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThCLENBQUUsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLE9BQU8sZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssTUFBTTtRQUFBTyxRQUFBLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7VUFBQVcsUUFBQSxFQUFFO1FBQU8sQ0FBbUI7TUFBQyxDQUFvQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDQyxJQUFJO1FBQUFXLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBYSxJQUFBLEVBQUNWLFdBQVcsQ0FBQ0csRUFBRTtNQUFDVSxFQUFFLEVBQUMsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSxLQUFLLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBVyxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNDLElBQUk7UUFBQVcsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3g4RjtBQUNlLFNBQVNHLFVBQVVBLENBQUNoQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDaUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1AsS0FBSyxDQUFDUTtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUFwQixXQUFBLENBQUFpQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLbEIsS0FBSztJQUFBYSxRQUFBLGVBQUUsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDaEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ21CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsb0NBQW9DLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDOVA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}