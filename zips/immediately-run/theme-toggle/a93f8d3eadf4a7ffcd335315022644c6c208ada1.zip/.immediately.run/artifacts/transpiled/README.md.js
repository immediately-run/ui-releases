var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "theme-toggle-theme-switcher",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "theme-toggle-theme-switcher"
      }), "theme-toggle → theme-switcher"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "widget.theme"
      }), " system app, upgraded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "in place"
      }), " from the two-state toggle to\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "theme switcher"
      }), " (R3-501 · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HOST_THEMING_SPEC"
      }), " §8.2). Loaded into a chrome\nregion by the host; not meant to be run standalone."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "It is the forkable surface for appearance:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Current selection"
        }), " — the active theme + resolved mode (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useHostThemeSelection"
        }), ");"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Theme list"
        }), " from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "theme-catalog"
        }), " channel (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useThemeCatalog"
        }), "), with\nlabel-collision disambiguation (\"Nord (repo)\");"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mode list"
        }), " of the selected theme (System + the theme's polarity modes);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Add theme"
        }), " → invokes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "open-bundle"
        }), " task with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kinds: [\"theme\"]"
        }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "addThemeSource(location)"
        }), ", with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "synchronous inline adoption feedback"
        }), " — a\ngated-out candidate surfaces here in the switcher, never another surface;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Refresh"
        }), " (the catalogue re-pushes via the channel) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "remove"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Requires the elevated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:set"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:sources"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task:invoke"
      }), "\ncapabilities (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "widget.theme"
      }), " ceiling in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "defaults.ts"
      }), "); a fork without them\ndegrades to read-only."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Built against ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), " 0.59.0 (the widened theme surface)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJsaSIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJ0aGVtZS10b2dnbGUtdGhlbWUtc3dpdGNoZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZW1lLXRvZ2dsZS10aGVtZS1zd2l0Y2hlclwiIC8+e1widGhlbWUtdG9nZ2xlIOKGkiB0aGVtZS1zd2l0Y2hlclwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpZGdldC50aGVtZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3lzdGVtIGFwcCwgdXBncmFkZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbiBwbGFjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmcm9tIHRoZSB0d28tc3RhdGUgdG9nZ2xlIHRvXFxudGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlbWUgc3dpdGNoZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFIzLTUwMSDCtyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT1NUX1RIRU1JTkdfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc4LjIpLiBMb2FkZWQgaW50byBhIGNocm9tZVxcbnJlZ2lvbiBieSB0aGUgaG9zdDsgbm90IG1lYW50IHRvIGJlIHJ1biBzdGFuZGFsb25lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJdCBpcyB0aGUgZm9ya2FibGUgc3VyZmFjZSBmb3IgYXBwZWFyYW5jZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkN1cnJlbnQgc2VsZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgYWN0aXZlIHRoZW1lICsgcmVzb2x2ZWQgbW9kZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlSG9zdFRoZW1lU2VsZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGVtZSBsaXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZyb20gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRoZW1lLWNhdGFsb2dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoYW5uZWwgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVRoZW1lQ2F0YWxvZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB3aXRoXFxubGFiZWwtY29sbGlzaW9uIGRpc2FtYmlndWF0aW9uIChcXFwiTm9yZCAocmVwbylcXFwiKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1vZGUgbGlzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvZiB0aGUgc2VsZWN0ZWQgdGhlbWUgKFN5c3RlbSArIHRoZSB0aGVtZSdzIHBvbGFyaXR5IG1vZGVzKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFkZCB0aGVtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDihpIgaW52b2tlcyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3Blbi1idW5kbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2sgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJraW5kczogW1xcXCJ0aGVtZVxcXCJdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJhZGRUaGVtZVNvdXJjZShsb2NhdGlvbilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3luY2hyb25vdXMgaW5saW5lIGFkb3B0aW9uIGZlZWRiYWNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhXFxuZ2F0ZWQtb3V0IGNhbmRpZGF0ZSBzdXJmYWNlcyBoZXJlIGluIHRoZSBzd2l0Y2hlciwgbmV2ZXIgYW5vdGhlciBzdXJmYWNlO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVmcmVzaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGNhdGFsb2d1ZSByZS1wdXNoZXMgdmlhIHRoZSBjaGFubmVsKSBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZW1vdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlcXVpcmVzIHRoZSBlbGV2YXRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aGVtZTpzZXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGhlbWU6c291cmNlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrOmludm9rZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5jYXBhYmlsaXRpZXMgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aWRnZXQudGhlbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNlaWxpbmcgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVmYXVsdHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgYSBmb3JrIHdpdGhvdXQgdGhlbVxcbmRlZ3JhZGVzIHRvIHJlYWQtb25seS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQnVpbHQgYWdhaW5zdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgMC41OS4wICh0aGUgd2lkZW5lZCB0aGVtZSBzdXJmYWNlKS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdSLEtBQUssQ0FBQ1M7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdULFdBQVc7RUFDaEMsSUFBSSxDQUFDUyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWIsV0FBQSxDQUFBYyxJQUFBLEVBQUFkLFdBQUEsQ0FBQWUsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRSxFQUFFO01BQUNZLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxDQUFDO01BQUFTLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNLLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxtRkFBbUY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0ksQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBNEMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ00sRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDSyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNHLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNLLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyw0REFBNEQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDSyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDSyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7VUFBQVksUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLGlGQUFpRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNHLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNLLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ksQ0FBQztNQUFBUyxRQUFBLEdBQUUsd0JBQXdCLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGdEQUFnRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNJLENBQUM7TUFBQVMsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDOWxGO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ2pCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNrQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHUixLQUFLLENBQUNTO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQXJCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtuQixLQUFLO0lBQUFjLFFBQUEsZUFBRSxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDakIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}