var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _lucideReact = require("lucide-react");
var _sdk = require("@immediately-run/sdk");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The theme switcher (R3-501 · HOST_THEMING_SPEC §8.2) — the `widget.theme` app
// upgraded in place from the two-state toggle. It composes the R3-500 SDK
// surface over the widened wire:
//
//   - current selection (`useHostThemeSelection`);
//   - the theme list from the `theme-catalog` channel (`useThemeCatalog`);
//   - the mode list of the selected theme;
//   - label-collision disambiguation ("Nord (repo)");
//   - **Add theme** → invokes the `open-bundle` task with `kinds: ["theme"]` →
//     `addThemeSource(location)` with SYNCHRONOUS inline adoption feedback
//     (a rejected pick surfaces in the switcher, never another surface);
//   - refresh (re-push of the catalogue follows the service);
//   - remove.
//
// The host gate rejects anything this frame may not do (`forbidden` for a
// fork without `theme:set`/`theme:sources`); this UI degrades to a read-only
// "preview" view rather than erroring.
/** The `open-bundle` task result (OPEN_BUNDLE_SPEC §2): a picked location. */
function Switcher() {
  _s();
  const {
    themeKey,
    modeId
  } = (0, _sdk.useHostThemeSelection)();
  const catalog = (0, _sdk.useThemeCatalog)();
  const [addState, setAddState] = (0, _react.useState)({
    status: "idle"
  });

  // The current theme entry (may be the default — always in the catalogue).
  const currentEntry = catalog.themes.find(t => t.themeKey === themeKey) ?? null;

  // Mode labels come from the catalogue (host-approved, bounded); the fixed
  // "System default" is always offered.
  const currentModes = currentEntry?.modes ?? [];

  /** Invoke the open-bundle picker for a theme bundle, then adopt it. */
  const addTheme = (0, _react.useCallback)(async () => {
    setAddState({
      status: "adding"
    });
    try {
      const result = await (0, _sdk.invokeTask)("open-bundle", {
        kinds: ["theme"]
      });
      if (!result?.location) {
        setAddState({
          status: "error",
          reason: "The picker returned no location."
        });
        return;
      }
      await (0, _sdk.addThemeSource)(result.location);
      // Synchronous, inline feedback: the service loads + gates + registers
      // BEFORE returning, so a rejection surfaces here, in the switcher. The
      // catalogue channel re-push will surface the new theme in the list.
      setAddState({
        status: "adopted",
        themeKey: ""
      });
    } catch (e) {
      const err = e;
      setAddState({
        status: "error",
        reason: err?.message ?? (err?.code === "cancelled" ? "Add cancelled." : "Could not add that theme.")
      });
    } finally {
      // Keep the success/error visible briefly, then settle.
      window.setTimeout(() => setAddState(s => s.status === "adopted" || s.status === "error" ? {
        status: "idle"
      } : s), 2600);
    }
  }, []);

  /** Disambiguate a label collision: "Nord" from two sources → "Nord (repo)". */
  const disambiguated = (0, _react.useCallback)(entry => {
    const sameLabel = catalog.themes.filter(t => t.label === entry.label);
    if (sameLabel.length <= 1) return entry.label;
    // The baseline catalogue carries no source identities; the label is all a
    // baseline reader has. When labels collide we can't name the source (the
    // projection withholds it), so fall back to the key's tail.
    const tail = entry.themeKey.split("|").pop() ?? "";
    return `${entry.label} (${tail})`;
  }, [catalog]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "tt",
    "aria-label": "Host theme",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__current",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tt__current-label",
        children: "Current theme"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "tt__current-value",
        children: [currentEntry ? disambiguated(currentEntry) : themeKey, /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "tt__current-mode",
          children: modeId === "system" ? " · System default" : ` · ${modeId}`
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__seg",
      role: "radiogroup",
      "aria-label": "Theme mode",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": modeId === "system",
        className: `tt__opt${modeId === "system" ? " is-active" : ""}`,
        onClick: () => (0, _sdk.setHostThemeSelection)({
          theme: themeKey,
          mode: "system"
        }),
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Monitor, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "System"
        })]
      }), currentModes.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": modeId === m.id,
        className: `tt__opt${modeId === m.id ? " is-active" : ""}`,
        onClick: () => (0, _sdk.setHostThemeSelection)({
          theme: themeKey,
          mode: m.id
        }),
        children: [m.polarity === "dark" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Moon, {
          size: 15,
          "aria-hidden": "true"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Sun, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: m.id
        })]
      }, m.id))]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__list",
      role: "list",
      "aria-label": "Themes",
      children: [catalog.themes.map(entry => {
        const active = entry.themeKey === themeKey;
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: `tt__theme${active ? " is-active" : ""}`,
          role: "listitem",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            type: "button",
            className: "tt__theme-select",
            onClick: () => (0, _sdk.setHostThemeSelection)({
              theme: entry.themeKey,
              mode: modeId === "system" ? "system" : currentModes[0]?.id ?? "system"
            }),
            children: [active ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Check, {
              size: 15,
              "aria-hidden": "true"
            }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "tt__theme-dot"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              children: disambiguated(entry)
            })]
          }), active && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "tt__active-badge",
            children: "active"
          }), entry.themeKey !== "immediately-run-default" && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "tt__remove",
            title: "Remove theme",
            "aria-label": `Remove ${entry.label}`,
            onClick: () => (0, _sdk.removeThemeSource)(entry.themeKey),
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Trash2, {
              size: 14,
              "aria-hidden": "true"
            })
          })]
        }, entry.themeKey);
      }), catalog.themes.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "tt__note",
        children: "No themes yet. Add one from a repository or space."
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__add",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "tt__add-btn",
        disabled: addState.status === "adding",
        onClick: addTheme,
        children: [addState.status === "adding" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.RefreshCw, {
          size: 15,
          "aria-hidden": "true",
          className: "tt__spin"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Plus, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "Add theme\u2026"
        })]
      }), addState.status === "error" && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "tt__note tt__note--err",
        children: addState.reason
      }), addState.status === "adopted" && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "tt__note tt__note--ok",
        children: "Added. Pick it from the list above."
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "tt__foot",
      children: "Themes are fetched, gated, and stored by the host. A theme with an accessibility gate failure is refused here, inline."
    })]
  });
}
_s(Switcher, "gm0pDCwNwUfCE3uGXUQyCAIvJ6U=", false, function () {
  return [_sdk.useHostThemeSelection, _sdk.useThemeCatalog];
});
_c = Switcher;
var _default = exports.default = Switcher;
var _c;
$RefreshReg$(_c, "Switcher");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJTd2l0Y2hlciIsInRoZW1lS2V5IiwibW9kZUlkIiwidXNlSG9zdFRoZW1lU2VsZWN0aW9uIiwiY2F0YWxvZyIsInVzZVRoZW1lQ2F0YWxvZyIsImFkZFN0YXRlIiwic2V0QWRkU3RhdGUiLCJ1c2VTdGF0ZSIsInN0YXR1cyIsImN1cnJlbnRFbnRyeSIsInRoZW1lcyIsImZpbmQiLCJ0IiwiY3VycmVudE1vZGVzIiwibW9kZXMiLCJhZGRUaGVtZSIsInVzZUNhbGxiYWNrIiwicmVzdWx0IiwiaW52b2tlVGFzayIsImtpbmRzIiwibG9jYXRpb24iLCJyZWFzb24iLCJhZGRUaGVtZVNvdXJjZSIsImUiLCJlcnIiLCJtZXNzYWdlIiwiY29kZSIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJzIiwiZGlzYW1iaWd1YXRlZCIsImVudHJ5Iiwic2FtZUxhYmVsIiwiZmlsdGVyIiwibGFiZWwiLCJsZW5ndGgiLCJ0YWlsIiwic3BsaXQiLCJwb3AiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJyb2xlIiwidHlwZSIsIm9uQ2xpY2siLCJzZXRIb3N0VGhlbWVTZWxlY3Rpb24iLCJ0aGVtZSIsIm1vZGUiLCJNb25pdG9yIiwic2l6ZSIsIm1hcCIsIm0iLCJpZCIsInBvbGFyaXR5IiwiTW9vbiIsIlN1biIsImFjdGl2ZSIsIkNoZWNrIiwidGl0bGUiLCJyZW1vdmVUaGVtZVNvdXJjZSIsIlRyYXNoMiIsImRpc2FibGVkIiwiUmVmcmVzaEN3IiwiUGx1cyIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN3aXRjaGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgdGhlbWUgc3dpdGNoZXIgKFIzLTUwMSDCtyBIT1NUX1RIRU1JTkdfU1BFQyDCpzguMikg4oCUIHRoZSBgd2lkZ2V0LnRoZW1lYCBhcHBcbi8vIHVwZ3JhZGVkIGluIHBsYWNlIGZyb20gdGhlIHR3by1zdGF0ZSB0b2dnbGUuIEl0IGNvbXBvc2VzIHRoZSBSMy01MDAgU0RLXG4vLyBzdXJmYWNlIG92ZXIgdGhlIHdpZGVuZWQgd2lyZTpcbi8vXG4vLyAgIC0gY3VycmVudCBzZWxlY3Rpb24gKGB1c2VIb3N0VGhlbWVTZWxlY3Rpb25gKTtcbi8vICAgLSB0aGUgdGhlbWUgbGlzdCBmcm9tIHRoZSBgdGhlbWUtY2F0YWxvZ2AgY2hhbm5lbCAoYHVzZVRoZW1lQ2F0YWxvZ2ApO1xuLy8gICAtIHRoZSBtb2RlIGxpc3Qgb2YgdGhlIHNlbGVjdGVkIHRoZW1lO1xuLy8gICAtIGxhYmVsLWNvbGxpc2lvbiBkaXNhbWJpZ3VhdGlvbiAoXCJOb3JkIChyZXBvKVwiKTtcbi8vICAgLSAqKkFkZCB0aGVtZSoqIOKGkiBpbnZva2VzIHRoZSBgb3Blbi1idW5kbGVgIHRhc2sgd2l0aCBga2luZHM6IFtcInRoZW1lXCJdYCDihpJcbi8vICAgICBgYWRkVGhlbWVTb3VyY2UobG9jYXRpb24pYCB3aXRoIFNZTkNIUk9OT1VTIGlubGluZSBhZG9wdGlvbiBmZWVkYmFja1xuLy8gICAgIChhIHJlamVjdGVkIHBpY2sgc3VyZmFjZXMgaW4gdGhlIHN3aXRjaGVyLCBuZXZlciBhbm90aGVyIHN1cmZhY2UpO1xuLy8gICAtIHJlZnJlc2ggKHJlLXB1c2ggb2YgdGhlIGNhdGFsb2d1ZSBmb2xsb3dzIHRoZSBzZXJ2aWNlKTtcbi8vICAgLSByZW1vdmUuXG4vL1xuLy8gVGhlIGhvc3QgZ2F0ZSByZWplY3RzIGFueXRoaW5nIHRoaXMgZnJhbWUgbWF5IG5vdCBkbyAoYGZvcmJpZGRlbmAgZm9yIGFcbi8vIGZvcmsgd2l0aG91dCBgdGhlbWU6c2V0YC9gdGhlbWU6c291cmNlc2ApOyB0aGlzIFVJIGRlZ3JhZGVzIHRvIGEgcmVhZC1vbmx5XG4vLyBcInByZXZpZXdcIiB2aWV3IHJhdGhlciB0aGFuIGVycm9yaW5nLlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDaGVjaywgTW9vbiwgUGx1cywgUmVmcmVzaEN3LCBTdW4sIFRyYXNoMiwgTW9uaXRvciB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7XG4gIHVzZUhvc3RUaGVtZVNlbGVjdGlvbixcbiAgdXNlVGhlbWVDYXRhbG9nLFxuICBzZXRIb3N0VGhlbWVTZWxlY3Rpb24sXG4gIGFkZFRoZW1lU291cmNlLFxuICByZW1vdmVUaGVtZVNvdXJjZSxcbiAgaW52b2tlVGFzayxcbiAgdHlwZSBUaGVtZUJ1bmRsZUxvY2F0aW9uLFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcblxuLyoqIFRoZSBgb3Blbi1idW5kbGVgIHRhc2sgcmVzdWx0IChPUEVOX0JVTkRMRV9TUEVDIMKnMik6IGEgcGlja2VkIGxvY2F0aW9uLiAqL1xuaW50ZXJmYWNlIE9wZW5CdW5kbGVSZXN1bHQge1xuICBsb2NhdGlvbjogVGhlbWVCdW5kbGVMb2NhdGlvbjtcbn1cblxudHlwZSBBZGRTdGF0ZSA9XG4gIHwgeyBzdGF0dXM6IFwiaWRsZVwiIH1cbiAgfCB7IHN0YXR1czogXCJhZGRpbmdcIiB9XG4gIHwgeyBzdGF0dXM6IFwiZXJyb3JcIjsgcmVhc29uOiBzdHJpbmcgfVxuICB8IHsgc3RhdHVzOiBcImFkb3B0ZWRcIjsgdGhlbWVLZXk6IHN0cmluZyB9O1xuXG5mdW5jdGlvbiBTd2l0Y2hlcigpIHtcbiAgY29uc3QgeyB0aGVtZUtleSwgbW9kZUlkIH0gPSB1c2VIb3N0VGhlbWVTZWxlY3Rpb24oKTtcbiAgY29uc3QgY2F0YWxvZyA9IHVzZVRoZW1lQ2F0YWxvZygpO1xuICBjb25zdCBbYWRkU3RhdGUsIHNldEFkZFN0YXRlXSA9IHVzZVN0YXRlPEFkZFN0YXRlPih7IHN0YXR1czogXCJpZGxlXCIgfSk7XG5cbiAgLy8gVGhlIGN1cnJlbnQgdGhlbWUgZW50cnkgKG1heSBiZSB0aGUgZGVmYXVsdCDigJQgYWx3YXlzIGluIHRoZSBjYXRhbG9ndWUpLlxuICBjb25zdCBjdXJyZW50RW50cnkgPSBjYXRhbG9nLnRoZW1lcy5maW5kKCh0KSA9PiB0LnRoZW1lS2V5ID09PSB0aGVtZUtleSkgPz8gbnVsbDtcblxuICAvLyBNb2RlIGxhYmVscyBjb21lIGZyb20gdGhlIGNhdGFsb2d1ZSAoaG9zdC1hcHByb3ZlZCwgYm91bmRlZCk7IHRoZSBmaXhlZFxuICAvLyBcIlN5c3RlbSBkZWZhdWx0XCIgaXMgYWx3YXlzIG9mZmVyZWQuXG4gIGNvbnN0IGN1cnJlbnRNb2RlcyA9IGN1cnJlbnRFbnRyeT8ubW9kZXMgPz8gW107XG5cbiAgLyoqIEludm9rZSB0aGUgb3Blbi1idW5kbGUgcGlja2VyIGZvciBhIHRoZW1lIGJ1bmRsZSwgdGhlbiBhZG9wdCBpdC4gKi9cbiAgY29uc3QgYWRkVGhlbWUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0QWRkU3RhdGUoeyBzdGF0dXM6IFwiYWRkaW5nXCIgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGludm9rZVRhc2s8T3BlbkJ1bmRsZVJlc3VsdD4oXCJvcGVuLWJ1bmRsZVwiLCB7XG4gICAgICAgIGtpbmRzOiBbXCJ0aGVtZVwiXSxcbiAgICAgIH0pO1xuICAgICAgaWYgKCFyZXN1bHQ/LmxvY2F0aW9uKSB7XG4gICAgICAgIHNldEFkZFN0YXRlKHsgc3RhdHVzOiBcImVycm9yXCIsIHJlYXNvbjogXCJUaGUgcGlja2VyIHJldHVybmVkIG5vIGxvY2F0aW9uLlwiIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBhd2FpdCBhZGRUaGVtZVNvdXJjZShyZXN1bHQubG9jYXRpb24pO1xuICAgICAgLy8gU3luY2hyb25vdXMsIGlubGluZSBmZWVkYmFjazogdGhlIHNlcnZpY2UgbG9hZHMgKyBnYXRlcyArIHJlZ2lzdGVyc1xuICAgICAgLy8gQkVGT1JFIHJldHVybmluZywgc28gYSByZWplY3Rpb24gc3VyZmFjZXMgaGVyZSwgaW4gdGhlIHN3aXRjaGVyLiBUaGVcbiAgICAgIC8vIGNhdGFsb2d1ZSBjaGFubmVsIHJlLXB1c2ggd2lsbCBzdXJmYWNlIHRoZSBuZXcgdGhlbWUgaW4gdGhlIGxpc3QuXG4gICAgICBzZXRBZGRTdGF0ZSh7IHN0YXR1czogXCJhZG9wdGVkXCIsIHRoZW1lS2V5OiBcIlwiIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGVyciA9IGUgYXMgeyBjb2RlPzogc3RyaW5nOyBtZXNzYWdlPzogc3RyaW5nIH07XG4gICAgICBzZXRBZGRTdGF0ZSh7XG4gICAgICAgIHN0YXR1czogXCJlcnJvclwiLFxuICAgICAgICByZWFzb246IGVycj8ubWVzc2FnZSA/PyAoZXJyPy5jb2RlID09PSBcImNhbmNlbGxlZFwiID8gXCJBZGQgY2FuY2VsbGVkLlwiIDogXCJDb3VsZCBub3QgYWRkIHRoYXQgdGhlbWUuXCIpLFxuICAgICAgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIC8vIEtlZXAgdGhlIHN1Y2Nlc3MvZXJyb3IgdmlzaWJsZSBicmllZmx5LCB0aGVuIHNldHRsZS5cbiAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldEFkZFN0YXRlKChzKSA9PiAocy5zdGF0dXMgPT09IFwiYWRvcHRlZFwiIHx8IHMuc3RhdHVzID09PSBcImVycm9yXCIgPyB7IHN0YXR1czogXCJpZGxlXCIgfSA6IHMpKSwgMjYwMCk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLyoqIERpc2FtYmlndWF0ZSBhIGxhYmVsIGNvbGxpc2lvbjogXCJOb3JkXCIgZnJvbSB0d28gc291cmNlcyDihpIgXCJOb3JkIChyZXBvKVwiLiAqL1xuICBjb25zdCBkaXNhbWJpZ3VhdGVkID0gdXNlQ2FsbGJhY2soKGVudHJ5OiAodHlwZW9mIGNhdGFsb2cudGhlbWVzKVtudW1iZXJdKTogc3RyaW5nID0+IHtcbiAgICBjb25zdCBzYW1lTGFiZWwgPSBjYXRhbG9nLnRoZW1lcy5maWx0ZXIoKHQpID0+IHQubGFiZWwgPT09IGVudHJ5LmxhYmVsKTtcbiAgICBpZiAoc2FtZUxhYmVsLmxlbmd0aCA8PSAxKSByZXR1cm4gZW50cnkubGFiZWw7XG4gICAgLy8gVGhlIGJhc2VsaW5lIGNhdGFsb2d1ZSBjYXJyaWVzIG5vIHNvdXJjZSBpZGVudGl0aWVzOyB0aGUgbGFiZWwgaXMgYWxsIGFcbiAgICAvLyBiYXNlbGluZSByZWFkZXIgaGFzLiBXaGVuIGxhYmVscyBjb2xsaWRlIHdlIGNhbid0IG5hbWUgdGhlIHNvdXJjZSAodGhlXG4gICAgLy8gcHJvamVjdGlvbiB3aXRoaG9sZHMgaXQpLCBzbyBmYWxsIGJhY2sgdG8gdGhlIGtleSdzIHRhaWwuXG4gICAgY29uc3QgdGFpbCA9IGVudHJ5LnRoZW1lS2V5LnNwbGl0KFwifFwiKS5wb3AoKSA/PyBcIlwiO1xuICAgIHJldHVybiBgJHtlbnRyeS5sYWJlbH0gKCR7dGFpbH0pYDtcbiAgfSwgW2NhdGFsb2ddKTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInR0XCIgYXJpYS1sYWJlbD1cIkhvc3QgdGhlbWVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHRfX2N1cnJlbnRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHRfX2N1cnJlbnQtbGFiZWxcIj5DdXJyZW50IHRoZW1lPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0dF9fY3VycmVudC12YWx1ZVwiPlxuICAgICAgICAgIHtjdXJyZW50RW50cnkgPyBkaXNhbWJpZ3VhdGVkKGN1cnJlbnRFbnRyeSkgOiB0aGVtZUtleX1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0dF9fY3VycmVudC1tb2RlXCI+XG4gICAgICAgICAgICB7bW9kZUlkID09PSBcInN5c3RlbVwiID8gXCIgwrcgU3lzdGVtIGRlZmF1bHRcIiA6IGAgwrcgJHttb2RlSWR9YH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTW9kZSBsaXN0IG9mIHRoZSBzZWxlY3RlZCB0aGVtZSAoZml4ZWQgaG9zdCBsYWJlbHM7IHRoZSBjYXRhbG9ndWUnc1xuICAgICAgICAgIG1vZGUgaWRzIGFyZSB0aGUgcmVzb2x2ZWQgb25lcykuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0dF9fc2VnXCIgcm9sZT1cInJhZGlvZ3JvdXBcIiBhcmlhLWxhYmVsPVwiVGhlbWUgbW9kZVwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgcm9sZT1cInJhZGlvXCJcbiAgICAgICAgICBhcmlhLWNoZWNrZWQ9e21vZGVJZCA9PT0gXCJzeXN0ZW1cIn1cbiAgICAgICAgICBjbGFzc05hbWU9e2B0dF9fb3B0JHttb2RlSWQgPT09IFwic3lzdGVtXCIgPyBcIiBpcy1hY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRIb3N0VGhlbWVTZWxlY3Rpb24oeyB0aGVtZTogdGhlbWVLZXksIG1vZGU6IFwic3lzdGVtXCIgfSl9XG4gICAgICAgID5cbiAgICAgICAgICA8TW9uaXRvciBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8c3Bhbj5TeXN0ZW08L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7Y3VycmVudE1vZGVzLm1hcCgobSkgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17bS5pZH1cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgcm9sZT1cInJhZGlvXCJcbiAgICAgICAgICAgIGFyaWEtY2hlY2tlZD17bW9kZUlkID09PSBtLmlkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHRfX29wdCR7bW9kZUlkID09PSBtLmlkID8gXCIgaXMtYWN0aXZlXCIgOiBcIlwifWB9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRIb3N0VGhlbWVTZWxlY3Rpb24oeyB0aGVtZTogdGhlbWVLZXksIG1vZGU6IG0uaWQgfSl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge20ucG9sYXJpdHkgPT09IFwiZGFya1wiID8gKFxuICAgICAgICAgICAgICA8TW9vbiBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxTdW4gc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPHNwYW4+e20uaWR9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGhlbWUgbGlzdCBmcm9tIHRoZSBjYXRhbG9ndWUgY2hhbm5lbC4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInR0X19saXN0XCIgcm9sZT1cImxpc3RcIiBhcmlhLWxhYmVsPVwiVGhlbWVzXCI+XG4gICAgICAgIHtjYXRhbG9nLnRoZW1lcy5tYXAoKGVudHJ5KSA9PiB7XG4gICAgICAgICAgY29uc3QgYWN0aXZlID0gZW50cnkudGhlbWVLZXkgPT09IHRoZW1lS2V5O1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17ZW50cnkudGhlbWVLZXl9IGNsYXNzTmFtZT17YHR0X190aGVtZSR7YWN0aXZlID8gXCIgaXMtYWN0aXZlXCIgOiBcIlwifWB9IHJvbGU9XCJsaXN0aXRlbVwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidHRfX3RoZW1lLXNlbGVjdFwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgIHNldEhvc3RUaGVtZVNlbGVjdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiBlbnRyeS50aGVtZUtleSxcbiAgICAgICAgICAgICAgICAgICAgbW9kZTogbW9kZUlkID09PSBcInN5c3RlbVwiID8gXCJzeXN0ZW1cIiA6IGN1cnJlbnRNb2Rlc1swXT8uaWQgPz8gXCJzeXN0ZW1cIixcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2FjdGl2ZSA/IDxDaGVjayBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4gOiA8c3BhbiBjbGFzc05hbWU9XCJ0dF9fdGhlbWUtZG90XCIgLz59XG4gICAgICAgICAgICAgICAgPHNwYW4+e2Rpc2FtYmlndWF0ZWQoZW50cnkpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIHthY3RpdmUgJiYgPHNwYW4gY2xhc3NOYW1lPVwidHRfX2FjdGl2ZS1iYWRnZVwiPmFjdGl2ZTwvc3Bhbj59XG4gICAgICAgICAgICAgIHtlbnRyeS50aGVtZUtleSAhPT0gXCJpbW1lZGlhdGVseS1ydW4tZGVmYXVsdFwiICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInR0X19yZW1vdmVcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmUgdGhlbWVcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFJlbW92ZSAke2VudHJ5LmxhYmVsfWB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVUaGVtZVNvdXJjZShlbnRyeS50aGVtZUtleSl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgICB7Y2F0YWxvZy50aGVtZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0dF9fbm90ZVwiPk5vIHRoZW1lcyB5ZXQuIEFkZCBvbmUgZnJvbSBhIHJlcG9zaXRvcnkgb3Igc3BhY2UuPC9wPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHRfX2FkZFwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidHRfX2FkZC1idG5cIlxuICAgICAgICAgIGRpc2FibGVkPXthZGRTdGF0ZS5zdGF0dXMgPT09IFwiYWRkaW5nXCJ9XG4gICAgICAgICAgb25DbGljaz17YWRkVGhlbWV9XG4gICAgICAgID5cbiAgICAgICAgICB7YWRkU3RhdGUuc3RhdHVzID09PSBcImFkZGluZ1wiID8gKFxuICAgICAgICAgICAgPFJlZnJlc2hDdyBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwidHRfX3NwaW5cIiAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8UGx1cyBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxzcGFuPkFkZCB0aGVtZeKApjwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHthZGRTdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiA8cCBjbGFzc05hbWU9XCJ0dF9fbm90ZSB0dF9fbm90ZS0tZXJyXCI+e2FkZFN0YXRlLnJlYXNvbn08L3A+fVxuICAgICAgICB7YWRkU3RhdGUuc3RhdHVzID09PSBcImFkb3B0ZWRcIiAmJiAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHRfX25vdGUgdHRfX25vdGUtLW9rXCI+QWRkZWQuIFBpY2sgaXQgZnJvbSB0aGUgbGlzdCBhYm92ZS48L3A+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPHAgY2xhc3NOYW1lPVwidHRfX2Zvb3RcIj5cbiAgICAgICAgVGhlbWVzIGFyZSBmZXRjaGVkLCBnYXRlZCwgYW5kIHN0b3JlZCBieSB0aGUgaG9zdC4gQSB0aGVtZSB3aXRoIGFuXG4gICAgICAgIGFjY2Vzc2liaWxpdHkgZ2F0ZSBmYWlsdXJlIGlzIHJlZnVzZWQgaGVyZSwgaW5saW5lLlxuICAgICAgPC9wPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3dpdGNoZXI7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBaUJBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLElBQUEsR0FBQUYsT0FBQTtBQVE4QixJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUEzQjlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFhQTtBQVdBLFNBQVNDLFFBQVFBLENBQUEsRUFBRztFQUFBRixFQUFBO0VBQ2xCLE1BQU07SUFBRUcsUUFBUTtJQUFFQztFQUFPLENBQUMsR0FBRyxJQUFBQywwQkFBcUIsRUFBQyxDQUFDO0VBQ3BELE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxvQkFBZSxFQUFDLENBQUM7RUFDakMsTUFBTSxDQUFDQyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBVztJQUFFQyxNQUFNLEVBQUU7RUFBTyxDQUFDLENBQUM7O0VBRXRFO0VBQ0EsTUFBTUMsWUFBWSxHQUFHTixPQUFPLENBQUNPLE1BQU0sQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ1osUUFBUSxLQUFLQSxRQUFRLENBQUMsSUFBSSxJQUFJOztFQUVoRjtFQUNBO0VBQ0EsTUFBTWEsWUFBWSxHQUFHSixZQUFZLEVBQUVLLEtBQUssSUFBSSxFQUFFOztFQUU5QztFQUNBLE1BQU1DLFFBQVEsR0FBRyxJQUFBQyxrQkFBVyxFQUFDLFlBQVk7SUFDdkNWLFdBQVcsQ0FBQztNQUFFRSxNQUFNLEVBQUU7SUFBUyxDQUFDLENBQUM7SUFDakMsSUFBSTtNQUNGLE1BQU1TLE1BQU0sR0FBRyxNQUFNLElBQUFDLGVBQVUsRUFBbUIsYUFBYSxFQUFFO1FBQy9EQyxLQUFLLEVBQUUsQ0FBQyxPQUFPO01BQ2pCLENBQUMsQ0FBQztNQUNGLElBQUksQ0FBQ0YsTUFBTSxFQUFFRyxRQUFRLEVBQUU7UUFDckJkLFdBQVcsQ0FBQztVQUFFRSxNQUFNLEVBQUUsT0FBTztVQUFFYSxNQUFNLEVBQUU7UUFBbUMsQ0FBQyxDQUFDO1FBQzVFO01BQ0Y7TUFDQSxNQUFNLElBQUFDLG1CQUFjLEVBQUNMLE1BQU0sQ0FBQ0csUUFBUSxDQUFDO01BQ3JDO01BQ0E7TUFDQTtNQUNBZCxXQUFXLENBQUM7UUFBRUUsTUFBTSxFQUFFLFNBQVM7UUFBRVIsUUFBUSxFQUFFO01BQUcsQ0FBQyxDQUFDO0lBQ2xELENBQUMsQ0FBQyxPQUFPdUIsQ0FBQyxFQUFFO01BQ1YsTUFBTUMsR0FBRyxHQUFHRCxDQUF3QztNQUNwRGpCLFdBQVcsQ0FBQztRQUNWRSxNQUFNLEVBQUUsT0FBTztRQUNmYSxNQUFNLEVBQUVHLEdBQUcsRUFBRUMsT0FBTyxLQUFLRCxHQUFHLEVBQUVFLElBQUksS0FBSyxXQUFXLEdBQUcsZ0JBQWdCLEdBQUcsMkJBQTJCO01BQ3JHLENBQUMsQ0FBQztJQUNKLENBQUMsU0FBUztNQUNSO01BQ0FDLE1BQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU10QixXQUFXLENBQUV1QixDQUFDLElBQU1BLENBQUMsQ0FBQ3JCLE1BQU0sS0FBSyxTQUFTLElBQUlxQixDQUFDLENBQUNyQixNQUFNLEtBQUssT0FBTyxHQUFHO1FBQUVBLE1BQU0sRUFBRTtNQUFPLENBQUMsR0FBR3FCLENBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQztJQUM5SDtFQUNGLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQSxNQUFNQyxhQUFhLEdBQUcsSUFBQWQsa0JBQVcsRUFBRWUsS0FBc0MsSUFBYTtJQUNwRixNQUFNQyxTQUFTLEdBQUc3QixPQUFPLENBQUNPLE1BQU0sQ0FBQ3VCLE1BQU0sQ0FBRXJCLENBQUMsSUFBS0EsQ0FBQyxDQUFDc0IsS0FBSyxLQUFLSCxLQUFLLENBQUNHLEtBQUssQ0FBQztJQUN2RSxJQUFJRixTQUFTLENBQUNHLE1BQU0sSUFBSSxDQUFDLEVBQUUsT0FBT0osS0FBSyxDQUFDRyxLQUFLO0lBQzdDO0lBQ0E7SUFDQTtJQUNBLE1BQU1FLElBQUksR0FBR0wsS0FBSyxDQUFDL0IsUUFBUSxDQUFDcUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUU7SUFDbEQsT0FBTyxHQUFHUCxLQUFLLENBQUNHLEtBQUssS0FBS0UsSUFBSSxHQUFHO0VBQ25DLENBQUMsRUFBRSxDQUFDakMsT0FBTyxDQUFDLENBQUM7RUFFYixvQkFDRSxJQUFBUCxXQUFBLENBQUEyQyxJQUFBO0lBQVNDLFNBQVMsRUFBQyxJQUFJO0lBQUMsY0FBVyxZQUFZO0lBQUFDLFFBQUEsZ0JBQzdDLElBQUE3QyxXQUFBLENBQUEyQyxJQUFBO01BQUtDLFNBQVMsRUFBQyxhQUFhO01BQUFDLFFBQUEsZ0JBQzFCLElBQUE3QyxXQUFBLENBQUE4QyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxtQkFBbUI7UUFBQUMsUUFBQSxFQUFDO01BQWEsQ0FBTSxDQUFDLGVBQ3hELElBQUE3QyxXQUFBLENBQUEyQyxJQUFBO1FBQU1DLFNBQVMsRUFBQyxtQkFBbUI7UUFBQUMsUUFBQSxHQUNoQ2hDLFlBQVksR0FBR3FCLGFBQWEsQ0FBQ3JCLFlBQVksQ0FBQyxHQUFHVCxRQUFRLGVBQ3RELElBQUFKLFdBQUEsQ0FBQThDLEdBQUE7VUFBTUYsU0FBUyxFQUFDLGtCQUFrQjtVQUFBQyxRQUFBLEVBQy9CeEMsTUFBTSxLQUFLLFFBQVEsR0FBRyxtQkFBbUIsR0FBRyxNQUFNQSxNQUFNO1FBQUUsQ0FDdkQsQ0FBQztNQUFBLENBQ0gsQ0FBQztJQUFBLENBQ0osQ0FBQyxlQUlOLElBQUFMLFdBQUEsQ0FBQTJDLElBQUE7TUFBS0MsU0FBUyxFQUFDLFNBQVM7TUFBQ0csSUFBSSxFQUFDLFlBQVk7TUFBQyxjQUFXLFlBQVk7TUFBQUYsUUFBQSxnQkFDaEUsSUFBQTdDLFdBQUEsQ0FBQTJDLElBQUE7UUFDRUssSUFBSSxFQUFDLFFBQVE7UUFDYkQsSUFBSSxFQUFDLE9BQU87UUFDWixnQkFBYzFDLE1BQU0sS0FBSyxRQUFTO1FBQ2xDdUMsU0FBUyxFQUFFLFVBQVV2QyxNQUFNLEtBQUssUUFBUSxHQUFHLFlBQVksR0FBRyxFQUFFLEVBQUc7UUFDL0Q0QyxPQUFPLEVBQUVBLENBQUEsS0FBTSxJQUFBQywwQkFBcUIsRUFBQztVQUFFQyxLQUFLLEVBQUUvQyxRQUFRO1VBQUVnRCxJQUFJLEVBQUU7UUFBUyxDQUFDLENBQUU7UUFBQVAsUUFBQSxnQkFFMUUsSUFBQTdDLFdBQUEsQ0FBQThDLEdBQUEsRUFBQ2hELFlBQUEsQ0FBQXVELE9BQU87VUFBQ0MsSUFBSSxFQUFFLEVBQUc7VUFBQyxlQUFZO1FBQU0sQ0FBRSxDQUFDLGVBQ3hDLElBQUF0RCxXQUFBLENBQUE4QyxHQUFBO1VBQUFELFFBQUEsRUFBTTtRQUFNLENBQU0sQ0FBQztNQUFBLENBQ2IsQ0FBQyxFQUNSNUIsWUFBWSxDQUFDc0MsR0FBRyxDQUFFQyxDQUFDLGlCQUNsQixJQUFBeEQsV0FBQSxDQUFBMkMsSUFBQTtRQUVFSyxJQUFJLEVBQUMsUUFBUTtRQUNiRCxJQUFJLEVBQUMsT0FBTztRQUNaLGdCQUFjMUMsTUFBTSxLQUFLbUQsQ0FBQyxDQUFDQyxFQUFHO1FBQzlCYixTQUFTLEVBQUUsVUFBVXZDLE1BQU0sS0FBS21ELENBQUMsQ0FBQ0MsRUFBRSxHQUFHLFlBQVksR0FBRyxFQUFFLEVBQUc7UUFDM0RSLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLElBQUFDLDBCQUFxQixFQUFDO1VBQUVDLEtBQUssRUFBRS9DLFFBQVE7VUFBRWdELElBQUksRUFBRUksQ0FBQyxDQUFDQztRQUFHLENBQUMsQ0FBRTtRQUFBWixRQUFBLEdBRXJFVyxDQUFDLENBQUNFLFFBQVEsS0FBSyxNQUFNLGdCQUNwQixJQUFBMUQsV0FBQSxDQUFBOEMsR0FBQSxFQUFDaEQsWUFBQSxDQUFBNkQsSUFBSTtVQUFDTCxJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQUMsZ0JBRXJDLElBQUF0RCxXQUFBLENBQUE4QyxHQUFBLEVBQUNoRCxZQUFBLENBQUE4RCxHQUFHO1VBQUNOLElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUUsQ0FDcEMsZUFDRCxJQUFBdEQsV0FBQSxDQUFBOEMsR0FBQTtVQUFBRCxRQUFBLEVBQU9XLENBQUMsQ0FBQ0M7UUFBRSxDQUFPLENBQUM7TUFBQSxHQVpkRCxDQUFDLENBQUNDLEVBYUQsQ0FDVCxDQUFDO0lBQUEsQ0FDQyxDQUFDLGVBR04sSUFBQXpELFdBQUEsQ0FBQTJDLElBQUE7TUFBS0MsU0FBUyxFQUFDLFVBQVU7TUFBQ0csSUFBSSxFQUFDLE1BQU07TUFBQyxjQUFXLFFBQVE7TUFBQUYsUUFBQSxHQUN0RHRDLE9BQU8sQ0FBQ08sTUFBTSxDQUFDeUMsR0FBRyxDQUFFcEIsS0FBSyxJQUFLO1FBQzdCLE1BQU0wQixNQUFNLEdBQUcxQixLQUFLLENBQUMvQixRQUFRLEtBQUtBLFFBQVE7UUFDMUMsb0JBQ0UsSUFBQUosV0FBQSxDQUFBMkMsSUFBQTtVQUEwQkMsU0FBUyxFQUFFLFlBQVlpQixNQUFNLEdBQUcsWUFBWSxHQUFHLEVBQUUsRUFBRztVQUFDZCxJQUFJLEVBQUMsVUFBVTtVQUFBRixRQUFBLGdCQUM1RixJQUFBN0MsV0FBQSxDQUFBMkMsSUFBQTtZQUNFSyxJQUFJLEVBQUMsUUFBUTtZQUNiSixTQUFTLEVBQUMsa0JBQWtCO1lBQzVCSyxPQUFPLEVBQUVBLENBQUEsS0FDUCxJQUFBQywwQkFBcUIsRUFBQztjQUNwQkMsS0FBSyxFQUFFaEIsS0FBSyxDQUFDL0IsUUFBUTtjQUNyQmdELElBQUksRUFBRS9DLE1BQU0sS0FBSyxRQUFRLEdBQUcsUUFBUSxHQUFHWSxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUV3QyxFQUFFLElBQUk7WUFDaEUsQ0FBQyxDQUNGO1lBQUFaLFFBQUEsR0FFQWdCLE1BQU0sZ0JBQUcsSUFBQTdELFdBQUEsQ0FBQThDLEdBQUEsRUFBQ2hELFlBQUEsQ0FBQWdFLEtBQUs7Y0FBQ1IsSUFBSSxFQUFFLEVBQUc7Y0FBQyxlQUFZO1lBQU0sQ0FBRSxDQUFDLGdCQUFHLElBQUF0RCxXQUFBLENBQUE4QyxHQUFBO2NBQU1GLFNBQVMsRUFBQztZQUFlLENBQUUsQ0FBQyxlQUNyRixJQUFBNUMsV0FBQSxDQUFBOEMsR0FBQTtjQUFBRCxRQUFBLEVBQU9YLGFBQWEsQ0FBQ0MsS0FBSztZQUFDLENBQU8sQ0FBQztVQUFBLENBQzdCLENBQUMsRUFDUjBCLE1BQU0saUJBQUksSUFBQTdELFdBQUEsQ0FBQThDLEdBQUE7WUFBTUYsU0FBUyxFQUFDLGtCQUFrQjtZQUFBQyxRQUFBLEVBQUM7VUFBTSxDQUFNLENBQUMsRUFDMURWLEtBQUssQ0FBQy9CLFFBQVEsS0FBSyx5QkFBeUIsaUJBQzNDLElBQUFKLFdBQUEsQ0FBQThDLEdBQUE7WUFDRUUsSUFBSSxFQUFDLFFBQVE7WUFDYkosU0FBUyxFQUFDLFlBQVk7WUFDdEJtQixLQUFLLEVBQUMsY0FBYztZQUNwQixjQUFZLFVBQVU1QixLQUFLLENBQUNHLEtBQUssRUFBRztZQUNwQ1csT0FBTyxFQUFFQSxDQUFBLEtBQU0sSUFBQWUsc0JBQWlCLEVBQUM3QixLQUFLLENBQUMvQixRQUFRLENBQUU7WUFBQXlDLFFBQUEsZUFFakQsSUFBQTdDLFdBQUEsQ0FBQThDLEdBQUEsRUFBQ2hELFlBQUEsQ0FBQW1FLE1BQU07Y0FBQ1gsSUFBSSxFQUFFLEVBQUc7Y0FBQyxlQUFZO1lBQU0sQ0FBRTtVQUFDLENBQ2pDLENBQ1Q7UUFBQSxHQXpCT25CLEtBQUssQ0FBQy9CLFFBMEJYLENBQUM7TUFFVixDQUFDLENBQUMsRUFDREcsT0FBTyxDQUFDTyxNQUFNLENBQUN5QixNQUFNLEtBQUssQ0FBQyxpQkFDMUIsSUFBQXZDLFdBQUEsQ0FBQThDLEdBQUE7UUFBR0YsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQWtELENBQUcsQ0FDOUU7SUFBQSxDQUNFLENBQUMsZUFFTixJQUFBN0MsV0FBQSxDQUFBMkMsSUFBQTtNQUFLQyxTQUFTLEVBQUMsU0FBUztNQUFBQyxRQUFBLGdCQUN0QixJQUFBN0MsV0FBQSxDQUFBMkMsSUFBQTtRQUNFSyxJQUFJLEVBQUMsUUFBUTtRQUNiSixTQUFTLEVBQUMsYUFBYTtRQUN2QnNCLFFBQVEsRUFBRXpELFFBQVEsQ0FBQ0csTUFBTSxLQUFLLFFBQVM7UUFDdkNxQyxPQUFPLEVBQUU5QixRQUFTO1FBQUEwQixRQUFBLEdBRWpCcEMsUUFBUSxDQUFDRyxNQUFNLEtBQUssUUFBUSxnQkFDM0IsSUFBQVosV0FBQSxDQUFBOEMsR0FBQSxFQUFDaEQsWUFBQSxDQUFBcUUsU0FBUztVQUFDYixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVksTUFBTTtVQUFDVixTQUFTLEVBQUM7UUFBVSxDQUFFLENBQUMsZ0JBRS9ELElBQUE1QyxXQUFBLENBQUE4QyxHQUFBLEVBQUNoRCxZQUFBLENBQUFzRSxJQUFJO1VBQUNkLElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUUsQ0FDckMsZUFDRCxJQUFBdEQsV0FBQSxDQUFBOEMsR0FBQTtVQUFBRCxRQUFBLEVBQU07UUFBVSxDQUFNLENBQUM7TUFBQSxDQUNqQixDQUFDLEVBQ1JwQyxRQUFRLENBQUNHLE1BQU0sS0FBSyxPQUFPLGlCQUFJLElBQUFaLFdBQUEsQ0FBQThDLEdBQUE7UUFBR0YsU0FBUyxFQUFDLHdCQUF3QjtRQUFBQyxRQUFBLEVBQUVwQyxRQUFRLENBQUNnQjtNQUFNLENBQUksQ0FBQyxFQUMxRmhCLFFBQVEsQ0FBQ0csTUFBTSxLQUFLLFNBQVMsaUJBQzVCLElBQUFaLFdBQUEsQ0FBQThDLEdBQUE7UUFBR0YsU0FBUyxFQUFDLHVCQUF1QjtRQUFBQyxRQUFBLEVBQUM7TUFBbUMsQ0FBRyxDQUM1RTtJQUFBLENBQ0UsQ0FBQyxlQUVOLElBQUE3QyxXQUFBLENBQUE4QyxHQUFBO01BQUdGLFNBQVMsRUFBQyxVQUFVO01BQUFDLFFBQUEsRUFBQztJQUd4QixDQUFHLENBQUM7RUFBQSxDQUNHLENBQUM7QUFFZDtBQUFDNUMsRUFBQSxDQWhLUUUsUUFBUTtFQUFBLFFBQ2NHLDBCQUFxQixFQUNsQ0Usb0JBQWU7QUFBQTtBQUFBNkQsRUFBQSxHQUZ4QmxFLFFBQVE7QUFBQSxJQUFBbUUsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FrS0ZyRSxRQUFRO0FBQUEsSUFBQWtFLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}