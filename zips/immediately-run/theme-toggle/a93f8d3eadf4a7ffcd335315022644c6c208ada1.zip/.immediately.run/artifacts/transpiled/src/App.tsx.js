var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./App.css");
var _Switcher = _interopRequireDefault(require("./components/Switcher"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The theme switcher (R3-501 · HOST_THEMING_SPEC §8.2): the `widget.theme` app
// upgraded in place from the two-state toggle.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Switcher.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX1N3aXRjaGVyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwianN4IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLlxuLy8gVGhlIHRoZW1lIHN3aXRjaGVyIChSMy01MDEgwrcgSE9TVF9USEVNSU5HX1NQRUMgwqc4LjIpOiB0aGUgYHdpZGdldC50aGVtZWAgYXBwXG4vLyB1cGdyYWRlZCBpbiBwbGFjZSBmcm9tIHRoZSB0d28tc3RhdGUgdG9nZ2xlLlxuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xuaW1wb3J0IFN3aXRjaGVyIGZyb20gXCIuL2NvbXBvbmVudHMvU3dpdGNoZXJcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gPFN3aXRjaGVyIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQUEsT0FBQTtBQUNBQSxPQUFBO0FBQ0EsSUFBQUMsU0FBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQTZDLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTDdDO0FBQ0E7QUFDQTs7QUFLQSxTQUFTRyxHQUFHQSxDQUFBLEVBQUc7RUFDYixvQkFBTyxJQUFBSixXQUFBLENBQUFLLEdBQUEsRUFBQ1AsU0FBQSxDQUFBSyxPQUFRLElBQUUsQ0FBQztBQUNyQjtBQUFDRyxFQUFBLEdBRlFGLEdBQUc7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUwsT0FBQSxHQUlHQyxHQUFHO0FBQUEsSUFBQUUsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}