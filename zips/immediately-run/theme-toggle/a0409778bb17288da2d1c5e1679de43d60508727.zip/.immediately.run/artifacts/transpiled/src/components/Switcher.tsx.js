var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _lucideReact = require("lucide-react");
var _sdk = require("@immediately-run/sdk");
var _select = require("../lib/select");
var _modeFor = require("../lib/modeFor");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The theme switcher (R3-501 · HOST_THEMING_SPEC §8.2) — the `widget.theme` app
// upgraded in place from the two-state toggle. It composes the R3-500 SDK
// surface over the widened wire:
//
//   - current selection (`useHostThemeSelection`);
//   - the theme list from the `theme-catalog` channel (`useThemeCatalog`);
//   - the mode list of the selected theme;
//   - label-collision disambiguation ("Nord (repo)");
//   - **Add theme** → invokes the `open-bundle` task with `kinds: ["theme"]` →
//     `addThemeSource(location)` with SYNCHRONOUS inline adoption feedback
//     (a rejected pick surfaces in the switcher, never another surface);
//   - refresh (re-push of the catalogue follows the service);
//   - remove.
//
// The host gate rejects anything this frame may not do (`forbidden` for a
// fork without `theme:set`/`theme:sources`); this UI degrades to a read-only
// "preview" view rather than erroring.
/** The `open-bundle` task result (OPEN_BUNDLE_SPEC §2): a picked location. */
/** The default theme's registry key — the SDK keeps its copy private, so this
 *  module owns the name (R3-847: one spelling, not six). */
const DEFAULT_THEME_KEY = "immediately-run-default";

/** §6's escape hatch, synthesized: the default row renders even when the
 *  catalogue is empty or the channel has not arrived. An empty target makes
 *  `modeFor` answer 'system' — the one selection the host always accepts. */
const DEFAULT_THEME = {
  themeKey: DEFAULT_THEME_KEY,
  label: "immediately.run default",
  modes: []
};
function Switcher() {
  _s();
  const {
    themeKey,
    modeId
  } = (0, _sdk.useHostThemeSelection)();
  const catalog = (0, _sdk.useThemeCatalog)();
  const [addState, setAddState] = (0, _react.useState)({
    status: "idle"
  });
  // R3-847 — a refused selection surfaces HERE, inline, and the switcher (and
  // the default row) stay clickable. `pendingKey` is the in-flight selection
  // (`theme|mode`): while one runs, the clicked control is `aria-busy` and
  // repeat clicks are ignored (R-IX-2); the applied selection arrives through
  // the `useHostThemeSelection` push, never as local state.
  const [selectError, setSelectError] = (0, _react.useState)(null);
  const [pendingKey, setPendingKey] = (0, _react.useState)(null);
  // The in-flight latch is a REF, not state: two clicks in one tick (a real
  // double-click) both read `pendingKey === null` before React commits, so a
  // state-only guard is racy — the ref is checked-and-set synchronously.
  const selectInFlight = (0, _react.useRef)(false);

  // The current theme entry (may be the default — always in the catalogue).
  const currentEntry = catalog.themes.find(t => t.themeKey === themeKey) ?? null;

  // Mode labels come from the catalogue (host-approved, bounded); the fixed
  // "System default" is always offered.
  const currentModes = currentEntry?.modes ?? [];
  // The tab stop derived ONCE (APG radio group: the checked radio, else the
  // first): a modeId matching no option must not drop the whole group out of
  // the tab order (R3-834 review round 2).
  const tabStopMode = modeId === "system" || currentModes.some(m => m.id === modeId) ? modeId : "system";

  /** One selection, caught: a refusal becomes an inline note, never a
   *  region-killing unhandled rejection (R3-847). */
  const select = (0, _react.useCallback)(async (theme, mode) => {
    const key = `${theme}|${mode}`;
    if (selectInFlight.current) return;
    selectInFlight.current = true;
    setSelectError(null);
    setPendingKey(key);
    const r = await (0, _select.selectTheme)(theme, mode);
    selectInFlight.current = false;
    setPendingKey(null);
    if (!r.ok) setSelectError(`That theme isn't available right now. ${r.reason}`);
  }, []);

  /** Invoke the open-bundle picker for a theme bundle, then adopt it. */
  const addTheme = (0, _react.useCallback)(async () => {
    setAddState({
      status: "adding"
    });
    try {
      const result = await (0, _sdk.invokeTask)("open-bundle", {
        kinds: ["theme"]
      });
      if (!result?.location) {
        setAddState({
          status: "error",
          reason: "The picker returned no location."
        });
        return;
      }
      await (0, _sdk.addThemeSource)(result.location);
      // Synchronous, inline feedback: the service loads + gates + registers
      // BEFORE returning, so a rejection surfaces here, in the switcher. The
      // catalogue channel re-push will surface the new theme in the list.
      setAddState({
        status: "adopted",
        themeKey: ""
      });
    } catch (e) {
      const err = e;
      setAddState({
        status: "error",
        reason: err?.message ?? (err?.code === "cancelled" ? "Add cancelled." : "Could not add that theme.")
      });
    } finally {
      // Keep the success/error visible briefly, then settle.
      window.setTimeout(() => setAddState(s => s.status === "adopted" || s.status === "error" ? {
        status: "idle"
      } : s), 2600);
    }
  }, []);

  /** Disambiguate a label collision: "Nord" from two sources → "Nord (repo)". */
  const disambiguated = (0, _react.useCallback)(entry => {
    const sameLabel = catalog.themes.filter(t => t.label === entry.label);
    if (sameLabel.length <= 1) return entry.label;
    // The baseline catalogue carries no source identities; the label is all a
    // baseline reader has. When labels collide we can't name the source (the
    // projection withholds it), so fall back to the key's tail.
    const tail = entry.themeKey.split("|").pop() ?? "";
    return `${entry.label} (${tail})`;
  }, [catalog]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "tt",
    "aria-label": "Host theme",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__current",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tt__current-label",
        children: "Current theme"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "tt__current-value",
        children: [currentEntry ? disambiguated(currentEntry) : "Unavailable theme", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "tt__current-mode",
          children: modeId === "system" ? " · System default" : ` · ${modeId}`
        })]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__seg",
      role: "radiogroup",
      "aria-label": "Theme mode",
      onKeyDown: e => {
        if (e.key !== "ArrowLeft" && e.key !== "ArrowRight" && e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
        e.preventDefault();
        const group = e.currentTarget;
        const opts = [...group.querySelectorAll('.tt__opt:not([aria-disabled="true"])')];
        if (opts.length < 2) return;
        const at = opts.indexOf(document.activeElement);
        const dir = e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1 : 1;
        const next = opts[(at + dir + opts.length) % opts.length];
        next.focus();
        next.click();
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": modeId === "system",
        "aria-busy": pendingKey === themeKey + "|system",
        "aria-disabled": pendingKey !== null,
        tabIndex: tabStopMode === "system" ? 0 : -1,
        className: `tt__opt${modeId === "system" ? " is-active" : ""}`,
        onClick: () => void select(themeKey, "system"),
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Monitor, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "System"
        })]
      }), currentModes.map(m => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": modeId === m.id,
        "aria-busy": pendingKey === themeKey + "|" + m.id,
        "aria-disabled": pendingKey !== null,
        tabIndex: tabStopMode === m.id ? 0 : -1,
        className: `tt__opt${modeId === m.id ? " is-active" : ""}`,
        onClick: () => void select(themeKey, m.id),
        children: [m.polarity === "dark" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Moon, {
          size: 15,
          "aria-hidden": "true"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Sun, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: m.id
        })]
      }, m.id))]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__list",
      role: "list",
      "aria-label": "Themes",
      children: [[DEFAULT_THEME, ...catalog.themes.filter(entry => entry.themeKey !== DEFAULT_THEME_KEY)].map(entry => {
        const active = entry.themeKey === themeKey;
        const targetMode = (0, _modeFor.modeFor)(modeId, currentModes, entry.modes);
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: `tt__theme${active ? " is-active" : ""}`,
          role: "listitem",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            type: "button",
            className: "tt__theme-select",
            "aria-busy": pendingKey === entry.themeKey + "|" + targetMode,
            "aria-disabled": pendingKey !== null,
            onClick: () => void select(entry.themeKey,
            // R3-847 — the user's intent, not a stale id: System
            // stays System; a fixed mode maps by polarity
            // (`modeFor`), so the target theme is never sent a mode
            // it does not carry.
            targetMode),
            children: [active ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Check, {
              size: 15,
              "aria-hidden": "true"
            }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "tt__theme-dot"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              children: entry.themeKey === DEFAULT_THEME_KEY ? "immediately.run default" : disambiguated(entry)
            })]
          }), active && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "tt__active-badge",
            children: "active"
          }), entry.themeKey !== DEFAULT_THEME_KEY && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "tt__remove",
            title: "Remove theme",
            "aria-label": `Remove ${entry.label}`,
            onClick: () => (0, _sdk.removeThemeSource)(entry.themeKey),
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Trash2, {
              size: 14,
              "aria-hidden": "true"
            })
          })]
        }, entry.themeKey);
      }), catalog.themes.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "tt__note",
        children: "No added themes yet. Add one from a repository or space."
      })]
    }), selectError && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      role: "status",
      className: "tt__note tt__note--err",
      children: selectError
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tt__add",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        className: "tt__add-btn",
        disabled: addState.status === "adding",
        onClick: addTheme,
        children: [addState.status === "adding" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.RefreshCw, {
          size: 15,
          "aria-hidden": "true",
          className: "tt__spin"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Plus, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "Add theme\u2026"
        })]
      }), addState.status === "error" && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        role: "status",
        className: "tt__note tt__note--err",
        children: addState.reason
      }), addState.status === "adopted" && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        role: "status",
        className: "tt__note tt__note--ok",
        children: "Added. Pick it from the list above."
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "tt__foot",
      children: "Themes are checked for contrast before they apply."
    })]
  });
}
_s(Switcher, "S4AsFFM/GMq0tl4udXVvD7KF7ts=", false, function () {
  return [_sdk.useHostThemeSelection, _sdk.useThemeCatalog];
});
_c = Switcher;
var _default = exports.default = Switcher;
var _c;
$RefreshReg$(_c, "Switcher");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX3NkayIsIl9zZWxlY3QiLCJfbW9kZUZvciIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJERUZBVUxUX1RIRU1FX0tFWSIsIkRFRkFVTFRfVEhFTUUiLCJ0aGVtZUtleSIsImxhYmVsIiwibW9kZXMiLCJTd2l0Y2hlciIsIm1vZGVJZCIsInVzZUhvc3RUaGVtZVNlbGVjdGlvbiIsImNhdGFsb2ciLCJ1c2VUaGVtZUNhdGFsb2ciLCJhZGRTdGF0ZSIsInNldEFkZFN0YXRlIiwidXNlU3RhdGUiLCJzdGF0dXMiLCJzZWxlY3RFcnJvciIsInNldFNlbGVjdEVycm9yIiwicGVuZGluZ0tleSIsInNldFBlbmRpbmdLZXkiLCJzZWxlY3RJbkZsaWdodCIsInVzZVJlZiIsImN1cnJlbnRFbnRyeSIsInRoZW1lcyIsImZpbmQiLCJ0IiwiY3VycmVudE1vZGVzIiwidGFiU3RvcE1vZGUiLCJzb21lIiwibSIsImlkIiwic2VsZWN0IiwidXNlQ2FsbGJhY2siLCJ0aGVtZSIsIm1vZGUiLCJrZXkiLCJjdXJyZW50IiwiciIsInNlbGVjdFRoZW1lIiwib2siLCJyZWFzb24iLCJhZGRUaGVtZSIsInJlc3VsdCIsImludm9rZVRhc2siLCJraW5kcyIsImxvY2F0aW9uIiwiYWRkVGhlbWVTb3VyY2UiLCJlIiwiZXJyIiwibWVzc2FnZSIsImNvZGUiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwicyIsImRpc2FtYmlndWF0ZWQiLCJlbnRyeSIsInNhbWVMYWJlbCIsImZpbHRlciIsImxlbmd0aCIsInRhaWwiLCJzcGxpdCIsInBvcCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInJvbGUiLCJvbktleURvd24iLCJwcmV2ZW50RGVmYXVsdCIsImdyb3VwIiwiY3VycmVudFRhcmdldCIsIm9wdHMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiYXQiLCJpbmRleE9mIiwiZG9jdW1lbnQiLCJhY3RpdmVFbGVtZW50IiwiZGlyIiwibmV4dCIsImZvY3VzIiwiY2xpY2siLCJ0eXBlIiwidGFiSW5kZXgiLCJvbkNsaWNrIiwiTW9uaXRvciIsInNpemUiLCJtYXAiLCJwb2xhcml0eSIsIk1vb24iLCJTdW4iLCJhY3RpdmUiLCJ0YXJnZXRNb2RlIiwibW9kZUZvciIsIkNoZWNrIiwidGl0bGUiLCJyZW1vdmVUaGVtZVNvdXJjZSIsIlRyYXNoMiIsImRpc2FibGVkIiwiUmVmcmVzaEN3IiwiUGx1cyIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN3aXRjaGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgdGhlbWUgc3dpdGNoZXIgKFIzLTUwMSDCtyBIT1NUX1RIRU1JTkdfU1BFQyDCpzguMikg4oCUIHRoZSBgd2lkZ2V0LnRoZW1lYCBhcHBcbi8vIHVwZ3JhZGVkIGluIHBsYWNlIGZyb20gdGhlIHR3by1zdGF0ZSB0b2dnbGUuIEl0IGNvbXBvc2VzIHRoZSBSMy01MDAgU0RLXG4vLyBzdXJmYWNlIG92ZXIgdGhlIHdpZGVuZWQgd2lyZTpcbi8vXG4vLyAgIC0gY3VycmVudCBzZWxlY3Rpb24gKGB1c2VIb3N0VGhlbWVTZWxlY3Rpb25gKTtcbi8vICAgLSB0aGUgdGhlbWUgbGlzdCBmcm9tIHRoZSBgdGhlbWUtY2F0YWxvZ2AgY2hhbm5lbCAoYHVzZVRoZW1lQ2F0YWxvZ2ApO1xuLy8gICAtIHRoZSBtb2RlIGxpc3Qgb2YgdGhlIHNlbGVjdGVkIHRoZW1lO1xuLy8gICAtIGxhYmVsLWNvbGxpc2lvbiBkaXNhbWJpZ3VhdGlvbiAoXCJOb3JkIChyZXBvKVwiKTtcbi8vICAgLSAqKkFkZCB0aGVtZSoqIOKGkiBpbnZva2VzIHRoZSBgb3Blbi1idW5kbGVgIHRhc2sgd2l0aCBga2luZHM6IFtcInRoZW1lXCJdYCDihpJcbi8vICAgICBgYWRkVGhlbWVTb3VyY2UobG9jYXRpb24pYCB3aXRoIFNZTkNIUk9OT1VTIGlubGluZSBhZG9wdGlvbiBmZWVkYmFja1xuLy8gICAgIChhIHJlamVjdGVkIHBpY2sgc3VyZmFjZXMgaW4gdGhlIHN3aXRjaGVyLCBuZXZlciBhbm90aGVyIHN1cmZhY2UpO1xuLy8gICAtIHJlZnJlc2ggKHJlLXB1c2ggb2YgdGhlIGNhdGFsb2d1ZSBmb2xsb3dzIHRoZSBzZXJ2aWNlKTtcbi8vICAgLSByZW1vdmUuXG4vL1xuLy8gVGhlIGhvc3QgZ2F0ZSByZWplY3RzIGFueXRoaW5nIHRoaXMgZnJhbWUgbWF5IG5vdCBkbyAoYGZvcmJpZGRlbmAgZm9yIGFcbi8vIGZvcmsgd2l0aG91dCBgdGhlbWU6c2V0YC9gdGhlbWU6c291cmNlc2ApOyB0aGlzIFVJIGRlZ3JhZGVzIHRvIGEgcmVhZC1vbmx5XG4vLyBcInByZXZpZXdcIiB2aWV3IHJhdGhlciB0aGFuIGVycm9yaW5nLlxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZWNrLCBNb29uLCBQbHVzLCBSZWZyZXNoQ3csIFN1biwgVHJhc2gyLCBNb25pdG9yIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHtcbiAgdXNlSG9zdFRoZW1lU2VsZWN0aW9uLFxuICB1c2VUaGVtZUNhdGFsb2csXG4gIGFkZFRoZW1lU291cmNlLFxuICByZW1vdmVUaGVtZVNvdXJjZSxcbiAgaW52b2tlVGFzayxcbiAgdHlwZSBUaGVtZUJ1bmRsZUxvY2F0aW9uLFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCB7IHNlbGVjdFRoZW1lIH0gZnJvbSBcIi4uL2xpYi9zZWxlY3RcIjtcbmltcG9ydCB7IG1vZGVGb3IgfSBmcm9tIFwiLi4vbGliL21vZGVGb3JcIjtcblxuLyoqIFRoZSBgb3Blbi1idW5kbGVgIHRhc2sgcmVzdWx0IChPUEVOX0JVTkRMRV9TUEVDIMKnMik6IGEgcGlja2VkIGxvY2F0aW9uLiAqL1xuaW50ZXJmYWNlIE9wZW5CdW5kbGVSZXN1bHQge1xuICBsb2NhdGlvbjogVGhlbWVCdW5kbGVMb2NhdGlvbjtcbn1cblxudHlwZSBBZGRTdGF0ZSA9XG4gIHwgeyBzdGF0dXM6IFwiaWRsZVwiIH1cbiAgfCB7IHN0YXR1czogXCJhZGRpbmdcIiB9XG4gIHwgeyBzdGF0dXM6IFwiZXJyb3JcIjsgcmVhc29uOiBzdHJpbmcgfVxuICB8IHsgc3RhdHVzOiBcImFkb3B0ZWRcIjsgdGhlbWVLZXk6IHN0cmluZyB9O1xuXG4vKiogVGhlIGRlZmF1bHQgdGhlbWUncyByZWdpc3RyeSBrZXkg4oCUIHRoZSBTREsga2VlcHMgaXRzIGNvcHkgcHJpdmF0ZSwgc28gdGhpc1xuICogIG1vZHVsZSBvd25zIHRoZSBuYW1lIChSMy04NDc6IG9uZSBzcGVsbGluZywgbm90IHNpeCkuICovXG5jb25zdCBERUZBVUxUX1RIRU1FX0tFWSA9IFwiaW1tZWRpYXRlbHktcnVuLWRlZmF1bHRcIjtcblxuLyoqIMKnNidzIGVzY2FwZSBoYXRjaCwgc3ludGhlc2l6ZWQ6IHRoZSBkZWZhdWx0IHJvdyByZW5kZXJzIGV2ZW4gd2hlbiB0aGVcbiAqICBjYXRhbG9ndWUgaXMgZW1wdHkgb3IgdGhlIGNoYW5uZWwgaGFzIG5vdCBhcnJpdmVkLiBBbiBlbXB0eSB0YXJnZXQgbWFrZXNcbiAqICBgbW9kZUZvcmAgYW5zd2VyICdzeXN0ZW0nIOKAlCB0aGUgb25lIHNlbGVjdGlvbiB0aGUgaG9zdCBhbHdheXMgYWNjZXB0cy4gKi9cbmNvbnN0IERFRkFVTFRfVEhFTUUgPSB7XG4gIHRoZW1lS2V5OiBERUZBVUxUX1RIRU1FX0tFWSxcbiAgbGFiZWw6IFwiaW1tZWRpYXRlbHkucnVuIGRlZmF1bHRcIixcbiAgbW9kZXM6IFtdIGFzIHsgaWQ6IHN0cmluZzsgcG9sYXJpdHk6IFwibGlnaHRcIiB8IFwiZGFya1wiIH1bXSxcbn07XG5cbmZ1bmN0aW9uIFN3aXRjaGVyKCkge1xuICBjb25zdCB7IHRoZW1lS2V5LCBtb2RlSWQgfSA9IHVzZUhvc3RUaGVtZVNlbGVjdGlvbigpO1xuICBjb25zdCBjYXRhbG9nID0gdXNlVGhlbWVDYXRhbG9nKCk7XG4gIGNvbnN0IFthZGRTdGF0ZSwgc2V0QWRkU3RhdGVdID0gdXNlU3RhdGU8QWRkU3RhdGU+KHsgc3RhdHVzOiBcImlkbGVcIiB9KTtcbiAgLy8gUjMtODQ3IOKAlCBhIHJlZnVzZWQgc2VsZWN0aW9uIHN1cmZhY2VzIEhFUkUsIGlubGluZSwgYW5kIHRoZSBzd2l0Y2hlciAoYW5kXG4gIC8vIHRoZSBkZWZhdWx0IHJvdykgc3RheSBjbGlja2FibGUuIGBwZW5kaW5nS2V5YCBpcyB0aGUgaW4tZmxpZ2h0IHNlbGVjdGlvblxuICAvLyAoYHRoZW1lfG1vZGVgKTogd2hpbGUgb25lIHJ1bnMsIHRoZSBjbGlja2VkIGNvbnRyb2wgaXMgYGFyaWEtYnVzeWAgYW5kXG4gIC8vIHJlcGVhdCBjbGlja3MgYXJlIGlnbm9yZWQgKFItSVgtMik7IHRoZSBhcHBsaWVkIHNlbGVjdGlvbiBhcnJpdmVzIHRocm91Z2hcbiAgLy8gdGhlIGB1c2VIb3N0VGhlbWVTZWxlY3Rpb25gIHB1c2gsIG5ldmVyIGFzIGxvY2FsIHN0YXRlLlxuICBjb25zdCBbc2VsZWN0RXJyb3IsIHNldFNlbGVjdEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcGVuZGluZ0tleSwgc2V0UGVuZGluZ0tleV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgLy8gVGhlIGluLWZsaWdodCBsYXRjaCBpcyBhIFJFRiwgbm90IHN0YXRlOiB0d28gY2xpY2tzIGluIG9uZSB0aWNrIChhIHJlYWxcbiAgLy8gZG91YmxlLWNsaWNrKSBib3RoIHJlYWQgYHBlbmRpbmdLZXkgPT09IG51bGxgIGJlZm9yZSBSZWFjdCBjb21taXRzLCBzbyBhXG4gIC8vIHN0YXRlLW9ubHkgZ3VhcmQgaXMgcmFjeSDigJQgdGhlIHJlZiBpcyBjaGVja2VkLWFuZC1zZXQgc3luY2hyb25vdXNseS5cbiAgY29uc3Qgc2VsZWN0SW5GbGlnaHQgPSB1c2VSZWYoZmFsc2UpO1xuXG4gIC8vIFRoZSBjdXJyZW50IHRoZW1lIGVudHJ5IChtYXkgYmUgdGhlIGRlZmF1bHQg4oCUIGFsd2F5cyBpbiB0aGUgY2F0YWxvZ3VlKS5cbiAgY29uc3QgY3VycmVudEVudHJ5ID0gY2F0YWxvZy50aGVtZXMuZmluZCgodCkgPT4gdC50aGVtZUtleSA9PT0gdGhlbWVLZXkpID8/IG51bGw7XG5cbiAgLy8gTW9kZSBsYWJlbHMgY29tZSBmcm9tIHRoZSBjYXRhbG9ndWUgKGhvc3QtYXBwcm92ZWQsIGJvdW5kZWQpOyB0aGUgZml4ZWRcbiAgLy8gXCJTeXN0ZW0gZGVmYXVsdFwiIGlzIGFsd2F5cyBvZmZlcmVkLlxuICBjb25zdCBjdXJyZW50TW9kZXMgPSBjdXJyZW50RW50cnk/Lm1vZGVzID8/IFtdO1xuICAvLyBUaGUgdGFiIHN0b3AgZGVyaXZlZCBPTkNFIChBUEcgcmFkaW8gZ3JvdXA6IHRoZSBjaGVja2VkIHJhZGlvLCBlbHNlIHRoZVxuICAvLyBmaXJzdCk6IGEgbW9kZUlkIG1hdGNoaW5nIG5vIG9wdGlvbiBtdXN0IG5vdCBkcm9wIHRoZSB3aG9sZSBncm91cCBvdXQgb2ZcbiAgLy8gdGhlIHRhYiBvcmRlciAoUjMtODM0IHJldmlldyByb3VuZCAyKS5cbiAgY29uc3QgdGFiU3RvcE1vZGUgPVxuICAgIG1vZGVJZCA9PT0gXCJzeXN0ZW1cIiB8fCBjdXJyZW50TW9kZXMuc29tZSgobSkgPT4gbS5pZCA9PT0gbW9kZUlkKSA/IG1vZGVJZCA6IFwic3lzdGVtXCI7XG5cbiAgLyoqIE9uZSBzZWxlY3Rpb24sIGNhdWdodDogYSByZWZ1c2FsIGJlY29tZXMgYW4gaW5saW5lIG5vdGUsIG5ldmVyIGFcbiAgICogIHJlZ2lvbi1raWxsaW5nIHVuaGFuZGxlZCByZWplY3Rpb24gKFIzLTg0NykuICovXG4gIGNvbnN0IHNlbGVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh0aGVtZTogc3RyaW5nLCBtb2RlOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGtleSA9IGAke3RoZW1lfXwke21vZGV9YDtcbiAgICAgIGlmIChzZWxlY3RJbkZsaWdodC5jdXJyZW50KSByZXR1cm47XG4gICAgICBzZWxlY3RJbkZsaWdodC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHNldFNlbGVjdEVycm9yKG51bGwpO1xuICAgICAgc2V0UGVuZGluZ0tleShrZXkpO1xuICAgICAgY29uc3QgciA9IGF3YWl0IHNlbGVjdFRoZW1lKHRoZW1lLCBtb2RlKTtcbiAgICAgIHNlbGVjdEluRmxpZ2h0LmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIHNldFBlbmRpbmdLZXkobnVsbCk7XG4gICAgICBpZiAoIXIub2spIHNldFNlbGVjdEVycm9yKGBUaGF0IHRoZW1lIGlzbid0IGF2YWlsYWJsZSByaWdodCBub3cuICR7ci5yZWFzb259YCk7XG4gICAgfSxcbiAgICBbXSxcbiAgKTtcblxuICAvKiogSW52b2tlIHRoZSBvcGVuLWJ1bmRsZSBwaWNrZXIgZm9yIGEgdGhlbWUgYnVuZGxlLCB0aGVuIGFkb3B0IGl0LiAqL1xuICBjb25zdCBhZGRUaGVtZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBzZXRBZGRTdGF0ZSh7IHN0YXR1czogXCJhZGRpbmdcIiB9KTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgaW52b2tlVGFzazxPcGVuQnVuZGxlUmVzdWx0PihcIm9wZW4tYnVuZGxlXCIsIHtcbiAgICAgICAga2luZHM6IFtcInRoZW1lXCJdLFxuICAgICAgfSk7XG4gICAgICBpZiAoIXJlc3VsdD8ubG9jYXRpb24pIHtcbiAgICAgICAgc2V0QWRkU3RhdGUoeyBzdGF0dXM6IFwiZXJyb3JcIiwgcmVhc29uOiBcIlRoZSBwaWNrZXIgcmV0dXJuZWQgbm8gbG9jYXRpb24uXCIgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGFkZFRoZW1lU291cmNlKHJlc3VsdC5sb2NhdGlvbik7XG4gICAgICAvLyBTeW5jaHJvbm91cywgaW5saW5lIGZlZWRiYWNrOiB0aGUgc2VydmljZSBsb2FkcyArIGdhdGVzICsgcmVnaXN0ZXJzXG4gICAgICAvLyBCRUZPUkUgcmV0dXJuaW5nLCBzbyBhIHJlamVjdGlvbiBzdXJmYWNlcyBoZXJlLCBpbiB0aGUgc3dpdGNoZXIuIFRoZVxuICAgICAgLy8gY2F0YWxvZ3VlIGNoYW5uZWwgcmUtcHVzaCB3aWxsIHN1cmZhY2UgdGhlIG5ldyB0aGVtZSBpbiB0aGUgbGlzdC5cbiAgICAgIHNldEFkZFN0YXRlKHsgc3RhdHVzOiBcImFkb3B0ZWRcIiwgdGhlbWVLZXk6IFwiXCIgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgZXJyID0gZSBhcyB7IGNvZGU/OiBzdHJpbmc7IG1lc3NhZ2U/OiBzdHJpbmcgfTtcbiAgICAgIHNldEFkZFN0YXRlKHtcbiAgICAgICAgc3RhdHVzOiBcImVycm9yXCIsXG4gICAgICAgIHJlYXNvbjogZXJyPy5tZXNzYWdlID8/IChlcnI/LmNvZGUgPT09IFwiY2FuY2VsbGVkXCIgPyBcIkFkZCBjYW5jZWxsZWQuXCIgOiBcIkNvdWxkIG5vdCBhZGQgdGhhdCB0aGVtZS5cIiksXG4gICAgICB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgLy8gS2VlcCB0aGUgc3VjY2Vzcy9lcnJvciB2aXNpYmxlIGJyaWVmbHksIHRoZW4gc2V0dGxlLlxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0QWRkU3RhdGUoKHMpID0+IChzLnN0YXR1cyA9PT0gXCJhZG9wdGVkXCIgfHwgcy5zdGF0dXMgPT09IFwiZXJyb3JcIiA/IHsgc3RhdHVzOiBcImlkbGVcIiB9IDogcykpLCAyNjAwKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICAvKiogRGlzYW1iaWd1YXRlIGEgbGFiZWwgY29sbGlzaW9uOiBcIk5vcmRcIiBmcm9tIHR3byBzb3VyY2VzIOKGkiBcIk5vcmQgKHJlcG8pXCIuICovXG4gIGNvbnN0IGRpc2FtYmlndWF0ZWQgPSB1c2VDYWxsYmFjaygoZW50cnk6ICh0eXBlb2YgY2F0YWxvZy50aGVtZXMpW251bWJlcl0pOiBzdHJpbmcgPT4ge1xuICAgIGNvbnN0IHNhbWVMYWJlbCA9IGNhdGFsb2cudGhlbWVzLmZpbHRlcigodCkgPT4gdC5sYWJlbCA9PT0gZW50cnkubGFiZWwpO1xuICAgIGlmIChzYW1lTGFiZWwubGVuZ3RoIDw9IDEpIHJldHVybiBlbnRyeS5sYWJlbDtcbiAgICAvLyBUaGUgYmFzZWxpbmUgY2F0YWxvZ3VlIGNhcnJpZXMgbm8gc291cmNlIGlkZW50aXRpZXM7IHRoZSBsYWJlbCBpcyBhbGwgYVxuICAgIC8vIGJhc2VsaW5lIHJlYWRlciBoYXMuIFdoZW4gbGFiZWxzIGNvbGxpZGUgd2UgY2FuJ3QgbmFtZSB0aGUgc291cmNlICh0aGVcbiAgICAvLyBwcm9qZWN0aW9uIHdpdGhob2xkcyBpdCksIHNvIGZhbGwgYmFjayB0byB0aGUga2V5J3MgdGFpbC5cbiAgICBjb25zdCB0YWlsID0gZW50cnkudGhlbWVLZXkuc3BsaXQoXCJ8XCIpLnBvcCgpID8/IFwiXCI7XG4gICAgcmV0dXJuIGAke2VudHJ5LmxhYmVsfSAoJHt0YWlsfSlgO1xuICB9LCBbY2F0YWxvZ10pO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidHRcIiBhcmlhLWxhYmVsPVwiSG9zdCB0aGVtZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0dF9fY3VycmVudFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0dF9fY3VycmVudC1sYWJlbFwiPkN1cnJlbnQgdGhlbWU8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInR0X19jdXJyZW50LXZhbHVlXCI+XG4gICAgICAgICAgey8qIFIzLTg0NzogbmV2ZXIgYSByYXcgdGhlbWVLZXkg4oCUIGFuIGVudHJ5IG1pc3NpbmcgZnJvbSB0aGVcbiAgICAgICAgICAgICAgY2F0YWxvZ3VlIHJlYWRzIFwiVW5hdmFpbGFibGUgdGhlbWVcIi4gKi99XG4gICAgICAgICAge2N1cnJlbnRFbnRyeSA/IGRpc2FtYmlndWF0ZWQoY3VycmVudEVudHJ5KSA6IFwiVW5hdmFpbGFibGUgdGhlbWVcIn1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0dF9fY3VycmVudC1tb2RlXCI+XG4gICAgICAgICAgICB7bW9kZUlkID09PSBcInN5c3RlbVwiID8gXCIgwrcgU3lzdGVtIGRlZmF1bHRcIiA6IGAgwrcgJHttb2RlSWR9YH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTW9kZSBsaXN0IG9mIHRoZSBzZWxlY3RlZCB0aGVtZSAoZml4ZWQgaG9zdCBsYWJlbHM7IHRoZSBjYXRhbG9ndWUnc1xuICAgICAgICAgIG1vZGUgaWRzIGFyZSB0aGUgcmVzb2x2ZWQgb25lcykuIFIzLTgzNCByZXZpZXcgcm91bmQgMTogdGhlIEFQR1xuICAgICAgICAgIHJhZGlvZ3JvdXAgcGF0dGVybiBpcyBpbXBsZW1lbnRlZCBmb3IgcmVhbCDigJQgYSByb3ZpbmcgdGFiaW5kZXhcbiAgICAgICAgICAodGhlIGNoZWNrZWQgb3B0aW9uIGlzIHRoZSB0YWIgc3RvcCkgYW5kIGFycm93IGtleXMgbW92ZSBmb2N1cyBhbmRcbiAgICAgICAgICBzZWxlY3QsIGV4YWN0bHkgd2hhdCByb2xlPVwicmFkaW9ncm91cFwiIGFubm91bmNlcy4gKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cInR0X19zZWdcIlxuICAgICAgICByb2xlPVwicmFkaW9ncm91cFwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJUaGVtZSBtb2RlXCJcbiAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xuICAgICAgICAgIGlmIChlLmtleSAhPT0gXCJBcnJvd0xlZnRcIiAmJiBlLmtleSAhPT0gXCJBcnJvd1JpZ2h0XCIgJiYgZS5rZXkgIT09IFwiQXJyb3dVcFwiICYmIGUua2V5ICE9PSBcIkFycm93RG93blwiKSByZXR1cm47XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IGdyb3VwID0gZS5jdXJyZW50VGFyZ2V0O1xuICAgICAgICAgIGNvbnN0IG9wdHMgPSBbLi4uZ3JvdXAucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oJy50dF9fb3B0Om5vdChbYXJpYS1kaXNhYmxlZD1cInRydWVcIl0pJyldO1xuICAgICAgICAgIGlmIChvcHRzLmxlbmd0aCA8IDIpIHJldHVybjtcbiAgICAgICAgICBjb25zdCBhdCA9IG9wdHMuaW5kZXhPZihkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxFbGVtZW50KTtcbiAgICAgICAgICBjb25zdCBkaXIgPSBlLmtleSA9PT0gXCJBcnJvd0xlZnRcIiB8fCBlLmtleSA9PT0gXCJBcnJvd1VwXCIgPyAtMSA6IDE7XG4gICAgICAgICAgY29uc3QgbmV4dCA9IG9wdHNbKGF0ICsgZGlyICsgb3B0cy5sZW5ndGgpICUgb3B0cy5sZW5ndGhdO1xuICAgICAgICAgIG5leHQuZm9jdXMoKTtcbiAgICAgICAgICBuZXh0LmNsaWNrKCk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICByb2xlPVwicmFkaW9cIlxuICAgICAgICAgIGFyaWEtY2hlY2tlZD17bW9kZUlkID09PSBcInN5c3RlbVwifVxuICAgICAgICAgIGFyaWEtYnVzeT17cGVuZGluZ0tleSA9PT0gdGhlbWVLZXkgKyBcInxzeXN0ZW1cIn1cbiAgICAgICAgICBhcmlhLWRpc2FibGVkPXtwZW5kaW5nS2V5ICE9PSBudWxsfVxuICAgICAgICAgIHRhYkluZGV4PXt0YWJTdG9wTW9kZSA9PT0gXCJzeXN0ZW1cIiA/IDAgOiAtMX1cbiAgICAgICAgICBjbGFzc05hbWU9e2B0dF9fb3B0JHttb2RlSWQgPT09IFwic3lzdGVtXCIgPyBcIiBpcy1hY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHNlbGVjdCh0aGVtZUtleSwgXCJzeXN0ZW1cIil9XG4gICAgICAgID5cbiAgICAgICAgICA8TW9uaXRvciBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8c3Bhbj5TeXN0ZW08L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7Y3VycmVudE1vZGVzLm1hcCgobSkgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17bS5pZH1cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgcm9sZT1cInJhZGlvXCJcbiAgICAgICAgICAgIGFyaWEtY2hlY2tlZD17bW9kZUlkID09PSBtLmlkfVxuICAgICAgICAgICAgYXJpYS1idXN5PXtwZW5kaW5nS2V5ID09PSB0aGVtZUtleSArIFwifFwiICsgbS5pZH1cbiAgICAgICAgICAgIGFyaWEtZGlzYWJsZWQ9e3BlbmRpbmdLZXkgIT09IG51bGx9XG4gICAgICAgICAgICB0YWJJbmRleD17dGFiU3RvcE1vZGUgPT09IG0uaWQgPyAwIDogLTF9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2B0dF9fb3B0JHttb2RlSWQgPT09IG0uaWQgPyBcIiBpcy1hY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgc2VsZWN0KHRoZW1lS2V5LCBtLmlkKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bS5wb2xhcml0eSA9PT0gXCJkYXJrXCIgPyAoXG4gICAgICAgICAgICAgIDxNb29uIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPFN1biBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8c3Bhbj57bS5pZH08L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUaGVtZSBsaXN0IGZyb20gdGhlIGNhdGFsb2d1ZSBjaGFubmVsLCB3aXRoIMKnNidzIGVzY2FwZSBoYXRjaCBmb2xkZWRcbiAgICAgICAgICBpbiBhcyB0aGUgZmlyc3QgZW50cnkgKFIzLTg0Nyk6IHRoZSBkZWZhdWx0IHJvdyBBTFdBWVMgcmVuZGVycyDigJRcbiAgICAgICAgICBlbXB0eSBjYXRhbG9ndWUsIGNoYW5uZWwgbm90IGFycml2ZWQsIHJlZnVzZWQgc2VsZWN0aW9uIOKAlCB0aHJvdWdoIHRoZVxuICAgICAgICAgIHNhbWUgcm93IHRlbXBsYXRlLCBhbmQgaXRzIGNsaWNrIHJlc29sdmVzIHRvIHRoZSBvbmUgc2VsZWN0aW9uIHRoZVxuICAgICAgICAgIGhvc3QgYWx3YXlzIGFjY2VwdHMgKG1vZGVGb3Igb3ZlciBhbiBlbXB0eSB0YXJnZXQgaXMgJ3N5c3RlbScpLiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHRfX2xpc3RcIiByb2xlPVwibGlzdFwiIGFyaWEtbGFiZWw9XCJUaGVtZXNcIj5cbiAgICAgICAge1tERUZBVUxUX1RIRU1FLCAuLi5jYXRhbG9nLnRoZW1lcy5maWx0ZXIoKGVudHJ5KSA9PiBlbnRyeS50aGVtZUtleSAhPT0gREVGQVVMVF9USEVNRV9LRVkpXVxuICAgICAgICAgIC5tYXAoKGVudHJ5KSA9PiB7XG4gICAgICAgICAgY29uc3QgYWN0aXZlID0gZW50cnkudGhlbWVLZXkgPT09IHRoZW1lS2V5O1xuICAgICAgICAgIGNvbnN0IHRhcmdldE1vZGUgPSBtb2RlRm9yKG1vZGVJZCwgY3VycmVudE1vZGVzLCBlbnRyeS5tb2Rlcyk7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYga2V5PXtlbnRyeS50aGVtZUtleX0gY2xhc3NOYW1lPXtgdHRfX3RoZW1lJHthY3RpdmUgPyBcIiBpcy1hY3RpdmVcIiA6IFwiXCJ9YH0gcm9sZT1cImxpc3RpdGVtXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0dF9fdGhlbWUtc2VsZWN0XCJcbiAgICAgICAgICAgICAgICBhcmlhLWJ1c3k9e3BlbmRpbmdLZXkgPT09IGVudHJ5LnRoZW1lS2V5ICsgXCJ8XCIgKyB0YXJnZXRNb2RlfVxuICAgICAgICAgICAgICAgIGFyaWEtZGlzYWJsZWQ9e3BlbmRpbmdLZXkgIT09IG51bGx9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgIHZvaWQgc2VsZWN0KFxuICAgICAgICAgICAgICAgICAgICBlbnRyeS50aGVtZUtleSxcbiAgICAgICAgICAgICAgICAgICAgLy8gUjMtODQ3IOKAlCB0aGUgdXNlcidzIGludGVudCwgbm90IGEgc3RhbGUgaWQ6IFN5c3RlbVxuICAgICAgICAgICAgICAgICAgICAvLyBzdGF5cyBTeXN0ZW07IGEgZml4ZWQgbW9kZSBtYXBzIGJ5IHBvbGFyaXR5XG4gICAgICAgICAgICAgICAgICAgIC8vIChgbW9kZUZvcmApLCBzbyB0aGUgdGFyZ2V0IHRoZW1lIGlzIG5ldmVyIHNlbnQgYSBtb2RlXG4gICAgICAgICAgICAgICAgICAgIC8vIGl0IGRvZXMgbm90IGNhcnJ5LlxuICAgICAgICAgICAgICAgICAgICB0YXJnZXRNb2RlLFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHthY3RpdmUgPyA8Q2hlY2sgc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+IDogPHNwYW4gY2xhc3NOYW1lPVwidHRfX3RoZW1lLWRvdFwiIC8+fVxuICAgICAgICAgICAgICAgIDxzcGFuPntlbnRyeS50aGVtZUtleSA9PT0gREVGQVVMVF9USEVNRV9LRVkgPyBcImltbWVkaWF0ZWx5LnJ1biBkZWZhdWx0XCIgOiBkaXNhbWJpZ3VhdGVkKGVudHJ5KX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7YWN0aXZlICYmIDxzcGFuIGNsYXNzTmFtZT1cInR0X19hY3RpdmUtYmFkZ2VcIj5hY3RpdmU8L3NwYW4+fVxuICAgICAgICAgICAgICB7ZW50cnkudGhlbWVLZXkgIT09IERFRkFVTFRfVEhFTUVfS0VZICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInR0X19yZW1vdmVcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmUgdGhlbWVcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFJlbW92ZSAke2VudHJ5LmxhYmVsfWB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVUaGVtZVNvdXJjZShlbnRyeS50aGVtZUtleSl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgICB7Y2F0YWxvZy50aGVtZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0dF9fbm90ZVwiPk5vIGFkZGVkIHRoZW1lcyB5ZXQuIEFkZCBvbmUgZnJvbSBhIHJlcG9zaXRvcnkgb3Igc3BhY2UuPC9wPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSMy04NDcg4oCUIGEgcmVmdXNlZCBzZWxlY3Rpb24ncyByZWFzb24sIGlubGluZSB1bmRlciB0aGUgY29udHJvbCB0aGF0XG4gICAgICAgICAgY2F1c2VkIGl0OyB0aGUgc3dpdGNoZXIgc3RheXMgbW91bnRlZCBhbmQgZXZlcnkgcm93IHN0YXlzIGNsaWNrYWJsZS4gKi99XG4gICAgICB7c2VsZWN0RXJyb3IgJiYgKFxuICAgICAgICA8cCByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwidHRfX25vdGUgdHRfX25vdGUtLWVyclwiPlxuICAgICAgICAgIHtzZWxlY3RFcnJvcn1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0dF9fYWRkXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0dF9fYWRkLWJ0blwiXG4gICAgICAgICAgZGlzYWJsZWQ9e2FkZFN0YXRlLnN0YXR1cyA9PT0gXCJhZGRpbmdcIn1cbiAgICAgICAgICBvbkNsaWNrPXthZGRUaGVtZX1cbiAgICAgICAgPlxuICAgICAgICAgIHthZGRTdGF0ZS5zdGF0dXMgPT09IFwiYWRkaW5nXCIgPyAoXG4gICAgICAgICAgICA8UmVmcmVzaEN3IHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJ0dF9fc3BpblwiIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxQbHVzIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPHNwYW4+QWRkIHRoZW1l4oCmPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAge2FkZFN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiICYmIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJ0dF9fbm90ZSB0dF9fbm90ZS0tZXJyXCI+e2FkZFN0YXRlLnJlYXNvbn08L3A+fVxuICAgICAgICB7YWRkU3RhdGUuc3RhdHVzID09PSBcImFkb3B0ZWRcIiAmJiAoXG4gICAgICAgICAgPHAgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cInR0X19ub3RlIHR0X19ub3RlLS1va1wiPkFkZGVkLiBQaWNrIGl0IGZyb20gdGhlIGxpc3QgYWJvdmUuPC9wPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSMy04MzQ6IG9uZSBzZW50ZW5jZSDigJQgdGhlIGZyYW1lIGlzIDMyMHB4IGFuZCB0aGUgb2xkIHR3by1zZW50ZW5jZVxuICAgICAgICAgIGZvb3RlciBwdXNoZWQgdGhlIGNvbnRlbnQgcGFzdCBpdC4gKi99XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0dF9fZm9vdFwiPlRoZW1lcyBhcmUgY2hlY2tlZCBmb3IgY29udHJhc3QgYmVmb3JlIHRoZXkgYXBwbHkuPC9wPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3dpdGNoZXI7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQWlCQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFRQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxRQUFBLEdBQUFKLE9BQUE7QUFBeUMsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQUEsSUFBQU0sRUFBQSxHQUFBQyxZQUFBLElBNUJ6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBY0E7QUFXQTtBQUNBO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcseUJBQXlCOztBQUVuRDtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxhQUFhLEdBQUc7RUFDcEJDLFFBQVEsRUFBRUYsaUJBQWlCO0VBQzNCRyxLQUFLLEVBQUUseUJBQXlCO0VBQ2hDQyxLQUFLLEVBQUU7QUFDVCxDQUFDO0FBRUQsU0FBU0MsUUFBUUEsQ0FBQSxFQUFHO0VBQUFQLEVBQUE7RUFDbEIsTUFBTTtJQUFFSSxRQUFRO0lBQUVJO0VBQU8sQ0FBQyxHQUFHLElBQUFDLDBCQUFxQixFQUFDLENBQUM7RUFDcEQsTUFBTUMsT0FBTyxHQUFHLElBQUFDLG9CQUFlLEVBQUMsQ0FBQztFQUNqQyxNQUFNLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFXO0lBQUVDLE1BQU0sRUFBRTtFQUFPLENBQUMsQ0FBQztFQUN0RTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDQyxXQUFXLEVBQUVDLGNBQWMsQ0FBQyxHQUFHLElBQUFILGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ25FLE1BQU0sQ0FBQ0ksVUFBVSxFQUFFQyxhQUFhLENBQUMsR0FBRyxJQUFBTCxlQUFRLEVBQWdCLElBQUksQ0FBQztFQUNqRTtFQUNBO0VBQ0E7RUFDQSxNQUFNTSxjQUFjLEdBQUcsSUFBQUMsYUFBTSxFQUFDLEtBQUssQ0FBQzs7RUFFcEM7RUFDQSxNQUFNQyxZQUFZLEdBQUdaLE9BQU8sQ0FBQ2EsTUFBTSxDQUFDQyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDckIsUUFBUSxLQUFLQSxRQUFRLENBQUMsSUFBSSxJQUFJOztFQUVoRjtFQUNBO0VBQ0EsTUFBTXNCLFlBQVksR0FBR0osWUFBWSxFQUFFaEIsS0FBSyxJQUFJLEVBQUU7RUFDOUM7RUFDQTtFQUNBO0VBQ0EsTUFBTXFCLFdBQVcsR0FDZm5CLE1BQU0sS0FBSyxRQUFRLElBQUlrQixZQUFZLENBQUNFLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBS3RCLE1BQU0sQ0FBQyxHQUFHQSxNQUFNLEdBQUcsUUFBUTs7RUFFdEY7QUFDRjtFQUNFLE1BQU11QixNQUFNLEdBQUcsSUFBQUMsa0JBQVcsRUFDeEIsT0FBT0MsS0FBYSxFQUFFQyxJQUFZLEtBQUs7SUFDckMsTUFBTUMsR0FBRyxHQUFHLEdBQUdGLEtBQUssSUFBSUMsSUFBSSxFQUFFO0lBQzlCLElBQUlkLGNBQWMsQ0FBQ2dCLE9BQU8sRUFBRTtJQUM1QmhCLGNBQWMsQ0FBQ2dCLE9BQU8sR0FBRyxJQUFJO0lBQzdCbkIsY0FBYyxDQUFDLElBQUksQ0FBQztJQUNwQkUsYUFBYSxDQUFDZ0IsR0FBRyxDQUFDO0lBQ2xCLE1BQU1FLENBQUMsR0FBRyxNQUFNLElBQUFDLG1CQUFXLEVBQUNMLEtBQUssRUFBRUMsSUFBSSxDQUFDO0lBQ3hDZCxjQUFjLENBQUNnQixPQUFPLEdBQUcsS0FBSztJQUM5QmpCLGFBQWEsQ0FBQyxJQUFJLENBQUM7SUFDbkIsSUFBSSxDQUFDa0IsQ0FBQyxDQUFDRSxFQUFFLEVBQUV0QixjQUFjLENBQUMseUNBQXlDb0IsQ0FBQyxDQUFDRyxNQUFNLEVBQUUsQ0FBQztFQUNoRixDQUFDLEVBQ0QsRUFDRixDQUFDOztFQUVEO0VBQ0EsTUFBTUMsUUFBUSxHQUFHLElBQUFULGtCQUFXLEVBQUMsWUFBWTtJQUN2Q25CLFdBQVcsQ0FBQztNQUFFRSxNQUFNLEVBQUU7SUFBUyxDQUFDLENBQUM7SUFDakMsSUFBSTtNQUNGLE1BQU0yQixNQUFNLEdBQUcsTUFBTSxJQUFBQyxlQUFVLEVBQW1CLGFBQWEsRUFBRTtRQUMvREMsS0FBSyxFQUFFLENBQUMsT0FBTztNQUNqQixDQUFDLENBQUM7TUFDRixJQUFJLENBQUNGLE1BQU0sRUFBRUcsUUFBUSxFQUFFO1FBQ3JCaEMsV0FBVyxDQUFDO1VBQUVFLE1BQU0sRUFBRSxPQUFPO1VBQUV5QixNQUFNLEVBQUU7UUFBbUMsQ0FBQyxDQUFDO1FBQzVFO01BQ0Y7TUFDQSxNQUFNLElBQUFNLG1CQUFjLEVBQUNKLE1BQU0sQ0FBQ0csUUFBUSxDQUFDO01BQ3JDO01BQ0E7TUFDQTtNQUNBaEMsV0FBVyxDQUFDO1FBQUVFLE1BQU0sRUFBRSxTQUFTO1FBQUVYLFFBQVEsRUFBRTtNQUFHLENBQUMsQ0FBQztJQUNsRCxDQUFDLENBQUMsT0FBTzJDLENBQUMsRUFBRTtNQUNWLE1BQU1DLEdBQUcsR0FBR0QsQ0FBd0M7TUFDcERsQyxXQUFXLENBQUM7UUFDVkUsTUFBTSxFQUFFLE9BQU87UUFDZnlCLE1BQU0sRUFBRVEsR0FBRyxFQUFFQyxPQUFPLEtBQUtELEdBQUcsRUFBRUUsSUFBSSxLQUFLLFdBQVcsR0FBRyxnQkFBZ0IsR0FBRywyQkFBMkI7TUFDckcsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxTQUFTO01BQ1I7TUFDQUMsTUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTXZDLFdBQVcsQ0FBRXdDLENBQUMsSUFBTUEsQ0FBQyxDQUFDdEMsTUFBTSxLQUFLLFNBQVMsSUFBSXNDLENBQUMsQ0FBQ3RDLE1BQU0sS0FBSyxPQUFPLEdBQUc7UUFBRUEsTUFBTSxFQUFFO01BQU8sQ0FBQyxHQUFHc0MsQ0FBRSxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBQzlIO0VBQ0YsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBLE1BQU1DLGFBQWEsR0FBRyxJQUFBdEIsa0JBQVcsRUFBRXVCLEtBQXNDLElBQWE7SUFDcEYsTUFBTUMsU0FBUyxHQUFHOUMsT0FBTyxDQUFDYSxNQUFNLENBQUNrQyxNQUFNLENBQUVoQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3BCLEtBQUssS0FBS2tELEtBQUssQ0FBQ2xELEtBQUssQ0FBQztJQUN2RSxJQUFJbUQsU0FBUyxDQUFDRSxNQUFNLElBQUksQ0FBQyxFQUFFLE9BQU9ILEtBQUssQ0FBQ2xELEtBQUs7SUFDN0M7SUFDQTtJQUNBO0lBQ0EsTUFBTXNELElBQUksR0FBR0osS0FBSyxDQUFDbkQsUUFBUSxDQUFDd0QsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUU7SUFDbEQsT0FBTyxHQUFHTixLQUFLLENBQUNsRCxLQUFLLEtBQUtzRCxJQUFJLEdBQUc7RUFDbkMsQ0FBQyxFQUFFLENBQUNqRCxPQUFPLENBQUMsQ0FBQztFQUViLG9CQUNFLElBQUFYLFdBQUEsQ0FBQStELElBQUE7SUFBU0MsU0FBUyxFQUFDLElBQUk7SUFBQyxjQUFXLFlBQVk7SUFBQUMsUUFBQSxnQkFDN0MsSUFBQWpFLFdBQUEsQ0FBQStELElBQUE7TUFBS0MsU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxnQkFDMUIsSUFBQWpFLFdBQUEsQ0FBQWtFLEdBQUE7UUFBTUYsU0FBUyxFQUFDLG1CQUFtQjtRQUFBQyxRQUFBLEVBQUM7TUFBYSxDQUFNLENBQUMsZUFDeEQsSUFBQWpFLFdBQUEsQ0FBQStELElBQUE7UUFBTUMsU0FBUyxFQUFDLG1CQUFtQjtRQUFBQyxRQUFBLEdBR2hDMUMsWUFBWSxHQUFHZ0MsYUFBYSxDQUFDaEMsWUFBWSxDQUFDLEdBQUcsbUJBQW1CLGVBQ2pFLElBQUF2QixXQUFBLENBQUFrRSxHQUFBO1VBQU1GLFNBQVMsRUFBQyxrQkFBa0I7VUFBQUMsUUFBQSxFQUMvQnhELE1BQU0sS0FBSyxRQUFRLEdBQUcsbUJBQW1CLEdBQUcsTUFBTUEsTUFBTTtRQUFFLENBQ3ZELENBQUM7TUFBQSxDQUNILENBQUM7SUFBQSxDQUNKLENBQUMsZUFPTixJQUFBVCxXQUFBLENBQUErRCxJQUFBO01BQ0VDLFNBQVMsRUFBQyxTQUFTO01BQ25CRyxJQUFJLEVBQUMsWUFBWTtNQUNqQixjQUFXLFlBQVk7TUFDdkJDLFNBQVMsRUFBR3BCLENBQUMsSUFBSztRQUNoQixJQUFJQSxDQUFDLENBQUNaLEdBQUcsS0FBSyxXQUFXLElBQUlZLENBQUMsQ0FBQ1osR0FBRyxLQUFLLFlBQVksSUFBSVksQ0FBQyxDQUFDWixHQUFHLEtBQUssU0FBUyxJQUFJWSxDQUFDLENBQUNaLEdBQUcsS0FBSyxXQUFXLEVBQUU7UUFDckdZLENBQUMsQ0FBQ3FCLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCLE1BQU1DLEtBQUssR0FBR3RCLENBQUMsQ0FBQ3VCLGFBQWE7UUFDN0IsTUFBTUMsSUFBSSxHQUFHLENBQUMsR0FBR0YsS0FBSyxDQUFDRyxnQkFBZ0IsQ0FBYyxzQ0FBc0MsQ0FBQyxDQUFDO1FBQzdGLElBQUlELElBQUksQ0FBQ2IsTUFBTSxHQUFHLENBQUMsRUFBRTtRQUNyQixNQUFNZSxFQUFFLEdBQUdGLElBQUksQ0FBQ0csT0FBTyxDQUFDQyxRQUFRLENBQUNDLGFBQTRCLENBQUM7UUFDOUQsTUFBTUMsR0FBRyxHQUFHOUIsQ0FBQyxDQUFDWixHQUFHLEtBQUssV0FBVyxJQUFJWSxDQUFDLENBQUNaLEdBQUcsS0FBSyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNqRSxNQUFNMkMsSUFBSSxHQUFHUCxJQUFJLENBQUMsQ0FBQ0UsRUFBRSxHQUFHSSxHQUFHLEdBQUdOLElBQUksQ0FBQ2IsTUFBTSxJQUFJYSxJQUFJLENBQUNiLE1BQU0sQ0FBQztRQUN6RG9CLElBQUksQ0FBQ0MsS0FBSyxDQUFDLENBQUM7UUFDWkQsSUFBSSxDQUFDRSxLQUFLLENBQUMsQ0FBQztNQUNkLENBQUU7TUFBQWhCLFFBQUEsZ0JBRUYsSUFBQWpFLFdBQUEsQ0FBQStELElBQUE7UUFDRW1CLElBQUksRUFBQyxRQUFRO1FBQ2JmLElBQUksRUFBQyxPQUFPO1FBQ1osZ0JBQWMxRCxNQUFNLEtBQUssUUFBUztRQUNsQyxhQUFXVSxVQUFVLEtBQUtkLFFBQVEsR0FBRyxTQUFVO1FBQy9DLGlCQUFlYyxVQUFVLEtBQUssSUFBSztRQUNuQ2dFLFFBQVEsRUFBRXZELFdBQVcsS0FBSyxRQUFRLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBRTtRQUM1Q29DLFNBQVMsRUFBRSxVQUFVdkQsTUFBTSxLQUFLLFFBQVEsR0FBRyxZQUFZLEdBQUcsRUFBRSxFQUFHO1FBQy9EMkUsT0FBTyxFQUFFQSxDQUFBLEtBQU0sS0FBS3BELE1BQU0sQ0FBQzNCLFFBQVEsRUFBRSxRQUFRLENBQUU7UUFBQTRELFFBQUEsZ0JBRS9DLElBQUFqRSxXQUFBLENBQUFrRSxHQUFBLEVBQUN0RSxZQUFBLENBQUF5RixPQUFPO1VBQUNDLElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUUsQ0FBQyxlQUN4QyxJQUFBdEYsV0FBQSxDQUFBa0UsR0FBQTtVQUFBRCxRQUFBLEVBQU07UUFBTSxDQUFNLENBQUM7TUFBQSxDQUNiLENBQUMsRUFDUnRDLFlBQVksQ0FBQzRELEdBQUcsQ0FBRXpELENBQUMsaUJBQ2xCLElBQUE5QixXQUFBLENBQUErRCxJQUFBO1FBRUVtQixJQUFJLEVBQUMsUUFBUTtRQUNiZixJQUFJLEVBQUMsT0FBTztRQUNaLGdCQUFjMUQsTUFBTSxLQUFLcUIsQ0FBQyxDQUFDQyxFQUFHO1FBQzlCLGFBQVdaLFVBQVUsS0FBS2QsUUFBUSxHQUFHLEdBQUcsR0FBR3lCLENBQUMsQ0FBQ0MsRUFBRztRQUNoRCxpQkFBZVosVUFBVSxLQUFLLElBQUs7UUFDbkNnRSxRQUFRLEVBQUV2RCxXQUFXLEtBQUtFLENBQUMsQ0FBQ0MsRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUU7UUFDeENpQyxTQUFTLEVBQUUsVUFBVXZELE1BQU0sS0FBS3FCLENBQUMsQ0FBQ0MsRUFBRSxHQUFHLFlBQVksR0FBRyxFQUFFLEVBQUc7UUFDM0RxRCxPQUFPLEVBQUVBLENBQUEsS0FBTSxLQUFLcEQsTUFBTSxDQUFDM0IsUUFBUSxFQUFFeUIsQ0FBQyxDQUFDQyxFQUFFLENBQUU7UUFBQWtDLFFBQUEsR0FFMUNuQyxDQUFDLENBQUMwRCxRQUFRLEtBQUssTUFBTSxnQkFDcEIsSUFBQXhGLFdBQUEsQ0FBQWtFLEdBQUEsRUFBQ3RFLFlBQUEsQ0FBQTZGLElBQUk7VUFBQ0gsSUFBSSxFQUFFLEVBQUc7VUFBQyxlQUFZO1FBQU0sQ0FBRSxDQUFDLGdCQUVyQyxJQUFBdEYsV0FBQSxDQUFBa0UsR0FBQSxFQUFDdEUsWUFBQSxDQUFBOEYsR0FBRztVQUFDSixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQ3BDLGVBQ0QsSUFBQXRGLFdBQUEsQ0FBQWtFLEdBQUE7VUFBQUQsUUFBQSxFQUFPbkMsQ0FBQyxDQUFDQztRQUFFLENBQU8sQ0FBQztNQUFBLEdBZmRELENBQUMsQ0FBQ0MsRUFnQkQsQ0FDVCxDQUFDO0lBQUEsQ0FDQyxDQUFDLGVBT04sSUFBQS9CLFdBQUEsQ0FBQStELElBQUE7TUFBS0MsU0FBUyxFQUFDLFVBQVU7TUFBQ0csSUFBSSxFQUFDLE1BQU07TUFBQyxjQUFXLFFBQVE7TUFBQUYsUUFBQSxHQUN0RCxDQUFDN0QsYUFBYSxFQUFFLEdBQUdPLE9BQU8sQ0FBQ2EsTUFBTSxDQUFDa0MsTUFBTSxDQUFFRixLQUFLLElBQUtBLEtBQUssQ0FBQ25ELFFBQVEsS0FBS0YsaUJBQWlCLENBQUMsQ0FBQyxDQUN4Rm9GLEdBQUcsQ0FBRS9CLEtBQUssSUFBSztRQUNoQixNQUFNbUMsTUFBTSxHQUFHbkMsS0FBSyxDQUFDbkQsUUFBUSxLQUFLQSxRQUFRO1FBQzFDLE1BQU11RixVQUFVLEdBQUcsSUFBQUMsZ0JBQU8sRUFBQ3BGLE1BQU0sRUFBRWtCLFlBQVksRUFBRTZCLEtBQUssQ0FBQ2pELEtBQUssQ0FBQztRQUM3RCxvQkFDRSxJQUFBUCxXQUFBLENBQUErRCxJQUFBO1VBQTBCQyxTQUFTLEVBQUUsWUFBWTJCLE1BQU0sR0FBRyxZQUFZLEdBQUcsRUFBRSxFQUFHO1VBQUN4QixJQUFJLEVBQUMsVUFBVTtVQUFBRixRQUFBLGdCQUM1RixJQUFBakUsV0FBQSxDQUFBK0QsSUFBQTtZQUNFbUIsSUFBSSxFQUFDLFFBQVE7WUFDYmxCLFNBQVMsRUFBQyxrQkFBa0I7WUFDNUIsYUFBVzdDLFVBQVUsS0FBS3FDLEtBQUssQ0FBQ25ELFFBQVEsR0FBRyxHQUFHLEdBQUd1RixVQUFXO1lBQzVELGlCQUFlekUsVUFBVSxLQUFLLElBQUs7WUFDbkNpRSxPQUFPLEVBQUVBLENBQUEsS0FDUCxLQUFLcEQsTUFBTSxDQUNUd0IsS0FBSyxDQUFDbkQsUUFBUTtZQUNkO1lBQ0E7WUFDQTtZQUNBO1lBQ0F1RixVQUNGLENBQ0Q7WUFBQTNCLFFBQUEsR0FFQTBCLE1BQU0sZ0JBQUcsSUFBQTNGLFdBQUEsQ0FBQWtFLEdBQUEsRUFBQ3RFLFlBQUEsQ0FBQWtHLEtBQUs7Y0FBQ1IsSUFBSSxFQUFFLEVBQUc7Y0FBQyxlQUFZO1lBQU0sQ0FBRSxDQUFDLGdCQUFHLElBQUF0RixXQUFBLENBQUFrRSxHQUFBO2NBQU1GLFNBQVMsRUFBQztZQUFlLENBQUUsQ0FBQyxlQUNyRixJQUFBaEUsV0FBQSxDQUFBa0UsR0FBQTtjQUFBRCxRQUFBLEVBQU9ULEtBQUssQ0FBQ25ELFFBQVEsS0FBS0YsaUJBQWlCLEdBQUcseUJBQXlCLEdBQUdvRCxhQUFhLENBQUNDLEtBQUs7WUFBQyxDQUFPLENBQUM7VUFBQSxDQUNoRyxDQUFDLEVBQ1JtQyxNQUFNLGlCQUFJLElBQUEzRixXQUFBLENBQUFrRSxHQUFBO1lBQU1GLFNBQVMsRUFBQyxrQkFBa0I7WUFBQUMsUUFBQSxFQUFDO1VBQU0sQ0FBTSxDQUFDLEVBQzFEVCxLQUFLLENBQUNuRCxRQUFRLEtBQUtGLGlCQUFpQixpQkFDbkMsSUFBQUgsV0FBQSxDQUFBa0UsR0FBQTtZQUNFZ0IsSUFBSSxFQUFDLFFBQVE7WUFDYmxCLFNBQVMsRUFBQyxZQUFZO1lBQ3RCK0IsS0FBSyxFQUFDLGNBQWM7WUFDcEIsY0FBWSxVQUFVdkMsS0FBSyxDQUFDbEQsS0FBSyxFQUFHO1lBQ3BDOEUsT0FBTyxFQUFFQSxDQUFBLEtBQU0sSUFBQVksc0JBQWlCLEVBQUN4QyxLQUFLLENBQUNuRCxRQUFRLENBQUU7WUFBQTRELFFBQUEsZUFFakQsSUFBQWpFLFdBQUEsQ0FBQWtFLEdBQUEsRUFBQ3RFLFlBQUEsQ0FBQXFHLE1BQU07Y0FBQ1gsSUFBSSxFQUFFLEVBQUc7Y0FBQyxlQUFZO1lBQU0sQ0FBRTtVQUFDLENBQ2pDLENBQ1Q7UUFBQSxHQS9CTzlCLEtBQUssQ0FBQ25ELFFBZ0NYLENBQUM7TUFFVixDQUFDLENBQUMsRUFDRE0sT0FBTyxDQUFDYSxNQUFNLENBQUNtQyxNQUFNLEtBQUssQ0FBQyxpQkFDMUIsSUFBQTNELFdBQUEsQ0FBQWtFLEdBQUE7UUFBR0YsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQXdELENBQUcsQ0FDcEY7SUFBQSxDQUNFLENBQUMsRUFJTGhELFdBQVcsaUJBQ1YsSUFBQWpCLFdBQUEsQ0FBQWtFLEdBQUE7TUFBR0MsSUFBSSxFQUFDLFFBQVE7TUFBQ0gsU0FBUyxFQUFDLHdCQUF3QjtNQUFBQyxRQUFBLEVBQ2hEaEQ7SUFBVyxDQUNYLENBQ0osZUFFRCxJQUFBakIsV0FBQSxDQUFBK0QsSUFBQTtNQUFLQyxTQUFTLEVBQUMsU0FBUztNQUFBQyxRQUFBLGdCQUN0QixJQUFBakUsV0FBQSxDQUFBK0QsSUFBQTtRQUNFbUIsSUFBSSxFQUFDLFFBQVE7UUFDYmxCLFNBQVMsRUFBQyxhQUFhO1FBQ3ZCa0MsUUFBUSxFQUFFckYsUUFBUSxDQUFDRyxNQUFNLEtBQUssUUFBUztRQUN2Q29FLE9BQU8sRUFBRTFDLFFBQVM7UUFBQXVCLFFBQUEsR0FFakJwRCxRQUFRLENBQUNHLE1BQU0sS0FBSyxRQUFRLGdCQUMzQixJQUFBaEIsV0FBQSxDQUFBa0UsR0FBQSxFQUFDdEUsWUFBQSxDQUFBdUcsU0FBUztVQUFDYixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVksTUFBTTtVQUFDdEIsU0FBUyxFQUFDO1FBQVUsQ0FBRSxDQUFDLGdCQUUvRCxJQUFBaEUsV0FBQSxDQUFBa0UsR0FBQSxFQUFDdEUsWUFBQSxDQUFBd0csSUFBSTtVQUFDZCxJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQ3JDLGVBQ0QsSUFBQXRGLFdBQUEsQ0FBQWtFLEdBQUE7VUFBQUQsUUFBQSxFQUFNO1FBQVUsQ0FBTSxDQUFDO01BQUEsQ0FDakIsQ0FBQyxFQUNScEQsUUFBUSxDQUFDRyxNQUFNLEtBQUssT0FBTyxpQkFBSSxJQUFBaEIsV0FBQSxDQUFBa0UsR0FBQTtRQUFHQyxJQUFJLEVBQUMsUUFBUTtRQUFDSCxTQUFTLEVBQUMsd0JBQXdCO1FBQUFDLFFBQUEsRUFBRXBELFFBQVEsQ0FBQzRCO01BQU0sQ0FBSSxDQUFDLEVBQ3hHNUIsUUFBUSxDQUFDRyxNQUFNLEtBQUssU0FBUyxpQkFDNUIsSUFBQWhCLFdBQUEsQ0FBQWtFLEdBQUE7UUFBR0MsSUFBSSxFQUFDLFFBQVE7UUFBQ0gsU0FBUyxFQUFDLHVCQUF1QjtRQUFBQyxRQUFBLEVBQUM7TUFBbUMsQ0FBRyxDQUMxRjtJQUFBLENBQ0UsQ0FBQyxlQUlOLElBQUFqRSxXQUFBLENBQUFrRSxHQUFBO01BQUdGLFNBQVMsRUFBQyxVQUFVO01BQUFDLFFBQUEsRUFBQztJQUFrRCxDQUFHLENBQUM7RUFBQSxDQUN2RSxDQUFDO0FBRWQ7QUFBQ2hFLEVBQUEsQ0EvT1FPLFFBQVE7RUFBQSxRQUNjRSwwQkFBcUIsRUFDbENFLG9CQUFlO0FBQUE7QUFBQXlGLEVBQUEsR0FGeEI3RixRQUFRO0FBQUEsSUFBQThGLFFBQUEsR0FBQUMsT0FBQSxDQUFBQyxPQUFBLEdBaVBGaEcsUUFBUTtBQUFBLElBQUE2RixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}