var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
require("./index.css");
require("./App.css");
var _Switcher = _interopRequireDefault(require("./components/Switcher"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file.
// The theme switcher (R3-501 · HOST_THEMING_SPEC §8.2): the `widget.theme` app
// upgraded in place from the two-state toggle.
//
// R3-834: the switcher's polarity FOLLOWS THE HOST. Apps receive only the
// host's polarity (§9.1), never its token values, so the app's own palette is
// neutral and `html[data-theme]` is set from `useHostTheme()` — never from
// `prefers-color-scheme`, which is the OS setting and not the host's.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  const theme = (0, _sdk.useHostTheme)();
  (0, _react.useEffect)(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Switcher.default, {});
}
_s(App, "s/fCWdnl0aS9PKe5owjfeMHSkpQ=", false, function () {
  return [_sdk.useHostTheme];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9Td2l0Y2hlciIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwidGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJ1c2VFZmZlY3QiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsImRhdGFzZXQiLCJqc3giLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUm9vdCBjb21wb25lbnQg4oCUIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIHRoZSBkZWZhdWx0IGV4cG9ydCBvZiBUSElTIGZpbGUuXG4vLyBUaGUgdGhlbWUgc3dpdGNoZXIgKFIzLTUwMSDCtyBIT1NUX1RIRU1JTkdfU1BFQyDCpzguMik6IHRoZSBgd2lkZ2V0LnRoZW1lYCBhcHBcbi8vIHVwZ3JhZGVkIGluIHBsYWNlIGZyb20gdGhlIHR3by1zdGF0ZSB0b2dnbGUuXG4vL1xuLy8gUjMtODM0OiB0aGUgc3dpdGNoZXIncyBwb2xhcml0eSBGT0xMT1dTIFRIRSBIT1NULiBBcHBzIHJlY2VpdmUgb25seSB0aGVcbi8vIGhvc3QncyBwb2xhcml0eSAowqc5LjEpLCBuZXZlciBpdHMgdG9rZW4gdmFsdWVzLCBzbyB0aGUgYXBwJ3Mgb3duIHBhbGV0dGUgaXNcbi8vIG5ldXRyYWwgYW5kIGBodG1sW2RhdGEtdGhlbWVdYCBpcyBzZXQgZnJvbSBgdXNlSG9zdFRoZW1lKClgIOKAlCBuZXZlciBmcm9tXG4vLyBgcHJlZmVycy1jb2xvci1zY2hlbWVgLCB3aGljaCBpcyB0aGUgT1Mgc2V0dGluZyBhbmQgbm90IHRoZSBob3N0J3MuXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUhvc3RUaGVtZSB9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xuaW1wb3J0IFN3aXRjaGVyIGZyb20gXCIuL2NvbXBvbmVudHMvU3dpdGNoZXJcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCB0aGVtZSA9IHVzZUhvc3RUaGVtZSgpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5kYXRhc2V0LnRoZW1lID0gdGhlbWU7XG4gIH0sIFt0aGVtZV0pO1xuICByZXR1cm4gPFN3aXRjaGVyIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVFBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBQSxPQUFBO0FBQ0FBLE9BQUE7QUFDQSxJQUFBRSxTQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFBNkMsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsSUFBQUssRUFBQSxHQUFBQyxZQUFBLElBWjdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQU9BLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2IsTUFBTU0sS0FBSyxHQUFHLElBQUFDLGlCQUFZLEVBQUMsQ0FBQztFQUM1QixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZEMsUUFBUSxDQUFDQyxlQUFlLENBQUNDLE9BQU8sQ0FBQ0wsS0FBSyxHQUFHQSxLQUFLO0VBQ2hELENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztFQUNYLG9CQUFPLElBQUFQLFdBQUEsQ0FBQWEsR0FBQSxFQUFDZixTQUFBLENBQUFPLE9BQVEsSUFBRSxDQUFDO0FBQ3JCO0FBQUNKLEVBQUEsQ0FOUUssR0FBRztFQUFBLFFBQ0lFLGlCQUFZO0FBQUE7QUFBQU0sRUFBQSxHQURuQlIsR0FBRztBQUFBLElBQUFTLFFBQUEsR0FBQUMsT0FBQSxDQUFBWCxPQUFBLEdBUUdDLEdBQUc7QUFBQSxJQUFBUSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}