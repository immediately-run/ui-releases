var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
var _nodeFs = require("node:fs");
var _react = require("@testing-library/react");
var _vitest = require("vitest");
var _App = _interopRequireDefault(require("./App"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// R3-834 — the switcher's polarity follows the host (HOST_THEMING_SPEC §9.1):
// `useHostTheme()` → `html[data-theme]`, never `prefers-color-scheme` (the OS
// setting, not the host's), and the mode control is one line, always.

// The SDK boundary: `useHostTheme`, the catalog and the selection setter are
// controllable per-case; everything else the Switcher imports resolves to
// inert no-ops.
const held = {
  theme: 'light',
  modeId: 'system',
  catalog: {
    themes: []
  }
};
const setSelection = _vitest.vi.fn();
_vitest.vi.mock('@immediately-run/sdk', () => ({
  useHostTheme: () => held.theme,
  useHostThemeSelection: () => ({
    themeKey: 'immediately-run-default',
    modeId: held.modeId
  }),
  useThemeCatalog: () => held.catalog,
  setHostThemeSelection: (...args) => setSelection(...args),
  addThemeSource: async () => {
    throw new Error('no host transport');
  },
  removeThemeSource: () => {},
  invokeTask: async () => {
    throw new Error('no host transport');
  }
}));
(0, _vitest.afterEach)(() => {
  (0, _react.cleanup)();
  setSelection.mockClear();
  held.modeId = 'system';
  held.catalog = {
    themes: []
  };
});
(0, _vitest.describe)('R3-834 — polarity from useHostTheme, set on <html>', () => {
  (0, _vitest.it)('a light host sets html[data-theme="light"]', () => {
    held.theme = 'light';
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(document.documentElement.dataset.theme).toBe('light');
  });
  (0, _vitest.it)('flipping the host to dark — and back — updates the attribute', () => {
    held.theme = 'dark';
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(document.documentElement.dataset.theme).toBe('dark');
    held.theme = 'light';
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    (0, _vitest.expect)(document.documentElement.dataset.theme).toBe('light');
  });
});

// The App.css guard (R3-834): the mode control can never wrap — a grid with
// minmax(0, 1fr) tracks, not a wrapping flex row (the old shape dropped
// "dark" onto a second line in the ~250px settings card).
(0, _vitest.describe)('R3-834 — the mode control is one line', () => {
  // process.cwd() is the repo root under vitest; the tests' tsconfig carries
  // the node types (tsconfig.vitest.json), so the app's stays ["vite/client"].
  const css = (0, _nodeFs.readFileSync)('src/App.css', 'utf8');
  const rule = selector => {
    const at = css.indexOf(selector);
    (0, _vitest.expect)(at).toBeGreaterThanOrEqual(0);
    return css.slice(at, css.indexOf('}', at));
  };
  (0, _vitest.it)('the wrap directive is gone from the segment control, which is a grid', () => {
    const seg = rule('.tt__seg');
    (0, _vitest.expect)(seg).not.toMatch(/flex-\s*wrap\s*:\s*wrap/i);
    (0, _vitest.expect)(seg).toMatch(/display\s*:\s*grid/i);
    (0, _vitest.expect)(seg).toMatch(/grid-template-columns\s*:\s*repeat\(auto-fit,\s*minmax\(0,\s*1fr\)\)/i);
  });
  (0, _vitest.it)('no rule anywhere reintroduces the wrap directive', () => {
    (0, _vitest.expect)(css).not.toMatch(/flex-\s*wrap\s*:\s*wrap/i);
  });
});

// ── R3-834 review round 1 — the APG radiogroup, driven ───────────────────────
// role="radiogroup" announces arrow-key movement; the round-1 reviewers found
// none existed (the item's "keeps" premise was false). Implemented for real:
// a roving tabindex (the checked option is the tab stop) and arrows move
// focus AND select — pinned here.
(0, _vitest.describe)('R3-834 — the mode control is a real radiogroup', () => {
  (0, _vitest.it)('a modeId matching no option still leaves the group tabbable (the APG fallback: the first radio)', () => {
    held.catalog = {
      themes: [{
        themeKey: 'immediately-run-default',
        label: 'immediately.run default',
        modes: [{
          id: 'light',
          polarity: 'light'
        }, {
          id: 'dark',
          polarity: 'dark'
        }]
      }]
    };
    // A stale mode id (the round-2 finding: the old theme's id sent to a new
    // theme) must not drop the whole group out of the tab order.
    held.modeId = 'a-stale-mode-from-another-theme';
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const opts = [...container.querySelectorAll('.tt__opt')];
    (0, _vitest.expect)(opts[0].tabIndex).toBe(0); // the first option is the tab stop
    (0, _vitest.expect)(opts.slice(1).every(o => o.tabIndex === -1)).toBe(true);
  });
  (0, _vitest.it)('arrow keys move focus and select the next option (roving tabindex)', async () => {
    held.catalog = {
      themes: [{
        themeKey: 'immediately-run-default',
        label: 'immediately.run default',
        modes: [{
          id: 'light',
          polarity: 'light'
        }, {
          id: 'dark',
          polarity: 'dark'
        }]
      }]
    };
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const seg = container.querySelector('.tt__seg');
    const opts = [...seg.querySelectorAll('.tt__opt')];
    (0, _vitest.expect)(opts.length).toBe(3); // System + light + dark
    // The checked option is the tab stop; the others are out of the tab order.
    (0, _vitest.expect)(opts[0].tabIndex).toBe(0);
    (0, _vitest.expect)(opts[1].tabIndex).toBe(-1);
    opts[0].focus();
    opts[0].dispatchEvent(new KeyboardEvent('keydown', {
      key: 'ArrowRight',
      bubbles: true
    }));
    (0, _vitest.expect)(document.activeElement).toBe(opts[1]);
    (0, _vitest.expect)(setSelection).toHaveBeenCalledWith({
      theme: 'immediately-run-default',
      mode: 'light'
    });
    // The selection follows: the newly selected option becomes the tab stop.
    held.modeId = 'light';
    // (The roving tabindex is derived from the selection, so a re-render moves
    // the stop; the arrows move within whatever the current stop is. One
    // selection is in flight at a time (R3-847's latch), so let it settle —
    // the options are aria-disabled while it runs — before the next arrow
    // drives another select.)
    await (0, _react.waitFor)(() => (0, _vitest.expect)(opts[1].getAttribute('aria-busy')).toBe('false'));
    opts[1].dispatchEvent(new KeyboardEvent('keydown', {
      key: 'ArrowLeft',
      bubbles: true
    }));
    (0, _vitest.expect)(document.activeElement).toBe(opts[0]);
    (0, _vitest.expect)(setSelection).toHaveBeenLastCalledWith({
      theme: 'immediately-run-default',
      mode: 'system'
    });
  });
});

// ── R3-834 review round 3 — the theme-row selection payload, driven ──────────
// The round-2 fix changed the payload (the NEW theme's first mode, never the
// old theme's id) with no test; this PR's own history had already proved that
// exact expression buggy. Pinned here, all three arms.
(0, _vitest.describe)('R3-834 — the theme-row selection payload', () => {
  const TWO_THEMES = {
    themes: [{
      themeKey: 'immediately-run-default',
      label: 'immediately.run default',
      modes: [{
        id: 'light',
        polarity: 'light'
      }, {
        id: 'dark',
        polarity: 'dark'
      }]
    }, {
      themeKey: 'danube-dusk',
      label: 'Danube Dusk',
      modes: [{
        id: 'light',
        polarity: 'light'
      }, {
        id: 'dark',
        polarity: 'dark'
      }]
    }]
  };
  (0, _vitest.it)('clicking a theme row maps the current polarity onto the target — never the old theme\'s id', async () => {
    held.catalog = TWO_THEMES;
    held.modeId = 'dark';
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const row = [...container.querySelectorAll('.tt__theme-select')].find(b => (b.textContent || '').includes('Danube'));
    (0, _vitest.expect)(row).toBeTruthy();
    row.click();
    // R3-847: the intent (a dark mode) maps to danube-dusk's dark-polarity
    // mode. The committed theme.json (site-main's fixture) gives Danube Dusk
    // the mode ids light/dark with Dawn/Dusk as LABELS — the catalogue
    // projects the ids.
    (0, _vitest.expect)(setSelection).toHaveBeenCalledWith({
      theme: 'danube-dusk',
      mode: 'dark'
    });
  });
  (0, _vitest.it)('the system arm: a system modeId crossing to a theme stays system', async () => {
    held.catalog = TWO_THEMES;
    held.modeId = 'system';
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const row = [...container.querySelectorAll('.tt__theme-select')].find(b => (b.textContent || '').includes('Danube'));
    row.click();
    (0, _vitest.expect)(setSelection).toHaveBeenCalledWith({
      theme: 'danube-dusk',
      mode: 'system'
    });
  });
  (0, _vitest.it)('the empty-modes arm: a theme with no modes falls back to system', async () => {
    held.catalog = {
      themes: [...TWO_THEMES.themes, {
        themeKey: 'empty-theme',
        label: 'Empty',
        modes: []
      }]
    };
    held.modeId = 'dark';
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {}));
    const row = [...container.querySelectorAll('.tt__theme-select')].find(b => (b.textContent || '').includes('Empty'));
    row.click();
    (0, _vitest.expect)(setSelection).toHaveBeenCalledWith({
      theme: 'empty-theme',
      mode: 'system'
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUZzIiwicmVxdWlyZSIsIl9yZWFjdCIsIl92aXRlc3QiLCJfQXBwIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGVsZCIsInRoZW1lIiwibW9kZUlkIiwiY2F0YWxvZyIsInRoZW1lcyIsInNldFNlbGVjdGlvbiIsInZpIiwiZm4iLCJtb2NrIiwidXNlSG9zdFRoZW1lIiwidXNlSG9zdFRoZW1lU2VsZWN0aW9uIiwidGhlbWVLZXkiLCJ1c2VUaGVtZUNhdGFsb2ciLCJzZXRIb3N0VGhlbWVTZWxlY3Rpb24iLCJhcmdzIiwiYWRkVGhlbWVTb3VyY2UiLCJFcnJvciIsInJlbW92ZVRoZW1lU291cmNlIiwiaW52b2tlVGFzayIsImFmdGVyRWFjaCIsImNsZWFudXAiLCJtb2NrQ2xlYXIiLCJkZXNjcmliZSIsIml0IiwicmVuZGVyIiwianN4IiwiZXhwZWN0IiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJkYXRhc2V0IiwidG9CZSIsInJlcmVuZGVyIiwiY3NzIiwicmVhZEZpbGVTeW5jIiwicnVsZSIsInNlbGVjdG9yIiwiYXQiLCJpbmRleE9mIiwidG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCIsInNsaWNlIiwic2VnIiwibm90IiwidG9NYXRjaCIsImxhYmVsIiwibW9kZXMiLCJpZCIsInBvbGFyaXR5IiwiY29udGFpbmVyIiwib3B0cyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJ0YWJJbmRleCIsImV2ZXJ5IiwibyIsInF1ZXJ5U2VsZWN0b3IiLCJsZW5ndGgiLCJmb2N1cyIsImRpc3BhdGNoRXZlbnQiLCJLZXlib2FyZEV2ZW50Iiwia2V5IiwiYnViYmxlcyIsImFjdGl2ZUVsZW1lbnQiLCJ0b0hhdmVCZWVuQ2FsbGVkV2l0aCIsIm1vZGUiLCJ3YWl0Rm9yIiwiZ2V0QXR0cmlidXRlIiwidG9IYXZlQmVlbkxhc3RDYWxsZWRXaXRoIiwiVFdPX1RIRU1FUyIsInJvdyIsImZpbmQiLCJiIiwidGV4dENvbnRlbnQiLCJpbmNsdWRlcyIsInRvQmVUcnV0aHkiLCJjbGljayJdLCJzb3VyY2VzIjpbIkFwcC50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy04MzQg4oCUIHRoZSBzd2l0Y2hlcidzIHBvbGFyaXR5IGZvbGxvd3MgdGhlIGhvc3QgKEhPU1RfVEhFTUlOR19TUEVDIMKnOS4xKTpcbi8vIGB1c2VIb3N0VGhlbWUoKWAg4oaSIGBodG1sW2RhdGEtdGhlbWVdYCwgbmV2ZXIgYHByZWZlcnMtY29sb3Itc2NoZW1lYCAodGhlIE9TXG4vLyBzZXR0aW5nLCBub3QgdGhlIGhvc3QncyksIGFuZCB0aGUgbW9kZSBjb250cm9sIGlzIG9uZSBsaW5lLCBhbHdheXMuXG5pbXBvcnQgeyByZWFkRmlsZVN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGNsZWFudXAsIHJlbmRlciwgd2FpdEZvciB9IGZyb20gJ0B0ZXN0aW5nLWxpYnJhcnkvcmVhY3QnO1xuaW1wb3J0IHsgYWZ0ZXJFYWNoLCBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuXG4vLyBUaGUgU0RLIGJvdW5kYXJ5OiBgdXNlSG9zdFRoZW1lYCwgdGhlIGNhdGFsb2cgYW5kIHRoZSBzZWxlY3Rpb24gc2V0dGVyIGFyZVxuLy8gY29udHJvbGxhYmxlIHBlci1jYXNlOyBldmVyeXRoaW5nIGVsc2UgdGhlIFN3aXRjaGVyIGltcG9ydHMgcmVzb2x2ZXMgdG9cbi8vIGluZXJ0IG5vLW9wcy5cbmNvbnN0IGhlbGQgPSB7XG4gIHRoZW1lOiAnbGlnaHQnIGFzICdsaWdodCcgfCAnZGFyaycsXG4gIG1vZGVJZDogJ3N5c3RlbScsXG4gIGNhdGFsb2c6IHsgdGhlbWVzOiBbXSBhcyB7IHRoZW1lS2V5OiBzdHJpbmc7IGxhYmVsOiBzdHJpbmc7IG1vZGVzOiB7IGlkOiBzdHJpbmc7IHBvbGFyaXR5OiAnbGlnaHQnIHwgJ2RhcmsnIH1bXSB9W10gfSxcbn07XG5jb25zdCBzZXRTZWxlY3Rpb24gPSB2aS5mbigpO1xudmkubW9jaygnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnLCAoKSA9PiAoe1xuICB1c2VIb3N0VGhlbWU6ICgpID0+IGhlbGQudGhlbWUsXG4gIHVzZUhvc3RUaGVtZVNlbGVjdGlvbjogKCkgPT4gKHsgdGhlbWVLZXk6ICdpbW1lZGlhdGVseS1ydW4tZGVmYXVsdCcsIG1vZGVJZDogaGVsZC5tb2RlSWQgfSksXG4gIHVzZVRoZW1lQ2F0YWxvZzogKCkgPT4gaGVsZC5jYXRhbG9nLFxuICBzZXRIb3N0VGhlbWVTZWxlY3Rpb246ICguLi5hcmdzOiB1bmtub3duW10pID0+IHNldFNlbGVjdGlvbiguLi4oYXJncyBhcyBbXSkpLFxuICBhZGRUaGVtZVNvdXJjZTogYXN5bmMgKCkgPT4ge1xuICAgIHRocm93IG5ldyBFcnJvcignbm8gaG9zdCB0cmFuc3BvcnQnKTtcbiAgfSxcbiAgcmVtb3ZlVGhlbWVTb3VyY2U6ICgpID0+IHt9LFxuICBpbnZva2VUYXNrOiBhc3luYyAoKSA9PiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdubyBob3N0IHRyYW5zcG9ydCcpO1xuICB9LFxufSkpO1xuXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwJztcblxuYWZ0ZXJFYWNoKCgpID0+IHtcbiAgY2xlYW51cCgpO1xuICBzZXRTZWxlY3Rpb24ubW9ja0NsZWFyKCk7XG4gIGhlbGQubW9kZUlkID0gJ3N5c3RlbSc7XG4gIGhlbGQuY2F0YWxvZyA9IHsgdGhlbWVzOiBbXSB9O1xufSk7XG5cbmRlc2NyaWJlKCdSMy04MzQg4oCUIHBvbGFyaXR5IGZyb20gdXNlSG9zdFRoZW1lLCBzZXQgb24gPGh0bWw+JywgKCkgPT4ge1xuICBpdCgnYSBsaWdodCBob3N0IHNldHMgaHRtbFtkYXRhLXRoZW1lPVwibGlnaHRcIl0nLCAoKSA9PiB7XG4gICAgaGVsZC50aGVtZSA9ICdsaWdodCc7XG4gICAgcmVuZGVyKDxBcHAgLz4pO1xuICAgIGV4cGVjdChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGF0YXNldC50aGVtZSkudG9CZSgnbGlnaHQnKTtcbiAgfSk7XG5cbiAgaXQoJ2ZsaXBwaW5nIHRoZSBob3N0IHRvIGRhcmsg4oCUIGFuZCBiYWNrIOKAlCB1cGRhdGVzIHRoZSBhdHRyaWJ1dGUnLCAoKSA9PiB7XG4gICAgaGVsZC50aGVtZSA9ICdkYXJrJztcbiAgICBjb25zdCB7IHJlcmVuZGVyIH0gPSByZW5kZXIoPEFwcCAvPik7XG4gICAgZXhwZWN0KGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5kYXRhc2V0LnRoZW1lKS50b0JlKCdkYXJrJyk7XG4gICAgaGVsZC50aGVtZSA9ICdsaWdodCc7XG4gICAgcmVyZW5kZXIoPEFwcCAvPik7XG4gICAgZXhwZWN0KGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5kYXRhc2V0LnRoZW1lKS50b0JlKCdsaWdodCcpO1xuICB9KTtcbn0pO1xuXG4vLyBUaGUgQXBwLmNzcyBndWFyZCAoUjMtODM0KTogdGhlIG1vZGUgY29udHJvbCBjYW4gbmV2ZXIgd3JhcCDigJQgYSBncmlkIHdpdGhcbi8vIG1pbm1heCgwLCAxZnIpIHRyYWNrcywgbm90IGEgd3JhcHBpbmcgZmxleCByb3cgKHRoZSBvbGQgc2hhcGUgZHJvcHBlZFxuLy8gXCJkYXJrXCIgb250byBhIHNlY29uZCBsaW5lIGluIHRoZSB+MjUwcHggc2V0dGluZ3MgY2FyZCkuXG5kZXNjcmliZSgnUjMtODM0IOKAlCB0aGUgbW9kZSBjb250cm9sIGlzIG9uZSBsaW5lJywgKCkgPT4ge1xuICAvLyBwcm9jZXNzLmN3ZCgpIGlzIHRoZSByZXBvIHJvb3QgdW5kZXIgdml0ZXN0OyB0aGUgdGVzdHMnIHRzY29uZmlnIGNhcnJpZXNcbiAgLy8gdGhlIG5vZGUgdHlwZXMgKHRzY29uZmlnLnZpdGVzdC5qc29uKSwgc28gdGhlIGFwcCdzIHN0YXlzIFtcInZpdGUvY2xpZW50XCJdLlxuICBjb25zdCBjc3MgPSByZWFkRmlsZVN5bmMoJ3NyYy9BcHAuY3NzJywgJ3V0ZjgnKTtcbiAgY29uc3QgcnVsZSA9IChzZWxlY3Rvcjogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICBjb25zdCBhdCA9IGNzcy5pbmRleE9mKHNlbGVjdG9yKTtcbiAgICBleHBlY3QoYXQpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoMCk7XG4gICAgcmV0dXJuIGNzcy5zbGljZShhdCwgY3NzLmluZGV4T2YoJ30nLCBhdCkpO1xuICB9O1xuXG4gIGl0KCd0aGUgd3JhcCBkaXJlY3RpdmUgaXMgZ29uZSBmcm9tIHRoZSBzZWdtZW50IGNvbnRyb2wsIHdoaWNoIGlzIGEgZ3JpZCcsICgpID0+IHtcbiAgICBjb25zdCBzZWcgPSBydWxlKCcudHRfX3NlZycpO1xuICAgIGV4cGVjdChzZWcpLm5vdC50b01hdGNoKC9mbGV4LVxccyp3cmFwXFxzKjpcXHMqd3JhcC9pKTtcbiAgICBleHBlY3Qoc2VnKS50b01hdGNoKC9kaXNwbGF5XFxzKjpcXHMqZ3JpZC9pKTtcbiAgICBleHBlY3Qoc2VnKS50b01hdGNoKC9ncmlkLXRlbXBsYXRlLWNvbHVtbnNcXHMqOlxccypyZXBlYXRcXChhdXRvLWZpdCxcXHMqbWlubWF4XFwoMCxcXHMqMWZyXFwpXFwpL2kpO1xuICB9KTtcblxuICBpdCgnbm8gcnVsZSBhbnl3aGVyZSByZWludHJvZHVjZXMgdGhlIHdyYXAgZGlyZWN0aXZlJywgKCkgPT4ge1xuICAgIGV4cGVjdChjc3MpLm5vdC50b01hdGNoKC9mbGV4LVxccyp3cmFwXFxzKjpcXHMqd3JhcC9pKTtcbiAgfSk7XG59KTtcblxuLy8g4pSA4pSAIFIzLTgzNCByZXZpZXcgcm91bmQgMSDigJQgdGhlIEFQRyByYWRpb2dyb3VwLCBkcml2ZW4g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyByb2xlPVwicmFkaW9ncm91cFwiIGFubm91bmNlcyBhcnJvdy1rZXkgbW92ZW1lbnQ7IHRoZSByb3VuZC0xIHJldmlld2VycyBmb3VuZFxuLy8gbm9uZSBleGlzdGVkICh0aGUgaXRlbSdzIFwia2VlcHNcIiBwcmVtaXNlIHdhcyBmYWxzZSkuIEltcGxlbWVudGVkIGZvciByZWFsOlxuLy8gYSByb3ZpbmcgdGFiaW5kZXggKHRoZSBjaGVja2VkIG9wdGlvbiBpcyB0aGUgdGFiIHN0b3ApIGFuZCBhcnJvd3MgbW92ZVxuLy8gZm9jdXMgQU5EIHNlbGVjdCDigJQgcGlubmVkIGhlcmUuXG5kZXNjcmliZSgnUjMtODM0IOKAlCB0aGUgbW9kZSBjb250cm9sIGlzIGEgcmVhbCByYWRpb2dyb3VwJywgKCkgPT4ge1xuICBpdCgnYSBtb2RlSWQgbWF0Y2hpbmcgbm8gb3B0aW9uIHN0aWxsIGxlYXZlcyB0aGUgZ3JvdXAgdGFiYmFibGUgKHRoZSBBUEcgZmFsbGJhY2s6IHRoZSBmaXJzdCByYWRpbyknLCAoKSA9PiB7XG4gICAgaGVsZC5jYXRhbG9nID0ge1xuICAgICAgdGhlbWVzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0aGVtZUtleTogJ2ltbWVkaWF0ZWx5LXJ1bi1kZWZhdWx0JyxcbiAgICAgICAgICBsYWJlbDogJ2ltbWVkaWF0ZWx5LnJ1biBkZWZhdWx0JyxcbiAgICAgICAgICBtb2RlczogW1xuICAgICAgICAgICAgeyBpZDogJ2xpZ2h0JywgcG9sYXJpdHk6ICdsaWdodCcgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdkYXJrJywgcG9sYXJpdHk6ICdkYXJrJyB9LFxuICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH07XG4gICAgLy8gQSBzdGFsZSBtb2RlIGlkICh0aGUgcm91bmQtMiBmaW5kaW5nOiB0aGUgb2xkIHRoZW1lJ3MgaWQgc2VudCB0byBhIG5ld1xuICAgIC8vIHRoZW1lKSBtdXN0IG5vdCBkcm9wIHRoZSB3aG9sZSBncm91cCBvdXQgb2YgdGhlIHRhYiBvcmRlci5cbiAgICBoZWxkLm1vZGVJZCA9ICdhLXN0YWxlLW1vZGUtZnJvbS1hbm90aGVyLXRoZW1lJztcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKDxBcHAgLz4pO1xuICAgIGNvbnN0IG9wdHMgPSBbLi4uY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KCcudHRfX29wdCcpXTtcbiAgICBleHBlY3Qob3B0c1swXS50YWJJbmRleCkudG9CZSgwKTsgLy8gdGhlIGZpcnN0IG9wdGlvbiBpcyB0aGUgdGFiIHN0b3BcbiAgICBleHBlY3Qob3B0cy5zbGljZSgxKS5ldmVyeSgobykgPT4gby50YWJJbmRleCA9PT0gLTEpKS50b0JlKHRydWUpO1xuICB9KTtcblxuICBpdCgnYXJyb3cga2V5cyBtb3ZlIGZvY3VzIGFuZCBzZWxlY3QgdGhlIG5leHQgb3B0aW9uIChyb3ZpbmcgdGFiaW5kZXgpJywgYXN5bmMgKCkgPT4ge1xuICAgIGhlbGQuY2F0YWxvZyA9IHtcbiAgICAgIHRoZW1lczogW1xuICAgICAgICB7XG4gICAgICAgICAgdGhlbWVLZXk6ICdpbW1lZGlhdGVseS1ydW4tZGVmYXVsdCcsXG4gICAgICAgICAgbGFiZWw6ICdpbW1lZGlhdGVseS5ydW4gZGVmYXVsdCcsXG4gICAgICAgICAgbW9kZXM6IFtcbiAgICAgICAgICAgIHsgaWQ6ICdsaWdodCcsIHBvbGFyaXR5OiAnbGlnaHQnIH0sXG4gICAgICAgICAgICB7IGlkOiAnZGFyaycsIHBvbGFyaXR5OiAnZGFyaycgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9O1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSByZW5kZXIoPEFwcCAvPik7XG4gICAgY29uc3Qgc2VnID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy50dF9fc2VnJykgYXMgSFRNTEVsZW1lbnQ7XG4gICAgY29uc3Qgb3B0cyA9IFsuLi5zZWcucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oJy50dF9fb3B0JyldO1xuICAgIGV4cGVjdChvcHRzLmxlbmd0aCkudG9CZSgzKTsgLy8gU3lzdGVtICsgbGlnaHQgKyBkYXJrXG4gICAgLy8gVGhlIGNoZWNrZWQgb3B0aW9uIGlzIHRoZSB0YWIgc3RvcDsgdGhlIG90aGVycyBhcmUgb3V0IG9mIHRoZSB0YWIgb3JkZXIuXG4gICAgZXhwZWN0KG9wdHNbMF0udGFiSW5kZXgpLnRvQmUoMCk7XG4gICAgZXhwZWN0KG9wdHNbMV0udGFiSW5kZXgpLnRvQmUoLTEpO1xuICAgIG9wdHNbMF0uZm9jdXMoKTtcbiAgICBvcHRzWzBdLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCB7IGtleTogJ0Fycm93UmlnaHQnLCBidWJibGVzOiB0cnVlIH0pKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShvcHRzWzFdKTtcbiAgICBleHBlY3Qoc2V0U2VsZWN0aW9uKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh7IHRoZW1lOiAnaW1tZWRpYXRlbHktcnVuLWRlZmF1bHQnLCBtb2RlOiAnbGlnaHQnIH0pO1xuICAgIC8vIFRoZSBzZWxlY3Rpb24gZm9sbG93czogdGhlIG5ld2x5IHNlbGVjdGVkIG9wdGlvbiBiZWNvbWVzIHRoZSB0YWIgc3RvcC5cbiAgICBoZWxkLm1vZGVJZCA9ICdsaWdodCc7XG4gICAgLy8gKFRoZSByb3ZpbmcgdGFiaW5kZXggaXMgZGVyaXZlZCBmcm9tIHRoZSBzZWxlY3Rpb24sIHNvIGEgcmUtcmVuZGVyIG1vdmVzXG4gICAgLy8gdGhlIHN0b3A7IHRoZSBhcnJvd3MgbW92ZSB3aXRoaW4gd2hhdGV2ZXIgdGhlIGN1cnJlbnQgc3RvcCBpcy4gT25lXG4gICAgLy8gc2VsZWN0aW9uIGlzIGluIGZsaWdodCBhdCBhIHRpbWUgKFIzLTg0NydzIGxhdGNoKSwgc28gbGV0IGl0IHNldHRsZSDigJRcbiAgICAvLyB0aGUgb3B0aW9ucyBhcmUgYXJpYS1kaXNhYmxlZCB3aGlsZSBpdCBydW5zIOKAlCBiZWZvcmUgdGhlIG5leHQgYXJyb3dcbiAgICAvLyBkcml2ZXMgYW5vdGhlciBzZWxlY3QuKVxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KG9wdHNbMV0uZ2V0QXR0cmlidXRlKCdhcmlhLWJ1c3knKSkudG9CZSgnZmFsc2UnKSk7XG4gICAgb3B0c1sxXS5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgeyBrZXk6ICdBcnJvd0xlZnQnLCBidWJibGVzOiB0cnVlIH0pKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShvcHRzWzBdKTtcbiAgICBleHBlY3Qoc2V0U2VsZWN0aW9uKS50b0hhdmVCZWVuTGFzdENhbGxlZFdpdGgoeyB0aGVtZTogJ2ltbWVkaWF0ZWx5LXJ1bi1kZWZhdWx0JywgbW9kZTogJ3N5c3RlbScgfSk7XG4gIH0pO1xufSk7XG5cbi8vIOKUgOKUgCBSMy04MzQgcmV2aWV3IHJvdW5kIDMg4oCUIHRoZSB0aGVtZS1yb3cgc2VsZWN0aW9uIHBheWxvYWQsIGRyaXZlbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIFRoZSByb3VuZC0yIGZpeCBjaGFuZ2VkIHRoZSBwYXlsb2FkICh0aGUgTkVXIHRoZW1lJ3MgZmlyc3QgbW9kZSwgbmV2ZXIgdGhlXG4vLyBvbGQgdGhlbWUncyBpZCkgd2l0aCBubyB0ZXN0OyB0aGlzIFBSJ3Mgb3duIGhpc3RvcnkgaGFkIGFscmVhZHkgcHJvdmVkIHRoYXRcbi8vIGV4YWN0IGV4cHJlc3Npb24gYnVnZ3kuIFBpbm5lZCBoZXJlLCBhbGwgdGhyZWUgYXJtcy5cbmRlc2NyaWJlKCdSMy04MzQg4oCUIHRoZSB0aGVtZS1yb3cgc2VsZWN0aW9uIHBheWxvYWQnLCAoKSA9PiB7XG4gIHR5cGUgTW9kZSA9IHsgaWQ6IHN0cmluZzsgcG9sYXJpdHk6ICdsaWdodCcgfCAnZGFyaycgfTtcbiAgdHlwZSBFbnRyeSA9IHsgdGhlbWVLZXk6IHN0cmluZzsgbGFiZWw6IHN0cmluZzsgbW9kZXM6IE1vZGVbXSB9O1xuICBjb25zdCBUV09fVEhFTUVTOiB7IHRoZW1lczogRW50cnlbXSB9ID0ge1xuICAgIHRoZW1lczogW1xuICAgICAge1xuICAgICAgICB0aGVtZUtleTogJ2ltbWVkaWF0ZWx5LXJ1bi1kZWZhdWx0JyxcbiAgICAgICAgbGFiZWw6ICdpbW1lZGlhdGVseS5ydW4gZGVmYXVsdCcsXG4gICAgICAgIG1vZGVzOiBbXG4gICAgICAgICAgeyBpZDogJ2xpZ2h0JywgcG9sYXJpdHk6ICdsaWdodCcgfSxcbiAgICAgICAgICB7IGlkOiAnZGFyaycsIHBvbGFyaXR5OiAnZGFyaycgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRoZW1lS2V5OiAnZGFudWJlLWR1c2snLFxuICAgICAgICBsYWJlbDogJ0RhbnViZSBEdXNrJyxcbiAgICAgICAgbW9kZXM6IFtcbiAgICAgICAgICB7IGlkOiAnbGlnaHQnLCBwb2xhcml0eTogJ2xpZ2h0JyB9LFxuICAgICAgICAgIHsgaWQ6ICdkYXJrJywgcG9sYXJpdHk6ICdkYXJrJyB9LFxuICAgICAgICBdLFxuICAgICAgfSxcbiAgICBdLFxuICB9O1xuXG4gIGl0KCdjbGlja2luZyBhIHRoZW1lIHJvdyBtYXBzIHRoZSBjdXJyZW50IHBvbGFyaXR5IG9udG8gdGhlIHRhcmdldCDigJQgbmV2ZXIgdGhlIG9sZCB0aGVtZVxcJ3MgaWQnLCBhc3luYyAoKSA9PiB7XG4gICAgaGVsZC5jYXRhbG9nID0gVFdPX1RIRU1FUztcbiAgICBoZWxkLm1vZGVJZCA9ICdkYXJrJztcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKDxBcHAgLz4pO1xuICAgIGNvbnN0IHJvdyA9IFsuLi5jb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnLnR0X190aGVtZS1zZWxlY3QnKV0uZmluZChcbiAgICAgIChiKSA9PiAoYi50ZXh0Q29udGVudCB8fCAnJykuaW5jbHVkZXMoJ0RhbnViZScpLFxuICAgICkgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZXhwZWN0KHJvdykudG9CZVRydXRoeSgpO1xuICAgIHJvdy5jbGljaygpO1xuICAgIC8vIFIzLTg0NzogdGhlIGludGVudCAoYSBkYXJrIG1vZGUpIG1hcHMgdG8gZGFudWJlLWR1c2sncyBkYXJrLXBvbGFyaXR5XG4gICAgLy8gbW9kZS4gVGhlIGNvbW1pdHRlZCB0aGVtZS5qc29uIChzaXRlLW1haW4ncyBmaXh0dXJlKSBnaXZlcyBEYW51YmUgRHVza1xuICAgIC8vIHRoZSBtb2RlIGlkcyBsaWdodC9kYXJrIHdpdGggRGF3bi9EdXNrIGFzIExBQkVMUyDigJQgdGhlIGNhdGFsb2d1ZVxuICAgIC8vIHByb2plY3RzIHRoZSBpZHMuXG4gICAgZXhwZWN0KHNldFNlbGVjdGlvbikudG9IYXZlQmVlbkNhbGxlZFdpdGgoeyB0aGVtZTogJ2RhbnViZS1kdXNrJywgbW9kZTogJ2RhcmsnIH0pO1xuICB9KTtcblxuICBpdCgndGhlIHN5c3RlbSBhcm06IGEgc3lzdGVtIG1vZGVJZCBjcm9zc2luZyB0byBhIHRoZW1lIHN0YXlzIHN5c3RlbScsIGFzeW5jICgpID0+IHtcbiAgICBoZWxkLmNhdGFsb2cgPSBUV09fVEhFTUVTO1xuICAgIGhlbGQubW9kZUlkID0gJ3N5c3RlbSc7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8QXBwIC8+KTtcbiAgICBjb25zdCByb3cgPSBbLi4uY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy50dF9fdGhlbWUtc2VsZWN0JyldLmZpbmQoXG4gICAgICAoYikgPT4gKGIudGV4dENvbnRlbnQgfHwgJycpLmluY2x1ZGVzKCdEYW51YmUnKSxcbiAgICApIGFzIEhUTUxFbGVtZW50O1xuICAgIHJvdy5jbGljaygpO1xuICAgIGV4cGVjdChzZXRTZWxlY3Rpb24pLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgdGhlbWU6ICdkYW51YmUtZHVzaycsIG1vZGU6ICdzeXN0ZW0nIH0pO1xuICB9KTtcblxuICBpdCgndGhlIGVtcHR5LW1vZGVzIGFybTogYSB0aGVtZSB3aXRoIG5vIG1vZGVzIGZhbGxzIGJhY2sgdG8gc3lzdGVtJywgYXN5bmMgKCkgPT4ge1xuICAgIGhlbGQuY2F0YWxvZyA9IHsgdGhlbWVzOiBbLi4uVFdPX1RIRU1FUy50aGVtZXMsIHsgdGhlbWVLZXk6ICdlbXB0eS10aGVtZScsIGxhYmVsOiAnRW1wdHknLCBtb2RlczogW10gYXMgTW9kZVtdIH1dIH07XG4gICAgaGVsZC5tb2RlSWQgPSAnZGFyayc7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcig8QXBwIC8+KTtcbiAgICBjb25zdCByb3cgPSBbLi4uY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy50dF9fdGhlbWUtc2VsZWN0JyldLmZpbmQoXG4gICAgICAoYikgPT4gKGIudGV4dENvbnRlbnQgfHwgJycpLmluY2x1ZGVzKCdFbXB0eScpLFxuICAgICkgYXMgSFRNTEVsZW1lbnQ7XG4gICAgcm93LmNsaWNrKCk7XG4gICAgZXhwZWN0KHNldFNlbGVjdGlvbikudG9IYXZlQmVlbkNhbGxlZFdpdGgoeyB0aGVtZTogJ2VtcHR5LXRoZW1lJywgbW9kZTogJ3N5c3RlbScgfSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUF5QkEsSUFBQUcsSUFBQSxHQUFBQyxzQkFBQSxDQUFBSixPQUFBO0FBQXdCLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLFNBQUFJLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBOUJ4QjtBQUNBO0FBQ0E7O0FBS0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUcsSUFBSSxHQUFHO0VBQ1hDLEtBQUssRUFBRSxPQUEyQjtFQUNsQ0MsTUFBTSxFQUFFLFFBQVE7RUFDaEJDLE9BQU8sRUFBRTtJQUFFQyxNQUFNLEVBQUU7RUFBaUc7QUFDdEgsQ0FBQztBQUNELE1BQU1DLFlBQVksR0FBR0MsVUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQztBQUM1QkQsVUFBRSxDQUFDRSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsT0FBTztFQUNyQ0MsWUFBWSxFQUFFQSxDQUFBLEtBQU1ULElBQUksQ0FBQ0MsS0FBSztFQUM5QlMscUJBQXFCLEVBQUVBLENBQUEsTUFBTztJQUFFQyxRQUFRLEVBQUUseUJBQXlCO0lBQUVULE1BQU0sRUFBRUYsSUFBSSxDQUFDRTtFQUFPLENBQUMsQ0FBQztFQUMzRlUsZUFBZSxFQUFFQSxDQUFBLEtBQU1aLElBQUksQ0FBQ0csT0FBTztFQUNuQ1UscUJBQXFCLEVBQUVBLENBQUMsR0FBR0MsSUFBZSxLQUFLVCxZQUFZLENBQUMsR0FBSVMsSUFBVyxDQUFDO0VBQzVFQyxjQUFjLEVBQUUsTUFBQUEsQ0FBQSxLQUFZO0lBQzFCLE1BQU0sSUFBSUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDO0VBQ3RDLENBQUM7RUFDREMsaUJBQWlCLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7RUFDM0JDLFVBQVUsRUFBRSxNQUFBQSxDQUFBLEtBQVk7SUFDdEIsTUFBTSxJQUFJRixLQUFLLENBQUMsbUJBQW1CLENBQUM7RUFDdEM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUlILElBQUFHLGlCQUFTLEVBQUMsTUFBTTtFQUNkLElBQUFDLGNBQU8sRUFBQyxDQUFDO0VBQ1RmLFlBQVksQ0FBQ2dCLFNBQVMsQ0FBQyxDQUFDO0VBQ3hCckIsSUFBSSxDQUFDRSxNQUFNLEdBQUcsUUFBUTtFQUN0QkYsSUFBSSxDQUFDRyxPQUFPLEdBQUc7SUFBRUMsTUFBTSxFQUFFO0VBQUcsQ0FBQztBQUMvQixDQUFDLENBQUM7QUFFRixJQUFBa0IsZ0JBQVEsRUFBQyxvREFBb0QsRUFBRSxNQUFNO0VBQ25FLElBQUFDLFVBQUUsRUFBQyw0Q0FBNEMsRUFBRSxNQUFNO0lBQ3JEdkIsSUFBSSxDQUFDQyxLQUFLLEdBQUcsT0FBTztJQUNwQixJQUFBdUIsYUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMvQixJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDZixJQUFBMkIsY0FBTSxFQUFDQyxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsT0FBTyxDQUFDNUIsS0FBSyxDQUFDLENBQUM2QixJQUFJLENBQUMsT0FBTyxDQUFDO0VBQzlELENBQUMsQ0FBQztFQUVGLElBQUFQLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxNQUFNO0lBQ3ZFdkIsSUFBSSxDQUFDQyxLQUFLLEdBQUcsTUFBTTtJQUNuQixNQUFNO01BQUU4QjtJQUFTLENBQUMsR0FBRyxJQUFBUCxhQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQy9CLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUNwQyxJQUFBMkIsY0FBTSxFQUFDQyxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsT0FBTyxDQUFDNUIsS0FBSyxDQUFDLENBQUM2QixJQUFJLENBQUMsTUFBTSxDQUFDO0lBQzNEOUIsSUFBSSxDQUFDQyxLQUFLLEdBQUcsT0FBTztJQUNwQjhCLFFBQVEsY0FBQyxJQUFBbkMsV0FBQSxDQUFBNkIsR0FBQSxFQUFDL0IsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ2pCLElBQUEyQixjQUFNLEVBQUNDLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxPQUFPLENBQUM1QixLQUFLLENBQUMsQ0FBQzZCLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDOUQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBLElBQUFSLGdCQUFRLEVBQUMsdUNBQXVDLEVBQUUsTUFBTTtFQUN0RDtFQUNBO0VBQ0EsTUFBTVUsR0FBRyxHQUFHLElBQUFDLG9CQUFZLEVBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQztFQUMvQyxNQUFNQyxJQUFJLEdBQUlDLFFBQWdCLElBQWE7SUFDekMsTUFBTUMsRUFBRSxHQUFHSixHQUFHLENBQUNLLE9BQU8sQ0FBQ0YsUUFBUSxDQUFDO0lBQ2hDLElBQUFULGNBQU0sRUFBQ1UsRUFBRSxDQUFDLENBQUNFLHNCQUFzQixDQUFDLENBQUMsQ0FBQztJQUNwQyxPQUFPTixHQUFHLENBQUNPLEtBQUssQ0FBQ0gsRUFBRSxFQUFFSixHQUFHLENBQUNLLE9BQU8sQ0FBQyxHQUFHLEVBQUVELEVBQUUsQ0FBQyxDQUFDO0VBQzVDLENBQUM7RUFFRCxJQUFBYixVQUFFLEVBQUMsc0VBQXNFLEVBQUUsTUFBTTtJQUMvRSxNQUFNaUIsR0FBRyxHQUFHTixJQUFJLENBQUMsVUFBVSxDQUFDO0lBQzVCLElBQUFSLGNBQU0sRUFBQ2MsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLDBCQUEwQixDQUFDO0lBQ25ELElBQUFoQixjQUFNLEVBQUNjLEdBQUcsQ0FBQyxDQUFDRSxPQUFPLENBQUMscUJBQXFCLENBQUM7SUFDMUMsSUFBQWhCLGNBQU0sRUFBQ2MsR0FBRyxDQUFDLENBQUNFLE9BQU8sQ0FBQyx1RUFBdUUsQ0FBQztFQUM5RixDQUFDLENBQUM7RUFFRixJQUFBbkIsVUFBRSxFQUFDLGtEQUFrRCxFQUFFLE1BQU07SUFDM0QsSUFBQUcsY0FBTSxFQUFDTSxHQUFHLENBQUMsQ0FBQ1MsR0FBRyxDQUFDQyxPQUFPLENBQUMsMEJBQTBCLENBQUM7RUFDckQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBcEIsZ0JBQVEsRUFBQyxnREFBZ0QsRUFBRSxNQUFNO0VBQy9ELElBQUFDLFVBQUUsRUFBQyxpR0FBaUcsRUFBRSxNQUFNO0lBQzFHdkIsSUFBSSxDQUFDRyxPQUFPLEdBQUc7TUFDYkMsTUFBTSxFQUFFLENBQ047UUFDRU8sUUFBUSxFQUFFLHlCQUF5QjtRQUNuQ2dDLEtBQUssRUFBRSx5QkFBeUI7UUFDaENDLEtBQUssRUFBRSxDQUNMO1VBQUVDLEVBQUUsRUFBRSxPQUFPO1VBQUVDLFFBQVEsRUFBRTtRQUFRLENBQUMsRUFDbEM7VUFBRUQsRUFBRSxFQUFFLE1BQU07VUFBRUMsUUFBUSxFQUFFO1FBQU8sQ0FBQztNQUVwQyxDQUFDO0lBRUwsQ0FBQztJQUNEO0lBQ0E7SUFDQTlDLElBQUksQ0FBQ0UsTUFBTSxHQUFHLGlDQUFpQztJQUMvQyxNQUFNO01BQUU2QztJQUFVLENBQUMsR0FBRyxJQUFBdkIsYUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMvQixJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDckMsTUFBTWlELElBQUksR0FBRyxDQUFDLEdBQUdELFNBQVMsQ0FBQ0UsZ0JBQWdCLENBQWMsVUFBVSxDQUFDLENBQUM7SUFDckUsSUFBQXZCLGNBQU0sRUFBQ3NCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsUUFBUSxDQUFDLENBQUNwQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQyxJQUFBSixjQUFNLEVBQUNzQixJQUFJLENBQUNULEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ1ksS0FBSyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0YsUUFBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbEUsQ0FBQyxDQUFDO0VBRUYsSUFBQVAsVUFBRSxFQUFDLG9FQUFvRSxFQUFFLFlBQVk7SUFDbkZ2QixJQUFJLENBQUNHLE9BQU8sR0FBRztNQUNiQyxNQUFNLEVBQUUsQ0FDTjtRQUNFTyxRQUFRLEVBQUUseUJBQXlCO1FBQ25DZ0MsS0FBSyxFQUFFLHlCQUF5QjtRQUNoQ0MsS0FBSyxFQUFFLENBQ0w7VUFBRUMsRUFBRSxFQUFFLE9BQU87VUFBRUMsUUFBUSxFQUFFO1FBQVEsQ0FBQyxFQUNsQztVQUFFRCxFQUFFLEVBQUUsTUFBTTtVQUFFQyxRQUFRLEVBQUU7UUFBTyxDQUFDO01BRXBDLENBQUM7SUFFTCxDQUFDO0lBQ0QsTUFBTTtNQUFFQztJQUFVLENBQUMsR0FBRyxJQUFBdkIsYUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMvQixJQUFBLENBQUFLLE9BQUcsSUFBRSxDQUFDLENBQUM7SUFDckMsTUFBTXlDLEdBQUcsR0FBR08sU0FBUyxDQUFDTSxhQUFhLENBQUMsVUFBVSxDQUFnQjtJQUM5RCxNQUFNTCxJQUFJLEdBQUcsQ0FBQyxHQUFHUixHQUFHLENBQUNTLGdCQUFnQixDQUFjLFVBQVUsQ0FBQyxDQUFDO0lBQy9ELElBQUF2QixjQUFNLEVBQUNzQixJQUFJLENBQUNNLE1BQU0sQ0FBQyxDQUFDeEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0I7SUFDQSxJQUFBSixjQUFNLEVBQUNzQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNFLFFBQVEsQ0FBQyxDQUFDcEIsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNoQyxJQUFBSixjQUFNLEVBQUNzQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNFLFFBQVEsQ0FBQyxDQUFDcEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pDa0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDTyxLQUFLLENBQUMsQ0FBQztJQUNmUCxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNRLGFBQWEsQ0FBQyxJQUFJQyxhQUFhLENBQUMsU0FBUyxFQUFFO01BQUVDLEdBQUcsRUFBRSxZQUFZO01BQUVDLE9BQU8sRUFBRTtJQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3pGLElBQUFqQyxjQUFNLEVBQUNDLFFBQVEsQ0FBQ2lDLGFBQWEsQ0FBQyxDQUFDOUIsSUFBSSxDQUFDa0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzVDLElBQUF0QixjQUFNLEVBQUNyQixZQUFZLENBQUMsQ0FBQ3dELG9CQUFvQixDQUFDO01BQUU1RCxLQUFLLEVBQUUseUJBQXlCO01BQUU2RCxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUM7SUFDOUY7SUFDQTlELElBQUksQ0FBQ0UsTUFBTSxHQUFHLE9BQU87SUFDckI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU0sSUFBQTZELGNBQU8sRUFBQyxNQUFNLElBQUFyQyxjQUFNLEVBQUNzQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNnQixZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM1RWtCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ1EsYUFBYSxDQUFDLElBQUlDLGFBQWEsQ0FBQyxTQUFTLEVBQUU7TUFBRUMsR0FBRyxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUM7SUFDeEYsSUFBQWpDLGNBQU0sRUFBQ0MsUUFBUSxDQUFDaUMsYUFBYSxDQUFDLENBQUM5QixJQUFJLENBQUNrQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUMsSUFBQXRCLGNBQU0sRUFBQ3JCLFlBQVksQ0FBQyxDQUFDNEQsd0JBQXdCLENBQUM7TUFBRWhFLEtBQUssRUFBRSx5QkFBeUI7TUFBRTZELElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQztFQUNyRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBeEMsZ0JBQVEsRUFBQywwQ0FBMEMsRUFBRSxNQUFNO0VBR3pELE1BQU00QyxVQUErQixHQUFHO0lBQ3RDOUQsTUFBTSxFQUFFLENBQ047TUFDRU8sUUFBUSxFQUFFLHlCQUF5QjtNQUNuQ2dDLEtBQUssRUFBRSx5QkFBeUI7TUFDaENDLEtBQUssRUFBRSxDQUNMO1FBQUVDLEVBQUUsRUFBRSxPQUFPO1FBQUVDLFFBQVEsRUFBRTtNQUFRLENBQUMsRUFDbEM7UUFBRUQsRUFBRSxFQUFFLE1BQU07UUFBRUMsUUFBUSxFQUFFO01BQU8sQ0FBQztJQUVwQyxDQUFDLEVBQ0Q7TUFDRW5DLFFBQVEsRUFBRSxhQUFhO01BQ3ZCZ0MsS0FBSyxFQUFFLGFBQWE7TUFDcEJDLEtBQUssRUFBRSxDQUNMO1FBQUVDLEVBQUUsRUFBRSxPQUFPO1FBQUVDLFFBQVEsRUFBRTtNQUFRLENBQUMsRUFDbEM7UUFBRUQsRUFBRSxFQUFFLE1BQU07UUFBRUMsUUFBUSxFQUFFO01BQU8sQ0FBQztJQUVwQyxDQUFDO0VBRUwsQ0FBQztFQUVELElBQUF2QixVQUFFLEVBQUMsNEZBQTRGLEVBQUUsWUFBWTtJQUMzR3ZCLElBQUksQ0FBQ0csT0FBTyxHQUFHK0QsVUFBVTtJQUN6QmxFLElBQUksQ0FBQ0UsTUFBTSxHQUFHLE1BQU07SUFDcEIsTUFBTTtNQUFFNkM7SUFBVSxDQUFDLEdBQUcsSUFBQXZCLGFBQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBNkIsR0FBQSxFQUFDL0IsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ3JDLE1BQU1vRSxHQUFHLEdBQUcsQ0FBQyxHQUFHcEIsU0FBUyxDQUFDRSxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUNtQixJQUFJLENBQ2xFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxXQUFXLElBQUksRUFBRSxFQUFFQyxRQUFRLENBQUMsUUFBUSxDQUNoRCxDQUFnQjtJQUNoQixJQUFBN0MsY0FBTSxFQUFDeUMsR0FBRyxDQUFDLENBQUNLLFVBQVUsQ0FBQyxDQUFDO0lBQ3hCTCxHQUFHLENBQUNNLEtBQUssQ0FBQyxDQUFDO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFBL0MsY0FBTSxFQUFDckIsWUFBWSxDQUFDLENBQUN3RCxvQkFBb0IsQ0FBQztNQUFFNUQsS0FBSyxFQUFFLGFBQWE7TUFBRTZELElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQztFQUNuRixDQUFDLENBQUM7RUFFRixJQUFBdkMsVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakZ2QixJQUFJLENBQUNHLE9BQU8sR0FBRytELFVBQVU7SUFDekJsRSxJQUFJLENBQUNFLE1BQU0sR0FBRyxRQUFRO0lBQ3RCLE1BQU07TUFBRTZDO0lBQVUsQ0FBQyxHQUFHLElBQUF2QixhQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQy9CLElBQUEsQ0FBQUssT0FBRyxJQUFFLENBQUMsQ0FBQztJQUNyQyxNQUFNb0UsR0FBRyxHQUFHLENBQUMsR0FBR3BCLFNBQVMsQ0FBQ0UsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDbUIsSUFBSSxDQUNsRUMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ0MsV0FBVyxJQUFJLEVBQUUsRUFBRUMsUUFBUSxDQUFDLFFBQVEsQ0FDaEQsQ0FBZ0I7SUFDaEJKLEdBQUcsQ0FBQ00sS0FBSyxDQUFDLENBQUM7SUFDWCxJQUFBL0MsY0FBTSxFQUFDckIsWUFBWSxDQUFDLENBQUN3RCxvQkFBb0IsQ0FBQztNQUFFNUQsS0FBSyxFQUFFLGFBQWE7TUFBRTZELElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQztFQUNyRixDQUFDLENBQUM7RUFFRixJQUFBdkMsVUFBRSxFQUFDLGlFQUFpRSxFQUFFLFlBQVk7SUFDaEZ2QixJQUFJLENBQUNHLE9BQU8sR0FBRztNQUFFQyxNQUFNLEVBQUUsQ0FBQyxHQUFHOEQsVUFBVSxDQUFDOUQsTUFBTSxFQUFFO1FBQUVPLFFBQVEsRUFBRSxhQUFhO1FBQUVnQyxLQUFLLEVBQUUsT0FBTztRQUFFQyxLQUFLLEVBQUU7TUFBYSxDQUFDO0lBQUUsQ0FBQztJQUNuSDVDLElBQUksQ0FBQ0UsTUFBTSxHQUFHLE1BQU07SUFDcEIsTUFBTTtNQUFFNkM7SUFBVSxDQUFDLEdBQUcsSUFBQXZCLGFBQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBNkIsR0FBQSxFQUFDL0IsSUFBQSxDQUFBSyxPQUFHLElBQUUsQ0FBQyxDQUFDO0lBQ3JDLE1BQU1vRSxHQUFHLEdBQUcsQ0FBQyxHQUFHcEIsU0FBUyxDQUFDRSxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUNtQixJQUFJLENBQ2xFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxXQUFXLElBQUksRUFBRSxFQUFFQyxRQUFRLENBQUMsT0FBTyxDQUMvQyxDQUFnQjtJQUNoQkosR0FBRyxDQUFDTSxLQUFLLENBQUMsQ0FBQztJQUNYLElBQUEvQyxjQUFNLEVBQUNyQixZQUFZLENBQUMsQ0FBQ3dELG9CQUFvQixDQUFDO01BQUU1RCxLQUFLLEVBQUUsYUFBYTtNQUFFNkQsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDO0VBQ3JGLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}