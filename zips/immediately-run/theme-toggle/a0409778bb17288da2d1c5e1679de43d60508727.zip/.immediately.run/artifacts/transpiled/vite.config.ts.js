"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The theme switcher (`widget.theme`, HOST_THEMING_SPEC §8.2): the R3-501
// two-state toggle upgraded in place. https://vite.dev/config/
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _pluginReact.default)()],
  test: {
    // R3-834: the tests read document.documentElement (the polarity effect).
    environment: 'jsdom'
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZpbmVDb25maWciLCJwbHVnaW5zIiwicmVhY3QiLCJ0ZXN0IiwiZW52aXJvbm1lbnQiXSwic291cmNlcyI6WyJ2aXRlLmNvbmZpZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlc3QvY29uZmlnJztcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCc7XG5cbi8vIFRoZSB0aGVtZSBzd2l0Y2hlciAoYHdpZGdldC50aGVtZWAsIEhPU1RfVEhFTUlOR19TUEVDIMKnOC4yKTogdGhlIFIzLTUwMVxuLy8gdHdvLXN0YXRlIHRvZ2dsZSB1cGdyYWRlZCBpbiBwbGFjZS4gaHR0cHM6Ly92aXRlLmRldi9jb25maWcvXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbcmVhY3QoKV0sXG4gIHRlc3Q6IHtcbiAgICAvLyBSMy04MzQ6IHRoZSB0ZXN0cyByZWFkIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCAodGhlIHBvbGFyaXR5IGVmZmVjdCkuXG4gICAgZW52aXJvbm1lbnQ6ICdqc2RvbScsXG4gIH0sXG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQXlDLFNBQUFFLHVCQUFBQyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRXpDO0FBQ0E7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUYsT0FBQSxHQUNlLElBQUFHLG9CQUFZLEVBQUM7RUFDMUJDLE9BQU8sRUFBRSxDQUFDLElBQUFDLG9CQUFLLEVBQUMsQ0FBQyxDQUFDO0VBQ2xCQyxJQUFJLEVBQUU7SUFDSjtJQUNBQyxXQUFXLEVBQUU7RUFDZjtBQUNGLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==