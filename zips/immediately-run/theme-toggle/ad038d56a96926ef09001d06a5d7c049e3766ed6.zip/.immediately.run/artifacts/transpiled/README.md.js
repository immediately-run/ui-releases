var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "theme-toggle",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "theme-toggle"
      }), "theme-toggle"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The smallest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), " system app, and the\ndesignated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pilot for the capability pipeline"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS_SPEC"
      }), " §5.4 / §8.5,\ndesign brief 06)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It reads the host UI theme (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:read"
      }), ", baseline) and sets it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:set"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "elevated"
      }), ") — a segmented light/dark control reflecting the current host theme.\nIt updates optimistically, then confirms from the host's re-push (the loop closes\nvia ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:read"
      }), "). A build running without ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:set"
      }), " degrades to a disabled\n\"preview only\" state rather than erroring."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Loaded into a chrome region by the host; not meant to be run standalone."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwicCIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJ0aGVtZS10b2dnbGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZW1lLXRvZ2dsZVwiIC8+e1widGhlbWUtdG9nZ2xlXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc21hbGxlc3QgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIiBzeXN0ZW0gYXBwLCBhbmQgdGhlXFxuZGVzaWduYXRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBpbG90IGZvciB0aGUgY2FwYWJpbGl0eSBwaXBlbGluZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzUuNCAvIMKnOC41LFxcbmRlc2lnbiBicmllZiAwNikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkl0IHJlYWRzIHRoZSBob3N0IFVJIHRoZW1lIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aGVtZTpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYmFzZWxpbmUpIGFuZCBzZXRzIGl0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aGVtZTpzZXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWxldmF0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIpIOKAlCBhIHNlZ21lbnRlZCBsaWdodC9kYXJrIGNvbnRyb2wgcmVmbGVjdGluZyB0aGUgY3VycmVudCBob3N0IHRoZW1lLlxcbkl0IHVwZGF0ZXMgb3B0aW1pc3RpY2FsbHksIHRoZW4gY29uZmlybXMgZnJvbSB0aGUgaG9zdCdzIHJlLXB1c2ggKHRoZSBsb29wIGNsb3Nlc1xcbnZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aGVtZTpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIEEgYnVpbGQgcnVubmluZyB3aXRob3V0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInRoZW1lOnNldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVncmFkZXMgdG8gYSBkaXNhYmxlZFxcblxcXCJwcmV2aWV3IG9ubHlcXFwiIHN0YXRlIHJhdGhlciB0aGFuIGVycm9yaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJMb2FkZWQgaW50byBhIGNocm9tZSByZWdpb24gYnkgdGhlIGhvc3Q7IG5vdCBtZWFudCB0byBiZSBydW4gc3RhbmRhbG9uZS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEIsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdQLEtBQUssQ0FBQ1E7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdSLFdBQVc7RUFDaEMsSUFBSSxDQUFDUSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQVosV0FBQSxDQUFBYSxJQUFBLEVBQUFiLFdBQUEsQ0FBQWMsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFmLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNHLEVBQUU7TUFBQ1UsRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWMsQ0FBRSxDQUFDLEVBQUMsY0FBYztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDYyxJQUFJLEVBQUMseUJBQXlCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNLLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQW1DLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNFLElBQUk7UUFBQVUsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxrQ0FBa0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFmLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDRSxJQUFJO1FBQUFVLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDSyxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxnS0FBZ0ssZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNFLElBQUk7UUFBQVUsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHVFQUF1RTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxFQUFFO0lBQTBFLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDbnJDO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQ2pCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNrQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHUCxLQUFLLENBQUNRO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQXJCLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUtuQixLQUFLO0lBQUFhLFFBQUEsZUFBRSxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNoQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDb0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}