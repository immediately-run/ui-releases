var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _lucideReact = require("lucide-react");
var _hostTheme = require("../hostTheme");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The theme toggle (UI_AS_APPS_SPEC §5.4 / §8.5; design brief 06). The smallest
// system app and the designated pilot for the whole capability pipeline: it
// READS the host theme (`theme:read`, baseline) and SETS it (`theme:set`,
// elevated). A segmented light/dark control reflecting the current host theme;
// it updates optimistically, then confirms from the host's re-push (the loop
// closes via `theme:read`). If this build runs without `theme:set` the control
// degrades to a disabled "preview only" state — never a hard error.
// Both read (useHostTheme) and write (setHostTheme) are local helpers reaching
// the sandbox bundler directly: the published SDK 0.1.5 ships neither a `theme`
// export nor `setHostTheme`. Switch to the SDK once it's republished.
const OPTIONS = [{
  value: "light",
  label: "Light",
  Icon: _lucideReact.Sun
}, {
  value: "dark",
  label: "Dark",
  Icon: _lucideReact.Moon
}];
function ThemeToggle() {
  _s();
  const hostTheme = (0, _hostTheme.useHostTheme)();
  // Optimistic selection while the host confirms via re-push. Once the host's
  // re-push makes `hostTheme` match, `pending` is ignored (derived, no effect).
  const [pending, setPending] = (0, _react.useState)(null);
  const [forbidden, setForbidden] = (0, _react.useState)(false);
  const current = pending && pending !== hostTheme ? pending : hostTheme;
  const choose = async value => {
    if (forbidden || value === current) return;
    setPending(value);
    try {
      await (0, _hostTheme.setHostTheme)(value);
      // Success: the host re-pushes the new theme; the effect above clears
      // `pending` when `useHostTheme` catches up.
    } catch (e) {
      const code = e?.code;
      if (code === "forbidden") setForbidden(true);
      setPending(null); // revert the optimistic choice
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "tt",
    "aria-label": "Host theme",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "tt__seg",
      role: "radiogroup",
      "aria-label": "Host theme",
      children: OPTIONS.map(({
        value,
        label,
        Icon
      }) => {
        const active = current === value;
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          role: "radio",
          "aria-checked": active,
          className: `tt__opt${active ? " is-active" : ""}`,
          disabled: forbidden,
          onClick: () => choose(value),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
            size: 15,
            "aria-hidden": "true"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            children: label
          })]
        }, value);
      })
    }), forbidden && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "tt__note",
      children: "Preview only \u2014 this copy can\u2019t change the host theme."
    })]
  });
}
_s(ThemeToggle, "IETefgF6QGHYW1uoBn6vo09IF+w=", false, function () {
  return [_hostTheme.useHostTheme];
});
_c = ThemeToggle;
var _default = exports.default = ThemeToggle;
var _c;
$RefreshReg$(_c, "ThemeToggle");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX2hvc3RUaGVtZSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJPUFRJT05TIiwidmFsdWUiLCJsYWJlbCIsIkljb24iLCJTdW4iLCJNb29uIiwiVGhlbWVUb2dnbGUiLCJob3N0VGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJwZW5kaW5nIiwic2V0UGVuZGluZyIsInVzZVN0YXRlIiwiZm9yYmlkZGVuIiwic2V0Rm9yYmlkZGVuIiwiY3VycmVudCIsImNob29zZSIsInNldEhvc3RUaGVtZSIsImUiLCJjb2RlIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4Iiwicm9sZSIsIm1hcCIsImFjdGl2ZSIsInR5cGUiLCJkaXNhYmxlZCIsIm9uQ2xpY2siLCJzaXplIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGhlbWVUb2dnbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSB0aGVtZSB0b2dnbGUgKFVJX0FTX0FQUFNfU1BFQyDCpzUuNCAvIMKnOC41OyBkZXNpZ24gYnJpZWYgMDYpLiBUaGUgc21hbGxlc3Rcbi8vIHN5c3RlbSBhcHAgYW5kIHRoZSBkZXNpZ25hdGVkIHBpbG90IGZvciB0aGUgd2hvbGUgY2FwYWJpbGl0eSBwaXBlbGluZTogaXRcbi8vIFJFQURTIHRoZSBob3N0IHRoZW1lIChgdGhlbWU6cmVhZGAsIGJhc2VsaW5lKSBhbmQgU0VUUyBpdCAoYHRoZW1lOnNldGAsXG4vLyBlbGV2YXRlZCkuIEEgc2VnbWVudGVkIGxpZ2h0L2RhcmsgY29udHJvbCByZWZsZWN0aW5nIHRoZSBjdXJyZW50IGhvc3QgdGhlbWU7XG4vLyBpdCB1cGRhdGVzIG9wdGltaXN0aWNhbGx5LCB0aGVuIGNvbmZpcm1zIGZyb20gdGhlIGhvc3QncyByZS1wdXNoICh0aGUgbG9vcFxuLy8gY2xvc2VzIHZpYSBgdGhlbWU6cmVhZGApLiBJZiB0aGlzIGJ1aWxkIHJ1bnMgd2l0aG91dCBgdGhlbWU6c2V0YCB0aGUgY29udHJvbFxuLy8gZGVncmFkZXMgdG8gYSBkaXNhYmxlZCBcInByZXZpZXcgb25seVwiIHN0YXRlIOKAlCBuZXZlciBhIGhhcmQgZXJyb3IuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgU3VuLCBNb29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuLy8gQm90aCByZWFkICh1c2VIb3N0VGhlbWUpIGFuZCB3cml0ZSAoc2V0SG9zdFRoZW1lKSBhcmUgbG9jYWwgaGVscGVycyByZWFjaGluZ1xuLy8gdGhlIHNhbmRib3ggYnVuZGxlciBkaXJlY3RseTogdGhlIHB1Ymxpc2hlZCBTREsgMC4xLjUgc2hpcHMgbmVpdGhlciBhIGB0aGVtZWBcbi8vIGV4cG9ydCBub3IgYHNldEhvc3RUaGVtZWAuIFN3aXRjaCB0byB0aGUgU0RLIG9uY2UgaXQncyByZXB1Ymxpc2hlZC5cbmltcG9ydCB7IHVzZUhvc3RUaGVtZSwgc2V0SG9zdFRoZW1lLCB0eXBlIEhvc3RUaGVtZSB9IGZyb20gXCIuLi9ob3N0VGhlbWVcIjtcblxuY29uc3QgT1BUSU9OUzogQXJyYXk8eyB2YWx1ZTogSG9zdFRoZW1lOyBsYWJlbDogc3RyaW5nOyBJY29uOiB0eXBlb2YgU3VuIH0+ID0gW1xuICB7IHZhbHVlOiBcImxpZ2h0XCIsIGxhYmVsOiBcIkxpZ2h0XCIsIEljb246IFN1biB9LFxuICB7IHZhbHVlOiBcImRhcmtcIiwgbGFiZWw6IFwiRGFya1wiLCBJY29uOiBNb29uIH0sXG5dO1xuXG5mdW5jdGlvbiBUaGVtZVRvZ2dsZSgpIHtcbiAgY29uc3QgaG9zdFRoZW1lID0gdXNlSG9zdFRoZW1lKCk7XG4gIC8vIE9wdGltaXN0aWMgc2VsZWN0aW9uIHdoaWxlIHRoZSBob3N0IGNvbmZpcm1zIHZpYSByZS1wdXNoLiBPbmNlIHRoZSBob3N0J3NcbiAgLy8gcmUtcHVzaCBtYWtlcyBgaG9zdFRoZW1lYCBtYXRjaCwgYHBlbmRpbmdgIGlzIGlnbm9yZWQgKGRlcml2ZWQsIG5vIGVmZmVjdCkuXG4gIGNvbnN0IFtwZW5kaW5nLCBzZXRQZW5kaW5nXSA9IHVzZVN0YXRlPEhvc3RUaGVtZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZm9yYmlkZGVuLCBzZXRGb3JiaWRkZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBjdXJyZW50OiBIb3N0VGhlbWUgPVxuICAgIHBlbmRpbmcgJiYgcGVuZGluZyAhPT0gaG9zdFRoZW1lID8gcGVuZGluZyA6IGhvc3RUaGVtZTtcblxuICBjb25zdCBjaG9vc2UgPSBhc3luYyAodmFsdWU6IEhvc3RUaGVtZSkgPT4ge1xuICAgIGlmIChmb3JiaWRkZW4gfHwgdmFsdWUgPT09IGN1cnJlbnQpIHJldHVybjtcbiAgICBzZXRQZW5kaW5nKHZhbHVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2V0SG9zdFRoZW1lKHZhbHVlKTtcbiAgICAgIC8vIFN1Y2Nlc3M6IHRoZSBob3N0IHJlLXB1c2hlcyB0aGUgbmV3IHRoZW1lOyB0aGUgZWZmZWN0IGFib3ZlIGNsZWFyc1xuICAgICAgLy8gYHBlbmRpbmdgIHdoZW4gYHVzZUhvc3RUaGVtZWAgY2F0Y2hlcyB1cC5cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgaWYgKGNvZGUgPT09IFwiZm9yYmlkZGVuXCIpIHNldEZvcmJpZGRlbih0cnVlKTtcbiAgICAgIHNldFBlbmRpbmcobnVsbCk7IC8vIHJldmVydCB0aGUgb3B0aW1pc3RpYyBjaG9pY2VcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0dFwiIGFyaWEtbGFiZWw9XCJIb3N0IHRoZW1lXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInR0X19zZWdcIiByb2xlPVwicmFkaW9ncm91cFwiIGFyaWEtbGFiZWw9XCJIb3N0IHRoZW1lXCI+XG4gICAgICAgIHtPUFRJT05TLm1hcCgoeyB2YWx1ZSwgbGFiZWwsIEljb24gfSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IGN1cnJlbnQgPT09IHZhbHVlO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17dmFsdWV9XG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICByb2xlPVwicmFkaW9cIlxuICAgICAgICAgICAgICBhcmlhLWNoZWNrZWQ9e2FjdGl2ZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHRfX29wdCR7YWN0aXZlID8gXCIgaXMtYWN0aXZlXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtmb3JiaWRkZW59XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNob29zZSh2YWx1ZSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxJY29uIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtmb3JiaWRkZW4gJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0dF9fbm90ZVwiPlxuICAgICAgICAgIFByZXZpZXcgb25seSDigJQgdGhpcyBjb3B5IGNhbuKAmXQgY2hhbmdlIHRoZSBob3N0IHRoZW1lLlxuICAgICAgICA8L3A+XG4gICAgICApfVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgVGhlbWVUb2dnbGU7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUQsT0FBQTtBQUlBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQUEwRSxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUFaMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFHQSxNQUFNQyxPQUFxRSxHQUFHLENBQzVFO0VBQUVDLEtBQUssRUFBRSxPQUFPO0VBQUVDLEtBQUssRUFBRSxPQUFPO0VBQUVDLElBQUksRUFBRUM7QUFBSSxDQUFDLEVBQzdDO0VBQUVILEtBQUssRUFBRSxNQUFNO0VBQUVDLEtBQUssRUFBRSxNQUFNO0VBQUVDLElBQUksRUFBRUU7QUFBSyxDQUFDLENBQzdDO0FBRUQsU0FBU0MsV0FBV0EsQ0FBQSxFQUFHO0VBQUFSLEVBQUE7RUFDckIsTUFBTVMsU0FBUyxHQUFHLElBQUFDLHVCQUFZLEVBQUMsQ0FBQztFQUNoQztFQUNBO0VBQ0EsTUFBTSxDQUFDQyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBbUIsSUFBSSxDQUFDO0VBQzlELE1BQU0sQ0FBQ0MsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ2pELE1BQU1HLE9BQWtCLEdBQ3RCTCxPQUFPLElBQUlBLE9BQU8sS0FBS0YsU0FBUyxHQUFHRSxPQUFPLEdBQUdGLFNBQVM7RUFFeEQsTUFBTVEsTUFBTSxHQUFHLE1BQU9kLEtBQWdCLElBQUs7SUFDekMsSUFBSVcsU0FBUyxJQUFJWCxLQUFLLEtBQUthLE9BQU8sRUFBRTtJQUNwQ0osVUFBVSxDQUFDVCxLQUFLLENBQUM7SUFDakIsSUFBSTtNQUNGLE1BQU0sSUFBQWUsdUJBQVksRUFBQ2YsS0FBSyxDQUFDO01BQ3pCO01BQ0E7SUFDRixDQUFDLENBQUMsT0FBT2dCLENBQUMsRUFBRTtNQUNWLE1BQU1DLElBQUksR0FBSUQsQ0FBQyxFQUF3QkMsSUFBSTtNQUMzQyxJQUFJQSxJQUFJLEtBQUssV0FBVyxFQUFFTCxZQUFZLENBQUMsSUFBSSxDQUFDO01BQzVDSCxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNwQjtFQUNGLENBQUM7RUFFRCxvQkFDRSxJQUFBYixXQUFBLENBQUFzQixJQUFBO0lBQVNDLFNBQVMsRUFBQyxJQUFJO0lBQUMsY0FBVyxZQUFZO0lBQUFDLFFBQUEsZ0JBQzdDLElBQUF4QixXQUFBLENBQUF5QixHQUFBO01BQUtGLFNBQVMsRUFBQyxTQUFTO01BQUNHLElBQUksRUFBQyxZQUFZO01BQUMsY0FBVyxZQUFZO01BQUFGLFFBQUEsRUFDL0RyQixPQUFPLENBQUN3QixHQUFHLENBQUMsQ0FBQztRQUFFdkIsS0FBSztRQUFFQyxLQUFLO1FBQUVDO01BQUssQ0FBQyxLQUFLO1FBQ3ZDLE1BQU1zQixNQUFNLEdBQUdYLE9BQU8sS0FBS2IsS0FBSztRQUNoQyxvQkFDRSxJQUFBSixXQUFBLENBQUFzQixJQUFBO1VBRUVPLElBQUksRUFBQyxRQUFRO1VBQ2JILElBQUksRUFBQyxPQUFPO1VBQ1osZ0JBQWNFLE1BQU87VUFDckJMLFNBQVMsRUFBRSxVQUFVSyxNQUFNLEdBQUcsWUFBWSxHQUFHLEVBQUUsRUFBRztVQUNsREUsUUFBUSxFQUFFZixTQUFVO1VBQ3BCZ0IsT0FBTyxFQUFFQSxDQUFBLEtBQU1iLE1BQU0sQ0FBQ2QsS0FBSyxDQUFFO1VBQUFvQixRQUFBLGdCQUU3QixJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDbkIsSUFBSTtZQUFDMEIsSUFBSSxFQUFFLEVBQUc7WUFBQyxlQUFZO1VBQU0sQ0FBRSxDQUFDLGVBQ3JDLElBQUFoQyxXQUFBLENBQUF5QixHQUFBO1lBQUFELFFBQUEsRUFBT25CO1VBQUssQ0FBTyxDQUFDO1FBQUEsR0FUZkQsS0FVQyxDQUFDO01BRWIsQ0FBQztJQUFDLENBQ0MsQ0FBQyxFQUNMVyxTQUFTLGlCQUNSLElBQUFmLFdBQUEsQ0FBQXlCLEdBQUE7TUFBR0YsU0FBUyxFQUFDLFVBQVU7TUFBQUMsUUFBQSxFQUFDO0lBRXhCLENBQUcsQ0FDSjtFQUFBLENBQ00sQ0FBQztBQUVkO0FBQUN2QixFQUFBLENBbkRRUSxXQUFXO0VBQUEsUUFDQUUsdUJBQVk7QUFBQTtBQUFBc0IsRUFBQSxHQUR2QnhCLFdBQVc7QUFBQSxJQUFBeUIsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FxREwzQixXQUFXO0FBQUEsSUFBQXdCLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}