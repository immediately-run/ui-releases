var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./App.css");
var _ThemeToggle = _interopRequireDefault(require("./components/ThemeToggle"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// Global CSS is imported here (not main.tsx). The pilot ELEVATED-write system
// app: reads the host theme and sets it via the gated theme:set action.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ThemeToggle.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX1RoZW1lVG9nZ2xlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwianN4IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLlxuLy8gR2xvYmFsIENTUyBpcyBpbXBvcnRlZCBoZXJlIChub3QgbWFpbi50c3gpLiBUaGUgcGlsb3QgRUxFVkFURUQtd3JpdGUgc3lzdGVtXG4vLyBhcHA6IHJlYWRzIHRoZSBob3N0IHRoZW1lIGFuZCBzZXRzIGl0IHZpYSB0aGUgZ2F0ZWQgdGhlbWU6c2V0IGFjdGlvbi5cbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5pbXBvcnQgXCIuL0FwcC5jc3NcIjtcbmltcG9ydCBUaGVtZVRvZ2dsZSBmcm9tIFwiLi9jb21wb25lbnRzL1RoZW1lVG9nZ2xlXCI7XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIDxUaGVtZVRvZ2dsZSAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQUEsT0FBQTtBQUNBQSxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQW1ELElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTG5EO0FBQ0E7QUFDQTs7QUFLQSxTQUFTRyxHQUFHQSxDQUFBLEVBQUc7RUFDYixvQkFBTyxJQUFBSixXQUFBLENBQUFLLEdBQUEsRUFBQ1AsWUFBQSxDQUFBSyxPQUFXLElBQUUsQ0FBQztBQUN4QjtBQUFDRyxFQUFBLEdBRlFGLEdBQUc7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUwsT0FBQSxHQUlHQyxHQUFHO0FBQUEsSUFBQUUsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}