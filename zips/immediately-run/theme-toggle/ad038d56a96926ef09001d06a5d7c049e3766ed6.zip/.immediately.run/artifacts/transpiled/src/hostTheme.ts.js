"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getHostTheme = getHostTheme;
exports.setHostTheme = setHostTheme;
exports.useHostTheme = useHostTheme;
var _react = require("react");
// Set the host UI theme — the elevated `theme:set` action (UI_AS_APPS_SPEC §8.5).
//
// This is a LOCAL copy of the SDK's `setHostTheme` (added in the SDK source but
// not yet on npm). It calls the same gated path the SDK wraps: the sandbox
// bundler's message bus `protocolRequest('theme', 'set', …)`. Switch to
// `import { setHostTheme } from '@immediately-run/sdk/theme'` once the SDK is
// republished. Reading the host theme uses the published `useHostTheme`.
//
// The host gate (§8.4) rejects this unless the calling iframe's grant holds
// `theme:set`, returning a `{ ok:false, code:'forbidden' }` envelope — we throw
// an Error carrying that `.code` so the UI can fall back to "preview only".

/* eslint-disable @typescript-eslint/no-explicit-any */
function bundler() {
  try {
    // @ts-expect-error - `module` is injected by the sandbox runtime
    return module?.evaluation?.module?.bundler ?? null;
  } catch {
    return null;
  }
}

// Reading the host theme: the published SDK 0.1.5 has no `theme` export, so we
// read the same bundler theme service the SDK's `useHostTheme` wraps. Baseline
// `theme:read` — every app may read it.
function getHostTheme() {
  const t = bundler()?.theme?.getTheme?.();
  return t === "light" ? "light" : "dark";
}

/** React hook: the current host theme, re-rendering on host re-push. */
function useHostTheme() {
  const [theme, setTheme] = (0, _react.useState)(getHostTheme);
  (0, _react.useEffect)(() => {
    const svc = bundler()?.theme;
    if (!svc?.onChange) return;
    const d = svc.onChange(t => setTheme(t === "light" ? "light" : "dark"));
    return () => d?.dispose?.();
  }, []);
  return theme;
}
async function setHostTheme(theme) {
  let bus;
  try {
    // @ts-expect-error - `module` is injected by the sandbox runtime
    bus = module?.evaluation?.module?.bundler?.messageBus;
  } catch {
    bus = undefined;
  }
  if (!bus?.protocolRequest) throw Object.assign(new Error("not in sandbox"), {
    code: "unknown"
  });
  const res = await bus.protocolRequest("theme", "set", [{
    theme
  }]);
  if (!res || res.ok !== true) {
    const err = new Error(res?.message ?? "setHostTheme failed");
    err.code = (res && "code" in res ? res.code : undefined) ?? "unknown";
    throw err;
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiYnVuZGxlciIsIm1vZHVsZSIsImV2YWx1YXRpb24iLCJnZXRIb3N0VGhlbWUiLCJ0IiwidGhlbWUiLCJnZXRUaGVtZSIsInVzZUhvc3RUaGVtZSIsInNldFRoZW1lIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJzdmMiLCJvbkNoYW5nZSIsImQiLCJkaXNwb3NlIiwic2V0SG9zdFRoZW1lIiwiYnVzIiwibWVzc2FnZUJ1cyIsInVuZGVmaW5lZCIsInByb3RvY29sUmVxdWVzdCIsIk9iamVjdCIsImFzc2lnbiIsIkVycm9yIiwiY29kZSIsInJlcyIsIm9rIiwiZXJyIiwibWVzc2FnZSJdLCJzb3VyY2VzIjpbImhvc3RUaGVtZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBTZXQgdGhlIGhvc3QgVUkgdGhlbWUg4oCUIHRoZSBlbGV2YXRlZCBgdGhlbWU6c2V0YCBhY3Rpb24gKFVJX0FTX0FQUFNfU1BFQyDCpzguNSkuXG4vL1xuLy8gVGhpcyBpcyBhIExPQ0FMIGNvcHkgb2YgdGhlIFNESydzIGBzZXRIb3N0VGhlbWVgIChhZGRlZCBpbiB0aGUgU0RLIHNvdXJjZSBidXRcbi8vIG5vdCB5ZXQgb24gbnBtKS4gSXQgY2FsbHMgdGhlIHNhbWUgZ2F0ZWQgcGF0aCB0aGUgU0RLIHdyYXBzOiB0aGUgc2FuZGJveFxuLy8gYnVuZGxlcidzIG1lc3NhZ2UgYnVzIGBwcm90b2NvbFJlcXVlc3QoJ3RoZW1lJywgJ3NldCcsIOKApilgLiBTd2l0Y2ggdG9cbi8vIGBpbXBvcnQgeyBzZXRIb3N0VGhlbWUgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay90aGVtZSdgIG9uY2UgdGhlIFNESyBpc1xuLy8gcmVwdWJsaXNoZWQuIFJlYWRpbmcgdGhlIGhvc3QgdGhlbWUgdXNlcyB0aGUgcHVibGlzaGVkIGB1c2VIb3N0VGhlbWVgLlxuLy9cbi8vIFRoZSBob3N0IGdhdGUgKMKnOC40KSByZWplY3RzIHRoaXMgdW5sZXNzIHRoZSBjYWxsaW5nIGlmcmFtZSdzIGdyYW50IGhvbGRzXG4vLyBgdGhlbWU6c2V0YCwgcmV0dXJuaW5nIGEgYHsgb2s6ZmFsc2UsIGNvZGU6J2ZvcmJpZGRlbicgfWAgZW52ZWxvcGUg4oCUIHdlIHRocm93XG4vLyBhbiBFcnJvciBjYXJyeWluZyB0aGF0IGAuY29kZWAgc28gdGhlIFVJIGNhbiBmYWxsIGJhY2sgdG8gXCJwcmV2aWV3IG9ubHlcIi5cblxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgdHlwZSBIb3N0VGhlbWUgPSBcImxpZ2h0XCIgfCBcImRhcmtcIjtcblxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuZnVuY3Rpb24gYnVuZGxlcigpOiBhbnkgfCBudWxsIHtcbiAgdHJ5IHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gYG1vZHVsZWAgaXMgaW5qZWN0ZWQgYnkgdGhlIHNhbmRib3ggcnVudGltZVxuICAgIHJldHVybiBtb2R1bGU/LmV2YWx1YXRpb24/Lm1vZHVsZT8uYnVuZGxlciA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vLyBSZWFkaW5nIHRoZSBob3N0IHRoZW1lOiB0aGUgcHVibGlzaGVkIFNESyAwLjEuNSBoYXMgbm8gYHRoZW1lYCBleHBvcnQsIHNvIHdlXG4vLyByZWFkIHRoZSBzYW1lIGJ1bmRsZXIgdGhlbWUgc2VydmljZSB0aGUgU0RLJ3MgYHVzZUhvc3RUaGVtZWAgd3JhcHMuIEJhc2VsaW5lXG4vLyBgdGhlbWU6cmVhZGAg4oCUIGV2ZXJ5IGFwcCBtYXkgcmVhZCBpdC5cbmV4cG9ydCBmdW5jdGlvbiBnZXRIb3N0VGhlbWUoKTogSG9zdFRoZW1lIHtcbiAgY29uc3QgdCA9IGJ1bmRsZXIoKT8udGhlbWU/LmdldFRoZW1lPy4oKTtcbiAgcmV0dXJuIHQgPT09IFwibGlnaHRcIiA/IFwibGlnaHRcIiA6IFwiZGFya1wiO1xufVxuXG4vKiogUmVhY3QgaG9vazogdGhlIGN1cnJlbnQgaG9zdCB0aGVtZSwgcmUtcmVuZGVyaW5nIG9uIGhvc3QgcmUtcHVzaC4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VIb3N0VGhlbWUoKTogSG9zdFRoZW1lIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZTxIb3N0VGhlbWU+KGdldEhvc3RUaGVtZSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc3ZjID0gYnVuZGxlcigpPy50aGVtZTtcbiAgICBpZiAoIXN2Yz8ub25DaGFuZ2UpIHJldHVybjtcbiAgICBjb25zdCBkID0gc3ZjLm9uQ2hhbmdlKCh0OiBzdHJpbmcpID0+IHNldFRoZW1lKHQgPT09IFwibGlnaHRcIiA/IFwibGlnaHRcIiA6IFwiZGFya1wiKSk7XG4gICAgcmV0dXJuICgpID0+IGQ/LmRpc3Bvc2U/LigpO1xuICB9LCBbXSk7XG4gIHJldHVybiB0aGVtZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEhvc3RUaGVtZSh0aGVtZTogSG9zdFRoZW1lKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBidXM6IGFueTtcbiAgdHJ5IHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gYG1vZHVsZWAgaXMgaW5qZWN0ZWQgYnkgdGhlIHNhbmRib3ggcnVudGltZVxuICAgIGJ1cyA9IG1vZHVsZT8uZXZhbHVhdGlvbj8ubW9kdWxlPy5idW5kbGVyPy5tZXNzYWdlQnVzO1xuICB9IGNhdGNoIHtcbiAgICBidXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKCFidXM/LnByb3RvY29sUmVxdWVzdCkgdGhyb3cgT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoXCJub3QgaW4gc2FuZGJveFwiKSwgeyBjb2RlOiBcInVua25vd25cIiB9KTtcblxuICBjb25zdCByZXMgPSAoYXdhaXQgYnVzLnByb3RvY29sUmVxdWVzdChcInRoZW1lXCIsIFwic2V0XCIsIFt7IHRoZW1lIH1dKSkgYXNcbiAgICB8IHsgb2s6IHRydWU7IGRhdGE/OiB1bmtub3duIH1cbiAgICB8IHsgb2s6IGZhbHNlOyBjb2RlPzogc3RyaW5nOyBtZXNzYWdlPzogc3RyaW5nIH1cbiAgICB8IHVuZGVmaW5lZDtcbiAgaWYgKCFyZXMgfHwgcmVzLm9rICE9PSB0cnVlKSB7XG4gICAgY29uc3QgZXJyID0gbmV3IEVycm9yKHJlcz8ubWVzc2FnZSA/PyBcInNldEhvc3RUaGVtZSBmYWlsZWRcIikgYXMgRXJyb3IgJiB7XG4gICAgICBjb2RlPzogc3RyaW5nO1xuICAgIH07XG4gICAgZXJyLmNvZGUgPSAocmVzICYmIFwiY29kZVwiIGluIHJlcyA/IHJlcy5jb2RlIDogdW5kZWZpbmVkKSA/PyBcInVua25vd25cIjtcbiAgICB0aHJvdyBlcnI7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFZQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BO0FBQ0EsU0FBU0MsT0FBT0EsQ0FBQSxFQUFlO0VBQzdCLElBQUk7SUFDRjtJQUNBLE9BQU9DLE1BQU0sRUFBRUMsVUFBVSxFQUFFRCxNQUFNLEVBQUVELE9BQU8sSUFBSSxJQUFJO0VBQ3BELENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBTyxJQUFJO0VBQ2I7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDTyxTQUFTRyxZQUFZQSxDQUFBLEVBQWM7RUFDeEMsTUFBTUMsQ0FBQyxHQUFHSixPQUFPLENBQUMsQ0FBQyxFQUFFSyxLQUFLLEVBQUVDLFFBQVEsR0FBRyxDQUFDO0VBQ3hDLE9BQU9GLENBQUMsS0FBSyxPQUFPLEdBQUcsT0FBTyxHQUFHLE1BQU07QUFDekM7O0FBRUE7QUFDTyxTQUFTRyxZQUFZQSxDQUFBLEVBQWM7RUFDeEMsTUFBTSxDQUFDRixLQUFLLEVBQUVHLFFBQVEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBWU4sWUFBWSxDQUFDO0VBQzNELElBQUFPLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE1BQU1DLEdBQUcsR0FBR1gsT0FBTyxDQUFDLENBQUMsRUFBRUssS0FBSztJQUM1QixJQUFJLENBQUNNLEdBQUcsRUFBRUMsUUFBUSxFQUFFO0lBQ3BCLE1BQU1DLENBQUMsR0FBR0YsR0FBRyxDQUFDQyxRQUFRLENBQUVSLENBQVMsSUFBS0ksUUFBUSxDQUFDSixDQUFDLEtBQUssT0FBTyxHQUFHLE9BQU8sR0FBRyxNQUFNLENBQUMsQ0FBQztJQUNqRixPQUFPLE1BQU1TLENBQUMsRUFBRUMsT0FBTyxHQUFHLENBQUM7RUFDN0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNOLE9BQU9ULEtBQUs7QUFDZDtBQUVPLGVBQWVVLFlBQVlBLENBQUNWLEtBQWdCLEVBQWlCO0VBQ2xFLElBQUlXLEdBQVE7RUFDWixJQUFJO0lBQ0Y7SUFDQUEsR0FBRyxHQUFHZixNQUFNLEVBQUVDLFVBQVUsRUFBRUQsTUFBTSxFQUFFRCxPQUFPLEVBQUVpQixVQUFVO0VBQ3ZELENBQUMsQ0FBQyxNQUFNO0lBQ05ELEdBQUcsR0FBR0UsU0FBUztFQUNqQjtFQUNBLElBQUksQ0FBQ0YsR0FBRyxFQUFFRyxlQUFlLEVBQUUsTUFBTUMsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7SUFBRUMsSUFBSSxFQUFFO0VBQVUsQ0FBQyxDQUFDO0VBRWhHLE1BQU1DLEdBQUcsR0FBSSxNQUFNUixHQUFHLENBQUNHLGVBQWUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUM7SUFBRWQ7RUFBTSxDQUFDLENBQUMsQ0FHckQ7RUFDYixJQUFJLENBQUNtQixHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsRUFBRSxLQUFLLElBQUksRUFBRTtJQUMzQixNQUFNQyxHQUFHLEdBQUcsSUFBSUosS0FBSyxDQUFDRSxHQUFHLEVBQUVHLE9BQU8sSUFBSSxxQkFBcUIsQ0FFMUQ7SUFDREQsR0FBRyxDQUFDSCxJQUFJLEdBQUcsQ0FBQ0MsR0FBRyxJQUFJLE1BQU0sSUFBSUEsR0FBRyxHQUFHQSxHQUFHLENBQUNELElBQUksR0FBR0wsU0FBUyxLQUFLLFNBQVM7SUFDckUsTUFBTVEsR0FBRztFQUNYO0FBQ0YiLCJpZ25vcmVMaXN0IjpbXX0=